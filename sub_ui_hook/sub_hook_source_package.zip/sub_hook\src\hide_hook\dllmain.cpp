#include <windows.h>
#include <psapi.h>
#include <tlhelp32.h>

#include <atomic>
#include <mutex>
#include <string_view>
#include <vector>

namespace {

using CreateWindowExWType = HWND(WINAPI*)(DWORD, LPCWSTR, LPCWSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);
using CreateWindowExAType = HWND(WINAPI*)(DWORD, LPCSTR, LPCSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);
using ShowWindowType = BOOL(WINAPI*)(HWND, int);
using SetWindowPosType = BOOL(WINAPI*)(HWND, HWND, int, int, int, int, UINT);
using BringWindowToTopType = BOOL(WINAPI*)(HWND);
using SetForegroundWindowType = BOOL(WINAPI*)(HWND);

struct ThreadHooks {
    DWORD threadId = 0;
    HHOOK cbtHook = nullptr;
    HHOOK callWndHook = nullptr;
};

std::mutex g_hookMutex;
std::atomic_bool g_hooksInstalled = false;
std::atomic_bool g_stopping = false;
HMODULE g_thisModule = nullptr;
HWINEVENTHOOK g_showEventHook = nullptr;
std::vector<ThreadHooks> g_threadHooks;

CreateWindowExWType g_createWindowExW = nullptr;
CreateWindowExAType g_createWindowExA = nullptr;
ShowWindowType g_showWindow = nullptr;
SetWindowPosType g_setWindowPos = nullptr;
BringWindowToTopType g_bringWindowToTop = nullptr;
SetForegroundWindowType g_setForegroundWindow = nullptr;

HWND WINAPI hookCreateWindowExW(DWORD exStyle, LPCWSTR className, LPCWSTR windowName, DWORD style, int x, int y, int width, int height, HWND parent, HMENU menu, HINSTANCE instance, LPVOID param);
HWND WINAPI hookCreateWindowExA(DWORD exStyle, LPCSTR className, LPCSTR windowName, DWORD style, int x, int y, int width, int height, HWND parent, HMENU menu, HINSTANCE instance, LPVOID param);
BOOL WINAPI hookShowWindow(HWND hwnd, int command);
BOOL WINAPI hookSetWindowPos(HWND hwnd, HWND insertAfter, int x, int y, int cx, int cy, UINT flags);
BOOL WINAPI hookBringWindowToTop(HWND hwnd);
BOOL WINAPI hookSetForegroundWindow(HWND hwnd);

bool isCurrentProcessWindow(HWND hwnd) {
    DWORD processId = 0;
    GetWindowThreadProcessId(hwnd, &processId);
    return processId == GetCurrentProcessId();
}

void forceHideWindow(HWND hwnd) {
    if (hwnd == nullptr || !isCurrentProcessWindow(hwnd)) {
        return;
    }

    if (g_setWindowPos != nullptr) {
        g_setWindowPos(hwnd, nullptr, 0, 0, 0, 0, SWP_HIDEWINDOW | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
    }
    if (g_showWindow != nullptr) {
        g_showWindow(hwnd, SW_HIDE);
    }
}

BOOL CALLBACK hideExistingWindow(HWND hwnd, LPARAM) {
    forceHideWindow(hwnd);
    return TRUE;
}

bool equalsIgnoreCaseAscii(std::string_view left, std::string_view right) {
    if (left.size() != right.size()) {
        return false;
    }
    for (size_t i = 0; i < left.size(); ++i) {
        char a = left[i];
        char b = right[i];
        if (a >= 'A' && a <= 'Z') {
            a = static_cast<char>(a - 'A' + 'a');
        }
        if (b >= 'A' && b <= 'Z') {
            b = static_cast<char>(b - 'A' + 'a');
        }
        if (a != b) {
            return false;
        }
    }
    return true;
}

void* replacementFor(std::string_view dllName, const char* functionName) {
    if (functionName == nullptr || !equalsIgnoreCaseAscii(dllName, "user32.dll")) {
        return nullptr;
    }
    if (std::string_view(functionName) == "CreateWindowExW") {
        return reinterpret_cast<void*>(&hookCreateWindowExW);
    }
    if (std::string_view(functionName) == "CreateWindowExA") {
        return reinterpret_cast<void*>(&hookCreateWindowExA);
    }
    if (std::string_view(functionName) == "ShowWindow") {
        return reinterpret_cast<void*>(&hookShowWindow);
    }
    if (std::string_view(functionName) == "SetWindowPos") {
        return reinterpret_cast<void*>(&hookSetWindowPos);
    }
    if (std::string_view(functionName) == "BringWindowToTop") {
        return reinterpret_cast<void*>(&hookBringWindowToTop);
    }
    if (std::string_view(functionName) == "SetForegroundWindow") {
        return reinterpret_cast<void*>(&hookSetForegroundWindow);
    }
    return nullptr;
}

void patchImport(HMODULE module, IMAGE_THUNK_DATA* thunk, void* replacement) {
    DWORD oldProtect = 0;
    if (VirtualProtect(&thunk->u1.Function, sizeof(void*), PAGE_READWRITE, &oldProtect) == FALSE) {
        return;
    }
    thunk->u1.Function = reinterpret_cast<ULONG_PTR>(replacement);
    DWORD ignored = 0;
    VirtualProtect(&thunk->u1.Function, sizeof(void*), oldProtect, &ignored);
    FlushInstructionCache(GetCurrentProcess(), &thunk->u1.Function, sizeof(void*));
}

void patchModuleImports(HMODULE module) {
    if (module == nullptr || module == g_thisModule) {
        return;
    }

    auto base = reinterpret_cast<unsigned char*>(module);
    auto dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) {
        return;
    }

    auto nt = reinterpret_cast<IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) {
        return;
    }

    const auto& importDirectory = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (importDirectory.VirtualAddress == 0) {
        return;
    }

    auto imports = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + importDirectory.VirtualAddress);
    for (; imports->Name != 0; ++imports) {
        const char* dllName = reinterpret_cast<const char*>(base + imports->Name);
        if (imports->OriginalFirstThunk == 0 || imports->FirstThunk == 0) {
            continue;
        }

        auto originalThunk = reinterpret_cast<IMAGE_THUNK_DATA*>(base + imports->OriginalFirstThunk);
        auto thunk = reinterpret_cast<IMAGE_THUNK_DATA*>(base + imports->FirstThunk);
        for (; originalThunk->u1.AddressOfData != 0; ++originalThunk, ++thunk) {
            if (IMAGE_SNAP_BY_ORDINAL(originalThunk->u1.Ordinal)) {
                continue;
            }
            auto importByName = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + originalThunk->u1.AddressOfData);
            void* replacement = replacementFor(dllName, reinterpret_cast<const char*>(importByName->Name));
            if (replacement != nullptr && reinterpret_cast<void*>(thunk->u1.Function) != replacement) {
                patchImport(module, thunk, replacement);
            }
        }
    }
}

void patchAllLoadedModules() {
    std::lock_guard lock(g_hookMutex);

    HMODULE modules[1024]{};
    DWORD needed = 0;
    if (EnumProcessModules(GetCurrentProcess(), modules, sizeof(modules), &needed) == FALSE) {
        return;
    }

    const DWORD count = needed / sizeof(HMODULE);
    for (DWORD i = 0; i < count; ++i) {
        patchModuleImports(modules[i]);
    }
}

LRESULT CALLBACK cbtProc(int code, WPARAM wParam, LPARAM lParam) {
    if (code == HCBT_CREATEWND || code == HCBT_ACTIVATE || code == HCBT_SETFOCUS) {
        forceHideWindow(reinterpret_cast<HWND>(wParam));
    }
    return CallNextHookEx(nullptr, code, wParam, lParam);
}

LRESULT CALLBACK callWndProc(int code, WPARAM wParam, LPARAM lParam) {
    if (code >= 0 && lParam != 0) {
        const auto* message = reinterpret_cast<const CWPSTRUCT*>(lParam);
        if (message->message == WM_SHOWWINDOW || message->message == WM_WINDOWPOSCHANGING || message->message == WM_WINDOWPOSCHANGED) {
            forceHideWindow(message->hwnd);
        }
    }
    return CallNextHookEx(nullptr, code, wParam, lParam);
}

void CALLBACK winEventProc(HWINEVENTHOOK, DWORD, HWND hwnd, LONG, LONG, DWORD, DWORD) {
    forceHideWindow(hwnd);
}

bool hasThreadHook(DWORD threadId) {
    for (const ThreadHooks& hooks : g_threadHooks) {
        if (hooks.threadId == threadId) {
            return true;
        }
    }
    return false;
}

void installThreadHooks() {
    std::lock_guard lock(g_hookMutex);

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        return;
    }

    THREADENTRY32 entry{};
    entry.dwSize = sizeof(entry);
    if (Thread32First(snapshot, &entry) == FALSE) {
        CloseHandle(snapshot);
        return;
    }

    const DWORD processId = GetCurrentProcessId();
    do {
        if (entry.th32OwnerProcessID != processId || hasThreadHook(entry.th32ThreadID)) {
            continue;
        }

        ThreadHooks hooks{};
        hooks.threadId = entry.th32ThreadID;
        hooks.cbtHook = SetWindowsHookExW(WH_CBT, cbtProc, g_thisModule, entry.th32ThreadID);
        hooks.callWndHook = SetWindowsHookExW(WH_CALLWNDPROC, callWndProc, g_thisModule, entry.th32ThreadID);
        if (hooks.cbtHook != nullptr || hooks.callWndHook != nullptr) {
            g_threadHooks.push_back(hooks);
        }
    } while (Thread32Next(snapshot, &entry) != FALSE);

    CloseHandle(snapshot);
}

void uninstallThreadHooks() {
    std::lock_guard lock(g_hookMutex);
    for (const ThreadHooks& hooks : g_threadHooks) {
        if (hooks.cbtHook != nullptr) {
            UnhookWindowsHookEx(hooks.cbtHook);
        }
        if (hooks.callWndHook != nullptr) {
            UnhookWindowsHookEx(hooks.callWndHook);
        }
    }
    g_threadHooks.clear();
}

DWORD WINAPI hookThread(void*) {
    g_createWindowExW = reinterpret_cast<CreateWindowExWType>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "CreateWindowExW"));
    g_createWindowExA = reinterpret_cast<CreateWindowExAType>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "CreateWindowExA"));
    g_showWindow = reinterpret_cast<ShowWindowType>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "ShowWindow"));
    g_setWindowPos = reinterpret_cast<SetWindowPosType>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetWindowPos"));
    g_bringWindowToTop = reinterpret_cast<BringWindowToTopType>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "BringWindowToTop"));
    g_setForegroundWindow = reinterpret_cast<SetForegroundWindowType>(GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetForegroundWindow"));

    g_showEventHook = SetWinEventHook(
        EVENT_OBJECT_SHOW,
        EVENT_OBJECT_SHOW,
        nullptr,
        winEventProc,
        GetCurrentProcessId(),
        0,
        WINEVENT_OUTOFCONTEXT);

    g_hooksInstalled = true;
    while (!g_stopping.load()) {
        MSG message{};
        while (PeekMessageW(&message, nullptr, 0, 0, PM_REMOVE) != FALSE) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }

        installThreadHooks();
        patchAllLoadedModules();
        EnumWindows(hideExistingWindow, 0);
        Sleep(100);
    }

    if (g_showEventHook != nullptr) {
        UnhookWinEvent(g_showEventHook);
    }
    uninstallThreadHooks();
    return 0;
}

HWND WINAPI hookCreateWindowExW(DWORD exStyle, LPCWSTR className, LPCWSTR windowName, DWORD style, int x, int y, int width, int height, HWND parent, HMENU menu, HINSTANCE instance, LPVOID param) {
    style &= ~WS_VISIBLE;
    HWND hwnd = g_createWindowExW(exStyle, className, windowName, style, x, y, width, height, parent, menu, instance, param);
    forceHideWindow(hwnd);
    return hwnd;
}

HWND WINAPI hookCreateWindowExA(DWORD exStyle, LPCSTR className, LPCSTR windowName, DWORD style, int x, int y, int width, int height, HWND parent, HMENU menu, HINSTANCE instance, LPVOID param) {
    style &= ~WS_VISIBLE;
    HWND hwnd = g_createWindowExA(exStyle, className, windowName, style, x, y, width, height, parent, menu, instance, param);
    forceHideWindow(hwnd);
    return hwnd;
}

BOOL WINAPI hookShowWindow(HWND hwnd, int) {
    forceHideWindow(hwnd);
    return TRUE;
}

BOOL WINAPI hookSetWindowPos(HWND hwnd, HWND insertAfter, int x, int y, int cx, int cy, UINT flags) {
    flags |= SWP_HIDEWINDOW | SWP_NOACTIVATE;
    flags &= ~SWP_SHOWWINDOW;
    return g_setWindowPos(hwnd, insertAfter, x, y, cx, cy, flags);
}

BOOL WINAPI hookBringWindowToTop(HWND hwnd) {
    forceHideWindow(hwnd);
    return TRUE;
}

BOOL WINAPI hookSetForegroundWindow(HWND hwnd) {
    forceHideWindow(hwnd);
    return FALSE;
}

} // namespace

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_thisModule = module;
        DisableThreadLibraryCalls(module);
        HANDLE thread = CreateThread(nullptr, 0, hookThread, nullptr, 0, nullptr);
        if (thread != nullptr) {
            CloseHandle(thread);
        }
    } else if (reason == DLL_PROCESS_DETACH) {
        g_stopping = true;
    }
    return TRUE;
}
