# Build From Zip

This package contains the `sub_hook` source code and a portable Visual Studio solution.

## Option 1: Visual Studio Solution

Open:

```text
vs\sub_hook.sln
```

Select `Release|x64` and build the solution.

Outputs are written to:

```text
out\Release\
```

For the fixed-entry UI deployment, place these files together:

```text
sub_hook_default_ui.exe
hide_window_hook.dll
entry.userdef
```

## Option 2: CMake

```powershell
cmake -S . -B build
cmake --build build --config Release
```

Outputs are written to:

```text
build\Release\
```
