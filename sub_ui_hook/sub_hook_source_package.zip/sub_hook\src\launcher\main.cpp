#include <windows.h>

#include <filesystem>
#include <iostream>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace {

struct Options {
    bool waitForExit = false;
    std::filesystem::path dllPath;
    std::filesystem::path targetPath;
    std::vector<std::wstring> targetArgs;
};

std::wstring getLastErrorMessage(DWORD error = GetLastError()) {
    LPWSTR buffer = nullptr;
    const DWORD size = FormatMessageW(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,
        error,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        reinterpret_cast<LPWSTR>(&buffer),
        0,
        nullptr);

    std::wstring message = size == 0 ? L"unknown error" : std::wstring(buffer, size);
    if (buffer != nullptr) {
        LocalFree(buffer);
    }
    while (!message.empty() && (message.back() == L'\r' || message.back() == L'\n')) {
        message.pop_back();
    }
    return message;
}

std::filesystem::path getCurrentExecutableDirectory() {
    std::wstring buffer(MAX_PATH, L'\0');
    DWORD length = 0;
    for (;;) {
        length = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
        if (length == 0) {
            throw std::runtime_error("GetModuleFileNameW failed");
        }
        if (length < buffer.size() - 1) {
            buffer.resize(length);
            return std::filesystem::path(buffer).parent_path();
        }
        buffer.resize(buffer.size() * 2);
    }
}

std::wstring quoteArgument(std::wstring_view value) {
    if (value.empty()) {
        return L"\"\"";
    }

    const bool needsQuotes = value.find_first_of(L" \t\n\v\"") != std::wstring_view::npos;
    if (!needsQuotes) {
        return std::wstring(value);
    }

    std::wstring quoted = L"\"";
    size_t backslashes = 0;
    for (const wchar_t ch : value) {
        if (ch == L'\\') {
            ++backslashes;
            continue;
        }
        if (ch == L'\"') {
            quoted.append(backslashes * 2 + 1, L'\\');
            quoted.push_back(ch);
            backslashes = 0;
            continue;
        }
        quoted.append(backslashes, L'\\');
        backslashes = 0;
        quoted.push_back(ch);
    }
    quoted.append(backslashes * 2, L'\\');
    quoted.push_back(L'\"');
    return quoted;
}

std::wstring buildTargetCommandLine(const Options& options) {
    std::wstring commandLine = quoteArgument(options.targetPath.wstring());
    for (const auto& arg : options.targetArgs) {
        commandLine.push_back(L' ');
        commandLine += quoteArgument(arg);
    }
    return commandLine;
}

void printUsage() {
    std::wcerr << L"Usage:\n"
               << L"  sub_hook_launcher.exe [--wait] [--dll <hide_window_hook.dll>] -- <target-pe-file> [args...]\n"
               << L"  sub_hook_launcher.exe [--wait] [--dll <hide_window_hook.dll>] <target-pe-file> [args...]\n";
}

std::optional<Options> parseOptions(int argc, wchar_t** argv, bool& helpRequested) {
    Options options;
    int index = 1;
    for (; index < argc; ++index) {
        const std::wstring_view arg(argv[index]);
        if (arg == L"--") {
            ++index;
            break;
        }
        if (arg == L"--wait") {
            options.waitForExit = true;
            continue;
        }
        if (arg == L"--dll") {
            if (++index >= argc) {
                std::wcerr << L"Missing value for --dll\n";
                return std::nullopt;
            }
            options.dllPath = argv[index];
            continue;
        }
        if (arg == L"--help" || arg == L"-h") {
            printUsage();
            helpRequested = true;
            return std::nullopt;
        }
        break;
    }

    if (index >= argc) {
        printUsage();
        return std::nullopt;
    }

    options.targetPath = argv[index++];
    for (; index < argc; ++index) {
        options.targetArgs.emplace_back(argv[index]);
    }

    if (options.dllPath.empty()) {
        options.dllPath = getCurrentExecutableDirectory() / L"hide_window_hook.dll";
    }

    return options;
}

bool injectDll(HANDLE process, const std::filesystem::path& dllPath) {
    const std::wstring absoluteDllPath = std::filesystem::absolute(dllPath).wstring();
    const size_t bytes = (absoluteDllPath.size() + 1) * sizeof(wchar_t);

    LPVOID remotePath = VirtualAllocEx(process, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (remotePath == nullptr) {
        std::wcerr << L"VirtualAllocEx failed: " << getLastErrorMessage() << L"\n";
        return false;
    }

    bool ok = WriteProcessMemory(process, remotePath, absoluteDllPath.c_str(), bytes, nullptr) != FALSE;
    if (!ok) {
        std::wcerr << L"WriteProcessMemory failed: " << getLastErrorMessage() << L"\n";
        VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
        return false;
    }

    HMODULE kernel32 = GetModuleHandleW(L"kernel32.dll");
    const auto loadLibrary = reinterpret_cast<LPTHREAD_START_ROUTINE>(GetProcAddress(kernel32, "LoadLibraryW"));
    if (loadLibrary == nullptr) {
        std::wcerr << L"GetProcAddress(LoadLibraryW) failed: " << getLastErrorMessage() << L"\n";
        VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
        return false;
    }

    HANDLE remoteThread = CreateRemoteThread(process, nullptr, 0, loadLibrary, remotePath, 0, nullptr);
    if (remoteThread == nullptr) {
        std::wcerr << L"CreateRemoteThread failed: " << getLastErrorMessage() << L"\n";
        VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
        return false;
    }

    WaitForSingleObject(remoteThread, INFINITE);

    DWORD exitCode = 0;
    ok = GetExitCodeThread(remoteThread, &exitCode) != FALSE && exitCode != 0;
    if (!ok) {
        std::wcerr << L"Remote LoadLibraryW failed. Check DLL path and bitness.\n";
    }

    CloseHandle(remoteThread);
    VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
    return ok;
}

} // namespace

int wmain(int argc, wchar_t** argv) {
    bool helpRequested = false;
    const auto parsed = parseOptions(argc, argv, helpRequested);
    if (!parsed.has_value()) {
        return helpRequested ? 0 : 1;
    }

    const Options& options = *parsed;
    if (!std::filesystem::exists(options.targetPath)) {
        std::wcerr << L"Target file not found: " << options.targetPath.wstring() << L"\n";
        return 1;
    }
    if (!std::filesystem::exists(options.dllPath)) {
        std::wcerr << L"Hook DLL not found: " << options.dllPath.wstring() << L"\n";
        return 1;
    }

    std::wstring commandLine = buildTargetCommandLine(options);
    STARTUPINFOW startupInfo{};
    startupInfo.cb = sizeof(startupInfo);
    PROCESS_INFORMATION processInfo{};

    const BOOL created = CreateProcessW(
        options.targetPath.c_str(),
        commandLine.data(),
        nullptr,
        nullptr,
        FALSE,
        CREATE_SUSPENDED,
        nullptr,
        nullptr,
        &startupInfo,
        &processInfo);

    if (!created) {
        std::wcerr << L"CreateProcessW failed: " << getLastErrorMessage() << L"\n";
        return 1;
    }

    const bool injected = injectDll(processInfo.hProcess, options.dllPath);
    if (ResumeThread(processInfo.hThread) == static_cast<DWORD>(-1)) {
        std::wcerr << L"ResumeThread failed: " << getLastErrorMessage() << L"\n";
    }

    DWORD exitCode = injected ? 0 : 1;
    if (options.waitForExit) {
        WaitForSingleObject(processInfo.hProcess, INFINITE);
        GetExitCodeProcess(processInfo.hProcess, &exitCode);
    }

    CloseHandle(processInfo.hThread);
    CloseHandle(processInfo.hProcess);
    return static_cast<int>(exitCode);
}
