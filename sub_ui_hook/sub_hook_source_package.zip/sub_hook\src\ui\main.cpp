#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>

#include <filesystem>
#include <string>
#include <string_view>

namespace {

constexpr int IdTargetEdit = 1001;
constexpr int IdTargetBrowse = 1002;
constexpr int IdParamEdit = 1003;
constexpr int IdDllEdit = 1004;
constexpr int IdDllBrowse = 1005;
constexpr int IdWaitCheck = 1006;
constexpr int IdLaunchButton = 1007;
constexpr int IdStatusText = 1008;

HWND g_targetEdit = nullptr;
HWND g_paramEdit = nullptr;
HWND g_dllEdit = nullptr;
HWND g_waitCheck = nullptr;
HWND g_statusText = nullptr;
HFONT g_titleFont = nullptr;
HFONT g_textFont = nullptr;
HBRUSH g_backgroundBrush = nullptr;
HBRUSH g_panelBrush = nullptr;
HANDLE g_childJob = nullptr;
COLORREF g_textColor = RGB(32, 32, 32);
COLORREF g_mutedTextColor = RGB(92, 92, 92);

std::filesystem::path getExecutableDirectory() {
    std::wstring buffer(MAX_PATH, L'\0');
    for (;;) {
        const DWORD length = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
        if (length == 0) {
            return {};
        }
        if (length < buffer.size() - 1) {
            buffer.resize(length);
            return std::filesystem::path(buffer).parent_path();
        }
        buffer.resize(buffer.size() * 2);
    }
}

std::wstring getWindowText(HWND hwnd) {
    const int length = GetWindowTextLengthW(hwnd);
    std::wstring value(static_cast<size_t>(length) + 1, L'\0');
    if (length > 0) {
        GetWindowTextW(hwnd, value.data(), length + 1);
    }
    value.resize(static_cast<size_t>(length));
    return value;
}

void setStatus(std::wstring_view text) {
    SetWindowTextW(g_statusText, std::wstring(text).c_str());
}

bool ensureChildJob() {
    if (g_childJob != nullptr) {
        return true;
    }

    g_childJob = CreateJobObjectW(nullptr, nullptr);
    if (g_childJob == nullptr) {
        return false;
    }

    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limitInfo{};
    limitInfo.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (SetInformationJobObject(g_childJob, JobObjectExtendedLimitInformation, &limitInfo, sizeof(limitInfo)) == FALSE) {
        CloseHandle(g_childJob);
        g_childJob = nullptr;
        return false;
    }

    return true;
}

std::wstring quoteArgument(std::wstring_view value) {
    if (value.empty()) {
        return L"\"\"";
    }

    const bool needsQuotes = value.find_first_of(L" \t\n\v\"") != std::wstring_view::npos;
    if (!needsQuotes) {
        return std::wstring(value);
    }

    std::wstring quoted = L"\"";
    size_t backslashes = 0;
    for (const wchar_t valueChar : value) {
        if (valueChar == L'\\') {
            ++backslashes;
            continue;
        }
        if (valueChar == L'\"') {
            quoted.append(backslashes * 2 + 1, L'\\');
            quoted.push_back(valueChar);
            backslashes = 0;
            continue;
        }
        quoted.append(backslashes, L'\\');
        backslashes = 0;
        quoted.push_back(valueChar);
    }
    quoted.append(backslashes * 2, L'\\');
    quoted.push_back(L'\"');
    return quoted;
}

std::wstring browseForFile(HWND owner, const wchar_t* filter) {
    std::wstring fileName(MAX_PATH, L'\0');
    OPENFILENAMEW openFile{};
    openFile.lStructSize = sizeof(openFile);
    openFile.hwndOwner = owner;
    openFile.lpstrFilter = filter;
    openFile.lpstrFile = fileName.data();
    openFile.nMaxFile = static_cast<DWORD>(fileName.size());
    openFile.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;

    if (GetOpenFileNameW(&openFile) == FALSE) {
        return {};
    }

    fileName.resize(wcslen(fileName.c_str()));
    return fileName;
}

HWND createLabel(HWND parent, std::wstring_view text, int x, int y, int width, int height) {
    HWND hwnd = CreateWindowExW(0, L"STATIC", std::wstring(text).c_str(), WS_CHILD | WS_VISIBLE, x, y, width, height, parent, nullptr, nullptr, nullptr);
    SendMessageW(hwnd, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);
    return hwnd;
}

HWND createEdit(HWND parent, int id, int x, int y, int width, int height, std::wstring_view text = L"") {
    HWND hwnd = CreateWindowExW(
        WS_EX_CLIENTEDGE,
        L"EDIT",
        std::wstring(text).c_str(),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | ES_AUTOHSCROLL,
        x,
        y,
        width,
        height,
        parent,
        reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
        nullptr,
        nullptr);
    SendMessageW(hwnd, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);
    return hwnd;
}

HWND createButton(HWND parent, int id, std::wstring_view text, int x, int y, int width, int height) {
    HWND hwnd = CreateWindowExW(
        0,
        L"BUTTON",
        std::wstring(text).c_str(),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
        x,
        y,
        width,
        height,
        parent,
        reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
        nullptr,
        nullptr);
    SendMessageW(hwnd, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);
    return hwnd;
}

bool launchTarget(HWND owner) {
    const std::wstring targetPath = getWindowText(g_targetEdit);
    const std::wstring params = getWindowText(g_paramEdit);
    const std::wstring dllPath = getWindowText(g_dllEdit);
    const bool waitForExit = SendMessageW(g_waitCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;

    if (targetPath.empty()) {
        MessageBoxW(owner, L"Please select a target PE file.", L"sub_hook", MB_ICONWARNING | MB_OK);
        return false;
    }

    const std::filesystem::path launcherPath = getExecutableDirectory() / L"sub_hook_launcher.exe";
    if (!std::filesystem::exists(launcherPath)) {
        MessageBoxW(owner, L"sub_hook_launcher.exe was not found next to the UI executable.", L"sub_hook", MB_ICONERROR | MB_OK);
        return false;
    }
    if (!ensureChildJob()) {
        MessageBoxW(owner, L"Failed to create a process lifetime guard.", L"sub_hook", MB_ICONERROR | MB_OK);
        return false;
    }

    std::wstring commandLine = quoteArgument(launcherPath.wstring());
    if (waitForExit) {
        commandLine += L" --wait";
    }
    if (!dllPath.empty()) {
        commandLine += L" --dll ";
        commandLine += quoteArgument(dllPath);
    }
    commandLine += L" -- ";
    commandLine += quoteArgument(targetPath);
    if (!params.empty()) {
        commandLine.push_back(L' ');
        commandLine += params;
    }

    STARTUPINFOW startupInfo{};
    startupInfo.cb = sizeof(startupInfo);
    startupInfo.dwFlags = STARTF_USESHOWWINDOW;
    startupInfo.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION processInfo{};
    std::wstring mutableCommandLine = commandLine;

    const BOOL created = CreateProcessW(nullptr, mutableCommandLine.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW | CREATE_SUSPENDED, nullptr, nullptr, &startupInfo, &processInfo);
    if (created == FALSE) {
        MessageBoxW(owner, L"Failed to start sub_hook_launcher.exe.", L"sub_hook", MB_ICONERROR | MB_OK);
        return false;
    }

    if (AssignProcessToJobObject(g_childJob, processInfo.hProcess) == FALSE) {
        TerminateProcess(processInfo.hProcess, 1);
        CloseHandle(processInfo.hThread);
        CloseHandle(processInfo.hProcess);
        MessageBoxW(owner, L"Failed to attach the launcher to the UI lifetime guard.", L"sub_hook", MB_ICONERROR | MB_OK);
        return false;
    }

    if (ResumeThread(processInfo.hThread) == static_cast<DWORD>(-1)) {
        TerminateProcess(processInfo.hProcess, 1);
        CloseHandle(processInfo.hThread);
        CloseHandle(processInfo.hProcess);
        MessageBoxW(owner, L"Failed to resume sub_hook_launcher.exe.", L"sub_hook", MB_ICONERROR | MB_OK);
        return false;
    }

    CloseHandle(processInfo.hThread);
    CloseHandle(processInfo.hProcess);
    setStatus(L"Launcher started. Closing this UI will stop the launched process.");
    return true;
}

void createMainControls(HWND hwnd) {
    g_textFont = CreateFontW(-16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    g_titleFont = CreateFontW(-26, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    g_backgroundBrush = CreateSolidBrush(RGB(243, 243, 243));
    g_panelBrush = CreateSolidBrush(RGB(255, 255, 255));

    HWND title = CreateWindowExW(0, L"STATIC", L"sub_hook launcher", WS_CHILD | WS_VISIBLE, 28, 22, 320, 34, hwnd, nullptr, nullptr, nullptr);
    SendMessageW(title, WM_SETFONT, reinterpret_cast<WPARAM>(g_titleFont), TRUE);

    HWND subtitle = CreateWindowExW(0, L"STATIC", L"Start an executable with hidden-window hooks enabled.", WS_CHILD | WS_VISIBLE, 30, 60, 520, 24, hwnd, nullptr, nullptr, nullptr);
    SendMessageW(subtitle, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);

    createLabel(hwnd, L"Target PE file", 32, 112, 180, 22);
    g_targetEdit = createEdit(hwnd, IdTargetEdit, 32, 138, 516, 30);
    createButton(hwnd, IdTargetBrowse, L"Browse", 560, 137, 96, 32);

    createLabel(hwnd, L"Parameters", 32, 188, 180, 22);
    g_paramEdit = createEdit(hwnd, IdParamEdit, 32, 214, 624, 30);

    createLabel(hwnd, L"Hook DLL", 32, 264, 180, 22);
    const std::wstring defaultDllPath = (getExecutableDirectory() / L"hide_window_hook.dll").wstring();
    g_dllEdit = createEdit(hwnd, IdDllEdit, 32, 290, 516, 30, defaultDllPath);
    createButton(hwnd, IdDllBrowse, L"Browse", 560, 289, 96, 32);

    g_waitCheck = CreateWindowExW(0, L"BUTTON", L"Keep launcher alive until target exits", WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_AUTOCHECKBOX, 32, 346, 320, 26, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(IdWaitCheck)), nullptr, nullptr);
    SendMessageW(g_waitCheck, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);

    createButton(hwnd, IdLaunchButton, L"Launch Hidden", 512, 394, 144, 38);
    g_statusText = CreateWindowExW(0, L"STATIC", L"Ready.", WS_CHILD | WS_VISIBLE, 32, 402, 440, 24, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(IdStatusText)), nullptr, nullptr);
    SendMessageW(g_statusText, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);
}

LRESULT CALLBACK windowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_CREATE:
        createMainControls(hwnd);
        return 0;
    case WM_COMMAND: {
        const int controlId = LOWORD(wParam);
        if (controlId == IdTargetBrowse) {
            const std::wstring selected = browseForFile(hwnd, L"Executable or userdef PE Files\0*.exe;*.userdef\0Userdef Files\0*.userdef\0Executable Files\0*.exe\0All Files\0*.*\0");
            if (!selected.empty()) {
                SetWindowTextW(g_targetEdit, selected.c_str());
            }
            return 0;
        }
        if (controlId == IdDllBrowse) {
            const std::wstring selected = browseForFile(hwnd, L"Dynamic Link Libraries\0*.dll\0All Files\0*.*\0");
            if (!selected.empty()) {
                SetWindowTextW(g_dllEdit, selected.c_str());
            }
            return 0;
        }
        if (controlId == IdLaunchButton) {
            launchTarget(hwnd);
            return 0;
        }
        break;
    }
    case WM_CTLCOLORSTATIC: {
        HDC deviceContext = reinterpret_cast<HDC>(wParam);
        SetBkMode(deviceContext, TRANSPARENT);
        SetTextColor(deviceContext, reinterpret_cast<HWND>(lParam) == g_statusText ? g_mutedTextColor : g_textColor);
        return reinterpret_cast<LRESULT>(g_backgroundBrush);
    }
    case WM_ERASEBKGND: {
        RECT rect{};
        GetClientRect(hwnd, &rect);
        FillRect(reinterpret_cast<HDC>(wParam), &rect, g_backgroundBrush);
        RECT panel{20, 96, 668, 448};
        FillRect(reinterpret_cast<HDC>(wParam), &panel, g_panelBrush);
        return 1;
    }
    case WM_DESTROY:
        if (g_titleFont != nullptr) {
            DeleteObject(g_titleFont);
        }
        if (g_textFont != nullptr) {
            DeleteObject(g_textFont);
        }
        if (g_backgroundBrush != nullptr) {
            DeleteObject(g_backgroundBrush);
        }
        if (g_panelBrush != nullptr) {
            DeleteObject(g_panelBrush);
        }
        if (g_childJob != nullptr) {
            CloseHandle(g_childJob);
            g_childJob = nullptr;
        }
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcW(hwnd, message, wParam, lParam);
    }

    return DefWindowProcW(hwnd, message, wParam, lParam);
}

} // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int showCommand) {
    const wchar_t className[] = L"SubHookLauncherWindow";

    WNDCLASSW windowClass{};
    windowClass.lpfnWndProc = windowProc;
    windowClass.hInstance = instance;
    windowClass.lpszClassName = className;
    windowClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    windowClass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);

    if (RegisterClassW(&windowClass) == 0) {
        return 1;
    }

    HWND hwnd = CreateWindowExW(
        0,
        className,
        L"sub_hook",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        704,
        508,
        nullptr,
        nullptr,
        instance,
        nullptr);

    if (hwnd == nullptr) {
        return 1;
    }

    ShowWindow(hwnd, showCommand);
    UpdateWindow(hwnd);

    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }

    return static_cast<int>(message.wParam);
}
