# sub_hook

`sub_hook` is a Windows-only C++ launcher plus injected DLL. The launcher starts a target executable in a suspended state, injects `hide_window_hook.dll`, then resumes the target. The injected DLL suppresses window display in that target process by intercepting common User32 window creation/display APIs and repeatedly hiding windows owned by the process.

This project is intentionally scoped to the child process launched by `sub_hook_launcher.exe`. It does not install a system-wide hook or persist outside the lifetime of the target process.

## Build

```powershell
cmake -S . -B build
cmake --build build --config Release
```

The launcher and DLL are written to the same build output directory for Visual Studio generators, for example:

```text
build\Release\sub_hook_launcher.exe
build\Release\sub_hook_ui.exe
build\Release\sub_hook_default_ui.exe
build\Release\hide_window_hook.dll
```

The launcher and DLL must match the bitness of the target process. Use an x64 build for x64 targets and an x86 build for x86 targets.

## Usage

```powershell
.\build\Release\sub_hook_launcher.exe -- "C:\Path\To\Target.exe" arg1 arg2
.\build\Release\sub_hook_launcher.exe -- "C:\Path\To\XXX.userdef" arg1 arg2
```

The target can be a normal `.exe` or a PE executable renamed to a custom extension such as `.userdef`. The launcher passes the target path to `CreateProcessW` as the application name, so Windows loads the file as an executable image instead of relying on file association.

Optional flags:

```powershell
.\build\Release\sub_hook_launcher.exe --wait -- "C:\Path\To\Target.exe" arg1
.\build\Release\sub_hook_launcher.exe --dll "C:\Path\To\hide_window_hook.dll" -- "C:\Path\To\Target.exe"
```

`--wait` keeps the launcher running until the target process exits and returns the target exit code.

## UI

Run the GUI front end if you want to select the target PE file and parameters from a desktop window:

```powershell
.\build\Release\sub_hook_ui.exe
```

The UI starts `sub_hook_launcher.exe` from the same directory, so keep these files together:

```text
sub_hook_ui.exe
sub_hook_launcher.exe
hide_window_hook.dll
```

Processes launched from the UI are attached to a Windows Job Object. Closing `sub_hook_ui.exe` closes that job and terminates the launcher plus any target process it started.

## Default UI

Run the fixed-entry UI when you want a two-button launcher without any path or parameter configuration:

```powershell
.\build\Release\sub_hook_default_ui.exe
```

Keep these files together in the same directory:

```text
sub_hook_default_ui.exe
hide_window_hook.dll
entry.userdef
```

`Start Program` directly starts `entry.userdef`, injects `hide_window_hook.dll`, and resumes the child process. `Exit Program` closes the process Job Object and terminates the started child process. Closing the UI window performs the same cleanup.

## How It Works

- `sub_hook_launcher.exe` calls `CreateProcessW` with `CREATE_SUSPENDED`.
- It injects `hide_window_hook.dll` with `VirtualAllocEx`, `WriteProcessMemory`, and a remote `LoadLibraryW` thread.
- The DLL patches loaded modules' import tables for selected User32 APIs:
  - `CreateWindowExW`
  - `CreateWindowExA`
  - `ShowWindow`
  - `SetWindowPos`
  - `BringWindowToTop`
  - `SetForegroundWindow`
- The DLL installs thread-level `WH_CBT` and `WH_CALLWNDPROC` hooks for threads owned by the target process, then periodically picks up new threads.
- A process-scoped `EVENT_OBJECT_SHOW` WinEvent hook and a small message pump provide an additional display-event fallback.
- The DLL also enumerates windows owned by the target process and hides them as a fallback.

## Limitations

- This is not a kernel-level or system-wide window blocker.
- Direct syscalls, custom rendering surfaces, child processes spawned later, or dynamically resolved User32 calls may need additional interception.
- Some applications may briefly create a window before the fallback loop hides it.
- Protected, elevated, or cross-integrity targets may reject DLL injection unless the launcher is run at a compatible integrity level.
