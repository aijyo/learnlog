#include <windows.h>

#include <filesystem>
#include <string>
#include <string_view>

namespace {

constexpr int IdStartButton = 2001;
constexpr int IdStopButton = 2002;
constexpr int IdStatusText = 2003;

HWND g_startButton = nullptr;
HWND g_stopButton = nullptr;
HWND g_statusText = nullptr;
HFONT g_titleFont = nullptr;
HFONT g_textFont = nullptr;
HBRUSH g_backgroundBrush = nullptr;
HBRUSH g_panelBrush = nullptr;
HANDLE g_childJob = nullptr;
HANDLE g_entryProcess = nullptr;
COLORREF g_textColor = RGB(28, 28, 28);
COLORREF g_statusColor = RGB(88, 88, 88);

std::filesystem::path getExecutableDirectory() {
    std::wstring buffer(MAX_PATH, L'\0');
    for (;;) {
        const DWORD length = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
        if (length == 0) {
            return {};
        }
        if (length < buffer.size() - 1) {
            buffer.resize(length);
            return std::filesystem::path(buffer).parent_path();
        }
        buffer.resize(buffer.size() * 2);
    }
}

void setStatus(std::wstring_view text) {
    SetWindowTextW(g_statusText, std::wstring(text).c_str());
}

void updateButtons(bool running) {
    EnableWindow(g_startButton, running ? FALSE : TRUE);
    EnableWindow(g_stopButton, running ? TRUE : FALSE);
}

std::wstring getLastErrorMessage(DWORD error = GetLastError()) {
    LPWSTR buffer = nullptr;
    const DWORD size = FormatMessageW(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        nullptr,
        error,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        reinterpret_cast<LPWSTR>(&buffer),
        0,
        nullptr);

    std::wstring message = size == 0 ? L"unknown error" : std::wstring(buffer, size);
    if (buffer != nullptr) {
        LocalFree(buffer);
    }
    while (!message.empty() && (message.back() == L'\r' || message.back() == L'\n')) {
        message.pop_back();
    }
    return message;
}

std::wstring quoteArgument(std::wstring_view value) {
    if (value.empty()) {
        return L"\"\"";
    }

    const bool needsQuotes = value.find_first_of(L" \t\n\v\"") != std::wstring_view::npos;
    if (!needsQuotes) {
        return std::wstring(value);
    }

    std::wstring quoted = L"\"";
    size_t backslashes = 0;
    for (const wchar_t ch : value) {
        if (ch == L'\\') {
            ++backslashes;
            continue;
        }
        if (ch == L'\"') {
            quoted.append(backslashes * 2 + 1, L'\\');
            quoted.push_back(ch);
            backslashes = 0;
            continue;
        }
        quoted.append(backslashes, L'\\');
        backslashes = 0;
        quoted.push_back(ch);
    }
    quoted.append(backslashes * 2, L'\\');
    quoted.push_back(L'\"');
    return quoted;
}

bool createChildJob() {
    g_childJob = CreateJobObjectW(nullptr, nullptr);
    if (g_childJob == nullptr) {
        return false;
    }

    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limitInfo{};
    limitInfo.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if (SetInformationJobObject(g_childJob, JobObjectExtendedLimitInformation, &limitInfo, sizeof(limitInfo)) == FALSE) {
        CloseHandle(g_childJob);
        g_childJob = nullptr;
        return false;
    }

    return true;
}

bool injectDll(HANDLE process, const std::filesystem::path& dllPath, std::wstring& errorMessage) {
    const std::wstring absoluteDllPath = std::filesystem::absolute(dllPath).wstring();
    const size_t bytes = (absoluteDllPath.size() + 1) * sizeof(wchar_t);

    LPVOID remotePath = VirtualAllocEx(process, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (remotePath == nullptr) {
        errorMessage = L"VirtualAllocEx failed: " + getLastErrorMessage();
        return false;
    }

    if (WriteProcessMemory(process, remotePath, absoluteDllPath.c_str(), bytes, nullptr) == FALSE) {
        errorMessage = L"WriteProcessMemory failed: " + getLastErrorMessage();
        VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
        return false;
    }

    HMODULE kernel32 = GetModuleHandleW(L"kernel32.dll");
    const auto loadLibrary = reinterpret_cast<LPTHREAD_START_ROUTINE>(GetProcAddress(kernel32, "LoadLibraryW"));
    if (loadLibrary == nullptr) {
        errorMessage = L"GetProcAddress(LoadLibraryW) failed: " + getLastErrorMessage();
        VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
        return false;
    }

    HANDLE remoteThread = CreateRemoteThread(process, nullptr, 0, loadLibrary, remotePath, 0, nullptr);
    if (remoteThread == nullptr) {
        errorMessage = L"CreateRemoteThread failed: " + getLastErrorMessage();
        VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
        return false;
    }

    WaitForSingleObject(remoteThread, INFINITE);

    DWORD exitCode = 0;
    const bool ok = GetExitCodeThread(remoteThread, &exitCode) != FALSE && exitCode != 0;
    if (!ok) {
        errorMessage = L"Remote LoadLibraryW failed. Check DLL path and bitness.";
    }

    CloseHandle(remoteThread);
    VirtualFreeEx(process, remotePath, 0, MEM_RELEASE);
    return ok;
}

void stopProgram() {
    if (g_entryProcess != nullptr) {
        CloseHandle(g_entryProcess);
        g_entryProcess = nullptr;
    }
    if (g_childJob != nullptr) {
        CloseHandle(g_childJob);
        g_childJob = nullptr;
    }

    updateButtons(false);
    setStatus(L"Program stopped.");
}

bool isProgramRunning() {
    if (g_entryProcess == nullptr) {
        return false;
    }

    DWORD exitCode = 0;
    if (GetExitCodeProcess(g_entryProcess, &exitCode) == FALSE || exitCode != STILL_ACTIVE) {
        stopProgram();
        return false;
    }
    return true;
}

bool startProgram(HWND owner) {
    if (isProgramRunning()) {
        setStatus(L"Program is already running.");
        return true;
    }

    const std::filesystem::path directory = getExecutableDirectory();
    const std::filesystem::path dllPath = directory / L"hide_window_hook.dll";
    const std::filesystem::path entryPath = directory / L"entry.userdef";

    if (!std::filesystem::exists(entryPath)) {
        MessageBoxW(owner, L"entry.userdef was not found next to this UI executable.", L"sub_hook", MB_ICONERROR | MB_OK);
        setStatus(L"Missing entry.userdef.");
        return false;
    }
    if (!std::filesystem::exists(dllPath)) {
        MessageBoxW(owner, L"hide_window_hook.dll was not found next to this UI executable.", L"sub_hook", MB_ICONERROR | MB_OK);
        setStatus(L"Missing hide_window_hook.dll.");
        return false;
    }
    if (!createChildJob()) {
        MessageBoxW(owner, L"Failed to create a process lifetime guard.", L"sub_hook", MB_ICONERROR | MB_OK);
        setStatus(L"Failed to create process guard.");
        return false;
    }

    std::wstring commandLine = quoteArgument(entryPath.wstring());

    STARTUPINFOW startupInfo{};
    startupInfo.cb = sizeof(startupInfo);
    startupInfo.dwFlags = STARTF_USESHOWWINDOW;
    startupInfo.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION processInfo{};
    std::wstring mutableCommandLine = commandLine;

    const BOOL created = CreateProcessW(entryPath.c_str(), mutableCommandLine.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW | CREATE_SUSPENDED, nullptr, nullptr, &startupInfo, &processInfo);
    if (created == FALSE) {
        CloseHandle(g_childJob);
        g_childJob = nullptr;
        const std::wstring message = L"Failed to start entry.userdef: " + getLastErrorMessage();
        MessageBoxW(owner, message.c_str(), L"sub_hook", MB_ICONERROR | MB_OK);
        setStatus(L"Failed to start program.");
        return false;
    }

    if (AssignProcessToJobObject(g_childJob, processInfo.hProcess) == FALSE) {
        TerminateProcess(processInfo.hProcess, 1);
        CloseHandle(processInfo.hThread);
        CloseHandle(processInfo.hProcess);
        CloseHandle(g_childJob);
        g_childJob = nullptr;
        MessageBoxW(owner, L"Failed to attach the program to the process guard.", L"sub_hook", MB_ICONERROR | MB_OK);
        setStatus(L"Failed to attach program guard.");
        return false;
    }

    std::wstring injectError;
    if (!injectDll(processInfo.hProcess, dllPath, injectError)) {
        TerminateProcess(processInfo.hProcess, 1);
        CloseHandle(processInfo.hThread);
        CloseHandle(processInfo.hProcess);
        CloseHandle(g_childJob);
        g_childJob = nullptr;
        MessageBoxW(owner, injectError.c_str(), L"sub_hook", MB_ICONERROR | MB_OK);
        setStatus(L"Failed to inject hook DLL.");
        return false;
    }

    if (ResumeThread(processInfo.hThread) == static_cast<DWORD>(-1)) {
        TerminateProcess(processInfo.hProcess, 1);
        CloseHandle(processInfo.hThread);
        CloseHandle(processInfo.hProcess);
        CloseHandle(g_childJob);
        g_childJob = nullptr;
        MessageBoxW(owner, L"Failed to resume entry.userdef.", L"sub_hook", MB_ICONERROR | MB_OK);
        setStatus(L"Failed to start program.");
        return false;
    }

    g_entryProcess = processInfo.hProcess;
    CloseHandle(processInfo.hThread);
    updateButtons(true);
    setStatus(L"Program started from entry.userdef.");
    return true;
}

HWND createButton(HWND parent, int id, std::wstring_view text, int x, int y, int width, int height) {
    HWND hwnd = CreateWindowExW(0, L"BUTTON", std::wstring(text).c_str(), WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON, x, y, width, height, parent, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), nullptr, nullptr);
    SendMessageW(hwnd, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);
    return hwnd;
}

void createMainControls(HWND hwnd) {
    g_textFont = CreateFontW(-16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    g_titleFont = CreateFontW(-28, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    g_backgroundBrush = CreateSolidBrush(RGB(245, 245, 245));
    g_panelBrush = CreateSolidBrush(RGB(255, 255, 255));

    HWND title = CreateWindowExW(0, L"STATIC", L"Program Control", WS_CHILD | WS_VISIBLE, 32, 28, 320, 40, hwnd, nullptr, nullptr, nullptr);
    SendMessageW(title, WM_SETFONT, reinterpret_cast<WPARAM>(g_titleFont), TRUE);

    HWND subtitle = CreateWindowExW(0, L"STATIC", L"entry.userdef", WS_CHILD | WS_VISIBLE, 34, 70, 360, 24, hwnd, nullptr, nullptr, nullptr);
    SendMessageW(subtitle, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);

    g_startButton = createButton(hwnd, IdStartButton, L"Start Program", 48, 132, 156, 44);
    g_stopButton = createButton(hwnd, IdStopButton, L"Exit Program", 224, 132, 156, 44);
    g_statusText = CreateWindowExW(0, L"STATIC", L"Ready.", WS_CHILD | WS_VISIBLE, 48, 204, 360, 26, hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(IdStatusText)), nullptr, nullptr);
    SendMessageW(g_statusText, WM_SETFONT, reinterpret_cast<WPARAM>(g_textFont), TRUE);
    updateButtons(false);
}

LRESULT CALLBACK windowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_CREATE:
        createMainControls(hwnd);
        SetTimer(hwnd, 1, 1000, nullptr);
        return 0;
    case WM_COMMAND: {
        const int controlId = LOWORD(wParam);
        if (controlId == IdStartButton) {
            startProgram(hwnd);
            return 0;
        }
        if (controlId == IdStopButton) {
            stopProgram();
            return 0;
        }
        break;
    }
    case WM_TIMER:
        isProgramRunning();
        return 0;
    case WM_CTLCOLORSTATIC: {
        HDC deviceContext = reinterpret_cast<HDC>(wParam);
        SetBkMode(deviceContext, TRANSPARENT);
        SetTextColor(deviceContext, reinterpret_cast<HWND>(lParam) == g_statusText ? g_statusColor : g_textColor);
        return reinterpret_cast<LRESULT>(g_backgroundBrush);
    }
    case WM_ERASEBKGND: {
        RECT rect{};
        GetClientRect(hwnd, &rect);
        FillRect(reinterpret_cast<HDC>(wParam), &rect, g_backgroundBrush);
        RECT panel{24, 112, 424, 248};
        FillRect(reinterpret_cast<HDC>(wParam), &panel, g_panelBrush);
        return 1;
    }
    case WM_DESTROY:
        KillTimer(hwnd, 1);
        stopProgram();
        if (g_titleFont != nullptr) {
            DeleteObject(g_titleFont);
        }
        if (g_textFont != nullptr) {
            DeleteObject(g_textFont);
        }
        if (g_backgroundBrush != nullptr) {
            DeleteObject(g_backgroundBrush);
        }
        if (g_panelBrush != nullptr) {
            DeleteObject(g_panelBrush);
        }
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcW(hwnd, message, wParam, lParam);
    }

    return DefWindowProcW(hwnd, message, wParam, lParam);
}

} // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int showCommand) {
    const wchar_t className[] = L"SubHookDefaultWindow";

    WNDCLASSW windowClass{};
    windowClass.lpfnWndProc = windowProc;
    windowClass.hInstance = instance;
    windowClass.lpszClassName = className;
    windowClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    windowClass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);

    if (RegisterClassW(&windowClass) == 0) {
        return 1;
    }

    HWND hwnd = CreateWindowExW(
        0,
        className,
        L"Program Control",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        464,
        324,
        nullptr,
        nullptr,
        instance,
        nullptr);

    if (hwnd == nullptr) {
        return 1;
    }

    ShowWindow(hwnd, showCommand);
    UpdateWindow(hwnd);

    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }

    return static_cast<int>(message.wParam);
}
