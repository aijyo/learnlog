/*
 * demo_iat_ui.cpp  —  IAT Dynamicization Demo (Win32 GUI)
 * ─────────────────────────────────────────────────────────────────────────────
 * Win32 native GUI, single-file entry point.
 * Embeds hash.h / strenc.h / resolve.h logic; requires generated config.h.
 *
 * Build (VS Developer Command Prompt):
 *   1. python gen_config.py "YourSeedHere" > config.h
 *   2. cl /nologo /MT /O2 /std:c++17 /W3 /EHsc demo_iat_ui.cpp comctl32.lib
 *         /link /subsystem:windows /out:demo_iat_ui.exe
 *
 * UI sections:
 *   ① Build-time info   — seed string, seed value, ESTR key
 *   ② API table         — name / module / pre-computed hash / address / status
 *   ③ Action buttons    — Resolve · Call each API · Hash cross-check · Clear
 *   ④ Encrypted strings — raw XOR bytes stored in binary for each DLL name
 *   ⑤ Log              — timestamped output
 */

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <commctrl.h>
#pragma comment(lib, "comctl32.lib")

#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdarg>
#include <string>

// ── Generated config — run gen_config.py first ────────────────────────────────
#include "config.h"
#include "hash.h"
#include "strenc.h"
#include "resolve.h"

// ─────────────────────────────────────────────────────────────────────────────
// Control IDs
// ─────────────────────────────────────────────────────────────────────────────
enum : int {
    IDC_LV          = 200,
    IDC_BTN_RESOLVE,
    IDC_BTN_MSGBOX,
    IDC_BTN_VALLOC,
    IDC_BTN_GSI,
    IDC_BTN_XCHECK,
    IDC_BTN_CLEAR,
    IDC_LOG,
};

// ─────────────────────────────────────────────────────────────────────────────
// Function pointer types for hidden APIs
// ─────────────────────────────────────────────────────────────────────────────
using fn_MessageBoxA   = int    (WINAPI*)(HWND, LPCSTR, LPCSTR, UINT);
using fn_VirtualAlloc  = LPVOID (WINAPI*)(LPVOID, SIZE_T, DWORD, DWORD);
using fn_VirtualFree   = BOOL   (WINAPI*)(LPVOID, SIZE_T, DWORD);
using fn_GetSystemInfo = void   (WINAPI*)(LPSYSTEM_INFO);

// ─────────────────────────────────────────────────────────────────────────────
// Global state
// ─────────────────────────────────────────────────────────────────────────────
static HWND g_hwnd, g_hLV, g_hLog;
static HFONT g_hFont;

static fn_MessageBoxA   g_MsgBox  = nullptr;
static fn_VirtualAlloc  g_VAlloc  = nullptr;
static fn_VirtualFree   g_VFree   = nullptr;
static fn_GetSystemInfo g_GSI     = nullptr;

// ─────────────────────────────────────────────────────────────────────────────
// API table descriptor
// ─────────────────────────────────────────────────────────────────────────────
struct ApiEntry {
    const char* name;
    const char* dll;
    uint32_t    expected_hash;
};

static const ApiEntry kApis[] = {
    { "MessageBoxA",            "user32.dll",   HASH_MessageBoxA            },
    { "VirtualAlloc",           "kernel32.dll", HASH_VirtualAlloc           },
    { "VirtualFree",            "kernel32.dll", HASH_VirtualFree            },
    { "GetSystemInfo",          "kernel32.dll", HASH_GetSystemInfo          },
    { "VirtualAllocEx",         "kernel32.dll", HASH_VirtualAllocEx         },
    { "WriteProcessMemory",     "kernel32.dll", HASH_WriteProcessMemory     },
    { "CreateRemoteThread",     "kernel32.dll", HASH_CreateRemoteThread     },
    { "NtAllocateVirtualMemory","ntdll.dll",    HASH_NtAllocateVirtualMemory},
};
static constexpr int kApiCount = (int)(sizeof(kApis) / sizeof(kApis[0]));

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

// Append text to multiline log edit
static void Log(const char* fmt, ...) {
    char buf[1024];
    va_list va; va_start(va, fmt);
    vsnprintf(buf, sizeof(buf), fmt, va);
    va_end(va);

    std::string line(buf);
    line += "\r\n";
    int len = GetWindowTextLength(g_hLog);
    SendMessage(g_hLog, EM_SETSEL,     (WPARAM)len, (LPARAM)len);
    SendMessage(g_hLog, EM_REPLACESEL, 0, (LPARAM)line.c_str());
}

// Set ListView sub-item text
static void LvSet(int row, int col, const char* text) {
    LVITEM lvi = {};
    lvi.mask     = LVIF_TEXT;
    lvi.iItem    = row;
    lvi.iSubItem = col;
    lvi.pszText  = const_cast<LPSTR>(text);
    if (col == 0) ListView_InsertItem(g_hLV, &lvi);
    else          ListView_SetItem(g_hLV, &lvi);
}

// Add a Win32 control and set its font
static HWND MakeCtl(const char* cls, const char* txt, DWORD style, DWORD exStyle,
                    int x, int y, int w, int h, int id) {
    HWND hw = CreateWindowEx(exStyle, cls, txt,
        WS_CHILD | WS_VISIBLE | style,
        x, y, w, h, g_hwnd, (HMENU)(UINT_PTR)id,
        (HINSTANCE)GetWindowLongPtr(g_hwnd, GWLP_HINSTANCE), nullptr);
    SendMessage(hw, WM_SETFONT, (WPARAM)g_hFont, TRUE);
    return hw;
}

static HWND MakeLabel(const char* txt, int x, int y, int w, int h = 18) {
    return MakeCtl("STATIC", txt, SS_SIMPLE, 0, x, y, w, h, 0);
}

static HWND MakeBtn(const char* txt, int id, int x, int y, int w, int h = 26) {
    return MakeCtl("BUTTON", txt, BS_PUSHBUTTON, 0, x, y, w, h, id);
}

// ─────────────────────────────────────────────────────────────────────────────
// Module handle cache  (DLL names encrypted via ESTR_BUF)
// ─────────────────────────────────────────────────────────────────────────────
static HMODULE hKernel32() {
    static HMODULE h = nullptr;
    if (!h) { ESTR_BUF(n, "kernel32.dll"); h = GetModuleHandleA(n); }
    return h;
}
static HMODULE hUser32() {
    static HMODULE h = nullptr;
    if (!h) { ESTR_BUF(n, "user32.dll"); h = LoadLibraryA(n); }
    return h;
}
static HMODULE hNtdll() {
    static HMODULE h = nullptr;
    if (!h) { ESTR_BUF(n, "ntdll.dll"); h = GetModuleHandleA(n); }
    return h;
}

static HMODULE ModuleFor(const char* dll) {
    if (!_stricmp(dll, "user32.dll"))   return hUser32();
    if (!_stricmp(dll, "ntdll.dll"))    return hNtdll();
    return hKernel32();
}

// ─────────────────────────────────────────────────────────────────────────────
// Build the encrypted-string info block
// ─────────────────────────────────────────────────────────────────────────────
static std::string EncBytesStr(const char* plain, size_t plain_len) {
    // Manually encrypt using same algorithm as _EStr template
    std::string s;
    char tmp[8];
    for (size_t i = 0; i < plain_len; i++) {
        uint8_t enc = (uint8_t)plain[i] ^ (uint8_t)(ESTR_KEY + (uint8_t)i);
        snprintf(tmp, sizeof(tmp), "%02X ", enc);
        s += tmp;
    }
    return s;
}

// ─────────────────────────────────────────────────────────────────────────────
// Actions
// ─────────────────────────────────────────────────────────────────────────────

static void DoResolve() {
    Log("──── EAT Resolution (seed 0x%08X) ────", CFG_SEED);

    // Reset all rows first
    for (int i = 0; i < kApiCount; i++) {
        LvSet(i, 3, "—");
        LvSet(i, 4, "...");
    }

    for (int i = 0; i < kApiCount; i++) {
        HMODULE mod = ModuleFor(kApis[i].dll);
        FARPROC fn  = resolve_by_hash(mod, kApis[i].expected_hash);

        char addr[32];
        if (fn) {
            snprintf(addr, sizeof(addr), "0x%p", (void*)fn);
            LvSet(i, 3, addr);
            LvSet(i, 4, "OK");
            Log("[+] %-28s %s", kApis[i].name, addr);
        } else {
            LvSet(i, 3, "—");
            LvSet(i, 4, "FAIL");
            Log("[-] %-28s not found", kApis[i].name);
        }

        // Cache the 4 callable ones
        if (!strcmp(kApis[i].name, "MessageBoxA"))   g_MsgBox = (fn_MessageBoxA)fn;
        if (!strcmp(kApis[i].name, "VirtualAlloc"))  g_VAlloc = (fn_VirtualAlloc)fn;
        if (!strcmp(kApis[i].name, "VirtualFree"))   g_VFree  = (fn_VirtualFree)fn;
        if (!strcmp(kApis[i].name, "GetSystemInfo")) g_GSI    = (fn_GetSystemInfo)fn;
    }
    Log("Done. Click action buttons to call APIs via resolved pointers.");
}

static void DoCallMsgBox() {
    if (!g_MsgBox) { Log("[!] Resolve APIs first."); return; }
    ESTR_BUF(title, "IAT Demo — MessageBoxA");
    ESTR_BUF(msg,
        "Called via EAT hash resolution.\n"
        "This API has NO entry in the IAT.\n\n"
        "Verify:  dumpbin /IMPORTS demo_iat_ui.exe\n"
        "-> MessageBoxA must NOT appear in the list.");
    Log("Calling MessageBoxA (ptr=0x%p)...", (void*)g_MsgBox);
    int r = g_MsgBox(g_hwnd, msg, title, MB_OK | MB_ICONINFORMATION);
    Log("[+] MessageBoxA returned %d", r);
}

static void DoCallVAlloc() {
    if (!g_VAlloc || !g_VFree) { Log("[!] Resolve APIs first."); return; }
    Log("Calling VirtualAlloc(0x1000, PAGE_READWRITE)...");
    void* mem = g_VAlloc(nullptr, 0x1000, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { Log("[-] VirtualAlloc returned null."); return; }
    Log("[+] VirtualAlloc -> 0x%p", mem);
    ((uint8_t*)mem)[0] = 0xCC;   // write to prove it's accessible
    BOOL ok = g_VFree(mem, 0, MEM_RELEASE);
    Log("[+] VirtualFree  -> %s", ok ? "OK" : "FAILED");
}

static void DoCallGSI() {
    if (!g_GSI) { Log("[!] Resolve APIs first."); return; }
    Log("Calling GetSystemInfo...");
    SYSTEM_INFO si{};
    g_GSI(&si);
    char minaddr[32], maxaddr[32];
    snprintf(minaddr, sizeof(minaddr), "0x%p", si.lpMinimumApplicationAddress);
    snprintf(maxaddr, sizeof(maxaddr), "0x%p", si.lpMaximumApplicationAddress);
    Log("[+] Processors    : %u", si.dwNumberOfProcessors);
    Log("[+] Page size     : %u bytes", si.dwPageSize);
    Log("[+] Alloc granul  : %u bytes", si.dwAllocationGranularity);
    Log("[+] Min app addr  : %s", minaddr);
    Log("[+] Max app addr  : %s", maxaddr);
}

static void DoHashCrossCheck() {
    Log("──── Hash cross-check (runtime EAT vs compile-time) ────");
    bool all_ok = true;
    for (int i = 0; i < kApiCount; i++) {
        HMODULE mod = ModuleFor(kApis[i].dll);
        if (!mod) { Log("  [!] %-28s module not loaded", kApis[i].name); continue; }

        // Walk EAT to find the name, compute hash ourselves
        auto* base = (const uint8_t*)mod;
        auto* dos  = (const IMAGE_DOS_HEADER*)base;
        auto* nt   = (const IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
        auto& xdd  = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
        if (!xdd.VirtualAddress) { Log("  [!] no export dir"); continue; }
        auto* exp  = (const IMAGE_EXPORT_DIRECTORY*)(base + xdd.VirtualAddress);
        auto* names = (const DWORD*)(base + exp->AddressOfNames);

        bool found = false;
        for (DWORD j = 0; j < exp->NumberOfNames; j++) {
            const char* n = (const char*)(base + names[j]);
            if (!strcmp(n, kApis[i].name)) {
                uint32_t got = api_hash(n, CFG_SEED);
                bool match = (got == kApis[i].expected_hash);
                Log("  %s %-28s computed=0x%08X  expected=0x%08X  %s",
                    match ? "[+]" : "[!]",
                    kApis[i].name, got, kApis[i].expected_hash,
                    match ? "MATCH" : "MISMATCH");
                if (!match) all_ok = false;
                found = true;
                break;
            }
        }
        if (!found)
            Log("  [?] %-28s not found in EAT", kApis[i].name);
    }
    Log("Cross-check %s", all_ok ? "PASSED — gen_config.py and hash.h are in sync." : "FAILED!");
}

// ─────────────────────────────────────────────────────────────────────────────
// WM_CREATE
// ─────────────────────────────────────────────────────────────────────────────
static void OnCreate(HINSTANCE hInst) {
    g_hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

    // ── Section ①: Build-time info ──────────────────────────────────────
    char info1[256], info2[256];
    snprintf(info1, sizeof(info1),
        "Build seed: \"%s\"   Seed value: 0x%08X   ESTR key: 0x%02X",
        CFG_SEED_STR, CFG_SEED, (unsigned)ESTR_KEY);
    snprintf(info2, sizeof(info2),
        "Changing seed rebuilds config.h → all HASH_* constants and encrypted "
        "string bytes change → binary fingerprint changes.");
    MakeLabel(info1, 8, 8, 750);
    MakeLabel(info2, 8, 26, 750);

    // ── Section ②: API table (ListView) ────────────────────────────────
    MakeLabel("API Resolution Table  (no IAT entries for these functions):", 8, 50, 500);
    g_hLV = MakeCtl(WC_LISTVIEW, "",
        LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS | LVS_NOSORTHEADER,
        WS_EX_CLIENTEDGE, 8, 68, 750, 196, IDC_LV);
    ListView_SetExtendedListViewStyle(g_hLV,
        LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

    struct { const char* title; int w; } cols[] = {
        {"API Name",       175}, {"Module",   100},
        {"Expected Hash",  110}, {"Address",  130}, {"Status", 70},
    };
    for (int i = 0; i < 5; i++) {
        LVCOLUMN c{}; c.mask = LVCF_TEXT|LVCF_WIDTH|LVCF_FMT;
        c.fmt = LVCFMT_LEFT; c.cx = cols[i].w;
        c.pszText = const_cast<char*>(cols[i].title);
        ListView_InsertColumn(g_hLV, i, &c);
    }

    // Pre-populate rows with known data
    for (int i = 0; i < kApiCount; i++) {
        char hash_s[24];
        snprintf(hash_s, sizeof(hash_s), "0x%08X", kApis[i].expected_hash);
        LvSet(i, 0, kApis[i].name);
        LvSet(i, 1, kApis[i].dll);
        LvSet(i, 2, hash_s);
        LvSet(i, 3, "—");
        LvSet(i, 4, "Pending");
    }

    // ── Section ③: Action buttons ───────────────────────────────────────
    int bx = 8, by = 272;
    MakeBtn("① Resolve All APIs",    IDC_BTN_RESOLVE, bx,        by, 140);
    MakeBtn("② Call MessageBoxA",    IDC_BTN_MSGBOX,  bx+148,   by, 140);
    MakeBtn("③ Call VirtualAlloc",   IDC_BTN_VALLOC,  bx+296,   by, 140);
    MakeBtn("④ Call GetSystemInfo",  IDC_BTN_GSI,     bx+444,   by, 140);
    MakeBtn("⑤ Hash Cross-check",    IDC_BTN_XCHECK,  bx+592,   by, 110);
    MakeBtn("Clear",                 IDC_BTN_CLEAR,   bx+710,   by,  48);

    // ── Section ④: Encrypted string display ─────────────────────────────
    MakeLabel("Encrypted DLL name literals (XOR-encoded in .rdata, decrypted on stack at runtime):",
              8, 308, 750);

    // Compute and display encrypted bytes for each DLL
    struct { const char* plain; } dlls[] = {
        {"kernel32.dll"}, {"user32.dll"}, {"ntdll.dll"},
    };
    int ey = 326;
    for (auto& d : dlls) {
        std::string enc = EncBytesStr(d.plain, strlen(d.plain));
        char line[256];
        snprintf(line, sizeof(line), "  \"%s\" (key 0x%02X) ->  %s",
                 d.plain, (unsigned)ESTR_KEY, enc.c_str());
        HWND hw = MakeCtl("EDIT", line, ES_READONLY | ES_AUTOHSCROLL,
                          WS_EX_CLIENTEDGE, 8, ey, 750, 20, 0);
        SendMessage(hw, WM_SETFONT, (WPARAM)g_hFont, TRUE);
        ey += 22;
    }

    // ── Section ⑤: Log ─────────────────────────────────────────────────
    MakeLabel("Log:", 8, ey + 2, 60);
    g_hLog = MakeCtl("EDIT", "",
        ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 8, ey + 20, 750, 195, IDC_LOG);

    Log("IAT Dynamicization Demo — ready.");
    Log("Seed: \"%s\"  (0x%08X)   ESTR_KEY: 0x%02X",
        CFG_SEED_STR, CFG_SEED, (unsigned)ESTR_KEY);
    Log("Click  [① Resolve All APIs]  to walk EAT and fill the table.");
    Log("After resolving, use buttons ②③④ to call APIs via hash-resolved pointers.");
    Log("Button ⑤ recomputes hashes at runtime and verifies they match config.h.");
    Log("dumpbin /IMPORTS demo_iat_ui.exe  ->  target APIs must not appear.");
}

// ─────────────────────────────────────────────────────────────────────────────
// Window procedure
// ─────────────────────────────────────────────────────────────────────────────
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE:
        g_hwnd = hwnd;
        OnCreate(((CREATESTRUCT*)lp)->hInstance);
        return 0;

    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case IDC_BTN_RESOLVE: DoResolve();      break;
        case IDC_BTN_MSGBOX:  DoCallMsgBox();   break;
        case IDC_BTN_VALLOC:  DoCallVAlloc();   break;
        case IDC_BTN_GSI:     DoCallGSI();      break;
        case IDC_BTN_XCHECK:  DoHashCrossCheck(); break;
        case IDC_BTN_CLEAR:   SetWindowText(g_hLog, ""); break;
        }
        return 0;

    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)wp, TRANSPARENT);
        return (LRESULT)GetSysColorBrush(COLOR_3DFACE);

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wp, lp);
}

// ─────────────────────────────────────────────────────────────────────────────
// WinMain
// ─────────────────────────────────────────────────────────────────────────────
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nShow) {
    INITCOMMONCONTROLSEX icex = { sizeof(icex), ICC_LISTVIEW_CLASSES };
    InitCommonControlsEx(&icex);

    WNDCLASSEX wc = { sizeof(wc) };
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hbrBackground = (HBRUSH)(COLOR_3DFACE + 1);
    wc.lpszClassName = "IATDemoWnd";
    wc.hIcon         = LoadIcon(nullptr, IDI_SHIELD);
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassEx(&wc);

    // Calculate window size from desired client area (766 x 600)
    RECT rc = { 0, 0, 766, 610 };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME|WS_MAXIMIZEBOX), FALSE);

    HWND hwnd = CreateWindowEx(0, "IATDemoWnd",
        "IAT Dynamicization Demo  —  EAT Hash Walk",
        WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME | WS_MAXIMIZEBOX),
        CW_USEDEFAULT, CW_USEDEFAULT,
        rc.right - rc.left, rc.bottom - rc.top,
        nullptr, nullptr, hInst, nullptr);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG m;
    while (GetMessage(&m, nullptr, 0, 0)) {
        TranslateMessage(&m);
        DispatchMessage(&m);
    }
    return (int)m.wParam;
}
