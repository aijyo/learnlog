#!/usr/bin/env python3
"""
gen_config.py  —  Generates config.h with pre-computed API hashes.

The hash algorithm here MUST match api_hash() in hash.h exactly.
Any difference causes runtime resolve failures.

Usage:
    python gen_config.py "YourSeedString"               # writes to stdout
    python gen_config.py "YourSeedString" > config.h    # shell redirect
    python gen_config.py "YourSeedString" config.h      # explicit out path
                                                         #   (CMake-friendly)
"""

import sys

# ---------------------------------------------------------------------------
# Hash algorithm  (mirror of hash.h)
# ---------------------------------------------------------------------------

def ror32(v: int, n: int) -> int:
    return ((v >> n) | (v << (32 - n))) & 0xFFFFFFFF

def str_to_seed(s: str) -> int:
    """djb2 variant — same as seed_from_str() in patchtool / resolve.h."""
    h = 5381
    for c in s:
        h = ((h << 5) + h) ^ ord(c)
    return h & 0xFFFFFFFF

def api_hash(name: str, seed: int) -> int:
    """ROR-13 accumulator — must match api_hash() in hash.h."""
    h = seed
    for c in name:
        h = ror32(h, 13)
        h = (h + ord(c)) & 0xFFFFFFFF
    return h

# ---------------------------------------------------------------------------
# API list  (dll, api_name)
# ---------------------------------------------------------------------------

APIS = [
    # ---- user32 ----
    ("user32.dll",   "MessageBoxA"),
    ("user32.dll",   "MessageBoxW"),
    # ---- kernel32 — memory ----
    ("kernel32.dll", "VirtualAlloc"),
    ("kernel32.dll", "VirtualAllocEx"),
    ("kernel32.dll", "VirtualFree"),
    ("kernel32.dll", "VirtualProtect"),
    # ---- kernel32 — process / thread ----
    ("kernel32.dll", "OpenProcess"),
    ("kernel32.dll", "CreateRemoteThread"),
    ("kernel32.dll", "WriteProcessMemory"),
    ("kernel32.dll", "ReadProcessMemory"),
    # ---- kernel32 — misc ----
    ("kernel32.dll", "GetSystemInfo"),
    ("kernel32.dll", "GetCurrentProcess"),
    ("kernel32.dll", "ExitProcess"),
    ("kernel32.dll", "LoadLibraryA"),
    ("kernel32.dll", "GetProcAddress"),
    # ---- ntdll ----
    ("ntdll.dll",    "NtAllocateVirtualMemory"),
    ("ntdll.dll",    "NtWriteVirtualMemory"),
    ("ntdll.dll",    "NtCreateThreadEx"),
]

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) < 2:
        print("Usage: python gen_config.py <seed_string> [output_path]",
              file=sys.stderr)
        sys.exit(1)

    seed_str = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else None
    seed     = str_to_seed(seed_str)

    lines = [
        "// -----------------------------------------------------------------------",
        "// config.h  —  AUTO-GENERATED, DO NOT EDIT",
        f"// Regenerate: python gen_config.py \"{seed_str}\"",
        f"// Seed string : \"{seed_str}\"",
        f"// Seed value  : 0x{seed:08X}",
        "// -----------------------------------------------------------------------",
        "#pragma once",
        "#include <cstdint>",
        "",
        f'#define CFG_SEED_STR  "{seed_str}"',
        f"#define CFG_SEED      0x{seed:08X}u",
        "",
    ]

    prev_dll = None
    for dll, api in APIS:
        if dll != prev_dll:
            lines.append(f"// {dll}")
            prev_dll = dll
        h = api_hash(api, seed)
        macro = f"HASH_{api}"
        lines.append(f"#define {macro:<38} 0x{h:08X}u")

    text = "\n".join(lines) + "\n"
    if out_path:
        with open(out_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        print(f"[gen_config.py] wrote {out_path}  seed=\"{seed_str}\"  value=0x{seed:08X}",
              file=sys.stderr)
    else:
        sys.stdout.write(text)

if __name__ == "__main__":
    main()
