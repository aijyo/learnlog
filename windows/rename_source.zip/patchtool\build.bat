@echo off
:: build.bat  —  patchtool build script (CLI + GUI)
:: Run from VS Developer Command Prompt

echo.
echo ════════════════════════════════════════════
echo   patchtool build
echo ════════════════════════════════════════════

echo.
echo [1/3] Building CLI version (patchtool.exe)...
cl /nologo /MT /O2 /std:c++17 /W3 /WX /EHsc ^
   patchtool.cpp ^
   /link /subsystem:console /out:patchtool.exe
if errorlevel 1 ( echo [-] CLI build failed & exit /b 1 )
echo [+] patchtool.exe

echo.
echo [2/3] Building GUI version (patchtool_ui.exe)...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc ^
   patchtool_ui.cpp comctl32.lib comdlg32.lib ^
   /link /subsystem:windows /out:patchtool_ui.exe
if errorlevel 1 ( echo [-] GUI build failed & exit /b 1 )
echo [+] patchtool_ui.exe

echo.
echo [3/3] Verifying: only system DLLs in GUI binary
dumpbin /DEPENDENTS patchtool_ui.exe

echo.
echo ════════════════════════════════════════════
echo   Run CLI : patchtool.exe --help
echo   Run GUI : patchtool_ui.exe
echo ════════════════════════════════════════════
