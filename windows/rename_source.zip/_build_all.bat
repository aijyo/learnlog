@echo off
setlocal EnableDelayedExpansion

set "VCVARS=D:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"
set "IAT_DIR=D:\code\work\research\rename\demo_iat"
set "PATCH_DIR=D:\code\work\research\rename\patchtool"
set "PEDIFF_DIR=D:\code\work\research\rename\pediff"
set "HASHLAB_DIR=D:\code\work\research\rename\hashlab"

echo [*] Setting up MSVC x64 environment...
call "%VCVARS%" x64 2>&1
if errorlevel 1 (
    echo [-] vcvarsall.bat failed
    exit /b 1
)

echo [*] cl.exe version:
cl /? 2>&1 | findstr "Version"

echo.
echo === Building demo_iat_ui.exe ===
pushd "%IAT_DIR%"
echo [*] Compiling...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc demo_iat_ui.cpp comctl32.lib user32.lib gdi32.lib /link /subsystem:windows /out:demo_iat_ui.exe
if errorlevel 1 (
    echo [-] demo_iat_ui build FAILED
    popd
    exit /b 1
)
echo [+] demo_iat_ui.exe OK
echo [*] IAT check:
dumpbin /IMPORTS demo_iat_ui.exe | findstr /i "MessageBoxA VirtualAlloc GetSystemInfo"
if errorlevel 1 (
    echo [PASS] Target APIs not in IAT
) else (
    echo [WARN] Some APIs found in IAT
)
popd

echo.
echo === Building patchtool_ui.exe ===
pushd "%PATCH_DIR%"
echo [*] Compiling...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc patchtool_ui.cpp comctl32.lib comdlg32.lib user32.lib gdi32.lib /link /subsystem:windows /out:patchtool_ui.exe
if errorlevel 1 (
    echo [-] patchtool_ui build FAILED
    popd
    exit /b 1
)
echo [+] patchtool_ui.exe OK
echo [*] Dependencies:
dumpbin /DEPENDENTS patchtool_ui.exe
popd

echo.
echo === Building pediff_ui.exe ===
pushd "%PEDIFF_DIR%"
echo [*] Compiling...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc pediff_ui.cpp comctl32.lib comdlg32.lib bcrypt.lib user32.lib gdi32.lib /link /subsystem:windows /out:pediff_ui.exe
if errorlevel 1 (
    echo [-] pediff_ui build FAILED
    popd
    exit /b 1
)
echo [+] pediff_ui.exe OK
echo [*] Dependencies:
dumpbin /DEPENDENTS pediff_ui.exe | findstr ".dll"
popd

echo.
echo === Building hashlab_ui.exe ===
pushd "%HASHLAB_DIR%"
echo [*] Compiling...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc hashlab_ui.cpp comctl32.lib user32.lib gdi32.lib /link /subsystem:windows /out:hashlab_ui.exe
if errorlevel 1 (
    echo [-] hashlab_ui build FAILED
    popd
    exit /b 1
)
echo [+] hashlab_ui.exe OK
echo [*] Dependencies:
dumpbin /DEPENDENTS hashlab_ui.exe | findstr ".dll"
popd

echo.
echo === Build complete ===
echo   demo_iat_ui.exe  -^>  %IAT_DIR%\demo_iat_ui.exe
echo   patchtool_ui.exe -^>  %PATCH_DIR%\patchtool_ui.exe
echo   pediff_ui.exe    -^>  %PEDIFF_DIR%\pediff_ui.exe
echo   hashlab_ui.exe   -^>  %HASHLAB_DIR%\hashlab_ui.exe
echo.
echo Workflow tip:
echo   1. demo_iat_ui  ^|  no-IAT API resolution via hash + EAT walk
echo   2. patchtool_ui ^|  patch PE timestamp/sections/rich/debug/sig
echo   3. pediff_ui    ^|  compare original vs patched (verify patches)
echo   4. hashlab_ui   ^|  explore hash algos + collisions + generate config.h
