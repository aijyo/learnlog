/*
 * patchtool_ui.cpp  —  PE Characteristic Patcher (Win32 GUI, standalone)
 * ─────────────────────────────────────────────────────────────────────────────
 * Single-file, Win32 native GUI, no external dependencies.
 * All PE patching logic is embedded; no separate headers required.
 *
 * Build (VS Developer Command Prompt):
 *   cl /nologo /MT /O2 /std:c++17 /W3 /EHsc patchtool_ui.cpp comctl32.lib
 *         /link /subsystem:windows /out:patchtool_ui.exe
 *
 * UI layout:
 *   ① File paths + seed input
 *   ② Before / After side-by-side PE info panels
 *   ③ Patch options checkboxes
 *   ④ Action buttons  (Load · Dry Run · Patch)
 *   ⑤ Log output
 */

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <commdlg.h>
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")

#include <cstdio>
#include <cstdint>
#include <cstdarg>
#include <cstring>
#include <string>
#include <vector>
#include <sstream>

// ═════════════════════════════════════════════════════════════════════════════
// PE patching engine  (same logic as patchtool.cpp, embedded here)
// ═════════════════════════════════════════════════════════════════════════════

struct PeCtx {
    std::vector<uint8_t> data;
    IMAGE_DOS_HEADER*    dos    = nullptr;
    IMAGE_FILE_HEADER*   fhdr   = nullptr;
    IMAGE_SECTION_HEADER* sects = nullptr;
    uint16_t             nsects = 0;
    bool                 is64   = false;
    bool                 valid  = false;

    IMAGE_DATA_DIRECTORY& datadir(int idx) {
        if (is64) return ((IMAGE_NT_HEADERS64*)(data.data()+dos->e_lfanew))->OptionalHeader.DataDirectory[idx];
        return     ((IMAGE_NT_HEADERS32*)(data.data()+dos->e_lfanew))->OptionalHeader.DataDirectory[idx];
    }
    DWORD& checksum() {
        if (is64) return ((IMAGE_NT_HEADERS64*)(data.data()+dos->e_lfanew))->OptionalHeader.CheckSum;
        return     ((IMAGE_NT_HEADERS32*)(data.data()+dos->e_lfanew))->OptionalHeader.CheckSum;
    }
    uint32_t rva_to_off(uint32_t rva) const {
        for (uint16_t i = 0; i < nsects; i++) {
            auto& s = sects[i];
            if (rva >= s.VirtualAddress && rva < s.VirtualAddress + s.SizeOfRawData && s.SizeOfRawData)
                return s.PointerToRawData + (rva - s.VirtualAddress);
        }
        return 0;
    }
    uint8_t* at_rva(uint32_t rva) {
        uint32_t o = rva_to_off(rva);
        return (o && o < data.size()) ? data.data()+o : nullptr;
    }
};

static bool pe_load(const char* path, PeCtx& ctx) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f); rewind(f);
    if (sz < (long)sizeof(IMAGE_DOS_HEADER)) { fclose(f); return false; }
    ctx.data.resize((size_t)sz);
    bool ok = fread(ctx.data.data(), 1, (size_t)sz, f) == (size_t)sz;
    fclose(f);
    if (!ok) return false;

    ctx.dos = (IMAGE_DOS_HEADER*)ctx.data.data();
    if (ctx.dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    if ((size_t)ctx.dos->e_lfanew + sizeof(IMAGE_NT_HEADERS32) > ctx.data.size()) return false;

    DWORD sig = *(DWORD*)(ctx.data.data() + ctx.dos->e_lfanew);
    if (sig != IMAGE_NT_SIGNATURE) return false;

    ctx.fhdr  = (IMAGE_FILE_HEADER*)(ctx.data.data() + ctx.dos->e_lfanew + sizeof(DWORD));
    ctx.nsects = ctx.fhdr->NumberOfSections;
    ctx.is64   = (ctx.fhdr->Machine == IMAGE_FILE_MACHINE_AMD64);
    ctx.sects  = IMAGE_FIRST_SECTION((IMAGE_NT_HEADERS*)(ctx.data.data()+ctx.dos->e_lfanew));
    ctx.valid  = true;
    return true;
}

static bool pe_save(const char* path, const PeCtx& ctx) {
    FILE* f = fopen(path, "wb");
    if (!f) return false;
    bool ok = fwrite(ctx.data.data(), 1, ctx.data.size(), f) == ctx.data.size();
    fclose(f);
    return ok;
}

static uint32_t seed_from_str(const char* s) {
    uint32_t h = 5381u;
    while (*s) h = ((h<<5)+h) ^ (uint8_t)*s++;
    return h;
}
static uint32_t lcg(uint32_t& st) { return st = st*1664525u+1013904223u; }

static void patch_rich(PeCtx& ctx, std::string& log) {
    uint8_t* base = ctx.data.data();
    uint32_t end  = ctx.dos->e_lfanew;
    for (uint32_t i = 0x40u; i+8u <= end; i += 4) {
        if (*(uint32_t*)(base+i) != 0x68636952u) continue;
        uint32_t key   = *(uint32_t*)(base+i+4);
        uint32_t dans  = 0x536e6144u ^ key;
        uint32_t start = 0x40u;
        for (uint32_t j = 0x40u; j < i; j += 4)
            if (*(uint32_t*)(base+j) == dans) { start = j; break; }
        uint32_t span = (i+8u) - start;
        memset(base+start, 0, span);
        char tmp[128]; snprintf(tmp, sizeof(tmp),
            "[+] Rich Header cleared  off=0x%04X  size=%u  key=0x%08X\r\n", start, span, key);
        log += tmp;
        return;
    }
    log += "[ ] Rich Header: not found\r\n";
}

static void patch_timestamp(PeCtx& ctx, uint32_t seed, std::string& log) {
    uint32_t old_ts = ctx.fhdr->TimeDateStamp;
    constexpr uint32_t BASE = 1262304000u, SPAN = 441676800u;
    uint32_t new_ts = BASE + (seed % SPAN);
    ctx.fhdr->TimeDateStamp = new_ts;
    char tmp[128]; snprintf(tmp, sizeof(tmp),
        "[+] TimeDateStamp  0x%08X -> 0x%08X\r\n", old_ts, new_ts);
    log += tmp;
}

static void patch_sections(PeCtx& ctx, uint32_t seed, std::string& log) {
    static const char CONS[] = "bcdfghjklmnpqrstvwxz";
    static const char VOWL[] = "aeiou";
    uint32_t rng = seed ^ 0xDEADC0DEu;
    for (uint16_t i = 0; i < ctx.nsects; i++) {
        char old_n[9]{}; memcpy(old_n, ctx.sects[i].Name, 8);
        uint32_t r = lcg(rng);
        char new_n[9]{};
        new_n[0]='.'; new_n[1]=CONS[r%20]; new_n[2]=VOWL[(r>>8)%5];
        new_n[3]=CONS[(r>>16)%20]; new_n[4]=VOWL[(r>>24)%5];
        memset(ctx.sects[i].Name, 0, 8);
        memcpy(ctx.sects[i].Name, new_n, strlen(new_n));
        char tmp[80]; snprintf(tmp, sizeof(tmp),
            "[+] Section %-8s -> %-8s\r\n", old_n, new_n);
        log += tmp;
    }
}

// Fisher-Yates shuffle IMAGE_IMPORT_DESCRIPTOR array.
// Safe: each descriptor's OriginalFirstThunk/FirstThunk are self-referential
// RVAs, so the IAT slots (which compiled code references by RVA) don't move.
// Effect: imphash MD5 input string is in a different order → new imphash.
static void patch_imports_reorder(PeCtx& ctx, uint32_t seed, std::string& log) {
    auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_IMPORT);
    if (!dd.VirtualAddress) { log += "[ ] Import Directory: not present\r\n"; return; }
    uint8_t* p = ctx.at_rva(dd.VirtualAddress);
    if (!p) { log += "[!] Import Directory: RVA unmapped\r\n"; return; }

    auto* imp = (IMAGE_IMPORT_DESCRIPTOR*)p;
    int n = 0;
    while (imp[n].Name) n++;
    if (n < 2) {
        char tmp[80];
        snprintf(tmp, sizeof(tmp),
            "[ ] Import Directory: %d entry, no reorder possible\r\n", n);
        log += tmp;
        return;
    }

    uint32_t rng = seed ^ 0xCAFEBABEu;
    int swaps = 0;
    for (int i = n - 1; i > 0; i--) {
        uint32_t r = lcg(rng);
        int j = (int)(r % (uint32_t)(i + 1));
        if (i != j) {
            IMAGE_IMPORT_DESCRIPTOR t = imp[i];
            imp[i] = imp[j];
            imp[j] = t;
            swaps++;
        }
    }
    char tmp[128];
    snprintf(tmp, sizeof(tmp),
        "[+] Import descriptors reordered (%d entries, %d swaps -> imphash changes)\r\n",
        n, swaps);
    log += tmp;
}

static void patch_debug(PeCtx& ctx, std::string& log) {
    auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_DEBUG);
    if (!dd.VirtualAddress) { log += "[ ] Debug Directory: not present\r\n"; return; }
    uint8_t* p = ctx.at_rva(dd.VirtualAddress);
    if (!p) { log += "[!] Debug Directory: RVA unmapped\r\n"; return; }
    DWORD cnt = dd.Size / sizeof(IMAGE_DEBUG_DIRECTORY);
    auto* e = (IMAGE_DEBUG_DIRECTORY*)p;
    for (DWORD j = 0; j < cnt; j++) {
        if (e[j].PointerToRawData && e[j].SizeOfData &&
            e[j].PointerToRawData + e[j].SizeOfData <= ctx.data.size())
            memset(ctx.data.data() + e[j].PointerToRawData, 0, e[j].SizeOfData);
        e[j].PointerToRawData = e[j].AddressOfRawData = e[j].SizeOfData = 0;
    }
    char tmp[64]; snprintf(tmp, sizeof(tmp), "[+] Debug Directory cleared (%lu entries)\r\n", (unsigned long)cnt);
    log += tmp;
}

static void patch_sig(PeCtx& ctx, std::string& log) {
    auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_SECURITY);
    if (!dd.VirtualAddress) { log += "[ ] Signature: not present\r\n"; return; }
    uint32_t off = dd.VirtualAddress, sz = dd.Size;
    if (off + sz <= ctx.data.size())
        memset(ctx.data.data() + off, 0, sz);
    dd.VirtualAddress = dd.Size = 0;
    char tmp[64]; snprintf(tmp, sizeof(tmp), "[+] Signature cleared  off=0x%X  size=%u\r\n", off, sz);
    log += tmp;
}

static void patch_checksum(PeCtx& ctx, std::string& log) {
    uint32_t old_cs = ctx.checksum();
    ctx.checksum() = 0;
    const uint8_t* d = ctx.data.data();
    size_t n = ctx.data.size();
    uint32_t sum = 0;
    const uint16_t* w = (const uint16_t*)d;
    for (size_t i = 0; i < n/2; i++) { sum += w[i]; if (sum>>16) sum=(sum&0xFFFF)+(sum>>16); }
    if (n&1) { sum += d[n-1]; if (sum>>16) sum=(sum&0xFFFF)+(sum>>16); }
    sum = (sum>>16)+(sum&0xFFFF); sum += (uint32_t)n;
    ctx.checksum() = sum;
    char tmp[64]; snprintf(tmp, sizeof(tmp), "[+] Checksum  0x%08X -> 0x%08X\r\n", old_cs, sum);
    log += tmp;
}

// Build a human-readable PE summary string
static std::string pe_summary(PeCtx& ctx) {
    if (!ctx.valid) return "(no PE loaded)";
    std::string s;
    char tmp[128];
    snprintf(tmp, sizeof(tmp), "Arch     : %s\r\n", ctx.is64 ? "x64 (PE32+)" : "x86 (PE32)");
    s += tmp;
    snprintf(tmp, sizeof(tmp), "Sections : %u\r\n", ctx.nsects);
    s += tmp;
    snprintf(tmp, sizeof(tmp), "Timestamp: 0x%08X\r\n", ctx.fhdr->TimeDateStamp);
    s += tmp;
    snprintf(tmp, sizeof(tmp), "Checksum : 0x%08X\r\n", ctx.checksum());
    s += tmp;
    auto& sec_dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_SECURITY);
    snprintf(tmp, sizeof(tmp), "Signature: %s\r\n", sec_dd.VirtualAddress ? "present" : "none");
    s += tmp;
    auto& dbg_dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_DEBUG);
    snprintf(tmp, sizeof(tmp), "Debug dir: %s\r\n\r\n", dbg_dd.VirtualAddress ? "present" : "none");
    s += tmp;
    s += "Sections:\r\n";
    for (int i = 0; i < ctx.nsects; i++) {
        char name[9]{}; memcpy(name, ctx.sects[i].Name, 8);
        snprintf(tmp, sizeof(tmp), "  [%2d] %-8s  VA=0x%08X  raw=0x%08X\r\n",
                 i, name, ctx.sects[i].VirtualAddress, ctx.sects[i].PointerToRawData);
        s += tmp;
    }
    return s;
}

// ═════════════════════════════════════════════════════════════════════════════
// Win32 GUI
// ═════════════════════════════════════════════════════════════════════════════

enum : int {
    IDC_EDT_INPUT = 300, IDC_BTN_BROWSE_IN,
    IDC_EDT_OUTPUT,      IDC_BTN_BROWSE_OUT,
    IDC_EDT_SEED,
    IDC_BTN_LOAD,
    IDC_PANEL_BEFORE,    IDC_PANEL_AFTER,
    IDC_CHK_RICH,        IDC_CHK_TS,
    IDC_CHK_SECTS,       IDC_CHK_DBG,
    IDC_CHK_SIG,         IDC_CHK_IMP,
    IDC_BTN_DRYRUN,      IDC_BTN_PATCH,
    IDC_BTN_CLEAR,
    IDC_LOG,
};

// ── Global widget handles ──────────────────────────────────────────────────
static HWND g_hwnd;
static HWND g_hEdtIn, g_hEdtOut, g_hEdtSeed;
static HWND g_hBefore, g_hAfter;
static HWND g_hLog;
static HWND g_hChkRich, g_hChkTS, g_hChkSects, g_hChkDbg, g_hChkSig, g_hChkImp;
static HFONT g_hFont, g_hFontMono;

static PeCtx g_ctx_before;   // loaded original PE
static PeCtx g_ctx_after;    // patched copy

// ── Helpers ───────────────────────────────────────────────────────────────

static void Log(const char* fmt, ...) {
    char buf[1024];
    va_list va; va_start(va, fmt);
    vsnprintf(buf, sizeof(buf), fmt, va);
    va_end(va);
    std::string line(buf); line += "\r\n";
    int len = GetWindowTextLength(g_hLog);
    SendMessage(g_hLog, EM_SETSEL,     (WPARAM)len, (LPARAM)len);
    SendMessage(g_hLog, EM_REPLACESEL, 0, (LPARAM)line.c_str());
}

static void PanelSet(HWND hw, const std::string& text) {
    SetWindowText(hw, text.c_str());
}

static std::string GetEditStr(HWND hw) {
    int n = GetWindowTextLength(hw);
    if (!n) return "";
    std::string s(n+1, '\0');
    GetWindowText(hw, &s[0], n+1);
    s.resize(n);
    return s;
}

static HWND MakeCtl(const char* cls, const char* txt, DWORD style, DWORD exStyle,
                    int x, int y, int w, int h, int id) {
    HWND hw = CreateWindowEx(exStyle, cls, txt,
        WS_CHILD|WS_VISIBLE|style,
        x, y, w, h, g_hwnd, (HMENU)(UINT_PTR)id,
        (HINSTANCE)GetWindowLongPtr(g_hwnd, GWLP_HINSTANCE), nullptr);
    SendMessage(hw, WM_SETFONT, (WPARAM)g_hFont, TRUE);
    return hw;
}
static HWND MakeLabel(const char* t, int x, int y, int w, int h = 18) {
    return MakeCtl("STATIC", t, SS_SIMPLE, 0, x, y, w, h, 0);
}
static HWND MakeBtn(const char* t, int id, int x, int y, int w, int h = 26) {
    return MakeCtl("BUTTON", t, BS_PUSHBUTTON, 0, x, y, w, h, id);
}
static HWND MakeChk(const char* t, int id, int x, int y, int w, bool chk) {
    HWND hw = MakeCtl("BUTTON", t, BS_AUTOCHECKBOX, 0, x, y, w, 20, id);
    Button_SetCheck(hw, chk ? BST_CHECKED : BST_UNCHECKED);
    return hw;
}

static bool BrowseFile(bool open, char* buf, int bufsz, const char* filter, const char* title) {
    OPENFILENAMEA ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner   = g_hwnd;
    ofn.lpstrFilter = filter;   // e.g. "EXE Files\0*.exe\0All\0*.*\0"
    ofn.lpstrFile   = buf;
    ofn.nMaxFile    = bufsz;
    ofn.lpstrTitle  = title;
    ofn.Flags       = open
        ? (OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY)
        : (OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY);
    return open ? GetOpenFileNameA(&ofn) != 0 : GetSaveFileNameA(&ofn) != 0;
}

// ── PE load & display ─────────────────────────────────────────────────────

static void DoLoad() {
    std::string path = GetEditStr(g_hEdtIn);
    if (path.empty()) { Log("[!] No input file specified."); return; }

    g_ctx_before = {};
    if (!pe_load(path.c_str(), g_ctx_before)) {
        Log("[-] Failed to load PE: %s", path.c_str());
        PanelSet(g_hBefore, "(load failed)");
        PanelSet(g_hAfter,  "");
        return;
    }

    std::string summary = pe_summary(g_ctx_before);
    PanelSet(g_hBefore, summary);
    PanelSet(g_hAfter, "(not patched yet)");
    g_ctx_after = {};

    char size_s[32]; snprintf(size_s, sizeof(size_s), "%zu", g_ctx_before.data.size());
    Log("[+] Loaded: %s  (%s bytes)", path.c_str(), size_s);
    Log("    Arch: %s  Sections: %u  Signed: %s",
        g_ctx_before.is64 ? "x64" : "x86",
        g_ctx_before.nsects,
        g_ctx_before.datadir(IMAGE_DIRECTORY_ENTRY_SECURITY).VirtualAddress ? "yes" : "no");
}

// ── Core patch action ─────────────────────────────────────────────────────

static void DoPatch(bool dry_run) {
    if (!g_ctx_before.valid) { Log("[!] Load a PE file first."); return; }

    std::string seed_str = GetEditStr(g_hEdtSeed);
    if (seed_str.empty()) { Log("[!] Enter a seed string."); return; }

    uint32_t seed = seed_from_str(seed_str.c_str());
    Log("──── %s  seed=\"%s\" (0x%08X) ────",
        dry_run ? "DRY RUN" : "PATCHING", seed_str.c_str(), seed);

    // Work on a deep copy — re-parse pointers into the new buffer
    g_ctx_after       = {};
    g_ctx_after.data  = g_ctx_before.data;
    g_ctx_after.dos   = (IMAGE_DOS_HEADER*)g_ctx_after.data.data();
    g_ctx_after.fhdr  = (IMAGE_FILE_HEADER*)(g_ctx_after.data.data() + g_ctx_after.dos->e_lfanew + sizeof(DWORD));
    g_ctx_after.nsects= g_ctx_after.fhdr->NumberOfSections;
    g_ctx_after.is64  = (g_ctx_after.fhdr->Machine == IMAGE_FILE_MACHINE_AMD64);
    g_ctx_after.sects = IMAGE_FIRST_SECTION((IMAGE_NT_HEADERS*)(g_ctx_after.data.data()+g_ctx_after.dos->e_lfanew));
    g_ctx_after.valid = true;

    std::string patch_log;

    if (Button_GetCheck(g_hChkRich))  patch_rich      (g_ctx_after, patch_log);
    if (Button_GetCheck(g_hChkTS))    patch_timestamp (g_ctx_after, seed, patch_log);
    if (Button_GetCheck(g_hChkSects)) patch_sections  (g_ctx_after, seed, patch_log);
    if (Button_GetCheck(g_hChkDbg))   patch_debug     (g_ctx_after, patch_log);
    if (Button_GetCheck(g_hChkSig))   patch_sig       (g_ctx_after, patch_log);
    if (Button_GetCheck(g_hChkImp))   patch_imports_reorder(g_ctx_after, seed, patch_log);
    patch_checksum(g_ctx_after, patch_log);    // always recalculate last

    // Show patch steps in log
    // Split patch_log by \r\n and log each line
    std::istringstream iss(patch_log);
    std::string line;
    while (std::getline(iss, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (!line.empty()) Log("  %s", line.c_str());
    }

    // Update After panel
    PanelSet(g_hAfter, pe_summary(g_ctx_after));

    if (dry_run) {
        Log("[dry-run] No file written.");
        return;
    }

    // Save to output path
    std::string out_path = GetEditStr(g_hEdtOut);
    if (out_path.empty()) {
        std::string in = GetEditStr(g_hEdtIn);
        size_t sep = in.find_last_of("/\\");
        out_path = (sep == std::string::npos)
            ? "patched_" + in
            : in.substr(0, sep+1) + "patched_" + in.substr(sep+1);
        SetWindowText(g_hEdtOut, out_path.c_str());
    }

    if (!pe_save(out_path.c_str(), g_ctx_after)) {
        Log("[-] Write failed: %s", out_path.c_str());
        return;
    }
    char sz_s[32]; snprintf(sz_s, sizeof(sz_s), "%zu", g_ctx_after.data.size());
    Log("[+] Saved: %s  (%s bytes)", out_path.c_str(), sz_s);
    Log("    Verify: dumpbin /HEADERS \"%s\"", out_path.c_str());
}

// ── WM_CREATE ─────────────────────────────────────────────────────────────

static void OnCreate(HINSTANCE hInst) {
    g_hFont     = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    g_hFontMono = CreateFont(14, 0, 0, 0, FW_NORMAL, 0, 0, 0,
                             DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                             CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                             FIXED_PITCH | FF_MODERN, "Consolas");

    // ── ① File inputs ───────────────────────────────────────────────────
    int y = 8;
    MakeLabel("Input EXE :", 8, y+4, 80);
    g_hEdtIn = MakeCtl("EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE,
                        94, y, 680, 22, IDC_EDT_INPUT);
    MakeBtn("Browse...", IDC_BTN_BROWSE_IN, 780, y, 80);
    y += 28;

    MakeLabel("Output EXE:", 8, y+4, 80);
    g_hEdtOut = MakeCtl("EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE,
                         94, y, 680, 22, IDC_EDT_OUTPUT);
    MakeBtn("Browse...", IDC_BTN_BROWSE_OUT, 780, y, 80);
    y += 28;

    MakeLabel("Seed string:", 8, y+4, 80);
    g_hEdtSeed = MakeCtl("EDIT", "RedTeam2024_v1", ES_AUTOHSCROLL,
                          WS_EX_CLIENTEDGE, 94, y, 340, 22, IDC_EDT_SEED);
    MakeBtn("Load PE", IDC_BTN_LOAD, 444, y, 80, 22);
    y += 34;

    // ── ② Before / After panels ─────────────────────────────────────────
    MakeLabel("─── Before (original) ───────────────────", 8, y, 432);
    MakeLabel("─── After (patched) ────────────────────", 448, y, 420);
    y += 16;

    g_hBefore = MakeCtl("EDIT", "(load a PE file first)",
        ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 8, y, 432, 210, IDC_PANEL_BEFORE);
    SendMessage(g_hBefore, WM_SETFONT, (WPARAM)g_hFontMono, TRUE);

    g_hAfter = MakeCtl("EDIT", "",
        ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 448, y, 418, 210, IDC_PANEL_AFTER);
    SendMessage(g_hAfter, WM_SETFONT, (WPARAM)g_hFontMono, TRUE);
    y += 218;

    // ── ③ Options ────────────────────────────────────────────────────────
    MakeLabel("Apply patches:", 8, y+2, 100);
    g_hChkRich  = MakeChk("Rich Header",    IDC_CHK_RICH,  116, y,   110, true);
    g_hChkTS    = MakeChk("TimeDateStamp",  IDC_CHK_TS,    234, y,   120, true);
    g_hChkSects = MakeChk("Section Names",  IDC_CHK_SECTS, 362, y,   110, true);
    g_hChkDbg   = MakeChk("Debug Dir",      IDC_CHK_DBG,   480, y,   90,  true);
    g_hChkSig   = MakeChk("Signature",      IDC_CHK_SIG,   578, y,   90,  true);
    g_hChkImp   = MakeChk("Reorder Imports",IDC_CHK_IMP,   674, y,   135, false);
    y += 28;

    // ── ④ Action buttons ─────────────────────────────────────────────────
    MakeBtn("Dry Run",      IDC_BTN_DRYRUN, 8,   y, 100);
    MakeBtn("▶  PATCH EXE",IDC_BTN_PATCH,  116, y, 130);
    MakeBtn("Clear Log",    IDC_BTN_CLEAR,  700, y,  80);
    y += 34;

    // ── ⑤ Log ─────────────────────────────────────────────────────────
    MakeLabel("Log:", 8, y, 60);
    y += 16;
    g_hLog = MakeCtl("EDIT", "",
        ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 8, y, 858, 178, IDC_LOG);
    SendMessage(g_hLog, WM_SETFONT, (WPARAM)g_hFontMono, TRUE);

    Log("PE Characteristic Patcher — ready.");
    Log("Step 1: Browse or type the input EXE path, then click [Load PE].");
    Log("Step 2: Enter a seed string (controls all parameter derivation).");
    Log("Step 3: Click [Dry Run] to preview changes, or [PATCH EXE] to write output.");
    Log("Changing the seed produces a completely different binary fingerprint.");
}

// ── WM_COMMAND ────────────────────────────────────────────────────────────

static void OnCommand(int id) {
    char buf[MAX_PATH] = {};
    switch (id) {
    case IDC_BTN_BROWSE_IN:
        if (BrowseFile(true, buf, MAX_PATH, "EXE Files\0*.exe\0All Files\0*.*\0", "Select Input EXE")) {
            SetWindowText(g_hEdtIn, buf);
            DoLoad();
        }
        break;
    case IDC_BTN_BROWSE_OUT:
        if (BrowseFile(false, buf, MAX_PATH, "EXE Files\0*.exe\0All Files\0*.*\0", "Save Patched EXE As"))
            SetWindowText(g_hEdtOut, buf);
        break;
    case IDC_BTN_LOAD:   DoLoad();          break;
    case IDC_BTN_DRYRUN: DoPatch(true);     break;
    case IDC_BTN_PATCH:  DoPatch(false);    break;
    case IDC_BTN_CLEAR:  SetWindowText(g_hLog, ""); break;
    }
}

// ── Window procedure ──────────────────────────────────────────────────────

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE:
        g_hwnd = hwnd;
        OnCreate(((CREATESTRUCT*)lp)->hInstance);
        return 0;

    case WM_COMMAND:
        if (HIWORD(wp) == BN_CLICKED || HIWORD(wp) == 0)
            OnCommand(LOWORD(wp));
        return 0;

    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)wp, TRANSPARENT);
        return (LRESULT)GetSysColorBrush(COLOR_3DFACE);

    case WM_DESTROY:
        if (g_hFontMono) DeleteObject(g_hFontMono);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wp, lp);
}

// ── WinMain ───────────────────────────────────────────────────────────────

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nShow) {
    INITCOMMONCONTROLSEX icex = { sizeof(icex), ICC_WIN95_CLASSES };
    InitCommonControlsEx(&icex);

    WNDCLASSEX wc = { sizeof(wc) };
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hbrBackground = (HBRUSH)(COLOR_3DFACE + 1);
    wc.lpszClassName = "PatchToolWnd";
    wc.hIcon         = LoadIcon(nullptr, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassEx(&wc);

    RECT rc = { 0, 0, 874, 740 };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME|WS_MAXIMIZEBOX), FALSE);

    HWND hwnd = CreateWindowEx(0, "PatchToolWnd",
        "PE Characteristic Patcher",
        WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME | WS_MAXIMIZEBOX),
        CW_USEDEFAULT, CW_USEDEFAULT,
        rc.right - rc.left, rc.bottom - rc.top,
        nullptr, nullptr, hInst, nullptr);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG m;
    while (GetMessage(&m, nullptr, 0, 0)) {
        TranslateMessage(&m);
        DispatchMessage(&m);
    }
    return (int)m.wParam;
}
