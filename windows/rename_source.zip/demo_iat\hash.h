#pragma once
// hash.h  —  API name hashing (ROR-13 accumulator)
//
// This algorithm is the single source of truth.
// gen_config.py mirrors it exactly in Python.
// Any change here must be reflected there too.

#include <cstdint>

static inline uint32_t ror32(uint32_t v, uint8_t n) {
    return (v >> n) | (v << (32u - n));
}

// Fold an arbitrary string into a 32-bit seed (djb2 variant).
// Used both offline (gen_config.py) and optionally at runtime.
static inline uint32_t str_to_seed(const char* s) {
    uint32_t h = 5381u;
    while (*s) h = ((h << 5) + h) ^ (uint8_t)*s++;
    return h;
}

// Hash an export name against a seed.
// Result must match the pre-computed HASH_* constants in config.h.
static inline uint32_t api_hash(const char* name, uint32_t seed) {
    uint32_t h = seed;
    while (*name) {
        h = ror32(h, 13);
        h += (uint8_t)*name++;
    }
    return h;
}

// ---------------------------------------------------------------------------
// Module-name hashing (lowercase) — for PEB module-list matching.
//
// BaseDllName in LDR_DATA_TABLE_ENTRY is a UNICODE_STRING; case varies across
// Windows versions ("KERNEL32.DLL" vs "kernel32.dll"). We lowercase before
// hashing so the precomputed MOD_HASH_* constants (generated against the
// canonical lowercase form in gen_config.py) match regardless of OS case.
// ---------------------------------------------------------------------------

// ASCII variant — mirror in Python (gen_config.py) for offline computation.
static inline uint32_t mod_hash(const char* s, uint32_t seed) {
    uint32_t h = seed;
    while (*s) {
        char c = *s++;
        if (c >= 'A' && c <= 'Z') c += 32;
        h = ror32(h, 13);
        h += (uint8_t)c;
    }
    return h;
}

// UTF-16 variant — for hashing BaseDllName.Buffer at runtime.
// DLL names are pure ASCII so we hash the low byte of each wchar_t only,
// which makes the result identical to mod_hash() on the ASCII form.
static inline uint32_t mod_hash_w(const wchar_t* s, uint32_t seed) {
    uint32_t h = seed;
    while (*s) {
        wchar_t c = *s++;
        if (c >= L'A' && c <= L'Z') c += 32;
        h = ror32(h, 13);
        h += (uint8_t)c;
    }
    return h;
}
