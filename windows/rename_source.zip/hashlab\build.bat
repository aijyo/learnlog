@echo off
:: build.bat — hashlab GUI build
:: Run from VS Developer Command Prompt (cl.exe in PATH)

echo.
echo ============================================
echo   hashlab_ui build
echo ============================================

echo.
echo [1/2] Building hashlab_ui.exe (Win32 GUI)...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc ^
   hashlab_ui.cpp ^
   comctl32.lib user32.lib gdi32.lib bcrypt.lib ^
   /link /subsystem:windows /out:hashlab_ui.exe
if errorlevel 1 ( echo [-] build failed & exit /b 1 )
echo [+] hashlab_ui.exe

echo.
echo [2/2] Dependencies:
dumpbin /DEPENDENTS hashlab_ui.exe | findstr ".dll"

echo.
echo ============================================
echo   Run: hashlab_ui.exe
echo   Companion to demo_iat:
echo     • Hash matrix    — compare ROR-13 / FNV-1a / djb2 / sdbm / CRC32 / Murmur3
echo     • Collision find — brute-force a string with a target hash
echo     • Export config.h— generates drop-in replacement for gen_config.py
echo     • String XOR     — preview strenc.h-style ciphertext
echo ============================================
