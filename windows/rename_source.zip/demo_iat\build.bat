@echo off
:: build.bat  —  demo_iat build script (CLI + GUI)
:: Run from VS Developer Command Prompt (cl.exe in PATH)
:: Requires Python 3 for gen_config.py

setlocal

set SEED=RedTeam2024_Demo
if not "%1"=="" set SEED=%1

echo.
echo ════════════════════════════════════════════
echo   demo_iat build
echo ════════════════════════════════════════════

echo.
echo [1/4] Generating config.h  seed="%SEED%"
python gen_config.py "%SEED%" > config.h
if errorlevel 1 ( echo [-] gen_config.py failed & exit /b 1 )
echo [+] config.h written
echo.
type config.h
echo.

echo [2/4] Building CLI version (demo_iat.exe)...
cl /nologo /MT /O2 /std:c++17 /W3 /WX /EHsc ^
   main.cpp ^
   /link /subsystem:console /out:demo_iat.exe
if errorlevel 1 ( echo [-] CLI build failed & exit /b 1 )
echo [+] demo_iat.exe

echo.
echo [3/4] Building GUI version (demo_iat_ui.exe)...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc ^
   demo_iat_ui.cpp comctl32.lib ^
   /link /subsystem:windows /out:demo_iat_ui.exe
if errorlevel 1 ( echo [-] GUI build failed & exit /b 1 )
echo [+] demo_iat_ui.exe

echo.
echo [4/4] IAT audit — target APIs must NOT appear
dumpbin /IMPORTS demo_iat_ui.exe | findstr /i "MessageBoxA VirtualAlloc VirtualFree GetSystemInfo"
if errorlevel 1 (
    echo [PASS] Target APIs are NOT in IAT.
) else (
    echo [FAIL] Some target APIs still in IAT!
)

echo.
echo ════════════════════════════════════════════
echo   Run CLI : demo_iat.exe
echo   Run GUI : demo_iat_ui.exe
echo   Change seed: build.bat "NewSeedString"
echo ════════════════════════════════════════════
