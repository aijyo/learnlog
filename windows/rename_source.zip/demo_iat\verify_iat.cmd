@echo off
rem verify_iat.cmd -- Post-build audit for demo_iat_ui (Level 4).
rem Usage: verify_iat.cmd <path-to-exe>
rem
rem Fails the build (exit 1) if any of the targeted "should-be-hidden" APIs
rem still appear in the EXE's import table.
rem
rem Patterns use a leading space so each /C: alternative aligns to the IAT
rem line format ("<ord> <Name>"). Only A-suffix variants are checked.
rem
rem Out of scope (CRT internals — cannot remove without abandoning /MT):
rem   - GetProcAddress / VirtualProtect    (CRT __security_init, EncodePointer)
rem   - GetModuleHandleW / LoadLibraryExW  (CRT module-enumeration helpers)
rem   - EncodePointer / ExitProcess / etc. (CRT bookkeeping)
rem
rem In scope (what *our* code controls):
rem   - MessageBox{A,W}, VirtualAlloc{,Ex}, VirtualFree, GetSystemInfo
rem   - LoadLibraryA, GetModuleHandleA     (A variants - CRT uses W)
rem   - CreateRemoteThread, OpenProcess, Write/ReadProcessMemory
rem   - NtAllocateVirtualMemory, NtWriteVirtualMemory, NtCreateThreadEx

setlocal

if "%~1"=="" (
    echo verify_iat.cmd: missing EXE argument
    exit /b 1
)

set "EXE=%~1"
set "TMP_IAT=%TEMP%\iat_dump_%RANDOM%.txt"

dumpbin /IMPORTS "%EXE%" > "%TMP_IAT%" 2>nul
if errorlevel 1 (
    echo [verify_iat] dumpbin failed on "%EXE%"
    del "%TMP_IAT%" 2>nul
    exit /b 1
)

call :run_findstr > nul
if errorlevel 1 (
    echo   [PASS] L4 audit clean -- our targeted APIs not in IAT
    echo          ^(CRT-pulled imports such as GetProcAddress/VirtualProtect/^*W are out of scope^)
    del "%TMP_IAT%" 2>nul
    exit /b 0
)

echo   [FAIL] targeted APIs still appear in IAT:
call :run_findstr
del "%TMP_IAT%" 2>nul
exit /b 1

:run_findstr
findstr /I /C:" MessageBoxA" /C:" MessageBoxW" /C:" VirtualAlloc" /C:" VirtualAllocEx" /C:" VirtualFree" /C:" GetSystemInfo" /C:" LoadLibraryA" /C:" GetModuleHandleA" /C:" CreateRemoteThread" /C:" OpenProcess" /C:" WriteProcessMemory" /C:" ReadProcessMemory" /C:" NtAllocateVirtualMemory" /C:" NtWriteVirtualMemory" /C:" NtCreateThreadEx" "%TMP_IAT%"
exit /b %errorlevel%
