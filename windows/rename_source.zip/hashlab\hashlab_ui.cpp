/*
 * hashlab_ui.cpp  —  API Hashing Algorithm Lab  (Win32 GUI, standalone)
 * ─────────────────────────────────────────────────────────────────────────────
 * Companion to demo_iat — explore the parameter space of API hashing.
 *
 * Why this exists:
 *   demo_iat hard-codes ROR-13 in hash.h and lets the seed string be the only
 *   knob. In reality, malware families pick from a wide menu of algorithms
 *   (ROR-13 / FNV-1a / djb2 / sdbm / CRC32 / Murmur3 / custom), and an analyst
 *   facing an unknown sample must first IDENTIFY which one. hashlab lets you
 *   eyeball them side-by-side and see exactly how hash constants shift.
 *
 * UI:
 *   ① Seed string + folded seed value (djb2, matches demo_iat's str_to_seed)
 *   ② API list (editable) ⟷ matrix of hash(API) for ALL 6 algorithms
 *   ③ Three tabs:
 *        [Collision finder]    brute-force a string with target hash
 *        [Export config.h]     emit drop-in replacement for gen_config.py
 *        [String XOR preview]  show strenc.h-style ciphertext for any string
 *   ④ Log
 *
 * Build (x64 VS Developer Command Prompt):
 *   cl /nologo /MT /O2 /std:c++17 /W3 /EHsc hashlab_ui.cpp ^
 *      comctl32.lib user32.lib gdi32.lib ^
 *      /link /subsystem:windows /out:hashlab_ui.exe
 */

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <commctrl.h>
#include <bcrypt.h>
#include <intrin.h>
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "bcrypt.lib")

#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdarg>
#include <cctype>
#include <ctime>
#include <string>
#include <vector>
#include <sstream>

// ═══════════════════════════════════════════════════════════════════════════
// 1. Hash algorithms
// ═══════════════════════════════════════════════════════════════════════════

static inline uint32_t ror32(uint32_t v, uint8_t n) { return (v >> n) | (v << (32u - n)); }

// All hash signatures: (string, seed) -> uint32.
// Each algorithm folds its native init constant with `seed` to keep parity
// between zero-seed and demo_iat-style seeded use.

static uint32_t hash_ror13(const char* s, uint32_t seed) {
    uint32_t h = seed;
    while (*s) { h = ror32(h, 13); h += (uint8_t)*s++; }
    return h;
}
static uint32_t hash_fnv1a(const char* s, uint32_t seed) {
    uint32_t h = 0x811C9DC5u ^ seed;
    while (*s) { h ^= (uint8_t)*s++; h *= 0x01000193u; }
    return h;
}
static uint32_t hash_djb2(const char* s, uint32_t seed) {
    uint32_t h = 5381u ^ seed;
    while (*s) { h = h * 33u + (uint8_t)*s++; }
    return h;
}
static uint32_t hash_sdbm(const char* s, uint32_t seed) {
    uint32_t h = seed;
    while (*s) { h = (uint8_t)*s++ + (h << 6) + (h << 16) - h; }
    return h;
}
static uint32_t hash_crc32(const char* s, uint32_t seed) {
    uint32_t h = 0xFFFFFFFFu ^ seed;
    while (*s) {
        h ^= (uint8_t)*s++;
        for (int b = 0; b < 8; b++) {
            uint32_t mask = 0u - (h & 1u);
            h = (h >> 1) ^ (0xEDB88320u & mask);
        }
    }
    return ~h;
}
static uint32_t hash_mm3(const char* s, uint32_t seed) {
    // MurmurHash3 x86 32 — abbreviated single-stream version.
    uint32_t h = seed;
    size_t len = strlen(s);
    const uint8_t* p = (const uint8_t*)s;
    const uint32_t c1 = 0xCC9E2D51u, c2 = 0x1B873593u;
    while (len >= 4) {
        uint32_t k = (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
        k *= c1; k = (k<<15)|(k>>17); k *= c2;
        h ^= k; h = (h<<13)|(h>>19); h = h*5 + 0xE6546B64u;
        p += 4; len -= 4;
    }
    uint32_t k = 0;
    if (len >= 3) k ^= (uint32_t)p[2] << 16;
    if (len >= 2) k ^= (uint32_t)p[1] << 8;
    if (len >= 1) { k ^= (uint32_t)p[0]; k *= c1; k = (k<<15)|(k>>17); k *= c2; h ^= k; }
    h ^= (uint32_t)strlen(s);
    h ^= h >> 16; h *= 0x85EBCA6Bu;
    h ^= h >> 13; h *= 0xC2B2AE35u;
    h ^= h >> 16;
    return h;
}

struct HashAlgo { const char* name; uint32_t (*fn)(const char*, uint32_t); };
static const HashAlgo ALGOS[] = {
    {"ROR-13",  hash_ror13},
    {"FNV-1a",  hash_fnv1a},
    {"djb2",    hash_djb2},
    {"sdbm",    hash_sdbm},
    {"CRC32",   hash_crc32},
    {"Murmur3", hash_mm3},
};
static constexpr int ALGO_N = (int)(sizeof(ALGOS) / sizeof(ALGOS[0]));

// Seed string → uint32 (matches str_to_seed in demo_iat/hash.h).
static uint32_t fold_seed(const char* s) {
    uint32_t h = 5381u;
    while (*s) h = ((h << 5) + h) ^ (uint8_t)*s++;
    return h;
}

// strenc.h-style XOR-key derivation from seed string.
static uint8_t derive_xor_key(const char* s) {
    uint8_t acc = 0x5Au;
    while (*s) {
        acc = (uint8_t)(((uint8_t)(acc << 3u) | (uint8_t)(acc >> 5u)) ^ (uint8_t)*s++);
    }
    return acc;
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. UI state
// ═══════════════════════════════════════════════════════════════════════════

enum : int {
    IDC_EDT_SEED = 500,
    IDC_LBL_SEED_VAL,
    IDC_EDT_APIS,
    IDC_BTN_HASH,
    IDC_LV_MATRIX,
    IDC_TAB,
    // Tab 0: collision
    IDC_EDT_TARGET, IDC_CMB_COLL_ALG, IDC_CMB_MAXLEN, IDC_CMB_CHARSET,
    IDC_BTN_COLL,   IDC_LBL_COLL_RES,
    // Tab 1: export
    IDC_CMB_EXP_ALG, IDC_BTN_EXP,
    // Tab 2: string enc
    IDC_EDT_PLAIN,  IDC_LBL_KEY,  IDC_BTN_ENC,  IDC_EDT_CIPHER,
    // Tab 3: imphash collision
    IDC_EDT_IMP_BASE,  IDC_EDT_IMP_CAND,
    IDC_EDT_IMP_TGT,   IDC_CMB_IMP_LEN,
    IDC_BTN_IMP_BASE,  IDC_BTN_IMP_FIND,
    IDC_LBL_IMP_RES,
    // Log
    IDC_LOG,        IDC_BTN_CLEAR,
};

static HWND g_hwnd;
static HWND g_hEdtSeed, g_hLblSeedVal;
static HWND g_hEdtApis, g_hLvMatrix, g_hTab, g_hLog;

// Tab 0
static HWND g_hEdtTarget, g_hCmbCollAlg, g_hCmbMaxLen, g_hCmbCharset;
static HWND g_hLblCollRes;
// Tab 1
static HWND g_hCmbExpAlg;
// Tab 2
static HWND g_hEdtPlain, g_hLblKey, g_hEdtCipher;
// Tab 3 (imphash collision)
static HWND g_hEdtImpBase, g_hEdtImpCand, g_hEdtImpTgt, g_hCmbImpLen;
static HWND g_hLblImpRes;

static HFONT g_hFont, g_hMono;
static int   g_cur_tab = 0;

// Cached matrix data
struct ApiRow { std::string name; uint32_t hashes[ALGO_N]; };
static std::vector<ApiRow> g_rows;

// ── helpers ────────────────────────────────────────────────────────────────

static void Log(const char* fmt, ...) {
    char buf[2048];
    va_list va; va_start(va, fmt); vsnprintf(buf, sizeof(buf), fmt, va); va_end(va);
    std::string s(buf); s += "\r\n";
    int len = GetWindowTextLength(g_hLog);
    SendMessage(g_hLog, EM_SETSEL, (WPARAM)len, (LPARAM)len);
    SendMessage(g_hLog, EM_REPLACESEL, 0, (LPARAM)s.c_str());
}

static HWND MakeCtl(const char* cls, const char* txt, DWORD style, DWORD exStyle,
                    int x, int y, int w, int h, int id, HFONT font = nullptr) {
    HWND hw = CreateWindowEx(exStyle, cls, txt,
        WS_CHILD | WS_VISIBLE | style,
        x, y, w, h, g_hwnd, (HMENU)(UINT_PTR)id,
        (HINSTANCE)GetWindowLongPtr(g_hwnd, GWLP_HINSTANCE), nullptr);
    SendMessage(hw, WM_SETFONT, (WPARAM)(font ? font : g_hFont), TRUE);
    return hw;
}
static HWND MakeLabel(const char* t, int x, int y, int w, int h = 18, int id = 0) {
    return MakeCtl("STATIC", t, SS_SIMPLE, 0, x, y, w, h, id);
}
static HWND MakeBtn(const char* t, int id, int x, int y, int w, int h = 26) {
    return MakeCtl("BUTTON", t, BS_PUSHBUTTON, 0, x, y, w, h, id);
}
static HWND MakeCombo(int id, int x, int y, int w, int h) {
    HWND hw = CreateWindowEx(0, "COMBOBOX", "",
        WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
        x, y, w, h, g_hwnd, (HMENU)(UINT_PTR)id,
        (HINSTANCE)GetWindowLongPtr(g_hwnd, GWLP_HINSTANCE), nullptr);
    SendMessage(hw, WM_SETFONT, (WPARAM)g_hFont, TRUE);
    return hw;
}

static void AddCol(HWND lv, int idx, int w, const char* text) {
    LVCOLUMN c{}; c.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_FMT;
    c.fmt = LVCFMT_LEFT; c.cx = w; c.pszText = const_cast<LPSTR>(text);
    ListView_InsertColumn(lv, idx, &c);
}
static void LvSet(HWND lv, int row, int col, const char* text) {
    LVITEM lvi{}; lvi.mask = LVIF_TEXT; lvi.iItem = row; lvi.iSubItem = col;
    lvi.pszText = const_cast<LPSTR>(text);
    if (col == 0) ListView_InsertItem(lv, &lvi);
    else          ListView_SetItem(lv, &lvi);
}

static std::string GetEditStr(HWND hw) {
    int n = GetWindowTextLength(hw);
    if (n <= 0) return "";
    std::string s(n + 1, '\0');
    GetWindowText(hw, &s[0], n + 1);
    s.resize(n);
    return s;
}

static std::vector<std::string> split_lines(const std::string& s) {
    std::vector<std::string> out;
    std::stringstream ss(s);
    std::string line;
    while (std::getline(ss, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (!line.empty()) out.push_back(line);
    }
    return out;
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. Hash matrix
// ═══════════════════════════════════════════════════════════════════════════

static uint32_t current_seed_value() {
    std::string s = GetEditStr(g_hEdtSeed);
    return fold_seed(s.c_str());
}

static void UpdateSeedLabel() {
    uint32_t v = current_seed_value();
    char buf[32]; snprintf(buf, sizeof(buf), "= 0x%08X", v);
    SetWindowText(g_hLblSeedVal, buf);
}

static void DoHashAll() {
    uint32_t seed = current_seed_value();
    std::string apis_txt = GetEditStr(g_hEdtApis);
    auto names = split_lines(apis_txt);
    g_rows.clear();
    for (auto& n : names) {
        ApiRow r; r.name = n;
        for (int a = 0; a < ALGO_N; a++) r.hashes[a] = ALGOS[a].fn(n.c_str(), seed);
        g_rows.push_back(std::move(r));
    }
    ListView_DeleteAllItems(g_hLvMatrix);
    for (size_t i = 0; i < g_rows.size(); i++) {
        LvSet(g_hLvMatrix, (int)i, 0, g_rows[i].name.c_str());
        for (int a = 0; a < ALGO_N; a++) {
            char buf[16]; snprintf(buf, sizeof(buf), "0x%08X", g_rows[i].hashes[a]);
            LvSet(g_hLvMatrix, (int)i, a + 1, buf);
        }
    }
    Log("Hashed %zu API names with seed 0x%08X across %d algorithms.",
        names.size(), seed, ALGO_N);
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. Collision finder
// ═══════════════════════════════════════════════════════════════════════════

static const char* CHARSETS[] = {
    "abcdefghijklmnopqrstuvwxyz",                                                              // alpha-lower
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",                                    // alpha
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",                          // alphanumeric
    " !#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_"
      "`abcdefghijklmnopqrstuvwxyz{|}~",                                                       // printable
};
static const char* CHARSET_NAMES[] = {"alpha-lower", "alpha (mixed case)", "alphanumeric", "printable ASCII"};

static void DoFindCollision() {
    std::string tgt_s = GetEditStr(g_hEdtTarget);
    if (tgt_s.empty()) { Log("[!] target hash required (e.g., 0x12345678)"); return; }
    uint32_t target = (uint32_t)strtoul(tgt_s.c_str(), nullptr, 0);

    int algo_idx = (int)SendMessage(g_hCmbCollAlg, CB_GETCURSEL, 0, 0);
    int maxlen   = (int)SendMessage(g_hCmbMaxLen, CB_GETCURSEL, 0, 0) + 1;  // 1..8
    int cs_idx   = (int)SendMessage(g_hCmbCharset, CB_GETCURSEL, 0, 0);
    if (algo_idx < 0 || algo_idx >= ALGO_N) algo_idx = 0;
    if (cs_idx < 0 || cs_idx >= 4) cs_idx = 2;

    uint32_t seed = current_seed_value();
    const char* cs = CHARSETS[cs_idx];
    int csn = (int)strlen(cs);
    const auto& A = ALGOS[algo_idx];

    Log("──── Collision search ────");
    Log("  target  = 0x%08X", target);
    Log("  algo    = %s   seed = 0x%08X", A.name, seed);
    Log("  charset = %s (n=%d)   max length = %d", CHARSET_NAMES[cs_idx], csn, maxlen);

    const uint64_t CAP = 50ULL * 1000ULL * 1000ULL;   // 50 million attempts
    uint64_t attempts = 0;
    char buf[16];
    clock_t t0 = clock();

    for (int len = 1; len <= maxlen && attempts < CAP; len++) {
        int idx[16] = {0};
        bool done_len = false;
        while (!done_len && attempts < CAP) {
            for (int i = 0; i < len; i++) buf[i] = cs[idx[i]];
            buf[len] = 0;
            attempts++;
            if (A.fn(buf, seed) == target) {
                double secs = (double)(clock() - t0) / CLOCKS_PER_SEC;
                Log("  [+] HIT  %s = \"%s\"  after %llu attempts (%.3f s)",
                    A.name, buf, (unsigned long long)attempts, secs);
                char res[256];
                snprintf(res, sizeof(res), "found  \"%s\"   (%llu tries, %.2f s)",
                         buf, (unsigned long long)attempts, secs);
                SetWindowText(g_hLblCollRes, res);
                return;
            }
            // increment indices (base-csn)
            int pos = len - 1;
            while (pos >= 0) {
                idx[pos]++;
                if (idx[pos] < csn) break;
                idx[pos] = 0;
                pos--;
            }
            if (pos < 0) done_len = true;
        }
        Log("  ... length %d exhausted (%llu attempts so far)", len,
            (unsigned long long)attempts);
    }
    double secs = (double)(clock() - t0) / CLOCKS_PER_SEC;
    Log("  [-] no collision found within %llu attempts (%.3f s)",
        (unsigned long long)attempts, secs);
    SetWindowText(g_hLblCollRes, "no collision found within budget");
}

// ═══════════════════════════════════════════════════════════════════════════
// 5. Export config.h
// ═══════════════════════════════════════════════════════════════════════════

// Same canonical API list as gen_config.py's APIS[].
static const struct { const char* dll; const char* api; } DEFAULT_APIS[] = {
    {"user32.dll",   "MessageBoxA"},
    {"user32.dll",   "MessageBoxW"},
    {"kernel32.dll", "VirtualAlloc"},
    {"kernel32.dll", "VirtualAllocEx"},
    {"kernel32.dll", "VirtualFree"},
    {"kernel32.dll", "VirtualProtect"},
    {"kernel32.dll", "OpenProcess"},
    {"kernel32.dll", "CreateRemoteThread"},
    {"kernel32.dll", "WriteProcessMemory"},
    {"kernel32.dll", "ReadProcessMemory"},
    {"kernel32.dll", "GetSystemInfo"},
    {"kernel32.dll", "GetCurrentProcess"},
    {"kernel32.dll", "ExitProcess"},
    {"kernel32.dll", "LoadLibraryA"},
    {"kernel32.dll", "GetProcAddress"},
    {"ntdll.dll",    "NtAllocateVirtualMemory"},
    {"ntdll.dll",    "NtWriteVirtualMemory"},
    {"ntdll.dll",    "NtCreateThreadEx"},
};

static void DoExportConfig() {
    int algo_idx = (int)SendMessage(g_hCmbExpAlg, CB_GETCURSEL, 0, 0);
    if (algo_idx < 0 || algo_idx >= ALGO_N) algo_idx = 0;
    const auto& A = ALGOS[algo_idx];

    std::string seed_str = GetEditStr(g_hEdtSeed);
    uint32_t seed = fold_seed(seed_str.c_str());

    Log("──── Generated config.h  (paste below into demo_iat/config.h) ────");
    Log("// ---------------------------------------------------------------");
    Log("// Generated by hashlab_ui — drop-in replacement for gen_config.py");
    Log("// Algorithm   : %s", A.name);
    Log("// Seed string : \"%s\"", seed_str.c_str());
    Log("// Seed value  : 0x%08X", seed);
    Log("// ---------------------------------------------------------------");
    Log("#pragma once");
    Log("#include <cstdint>");
    Log("");
    Log("#define CFG_SEED_STR  \"%s\"", seed_str.c_str());
    Log("#define CFG_SEED      0x%08Xu", seed);
    Log("");
    if (algo_idx != 0) {
        Log("// NOTE: this output uses %s, NOT the default ROR-13 of hash.h.", A.name);
        Log("//       You must replace api_hash() in hash.h with the matching impl.");
        Log("");
    }
    const char* prev = nullptr;
    int n = (int)(sizeof(DEFAULT_APIS) / sizeof(DEFAULT_APIS[0]));
    for (int i = 0; i < n; i++) {
        if (!prev || strcmp(prev, DEFAULT_APIS[i].dll) != 0) {
            Log("// %s", DEFAULT_APIS[i].dll);
            prev = DEFAULT_APIS[i].dll;
        }
        uint32_t h = A.fn(DEFAULT_APIS[i].api, seed);
        char line[160];
        snprintf(line, sizeof(line), "#define HASH_%-32s 0x%08Xu",
                 DEFAULT_APIS[i].api, h);
        Log("%s", line);
    }
    Log("");
    Log("// ── end of generated config.h ──");
}

// ═══════════════════════════════════════════════════════════════════════════
// 6. String XOR encryption preview
// ═══════════════════════════════════════════════════════════════════════════

static void UpdateKeyLabel() {
    std::string s = GetEditStr(g_hEdtSeed);
    uint8_t k = derive_xor_key(s.c_str());
    char buf[64];
    snprintf(buf, sizeof(buf), "ESTR_KEY = 0x%02X   (derived from seed)", k);
    SetWindowText(g_hLblKey, buf);
}

static void DoEncrypt() {
    std::string plain = GetEditStr(g_hEdtPlain);
    std::string seed  = GetEditStr(g_hEdtSeed);
    uint8_t key = derive_xor_key(seed.c_str());

    std::string hex;
    for (size_t i = 0; i < plain.size() + 1; i++) {
        uint8_t b = (uint8_t)((i < plain.size() ? (uint8_t)plain[i] : 0u)
                              ^ (uint8_t)(key + (uint8_t)i));
        char tmp[4]; sprintf(tmp, "%02X ", b);
        hex += tmp;
    }
    SetWindowText(g_hEdtCipher, hex.c_str());

    // Round-trip verify
    std::string dec;
    std::vector<uint8_t> cipher;
    for (size_t i = 0; i < plain.size() + 1; i++) {
        uint8_t b = (uint8_t)((i < plain.size() ? (uint8_t)plain[i] : 0u)
                              ^ (uint8_t)(key + (uint8_t)i));
        cipher.push_back(b);
    }
    for (size_t i = 0; i < cipher.size(); i++) {
        uint8_t d = (uint8_t)(cipher[i] ^ (uint8_t)(key + (uint8_t)i));
        if (d) dec += (char)d;
    }

    Log("──── XOR string encryption (strenc.h-style) ────");
    Log("  plain      : \"%s\"  (len=%zu)", plain.c_str(), plain.size());
    Log("  ESTR_KEY   : 0x%02X", key);
    Log("  algorithm  : enc[i] = plain[i] ^ (key + i)   // per-byte rolling key");
    Log("  cipher hex : %s", hex.c_str());
    Log("  round-trip : \"%s\"  %s", dec.c_str(),
        dec == plain ? "[OK]" : "[MISMATCH!]");
}

// ═══════════════════════════════════════════════════════════════════════════
// 6b. Imphash collision (Tab 3)
// ═══════════════════════════════════════════════════════════════════════════

struct ImpEntry { std::string dll, fn; };

// Parse multi-line text: each line "dll!func" or "dll.func" (lowercased on input).
// Comments starting with '#' and blank lines are skipped.
static std::vector<ImpEntry> parse_imports(const std::string& text) {
    std::vector<ImpEntry> out;
    std::stringstream ss(text);
    std::string line;
    while (std::getline(ss, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        // trim leading/trailing whitespace
        size_t a = line.find_first_not_of(" \t");
        size_t b = line.find_last_not_of(" \t");
        if (a == std::string::npos) continue;
        line = line.substr(a, b - a + 1);
        if (line.empty() || line[0] == '#') continue;

        // Prefer '!' as separator (unambiguous). Fall back to first '.'.
        size_t sep = line.find('!');
        if (sep == std::string::npos) sep = line.find('.');
        if (sep == std::string::npos || sep == 0 || sep + 1 >= line.size()) continue;

        ImpEntry e;
        e.dll = line.substr(0, sep);
        e.fn  = line.substr(sep + 1);
        for (auto& c : e.dll) c = (char)tolower((unsigned char)c);
        for (auto& c : e.fn)  c = (char)tolower((unsigned char)c);
        // Strip .dll/.sys/.ocx/.drv extension from DLL part
        size_t dot = e.dll.rfind('.');
        if (dot != std::string::npos) {
            std::string ext = e.dll.substr(dot);
            if (ext == ".dll" || ext == ".sys" || ext == ".ocx" || ext == ".drv")
                e.dll = e.dll.substr(0, dot);
        }
        if (!e.dll.empty() && !e.fn.empty()) out.push_back(std::move(e));
    }
    return out;
}

static std::string md5_hex(const void* data, size_t len) {
    BCRYPT_ALG_HANDLE hAlg = nullptr;
    if (BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_MD5_ALGORITHM, nullptr, 0) != 0) return "";
    DWORD hlen = 0, junk = 0;
    BCryptGetProperty(hAlg, BCRYPT_HASH_LENGTH, (PUCHAR)&hlen, sizeof(hlen), &junk, 0);
    BCRYPT_HASH_HANDLE hHash = nullptr;
    BCryptCreateHash(hAlg, &hHash, nullptr, 0, nullptr, 0, 0);
    BCryptHashData(hHash, (PUCHAR)data, (ULONG)len, 0);
    std::vector<UCHAR> out(hlen);
    BCryptFinishHash(hHash, out.data(), hlen, 0);
    BCryptDestroyHash(hHash);
    BCryptCloseAlgorithmProvider(hAlg, 0);
    std::string s; s.reserve(hlen * 2);
    for (DWORD i = 0; i < hlen; i++) { char b[3]; sprintf(b, "%02x", out[i]); s += b; }
    return s;
}

static std::string imphash_of(const std::vector<ImpEntry>& imports) {
    std::string s;
    for (auto& e : imports) {
        if (!s.empty()) s += ',';
        s += e.dll + '.' + e.fn;
    }
    return md5_hex(s.data(), s.size());
}

static void DoImpBaseCompute() {
    auto base = parse_imports(GetEditStr(g_hEdtImpBase));
    if (base.empty()) { Log("[!] Base imports empty or unparseable."); return; }
    std::string h = imphash_of(base);
    Log("──── Base imphash ────");
    Log("  parsed %zu imports", base.size());
    Log("  imphash = %s", h.c_str());
    char buf[256];
    snprintf(buf, sizeof(buf), "base imphash = %s   (%zu imports)",
             h.c_str(), base.size());
    SetWindowText(g_hLblImpRes, buf);
}

static void DoImpCollision() {
    auto base = parse_imports(GetEditStr(g_hEdtImpBase));
    auto cand = parse_imports(GetEditStr(g_hEdtImpCand));
    if (base.empty()) { Log("[!] Base imports empty."); return; }

    std::string base_h = imphash_of(base);
    Log("──── Imphash truncated-collision search ────");
    Log("  base imports   : %zu  ->  imphash %s", base.size(), base_h.c_str());
    Log("  candidate pool : %zu decoys", cand.size());

    std::string target = GetEditStr(g_hEdtImpTgt);
    for (auto& c : target) c = (char)tolower((unsigned char)c);
    if (target.size() >= 2 && target[0] == '0' && target[1] == 'x') target = target.substr(2);
    if (target.empty()) { Log("[!] Target prefix is empty."); return; }

    int idx = (int)SendMessage(g_hCmbImpLen, CB_GETCURSEL, 0, 0);
    if (idx < 0) idx = 2;
    int prefix_len = idx + 2;  // 2..16
    if (prefix_len > (int)target.size()) prefix_len = (int)target.size();
    std::string tgt = target.substr(0, prefix_len);
    Log("  target prefix  : %s  (%d hex chars = %d bits)",
        tgt.c_str(), prefix_len, prefix_len * 4);

    if (cand.empty()) {
        if (base_h.compare(0, prefix_len, tgt) == 0) {
            Log("  [+] base alone matches the target prefix.");
            SetWindowText(g_hLblImpRes, ("MATCH (base only) " + base_h).c_str());
        } else {
            Log("  [-] no match; provide some decoys to enable the search.");
            SetWindowText(g_hLblImpRes, "no match (no decoys provided)");
        }
        return;
    }

    int N = (int)cand.size();
    const int N_MAX = 24;
    if (N > N_MAX) {
        Log("[!] Candidate pool > %d entries (2^%d = %llu subsets); cap exceeded.",
            N_MAX, N_MAX, 1ULL << N_MAX);
        Log("    Trim the pool or accept truncated search by reordering.");
        N = N_MAX;
    }
    Log("  searching 2^%d = %llu subsets...", N, 1ULL << N);

    clock_t t0 = clock();
    uint64_t total = 1ULL << N;
    int best_len = 0;
    uint64_t best_mask = 0;

    for (uint64_t mask = 0; mask < total; mask++) {
        std::vector<ImpEntry> trial = base;
        for (int i = 0; i < N; i++)
            if (mask & (1ULL << i)) trial.push_back(cand[i]);
        std::string h = imphash_of(trial);

        if (h.compare(0, prefix_len, tgt) == 0) {
            double secs = (double)(clock() - t0) / CLOCKS_PER_SEC;
            Log("  [+] HIT after %llu subsets (%.3f s)",
                (unsigned long long)(mask + 1), secs);
            Log("      imphash    = %s", h.c_str());
            std::string sel;
            int picked = 0;
            for (int i = 0; i < N; i++) {
                if (mask & (1ULL << i)) {
                    if (!sel.empty()) sel += ", ";
                    sel += cand[i].dll + "!" + cand[i].fn;
                    picked++;
                }
            }
            Log("      decoy set  = { %s }", sel.empty() ? "(empty)" : sel.c_str());
            Log("      |decoys|   = %d", picked);
            char buf[256];
            snprintf(buf, sizeof(buf),
                "MATCH  %s   (+%d decoys, %.2f s)",
                h.c_str(), picked, secs);
            SetWindowText(g_hLblImpRes, buf);
            return;
        }

        // track best partial match for diagnostics
        int m = 0;
        while (m < prefix_len && h[m] == tgt[m]) m++;
        if (m > best_len) { best_len = m; best_mask = mask; }
    }
    double secs = (double)(clock() - t0) / CLOCKS_PER_SEC;
    Log("  [-] no exact match within budget (%.3f s)", secs);
    Log("      best partial: %d/%d chars (mask=0x%llx)",
        best_len, prefix_len, (unsigned long long)best_mask);
    char buf[256];
    snprintf(buf, sizeof(buf), "no exact match; best partial %d/%d hex chars",
             best_len, prefix_len);
    SetWindowText(g_hLblImpRes, buf);
}

// ═══════════════════════════════════════════════════════════════════════════
// 7. Tab switching — show/hide per-tab controls
// ═══════════════════════════════════════════════════════════════════════════

struct TabCtrls {
    std::vector<HWND> ctrls;
};
static TabCtrls g_tab_ctrls[4];

static void SwitchTab(int idx) {
    g_cur_tab = idx;
    for (int t = 0; t < 4; t++) {
        int show = (t == idx) ? SW_SHOW : SW_HIDE;
        for (auto& h : g_tab_ctrls[t].ctrls) ShowWindow(h, show);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 8. WM_CREATE
// ═══════════════════════════════════════════════════════════════════════════

static const char* DEFAULT_API_LIST =
    "MessageBoxA\r\n"
    "MessageBoxW\r\n"
    "VirtualAlloc\r\n"
    "VirtualAllocEx\r\n"
    "VirtualFree\r\n"
    "VirtualProtect\r\n"
    "OpenProcess\r\n"
    "CreateRemoteThread\r\n"
    "WriteProcessMemory\r\n"
    "GetProcAddress\r\n"
    "LoadLibraryA\r\n"
    "NtAllocateVirtualMemory";

static void OnCreate(HINSTANCE) {
    g_hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    g_hMono = CreateFont(14, 0, 0, 0, FW_NORMAL, 0, 0, 0,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN, "Consolas");

    int y = 8;
    MakeLabel("Seed string:", 8, y+4, 80);
    g_hEdtSeed = MakeCtl("EDIT", "RedTeam2024_Demo", ES_AUTOHSCROLL,
        WS_EX_CLIENTEDGE, 92, y, 240, 22, IDC_EDT_SEED);
    g_hLblSeedVal = MakeCtl("STATIC", "= 0x00000000", SS_SIMPLE, 0,
        342, y+4, 200, 18, IDC_LBL_SEED_VAL, g_hMono);
    MakeLabel("(folded via djb2; matches demo_iat str_to_seed)", 550, y+4, 320);
    y += 32;

    MakeLabel("API names (one per line)", 8, y, 200);
    MakeLabel("Hash matrix (all 6 algorithms × API names)", 400, y, 400);
    y += 18;

    g_hEdtApis = MakeCtl("EDIT", DEFAULT_API_LIST,
        ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 8, y, 380, 200, IDC_EDT_APIS, g_hMono);

    g_hLvMatrix = MakeCtl(WC_LISTVIEW, "",
        LVS_REPORT | LVS_SINGLESEL | LVS_NOSORTHEADER,
        WS_EX_CLIENTEDGE, 400, y, 472, 200, IDC_LV_MATRIX, g_hMono);
    ListView_SetExtendedListViewStyle(g_hLvMatrix, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    AddCol(g_hLvMatrix, 0, 130, "API");
    for (int i = 0; i < ALGO_N; i++) {
        char hdr[16]; snprintf(hdr, sizeof(hdr), "%s", ALGOS[i].name);
        AddCol(g_hLvMatrix, i + 1, 80, hdr);
    }
    y += 208;

    MakeBtn("Hash all",   IDC_BTN_HASH,  8,   y, 100);
    MakeBtn("Clear log",  IDC_BTN_CLEAR, 770, y, 100);
    y += 36;

    g_hTab = MakeCtl(WC_TABCONTROL, "", 0, 0, 8, y, 864, 28, IDC_TAB);
    static const char* TABS[] = {
        "Collision finder", "Export config.h", "String XOR preview", "Imphash collision"
    };
    for (int i = 0; i < 4; i++) {
        TCITEM ti{}; ti.mask = TCIF_TEXT; ti.pszText = const_cast<LPSTR>(TABS[i]);
        TabCtrl_InsertItem(g_hTab, i, &ti);
    }
    int tabY = y + 36;

    // ── Tab 0: Collision finder ───────────────────────────────────────────
    int yy = tabY;
    HWND h;
    h = MakeLabel("Target hash:", 16, yy+4, 90);                     g_tab_ctrls[0].ctrls.push_back(h);
    g_hEdtTarget = MakeCtl("EDIT", "0x9434B9C0", ES_AUTOHSCROLL,
        WS_EX_CLIENTEDGE, 110, yy, 140, 22, IDC_EDT_TARGET, g_hMono);
    g_tab_ctrls[0].ctrls.push_back(g_hEdtTarget);
    h = MakeLabel("Algorithm:", 270, yy+4, 70);                       g_tab_ctrls[0].ctrls.push_back(h);
    g_hCmbCollAlg = MakeCombo(IDC_CMB_COLL_ALG, 344, yy, 110, 200);
    for (int i = 0; i < ALGO_N; i++) SendMessage(g_hCmbCollAlg, CB_ADDSTRING, 0, (LPARAM)ALGOS[i].name);
    SendMessage(g_hCmbCollAlg, CB_SETCURSEL, 0, 0);
    g_tab_ctrls[0].ctrls.push_back(g_hCmbCollAlg);
    h = MakeLabel("Max length:", 472, yy+4, 80);                      g_tab_ctrls[0].ctrls.push_back(h);
    g_hCmbMaxLen = MakeCombo(IDC_CMB_MAXLEN, 556, yy, 50, 200);
    for (int i = 1; i <= 8; i++) {
        char b[4]; snprintf(b, sizeof(b), "%d", i);
        SendMessage(g_hCmbMaxLen, CB_ADDSTRING, 0, (LPARAM)b);
    }
    SendMessage(g_hCmbMaxLen, CB_SETCURSEL, 3, 0);   // default = 4
    g_tab_ctrls[0].ctrls.push_back(g_hCmbMaxLen);
    h = MakeLabel("Charset:", 624, yy+4, 60);                         g_tab_ctrls[0].ctrls.push_back(h);
    g_hCmbCharset = MakeCombo(IDC_CMB_CHARSET, 690, yy, 175, 200);
    for (int i = 0; i < 4; i++) SendMessage(g_hCmbCharset, CB_ADDSTRING, 0, (LPARAM)CHARSET_NAMES[i]);
    SendMessage(g_hCmbCharset, CB_SETCURSEL, 2, 0);   // alphanumeric
    g_tab_ctrls[0].ctrls.push_back(g_hCmbCharset);
    yy += 30;
    h = MakeBtn("Find collision", IDC_BTN_COLL, 16, yy, 130);          g_tab_ctrls[0].ctrls.push_back(h);
    g_hLblCollRes = MakeCtl("STATIC", "(no search yet)", SS_SIMPLE, 0,
        160, yy+4, 700, 20, IDC_LBL_COLL_RES, g_hMono);
    g_tab_ctrls[0].ctrls.push_back(g_hLblCollRes);
    yy += 30;
    h = MakeLabel(
        "Brute-force a printable string s.t. hash(s, seed) == target. "
        "Limit 50M attempts; pick length & charset to keep it tractable.",
        16, yy, 850);
    g_tab_ctrls[0].ctrls.push_back(h);

    // ── Tab 1: Export config.h ────────────────────────────────────────────
    yy = tabY;
    h = MakeLabel("Output algorithm:", 16, yy+4, 110);                g_tab_ctrls[1].ctrls.push_back(h);
    g_hCmbExpAlg = MakeCombo(IDC_CMB_EXP_ALG, 130, yy, 130, 200);
    for (int i = 0; i < ALGO_N; i++) SendMessage(g_hCmbExpAlg, CB_ADDSTRING, 0, (LPARAM)ALGOS[i].name);
    SendMessage(g_hCmbExpAlg, CB_SETCURSEL, 0, 0);
    g_tab_ctrls[1].ctrls.push_back(g_hCmbExpAlg);
    h = MakeBtn("Generate config.h", IDC_BTN_EXP, 280, yy, 150);      g_tab_ctrls[1].ctrls.push_back(h);
    yy += 30;
    h = MakeLabel(
        "Emits a drop-in config.h for demo_iat (same format as gen_config.py output). "
        "Result goes to the Log so you can copy it out.",
        16, yy, 850);
    g_tab_ctrls[1].ctrls.push_back(h);
    yy += 22;
    h = MakeLabel(
        "Picking an algorithm other than ROR-13 also requires editing api_hash() in hash.h.",
        16, yy, 850);
    g_tab_ctrls[1].ctrls.push_back(h);

    // ── Tab 2: String XOR preview ─────────────────────────────────────────
    yy = tabY;
    h = MakeLabel("Plain text:", 16, yy+4, 80);                       g_tab_ctrls[2].ctrls.push_back(h);
    g_hEdtPlain = MakeCtl("EDIT", "kernel32.dll", ES_AUTOHSCROLL,
        WS_EX_CLIENTEDGE, 100, yy, 280, 22, IDC_EDT_PLAIN, g_hMono);
    g_tab_ctrls[2].ctrls.push_back(g_hEdtPlain);
    h = MakeBtn("Encrypt", IDC_BTN_ENC, 400, yy, 90, 22);             g_tab_ctrls[2].ctrls.push_back(h);
    yy += 30;
    g_hLblKey = MakeCtl("STATIC", "ESTR_KEY = ?", SS_SIMPLE, 0,
        16, yy+4, 600, 18, IDC_LBL_KEY, g_hMono);
    g_tab_ctrls[2].ctrls.push_back(g_hLblKey);
    yy += 24;
    h = MakeLabel("Cipher (hex):", 16, yy+4, 90);                     g_tab_ctrls[2].ctrls.push_back(h);
    g_hEdtCipher = MakeCtl("EDIT", "", ES_AUTOHSCROLL | ES_READONLY,
        WS_EX_CLIENTEDGE, 110, yy, 750, 22, IDC_EDT_CIPHER, g_hMono);
    g_tab_ctrls[2].ctrls.push_back(g_hEdtCipher);
    yy += 30;
    h = MakeLabel(
        "Mirrors strenc.h: encrypted bytes go into .rdata; decryption happens "
        "on the stack via `enc[i] ^ (KEY + i)`. Changing the seed flips every byte.",
        16, yy, 850);
    g_tab_ctrls[2].ctrls.push_back(h);

    // ── Tab 3: Imphash collision ──────────────────────────────────────────
    yy = tabY;
    h = MakeLabel("Base imports (one 'dll!fn' per line):", 16, yy, 320);
        g_tab_ctrls[3].ctrls.push_back(h);
    h = MakeLabel("Decoy candidate pool (one 'dll!fn' per line):", 446, yy, 320);
        g_tab_ctrls[3].ctrls.push_back(h);
    yy += 18;
    static const char* DEFAULT_IMP_BASE =
        "kernel32!LoadLibraryA\r\n"
        "kernel32!GetProcAddress\r\n"
        "kernel32!ExitProcess\r\n"
        "user32!MessageBoxA\r\n";
    static const char* DEFAULT_IMP_CAND =
        "kernel32!Sleep\r\n"
        "kernel32!GetTickCount\r\n"
        "kernel32!GetCurrentProcessId\r\n"
        "kernel32!CloseHandle\r\n"
        "user32!SetTimer\r\n"
        "user32!GetCursorPos\r\n"
        "shlwapi!PathFindExtensionA\r\n"
        "msvcrt!atoi\r\n"
        "msvcrt!strlen\r\n"
        "msvcrt!malloc\r\n"
        "ws2_32!htons\r\n"
        "ws2_32!ntohl\r\n";
    g_hEdtImpBase = MakeCtl("EDIT", DEFAULT_IMP_BASE,
        ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 16, yy, 414, 60, IDC_EDT_IMP_BASE, g_hMono);
        g_tab_ctrls[3].ctrls.push_back(g_hEdtImpBase);
    g_hEdtImpCand = MakeCtl("EDIT", DEFAULT_IMP_CAND,
        ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 446, yy, 414, 60, IDC_EDT_IMP_CAND, g_hMono);
        g_tab_ctrls[3].ctrls.push_back(g_hEdtImpCand);
    yy += 66;

    h = MakeLabel("Target imphash:", 16, yy+4, 100);
        g_tab_ctrls[3].ctrls.push_back(h);
    g_hEdtImpTgt = MakeCtl("EDIT", "f6aa299a", ES_AUTOHSCROLL,
        WS_EX_CLIENTEDGE, 120, yy, 220, 22, IDC_EDT_IMP_TGT, g_hMono);
        g_tab_ctrls[3].ctrls.push_back(g_hEdtImpTgt);
    h = MakeLabel("Match first:", 356, yy+4, 80);
        g_tab_ctrls[3].ctrls.push_back(h);
    g_hCmbImpLen = MakeCombo(IDC_CMB_IMP_LEN, 436, yy, 80, 200);
    for (int i = 2; i <= 16; i++) {
        char b[16]; snprintf(b, sizeof(b), "%d chars", i);
        SendMessage(g_hCmbImpLen, CB_ADDSTRING, 0, (LPARAM)b);
    }
    SendMessage(g_hCmbImpLen, CB_SETCURSEL, 2, 0);  // default = 4 chars
        g_tab_ctrls[3].ctrls.push_back(g_hCmbImpLen);
    h = MakeBtn("Imphash(base)", IDC_BTN_IMP_BASE, 528, yy-2, 130, 24);
        g_tab_ctrls[3].ctrls.push_back(h);
    h = MakeBtn("Find collision", IDC_BTN_IMP_FIND, 668, yy-2, 130, 24);
        g_tab_ctrls[3].ctrls.push_back(h);
    yy += 30;
    g_hLblImpRes = MakeCtl("STATIC", "(no search yet)", SS_SIMPLE, 0,
        16, yy, 850, 18, IDC_LBL_IMP_RES, g_hMono);
        g_tab_ctrls[3].ctrls.push_back(g_hLblImpRes);

    y = tabY + 130;
    MakeLabel("Log:", 8, y, 60);
    y += 16;
    g_hLog = MakeCtl("EDIT", "",
        ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 8, y, 864, 110, IDC_LOG, g_hMono);

    // Initial state
    UpdateSeedLabel();
    UpdateKeyLabel();
    DoHashAll();
    SwitchTab(0);

    Log("API hashing lab — ready.");
    Log("• Edit API list on the left, click [Hash all] to refill the matrix.");
    Log("• Change the seed → matrix recomputes immediately on the next [Hash all].");
    Log("• Collision finder tab: brute-force a printable string that hits a target hash.");
    Log("• Export config.h tab: emit drop-in replacement for demo_iat's gen_config.py.");
    Log("• String XOR tab: preview strenc.h-style ciphertext bytes for any plaintext.");
}

// ═══════════════════════════════════════════════════════════════════════════
// 9. WndProc + WinMain
// ═══════════════════════════════════════════════════════════════════════════

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE:
        g_hwnd = hwnd;
        OnCreate(((CREATESTRUCT*)lp)->hInstance);
        return 0;

    case WM_NOTIFY: {
        LPNMHDR nmh = (LPNMHDR)lp;
        if (nmh->idFrom == IDC_TAB && nmh->code == TCN_SELCHANGE) {
            SwitchTab(TabCtrl_GetCurSel(g_hTab));
        }
        return 0;
    }

    case WM_COMMAND: {
        int id   = LOWORD(wp);
        int code = HIWORD(wp);
        if (id == IDC_EDT_SEED && code == EN_CHANGE) {
            UpdateSeedLabel();
            UpdateKeyLabel();
            return 0;
        }
        switch (id) {
        case IDC_BTN_HASH:     DoHashAll();        return 0;
        case IDC_BTN_COLL:     DoFindCollision();  return 0;
        case IDC_BTN_EXP:      DoExportConfig();   return 0;
        case IDC_BTN_ENC:      DoEncrypt();        return 0;
        case IDC_BTN_IMP_BASE: DoImpBaseCompute(); return 0;
        case IDC_BTN_IMP_FIND: DoImpCollision();   return 0;
        case IDC_BTN_CLEAR:    SetWindowText(g_hLog, ""); return 0;
        }
        return 0;
    }

    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)wp, TRANSPARENT);
        return (LRESULT)GetSysColorBrush(COLOR_3DFACE);

    case WM_DESTROY:
        if (g_hMono) DeleteObject(g_hMono);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nShow) {
    INITCOMMONCONTROLSEX icex = { sizeof(icex), ICC_LISTVIEW_CLASSES | ICC_TAB_CLASSES | ICC_STANDARD_CLASSES };
    InitCommonControlsEx(&icex);

    WNDCLASSEX wc = { sizeof(wc) };
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hbrBackground = (HBRUSH)(COLOR_3DFACE + 1);
    wc.lpszClassName = "HashLabWnd";
    wc.hIcon         = LoadIcon(nullptr, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassEx(&wc);

    RECT rc = { 0, 0, 888, 700 };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME|WS_MAXIMIZEBOX), FALSE);

    HWND hwnd = CreateWindowEx(0, "HashLabWnd",
        "API Hashing Algorithm Lab",
        WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME | WS_MAXIMIZEBOX),
        CW_USEDEFAULT, CW_USEDEFAULT,
        rc.right - rc.left, rc.bottom - rc.top,
        nullptr, nullptr, hInst, nullptr);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG m;
    while (GetMessage(&m, nullptr, 0, 0)) {
        TranslateMessage(&m);
        DispatchMessage(&m);
    }
    return (int)m.wParam;
}
