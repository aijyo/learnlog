# rename — PE 反指纹 demo 套件

四个 Win32 GUI/CLI demo,组成一条 **PE 抗静态指纹分析** 完整工具链:

| 工具 | 类型 | 作用 |
|---|---|---|
| `demo_iat` / `demo_iat_ui` | 编译期 | 让目标 API 不出现在 IAT 中(EAT-walk + 哈希解析 + XOR 字符串加密) |
| `patchtool` / `patchtool_ui` | 后处理 | 改写已编译 PE 的 6 类静态指纹字段(seed 驱动,可重复) |
| `pediff_ui` | 验证 | 对比两个 PE 的 MD5/SHA/imphash + header/section/imports/字节级 diff |
| `hashlab_ui` | 实验 | 6 种哈希算法矩阵 + 碰撞查找 + imphash 碰撞 + `config.h` 一键导出 |

技术细节、字节级原理、如何应用到其他 EXE → 见 **[TECHNICAL_DESIGN.md](TECHNICAL_DESIGN.md)**。

## 快速开始

### 先决条件

- Windows 10/11
- Visual Studio 2022 (Community / Professional) with C++ workload, **x64 toolchain**
- Python 3.7+ (driver for `gen_config.py`)
- CMake 3.20+(VS 2022 自带的 cmake 即可)

### 构建

```powershell
cd D:\code\work\research\rename
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target rename_all
```

完成后 6 个 EXE 全部输出到 `output\`:

```
output\
├── demo_iat.exe              CLI: IAT dynamicization
├── demo_iat_ui.exe           GUI 同上
├── patchtool.exe             CLI: PE metadata patcher
├── patchtool_ui.exe          GUI 同上
├── pediff_ui.exe             GUI: binary diff viewer
└── hashlab_ui.exe            GUI: hash algorithm lab
```

### 改 seed 重 roll 全部 API hash 常量

```powershell
cmake -B build -DSEED_STRING="MyNewSeed"
cmake --build build --config Release --target demo_iat_ui
```

`config.h` 会用新 seed 重新生成,所有 `HASH_*` 常量翻新一遍。

### 端到端验证流程

```powershell
# 1. 拿 demo_iat_ui.exe 当试验品(任何 PE 都行)
Copy-Item output\demo_iat_ui.exe D:\tmp\before.exe

# 2. patch 一次:打开全部 patch 包括 reorder-imports
output\patchtool.exe --seed "Variant-A" `
    --input  D:\tmp\before.exe `
    --output D:\tmp\after.exe `
    --reorder-imports --verbose

# 3. 用 pediff_ui 对比看 diff
output\pediff_ui.exe
#   File A: D:\tmp\before.exe
#   File B: D:\tmp\after.exe
#   → Compare
# 应看到: MD5/SHA-1/SHA-256/imphash 全 DIFF;
#         File.TimeDateStamp / 节名 / Opt.CheckSum DIFF;
#         Imports tab 全 SAME (功能未损)。
```

## 目录结构

```
rename/
├── CMakeLists.txt                  顶层 CMake 配置(/MT + 统一 output/)
├── README.md                       本文件
├── TECHNICAL_DESIGN.md             完整技术方案
├── output/                         构建产物(6 个 EXE)
├── build/                          CMake 中间产物
│
├── demo_iat/
│   ├── CMakeLists.txt
│   ├── gen_config.py               生成 config.h(API hash 常量 + XOR key)
│   ├── hash.h                      ROR-13 哈希(api_hash) + djb2 seed fold
│   ├── strenc.h                    编译期 XOR 字符串加密(ESTR_BUF)
│   ├── resolve.h                   运行期 EAT walk + 哈希匹配
│   ├── main.cpp                    CLI demo
│   └── demo_iat_ui.cpp             Win32 GUI demo
│
├── patchtool/
│   ├── CMakeLists.txt
│   ├── patchtool.cpp               CLI: --seed/--input/--output/--reorder-imports
│   └── patchtool_ui.cpp            Win32 GUI(Before/After 双面板)
│
├── pediff/
│   ├── CMakeLists.txt
│   └── pediff_ui.cpp               Win32 GUI(5 tab:Hashes/Headers/Sections/Regions/Imports)
│
└── hashlab/
    ├── CMakeLists.txt
    └── hashlab_ui.cpp              Win32 GUI(算法矩阵 + 4 tab 工具)
```

## 项目纪律

- 全部 EXE **`/MT` 静态链接 CRT**,只依赖系统 DLL(`KERNEL32.dll` / `USER32.dll` / `COMCTL32.dll` / `COMDLG32.dll` / `GDI32.dll` / `BCRYPT.dll`)。复制到任何无 VC 运行库的 Windows 机器都能直接跑。
- 全部源码自包含一个 `.cpp` 文件(`demo_iat` 例外:头文件 + main 拆分,因为有 Python 生成的 config.h 参与编译)。
- 静态分析期望:`dumpbin /IMPORTS demo_iat_ui.exe` 不应看到 `MessageBoxA` / `VirtualAlloc` / `GetSystemInfo` 等敏感名字。`demo_iat` 的 POST_BUILD 自动验证这一点。

## 限制 / 注意

- 这套工具改的是 **PE 静态指纹**。运行时行为没动——`VirtualAlloc + WriteProcessMemory + CreateRemoteThread` 的注入链一旦真执行,行为级 EDR 仍会告警。
- `imphash` 通过 reorder-imports 可改,但 `authentihash` 不动(它本来就是签过的 PE 才有意义,我们这套清掉签名了)。
- `demo_iat` 现在是 **Level 4 实现**:`find_module_by_hash` 走 PEB.InMemoryOrderModuleList,**不再依赖 `GetModuleHandleA` / `LoadLibraryA` 在 IAT 里**。`resolve.h` 也处理 forwarder(`KERNEL32.LoadLibraryA → KERNELBASE.LoadLibraryA` 这种递归走目标 DLL 再 EAT walk)。
- CMake build 后 `verify_iat.cmd` 自动 POST_BUILD 审计,确保我们能控制的敏感 API(`MessageBoxA` / `VirtualAlloc` / `CreateRemoteThread` 等)不在 IAT。CRT 自己拉的 import(`GetProcAddress` / `VirtualProtect` / `*W` 变体)是不可避免的内部用,显式从审计排除。

详见 [TECHNICAL_DESIGN.md 第 7 节 "限制和已知问题"](TECHNICAL_DESIGN.md#7-限制和已知问题)。
