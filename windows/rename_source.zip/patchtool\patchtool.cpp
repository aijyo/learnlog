/*
 * patchtool.cpp  —  PE Characteristic Patcher (standalone, single file)
 * ─────────────────────────────────────────────────────────────────────────────
 * Modifies PE metadata to change static fingerprints WITHOUT breaking execution.
 *
 * Modifications applied (all controlled by --seed):
 *   1. Clear Rich Header         — removes compiler/linker version fingerprint
 *   2. Patch TimeDateStamp       — seed-derived plausible epoch value
 *   3. Rename Sections           — seed-derived pronounceable names
 *   4. Clear Debug Directory     — removes embedded PDB path & CV record
 *   5. Clear Authenticode Sig    — removes digital signature block
 *   6. Recalculate Checksum      — always done last to keep PE valid
 *
 * Build (MSVC Developer Prompt):
 *   cl /nologo /MT /O2 /std:c++17 /W3 /EHsc patchtool.cpp /link /out:patchtool.exe
 *
 * Usage:
 *   patchtool.exe --seed <string> --input <exe> [--output <exe>] [--verbose] [--dry-run]
 *
 * Examples:
 *   patchtool.exe --seed "AlphaConfig" --input release.exe --output patched.exe --verbose
 *   patchtool.exe --seed "AlphaConfig" --input release.exe --dry-run
 *
 * Verify result:
 *   dumpbin /HEADERS patched.exe
 *   sigcheck -a patched.exe
 *   dumpbin /DEPENDENTS patched.exe   (execution must be unaffected)
 */

#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cassert>
#include <vector>
#include <string>

// ─── PE context ───────────────────────────────────────────────────────────────
//
// Supports both 32-bit and 64-bit PE.
// FileHeader is at the same offset in both; OptionalHeader differs.

struct PeCtx {
    std::vector<uint8_t> data;

    IMAGE_DOS_HEADER*     dos     = nullptr;
    IMAGE_FILE_HEADER*    fhdr    = nullptr;  // always valid
    IMAGE_SECTION_HEADER* sects   = nullptr;
    uint16_t              nsects  = 0;
    bool                  is64    = false;

    // ── OptionalHeader field accessors ──────────────────────────────────────

    IMAGE_DATA_DIRECTORY& datadir(int idx) {
        if (is64)
            return ((IMAGE_NT_HEADERS64*)(data.data() + dos->e_lfanew))
                       ->OptionalHeader.DataDirectory[idx];
        return ((IMAGE_NT_HEADERS32*)(data.data() + dos->e_lfanew))
                   ->OptionalHeader.DataDirectory[idx];
    }

    DWORD& checksum() {
        if (is64)
            return ((IMAGE_NT_HEADERS64*)(data.data() + dos->e_lfanew))
                       ->OptionalHeader.CheckSum;
        return ((IMAGE_NT_HEADERS32*)(data.data() + dos->e_lfanew))
                   ->OptionalHeader.CheckSum;
    }

    WORD optional_magic() {
        // OptionalHeader.Magic is at the same location for both 32/64
        return ((IMAGE_NT_HEADERS32*)(data.data() + dos->e_lfanew))
                   ->OptionalHeader.Magic;
    }

    // ── RVA helpers ──────────────────────────────────────────────────────────

    // Returns 0 when not found (file offset 0 is the DOS header, always valid
    // for our purposes since we never need offset 0 from a section).
    uint32_t rva_to_off(uint32_t rva) const {
        for (uint16_t i = 0; i < nsects; i++) {
            const auto& s = sects[i];
            if (rva >= s.VirtualAddress &&
                rva <  s.VirtualAddress + s.SizeOfRawData &&
                s.SizeOfRawData > 0) {
                return s.PointerToRawData + (rva - s.VirtualAddress);
            }
        }
        return 0;
    }

    uint8_t* at_rva(uint32_t rva) {
        uint32_t off = rva_to_off(rva);
        return (off && off < data.size()) ? data.data() + off : nullptr;
    }

    uint8_t* at_off(uint32_t off) {
        return (off < data.size()) ? data.data() + off : nullptr;
    }
};

// ─── PE parse ─────────────────────────────────────────────────────────────────

static bool parse_pe(PeCtx& ctx) {
    if (ctx.data.size() < sizeof(IMAGE_DOS_HEADER)) return false;

    ctx.dos = reinterpret_cast<IMAGE_DOS_HEADER*>(ctx.data.data());
    if (ctx.dos->e_magic != IMAGE_DOS_SIGNATURE) {
        fprintf(stderr, "[-] Not a DOS PE (bad MZ magic)\n");
        return false;
    }

    if ((size_t)ctx.dos->e_lfanew + sizeof(IMAGE_NT_HEADERS32) > ctx.data.size()) {
        fprintf(stderr, "[-] e_lfanew out of bounds\n");
        return false;
    }

    auto* sig = reinterpret_cast<DWORD*>(ctx.data.data() + ctx.dos->e_lfanew);
    if (*sig != IMAGE_NT_SIGNATURE) {
        fprintf(stderr, "[-] Not a valid PE (bad NT signature)\n");
        return false;
    }

    ctx.fhdr = reinterpret_cast<IMAGE_FILE_HEADER*>(
        ctx.data.data() + ctx.dos->e_lfanew + sizeof(DWORD));

    ctx.nsects = ctx.fhdr->NumberOfSections;
    ctx.is64   = (ctx.fhdr->Machine == IMAGE_FILE_MACHINE_AMD64);
    ctx.sects  = IMAGE_FIRST_SECTION(
        reinterpret_cast<IMAGE_NT_HEADERS*>(ctx.data.data() + ctx.dos->e_lfanew));

    WORD magic = ctx.optional_magic();
    if (magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC &&
        magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) {
        fprintf(stderr, "[-] Unexpected OptionalHeader magic: 0x%04X\n", magic);
        return false;
    }

    return true;
}

// ─── Seed utilities ───────────────────────────────────────────────────────────

static uint32_t seed_from_str(const char* s) {
    uint32_t h = 5381u;
    while (*s) h = ((h << 5) + h) ^ (uint8_t)*s++;
    return h;
}

static uint32_t lcg(uint32_t& state) {
    state = state * 1664525u + 1013904223u;
    return state;
}

// ─── Step 1: Clear Rich Header ────────────────────────────────────────────────

static void step_rich_header(PeCtx& ctx, bool verbose) {
    uint8_t* base       = ctx.data.data();
    uint32_t search_end = ctx.dos->e_lfanew;

    // Rich header (if present) starts at an aligned offset after the DOS stub
    // and ends with the 8-byte "Rich" + XOR-key marker.
    //
    // Memory layout:
    //   [DOS stub params | ... DanS XOR'd entries ... | Rich | XOR_key | PE sig]
    //
    // "Rich" == 0x68636952 LE
    static const uint32_t RICH_TAG = 0x68636952u;

    for (uint32_t i = 0x40u; i + 8u <= search_end; i += 4) {
        if (*reinterpret_cast<uint32_t*>(base + i) != RICH_TAG) continue;

        uint32_t xor_key = *reinterpret_cast<uint32_t*>(base + i + 4u);
        // "DanS" XOR'd with xor_key marks the start
        uint32_t dans_xord = 0x536e6144u ^ xor_key;

        uint32_t start = 0x40u;
        for (uint32_t j = 0x40u; j < i; j += 4) {
            if (*reinterpret_cast<uint32_t*>(base + j) == dans_xord) {
                start = j;
                break;
            }
        }

        uint32_t end_off = i + 8u;  // past "Rich" + key
        uint32_t span    = end_off - start;
        memset(base + start, 0, span);

        if (verbose)
            printf("  [+] Rich Header: offset=0x%04X  size=%u bytes  xor_key=0x%08X\n",
                   start, span, xor_key);
        return;
    }

    if (verbose) printf("  [~] Rich Header: not found (may have been stripped already)\n");
}

// ─── Step 2: Patch TimeDateStamp ─────────────────────────────────────────────

static void step_timestamp(PeCtx& ctx, uint32_t seed, bool verbose) {
    uint32_t old_ts = ctx.fhdr->TimeDateStamp;

    // Map seed into a plausible range: 2010-01-01 to 2023-12-31
    // Unix: 1262304000 .. 1703980800  (range ≈ 441676800 seconds)
    constexpr uint32_t BASE = 1262304000u;
    constexpr uint32_t SPAN = 441676800u;
    uint32_t new_ts = BASE + (seed % SPAN);
    ctx.fhdr->TimeDateStamp = new_ts;

    if (verbose)
        printf("  [+] TimeDateStamp: 0x%08X (%u) -> 0x%08X (%u)\n",
               old_ts, old_ts, new_ts, new_ts);
}

// ─── Step 3: Rename sections ──────────────────────────────────────────────────
//
// Names are seed-derived, pronounceable 4-char identifiers with a leading dot.
// Changing the seed produces completely different section names.

static void step_rename_sections(PeCtx& ctx, uint32_t seed, bool verbose) {
    static const char CONS[] = "bcdfghjklmnpqrstvwxz";  // 20 consonants
    static const char VOWL[] = "aeiou";                  // 5 vowels

    uint32_t rng = seed ^ 0xDEADC0DEu;

    for (uint16_t i = 0; i < ctx.nsects; i++) {
        char old_name[9] = {};
        memcpy(old_name, ctx.sects[i].Name, 8);

        uint32_t r = lcg(rng);
        char new_name[9] = {};
        new_name[0] = '.';
        new_name[1] = CONS[(r      ) % 20];
        new_name[2] = VOWL[(r >>  8) % 5 ];
        new_name[3] = CONS[(r >> 16) % 20];
        new_name[4] = VOWL[(r >> 24) % 5 ];

        memset(ctx.sects[i].Name, 0, 8);
        memcpy(ctx.sects[i].Name, new_name, strlen(new_name));

        if (verbose)
            printf("  [+] Section %2u: %-8s -> %-8s  "
                   "VA=0x%08X  raw_off=0x%08X\n",
                   i, old_name, new_name,
                   ctx.sects[i].VirtualAddress,
                   ctx.sects[i].PointerToRawData);
    }
}

// ─── Step 3b: Reorder Import Descriptors  (changes imphash) ─────────────────
//
// pefile (and VirusTotal's imphash) iterate IMAGE_IMPORT_DESCRIPTOR in file
// order. Shuffling that order changes the comma-joined "dll.fn" string fed
// into MD5 → different imphash, same imports, same runtime behavior.
// Each descriptor's OFT/FT RVAs are self-referential so the IAT slots
// referenced by compiled code stay put.

static void step_reorder_imports(PeCtx& ctx, uint32_t seed, bool verbose) {
    auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_IMPORT);
    if (!dd.VirtualAddress) {
        if (verbose) printf("  [~] Import Directory: not present\n");
        return;
    }
    uint8_t* p = ctx.at_rva(dd.VirtualAddress);
    if (!p) {
        if (verbose) printf("  [!] Import Directory: RVA unmapped\n");
        return;
    }
    auto* imp = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(p);
    int n = 0;
    while (imp[n].Name) n++;
    if (n < 2) {
        if (verbose) printf("  [~] Import Directory: %d entry; nothing to reorder\n", n);
        return;
    }

    uint32_t rng = seed ^ 0xCAFEBABEu;
    int swaps = 0;
    for (int i = n - 1; i > 0; i--) {
        uint32_t r = lcg(rng);
        int j = (int)(r % (uint32_t)(i + 1));
        if (i != j) {
            IMAGE_IMPORT_DESCRIPTOR t = imp[i]; imp[i] = imp[j]; imp[j] = t;
            swaps++;
        }
    }
    if (verbose)
        printf("  [+] Import Descriptors: %d entries, %d swaps -> imphash changed\n",
               n, swaps);
}

// ─── Step 4: Clear Debug Directory ───────────────────────────────────────────
//
// Zeros the raw data pointed to by each IMAGE_DEBUG_DIRECTORY entry
// (typically contains a RSDS/NB10 record with the PDB path and GUID).
// Then clears the PointerToRawData fields so nothing points to the zeroed area.

static void step_debug_dir(PeCtx& ctx, bool verbose) {
    auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_DEBUG);
    if (!dd.VirtualAddress || !dd.Size) {
        if (verbose) printf("  [~] Debug Directory: not present\n");
        return;
    }

    uint8_t* p = ctx.at_rva(dd.VirtualAddress);
    if (!p) {
        if (verbose) printf("  [!] Debug Directory: RVA not mapped\n");
        return;
    }

    DWORD count   = dd.Size / sizeof(IMAGE_DEBUG_DIRECTORY);
    auto* entries = reinterpret_cast<IMAGE_DEBUG_DIRECTORY*>(p);
    DWORD cleared = 0;

    for (DWORD j = 0; j < count; j++) {
        uint32_t raw_off = entries[j].PointerToRawData;
        uint32_t raw_sz  = entries[j].SizeOfData;

        if (verbose)
            printf("  [+] Debug entry %u: type=%u  raw_off=0x%X  size=%u\n",
                   j, entries[j].Type, raw_off, raw_sz);

        if (raw_off && raw_sz && (raw_off + raw_sz) <= ctx.data.size()) {
            memset(ctx.data.data() + raw_off, 0, raw_sz);
            cleared++;
        }
        entries[j].PointerToRawData = 0;
        entries[j].AddressOfRawData = 0;
        entries[j].SizeOfData       = 0;
    }

    if (verbose)
        printf("  [+] Debug Directory: %lu entries cleared\n", (unsigned long)count);
}

// ─── Step 5: Clear Authenticode signature ────────────────────────────────────
//
// Security directory uses a FILE OFFSET (not an RVA) per the PE spec.
// We zero the PKCS#7 blob and clear the directory entry.

static void step_signature(PeCtx& ctx, bool verbose) {
    auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_SECURITY);
    if (!dd.VirtualAddress || !dd.Size) {
        if (verbose) printf("  [~] Authenticode: not present\n");
        return;
    }

    uint32_t file_off = dd.VirtualAddress;  // this IS a file offset for security dir
    uint32_t size     = dd.Size;

    if (file_off + size > ctx.data.size()) {
        fprintf(stderr, "  [!] Signature dir out of file bounds (off=0x%X sz=%u)\n",
                file_off, size);
        dd.VirtualAddress = 0;
        dd.Size = 0;
        return;
    }

    memset(ctx.data.data() + file_off, 0, size);
    dd.VirtualAddress = 0;
    dd.Size           = 0;

    if (verbose)
        printf("  [+] Authenticode: zeroed %u bytes at file offset 0x%X\n",
               size, file_off);
}

// ─── Step 6: Recalculate PE Checksum ─────────────────────────────────────────
//
// Algorithm per Microsoft PE spec and Wine's implementation:
//   sum = 0
//   for each 16-bit word in file (checksum field zeroed):
//       sum += word
//       if (sum >> 16) fold carry
//   final fold
//   checksum = low16(sum) + file_size

static void step_checksum(PeCtx& ctx, bool verbose) {
    uint32_t old_cksum = ctx.checksum();
    ctx.checksum() = 0;  // zero field before computing

    const uint8_t* data   = ctx.data.data();
    size_t         size   = ctx.data.size();
    uint32_t       sum    = 0;

    const uint16_t* words = reinterpret_cast<const uint16_t*>(data);
    size_t          wlen  = size / 2;

    for (size_t i = 0; i < wlen; i++) {
        sum += words[i];
        if (sum >> 16) sum = (sum & 0xFFFFu) + (sum >> 16);
    }
    // Odd trailing byte
    if (size & 1) {
        sum += data[size - 1];
        if (sum >> 16) sum = (sum & 0xFFFFu) + (sum >> 16);
    }

    // Final fold and add file size
    sum = (sum >> 16) + (sum & 0xFFFFu);
    sum += (uint32_t)size;

    ctx.checksum() = sum;

    if (verbose)
        printf("  [+] Checksum: 0x%08X -> 0x%08X\n", old_cksum, sum);
}

// ─── Print PE summary ─────────────────────────────────────────────────────────

static void print_summary(PeCtx& ctx, const char* label) {
    printf("  ── %s ──\n", label);
    printf("  Arch         : %s  (%s)\n",
           ctx.is64 ? "x64" : "x86",
           ctx.is64 ? "PE32+" : "PE32");
    printf("  Sections     : %u\n", ctx.nsects);
    printf("  TimeDateStamp: 0x%08X\n", ctx.fhdr->TimeDateStamp);
    printf("  Checksum     : 0x%08X\n", ctx.checksum());

    // Signature present?
    auto& sec_dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_SECURITY);
    printf("  Signature    : %s\n", sec_dd.VirtualAddress ? "present" : "none");

    // Debug dir present?
    auto& dbg_dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_DEBUG);
    printf("  Debug dir    : %s\n", dbg_dd.VirtualAddress ? "present" : "none");

    // Section listing
    for (uint16_t i = 0; i < ctx.nsects; i++) {
        char name[9] = {};
        memcpy(name, ctx.sects[i].Name, 8);
        printf("    [%2u] %-8s  VA=0x%08X  raw=0x%08X  sz=%u\n",
               i, name,
               ctx.sects[i].VirtualAddress,
               ctx.sects[i].PointerToRawData,
               ctx.sects[i].SizeOfRawData);
    }
}

// ─── File I/O ─────────────────────────────────────────────────────────────────

static bool load_file(const char* path, std::vector<uint8_t>& buf) {
    FILE* f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "[-] Cannot open: %s\n", path); return false; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    rewind(f);
    if (sz <= 0) { fclose(f); fprintf(stderr, "[-] Empty file\n"); return false; }
    buf.resize((size_t)sz);
    bool ok = fread(buf.data(), 1, (size_t)sz, f) == (size_t)sz;
    fclose(f);
    if (!ok) fprintf(stderr, "[-] Read error: %s\n", path);
    return ok;
}

static bool save_file(const char* path, const std::vector<uint8_t>& buf) {
    FILE* f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "[-] Cannot write: %s\n", path); return false; }
    bool ok = fwrite(buf.data(), 1, buf.size(), f) == buf.size();
    fclose(f);
    if (!ok) fprintf(stderr, "[-] Write error: %s\n", path);
    return ok;
}

// ─── Usage ────────────────────────────────────────────────────────────────────

static void usage(const char* prog) {
    fprintf(stderr,
        "\nUsage:\n"
        "  %s --seed <string> --input <in.exe> [--output <out.exe>]\n"
        "       [--verbose] [--dry-run] [--skip-sections] [--skip-timestamp]\n"
        "\nOptions:\n"
        "  --seed <str>        Configuration string (all mods derived from this)\n"
        "  --input <path>      Input PE file\n"
        "  --output <path>     Output PE file (default: patched_<input filename>)\n"
        "  --verbose           Per-step detail\n"
        "  --dry-run           Parse and show PE info only; write nothing\n"
        "  --skip-sections     Do not rename sections\n"
        "  --skip-timestamp    Do not modify TimeDateStamp\n"
        "  --reorder-imports   Shuffle IMAGE_IMPORT_DESCRIPTOR order (changes imphash)\n"
        "\nModifications (all non-breaking):\n"
        "  1. Clear Rich Header      (compiler/linker fingerprint)\n"
        "  2. Patch TimeDateStamp    (seed-derived epoch)\n"
        "  3. Rename Sections        (seed-derived names, e.g. .text -> .bovu)\n"
        "  4. Clear Debug Directory  (PDB path, CV GUID)\n"
        "  5. Clear Authenticode     (signature block, file offset)\n"
        "  6. Recalculate Checksum   (always last)\n"
        "\nExamples:\n"
        "  %s --seed AlphaConfig --input release.exe --output patched.exe --verbose\n"
        "  %s --seed AlphaConfig --input release.exe --dry-run\n",
        prog, prog, prog);
}

// ─── Main ─────────────────────────────────────────────────────────────────────

int main(int argc, char** argv) {
    // ── Parse arguments ──────────────────────────────────────────────────────
    const char* opt_seed         = nullptr;
    const char* opt_input        = nullptr;
    const char* opt_output       = nullptr;
    bool        opt_verbose      = false;
    bool        opt_dry_run      = false;
    bool        opt_skip_sects   = false;
    bool        opt_skip_ts      = false;
    bool        opt_reorder_imp  = false;

    for (int i = 1; i < argc; i++) {
        if      (!strcmp(argv[i], "--seed")          && i+1 < argc) opt_seed        = argv[++i];
        else if (!strcmp(argv[i], "--input")         && i+1 < argc) opt_input       = argv[++i];
        else if (!strcmp(argv[i], "--output")        && i+1 < argc) opt_output      = argv[++i];
        else if (!strcmp(argv[i], "--verbose"))                      opt_verbose     = true;
        else if (!strcmp(argv[i], "--dry-run"))                      opt_dry_run     = true;
        else if (!strcmp(argv[i], "--skip-sections"))                opt_skip_sects  = true;
        else if (!strcmp(argv[i], "--skip-timestamp"))               opt_skip_ts     = true;
        else if (!strcmp(argv[i], "--reorder-imports"))              opt_reorder_imp = true;
        else {
            fprintf(stderr, "[-] Unknown option: %s\n", argv[i]);
            usage(argv[0]);
            return 1;
        }
    }

    if (!opt_seed || !opt_input) { usage(argv[0]); return 1; }

    // Default output path
    std::string out_path;
    if (opt_output) {
        out_path = opt_output;
    } else {
        // Insert "patched_" before the filename
        std::string inp(opt_input);
        size_t sep = inp.find_last_of("/\\");
        if (sep == std::string::npos) {
            out_path = "patched_" + inp;
        } else {
            out_path = inp.substr(0, sep + 1) + "patched_" + inp.substr(sep + 1);
        }
    }

    // ── Banner ───────────────────────────────────────────────────────────────
    printf("╔══════════════════════════════════════════════════╗\n");
    printf("║          PE Characteristic Patcher              ║\n");
    printf("╚══════════════════════════════════════════════════╝\n");

    uint32_t seed = seed_from_str(opt_seed);
    printf("\nSeed string : \"%s\"\n", opt_seed);
    printf("Seed value  : 0x%08X\n",  seed);
    printf("Input       : %s\n",       opt_input);
    if (!opt_dry_run) printf("Output      : %s\n", out_path.c_str());
    else              printf("Mode        : dry-run (no output written)\n");
    printf("\n");

    // ── Load & parse ─────────────────────────────────────────────────────────
    PeCtx ctx;
    if (!load_file(opt_input, ctx.data)) return 1;
    if (!parse_pe(ctx)) return 1;

    printf("══ BEFORE ═══════════════════════════════════════════\n");
    print_summary(ctx, "original");
    printf("\n");

    if (opt_dry_run) {
        printf("[dry-run] No modifications made.\n");
        return 0;
    }

    // ── Apply patches ─────────────────────────────────────────────────────────
    printf("══ PATCHING ════════════════════════════════════════\n");

    if (opt_verbose) printf(" [1] Rich Header\n");
    step_rich_header(ctx, opt_verbose);

    if (!opt_skip_ts) {
        if (opt_verbose) printf(" [2] TimeDateStamp\n");
        step_timestamp(ctx, seed, opt_verbose);
    } else {
        if (opt_verbose) printf(" [2] TimeDateStamp — skipped\n");
    }

    if (!opt_skip_sects) {
        if (opt_verbose) printf(" [3] Section Names\n");
        step_rename_sections(ctx, seed, opt_verbose);
    } else {
        if (opt_verbose) printf(" [3] Section Names — skipped\n");
    }

    if (opt_reorder_imp) {
        if (opt_verbose) printf(" [3b] Reorder Import Descriptors\n");
        step_reorder_imports(ctx, seed, opt_verbose);
    }

    if (opt_verbose) printf(" [4] Debug Directory\n");
    step_debug_dir(ctx, opt_verbose);

    if (opt_verbose) printf(" [5] Authenticode Signature\n");
    step_signature(ctx, opt_verbose);

    if (opt_verbose) printf(" [6] Checksum\n");
    step_checksum(ctx, opt_verbose);

    printf("\n══ AFTER ════════════════════════════════════════════\n");
    print_summary(ctx, "patched");
    printf("\n");

    // ── Save ─────────────────────────────────────────────────────────────────
    if (!save_file(out_path.c_str(), ctx.data)) return 1;

    printf("══ RESULT ══════════════════════════════════════════\n");
    printf("Saved   : %s  (%zu bytes)\n\n", out_path.c_str(), ctx.data.size());
    printf("Verify with:\n");
    printf("  dumpbin /HEADERS  \"%s\"\n", out_path.c_str());
    printf("  dumpbin /IMPORTS  \"%s\"   (imports must be unchanged)\n", out_path.c_str());
    printf("  sigcheck -a       \"%s\"\n", out_path.c_str());
    printf("\nChange the seed string to produce a completely different binary:\n");
    printf("  patchtool.exe --seed BetaConfig --input %s --output v2.exe\n",
           opt_input);

    return 0;
}
