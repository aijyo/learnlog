@echo off
:: build.bat — pediff GUI build
:: Run from VS Developer Command Prompt (cl.exe in PATH)

echo.
echo ============================================
echo   pediff_ui build
echo ============================================

echo.
echo [1/2] Building pediff_ui.exe (Win32 GUI)...
cl /nologo /MT /O2 /std:c++17 /W3 /EHsc ^
   pediff_ui.cpp ^
   comctl32.lib comdlg32.lib bcrypt.lib user32.lib gdi32.lib ^
   /link /subsystem:windows /out:pediff_ui.exe
if errorlevel 1 ( echo [-] build failed & exit /b 1 )
echo [+] pediff_ui.exe

echo.
echo [2/2] Dependencies:
dumpbin /DEPENDENTS pediff_ui.exe | findstr ".dll"

echo.
echo ============================================
echo   Run: pediff_ui.exe
echo   Pair with patchtool_ui:
echo     1) patchtool_ui — generate patched.exe from some target
echo     2) pediff_ui    — Compare original.exe vs patched.exe
echo ============================================
