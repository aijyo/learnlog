/*
 * pediff_ui.cpp  —  PE Binary Diff Viewer  (Win32 GUI, standalone)
 * ─────────────────────────────────────────────────────────────────────────────
 * Companion to patchtool — verifies what actually changed between two PE files.
 *
 * UI:
 *   ① File A / File B path input + Browse buttons + Compare button
 *   ② Summary panel (sizes, deltas, diff counts)
 *   ③ Tab control with 5 views:
 *        [Hashes]    MD5 / SHA-1 / SHA-256 / imphash (side by side)
 *        [Headers]   DOS / File / Optional / DataDir field diff
 *        [Sections]  Per-section comparison
 *        [Regions]   Byte-level diff regions (offset, size, before/after bytes)
 *        [Imports]   IAT-level diff (DLL.function entries added/removed/kept)
 *   ④ Log
 *
 *   DIFF rows painted red (NM_CUSTOMDRAW), SAME rows green.
 *
 * Build (x64 VS Developer Command Prompt):
 *   cl /nologo /MT /O2 /std:c++17 /W3 /EHsc pediff_ui.cpp ^
 *      comctl32.lib comdlg32.lib bcrypt.lib ^
 *      /link /subsystem:windows /out:pediff_ui.exe
 */

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <bcrypt.h>
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdarg>
#include <cctype>
#include <algorithm>
#include <string>
#include <vector>
#include <utility>

// ═══════════════════════════════════════════════════════════════════════════
// 1. PE context (read-only)
// ═══════════════════════════════════════════════════════════════════════════

struct PeCtx {
    std::vector<uint8_t>  data;
    IMAGE_DOS_HEADER*     dos    = nullptr;
    IMAGE_FILE_HEADER*    fhdr   = nullptr;
    IMAGE_SECTION_HEADER* sects  = nullptr;
    uint16_t              nsects = 0;
    bool                  is64   = false;
    bool                  valid  = false;

    const IMAGE_DATA_DIRECTORY& datadir(int i) const {
        if (is64) return ((const IMAGE_NT_HEADERS64*)(data.data()+dos->e_lfanew))->OptionalHeader.DataDirectory[i];
        return     ((const IMAGE_NT_HEADERS32*)(data.data()+dos->e_lfanew))->OptionalHeader.DataDirectory[i];
    }
    uint32_t rva_to_off(uint32_t rva) const {
        for (uint16_t i = 0; i < nsects; i++) {
            const auto& s = sects[i];
            if (rva >= s.VirtualAddress &&
                rva <  s.VirtualAddress + s.SizeOfRawData && s.SizeOfRawData)
                return s.PointerToRawData + (rva - s.VirtualAddress);
        }
        return 0;
    }
    const uint8_t* at_rva(uint32_t rva) const {
        uint32_t o = rva_to_off(rva);
        return (o && o < data.size()) ? data.data()+o : nullptr;
    }
    int section_of_offset(uint32_t off) const {
        for (uint16_t i = 0; i < nsects; i++) {
            const auto& s = sects[i];
            if (s.SizeOfRawData && off >= s.PointerToRawData &&
                off <  s.PointerToRawData + s.SizeOfRawData) return (int)i;
        }
        uint32_t first_raw = UINT32_MAX;
        for (uint16_t i = 0; i < nsects; i++)
            if (sects[i].SizeOfRawData && sects[i].PointerToRawData < first_raw)
                first_raw = sects[i].PointerToRawData;
        if (off < first_raw) return -1;   // header region
        return -2;                         // beyond last section
    }
};

static bool pe_load(const char* path, PeCtx& ctx) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    rewind(f);
    if (sz < (long)sizeof(IMAGE_DOS_HEADER)) { fclose(f); return false; }
    ctx.data.resize((size_t)sz);
    bool ok = fread(ctx.data.data(), 1, (size_t)sz, f) == (size_t)sz;
    fclose(f);
    if (!ok) return false;
    ctx.dos = (IMAGE_DOS_HEADER*)ctx.data.data();
    if (ctx.dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    if ((size_t)ctx.dos->e_lfanew + sizeof(IMAGE_NT_HEADERS32) > ctx.data.size()) return false;
    DWORD sig = *(DWORD*)(ctx.data.data() + ctx.dos->e_lfanew);
    if (sig != IMAGE_NT_SIGNATURE) return false;
    ctx.fhdr   = (IMAGE_FILE_HEADER*)(ctx.data.data() + ctx.dos->e_lfanew + sizeof(DWORD));
    ctx.nsects = ctx.fhdr->NumberOfSections;
    ctx.is64   = (ctx.fhdr->Machine == IMAGE_FILE_MACHINE_AMD64);
    ctx.sects  = IMAGE_FIRST_SECTION((IMAGE_NT_HEADERS*)(ctx.data.data() + ctx.dos->e_lfanew));
    ctx.valid  = true;
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. Hash helpers — BCrypt (MD5/SHA1/SHA256) + imphash
// ═══════════════════════════════════════════════════════════════════════════

static std::string bcrypt_hex(LPCWSTR alg, const void* data, size_t len) {
    BCRYPT_ALG_HANDLE hAlg = nullptr;
    if (BCryptOpenAlgorithmProvider(&hAlg, alg, nullptr, 0) != 0) return "";
    DWORD hlen = 0, junk = 0;
    BCryptGetProperty(hAlg, BCRYPT_HASH_LENGTH, (PUCHAR)&hlen, sizeof(hlen), &junk, 0);
    BCRYPT_HASH_HANDLE hHash = nullptr;
    BCryptCreateHash(hAlg, &hHash, nullptr, 0, nullptr, 0, 0);
    BCryptHashData(hHash, (PUCHAR)data, (ULONG)len, 0);
    std::vector<UCHAR> out(hlen);
    BCryptFinishHash(hHash, out.data(), hlen, 0);
    BCryptDestroyHash(hHash);
    BCryptCloseAlgorithmProvider(hAlg, 0);
    std::string s; s.reserve(hlen * 2);
    for (DWORD i = 0; i < hlen; i++) { char b[3]; sprintf(b, "%02x", out[i]); s += b; }
    return s;
}

// imphash: MD5 of comma-separated lowercase "dllname.function" entries.
static std::string compute_imphash(const PeCtx& ctx) {
    if (!ctx.valid) return "";
    const auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_IMPORT);
    if (!dd.VirtualAddress) return bcrypt_hex(BCRYPT_MD5_ALGORITHM, "", 0);
    const auto* imp = (const IMAGE_IMPORT_DESCRIPTOR*)ctx.at_rva(dd.VirtualAddress);
    if (!imp) return "";
    std::string s;
    while (imp->Name) {
        const char* dll = (const char*)ctx.at_rva(imp->Name);
        if (!dll) { imp++; continue; }
        std::string ldll = dll;
        for (auto& c : ldll) c = (char)tolower((unsigned char)c);
        size_t dot = ldll.rfind('.');
        if (dot != std::string::npos) {
            std::string ext = ldll.substr(dot);
            if (ext == ".dll" || ext == ".sys" || ext == ".ocx" || ext == ".drv")
                ldll = ldll.substr(0, dot);
        }
        DWORD ilt = imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk;
        if (ctx.is64) {
            const auto* th = (const ULONGLONG*)ctx.at_rva(ilt);
            if (!th) { imp++; continue; }
            while (*th) {
                std::string fn;
                if (IMAGE_SNAP_BY_ORDINAL64(*th)) {
                    char b[32]; sprintf(b, "ord%llu", (unsigned long long)IMAGE_ORDINAL64(*th));
                    fn = b;
                } else {
                    const auto* iin = (const IMAGE_IMPORT_BY_NAME*)ctx.at_rva((DWORD)*th);
                    if (!iin) { th++; continue; }
                    fn = (const char*)iin->Name;
                    for (auto& c : fn) c = (char)tolower((unsigned char)c);
                }
                if (!s.empty()) s += ',';
                s += ldll + '.' + fn;
                th++;
            }
        } else {
            const auto* th = (const DWORD*)ctx.at_rva(ilt);
            if (!th) { imp++; continue; }
            while (*th) {
                std::string fn;
                if (IMAGE_SNAP_BY_ORDINAL32(*th)) {
                    char b[32]; sprintf(b, "ord%u", (unsigned)IMAGE_ORDINAL32(*th));
                    fn = b;
                } else {
                    const auto* iin = (const IMAGE_IMPORT_BY_NAME*)ctx.at_rva(*th & 0x7FFFFFFFu);
                    if (!iin) { th++; continue; }
                    fn = (const char*)iin->Name;
                    for (auto& c : fn) c = (char)tolower((unsigned char)c);
                }
                if (!s.empty()) s += ',';
                s += ldll + '.' + fn;
                th++;
            }
        }
        imp++;
    }
    return bcrypt_hex(BCRYPT_MD5_ALGORITHM, s.data(), s.size());
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. Diff engines
// ═══════════════════════════════════════════════════════════════════════════

static std::string h16(uint16_t v) { char b[16]; sprintf(b, "0x%04X", v); return b; }
static std::string h32(uint32_t v) { char b[16]; sprintf(b, "0x%08X", v); return b; }
static std::string h64(uint64_t v) { char b[32]; sprintf(b, "0x%016llX", (unsigned long long)v); return b; }
static std::string d32(uint32_t v) { char b[16]; sprintf(b, "%u", v); return b; }

struct FieldRow { std::string name, va, vb; };

#define FA(n_, va_, vb_) out.push_back({(n_), (va_), (vb_)})

static void build_header_fields(const PeCtx& a, const PeCtx& b, std::vector<FieldRow>& out) {
    out.clear();
    FA("DOS.e_magic",                h16(a.dos->e_magic),               h16(b.dos->e_magic));
    FA("DOS.e_lfanew",               h32(a.dos->e_lfanew),              h32(b.dos->e_lfanew));
    FA("File.Machine",               h16(a.fhdr->Machine),              h16(b.fhdr->Machine));
    FA("File.NumberOfSections",      d32(a.fhdr->NumberOfSections),     d32(b.fhdr->NumberOfSections));
    FA("File.TimeDateStamp",         h32(a.fhdr->TimeDateStamp),        h32(b.fhdr->TimeDateStamp));
    FA("File.PointerToSymbolTable",  h32(a.fhdr->PointerToSymbolTable), h32(b.fhdr->PointerToSymbolTable));
    FA("File.NumberOfSymbols",       h32(a.fhdr->NumberOfSymbols),      h32(b.fhdr->NumberOfSymbols));
    FA("File.SizeOfOptionalHeader",  h16(a.fhdr->SizeOfOptionalHeader), h16(b.fhdr->SizeOfOptionalHeader));
    FA("File.Characteristics",       h16(a.fhdr->Characteristics),      h16(b.fhdr->Characteristics));

    if (a.is64 == b.is64) {
        if (a.is64) {
            auto* oa = &((const IMAGE_NT_HEADERS64*)(a.data.data()+a.dos->e_lfanew))->OptionalHeader;
            auto* ob = &((const IMAGE_NT_HEADERS64*)(b.data.data()+b.dos->e_lfanew))->OptionalHeader;
            FA("Opt.Magic",                  h16(oa->Magic),                    h16(ob->Magic));
            FA("Opt.MajorLinkerVersion",     d32(oa->MajorLinkerVersion),       d32(ob->MajorLinkerVersion));
            FA("Opt.MinorLinkerVersion",     d32(oa->MinorLinkerVersion),       d32(ob->MinorLinkerVersion));
            FA("Opt.SizeOfCode",             h32(oa->SizeOfCode),               h32(ob->SizeOfCode));
            FA("Opt.SizeOfInitializedData",  h32(oa->SizeOfInitializedData),    h32(ob->SizeOfInitializedData));
            FA("Opt.SizeOfUninitData",       h32(oa->SizeOfUninitializedData),  h32(ob->SizeOfUninitializedData));
            FA("Opt.AddressOfEntryPoint",    h32(oa->AddressOfEntryPoint),      h32(ob->AddressOfEntryPoint));
            FA("Opt.BaseOfCode",             h32(oa->BaseOfCode),               h32(ob->BaseOfCode));
            FA("Opt.ImageBase",              h64(oa->ImageBase),                h64(ob->ImageBase));
            FA("Opt.SectionAlignment",       h32(oa->SectionAlignment),         h32(ob->SectionAlignment));
            FA("Opt.FileAlignment",          h32(oa->FileAlignment),            h32(ob->FileAlignment));
            FA("Opt.SizeOfImage",            h32(oa->SizeOfImage),              h32(ob->SizeOfImage));
            FA("Opt.SizeOfHeaders",          h32(oa->SizeOfHeaders),            h32(ob->SizeOfHeaders));
            FA("Opt.CheckSum",               h32(oa->CheckSum),                 h32(ob->CheckSum));
            FA("Opt.Subsystem",              h16(oa->Subsystem),                h16(ob->Subsystem));
            FA("Opt.DllCharacteristics",     h16(oa->DllCharacteristics),       h16(ob->DllCharacteristics));
            FA("Opt.SizeOfStackReserve",     h64(oa->SizeOfStackReserve),       h64(ob->SizeOfStackReserve));
            FA("Opt.SizeOfStackCommit",      h64(oa->SizeOfStackCommit),        h64(ob->SizeOfStackCommit));
            FA("Opt.SizeOfHeapReserve",      h64(oa->SizeOfHeapReserve),        h64(ob->SizeOfHeapReserve));
            FA("Opt.SizeOfHeapCommit",       h64(oa->SizeOfHeapCommit),         h64(ob->SizeOfHeapCommit));
        } else {
            auto* oa = &((const IMAGE_NT_HEADERS32*)(a.data.data()+a.dos->e_lfanew))->OptionalHeader;
            auto* ob = &((const IMAGE_NT_HEADERS32*)(b.data.data()+b.dos->e_lfanew))->OptionalHeader;
            FA("Opt.Magic",                  h16(oa->Magic),                    h16(ob->Magic));
            FA("Opt.AddressOfEntryPoint",    h32(oa->AddressOfEntryPoint),      h32(ob->AddressOfEntryPoint));
            FA("Opt.ImageBase",              h32(oa->ImageBase),                h32(ob->ImageBase));
            FA("Opt.SectionAlignment",       h32(oa->SectionAlignment),         h32(ob->SectionAlignment));
            FA("Opt.FileAlignment",          h32(oa->FileAlignment),            h32(ob->FileAlignment));
            FA("Opt.SizeOfImage",            h32(oa->SizeOfImage),              h32(ob->SizeOfImage));
            FA("Opt.SizeOfHeaders",          h32(oa->SizeOfHeaders),            h32(ob->SizeOfHeaders));
            FA("Opt.CheckSum",               h32(oa->CheckSum),                 h32(ob->CheckSum));
            FA("Opt.Subsystem",              h16(oa->Subsystem),                h16(ob->Subsystem));
            FA("Opt.DllCharacteristics",     h16(oa->DllCharacteristics),       h16(ob->DllCharacteristics));
        }
    } else {
        FA("(Optional header)", "x86", "x64");   // sentinel — arch mismatch
    }

    static const char* dirnm[16] = {
        "Export","Import","Resource","Exception","Security","BaseReloc",
        "Debug","Architecture","GlobalPtr","TLS","LoadConfig","BoundImport",
        "IAT","DelayImport","CLR","Reserved"
    };
    for (int i = 0; i < 16; i++) {
        const auto& da = a.datadir(i);
        const auto& db = b.datadir(i);
        char nm[64];
        snprintf(nm, sizeof(nm), "DataDir[%2d] %-12s RVA",  i, dirnm[i]);
        FA(nm, h32(da.VirtualAddress), h32(db.VirtualAddress));
        snprintf(nm, sizeof(nm), "DataDir[%2d] %-12s Size", i, dirnm[i]);
        FA(nm, h32(da.Size),           h32(db.Size));
    }
}
#undef FA

struct SectionRow {
    int  idx;
    std::string name_a, name_b;
    std::string va_a,   va_b;
    std::string vs_a,   vs_b;
    std::string ra_a,   ra_b;
    std::string rs_a,   rs_b;
    std::string ch_a,   ch_b;
    bool changed;
};

static std::string sect_name(const IMAGE_SECTION_HEADER& s) {
    char b[9]{}; memcpy(b, s.Name, 8); return std::string(b);
}

static void build_section_rows(const PeCtx& a, const PeCtx& b, std::vector<SectionRow>& out) {
    out.clear();
    int n = (int)std::max(a.nsects, b.nsects);
    for (int i = 0; i < n; i++) {
        SectionRow r{}; r.idx = i;
        if (i < a.nsects) {
            r.name_a = sect_name(a.sects[i]);
            r.va_a = h32(a.sects[i].VirtualAddress);
            r.vs_a = h32(a.sects[i].Misc.VirtualSize);
            r.ra_a = h32(a.sects[i].PointerToRawData);
            r.rs_a = h32(a.sects[i].SizeOfRawData);
            r.ch_a = h32(a.sects[i].Characteristics);
        }
        if (i < b.nsects) {
            r.name_b = sect_name(b.sects[i]);
            r.va_b = h32(b.sects[i].VirtualAddress);
            r.vs_b = h32(b.sects[i].Misc.VirtualSize);
            r.ra_b = h32(b.sects[i].PointerToRawData);
            r.rs_b = h32(b.sects[i].SizeOfRawData);
            r.ch_b = h32(b.sects[i].Characteristics);
        }
        r.changed = (r.name_a != r.name_b) || (r.va_a != r.va_b) || (r.vs_a != r.vs_b) ||
                    (r.ra_a != r.ra_b)     || (r.rs_a != r.rs_b) || (r.ch_a != r.ch_b);
        out.push_back(std::move(r));
    }
}

struct ByteRegion {
    uint32_t offset;
    uint32_t size;
    int      sect_idx;
    std::vector<uint8_t> a_bytes;
    std::vector<uint8_t> b_bytes;
};

static const uint32_t BRIDGE_GAP = 8;
static const int      MAX_REGS   = 1000;

static void compute_byte_diff(const PeCtx& a, const PeCtx& b,
                              std::vector<ByteRegion>& out, uint32_t& diff_bytes)
{
    out.clear(); diff_bytes = 0;
    const size_t n = std::min(a.data.size(), b.data.size());
    bool in_r = false;
    ByteRegion cur{};
    size_t i = 0;
    while (i < n) {
        if (a.data[i] != b.data[i]) {
            if (!in_r) { cur = {}; cur.offset = (uint32_t)i; in_r = true; }
            cur.a_bytes.push_back(a.data[i]);
            cur.b_bytes.push_back(b.data[i]);
            diff_bytes++;
            i++;
        } else if (in_r) {
            // Look ahead: do we bridge or close?
            size_t same_run = 0;
            while (i + same_run < n && a.data[i+same_run] == b.data[i+same_run] && same_run <= BRIDGE_GAP)
                same_run++;
            if (same_run > BRIDGE_GAP || i + same_run >= n) {
                cur.size = (uint32_t)cur.a_bytes.size();
                cur.sect_idx = a.section_of_offset(cur.offset);
                out.push_back(std::move(cur));
                if ((int)out.size() >= MAX_REGS) return;
                in_r = false;
                i += same_run;
            } else {
                for (size_t k = 0; k < same_run; k++) {
                    cur.a_bytes.push_back(a.data[i+k]);
                    cur.b_bytes.push_back(b.data[i+k]);
                }
                i += same_run;
            }
        } else {
            i++;
        }
    }
    if (in_r) {
        cur.size = (uint32_t)cur.a_bytes.size();
        cur.sect_idx = a.section_of_offset(cur.offset);
        out.push_back(std::move(cur));
    }
    if (a.data.size() != b.data.size()) {
        ByteRegion tail{};
        tail.offset = (uint32_t)std::min(a.data.size(), b.data.size());
        if (a.data.size() > b.data.size()) {
            for (size_t k = b.data.size(); k < a.data.size(); k++) tail.a_bytes.push_back(a.data[k]);
        } else {
            for (size_t k = a.data.size(); k < b.data.size(); k++) tail.b_bytes.push_back(b.data[k]);
        }
        tail.size = (uint32_t)std::max(tail.a_bytes.size(), tail.b_bytes.size());
        tail.sect_idx = -2;
        out.push_back(tail);
        diff_bytes += tail.size;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. UI state
// ═══════════════════════════════════════════════════════════════════════════

enum : int {
    IDC_EDT_A = 400, IDC_BTN_BR_A,
    IDC_EDT_B,       IDC_BTN_BR_B,
    IDC_BTN_COMPARE, IDC_BTN_CLEAR,
    IDC_TAB,
    IDC_LV_HASHES,
    IDC_LV_HEADERS,
    IDC_LV_SECTS,
    IDC_LV_REGS,
    IDC_LV_IMPORTS,
    IDC_EDT_SUMMARY,
    IDC_LOG,
};

static HWND g_hwnd, g_hLog, g_hTab, g_hSummary;
static HWND g_hEdtA, g_hEdtB;
static HWND g_hLvHashes, g_hLvHdrs, g_hLvSects, g_hLvRegs, g_hLvImports;
static HFONT g_hFont, g_hMono;

static PeCtx g_a, g_b;
static int   g_cur_tab = 0;

struct HashRow { std::string name, va, vb; bool diff; };
static std::vector<HashRow>    g_hashes;
static std::vector<FieldRow>   g_hdrs;
static std::vector<SectionRow> g_sects;
static std::vector<ByteRegion> g_regs;

struct ImportRow { std::string dll, fn; bool in_a, in_b; };
static std::vector<ImportRow>  g_imports;

// ── helpers ────────────────────────────────────────────────────────────────

static void Log(const char* fmt, ...) {
    char buf[1024];
    va_list va; va_start(va, fmt); vsnprintf(buf, sizeof(buf), fmt, va); va_end(va);
    std::string s(buf); s += "\r\n";
    int len = GetWindowTextLength(g_hLog);
    SendMessage(g_hLog, EM_SETSEL,     (WPARAM)len, (LPARAM)len);
    SendMessage(g_hLog, EM_REPLACESEL, 0, (LPARAM)s.c_str());
}

static HWND MakeCtl(const char* cls, const char* txt, DWORD style, DWORD exStyle,
                    int x, int y, int w, int h, int id, HFONT font = nullptr) {
    HWND hw = CreateWindowEx(exStyle, cls, txt,
        WS_CHILD | WS_VISIBLE | style,
        x, y, w, h, g_hwnd, (HMENU)(UINT_PTR)id,
        (HINSTANCE)GetWindowLongPtr(g_hwnd, GWLP_HINSTANCE), nullptr);
    SendMessage(hw, WM_SETFONT, (WPARAM)(font ? font : g_hFont), TRUE);
    return hw;
}
static HWND MakeLabel(const char* t, int x, int y, int w, int h = 18) {
    return MakeCtl("STATIC", t, SS_SIMPLE, 0, x, y, w, h, 0);
}
static HWND MakeBtn(const char* t, int id, int x, int y, int w, int h = 26) {
    return MakeCtl("BUTTON", t, BS_PUSHBUTTON, 0, x, y, w, h, id);
}

static void AddCol(HWND lv, int idx, int w, const char* text) {
    LVCOLUMN c{}; c.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_FMT;
    c.fmt = LVCFMT_LEFT; c.cx = w; c.pszText = const_cast<LPSTR>(text);
    ListView_InsertColumn(lv, idx, &c);
}
static void LvSet(HWND lv, int row, int col, const char* text) {
    LVITEM lvi{}; lvi.mask = LVIF_TEXT; lvi.iItem = row; lvi.iSubItem = col;
    lvi.pszText = const_cast<LPSTR>(text);
    if (col == 0) ListView_InsertItem(lv, &lvi);
    else          ListView_SetItem(lv, &lvi);
}

static bool BrowseFile(char* buf, int bufsz) {
    OPENFILENAMEA ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner   = g_hwnd;
    ofn.lpstrFilter = "EXE/DLL\0*.exe;*.dll;*.sys\0All\0*.*\0";
    ofn.lpstrFile   = buf;
    ofn.nMaxFile    = bufsz;
    ofn.lpstrTitle  = "Select PE file";
    ofn.Flags       = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
    return GetOpenFileNameA(&ofn) != 0;
}

static std::string GetEditStr(HWND hw) {
    int n = GetWindowTextLength(hw);
    if (n <= 0) return "";
    std::string s(n + 1, '\0');
    GetWindowText(hw, &s[0], n + 1);
    s.resize(n);
    return s;
}

// ── Imports diff ────────────────────────────────────────────────────────────

static void build_import_set(const PeCtx& ctx, std::vector<std::pair<std::string,std::string>>& out) {
    out.clear();
    if (!ctx.valid) return;
    const auto& dd = ctx.datadir(IMAGE_DIRECTORY_ENTRY_IMPORT);
    if (!dd.VirtualAddress) return;
    const auto* imp = (const IMAGE_IMPORT_DESCRIPTOR*)ctx.at_rva(dd.VirtualAddress);
    if (!imp) return;
    while (imp->Name) {
        const char* dll = (const char*)ctx.at_rva(imp->Name);
        if (!dll) { imp++; continue; }
        std::string ld = dll;
        for (auto& c : ld) c = (char)tolower((unsigned char)c);
        DWORD ilt = imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk;
        if (ctx.is64) {
            const auto* th = (const ULONGLONG*)ctx.at_rva(ilt);
            if (!th) { imp++; continue; }
            while (*th) {
                std::string fn;
                if (IMAGE_SNAP_BY_ORDINAL64(*th)) {
                    char b[32]; sprintf(b, "#%llu", (unsigned long long)IMAGE_ORDINAL64(*th));
                    fn = b;
                } else {
                    const auto* iin = (const IMAGE_IMPORT_BY_NAME*)ctx.at_rva((DWORD)*th);
                    if (iin) fn = (const char*)iin->Name;
                }
                if (!fn.empty()) out.push_back({ld, fn});
                th++;
            }
        } else {
            const auto* th = (const DWORD*)ctx.at_rva(ilt);
            if (!th) { imp++; continue; }
            while (*th) {
                std::string fn;
                if (IMAGE_SNAP_BY_ORDINAL32(*th)) {
                    char b[32]; sprintf(b, "#%u", (unsigned)IMAGE_ORDINAL32(*th)); fn = b;
                } else {
                    const auto* iin = (const IMAGE_IMPORT_BY_NAME*)ctx.at_rva(*th & 0x7FFFFFFFu);
                    if (iin) fn = (const char*)iin->Name;
                }
                if (!fn.empty()) out.push_back({ld, fn});
                th++;
            }
        }
        imp++;
    }
    std::sort(out.begin(), out.end());
}

static void build_import_diff() {
    g_imports.clear();
    std::vector<std::pair<std::string,std::string>> A, B;
    build_import_set(g_a, A);
    build_import_set(g_b, B);
    size_t i = 0, j = 0;
    while (i < A.size() || j < B.size()) {
        bool both = (i < A.size() && j < B.size() && A[i] == B[j]);
        if (both) {
            g_imports.push_back({A[i].first, A[i].second, true, true});
            i++; j++;
        } else if (j == B.size() || (i < A.size() && A[i] < B[j])) {
            g_imports.push_back({A[i].first, A[i].second, true, false});
            i++;
        } else {
            g_imports.push_back({B[j].first, B[j].second, false, true});
            j++;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// 5. Tab population
// ═══════════════════════════════════════════════════════════════════════════

static void populate_hashes() {
    ListView_DeleteAllItems(g_hLvHashes);
    for (size_t i = 0; i < g_hashes.size(); i++) {
        LvSet(g_hLvHashes, (int)i, 0, g_hashes[i].name.c_str());
        LvSet(g_hLvHashes, (int)i, 1, g_hashes[i].va.c_str());
        LvSet(g_hLvHashes, (int)i, 2, g_hashes[i].vb.c_str());
        LvSet(g_hLvHashes, (int)i, 3, g_hashes[i].diff ? "DIFF" : "SAME");
    }
}
static void populate_headers() {
    ListView_DeleteAllItems(g_hLvHdrs);
    for (size_t i = 0; i < g_hdrs.size(); i++) {
        LvSet(g_hLvHdrs, (int)i, 0, g_hdrs[i].name.c_str());
        LvSet(g_hLvHdrs, (int)i, 1, g_hdrs[i].va.c_str());
        LvSet(g_hLvHdrs, (int)i, 2, g_hdrs[i].vb.c_str());
        LvSet(g_hLvHdrs, (int)i, 3, g_hdrs[i].va != g_hdrs[i].vb ? "DIFF" : "SAME");
    }
}
static void populate_sects() {
    ListView_DeleteAllItems(g_hLvSects);
    for (size_t i = 0; i < g_sects.size(); i++) {
        const auto& r = g_sects[i];
        char buf[16]; snprintf(buf, sizeof(buf), "%d", r.idx);
        LvSet(g_hLvSects, (int)i, 0, buf);
        LvSet(g_hLvSects, (int)i, 1, r.name_a.c_str());
        LvSet(g_hLvSects, (int)i, 2, r.name_b.c_str());
        LvSet(g_hLvSects, (int)i, 3, r.va_a.c_str());
        LvSet(g_hLvSects, (int)i, 4, r.va_b.c_str());
        LvSet(g_hLvSects, (int)i, 5, r.rs_a.c_str());
        LvSet(g_hLvSects, (int)i, 6, r.rs_b.c_str());
        LvSet(g_hLvSects, (int)i, 7, r.ch_a.c_str());
        LvSet(g_hLvSects, (int)i, 8, r.ch_b.c_str());
    }
}
static std::string bytes_hex(const std::vector<uint8_t>& v, size_t maxn = 16) {
    std::string s;
    size_t n = std::min(v.size(), maxn);
    for (size_t i = 0; i < n; i++) { char b[4]; sprintf(b, "%02X ", v[i]); s += b; }
    if (v.size() > maxn) s += "...";
    return s;
}
static void populate_regs() {
    ListView_DeleteAllItems(g_hLvRegs);
    for (size_t i = 0; i < g_regs.size(); i++) {
        const auto& r = g_regs[i];
        char buf[64];
        snprintf(buf, sizeof(buf), "0x%08X", r.offset);
        LvSet(g_hLvRegs, (int)i, 0, buf);
        snprintf(buf, sizeof(buf), "%u", r.size);
        LvSet(g_hLvRegs, (int)i, 1, buf);
        if (r.sect_idx == -1)      strcpy(buf, "(header)");
        else if (r.sect_idx == -2) strcpy(buf, "(beyond)");
        else if (r.sect_idx >= 0 && r.sect_idx < g_a.nsects)
             snprintf(buf, sizeof(buf), "[%d] %s", r.sect_idx, sect_name(g_a.sects[r.sect_idx]).c_str());
        else strcpy(buf, "?");
        LvSet(g_hLvRegs, (int)i, 2, buf);
        LvSet(g_hLvRegs, (int)i, 3, bytes_hex(r.a_bytes).c_str());
        LvSet(g_hLvRegs, (int)i, 4, bytes_hex(r.b_bytes).c_str());
    }
}
static void populate_imports() {
    ListView_DeleteAllItems(g_hLvImports);
    for (size_t i = 0; i < g_imports.size(); i++) {
        const auto& r = g_imports[i];
        LvSet(g_hLvImports, (int)i, 0, r.dll.c_str());
        LvSet(g_hLvImports, (int)i, 1, r.fn.c_str());
        LvSet(g_hLvImports, (int)i, 2, r.in_a ? "yes" : "—");
        LvSet(g_hLvImports, (int)i, 3, r.in_b ? "yes" : "—");
        const char* st = (r.in_a && r.in_b) ? "SAME"
                       : (r.in_a ? "REMOVED" : "ADDED");
        LvSet(g_hLvImports, (int)i, 4, st);
    }
}

static void SwitchTab(int idx) {
    g_cur_tab = idx;
    ShowWindow(g_hLvHashes,  idx == 0 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hLvHdrs,    idx == 1 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hLvSects,   idx == 2 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hLvRegs,    idx == 3 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_hLvImports, idx == 4 ? SW_SHOW : SW_HIDE);
}

// ═══════════════════════════════════════════════════════════════════════════
// 6. Main compare action
// ═══════════════════════════════════════════════════════════════════════════

static void DoCompare() {
    g_a = {}; g_b = {};
    std::string pa = GetEditStr(g_hEdtA);
    std::string pb = GetEditStr(g_hEdtB);
    if (pa.empty() || pb.empty()) { Log("[!] Both file paths required."); return; }
    if (!pe_load(pa.c_str(), g_a)) { Log("[-] Failed to load PE A: %s", pa.c_str()); return; }
    if (!pe_load(pb.c_str(), g_b)) { Log("[-] Failed to load PE B: %s", pb.c_str()); return; }

    Log("──── Compare ────");
    Log("  A: %s  (%zu bytes)", pa.c_str(), g_a.data.size());
    Log("  B: %s  (%zu bytes)", pb.c_str(), g_b.data.size());
    if (g_a.is64 != g_b.is64)
        Log("[!] Architecture mismatch: A=%s  B=%s",
            g_a.is64 ? "x64" : "x86", g_b.is64 ? "x64" : "x86");

    g_hashes.clear();
    auto add_h = [&](const char* nm, std::string a, std::string b) {
        // Compute diff BEFORE moving — otherwise a and b would be
        // moved-from when the comparison runs (C++17 left-to-right
        // sequencing of brace-init clauses), so a != b would always
        // be false.  Classic use-after-move trap.
        bool d = (a != b);
        g_hashes.push_back({nm, std::move(a), std::move(b), d});
    };
    char sa[32], sb[32];
    snprintf(sa, sizeof(sa), "%zu bytes", g_a.data.size());
    snprintf(sb, sizeof(sb), "%zu bytes", g_b.data.size());
    add_h("File size", sa, sb);
    add_h("MD5",     bcrypt_hex(BCRYPT_MD5_ALGORITHM,    g_a.data.data(), g_a.data.size()),
                     bcrypt_hex(BCRYPT_MD5_ALGORITHM,    g_b.data.data(), g_b.data.size()));
    add_h("SHA-1",   bcrypt_hex(BCRYPT_SHA1_ALGORITHM,   g_a.data.data(), g_a.data.size()),
                     bcrypt_hex(BCRYPT_SHA1_ALGORITHM,   g_b.data.data(), g_b.data.size()));
    add_h("SHA-256", bcrypt_hex(BCRYPT_SHA256_ALGORITHM, g_a.data.data(), g_a.data.size()),
                     bcrypt_hex(BCRYPT_SHA256_ALGORITHM, g_b.data.data(), g_b.data.size()));
    add_h("imphash", compute_imphash(g_a), compute_imphash(g_b));

    build_header_fields(g_a, g_b, g_hdrs);
    build_section_rows (g_a, g_b, g_sects);
    uint32_t diff_bytes = 0;
    compute_byte_diff  (g_a, g_b, g_regs, diff_bytes);
    build_import_diff();

    int fld_diff = 0;  for (auto& f : g_hdrs)    if (f.va != f.vb)            fld_diff++;
    int sec_diff = 0;  for (auto& s : g_sects)   if (s.changed)               sec_diff++;
    int imp_diff = 0;  for (auto& im: g_imports) if (!(im.in_a && im.in_b))   imp_diff++;
    int hash_diff = 0; for (auto& h : g_hashes)  if (h.diff)                  hash_diff++;

    char sum[1024];
    snprintf(sum, sizeof(sum),
        "File sizes        : A=%zu B=%zu  (Δ=%+lld bytes)\r\n"
        "Cryptographic hash: %d / %d differ\r\n"
        "Header fields     : %d / %zu differ\r\n"
        "Sections          : %d / %zu differ\r\n"
        "Imports (unique)  : %d / %zu differ\r\n"
        "Byte diff regions : %zu  (bridge gap = %u bytes; capped at %d)\r\n"
        "Total diff bytes  : %u",
        g_a.data.size(), g_b.data.size(),
        (long long)g_b.data.size() - (long long)g_a.data.size(),
        hash_diff, (int)g_hashes.size(),
        fld_diff,  g_hdrs.size(),
        sec_diff,  g_sects.size(),
        imp_diff,  g_imports.size(),
        g_regs.size(), BRIDGE_GAP, MAX_REGS,
        diff_bytes);
    SetWindowText(g_hSummary, sum);

    populate_hashes();
    populate_headers();
    populate_sects();
    populate_regs();
    populate_imports();

    Log("[+] Done. hashes:%d  fields:%d  sections:%d  imports:%d  regions:%zu",
        hash_diff, fld_diff, sec_diff, imp_diff, g_regs.size());
}

// ═══════════════════════════════════════════════════════════════════════════
// 7. Custom draw — red for DIFF, green for SAME
// ═══════════════════════════════════════════════════════════════════════════

// kind: 0 hashes, 1 headers, 2 sections, 4 imports
static LRESULT CustomDraw(LPNMLVCUSTOMDRAW cd, int kind) {
    switch (cd->nmcd.dwDrawStage) {
    case CDDS_PREPAINT: return CDRF_NOTIFYITEMDRAW;
    case CDDS_ITEMPREPAINT: {
        int row = (int)cd->nmcd.dwItemSpec;
        bool diff = false;
        if (kind == 0) {
            if (row < (int)g_hashes.size()) diff = g_hashes[row].diff;
        } else if (kind == 1) {
            if (row < (int)g_hdrs.size()) diff = (g_hdrs[row].va != g_hdrs[row].vb);
        } else if (kind == 2) {
            if (row < (int)g_sects.size()) diff = g_sects[row].changed;
        } else if (kind == 4) {
            if (row < (int)g_imports.size()) diff = !(g_imports[row].in_a && g_imports[row].in_b);
        }
        cd->clrTextBk = diff ? RGB(255, 220, 220) : RGB(220, 255, 220);
        return CDRF_NEWFONT;
    }}
    return CDRF_DODEFAULT;
}

// ═══════════════════════════════════════════════════════════════════════════
// 8. WM_CREATE
// ═══════════════════════════════════════════════════════════════════════════

static void OnCreate(HINSTANCE) {
    g_hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    g_hMono = CreateFont(14, 0, 0, 0, FW_NORMAL, 0, 0, 0,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN, "Consolas");

    int y = 8;
    MakeLabel("File A :", 8, y+4, 60);
    g_hEdtA = MakeCtl("EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE,
                      72, y, 700, 22, IDC_EDT_A);
    MakeBtn("Browse...", IDC_BTN_BR_A, 780, y, 80, 22);
    y += 28;

    MakeLabel("File B :", 8, y+4, 60);
    g_hEdtB = MakeCtl("EDIT", "", ES_AUTOHSCROLL, WS_EX_CLIENTEDGE,
                      72, y, 700, 22, IDC_EDT_B);
    MakeBtn("Browse...", IDC_BTN_BR_B, 780, y, 80, 22);
    y += 28;

    MakeBtn("Compare", IDC_BTN_COMPARE, 8, y, 100);
    MakeBtn("Clear log", IDC_BTN_CLEAR, 780, y, 80);
    y += 34;

    MakeLabel("Summary:", 8, y, 80);
    y += 16;
    g_hSummary = MakeCtl("EDIT", "(no comparison yet)",
        ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 8, y, 858, 110, IDC_EDT_SUMMARY, g_hMono);
    y += 118;

    g_hTab = MakeCtl(WC_TABCONTROL, "", 0, 0, 8, y, 858, 28, IDC_TAB);
    TCITEM ti{}; ti.mask = TCIF_TEXT;
    static const char* tabs[] = {"Hashes", "Headers", "Sections", "Diff regions", "Imports"};
    for (int i = 0; i < 5; i++) {
        ti.pszText = const_cast<LPSTR>(tabs[i]);
        TabCtrl_InsertItem(g_hTab, i, &ti);
    }
    int lvY = y + 32;
    int lvH = 290;

    g_hLvHashes = MakeCtl(WC_LISTVIEW, "",
        LVS_REPORT | LVS_SINGLESEL | LVS_NOSORTHEADER,
        WS_EX_CLIENTEDGE, 8, lvY, 858, lvH, IDC_LV_HASHES, g_hMono);
    ListView_SetExtendedListViewStyle(g_hLvHashes, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    AddCol(g_hLvHashes, 0, 90,  "Metric");
    AddCol(g_hLvHashes, 1, 360, "File A");
    AddCol(g_hLvHashes, 2, 360, "File B");
    AddCol(g_hLvHashes, 3, 40,  "Δ");

    g_hLvHdrs = MakeCtl(WC_LISTVIEW, "",
        LVS_REPORT | LVS_SINGLESEL | LVS_NOSORTHEADER,
        WS_EX_CLIENTEDGE, 8, lvY, 858, lvH, IDC_LV_HEADERS, g_hMono);
    ListView_SetExtendedListViewStyle(g_hLvHdrs, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    AddCol(g_hLvHdrs, 0, 270, "Field");
    AddCol(g_hLvHdrs, 1, 245, "File A");
    AddCol(g_hLvHdrs, 2, 245, "File B");
    AddCol(g_hLvHdrs, 3, 80,  "Status");
    ShowWindow(g_hLvHdrs, SW_HIDE);

    g_hLvSects = MakeCtl(WC_LISTVIEW, "",
        LVS_REPORT | LVS_SINGLESEL | LVS_NOSORTHEADER,
        WS_EX_CLIENTEDGE, 8, lvY, 858, lvH, IDC_LV_SECTS, g_hMono);
    ListView_SetExtendedListViewStyle(g_hLvSects, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    AddCol(g_hLvSects, 0, 30,  "#");
    AddCol(g_hLvSects, 1, 90,  "Name A");
    AddCol(g_hLvSects, 2, 90,  "Name B");
    AddCol(g_hLvSects, 3, 100, "VA (A)");
    AddCol(g_hLvSects, 4, 100, "VA (B)");
    AddCol(g_hLvSects, 5, 100, "RSize (A)");
    AddCol(g_hLvSects, 6, 100, "RSize (B)");
    AddCol(g_hLvSects, 7, 120, "Char (A)");
    AddCol(g_hLvSects, 8, 120, "Char (B)");
    ShowWindow(g_hLvSects, SW_HIDE);

    g_hLvRegs = MakeCtl(WC_LISTVIEW, "",
        LVS_REPORT | LVS_SINGLESEL | LVS_NOSORTHEADER,
        WS_EX_CLIENTEDGE, 8, lvY, 858, lvH, IDC_LV_REGS, g_hMono);
    ListView_SetExtendedListViewStyle(g_hLvRegs, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    AddCol(g_hLvRegs, 0, 90,  "Offset");
    AddCol(g_hLvRegs, 1, 60,  "Size");
    AddCol(g_hLvRegs, 2, 130, "Section");
    AddCol(g_hLvRegs, 3, 280, "Before (hex)");
    AddCol(g_hLvRegs, 4, 280, "After  (hex)");
    ShowWindow(g_hLvRegs, SW_HIDE);

    g_hLvImports = MakeCtl(WC_LISTVIEW, "",
        LVS_REPORT | LVS_SINGLESEL | LVS_NOSORTHEADER,
        WS_EX_CLIENTEDGE, 8, lvY, 858, lvH, IDC_LV_IMPORTS, g_hMono);
    ListView_SetExtendedListViewStyle(g_hLvImports, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    AddCol(g_hLvImports, 0, 150, "DLL");
    AddCol(g_hLvImports, 1, 300, "Function");
    AddCol(g_hLvImports, 2, 80,  "In A");
    AddCol(g_hLvImports, 3, 80,  "In B");
    AddCol(g_hLvImports, 4, 120, "Status");
    ShowWindow(g_hLvImports, SW_HIDE);

    y = lvY + lvH + 8;
    MakeLabel("Log:", 8, y, 60);
    y += 16;
    g_hLog = MakeCtl("EDIT", "",
        ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL,
        WS_EX_CLIENTEDGE, 8, y, 858, 100, IDC_LOG, g_hMono);

    Log("PE Binary Diff Viewer  —  ready.");
    Log("1. Browse for File A (original) and File B (e.g., patched output).");
    Log("2. Click [Compare] — Hashes / Headers / Sections / Regions / Imports tabs populate.");
    Log("Color key:  red = DIFF, green = SAME.");
    Log("Tip: feed this the input and output of patchtool_ui to verify your patch surgically.");
}

// ═══════════════════════════════════════════════════════════════════════════
// 9. WndProc + WinMain
// ═══════════════════════════════════════════════════════════════════════════

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE:
        g_hwnd = hwnd;
        OnCreate(((CREATESTRUCT*)lp)->hInstance);
        return 0;

    case WM_NOTIFY: {
        LPNMHDR nmh = (LPNMHDR)lp;
        if (nmh->idFrom == IDC_TAB && nmh->code == TCN_SELCHANGE) {
            SwitchTab(TabCtrl_GetCurSel(g_hTab));
            return 0;
        }
        if (nmh->code == NM_CUSTOMDRAW) {
            switch (nmh->idFrom) {
            case IDC_LV_HASHES:  return CustomDraw((LPNMLVCUSTOMDRAW)lp, 0);
            case IDC_LV_HEADERS: return CustomDraw((LPNMLVCUSTOMDRAW)lp, 1);
            case IDC_LV_SECTS:   return CustomDraw((LPNMLVCUSTOMDRAW)lp, 2);
            case IDC_LV_IMPORTS: return CustomDraw((LPNMLVCUSTOMDRAW)lp, 4);
            }
        }
        return 0;
    }

    case WM_COMMAND: {
        int id = LOWORD(wp);
        char buf[MAX_PATH] = {};
        switch (id) {
        case IDC_BTN_BR_A:    if (BrowseFile(buf, MAX_PATH)) SetWindowText(g_hEdtA, buf); break;
        case IDC_BTN_BR_B:    if (BrowseFile(buf, MAX_PATH)) SetWindowText(g_hEdtB, buf); break;
        case IDC_BTN_COMPARE: DoCompare(); break;
        case IDC_BTN_CLEAR:   SetWindowText(g_hLog, ""); break;
        }
        return 0;
    }

    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)wp, TRANSPARENT);
        return (LRESULT)GetSysColorBrush(COLOR_3DFACE);

    case WM_DESTROY:
        if (g_hMono) DeleteObject(g_hMono);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nShow) {
    INITCOMMONCONTROLSEX icex = { sizeof(icex), ICC_LISTVIEW_CLASSES | ICC_TAB_CLASSES };
    InitCommonControlsEx(&icex);

    WNDCLASSEX wc = { sizeof(wc) };
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hbrBackground = (HBRUSH)(COLOR_3DFACE + 1);
    wc.lpszClassName = "PeDiffWnd";
    wc.hIcon         = LoadIcon(nullptr, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassEx(&wc);

    RECT rc = { 0, 0, 882, 720 };
    AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME|WS_MAXIMIZEBOX), FALSE);

    HWND hwnd = CreateWindowEx(0, "PeDiffWnd",
        "PE Binary Diff Viewer",
        WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME | WS_MAXIMIZEBOX),
        CW_USEDEFAULT, CW_USEDEFAULT,
        rc.right - rc.left, rc.bottom - rc.top,
        nullptr, nullptr, hInst, nullptr);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG m;
    while (GetMessage(&m, nullptr, 0, 0)) {
        TranslateMessage(&m);
        DispatchMessage(&m);
    }
    return (int)m.wParam;
}
