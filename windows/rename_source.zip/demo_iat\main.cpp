/*
 * demo_iat/main.cpp
 * ─────────────────────────────────────────────────────────────────────────────
 * Demonstrates IAT-free API resolution via EAT hash walking.
 *
 * What this demo proves
 *   - MessageBoxA, VirtualAlloc, GetSystemInfo, VirtualAllocEx, etc. are
 *     resolved and called at runtime WITHOUT appearing in the IAT.
 *   - DLL name strings ("user32.dll" etc.) are XOR-encrypted in the binary.
 *   - Changing CFG_SEED_STR in gen_config.py and rebuilding produces a
 *     completely different binary with different hashes and encrypted bytes.
 *
 * What IS still in the IAT (acceptable for this demo level)
 *   - GetModuleHandleA, LoadLibraryA   (benign loader APIs)
 *   - printf / puts                    (CRT I/O)
 *   A production loader would remove these too via PEB walking.
 *
 * Build
 *   1. python gen_config.py "YourSeedHere" > config.h
 *   2. cl /nologo /MT /O2 /std:c++17 /W3 /EHsc main.cpp /link /out:demo_iat.exe
 *
 * Verify IAT after build
 *   dumpbin /IMPORTS demo_iat.exe
 *   -> MessageBoxA / VirtualAlloc / GetSystemInfo must NOT appear.
 */

#include <windows.h>
#include <cstdio>
#include <cstdint>

// config.h MUST come first: defines CFG_SEED, CFG_SEED_STR, HASH_* constants.
#include "config.h"
#include "hash.h"
#include "strenc.h"
#include "resolve.h"

// ─── Function pointer typedefs ────────────────────────────────────────────────
using fn_MessageBoxA   = int    (WINAPI*)(HWND, LPCSTR, LPCSTR, UINT);
using fn_VirtualAlloc  = LPVOID (WINAPI*)(LPVOID, SIZE_T, DWORD, DWORD);
using fn_VirtualFree   = BOOL   (WINAPI*)(LPVOID, SIZE_T, DWORD);
using fn_GetSystemInfo = void   (WINAPI*)(LPSYSTEM_INFO);

// ─── Module handle cache ──────────────────────────────────────────────────────
// DLL names are encrypted; GetModuleHandleA is still a static import (acceptable).

static HMODULE hKernel32() {
    static HMODULE h = nullptr;
    if (!h) {
        ESTR_BUF(name, "kernel32.dll");  // "kernel32.dll" is XOR-encrypted
        h = GetModuleHandleA(name);
    }
    return h;
}

static HMODULE hUser32() {
    static HMODULE h = nullptr;
    if (!h) {
        ESTR_BUF(name, "user32.dll");    // "user32.dll" is XOR-encrypted
        h = LoadLibraryA(name);
    }
    return h;
}

// ─── Lazy-resolved function accessors ────────────────────────────────────────

static fn_MessageBoxA   pfn_MessageBoxA() {
    static auto fn = resolve<fn_MessageBoxA>(hUser32(),   HASH_MessageBoxA);
    return fn;
}
static fn_VirtualAlloc  pfn_VirtualAlloc() {
    static auto fn = resolve<fn_VirtualAlloc>(hKernel32(), HASH_VirtualAlloc);
    return fn;
}
static fn_VirtualFree   pfn_VirtualFree() {
    static auto fn = resolve<fn_VirtualFree>(hKernel32(),  HASH_VirtualFree);
    return fn;
}
static fn_GetSystemInfo pfn_GetSystemInfo() {
    static auto fn = resolve<fn_GetSystemInfo>(hKernel32(), HASH_GetSystemInfo);
    return fn;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

static bool check(void* fn, const char* name) {
    if (!fn) { printf("  [-] FAIL: %s not resolved\n", name); return false; }
    printf("  [+] %-25s -> 0x%p\n", name, fn);
    return true;
}

// ─── Main ─────────────────────────────────────────────────────────────────────

int main() {
    printf("============================================================\n");
    printf("  IAT Dynamicization Demo\n");
    printf("============================================================\n");
    printf("  Seed string : %s\n", CFG_SEED_STR);
    printf("  Seed value  : 0x%08X\n", CFG_SEED);
    printf("  ESTR key    : 0x%02X\n", (unsigned)ESTR_KEY);
    printf("\n");

    // ── 1. Show encrypted DLL names ──────────────────────────────────────────
    printf("[1] Encrypted DLL name bytes (in binary these are NOT plaintext):\n");
    {
        static constexpr _EStr<sizeof("kernel32.dll")> e("kernel32.dll");
        printf("  \"kernel32.dll\" encrypted: ");
        for (size_t i = 0; i < sizeof("kernel32.dll") - 1; i++)
            printf("%02X ", (uint8_t)e.enc[i]);
        printf("\n");
    }
    {
        static constexpr _EStr<sizeof("user32.dll")>  e("user32.dll");
        printf("  \"user32.dll\" encrypted:   ");
        for (size_t i = 0; i < sizeof("user32.dll") - 1; i++)
            printf("%02X ", (uint8_t)e.enc[i]);
        printf("\n");
    }
    printf("\n");

    // ── 2. Show pre-computed hashes ───────────────────────────────────────────
    printf("[2] Pre-computed API hashes (from config.h, verified at runtime):\n");
    printf("  HASH_MessageBoxA   = 0x%08X\n", HASH_MessageBoxA);
    printf("  HASH_VirtualAlloc  = 0x%08X\n", HASH_VirtualAlloc);
    printf("  HASH_VirtualFree   = 0x%08X\n", HASH_VirtualFree);
    printf("  HASH_GetSystemInfo = 0x%08X\n", HASH_GetSystemInfo);
    printf("\n");

    // ── 3. Resolve APIs by walking EAT ───────────────────────────────────────
    printf("[3] Runtime EAT resolution (no IAT entry for these APIs):\n");
    bool ok = true;
    ok &= check((void*)pfn_MessageBoxA(),   "MessageBoxA");
    ok &= check((void*)pfn_VirtualAlloc(),  "VirtualAlloc");
    ok &= check((void*)pfn_VirtualFree(),   "VirtualFree");
    ok &= check((void*)pfn_GetSystemInfo(), "GetSystemInfo");
    printf("\n");
    if (!ok) { printf("[-] One or more APIs failed to resolve.\n"); return 1; }

    // ── 4. Call MessageBoxA (no IAT entry) ───────────────────────────────────
    printf("[4] Calling MessageBoxA via resolved pointer:\n");
    {
        ESTR_BUF(title, "IAT Demo");
        ESTR_BUF(msg,
            "MessageBoxA resolved via EAT hash walk.\n"
            "This API has NO entry in the IAT.\n\n"
            "Verify with:  dumpbin /IMPORTS demo_iat.exe");
        pfn_MessageBoxA()(nullptr, msg, title, MB_OK | MB_ICONINFORMATION);
    }
    printf("  [+] MessageBoxA called successfully.\n\n");

    // ── 5. Call VirtualAlloc / VirtualFree (no IAT entry) ────────────────────
    printf("[5] Calling VirtualAlloc / VirtualFree via resolved pointer:\n");
    {
        void* mem = pfn_VirtualAlloc()(nullptr, 4096,
                                       MEM_COMMIT | MEM_RESERVE,
                                       PAGE_READWRITE);
        if (!mem) { printf("  [-] VirtualAlloc returned null\n"); return 1; }
        printf("  [+] VirtualAlloc  -> 0x%p  (4096 bytes)\n", mem);

        // Write something to prove the memory is usable
        reinterpret_cast<uint8_t*>(mem)[0] = 0xCC;

        BOOL freed = pfn_VirtualFree()(mem, 0, MEM_RELEASE);
        printf("  [+] VirtualFree   -> %s\n", freed ? "OK" : "FAILED");
    }
    printf("\n");

    // ── 6. Call GetSystemInfo (no IAT entry) ──────────────────────────────────
    printf("[6] Calling GetSystemInfo via resolved pointer:\n");
    {
        SYSTEM_INFO si{};
        pfn_GetSystemInfo()(&si);
        printf("  [+] Processors    : %u\n",   si.dwNumberOfProcessors);
        printf("  [+] Page size     : %u\n",   si.dwPageSize);
        printf("  [+] Min app addr  : 0x%p\n", si.lpMinimumApplicationAddress);
        printf("  [+] Max app addr  : 0x%p\n", si.lpMaximumApplicationAddress);
    }
    printf("\n");

    // ── 7. Runtime hash verification ─────────────────────────────────────────
    printf("[7] Runtime hash cross-check (gen_config.py vs runtime EAT):\n");
    {
        auto verify = [&](HMODULE mod, const char* api_name, uint32_t expected_hash) {
            // Walk EAT manually to find the actual name and compute hash
            auto* base = reinterpret_cast<const uint8_t*>(mod);
            auto* dos  = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
            auto* nt   = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
            auto* exp  = reinterpret_cast<const IMAGE_EXPORT_DIRECTORY*>(
                             base + nt->OptionalHeader.DataDirectory[0].VirtualAddress);
            auto* names = reinterpret_cast<const DWORD*>(base + exp->AddressOfNames);
            for (DWORD i = 0; i < exp->NumberOfNames; i++) {
                const char* n = reinterpret_cast<const char*>(base + names[i]);
                if (!strcmp(n, api_name)) {
                    uint32_t got = api_hash(n, CFG_SEED);
                    bool match = (got == expected_hash);
                    printf("  %s %-25s  computed=0x%08X  expected=0x%08X\n",
                           match ? "[+]" : "[!]", api_name, got, expected_hash);
                    return;
                }
            }
            printf("  [!] %-25s  NOT FOUND in EAT\n", api_name);
        };

        verify(hKernel32(), "VirtualAlloc",  HASH_VirtualAlloc);
        verify(hKernel32(), "GetSystemInfo", HASH_GetSystemInfo);
        verify(hUser32(),   "MessageBoxA",   HASH_MessageBoxA);
    }
    printf("\n");

    printf("============================================================\n");
    printf("  Done. Verify IAT with:\n");
    printf("    dumpbin /IMPORTS demo_iat.exe\n");
    printf("  The following should NOT appear:\n");
    printf("    MessageBoxA, VirtualAlloc, VirtualFree, GetSystemInfo\n");
    printf("============================================================\n");

    return 0;
}
