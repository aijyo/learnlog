// -----------------------------------------------------------------------
// config.h  —  AUTO-GENERATED, DO NOT EDIT
// Regenerate: python gen_config.py "RedTeam2024_Demo"
// Seed string : "RedTeam2024_Demo"
// Seed value  : 0x8B8BEBF3
// -----------------------------------------------------------------------
#pragma once
#include <cstdint>

#define CFG_SEED_STR  "RedTeam2024_Demo"
#define CFG_SEED      0x8B8BEBF3u

// user32.dll
#define HASH_MessageBoxA                       0x9434B9C0u
#define HASH_MessageBoxW                       0x9434B9D6u
// kernel32.dll
#define HASH_VirtualAlloc                      0x4A6E898Du
#define HASH_VirtualAllocEx                    0x9DCA63CAu
#define HASH_VirtualFree                       0xDAED4AC3u
#define HASH_VirtualProtect                    0xA8F69449u
#define HASH_OpenProcess                       0xC7C9AED8u
#define HASH_CreateRemoteThread                0x6FA07FD8u
#define HASH_WriteProcessMemory                0xD5204D9Cu
#define HASH_ReadProcessMemory                 0xB3FC7B85u
#define HASH_GetSystemInfo                     0x8A995D05u
#define HASH_GetCurrentProcess                 0xD7EE7782u
#define HASH_ExitProcess                       0x4BC9EF96u
#define HASH_LoadLibraryA                      0xA4CD0DC7u
#define HASH_GetProcAddress                    0xABBDCAD8u
// ntdll.dll
#define HASH_NtAllocateVirtualMemory           0x51AD3C3Bu
#define HASH_NtWriteVirtualMemory              0xFDC94B81u
#define HASH_NtCreateThreadEx                  0x39117700u

// Module name hashes (lowercased; used by PEB walk in resolve.h)
#define MOD_HASH_user32                        0x3711E923u
#define MOD_HASH_kernel32                      0x48AB9578u
#define MOD_HASH_ntdll                         0x2E56847Fu
