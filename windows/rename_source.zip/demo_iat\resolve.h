#pragma once
// resolve.h  —  Runtime API resolution via PEB walk + EAT hash matching (Level 4)
//
// What this gives you:
//   - find_module_by_hash(MOD_HASH_kernel32) — locate a loaded DLL without
//     calling GetModuleHandleA. Uses gs:[0x60]/fs:[0x30] -> PEB ->
//     InMemoryOrderModuleList. BaseDllName is hashed (lowercased) at runtime
//     against the constant from config.h.
//   - resolve_by_hash(mod, HASH_FuncName) — find an export by hashed name,
//     handling forwarders (e.g. kernel32!LoadLibraryA -> kernelbase!LoadLibraryA)
//     by recursively walking PEB+EAT in the forward target module.
//
// What's NOT in the resulting binary:
//   - "kernel32.dll" / "user32.dll" / "ntdll.dll" strings (mod_hash only)
//   - GetModuleHandleA / LoadLibraryA / GetProcAddress (we do it ourselves)
//   - Names of any APIs resolved through this header
//
// What may still be in the IAT:
//   - CRT runtime helpers (printf, etc — these are NOT in our targeted APIS list)
//   - The libraries this demo's GUI uses for window management (USER32, etc.)
//     are still imported, but those are benign Win32 APIs whose runtime use
//     would be observable anyway.

#include <windows.h>
#include <intrin.h>      // __readgsqword / __readfsdword
#include "hash.h"
#include "config.h"

// ─── PEB / LDR layout (minimal subset; stable from Win7 to Win11) ────────────

typedef struct _RH_UNICODE_STR {
    USHORT Length;        // bytes, not chars
    USHORT MaximumLength;
    PWSTR  Buffer;
} RH_UNICODE_STR;

typedef struct _RH_LDR_ENTRY {
    LIST_ENTRY     InLoadOrderLinks;
    LIST_ENTRY     InMemoryOrderLinks;   // <- list head points here
    LIST_ENTRY     InInitOrderLinks;
    PVOID          DllBase;
    PVOID          EntryPoint;
    ULONG          SizeOfImage;
    RH_UNICODE_STR FullDllName;
    RH_UNICODE_STR BaseDllName;
} RH_LDR_ENTRY;

typedef struct _RH_PEB_LDR {
    ULONG       Length;
    BOOLEAN     Initialized;
    PVOID       SsHandle;
    LIST_ENTRY  InLoadOrderModuleList;
    LIST_ENTRY  InMemoryOrderModuleList;
    LIST_ENTRY  InInitOrderModuleList;
} RH_PEB_LDR;

typedef struct _RH_PEB {
    BYTE        Reserved1[2];
    BYTE        BeingDebugged;
    BYTE        Reserved2[1];
    PVOID       Reserved3[2];            // Mutant, ImageBaseAddress
    RH_PEB_LDR* Ldr;                     // +0x18 on x64
} RH_PEB;

static __forceinline RH_PEB* _rh_peb() {
#ifdef _WIN64
    return reinterpret_cast<RH_PEB*>(__readgsqword(0x60));
#else
    return reinterpret_cast<RH_PEB*>(__readfsdword(0x30));
#endif
}

// ─── Module lookup: walk PEB.InMemoryOrderModuleList, match by hashed name ──

static HMODULE find_module_by_hash(uint32_t target_hash) {
    RH_PEB*     peb  = _rh_peb();
    RH_PEB_LDR* ldr  = peb->Ldr;
    LIST_ENTRY* head = &ldr->InMemoryOrderModuleList;

    for (LIST_ENTRY* cur = head->Flink; cur != head; cur = cur->Flink) {
        RH_LDR_ENTRY* e = CONTAINING_RECORD(cur, RH_LDR_ENTRY, InMemoryOrderLinks);
        if (!e->BaseDllName.Buffer) continue;
        if (mod_hash_w(e->BaseDllName.Buffer, CFG_SEED) == target_hash)
            return reinterpret_cast<HMODULE>(e->DllBase);
    }
    return nullptr;
}

// ─── EAT walk with forwarder handling ───────────────────────────────────────

static FARPROC resolve_by_hash(HMODULE mod, uint32_t target);   // fwd decl

// Parse "DllName.FunctionName" forwarder string, resolve through PEB.
// DllName is appended with ".dll" before hashing — same convention as
// MOD_HASH_kernel32 from gen_config.py.
static FARPROC _resolve_forwarder(const char* fwd) {
    const char* dot = nullptr;
    for (const char* p = fwd; *p; p++) if (*p == '.') { dot = p; break; }
    if (!dot) return nullptr;

    char dllname[64];
    size_t n = static_cast<size_t>(dot - fwd);
    if (n + 5 > sizeof(dllname)) return nullptr;
    for (size_t i = 0; i < n; i++) {
        char c = fwd[i];
        if (c >= 'A' && c <= 'Z') c += 32;
        dllname[i] = c;
    }
    // append ".dll\0" so the hash input matches gen_config.py's mod_hash("kernel32.dll", ...)
    dllname[n + 0] = '.';
    dllname[n + 1] = 'd';
    dllname[n + 2] = 'l';
    dllname[n + 3] = 'l';
    dllname[n + 4] = '\0';

    HMODULE target_mod = find_module_by_hash(mod_hash(dllname, CFG_SEED));
    if (!target_mod) return nullptr;
    return resolve_by_hash(target_mod, api_hash(dot + 1, CFG_SEED));
}

static FARPROC resolve_by_hash(HMODULE mod, uint32_t target) {
    if (!mod) return nullptr;

    auto* base = reinterpret_cast<const uint8_t*>(mod);
    auto* dos  = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return nullptr;

    auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return nullptr;

    const auto& exp_dd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    if (!exp_dd.VirtualAddress || !exp_dd.Size) return nullptr;

    auto* exp = reinterpret_cast<const IMAGE_EXPORT_DIRECTORY*>(base + exp_dd.VirtualAddress);

    auto* names     = reinterpret_cast<const DWORD*>(base + exp->AddressOfNames);
    auto* ordinals  = reinterpret_cast<const WORD* >(base + exp->AddressOfNameOrdinals);
    auto* functions = reinterpret_cast<const DWORD*>(base + exp->AddressOfFunctions);

    for (DWORD i = 0; i < exp->NumberOfNames; i++) {
        const char* name = reinterpret_cast<const char*>(base + names[i]);
        if (api_hash(name, CFG_SEED) == target) {
            DWORD fn_rva = functions[ordinals[i]];

            // Forwarder? funcRVA falls inside the export directory blob.
            if (fn_rva >= exp_dd.VirtualAddress &&
                fn_rva <  exp_dd.VirtualAddress + exp_dd.Size) {
                const char* fwd = reinterpret_cast<const char*>(base + fn_rva);
                return _resolve_forwarder(fwd);
            }
            return reinterpret_cast<FARPROC>(const_cast<uint8_t*>(base) + fn_rva);
        }
    }
    return nullptr;
}

// ─── Typed wrappers ─────────────────────────────────────────────────────────

template<typename Fn>
static Fn resolve(HMODULE mod, uint32_t hash) {
    return reinterpret_cast<Fn>(resolve_by_hash(mod, hash));
}

// Convenience: find module by hash AND resolve export in one call.
//   auto pVA = resolve<fn_VirtualAlloc>(MOD_HASH_kernel32, HASH_VirtualAlloc);
template<typename Fn>
static Fn resolve(uint32_t mod_hash_value, uint32_t fn_hash_value) {
    return reinterpret_cast<Fn>(
        resolve_by_hash(find_module_by_hash(mod_hash_value), fn_hash_value));
}
