#pragma once
// resolve.h  —  Runtime API resolution via EAT walking
//
// Resolves exported functions by pre-computed hash (from config.h).
// These APIs never appear in the IAT of the compiled binary.
//
// Limitation of this demo:
//   GetModuleHandleA / LoadLibraryA themselves ARE static imports.
//   A production-grade loader would also walk the PEB InLoadOrderModuleList
//   to find kernel32 without calling GetModuleHandleA at all.
//   That step is intentionally omitted here for readability.

#include <windows.h>
#include "hash.h"
#include "config.h"

// Walk the EAT of `mod` and return the function whose name hashes to `target`.
static FARPROC resolve_by_hash(HMODULE mod, uint32_t target) {
    if (!mod) return nullptr;

    auto* base = reinterpret_cast<const uint8_t*>(mod);
    auto* dos  = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return nullptr;

    auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return nullptr;

    const auto& exp_dd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    if (!exp_dd.VirtualAddress || !exp_dd.Size) return nullptr;

    auto* exp = reinterpret_cast<const IMAGE_EXPORT_DIRECTORY*>(base + exp_dd.VirtualAddress);

    auto* names     = reinterpret_cast<const DWORD*>(base + exp->AddressOfNames);
    auto* ordinals  = reinterpret_cast<const WORD* >(base + exp->AddressOfNameOrdinals);
    auto* functions = reinterpret_cast<const DWORD*>(base + exp->AddressOfFunctions);

    for (DWORD i = 0; i < exp->NumberOfNames; i++) {
        const char* name = reinterpret_cast<const char*>(base + names[i]);
        if (api_hash(name, CFG_SEED) == target) {
            DWORD fn_rva = functions[ordinals[i]];

            // Detect forwarded exports (RVA falls inside export section).
            // For demo simplicity we skip forwarded exports; they are rare
            // for the kernel32/user32 APIs targeted here.
            const auto& exp_end = exp_dd.VirtualAddress + exp_dd.Size;
            if (fn_rva >= exp_dd.VirtualAddress && fn_rva < exp_end)
                return nullptr; // forwarded — skip

            return reinterpret_cast<FARPROC>(const_cast<uint8_t*>(base) + fn_rva);
        }
    }
    return nullptr;
}

// Typed wrapper: resolve<fn_ptr_type>(module, HASH_ApiName)
template<typename Fn>
static Fn resolve(HMODULE mod, uint32_t hash) {
    return reinterpret_cast<Fn>(resolve_by_hash(mod, hash));
}
