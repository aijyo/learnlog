# TECHNICAL DESIGN — PE 反指纹工具链

> 本文是 `rename/` 项目的完整技术参考。所有概念、字节级原理、可迁移到其他 EXE 的步骤都在这里。
>
> 受众:Windows 安全研究员 / 恶意软件分析师 / 红队工具开发者。

---

## 目录

1. [项目动机和威胁模型](#1-项目动机和威胁模型)
2. [整体架构](#2-整体架构)
3. [demo_iat — IAT 动态化(编译期)](#3-demo_iat--iat-动态化编译期)
4. [patchtool — PE 元数据 patch(后处理)](#4-patchtool--pe-元数据-patch后处理)
5. [pediff — 验证工具](#5-pediff--验证工具)
6. [hashlab — 哈希实验](#6-hashlab--哈希实验)
7. [限制和已知问题](#7-限制和已知问题)
8. [迁移到你自己的 EXE](#8-迁移到你自己的-exe)
9. [参考:PE 结构和算法](#9-参考pe-结构和算法)

---

## 1. 项目动机和威胁模型

### 1.1 问题

一个普通 C/C++ 编译的 Win32 EXE,**未经处理**前在静态扫描器眼里有以下"廉价指纹":

| 指纹 | 来源 | 检测者用它做什么 |
|---|---|---|
| **MD5 / SHA-1 / SHA-256** | 整个文件字节 | 已知样本黑名单 |
| **imphash** | Import 表内容+顺序 → MD5 | 家族聚类(同样的 import 集合 → 同一家族) |
| **Rich Header** | MS 编译器/链接器嵌入的工具版本指纹 | 编译环境聚类 |
| **TimeDateStamp** | 链接器时间戳 | 时间相关性 / 攻击者作息 |
| **PDB 路径(Debug Dir)** | 调试信息 | 项目路径泄漏(`C:\Users\Bob\proj\…`)、commit hash |
| **节名 (.text/.rdata/...)** | 编译器默认 | 工具链识别(rust、go、UPX 等) |
| **Authenticode 签名** | 签发方 + 哈希 | 签发方信誉 + tampering 检测 |
| **明文 API 名/字符串** | `dumpbin /IMPORTS` + `strings` | YARA / capa 规则、行为预判 |

一份"裸"程序拿到 VirusTotal,这些指标合起来基本就把它"摆桌面上"了。

### 1.2 威胁模型

- **静态扫描器**(看 PE 的 byte / 表结构,不真跑):基本上能被这套工具绕过。
- **行为 EDR**(钩 API + 看运行时行为):**绕不过**——这套工具完全不动运行时行为。
- **AI / heuristic 分类器**:看具体喂什么特征。指纹改了 → 部分特征值变,但可能保留 entropy / opcode pattern 等高阶特征。
- **人工逆向**:**完全没影响**——他们看 disassembly 不看 IAT。

> **结论**:这套工具是"反静态分类"工具,不是"杀软绕过工具"。预期场景是研究、CTF、授权渗透中的载荷多态;不是真实攻击规模化武器化。

### 1.3 设计哲学

| 原则 | 体现 |
|---|---|
| **种子驱动确定性** | 同一个 seed → 同一份输出。便于 reproducible builds 和变体管理 |
| **静态指纹改;运行时不动** | 不引入 ETW evasion、不 unhook、不打 syscall stub。降低意外破坏 |
| **`/MT` 静态独立 exe** | 拷到任何无开发环境的机器都能直接跑 |
| **单文件可编译** | 每个 demo 一个 .cpp,头文件最少;砍 CMake 后用 `cl.exe` 一行也能 build |
| **可验证** | `pediff_ui` 让你**亲眼看到**改了哪些字节,而不是"信我" |

---

## 2. 整体架构

```
       ┌─────────────────────────────────────────────────────────┐
       │                  rename toolchain                       │
       └─────────────────────────────────────────────────────────┘

  ┌─────────────┐                          ┌─────────────────┐
  │   你的源码   │                          │ 已编译的 PE 文件 │
  │   .cpp/.h   │                          │  release.exe    │
  └──────┬──────┘                          └────────┬────────┘
         │                                          │
         │  编译期手法                              │  后处理手法
         │ (源码改动 + 头文件)                      │ (二进制改写)
         ▼                                          ▼
  ┌─────────────┐                          ┌─────────────────┐
  │   demo_iat  │                          │    patchtool    │
  │  hash.h     │                          │ Rich/TS/Section/│
  │  strenc.h   │                          │  Debug/Sig/Imp/ │
  │  resolve.h  │                          │  Checksum       │
  │  config.h ←─── gen_config.py (seed)    │       ↑         │
  │             │                          │       │ seed    │
  └──────┬──────┘                          └───────┴─────────┘
         │                                          │
         ▼                                          ▼
  ┌────────────────────────────────────────────────────────────┐
  │            patched.exe (IAT 干净 + 元数据洗过)             │
  └────────────────────────────────────────────────────────────┘
                              │
                              │   验证 / 实验
                              ▼
                ┌──────────────────────────┐
                │   pediff_ui    hashlab_ui│
                │ 字节级 diff   多哈希算法 │
                │ 5 个 tab      碰撞查找   │
                └──────────────────────────┘
```

**两条路径互补**:

| 场景 | 用哪个 |
|---|---|
| 你**有源码**,刚要写 / 重编 | `demo_iat`(把目标 API 从源头藏起来) |
| 拿到第三方 EXE,**不能重编** | `patchtool`(后处理改元数据) |
| **生产**变体(每个 target 一份不同的 fingerprint) | 两个都用,先 `demo_iat` 编译,再 `patchtool` 后处理(每个 target 不同 seed) |

---

## 3. demo_iat — IAT 动态化(编译期)

### 3.1 目标

让 `MessageBoxA` / `VirtualAlloc` / `CreateRemoteThread` 等敏感 API 名**不出现在 `dumpbin /IMPORTS`** 输出里。同时 DLL 名字符串(`kernel32.dll` 等)也不能明文落在 `.rdata`。

### 3.2 技术栈(4 个文件)

```
hash.h        ← ROR-13 哈希函数 + djb2 seed-fold
strenc.h      ← 编译期 XOR 字符串加密(constexpr)
resolve.h     ← 运行期 EAT walk + 哈希匹配
gen_config.py ← 用 seed 生成 HASH_xxx 常量到 config.h
config.h      ← 自动生成,被以上 3 个 .h 引用
```

### 3.3 ROR-13 哈希(`hash.h`)

```cpp
static inline uint32_t api_hash(const char* name, uint32_t seed) {
    uint32_t h = seed;
    while (*name) {
        h = ror32(h, 13);      // 循环右移 13 位
        h += (uint8_t)*name++; // 累加每个 char
    }
    return h;
}
```

经典的 Stephen Fewer 算法,reflective DLL injection / Metasploit migrate stub 都在用。

**为什么是 ROR-13 而不是 MD5**:
- 32-bit 输出 → 一个 `cmp eax, imm32` 指令搞定匹配
- 无依赖 → 不需要拉 BCrypt / OpenSSL
- 雪崩性"够用"——对 EAT 里几千个名字基本不会冲突

**seed 怎么进来**: `gen_config.py` 把 `"YourSeed"` 用 djb2 折叠成 32-bit,作为 `CFG_SEED` 写进 `config.h`。每次 `api_hash` 都从这个 seed 出发,**改 seed → 所有 HASH_* 常量全变**,二进制层面的 hash 常量完全洗一遍。

### 3.4 编译期字符串加密(`strenc.h`)

DLL 名 `kernel32.dll` 也不能明文进 binary。`strenc.h` 用 `constexpr` 把字符串编译期 XOR,运行时栈上解密:

```cpp
ESTR_BUF(n, "kernel32.dll");      // 宏展开:
//   static constexpr _EStr<13> _enc_n("kernel32.dll");  ← .rdata 里只有密文
//   _Dec<13> n(_enc_n);                                 ← 栈上构造时解密
LoadLibraryA(n);                  // 用法和 const char* 一样
```

XOR key 由 seed 派生(`_enc_fold`):

```cpp
// 用 seed 字符串折叠出一个 8-bit key (acc 初始 0x5A,每 char 循环左移 3 后 XOR)
constexpr uint8_t ESTR_KEY = _enc_fold(CFG_SEED_STR);

// 每字节用滚动 key 加密
enc[i] = plain[i] ^ (uint8_t)(ESTR_KEY + (uint8_t)i)
```

**为什么用滚动 key 而不是固定 key**:固定 key 让密文里同样的明文 char 产生同样的密文 byte,strings/熵分析容易识破。`KEY + i` 让密文看起来更随机。

### 3.5 运行期 EAT walk(`resolve.h`)

```cpp
static FARPROC resolve_by_hash(HMODULE mod, uint32_t target) {
    // 1. 走 IMAGE_DOS_HEADER → IMAGE_NT_HEADERS → DataDir[0] (Export)
    // 2. 拿到 IMAGE_EXPORT_DIRECTORY 的 names / ordinals / functions 三数组
    // 3. 遍历 names[]:对每个 name 算 api_hash(name, CFG_SEED)
    // 4. 匹配 target 哈希 → 返回 base + functions[ordinals[i]]
    // 5. 跳过 forwarder(funcRVA 落在 export dir 范围内)
}

template<typename Fn>
static Fn resolve(HMODULE mod, uint32_t hash);   // 类型安全封装
```

**调用示例**:

```cpp
HMODULE k32 = GetModuleHandleA(/* "kernel32.dll" 经 ESTR_BUF 解密 */);
auto pVA = resolve<fn_VirtualAlloc>(k32, HASH_VirtualAlloc);
LPVOID m = pVA(nullptr, 0x1000, MEM_COMMIT, PAGE_READWRITE);
```

最后产物的 IAT 里既没有 `VirtualAlloc` 名字、也没有 `kernel32.dll` 字符串。

### 3.6 一个完整的反指纹链

```
源码: pVA = resolve<fn_VirtualAlloc>(k32, HASH_VirtualAlloc);

编译期:
  gen_config.py "MySeed" 算出 api_hash("VirtualAlloc", djb2("MySeed")) = 0x4A6E898D
  生成 #define HASH_VirtualAlloc 0x4A6E898Du 到 config.h
  代码里只剩 cmp 一个 0x4A6E898D 常量,没有 "VirtualAlloc" 字符串

运行时:
  EAT walk kernel32 的导出表,遍历几千个名字
  对 "VirtualAlloc" 算 api_hash → 0x4A6E898D,匹配 → 返回真实地址

静态分析:
  dumpbin /IMPORTS:没有 VirtualAlloc
  strings:没有 "VirtualAlloc",没有 "kernel32.dll"
  IAT:只有 GetModuleHandleA(用来引导 EAT walk)
```

### 3.7 demo_iat_ui 的 UI

5 个区:
1. Build-time info:显示 seed、CFG_SEED、ESTR_KEY
2. API 表:8 个 API × (Name / DLL / Expected Hash / Address / Status)
3. Action 按钮:Resolve → Call MessageBoxA → Call VirtualAlloc → Call GetSystemInfo → Hash Cross-check
4. 加密字符串展示:DLL 名的密文字节(以 hex)
5. Log

**Hash Cross-check** 按钮值得专门讲:它在运行时重新算 `api_hash("VirtualAlloc", CFG_SEED)`,确认结果 == `HASH_VirtualAlloc`。这是验证 `gen_config.py` 和 `hash.h` 算法一致性的 sanity check —— 改任何一边都会 cross-check 失败。

---

## 4. patchtool — PE 元数据 patch(后处理)

### 4.1 7 类改动详解

每种改动的 PE 字节级精确位置 + 公式:

#### 4.1.1 Rich Header(不用 seed)

**位置**:DOS 头之后、PE 头之前(`e_lfanew` 之前)。MS 链接器在这里塞了一段包含工具链版本、obj 数量的"富信息"。

**算法**:
1. 从 `0x40` 起,4 字节对齐扫描 `'Rich'` 标记(`0x68636952` LE)
2. 找到后,后面 4 字节是 XOR key
3. 用 key XOR `'DanS'`(`0x536e6144`)得到搜索目标
4. 从前往后找这个 dans^key 值,定位 Rich Header 起点
5. 把这一段(`start` 到 `'Rich'+4`)整段清零

**效果**:VirusTotal 的 `pe_rich_hash` 字段消失;工具链识别不出来。

#### 4.1.2 TimeDateStamp(用 seed)

**位置**:`IMAGE_FILE_HEADER.TimeDateStamp` —— 文件偏移 = `e_lfanew + 4 + 4`(NT signature + Machine字段之后),**4 字节**。

**公式**:
```cpp
constexpr uint32_t BASE = 1262304000u;   // 2010-01-01 UTC
constexpr uint32_t SPAN =  441676800u;   // ≈ 14 年
new_ts = BASE + (seed % SPAN);
```

落到 2010-2023 区间随机一个时间戳。看起来像正常发布。

#### 4.1.3 Section Names(用 seed)

**位置**:Section table 里每个 `IMAGE_SECTION_HEADER.Name[8]` 字段。Section table 紧跟在 Optional Header 后。

**公式**:每个节用 LCG 派生一个 32-bit 随机数,挑 4 个字符:
```cpp
uint32_t rng = seed ^ 0xDEADC0DE;
for each section:
    uint32_t r = lcg(rng);    // rng = rng * 1664525 + 1013904223
    name[0] = '.'
    name[1] = "bcdfghjklmnpqrstvwxz"[(r      ) % 20]   // 辅音
    name[2] = "aeiou"           [(r >>  8) %  5]        // 元音
    name[3] = "bcdfghjklmnpqrstvwxz"[(r >> 16) % 20]
    name[4] = "aeiou"           [(r >> 24) %  5]
```

输出:`.text → .bovu`、`.rdata → .ozak`(辅元辅元,可发音,看着不像伪造)。

**注意**:节名变了**不影响代码执行**,因为 RVA-to-section 查询是按 VA 范围,不按名字。但有些奇葩的运行时 hack(比如某些 protector 找 `.text` 名字)会失效——主流商业软件不靠节名。

#### 4.1.4 Debug Directory(不用 seed)

**位置**:`OptionalHeader.DataDirectory[6]` (`IMAGE_DIRECTORY_ENTRY_DEBUG`)。

**算法**:
1. 遍历每个 `IMAGE_DEBUG_DIRECTORY` 条目
2. 对每个条目的 `PointerToRawData` 指向的数据(通常是 `RSDS` 记录,包含 PDB GUID + 路径)整段清零
3. 把 entry 自己的 `PointerToRawData` / `AddressOfRawData` / `SizeOfData` 清零

**效果**:`C:\Users\Bob\dev\myproject\Release\foo.pdb` 这种路径消失;CV GUID 也没了。

#### 4.1.5 Authenticode Signature(不用 seed)

**位置**:`OptionalHeader.DataDirectory[4]` (`IMAGE_DIRECTORY_ENTRY_SECURITY`)。**特殊**:这个 `VirtualAddress` 字段实际是**文件偏移**,不是 RVA。

**算法**:
1. 读 `dd.VirtualAddress`(其实是 file offset)和 `dd.Size`
2. 文件那段整段清零
3. 把 `VirtualAddress` 和 `Size` 都清零

**效果**:`sigcheck` / `signtool verify` 全说"unsigned"。

#### 4.1.6 Reorder Imports(用 seed)— v2 新加

**位置**:`OptionalHeader.DataDirectory[1]` 指向的 `IMAGE_IMPORT_DESCRIPTOR` 数组。每个 entry 20 字节(5×DWORD)。

**算法**(Fisher-Yates):
```cpp
uint32_t rng = seed ^ 0xCAFEBABE;
for (int i = n - 1; i > 0; i--) {
    uint32_t r = lcg(rng);
    int j = (int)(r % (i + 1));
    if (i != j) swap(imp[i], imp[j]);    // 整个 descriptor swap
}
```

**为什么安全**:每个 descriptor 内部有自己的 `OriginalFirstThunk` / `FirstThunk` RVA,指向自己的 thunk 数组。loader 遍历 descriptor 是按顺序、无状态的,任何顺序都正确解析。代码引用 IAT slot 是按**绝对 RVA**,跟 descriptor 顺序无关。

**为什么 imphash 变**:`pefile.get_imphash()` 按文件顺序遍历 descriptors,把它们的 import 拼成 `"kernel32.foo,user32.bar,..."` 字符串再 MD5。顺序变 → 字符串不同 → MD5 不同。

#### 4.1.7 Checksum(不用 seed,但必须最后做)

**位置**:`OptionalHeader.CheckSum`,4 字节。

**算法**:MS PE 规范的 16-bit accumulator + 末尾加 size:
```cpp
ctx.checksum() = 0;            // 先清零,因为 checksum 不能算自己
sum = sum_of_uint16_words_with_fold_carry
if (size_odd) sum += last_byte
sum = (sum >> 16) + (sum & 0xFFFF) + size
ctx.checksum() = sum
```

**为什么放最后**:其他 6 步都改了文件内容,checksum 自然要重算。loader 检 checksum 不严(用户态 PE 大部分根本是 0),但**驱动 / 关键系统 PE 强制检**。

### 4.2 patchtool_ui 的 UI

5 区:
1. 文件输入(Input / Output / Seed)
2. Before / After 双面板(并排显示 PE 摘要)
3. 6 个 checkbox + 1 个 Reorder Imports checkbox(v2)
4. Dry Run / PATCH EXE / Clear Log
5. Log

**Dry Run** 极有用:跑完整 patch 流程,显示所有改动到 After 面板,但不写文件。给你看一眼"如果按这个 seed 跑,会变成什么样",再决定是不是 commit。

### 4.3 CLI

```powershell
patchtool.exe --seed "Variant-A" `
    --input release.exe --output patched.exe `
    --verbose --reorder-imports
```

完整 flag:
- `--seed <str>` 必填
- `--input <path>` 必填
- `--output <path>` 默认 `patched_<input>`
- `--verbose` 每步详细
- `--dry-run` 不写文件
- `--skip-sections` 不改节名
- `--skip-timestamp` 不改 TS
- `--reorder-imports` 启用 v2 import 重排

---

## 5. pediff — 验证工具

### 5.1 为什么需要

patchtool 改完拿到 patched.exe,你怎么知道:
- 它**真**改了想改的字段?(可能是空 path / 跳过了某步)
- 它**只**改了想改的字段,没意外踩到代码段?
- 改完 imphash **真**变了?(reorder-imports 工作了?)
- IAT 没动?(功能未损?)

`dumpbin /HEADERS` + `diff` 能给一部分答案,但效率低、容易漏。`pediff_ui` 一键搞定:

### 5.2 5 个 Tab

| Tab | 内容 | 用法 |
|---|---|---|
| **Hashes** | MD5 / SHA-1 / SHA-256 / **imphash** 双侧并排 | 看 imphash 改没改;看 MD5 这种全文件 hash 有差异 |
| **Headers** | DOS / File / Optional / DataDir 全部字段 field-by-field 比对(~50 行) | 精确确认 TimeDateStamp / CheckSum 这些字段是不是按预期变了 |
| **Sections** | 每个节的 Name / VA / RSize / Characteristics 双侧对比 | 看节名是不是真随机化了 |
| **Diff regions** | 字节级 diff 区域,合并 ≤8 字节的小相同段 | 看 patch 是不是只改了**预期范围**——如果意外改了代码段会立刻显现 |
| **Imports** | 排序后的 `dll.fn` 集合并集 + 状态(SAME/ADDED/REMOVED) | 关键:**应该全 SAME**,否则 patchtool 出了 bug(可能破坏程序) |

### 5.3 染色规则

NM_CUSTOMDRAW 自定义:
- 🟢 浅绿:SAME 行
- 🔴 浅红:DIFF 行

一眼看到改动密度。

### 5.4 实现亮点

- **MD5/SHA**:用 `BCrypt`(系统自带,无第三方依赖)。函数 `bcrypt_hex()`。
- **imphash**:自实现 pefile 算法,逻辑同 §4.1.6——遍历 descriptors,小写 dll 名+stripping `.dll`/`.sys`/`.ocx`/`.drv` 扩展,ordinal 转 `ord%d`,逗号拼接,MD5。
- **字节 diff**:O(N) 单次扫描,bridge gap 8(跳过 ≤8 字节的相同段,合并 diff 区域),上限 1000 区域。
- **Imports diff**:把两侧 imports 各自 sort,做 sorted-merge 找 ADDED/REMOVED/SAME。
- **Tab 切换**:5 个 ListView 同位置叠放,`ShowWindow(SW_SHOW/SW_HIDE)` 切换。

---

## 6. hashlab — 哈希实验

### 6.1 为什么需要

`demo_iat` 用了 ROR-13。但**其他家族用什么**?如果你是分析师,看到一个 binary 在做 EAT walk + 哈希匹配,你怎么识别它用的算法?如果你是开发者,想换个算法以避开已有签名,选哪个?`hashlab` 是参数空间探索器。

### 6.2 4 大功能

#### 6.2.1 算法矩阵

6 种算法 × 你输入的 API 名列表 = 矩阵 ListView:

| API | ROR-13 | FNV-1a | djb2 | sdbm | CRC32 | Murmur3 |
|---|---|---|---|---|---|---|
| MessageBoxA | 0xXX... | 0xYY... | ... | | | |
| VirtualAlloc | ... | | | | | |

改 seed 串 → 矩阵实时刷(再点 [Hash all])。

**教学价值**:直观看到同一个 `LoadLibraryA` 在 6 个算法下产出 6 个完全不同的 32-bit 常量。这就是**为什么逆向时必须先识别算法**——拿一个未知算法的常量去查表是查不到的。

#### 6.2.2 Collision finder

输入:目标哈希(hex)+ 算法 + 最大长度(1-8)+ 字符集(alpha-lower / mixed / alphanumeric / printable)。

Brute-force 5000 万次为上限。找到一个 `hash(s, seed) == target` 的 `s`。

**用途**:
- 红队:伪造一个看起来无害的字符串,其哈希撞上一个内部已知的 API 哈希常量
- 蓝队:理解某个家族的哈希算法的"碰撞难度"——是雪崩的强算法,还是容易撞的弱算法

#### 6.2.3 Export config.h

选种子 + 算法 → 一键 emit 完整的 `config.h` 文本到 Log。直接拷贝粘贴覆盖 `demo_iat/config.h`,等于 GUI 化的 `gen_config.py`(且支持任意算法,不只 ROR-13)。

```
// Algorithm   : ROR-13
// Seed string : "MyCustom"
// Seed value  : 0xXXXXXXXX
#define CFG_SEED_STR  "MyCustom"
#define CFG_SEED      0xXXXXXXXXu
#define HASH_MessageBoxA      0xYYYYYYYYu
...
```

#### 6.2.4 String XOR preview

输入 plaintext,GUI 显示用当前 seed 派生的 `ESTR_KEY` 加密后的密文字节(hex)+ 往返校验。

完全镜像 `strenc.h` 的 `_enc_fold + (key + i)` XOR 算法。

#### 6.2.5 Imphash collision(v2 新加)

输入:base imports(几行 `dll!fn`)+ candidate decoys(几行 `dll!fn`)+ target imphash 前缀(2-16 hex chars)。

Brute-force 子集(2^N ≤ 16M):在 candidates 里挑一个子集,加到 base 上,算 MD5(逗号拼字符串),看是否前缀匹配。

**用途**:演示 imphash 作为指纹的**不稳定性**——只要往 IAT 加几个无害的 decoy import(`ws2_32!htons` 之类),imphash 立刻不一样。配合较长的目标前缀,可以做 "**让我的 imphash 撞上某个良性程序**" 的 evasion 演示。

**注意**:这只是教学演示。要真撞**完整** 128-bit imphash 需要 2^64 attempts(birthday),不可行。撞 16-bit / 24-bit 前缀就是分钟级。

---

## 7. 限制和已知问题

### 7.1 这套工具**不能**做的事

1. **行为级 EDR 绕过**:本工具完全不动运行时行为。`VirtualAlloc(MEM_COMMIT|PAGE_EXECUTE_READWRITE)` 一旦真在内存里画一块可执行区域,Win Defender / CrowdStrike / Carbon Black 还是会 flag。
2. **ETW / AMSI / 内核回调 bypass**:同上。
3. **YARA 规则全绕过**:规则可以基于任何字段——opcode 模式、entropy、节大小等。本工具改的只是少数静态字段。
4. **Authenticode hash 篡改**:authentihash 算法故意排除 checksum 和 security data dir。所以它对本工具的改动**确实免疫**——但我们也不需要在意 authentihash,因为这套工具假设输出是**未签名**的(签名都被 patch 清了)。
5. **运行时 unhook**:如果 EDR 已经在 ntdll 里下了 inline hook,本工具不解决。

### 7.2 demo_iat 当前的具体局限

1. **不处理 forwarder**:`LoadLibraryA` 在 Win10/11 上大概率从 kernel32 forward 到 kernelbase。`resolve.h` 第 47 行检测到 forwarder 直接 return nullptr。修法见 `D:\code\work\research\windows\demos\peb-eat-resolve\` 那个 demo 里有完整 forwarder 解析(递归走 PEB 找目标 DLL 再走它的 EAT)。
2. **仍依赖 GetModuleHandleA / LoadLibraryA**:这两个函数本身还在 IAT 里——`demo_iat_ui.exe` 的 IAT 仍有 `LoadLibraryA`、`GetModuleHandleA`。要全部彻底抽离,需要从 PEB 走 `InMemoryOrderModuleList` 直接拿模块基址。同样见 `peb-eat-resolve` demo。
3. **运行时计算 hash 的代码本身有 ROR-13 模式**:capa 之类的工具会识别"32-bit hash + EAT 遍历"作为 indicator。算法选择会影响识别率(Murmur 比 ROR-13 难识别)。

### 7.3 patchtool 当前的具体局限

1. **修改"已绑定 import" (bound import)**:不常见,但某些预绑定的二进制改 descriptor 顺序可能让 bound import dir 失效。`patchtool` 不修 bound import dir,但程序若依赖它会重新绑定(无害但慢)。
2. **没改 manifest**:嵌入 manifest 资源(`.rsrc/RT_MANIFEST`)还能泄漏一些指纹(运行时兼容性声明、UAC 级别)。未来可加。
3. **TLS 回调函数表没动**:某些样本把"真"逻辑放在 TLS callback 里。本工具不动 TLS dir。
4. **没改资源段中的版本信息**:`VS_VERSION_INFO` 里有版权字符串、文件描述、产品名等,这些都进 `.rsrc`。当前不处理。

### 7.4 imphash 的本质局限

imphash 是个**信噪比 50/50 的指纹**。VirusTotal/Mandiant 用它做家族聚类是因为**改 imphash 比改 MD5 难**(导入表内容/顺序约束于实际功能需求,不能瞎改)。本工具的 reorder-imports 撕开了"顺序"这一层,但**真正聪明的检测者会用 sorted-imphash**(把 imports 排序后再 MD5),那就抗 reorder 了。所以 reorder 是"打 imphash 这种特定工具的洞",不是"抗所有 import-based 指纹"。

---

## 8. 迁移到你自己的 EXE

### 8.1 场景 A:你有源码,要编一个新的反指纹 EXE

**步骤**:

1. 把以下 4 个文件从 `demo_iat/` 拷到你的项目:
   ```
   gen_config.py
   hash.h
   strenc.h
   resolve.h
   ```

2. 编辑 `gen_config.py`,把你要藏的 API 列表加进 `APIS[]`:
   ```python
   APIS = [
       ("kernel32.dll", "VirtualAlloc"),
       ("kernel32.dll", "CreateRemoteThread"),
       ("kernel32.dll", "OpenProcess"),
       # 加你的:
       ("ws2_32.dll",   "connect"),
       ("ws2_32.dll",   "send"),
       ("wininet.dll",  "InternetOpenA"),
   ]
   ```

3. 在你的源码里:
   ```cpp
   #include "config.h"     // 必须先 include
   #include "hash.h"
   #include "strenc.h"
   #include "resolve.h"

   // 在调用点:
   ESTR_BUF(k32_name, "kernel32.dll");
   HMODULE k32 = GetModuleHandleA(k32_name);
   auto pVA = resolve<fn_VirtualAlloc>(k32, HASH_VirtualAlloc);
   void* mem = pVA(nullptr, 0x1000, MEM_COMMIT, PAGE_READWRITE);
   ```

4. 编译前先跑 `python gen_config.py "YourSeed" config.h` 生成 `config.h`。或者 CMake 化(参考本项目的 `demo_iat/CMakeLists.txt`)。

5. 编译完检查:
   ```powershell
   dumpbin /IMPORTS your.exe | findstr /i "VirtualAlloc CreateRemoteThread"
   ```
   应该看不到这些 API。`strings your.exe` 也应该看不到 `kernel32.dll`。

6. **每个版本/客户用不同 seed**:
   ```powershell
   python gen_config.py "ClientA_2024" config.h && cmake --build ...
   python gen_config.py "ClientB_2024" config.h && cmake --build ...
   ```
   两份 EXE 完全不一样的 hash 常量、不一样的密文字节。

### 8.2 场景 B:已有 EXE,不能重编

**步骤**:

1. 拷一份原始 EXE 到工作目录(不要动原件)
2. 用 `patchtool.exe`:
   ```powershell
   output\patchtool.exe `
       --seed "Variant-X" `
       --input  copy.exe `
       --output patched.exe `
       --reorder-imports `
       --verbose
   ```
3. 用 `pediff_ui.exe` 对比 `copy.exe` 和 `patched.exe`,确认:
   - **Imports tab 全 SAME**(没破坏功能)
   - **Hashes tab MD5/SHA/imphash 全 DIFF**
   - **Headers tab TimeDateStamp / Checksum DIFF**
   - **Sections tab Name 列 DIFF**
4. 跑一下 `patched.exe`,确认行为和原来一致

**生产变体**:
```powershell
foreach ($i in 1..100) {
    output\patchtool.exe --seed "Variant-$i" --input src.exe --output "out\v$i.exe" --reorder-imports
}
# 100 份 hash / TimeStamp / 节名 / imphash 全部不同的 EXE,行为相同。
```

### 8.3 场景 C:混合(推荐用于多客户分发)

**步骤**:
1. 编译期用 `demo_iat`(场景 A),让基础 EXE 已经 IAT 干净
2. 后处理期用 `patchtool`(场景 B),给每个客户/target 配不同 seed → 每份的 timestamp / 节名 / import 顺序 / checksum 都不同

每份变体:
- IAT 没有敏感 API(场景 A 给的)
- imphash 各不相同(场景 B 的 reorder-imports)
- TimeDateStamp 各不相同
- 节名各不相同
- MD5 / SHA-256 各不相同

但是**功能完全一致**,行为一模一样。

### 8.4 跨工程移植 `resolve.h` 的注意点

`resolve.h` 当前实现假设:
- x64 PE(它读 `IMAGE_NT_HEADERS`,在 x64 上是 `_HEADERS64`)
- 目标 DLL 已经加载在进程里(用 `GetModuleHandleA` 拿 handle,需要先 LoadLibrary)
- 目标 API **不是 forwarder**(forwarder 时返回 nullptr)

x86 移植:`IMAGE_NT_HEADERS` 在 x86 是 `_HEADERS32`。改 `resolve.h` 用条件编译或 template 化。

Forwarder 处理:见 `D:\code\work\research\windows\demos\peb-eat-resolve\` 的 `resolve_forwarder()` 函数。直接拷过来就行。

---

## 9. 参考:PE 结构和算法

### 9.1 关键 PE 字段速查

| 字段 | 偏移(相对) | 大小 | 用途 |
|---|---|---|---|
| `IMAGE_DOS_HEADER.e_magic` | 0x00 | 2 | `"MZ"` |
| `IMAGE_DOS_HEADER.e_lfanew` | 0x3C | 4 | `IMAGE_NT_HEADERS` 偏移 |
| `IMAGE_NT_HEADERS.Signature` | e_lfanew | 4 | `"PE\0\0"` |
| `IMAGE_FILE_HEADER.Machine` | +4 | 2 | 0x8664 = x64,0x14C = x86 |
| `IMAGE_FILE_HEADER.NumberOfSections` | +6 | 2 | 节数 |
| `IMAGE_FILE_HEADER.TimeDateStamp` | +8 | 4 | **patchtool 改这里** |
| `IMAGE_FILE_HEADER.SizeOfOptionalHeader` | +16 | 2 | x64 上 0xF0,x86 上 0xE0 |
| `IMAGE_FILE_HEADER.Characteristics` | +18 | 2 | EXE / DLL / SYS 等 flag |
| `IMAGE_OPTIONAL_HEADER64.AddressOfEntryPoint` | +20 | 4 | EP RVA |
| `IMAGE_OPTIONAL_HEADER64.CheckSum` | +64 | 4 | **patchtool 改这里** |
| `IMAGE_OPTIONAL_HEADER64.DataDirectory[]` | +112 | 16×8 | 16 个 (RVA, Size) 二元组 |
| `IMAGE_SECTION_HEADER.Name[8]` | 紧跟 optional header | 8 | **patchtool 改这里** |

DataDirectory 索引:

| 索引 | 名字 | 用途 |
|---|---|---|
| 0 | Export | EAT (`demo_iat` 走它) |
| 1 | Import | IAT (`patchtool reorder-imports` 改它) |
| 2 | Resource | `.rsrc` |
| 4 | Security | Authenticode (`patchtool` 清它) |
| 5 | BaseReloc | 重定位 |
| 6 | Debug | PDB info (`patchtool` 清它) |
| 12 | IAT | IAT 整体范围(loader 用) |
| 13 | DelayImport | 延迟加载 import |

### 9.2 哈希算法速查

#### ROR-13(`hash.h` 用)

```c
h = seed
for c in name:
    h = ((h >> 13) | (h << 19)) & 0xFFFFFFFF  // 循环右移 13
    h = (h + ord(c)) & 0xFFFFFFFF
```

雪崩性中等,32-bit 输出,无表无依赖。

#### djb2(seed-folding 用)

```c
h = 5381
for c in s:
    h = ((h << 5) + h) ^ ord(c)   // = h * 33 ^ c
```

#### FNV-1a 32

```c
h = 0x811C9DC5
for c in s:
    h = h ^ ord(c)
    h = (h * 0x01000193) & 0xFFFFFFFF
```

#### sdbm

```c
h = 0
for c in s:
    h = ord(c) + (h << 6) + (h << 16) - h
```

#### CRC32 (IEEE)

```c
h = 0xFFFFFFFF
for c in s:
    h ^= ord(c)
    for _ in range(8):
        h = (h >> 1) ^ (0xEDB88320 if (h & 1) else 0)
return ~h
```

#### MurmurHash3 32

复杂——见 `hashlab_ui.cpp::hash_mm3`。约 30 行代码,有 32-bit 块处理 + tail + finalization mixing。

### 9.3 imphash 算法精确定义

```python
# pefile 的 get_imphash() 实现等价:
parts = []
for desc in import_descriptors_in_file_order:
    dll = desc.name.lower()
    if dll.endswith(('.dll', '.sys', '.ocx', '.drv')):
        dll = dll.rsplit('.', 1)[0]
    for thunk in desc.thunks_in_order:
        if thunk.by_ordinal:
            fn = ordinal_lookup_table.get(dll, thunk.ord) or f"ord{thunk.ord}"
        else:
            fn = thunk.name.lower()
        parts.append(f"{dll}.{fn}")
return md5(','.join(parts).encode()).hexdigest()
```

**关键**:
- DLL 名小写,strip 几种扩展名
- 函数名小写
- ordinal 转 `ord%d`(对部分 well-known DLL 有 ordinal→name 反查表,但对未知 DLL 直接用 ord%d)
- **按文件中出现顺序遍历**(不排序)→ 这就是为什么 reorder-imports 起作用

### 9.4 LCG 参数

`patchtool` 和 `hashlab` 共用一个简单 LCG:

```c
uint32_t lcg(uint32_t &state) {
    state = state * 1664525u + 1013904223u;
    return state;
}
```

这是 Numerical Recipes 推荐的"minimum standard"参数(实际叫 Park-Miller-Lehmer 的兄弟版本)。周期 2^32,雪崩中等,对随机化 4 字节节名 / 选 import 顺序绰绰有余。**不要**用它做密码学。

---

## 附录:常用命令速查

```powershell
# 全量 build
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target rename_all

# 改 seed 重 build demo_iat
cmake -B build -DSEED_STRING="NewSeed"
cmake --build build --config Release --target demo_iat_ui

# 静态分析 patched EXE
dumpbin /IMPORTS  output\demo_iat_ui.exe   # 应无 MessageBoxA / VirtualAlloc
dumpbin /HEADERS  output\demo_iat_ui.exe   # 看 TimeDateStamp / sections
dumpbin /DEPENDENTS output\demo_iat_ui.exe # 应只有系统 DLL

# 列字符串
strings64.exe -n 6 output\demo_iat_ui.exe | findstr /i "kernel32 user32"  # 不应找到

# Patch 一份
output\patchtool.exe --seed "Test" --input src.exe --output dst.exe --reorder-imports --verbose

# 比较
output\pediff_ui.exe    # GUI

# 算 SHA-256
certutil -hashfile output\demo_iat_ui.exe SHA256
```
