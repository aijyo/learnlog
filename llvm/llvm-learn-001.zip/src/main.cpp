//#include "llvm/ADT/StringRef.h"
//#include "llvm/ExecutionEngine/Orc/LLJIT.h"
//#include "llvm/ExecutionEngine/Orc/ThreadSafeModule.h"
//#include "llvm/IR/IRBuilder.h"
//#include "llvm/IR/LLVMContext.h"
//#include "llvm/IR/Module.h"
//#include "llvm/Support/TargetSelect.h"
//#include <cstdio>
//#include <memory>
//
//using namespace llvm;
//using namespace llvm::orc;
//
//// Build an LLVM IR function that returns 42.0 (double).
//std::unique_ptr<Module> buildModule(LLVMContext& Ctx) {
//	auto M = std::make_unique<Module>("jitdemo", Ctx);
//	FunctionType* FT = FunctionType::get(Type::getDoubleTy(Ctx), {}, false);
//	Function* F = Function::Create(FT, Function::ExternalLinkage, "foo", M.get());
//	BasicBlock* BB = BasicBlock::Create(Ctx, "entry", F);
//	IRBuilder<> builder(BB);
//	builder.CreateRet(ConstantFP::get(Type::getDoubleTy(Ctx), 42.0));
//	return M;
//}
//
//int main() {
//	// Initialize native target (C++ API only).
//	InitializeNativeTarget();
//	InitializeNativeTargetAsmPrinter();
//	InitializeNativeTargetAsmParser();
//
//	auto J = cantFail(LLJITBuilder().create());
//
//	auto Ctx = std::make_unique<LLVMContext>();
//	auto M = buildModule(*Ctx);
//	M->setDataLayout(J->getDataLayout());
//	ThreadSafeModule TSM(std::move(M), std::move(Ctx));
//	cantFail(J->addIRModule(std::move(TSM)));
//
//	auto Sym = cantFail(J->lookup("foo"));
//	auto FooPtr = Sym.toPtr<double()>(); // double (*)()
//	std::printf("JIT returned %f\n", FooPtr());
//	return 0;
//}

// All comments are in English as requested.

#include "llvm/ADT/StringRef.h"
#include "llvm/ExecutionEngine/Orc/LLJIT.h"
#include "llvm/ExecutionEngine/Orc/ThreadSafeModule.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/Support/TargetSelect.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Verifier.h" 
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>
#include <iostream>

using namespace llvm;
using namespace llvm::orc;

// ====== Lexer ======
// Tokens: EOF = -1, def/external identifiers, number literals, identifiers, punctuation.
enum Token {
    tok_eof = -1,

    // commands
    tok_def = -2,
    tok_extern = -3,

    // primary
    tok_identifier = -4,
    tok_number = -5,
};

static std::string IdentifierStr; // filled in if tok_identifier
static double NumVal;             // filled in if tok_number

static std::string LineBuf;
static size_t LinePos = 0;

static int gettok() {
    // Skip spaces.
    while (LinePos < LineBuf.size() && isspace(LineBuf[LinePos])) ++LinePos;

    if (LinePos >= LineBuf.size())
        return tok_eof;

    char c = LineBuf[LinePos++];

    if (isalpha(c)) {
        IdentifierStr = std::string(1, c);
        while (LinePos < LineBuf.size() && isalnum(LineBuf[LinePos]))
            IdentifierStr.push_back(LineBuf[LinePos++]);
        if (IdentifierStr == "def") return tok_def;
        if (IdentifierStr == "extern") return tok_extern;
        return tok_identifier;
    }

    if (isdigit(c) || c == '.') {
        std::string num(1, c);
        while (LinePos < LineBuf.size() && (isdigit(LineBuf[LinePos]) || LineBuf[LinePos] == '.'))
            num.push_back(LineBuf[LinePos++]);
        NumVal = strtod(num.c_str(), nullptr);
        return tok_number;
    }

    if (c == '#') {
        // Comment until end of line.
        LinePos = LineBuf.size();
        return tok_eof;
    }

    // Return the ASCII value of the character.
    return c;
}

static int CurTok;
static int getNextToken() { return CurTok = gettok(); }

// ====== AST ======
namespace AST {

    struct ExprAST {
        virtual ~ExprAST() = default;
        virtual Value* codegen(LLVMContext& Ctx, Module& M, IRBuilder<>& B,
            std::map<std::string, Value*>& NamedValues) = 0;
    };

    struct NumberExprAST : ExprAST {
        double Val;
        explicit NumberExprAST(double V) : Val(V) {}
        Value* codegen(LLVMContext& Ctx, Module&, IRBuilder<>& B,
            std::map<std::string, Value*>&) override {
            return ConstantFP::get(Type::getDoubleTy(Ctx), Val);
        }
    };

    struct VariableExprAST : ExprAST {
        std::string Name;
        explicit VariableExprAST(std::string N) : Name(std::move(N)) {}
        Value* codegen(LLVMContext&, Module&, IRBuilder<>&,
            std::map<std::string, Value*>& NamedValues) override {
            Value* V = NamedValues[Name];
            if (!V) {
                errs() << "Unknown variable: " << Name << "\n";
                return nullptr;
            }
            return V;
        }
    };

    struct BinaryExprAST : ExprAST {
        char Op;
        std::unique_ptr<ExprAST> LHS, RHS;
        BinaryExprAST(char Op, std::unique_ptr<ExprAST> L, std::unique_ptr<ExprAST> R)
            : Op(Op), LHS(std::move(L)), RHS(std::move(R)) {}
        Value* codegen(LLVMContext& Ctx, Module&, IRBuilder<>& B,
            std::map<std::string, Value*>& NamedValues) override {
            Value* L = LHS->codegen(Ctx, *(Module*)nullptr, B, NamedValues);
            Value* R = RHS->codegen(Ctx, *(Module*)nullptr, B, NamedValues);
            if (!L || !R) return nullptr;
            switch (Op) {
            case '+': return B.CreateFAdd(L, R, "addtmp");
            case '-': return B.CreateFSub(L, R, "subtmp");
            case '*': return B.CreateFMul(L, R, "multmp");
            case '<': {
                Value* Cmp = B.CreateFCmpULT(L, R, "cmptmp");
                // Convert bool(1-bit) to double
                return B.CreateUIToFP(Cmp, Type::getDoubleTy(Ctx), "booltmp");
            }
            default:
                errs() << "Invalid binary operator: " << Op << "\n";
                return nullptr;
            }
        }
    };

    struct CallExprAST : ExprAST {
        std::string Callee;
        std::vector<std::unique_ptr<ExprAST>> Args;
        CallExprAST(std::string C, std::vector<std::unique_ptr<ExprAST>> A)
            : Callee(std::move(C)), Args(std::move(A)) {}
        Value* codegen(LLVMContext& Ctx, Module& M, IRBuilder<>& B,
            std::map<std::string, Value*>& NamedValues) override {
            Function* CalleeF = M.getFunction(Callee);
            if (!CalleeF) {
                errs() << "Unknown function referenced: " << Callee << "\n";
                return nullptr;
            }
            if (CalleeF->arg_size() != Args.size()) {
                errs() << "Incorrect # arguments passed to " << Callee << "\n";
                return nullptr;
            }
            std::vector<Value*> ArgsV;
            for (auto& A : Args) {
                Value* V = A->codegen(Ctx, M, B, NamedValues);
                if (!V) return nullptr;
                ArgsV.push_back(V);
            }
            return B.CreateCall(CalleeF, ArgsV, "calltmp");
        }
    };

    struct PrototypeAST {
        std::string Name;
        std::vector<std::string> Args;
        PrototypeAST(std::string N, std::vector<std::string> A)
            : Name(std::move(N)), Args(std::move(A)) {}
        Function* codegen(LLVMContext& Ctx, Module& M) {
            std::vector<Type*> Doubles(Args.size(), Type::getDoubleTy(Ctx));
            FunctionType* FT = FunctionType::get(Type::getDoubleTy(Ctx), Doubles, false);
            Function* F = Function::Create(FT, Function::ExternalLinkage, Name, &M);
            unsigned idx = 0;
            for (auto& Arg : F->args())
                Arg.setName(Args[idx++]);
            return F;
        }
    };

    struct FunctionAST {
        std::unique_ptr<PrototypeAST> Proto;
        std::unique_ptr<ExprAST> Body;
        FunctionAST(std::unique_ptr<PrototypeAST> P, std::unique_ptr<ExprAST> B)
            : Proto(std::move(P)), Body(std::move(B)) {}
        Function* codegen(LLVMContext& Ctx, Module& M) {
            Function* F = M.getFunction(Proto->Name);
            if (!F) F = Proto->codegen(Ctx, M);
            BasicBlock* BB = BasicBlock::Create(Ctx, "entry", F);
            IRBuilder<> Builder(BB);
            std::map<std::string, Value*> NamedValues;
            for (auto& Arg : F->args())
                NamedValues[std::string(Arg.getName())] = &Arg;
            if (Value* Ret = Body->codegen(Ctx, M, Builder, NamedValues)) {
                Builder.CreateRet(Ret);
                verifyFunction(*F);
                return F;
            }
            F->eraseFromParent();
            return nullptr;
        }
    };

} // namespace AST

// ====== Parser ======
static std::map<char, int> BinopPrecedence;

static int GetTokPrecedence() {
    if (!isascii(CurTok)) return -1;
    int TokPrec = BinopPrecedence[(char)CurTok];
    if (TokPrec <= 0) return -1;
    return TokPrec;
}

static std::unique_ptr<AST::ExprAST> ParseExpression();

static std::unique_ptr<AST::ExprAST> ParseNumberExpr() {
    auto Result = std::make_unique<AST::NumberExprAST>(NumVal);
    getNextToken();
    return Result;
}

static std::unique_ptr<AST::ExprAST> ParseParenExpr() {
    getNextToken(); // eat '('
    auto V = ParseExpression();
    if (!V) return nullptr;
    if (CurTok != ')') {
        errs() << "expected ')'\n";
        return nullptr;
    }
    getNextToken(); // eat ')'
    return V;
}

static std::unique_ptr<AST::ExprAST> ParseIdentifierExpr() {
    std::string IdName = IdentifierStr;
    getNextToken(); // eat identifier

    if (CurTok != '(') {
        // Simple variable
        return std::make_unique<AST::VariableExprAST>(IdName);
    }

    // Call
    getNextToken(); // eat '('
    std::vector<std::unique_ptr<AST::ExprAST>> Args;
    if (CurTok != ')') {
        while (true) {
            if (auto Arg = ParseExpression())
                Args.push_back(std::move(Arg));
            else
                return nullptr;

            if (CurTok == ')') break;
            if (CurTok != ',') {
                errs() << "Expected ')' or ',' in argument list\n";
                return nullptr;
            }
            getNextToken();
        }
    }
    getNextToken(); // eat ')'
    return std::make_unique<AST::CallExprAST>(IdName, std::move(Args));
}

static std::unique_ptr<AST::ExprAST> ParsePrimary() {
    switch (CurTok) {
    case tok_identifier: return ParseIdentifierExpr();
    case tok_number:     return ParseNumberExpr();
    case '(':            return ParseParenExpr();
    default:
        errs() << "unknown token when expecting an expression\n";
        return nullptr;
    }
}

static std::unique_ptr<AST::ExprAST> ParseBinOpRHS(int ExprPrec,
    std::unique_ptr<AST::ExprAST> LHS) {
    while (true) {
        int TokPrec = GetTokPrecedence();
        if (TokPrec < ExprPrec) return LHS;

        int BinOp = CurTok;
        getNextToken(); // eat binop

        auto RHS = ParsePrimary();
        if (!RHS) return nullptr;

        int NextPrec = GetTokPrecedence();
        if (TokPrec < NextPrec) {
            RHS = ParseBinOpRHS(TokPrec + 1, std::move(RHS));
            if (!RHS) return nullptr;
        }

        LHS = std::make_unique<AST::BinaryExprAST>(BinOp, std::move(LHS), std::move(RHS));
    }
}

static std::unique_ptr<AST::ExprAST> ParseExpression() {
    auto LHS = ParsePrimary();
    if (!LHS) return nullptr;
    return ParseBinOpRHS(0, std::move(LHS));
}

static std::unique_ptr<AST::PrototypeAST> ParsePrototype() {
    if (CurTok != tok_identifier) {
        errs() << "Expected function name in prototype\n";
        return nullptr;
    }
    std::string FnName = IdentifierStr;
    getNextToken();

    if (CurTok != '(') {
        errs() << "Expected '('\n";
        return nullptr;
    }
    std::vector<std::string> ArgNames;
    while (getNextToken() == tok_identifier)
        ArgNames.push_back(IdentifierStr);
    if (CurTok != ')') {
        errs() << "Expected ')'\n";
        return nullptr;
    }
    getNextToken(); // eat ')'
    return std::make_unique<AST::PrototypeAST>(FnName, std::move(ArgNames));
}

static std::unique_ptr<AST::FunctionAST> ParseDefinition() {
    getNextToken(); // eat 'def'
    auto Proto = ParsePrototype();
    if (!Proto) return nullptr;
    if (auto E = ParseExpression())
        return std::make_unique<AST::FunctionAST>(std::move(Proto), std::move(E));
    return nullptr;
}

static std::unique_ptr<AST::PrototypeAST> ParseExtern() {
    getNextToken(); // eat 'extern'
    return ParsePrototype();
}

static std::unique_ptr<AST::FunctionAST> ParseTopLevelExpr() {
    if (auto E = ParseExpression()) {
        auto Proto = std::make_unique<AST::PrototypeAST>("__anon_expr", std::vector<std::string>{});
        return std::make_unique<AST::FunctionAST>(std::move(Proto), std::move(E));
    }
    return nullptr;
}

// ====== JIT / Driver ======
static std::unique_ptr<LLVMContext> TheContext;
static std::unique_ptr<Module> TheModule;
static std::unique_ptr<LLJIT> TheJIT;

static void InitializeModuleAndFPM() {
    TheContext = std::make_unique<LLVMContext>();
    TheModule = std::make_unique<Module>("jit_module", *TheContext);
    TheModule->setDataLayout(TheJIT->getDataLayout());
}

static void HandleDefinition() {
    if (auto FnAST = ParseDefinition()) {
        if (auto* FnIR = FnAST->codegen(*TheContext, *TheModule)) {
            FnIR->print(errs(), nullptr);
            errs() << "\n";
            // Add module to JIT
            ThreadSafeModule TSM(std::move(TheModule), std::move(TheContext));
            cantFail(TheJIT->addIRModule(std::move(TSM)));
            // Prepare a fresh module for subsequent definitions
            InitializeModuleAndFPM();
        }
    }
    else {
        // skip token on error
        getNextToken();
    }
}

static void HandleExtern() {
    if (auto ProtoAST = ParseExtern()) {
        if (auto* FnIR = ProtoAST->codegen(*TheContext, *TheModule)) {
            FnIR->print(errs(), nullptr);
            errs() << "\n";
            // We don't add the module yet; externs can sit in the current module.
        }
    }
    else {
        getNextToken();
    }
}

static void HandleTopLevelExpression() {
    if (auto FnAST = ParseTopLevelExpr()) {
        if (auto* FnIR = FnAST->codegen(*TheContext, *TheModule)) {
            // JIT the module
            ThreadSafeModule TSM(std::move(TheModule), std::move(TheContext));
            cantFail(TheJIT->addIRModule(std::move(TSM)));

            // Lookup and run __anon_expr
            auto Sym = cantFail(TheJIT->lookup("__anon_expr"));
            auto FP = Sym.toPtr<double()>(); // double (*)()
            double Result = FP();
            std::printf("=> %f\n", Result);

            // Prepare a new module for the next input
            InitializeModuleAndFPM();
        }
    }
    else {
        getNextToken();
    }
}

static void MainLoop() {
    while (true) {
        errs() << "ready> ";
        LineBuf.clear();
        if (!std::getline(std::cin, LineBuf)) return;
        LinePos = 0;
        getNextToken(); // initialize CurTok for this line

        switch (CurTok) {
        case tok_eof:   return;
        case ';':       /* ignore */ getNextToken(); break;
        case tok_def:   HandleDefinition(); break;
        case tok_extern:HandleExtern(); break;
        default:        HandleTopLevelExpression(); break;
        }
    }
}

int main() {
    // Set operator precedences
    BinopPrecedence['<'] = 10;
    BinopPrecedence['+'] = 20;
    BinopPrecedence['-'] = 20;
    BinopPrecedence['*'] = 40;

    // Initialize native targets (C++ API only)
    InitializeNativeTarget();
    InitializeNativeTargetAsmPrinter();
    InitializeNativeTargetAsmParser();

    // Create JIT
    TheJIT = cantFail(LLJITBuilder().create());

    // Create first module
    InitializeModuleAndFPM();

    // Provide a couple of externs from the C runtime if desired (optional):
    // You can declare with: extern sin(x); then call: sin(1.0)
    // On Windows/MSVC this works if the CRT exports 'sin' as usual.

    // REPL
    MainLoop();

    return 0;
}
