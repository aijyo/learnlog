// 极简 WAV 读写（PCM16）。读：任意声道→下混单声道 float[-1,1]；写：单声道 PCM16。
// 仅支持 PCM16（audioFormat==1, bits==16）——本实验输入均为此格式；其它格式返回 false。
#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

namespace wav {

inline bool readMonoF32(const std::string& path, std::vector<float>& out, int& sampleRate) {
    std::ifstream f(std::filesystem::u8path(path), std::ios::binary);
    if (!f) return false;
    auto rd32 = [&](uint32_t& v) { f.read(reinterpret_cast<char*>(&v), 4); };
    auto rd16 = [&](uint16_t& v) { f.read(reinterpret_cast<char*>(&v), 2); };

    char riff[4], wave[4];
    uint32_t riffSz = 0;
    f.read(riff, 4); rd32(riffSz); f.read(wave, 4);
    if (std::strncmp(riff, "RIFF", 4) != 0 || std::strncmp(wave, "WAVE", 4) != 0) return false;

    uint16_t audioFormat = 0, numCh = 0, bits = 0, blockAlign = 0;
    uint32_t sr = 0, byteRate = 0;
    std::vector<int16_t> pcm;
    bool gotFmt = false, gotData = false;

    while (f && !gotData) {
        char id[4];
        f.read(id, 4);
        if (f.gcount() < 4) break;
        uint32_t csz = 0; rd32(csz);
        if (std::strncmp(id, "fmt ", 4) == 0) {
            rd16(audioFormat); rd16(numCh); rd32(sr); rd32(byteRate); rd16(blockAlign); rd16(bits);
            if (csz > 16) f.seekg(csz - 16, std::ios::cur);   // 跳过扩展 fmt 字节
            gotFmt = true;
        } else if (std::strncmp(id, "data", 4) == 0) {
            pcm.resize(csz / 2);
            f.read(reinterpret_cast<char*>(pcm.data()), csz);
            gotData = true;
        } else {
            f.seekg(csz + (csz & 1), std::ios::cur);          // chunk 按字对齐
        }
    }
    if (!gotFmt || !gotData || audioFormat != 1 || bits != 16 || numCh < 1) return false;

    sampleRate = static_cast<int>(sr);
    const size_t frames = pcm.size() / numCh;
    out.resize(frames);
    for (size_t i = 0; i < frames; ++i) {
        int acc = 0;
        for (int c = 0; c < numCh; ++c) acc += pcm[i * numCh + c];
        out[i] = static_cast<float>(acc) / numCh / 32768.0f;
    }
    return true;
}

inline bool writeMonoF32(const std::string& path, const std::vector<float>& in, int sampleRate) {
    std::ofstream f(std::filesystem::u8path(path), std::ios::binary);
    if (!f) return false;
    const uint16_t numCh = 1, bits = 16;
    const uint32_t sr = static_cast<uint32_t>(sampleRate);
    const uint32_t byteRate = sr * numCh * bits / 8;
    const uint16_t blockAlign = numCh * bits / 8;
    const uint32_t dataBytes = static_cast<uint32_t>(in.size() * 2);
    const uint32_t riffSz = 36 + dataBytes;
    auto w32 = [&](uint32_t v) { f.write(reinterpret_cast<char*>(&v), 4); };
    auto w16 = [&](uint16_t v) { f.write(reinterpret_cast<char*>(&v), 2); };

    f.write("RIFF", 4); w32(riffSz); f.write("WAVE", 4);
    f.write("fmt ", 4); w32(16); w16(1); w16(numCh); w32(sr); w32(byteRate); w16(blockAlign); w16(bits);
    f.write("data", 4); w32(dataBytes);
    for (float s : in) {
        long v = std::lround(s * 32767.0f);
        if (v > 32767) v = 32767;
        if (v < -32768) v = -32768;
        int16_t o = static_cast<int16_t>(v);
        f.write(reinterpret_cast<char*>(&o), 2);
    }
    return true;
}

} // namespace wav
