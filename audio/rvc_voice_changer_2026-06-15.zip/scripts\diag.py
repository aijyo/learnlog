import os
from rvc_python.infer import RVCInference
D = r"D:\code\work\research\voice\rvc_demo"
rvc = RVCInference(device="cpu:0")
rvc.set_params(f0method="harvest", index_rate=0.6)
rvc.load_model(os.path.join(D, "models", "egirl", "egirl.pth"),
               index_path=os.path.join(D, "models", "egirl", "added_IVF2182_Flat_nprobe_1_egirl.index"))
mi = rvc.models[rvc.current_model]
res = rvc.vc.vc_single(
    sid=0, input_audio_path=os.path.join(D, "source_male.wav"),
    f0_up_key=rvc.f0up_key, f0_method=rvc.f0method, f0_file="",
    file_index=mi.get("index", "") or "", file_index2="",
    index_rate=rvc.index_rate, filter_radius=rvc.filter_radius,
    resample_sr=rvc.resample_sr, rms_mix_rate=rvc.rms_mix_rate, protect=rvc.protect)
print("RESULT TYPE:", type(res))
if isinstance(res, tuple):
    print("=== ERROR TRACEBACK (info) ===")
    print(res[0])
else:
    print("OK audio:", getattr(res, "shape", None), getattr(res, "dtype", None))
