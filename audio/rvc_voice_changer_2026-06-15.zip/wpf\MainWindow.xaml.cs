using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using Microsoft.Win32;

namespace RvcWpf
{
    public partial class MainWindow : Window
    {
        const string DEMO = @"D:\code\work\research\voice\rvc_demo";
        IntPtr eng = IntPtr.Zero;
        DispatcherTimer timer;

        // 声音面板
        readonly ObservableCollection<SoundSlot> slots = new ObservableCollection<SoundSlot>();
        readonly Dictionary<int, SoundSlot> hotkeyMap = new Dictionary<int, SoundSlot>();
        IntPtr hwnd = IntPtr.Zero;
        int sbDev = -99;            // 当前 soundboard 已开的输出设备索引（-99=未开）
        SoundSlot capturing;        // 正在录制热键的行（非空=捕获中）

        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        public MainWindow()
        {
            InitializeComponent();
            eng = Native.rvc_create();
            VecBox.Text = Path.Combine(DEMO, "vec-768-layer-12.onnx");
            ScanModels();
            PopulateDevices();
            SlotList.ItemsSource = slots;
            timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
            timer.Tick += Timer_Tick;
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            hwnd = new WindowInteropHelper(this).Handle;
            HwndSource.FromHwnd(hwnd)?.AddHook(WndHook);
        }

        void ScanModels()
        {
            ModelCombo.Items.Clear();
            string md = Path.Combine(DEMO, "models");
            if (Directory.Exists(md))
                foreach (var f in Directory.GetFiles(md, "*.onnx", SearchOption.AllDirectories))
                    ModelCombo.Items.Add(new ComboItem(f));
            if (ModelCombo.Items.Count > 0) ModelCombo.SelectedIndex = 0;
        }

        void PopulateDevices()
        {
            InCombo.Items.Clear(); OutCombo.Items.Clear();
            for (int i = 0, n = Native.rvc_in_count(eng); i < n; i++) InCombo.Items.Add(Native.Utf8(Native.rvc_in_name(eng, i)));
            SbOutCombo.Items.Clear();
            int cable = -1;
            for (int i = 0, n = Native.rvc_out_count(eng); i < n; i++)
            {
                string nm = Native.Utf8(Native.rvc_out_name(eng, i));
                OutCombo.Items.Add(nm);
                SbOutCombo.Items.Add(nm);
                if (cable < 0 && nm.Contains("CABLE Input")) cable = i;
            }
            if (InCombo.Items.Count > 0) InCombo.SelectedIndex = 0;
            if (OutCombo.Items.Count > 0) OutCombo.SelectedIndex = 0;
            if (SbOutCombo.Items.Count > 0) SbOutCombo.SelectedIndex = cable >= 0 ? cable : 0;
        }

        void VecBrowse_Click(object s, RoutedEventArgs e)
        {
            var d = new OpenFileDialog { Filter = "onnx 模型|*.onnx" };
            if (d.ShowDialog() == true) VecBox.Text = d.FileName;
        }

        async void LoadBtn_Click(object s, RoutedEventArgs e)
        {
            if (ModelCombo.SelectedItem is not ComboItem mi) { StatusLbl.Text = "请先选一个音色模型"; return; }
            string vec = VecBox.Text, model = mi.Path;
            Native.rvc_set_gpu(eng, GpuChk.IsChecked == true ? 1 : 0);
            LoadBtn.IsEnabled = false; StartBtn.IsEnabled = false; StatusLbl.Text = "加载模型中…(几秒)";
            int ok = await Task.Run(() => Native.rvc_load(eng, vec, model));
            StatusLbl.Text = Native.Utf8(Native.rvc_status(eng));
            LoadBtn.IsEnabled = true; StartBtn.IsEnabled = (ok == 1);
            if (ok == 1)
            {
                bool gpu = Native.rvc_gpu_active(eng) == 1;
                GpuHint.Text = gpu ? "✓ 正在用 GPU(DirectML)，看 RTF 与 CPU 对比。"
                    : (GpuChk.IsChecked == true ? "未启用 GPU：缺 DirectML 版 onnxruntime.dll，已回退 CPU（见 README）。" : "当前用 CPU。");
                GpuHint.Foreground = new System.Windows.Media.SolidColorBrush(gpu
                    ? System.Windows.Media.Color.FromRgb(0x5F, 0xD0, 0x8A)
                    : System.Windows.Media.Color.FromRgb(0x8A, 0x8F, 0x99));
                Native.rvc_set_index(eng, (float)IndexSlider.Value);
                Native.rvc_set_protect(eng, (float)ProtectSlider.Value);
                Native.rvc_set_rms(eng, (float)RmsSlider.Value);
                bool hasIdx = Native.rvc_has_index(eng) == 1;
                IndexSlider.IsEnabled = hasIdx;
                IndexHint.Text = hasIdx
                    ? "✓ 该模型带 index：拉高“音色贴合度”会更像目标音色。"
                    : "该模型目录无 index.bin，音色贴合度无效（先跑 export_index.py 导出）。";
                IndexHint.Foreground = new System.Windows.Media.SolidColorBrush(hasIdx
                    ? System.Windows.Media.Color.FromRgb(0x5F, 0xD0, 0x8A)
                    : System.Windows.Media.Color.FromRgb(0xD0, 0x96, 0x5F));
            }
        }

        void StartBtn_Click(object s, RoutedEventArgs e)
        {
            Native.rvc_set_pitch(eng, (float)PitchSlider.Value);
            Native.rvc_set_index(eng, (float)IndexSlider.Value);
            Native.rvc_set_protect(eng, (float)ProtectSlider.Value);
            Native.rvc_set_rms(eng, (float)RmsSlider.Value);
            int ok = Native.rvc_start(eng, InCombo.SelectedIndex, OutCombo.SelectedIndex, (float)BlockSlider.Value);
            StatusLbl.Text = Native.Utf8(Native.rvc_status(eng));
            if (ok == 1) { StartBtn.IsEnabled = false; StopBtn.IsEnabled = true; LoadBtn.IsEnabled = false; timer.Start(); }
        }

        void StopBtn_Click(object s, RoutedEventArgs e)
        {
            timer.Stop(); Native.rvc_stop(eng);
            StartBtn.IsEnabled = true; StopBtn.IsEnabled = false; LoadBtn.IsEnabled = true;
            StatusLbl.Text = Native.Utf8(Native.rvc_status(eng)); StatLbl.Text = "";
        }

        async void BenchBtn_Click(object s, RoutedEventArgs e)
        {
            if (eng == IntPtr.Zero) return;
            BenchBtn.IsEnabled = false; StatusLbl.Text = "测速中…(GPU 首次需编译内核，稍等)";
            float rtf = await Task.Run(() => Native.rvc_bench(eng, 1.0f));
            bool gpu = Native.rvc_gpu_active(eng) == 1;
            StatusLbl.Text = rtf < 0 ? "先加载模型再测速"
                : $"测速：1 秒音频 RTF={rtf:F2}（<1 才实时；当前 {(gpu ? "GPU" : "CPU")}）";
            BenchBtn.IsEnabled = true;
        }

        void PitchSlider_ValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (PitchLbl != null) PitchLbl.Text = (PitchSlider.Value >= 0 ? "+" : "") + ((int)PitchSlider.Value);
            if (eng != IntPtr.Zero) Native.rvc_set_pitch(eng, (float)PitchSlider.Value);
        }

        void BlockSlider_ValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (BlockLbl != null) BlockLbl.Text = BlockSlider.Value.ToString("F2");
            if (eng != IntPtr.Zero) Native.rvc_set_block(eng, (float)BlockSlider.Value);
        }

        void IndexSlider_ValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (IndexLbl != null) IndexLbl.Text = IndexSlider.Value.ToString("F2");
            if (eng != IntPtr.Zero) Native.rvc_set_index(eng, (float)IndexSlider.Value);
        }

        void ProtectSlider_ValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (ProtectLbl != null) ProtectLbl.Text = ProtectSlider.Value.ToString("F2");
            if (eng != IntPtr.Zero) Native.rvc_set_protect(eng, (float)ProtectSlider.Value);
        }

        void RmsSlider_ValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (RmsLbl != null) RmsLbl.Text = RmsSlider.Value.ToString("F2");
            if (eng != IntPtr.Zero) Native.rvc_set_rms(eng, (float)RmsSlider.Value);
        }

        void Timer_Tick(object s, EventArgs e)
        {
            if (eng == IntPtr.Zero) return;
            StatLbl.Text = $"RTF={Native.rvc_rtf(eng):F2}（<1 跟得上）   输入电平={Native.rvc_level(eng):F3}";
        }

        // ================= 声音面板 =================
        void EnsureSbDevice()
        {
            if (eng == IntPtr.Zero) return;
            int idx = SbOutCombo.SelectedIndex;
            if (idx < 0) idx = OutCombo.SelectedIndex;
            if (idx == sbDev) return;
            sbDev = Native.rvc_sb_init(eng, idx) == 1 ? idx : -99;
            if (sbDev < 0) SbStatus.Text = "声音面板：打开输出设备失败（设备被占用？换一个）";
        }

        void PlaySlot(SoundSlot s)
        {
            if (eng == IntPtr.Zero || s == null || string.IsNullOrEmpty(s.Path)) return;
            EnsureSbDevice();
            int ok = Native.rvc_sb_play(eng, s.Path);
            SbStatus.Text = ok == 1 ? $"播放：{s.Name}" : $"播放失败：{s.Name}（文件/设备?）";
        }

        void SbOutCombo_Changed(object s, SelectionChangedEventArgs e)
        {
            if (eng != IntPtr.Zero && sbDev != -99) EnsureSbDevice();   // 已开过才热切换
        }

        void SbVol_Changed(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (SbVolLbl != null) SbVolLbl.Text = SbVolSlider.Value.ToString("F2");
            if (eng != IntPtr.Zero) Native.rvc_sb_volume(eng, (float)SbVolSlider.Value);
        }

        void SbAdd_Click(object s, RoutedEventArgs e)
        {
            var d = new OpenFileDialog { Filter = "音频|*.wav;*.mp3;*.flac;*.ogg|所有文件|*.*", Multiselect = true };
            if (d.ShowDialog() != true) return;
            foreach (var f in d.FileNames) slots.Add(new SoundSlot { Path = f, Mods = 3, Vk = NextFreeVk() });
            SbStatus.Text = $"已添加 {d.FileNames.Length} 个；共 {slots.Count} 个。点“录制”改热键。";
            if (HotkeyChk.IsChecked == true) RegisterAll();
        }

        void SbPlayRow_Click(object s, RoutedEventArgs e) => PlaySlot((s as FrameworkElement)?.DataContext as SoundSlot);

        void SbRemoveRow_Click(object s, RoutedEventArgs e)
        {
            if ((s as FrameworkElement)?.DataContext is SoundSlot slot)
            {
                slots.Remove(slot);
                if (HotkeyChk.IsChecked == true) RegisterAll();
            }
        }

        void SbStop_Click(object s, RoutedEventArgs e) { if (eng != IntPtr.Zero) Native.rvc_sb_stop(eng); }

        // 录制热键：点“录制”后，下一次按键组合写进该行
        void SbCapture_Click(object s, RoutedEventArgs e)
        {
            if ((s as FrameworkElement)?.DataContext is SoundSlot slot)
            {
                capturing = slot;
                SbStatus.Text = $"按下要绑定给「{slot.Name}」的组合键…（Esc 取消）";
            }
        }

        void Window_PreviewKeyDown(object s, KeyEventArgs e)
        {
            if (capturing == null) return;
            Key k = e.Key == Key.System ? e.SystemKey : e.Key;
            if (k == Key.LeftCtrl || k == Key.RightCtrl || k == Key.LeftAlt || k == Key.RightAlt ||
                k == Key.LeftShift || k == Key.RightShift || k == Key.LWin || k == Key.RWin) return;  // 等真正的主键
            e.Handled = true;
            if (k == Key.Escape) { capturing = null; SbStatus.Text = "已取消录制。"; return; }
            uint mods = 0; var m = Keyboard.Modifiers;
            if ((m & ModifierKeys.Alt) != 0) mods |= 1;
            if ((m & ModifierKeys.Control) != 0) mods |= 2;
            if ((m & ModifierKeys.Shift) != 0) mods |= 4;
            if ((m & ModifierKeys.Windows) != 0) mods |= 8;
            capturing.Mods = mods;
            capturing.Vk = (uint)KeyInterop.VirtualKeyFromKey(k);
            string warn = mods == 0 ? "（无修饰键，可能和游戏按键冲突）" : "";
            SbStatus.Text = $"已绑定 {capturing.HotkeyText} → {capturing.Name} {warn}";
            capturing = null;
            if (HotkeyChk.IsChecked == true) RegisterAll();
        }

        void Hotkey_Toggle(object s, RoutedEventArgs e)
        {
            if (HotkeyChk.IsChecked == true)
            {
                EnsureSbDevice();
                RegisterAll();
                SbStatus.Text = $"全局热键已启用（Ctrl+Alt+键），游戏里也能触发。已绑定 {hotkeyMap.Count} 个。";
            }
            else { UnregisterAll(); SbStatus.Text = "全局热键已关闭。"; }
        }

        void RegisterAll()
        {
            UnregisterAll();
            if (hwnd == IntPtr.Zero) return;
            int id = 0x9000;
            foreach (var s in slots)
            {
                if (s.Vk == 0) continue;
                // MOD_NOREPEAT=0x4000，按住不连发
                if (RegisterHotKey(hwnd, id, s.Mods | 0x4000, s.Vk)) { hotkeyMap[id] = s; id++; }
            }
        }

        void UnregisterAll()
        {
            foreach (var kv in hotkeyMap) UnregisterHotKey(hwnd, kv.Key);
            hotkeyMap.Clear();
        }

        uint NextFreeVk()
        {
            var used = new HashSet<uint>();
            foreach (var s in slots) used.Add(s.Vk);
            for (uint v = 0x31; v <= 0x39; v++) if (!used.Contains(v)) return v;  // 1-9
            if (!used.Contains(0x30)) return 0x30;                                // 0
            for (uint v = 0x70; v <= 0x7B; v++) if (!used.Contains(v)) return v;  // F1-F12
            return 0x31;
        }

        IntPtr WndHook(IntPtr h, int msg, IntPtr w, IntPtr l, ref bool handled)
        {
            if (msg == 0x0312 && hotkeyMap.TryGetValue(w.ToInt32(), out var slot)) { PlaySlot(slot); handled = true; }
            return IntPtr.Zero;
        }

        protected override void OnClosed(EventArgs e)
        {
            UnregisterAll();
            if (eng != IntPtr.Zero)
            {
                Native.rvc_sb_shutdown(eng);
                Native.rvc_stop(eng);
                Native.rvc_destroy(eng);
                eng = IntPtr.Zero;
            }
            base.OnClosed(e);
        }

        class ComboItem
        {
            public string Path;
            public ComboItem(string p) { Path = p; }
            public override string ToString()
            {
                string dir = System.IO.Path.GetFileName(System.IO.Path.GetDirectoryName(Path));
                return dir + " / " + System.IO.Path.GetFileName(Path);
            }
        }
    }

    public class SoundSlot : INotifyPropertyChanged
    {
        string _path = "";
        public string Path { get => _path; set { _path = value; OnP(nameof(Path)); OnP(nameof(Name)); } }
        public string Name => string.IsNullOrEmpty(_path) ? "(空)" : System.IO.Path.GetFileName(_path);

        uint _mods = 3;   // 1=Alt 2=Ctrl 4=Shift 8=Win（默认 Ctrl+Alt）
        uint _vk = 0;
        public uint Mods { get => _mods; set { _mods = value; OnP(nameof(HotkeyText)); } }
        public uint Vk { get => _vk; set { _vk = value; OnP(nameof(HotkeyText)); } }
        public string HotkeyText => _vk == 0 ? "(未设热键)" : ModStr(_mods) + KeyName(_vk);

        public event PropertyChangedEventHandler PropertyChanged;
        void OnP(string n) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

        static string ModStr(uint m)
        {
            var sb = new StringBuilder();
            if ((m & 2) != 0) sb.Append("Ctrl+");
            if ((m & 1) != 0) sb.Append("Alt+");
            if ((m & 4) != 0) sb.Append("Shift+");
            if ((m & 8) != 0) sb.Append("Win+");
            return sb.ToString();
        }
        static string KeyName(uint vk)
        {
            string n = KeyInterop.KeyFromVirtualKey((int)vk).ToString();
            if (n.Length == 2 && n[0] == 'D' && char.IsDigit(n[1])) return n.Substring(1); // D1 -> 1
            return n;
        }
    }
}
