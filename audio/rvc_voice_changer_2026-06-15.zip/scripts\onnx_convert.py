# 用 onnx 管线完整转换 source_male -> egirl，验证正确性 + 全程 RTF。复刻 onnx_inference.inference 逻辑。
import os, sys, time
sys.argv = [sys.argv[0]]
import numpy as np, soundfile as sf, librosa
import onnxruntime as ort
from rvc_python.lib.infer_pack.onnx_inference import ContentVec, get_f0_predictor

D = r"D:\code\work\research\voice\rvc_demo"
VEC = os.path.join(D, "vec-768-layer-12.onnx")
MODEL = os.path.join(D, "models", "egirl", "egirl.onnx")
SR = 48000      # egirl tgt_sr
HOP = 512
F0UP = 12       # 男->女

cv = ContentVec(VEC, device="cpu")
m = ort.InferenceSession(MODEL, providers=["CPUExecutionProvider"])

wav, _ = librosa.load(os.path.join(D, "source_male.wav"), sr=SR)
wav16 = librosa.resample(wav, orig_sr=SR, target_sr=16000)

t0 = time.time()
h = cv(wav16)
hub = np.repeat(h, 2, axis=2).transpose(0, 2, 1).astype(np.float32)
L = hub.shape[1]
# f0 用 librosa.pyin（验证用；C++/实时会换快的 dio/WORLD）
f0raw, _, _ = librosa.pyin(wav, fmin=50, fmax=1100, sr=SR, frame_length=2048)
f0raw = np.nan_to_num(f0raw)
pitchf = np.interp(np.linspace(0, 1, L), np.linspace(0, 1, len(f0raw)), f0raw).astype(np.float32)
pitchf = pitchf * (2 ** (F0UP / 12))
used = "librosa-pyin"
pitch = pitchf.copy()
f0_min, f0_max = 50, 1100
mmin, mmax = 1127*np.log(1+f0_min/700), 1127*np.log(1+f0_max/700)
fmel = 1127*np.log(1+pitch/700)
fmel[fmel > 0] = (fmel[fmel > 0]-mmin)*254/(mmax-mmin)+1
fmel[fmel <= 1] = 1; fmel[fmel > 255] = 255
pitch = np.rint(fmel).astype(np.int64).reshape(1, -1)
pitchf = pitchf.reshape(1, -1).astype(np.float32)
out = (m.run(None, {"phone": hub, "phone_lengths": np.array([L]).astype(np.int64),
                    "pitch": pitch, "pitchf": pitchf, "ds": np.array([0]).astype(np.int64),
                    "rnd": np.random.randn(1, 192, L).astype(np.float32)})[0] * 32767).astype(np.int16).squeeze()
dt = time.time() - t0
sf.write(os.path.join(D, "out_onnx_egirl.wav"), out, SR)
print(f"onnx 全程转换: 音频{len(out)/SR:.2f}s / 计算{dt:.2f}s / 全程RTF={dt/(len(out)/SR):.3f} / f0={used} -> out_onnx_egirl.wav")
