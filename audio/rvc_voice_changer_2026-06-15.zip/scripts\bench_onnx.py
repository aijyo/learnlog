# 测完整 onnx 管线两个 onnx 重头(ContentVec + 模型)的每块耗时。f0(dio,DSP)另算。
import os, sys, time
sys.argv = [sys.argv[0]]
import numpy as np
import onnxruntime as ort
from rvc_python.lib.infer_pack.onnx_inference import ContentVec

D = r"D:\code\work\research\voice\rvc_demo"
VEC = os.path.join(D, "vec-768-layer-12.onnx")
MODEL = os.path.join(D, "models", "egirl", "egirl.onnx")

print("ORT", ort.__version__)
cv = ContentVec(VEC, device="cpu")
m = ort.InferenceSession(MODEL, providers=["CPUExecutionProvider"])

def bench(sec, n=5):
    N = int(sec * 16000)
    wav16 = np.random.rand(N).astype(np.float32)
    cv(wav16)
    t = time.time()
    for _ in range(n): h = cv(wav16)
    tc = (time.time() - t) / n
    hub = np.repeat(h, 2, axis=2).transpose(0, 2, 1).astype(np.float32)
    L = hub.shape[1]
    feed = {
        "phone": hub, "phone_lengths": np.array([L]).astype(np.int64),
        "pitch": np.random.randint(5, 255, (1, L)).astype(np.int64),
        "pitchf": np.random.rand(1, L).astype(np.float32),
        "ds": np.array([0]).astype(np.int64),
        "rnd": np.random.rand(1, 192, L).astype(np.float32),
    }
    m.run(None, feed)
    t = time.time()
    for _ in range(n): a = m.run(None, feed)
    tm = (time.time() - t) / n
    tot = tc + tm
    print(f"{sec}s块: ContentVec {tc*1000:.0f}ms + 模型 {tm*1000:.0f}ms = {tot*1000:.0f}ms  RTF(仅这两块onnx)={tot/sec:.3f}")

for s in [1.0, 2.0]:
    bench(s)
