# 实时 RVC 变声 GUI（Python/tkinter）：麦克风 -> RVC 转换 -> 扬声器/虚拟声卡。
#   选音色模型 + 调音高(transpose)/index_rate + 选输入/输出设备 + 块大小(延迟)。
#   基于 rvc-python(CPU)，块流式 + 重叠交叉淡化。
#   headless 验证: python rt_rvc.py --selftest   (用 source_male.wav 走流式引擎 -> out_stream_selftest.wav)
import os, sys, time, threading
import numpy as np
import torch
# torch 2.6+ 默认 weights_only=True 会拒载 fairseq/RVC 权重；本地可信文件，改回 False
_ol = torch.load
def _pl(*a, **k):
    k.setdefault("weights_only", False); return _ol(*a, **k)
torch.load = _pl

import scipy.signal
from fractions import Fraction
from rvc_python.infer import RVCInference
from rvc_python.modules.vc.utils import load_hubert

D = r"D:\code\work\research\voice\rvc_demo"
MODELS_DIR = os.path.join(D, "models")

def resample(y, sr_in, sr_out):
    y = np.asarray(y, dtype=np.float32)
    if sr_in == sr_out or len(y) == 0:
        return y
    fr = Fraction(int(sr_out), int(sr_in)).limit_denominator(2000)
    return scipy.signal.resample_poly(y, fr.numerator, fr.denominator).astype(np.float32)

def list_models():
    out = []
    if os.path.isdir(MODELS_DIR):
        for n in sorted(os.listdir(MODELS_DIR)):
            sub = os.path.join(MODELS_DIR, n)
            if os.path.isdir(sub) and any(f.endswith(".pth") for f in os.listdir(sub)):
                out.append(n)
    return out

class Engine:
    def __init__(self):
        self.rvc = RVCInference(device="cpu:0")
        if self.rvc.vc.hubert_model is None:
            self.rvc.vc.hubert_model = load_hubert(self.rvc.vc.config, self.rvc.vc.lib_dir)
        self.model_name = None
        self.index_path = ""
        self.pitch = 12.0          # 音高 transpose（半音）；男->女 +12
        self.index_rate = 0.5
        self.protect = 0.33
        self.out_sr = 40000
        self.last_rtf = 0.0
        self._reset()

    def _reset(self):
        self.prev_in_tail = np.zeros(0, dtype=np.float32)
        self.prev_out_tail = np.zeros(0, dtype=np.float32)

    def load(self, name):
        sub = os.path.join(MODELS_DIR, name)
        pth = [f for f in os.listdir(sub) if f.endswith(".pth")][0]
        idx = [f for f in os.listdir(sub) if f.endswith(".index")]
        self.index_path = os.path.join(sub, idx[0]) if idx else ""
        self.rvc.load_model(os.path.join(sub, pth), index_path=self.index_path)
        self.model_name = name
        self._reset()

    def tgt_sr(self):
        return self.rvc.vc.tgt_sr

    def _convert16(self, win16):
        vc = self.rvc.vc
        out = vc.pipeline.pipeline(
            vc.hubert_model, vc.net_g, 0, win16.astype(np.float32),
            "", [0, 0, 0], int(self.pitch), "rmvpe",
            self.index_path or "", float(self.index_rate), vc.if_f0,
            3, vc.tgt_sr, 0, 0.25, vc.version, float(self.protect), "")
        out = np.asarray(out)
        if np.issubdtype(out.dtype, np.integer):
            return out.astype(np.float32) / 32768.0
        out = out.astype(np.float32)
        if len(out) and np.max(np.abs(out)) > 1.5:
            out = out / 32768.0
        return out

    # 处理一块新输入(16k mono float) -> 一块输出(out_sr mono float)
    def process(self, new16, hop_sec, overlap_sec=0.12, xfade_sec=0.06):
        ov16 = int(overlap_sec * 16000)
        window = np.concatenate([self.prev_in_tail, new16]) if len(self.prev_in_tail) else new16
        t0 = time.time()
        conv = self._convert16(window)
        win_sec = len(window) / 16000.0
        self.last_rtf = (time.time() - t0) / win_sec if win_sec > 0 else 0.0
        conv_out = resample(conv, self.tgt_sr(), self.out_sr)
        n_out = int(hop_sec * self.out_sr)
        out_block = (conv_out[-n_out:] if len(conv_out) >= n_out else conv_out).copy()
        xf = int(xfade_sec * self.out_sr)
        if xf > 0 and len(self.prev_out_tail) >= xf and len(out_block) >= xf:
            fade = np.linspace(0, 1, xf, dtype=np.float32)
            out_block[:xf] = self.prev_out_tail[-xf:] * (1 - fade) + out_block[:xf] * fade
        self.prev_in_tail = (window[-ov16:] if len(window) >= ov16 else window).copy()
        self.prev_out_tail = (out_block[-xf:] if len(out_block) >= xf else out_block).copy()
        return out_block

# ---------------- 离线自测（headless 验证流式引擎正确性）----------------
def selftest():
    import soundfile as sf
    eng = Engine()
    models = list_models()
    print("models:", models)
    eng.load(models[0]); eng.out_sr = eng.tgt_sr(); eng.pitch = 12; eng.index_rate = 0.5
    y, sr = sf.read(os.path.join(D, "source_male.wav"))
    if y.ndim > 1: y = y.mean(1)
    y16 = resample(y.astype(np.float32), sr, 16000)
    hop = 1.0; hop16 = int(hop * 16000); outs = []
    for i in range(0, len(y16), hop16):
        blk = y16[i:i + hop16]
        if len(blk) < hop16: blk = np.pad(blk, (0, hop16 - len(blk)))
        outs.append(eng.process(blk, hop))
    out = np.concatenate(outs)
    op = os.path.join(D, "out_stream_selftest.wav")
    sf.write(op, out, eng.out_sr)
    print(f"selftest -> {op}  {len(out)/eng.out_sr:.2f}s  model={eng.model_name}  tgt_sr={eng.tgt_sr()}  last_rtf={eng.last_rtf:.3f}")

# ---------------- 实时 (sounddevice) ----------------
class Live:
    def __init__(self, eng):
        self.eng = eng; self.running = False

    def start(self, in_dev, out_dev, hop_sec):
        import sounddevice as sd
        self.sd = sd
        self.in_sr = int(sd.query_devices(in_dev)['default_samplerate'])
        self.out_sr = int(sd.query_devices(out_dev)['default_samplerate'])
        self.eng.out_sr = self.out_sr; self.eng._reset()
        self.hop = hop_sec
        self.in_buf = np.zeros(0, dtype=np.float32); self.in_lock = threading.Lock()
        self.out_buf = np.zeros(0, dtype=np.float32); self.out_lock = threading.Lock()
        self.level = 0.0; self.running = True
        self.in_stream = sd.InputStream(device=in_dev, channels=1, samplerate=self.in_sr,
                                        dtype='float32', blocksize=int(0.05*self.in_sr), callback=self._in_cb)
        self.out_stream = sd.OutputStream(device=out_dev, channels=1, samplerate=self.out_sr,
                                          dtype='float32', blocksize=int(0.05*self.out_sr), callback=self._out_cb)
        self.in_stream.start(); self.out_stream.start()
        self.worker = threading.Thread(target=self._work, daemon=True); self.worker.start()

    def _in_cb(self, indata, frames, t, status):
        x = indata[:, 0].copy()
        self.level = float(np.sqrt(np.mean(x*x))) if len(x) else 0.0
        with self.in_lock:
            self.in_buf = np.concatenate([self.in_buf, x])

    def _out_cb(self, outdata, frames, t, status):
        with self.out_lock:
            n = min(frames, len(self.out_buf))
            outdata[:n, 0] = self.out_buf[:n]; outdata[n:, 0] = 0.0
            self.out_buf = self.out_buf[n:]

    def _work(self):
        take = int(self.hop * self.in_sr)
        while self.running:
            chunk = None
            with self.in_lock:
                if len(self.in_buf) >= take:
                    chunk = self.in_buf[:take]; self.in_buf = self.in_buf[take:]
            if chunk is None:
                time.sleep(0.01); continue
            try:
                new16 = resample(chunk, self.in_sr, 16000)
                outb = self.eng.process(new16, self.hop)
                with self.out_lock:
                    self.out_buf = np.concatenate([self.out_buf, outb])
            except Exception as e:
                print("process error:", repr(e)[:160])

    def stop(self):
        self.running = False
        for s in ("in_stream", "out_stream"):
            try:
                st = getattr(self, s, None)
                if st: st.stop(); st.close()
            except Exception:
                pass

# ---------------- GUI ----------------
def gui():
    import tkinter as tk
    from tkinter import ttk
    import sounddevice as sd

    root = tk.Tk(); root.title("实时 RVC 变声 (CPU)"); root.geometry("560x430")
    state = {"eng": None, "live": None}

    inputs = [(i, d['name']) for i, d in enumerate(sd.query_devices()) if d['max_input_channels'] > 0]
    outputs = [(i, d['name']) for i, d in enumerate(sd.query_devices()) if d['max_output_channels'] > 0]

    frm = ttk.Frame(root, padding=12); frm.pack(fill="both", expand=True)
    def row(label):
        f = ttk.Frame(frm); f.pack(fill="x", pady=4); ttk.Label(f, text=label, width=12).pack(side="left"); return f

    f = row("音色模型")
    model_cb = ttk.Combobox(f, values=list_models(), state="readonly"); model_cb.pack(side="left", fill="x", expand=True)
    if list_models(): model_cb.current(0)

    f = row("输入(麦克风)")
    in_cb = ttk.Combobox(f, values=[f"{i}: {n[:34]}" for i, n in inputs], state="readonly"); in_cb.pack(side="left", fill="x", expand=True)
    if inputs: in_cb.current(0)
    f = row("输出(扬声器/虚拟声卡)")
    out_cb = ttk.Combobox(f, values=[f"{i}: {n[:34]}" for i, n in outputs], state="readonly"); out_cb.pack(side="left", fill="x", expand=True)
    if outputs: out_cb.current(0)

    pitch = tk.DoubleVar(value=12.0)
    f = row("音高(半音)"); ttk.Scale(f, from_=-12, to=12, variable=pitch, command=lambda v: plab.config(text=f"{pitch.get():+.0f}")).pack(side="left", fill="x", expand=True)
    plab = ttk.Label(f, text="+12", width=5); plab.pack(side="left")
    ttk.Label(frm, text="男→女 +12，女→男 -12，同性别 0", foreground="#888").pack(anchor="w")

    idx = tk.DoubleVar(value=0.0)
    f = row("音色贴合度"); ttk.Scale(f, from_=0, to=1, variable=idx, command=lambda v: ilab.config(text=f"{idx.get():.2f}")).pack(side="left", fill="x", expand=True)
    ilab = ttk.Label(f, text="0.00", width=5); ilab.pack(side="left")
    ttk.Label(frm, text="越高越像目标音色，但 CPU 更慢更易卡（实时建议 0~0.3）", foreground="#888").pack(anchor="w")

    block = tk.DoubleVar(value=4.0)
    f = row("块/延迟(秒)"); ttk.Scale(f, from_=1.0, to=6.0, variable=block, command=lambda v: blab.config(text=f"{block.get():.2f}")).pack(side="left", fill="x", expand=True)
    blab = ttk.Label(f, text="4.00", width=5); blab.pack(side="left")
    ttk.Label(frm, text="⚠ CPU 实测约需 4s 才不卡（RTF<1）；越小延迟越低但会跟不上。低延迟实时需 GPU。", foreground="#c70").pack(anchor="w")

    status = tk.StringVar(value="就绪。选模型/设备后点开始（首次加载约几秒）。")
    btn_f = ttk.Frame(frm); btn_f.pack(fill="x", pady=8)
    start_btn = ttk.Button(btn_f, text="开始变声"); start_btn.pack(side="left")
    stop_btn = ttk.Button(btn_f, text="停止", state="disabled"); stop_btn.pack(side="left", padx=6)
    ttk.Label(frm, textvariable=status, wraplength=520, foreground="#3a7").pack(anchor="w", pady=4)
    stat2 = tk.StringVar(value=""); ttk.Label(frm, textvariable=stat2, foreground="#888").pack(anchor="w")

    def push_params():
        if state["eng"]:
            state["eng"].pitch = pitch.get(); state["eng"].index_rate = idx.get()

    def do_start():
        if not model_cb.get(): return
        start_btn.config(state="disabled"); status.set("加载模型中…")
        def worker():
            try:
                if state["eng"] is None:
                    state["eng"] = Engine()
                eng = state["eng"]
                if eng.model_name != model_cb.get():
                    eng.load(model_cb.get())
                eng.pitch = pitch.get(); eng.index_rate = idx.get()
                in_dev = inputs[in_cb.current()][0]; out_dev = outputs[out_cb.current()][0]
                state["live"] = Live(eng); state["live"].start(in_dev, out_dev, block.get())
                status.set(f"运行中（{eng.model_name}, 输出 {eng.out_sr}Hz）。戴耳机或输出到虚拟声卡避免啸叫。")
                root.after(0, lambda: stop_btn.config(state="normal"))
            except Exception as e:
                status.set("出错: " + repr(e)[:200]); root.after(0, lambda: start_btn.config(state="normal"))
        threading.Thread(target=worker, daemon=True).start()

    def do_stop():
        if state["live"]: state["live"].stop(); state["live"] = None
        start_btn.config(state="normal"); stop_btn.config(state="disabled"); status.set("已停止。")

    start_btn.config(command=do_start); stop_btn.config(command=do_stop)

    def tick():
        push_params()
        lv = state["live"]
        if lv and lv.running and state["eng"]:
            rtf = state["eng"].last_rtf
            keep = "跟得上" if rtf < 1 else "★CPU跟不上,调大块/降低贴合度"
            stat2.set(f"RTF={rtf:.2f} ({keep})   输入电平={lv.level:.3f}")
        root.after(200, tick)
    tick()
    root.mainloop()
    if state["live"]: state["live"].stop()

if __name__ == "__main__":
    if "--selftest" in sys.argv:
        selftest()
    else:
        gui()
