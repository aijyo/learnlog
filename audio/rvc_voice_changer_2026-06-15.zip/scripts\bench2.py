import os, sys, time, numpy as np, soundfile as sf
sys.argv = [sys.argv[0]]
import torch
from rt_rvc import Engine, resample, D

eng = Engine(); eng.load("egirl"); eng.out_sr = eng.tgt_sr()
y, sr = sf.read(os.path.join(D, "source_male.wav"))
if y.ndim > 1: y = y.mean(1)
y16 = resample(y.astype(np.float32), sr, 16000)
# 用更长输入(循环拼接)以得到多块平均
y16 = np.tile(y16, 3)

def bench(ir, hop):
    eng.index_rate = ir; eng.pitch = 12; eng._reset()
    hop16 = int(hop * 16000); times = []
    for i in range(0, len(y16) - hop16, hop16):
        blk = y16[i:i+hop16]
        t0 = time.time(); eng.process(blk, hop); times.append(time.time() - t0)
    times = times[1:]
    avg = sum(times)/len(times)
    print(f"ir={ir} hop={hop}s -> {avg:.2f}s/块 RTF={avg/hop:.2f} {'OK' if avg/hop<0.9 else '跟不上'} (n={len(times)})")

print("torch threads:", torch.get_num_threads())
for hop in [2.0, 3.0, 4.0]:
    bench(0.0, hop)
bench(0.5, 3.0)
