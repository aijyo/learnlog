import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"   # 走国内镜像
from huggingface_hub import hf_hub_download

base_dir = r"D:\code\work\research\voice\rvc_demo\.venv\Lib\site-packages\rvc_python\base_model"
os.makedirs(base_dir, exist_ok=True)
for f in ["hubert_base.pt", "rmvpe.pt", "rmvpe.onnx"]:
    p = hf_hub_download("Daswer123/RVC_Base", f, local_dir=base_dir)
    print("OK", p, os.path.getsize(p) // (1024*1024), "MB")
print("BASE DONE")
