using System.Windows;

namespace RvcWpf
{
    public partial class App : Application { }
}
