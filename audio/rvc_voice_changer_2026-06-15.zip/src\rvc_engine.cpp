#include "rvc_engine.h"

#include <miniaudio.h>
#include "onnxruntime_cxx_api.h"
#include "world/dio.h"
#include "world/stonemask.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <mutex>
#include <random>
#include <thread>
#include <utility>
#include <vector>
#ifdef _WIN32
#include <windows.h>   // GetModuleHandleW / GetProcAddress（动态探测 DirectML EP）
#endif

namespace rvc {

static std::wstring wpath(const std::string& s) { return std::filesystem::path(s).wstring(); }

static std::vector<float> resampleLin(const float* x, size_t n, int sin, int sout) {
    if (sin == sout || n == 0) return std::vector<float>(x, x + n);
    size_t m = (size_t)((double)n * sout / sin);
    std::vector<float> y(m);
    for (size_t i = 0; i < m; ++i) {
        double pos = (double)i * sin / sout;
        size_t i0 = (size_t)pos, i1 = std::min(i0 + 1, n - 1);
        double fr = pos - i0;
        y[i] = (float)(x[i0] * (1 - fr) + x[i1] * fr);
    }
    return y;
}

// 把 [0,total) 拆到多线程跑（每帧独立，用于 IVF 检索）
template <class Fn>
static void parallelFor(int total, Fn fn) {
    int nt = (int)std::thread::hardware_concurrency(); if (nt > 8) nt = 8; if (nt < 1) nt = 1;
    if (total < 2 * nt) { for (int i = 0; i < total; ++i) fn(i); return; }
    std::vector<std::thread> ths; int per = (total + nt - 1) / nt;
    for (int t = 0; t < nt; ++t) {
        int s = t * per, e = std::min(total, s + per); if (s >= e) break;
        ths.emplace_back([&fn, s, e] { for (int i = s; i < e; ++i) fn(i); });
    }
    for (auto& th : ths) th.join();
}

// ---- 自写 IVF 倒排检索（替代 faiss；读 export_index.py 导出的 index.bin）----
struct IvfIndex {
    int n = 0, dim = 0, nlist = 0;
    std::vector<float> centroids;   // nlist*dim
    std::vector<int>   cellStart;   // nlist+1（前缀和）
    std::vector<float> vecs;        // n*dim，按 cell 分组
    bool ok = false;

    bool load(const std::string& path) {
        ok = false; n = dim = nlist = 0;
        centroids.clear(); cellStart.clear(); vecs.clear();
        FILE* f = nullptr;
#ifdef _WIN32
        _wfopen_s(&f, std::filesystem::path(path).wstring().c_str(), L"rb");
#else
        f = std::fopen(path.c_str(), "rb");
#endif
        if (!f) return false;
        int32_t hdr[4];
        if (std::fread(hdr, sizeof(int32_t), 4, f) != 4 || hdr[0] != 0x52564331) { std::fclose(f); return false; }
        n = hdr[1]; dim = hdr[2]; nlist = hdr[3];
        if (n <= 0 || dim <= 0 || nlist <= 0) { std::fclose(f); n = 0; return false; }
        centroids.resize((size_t)nlist * dim);
        cellStart.resize((size_t)nlist + 1);
        vecs.resize((size_t)n * dim);
        bool good =
            std::fread(centroids.data(), sizeof(float), centroids.size(), f) == centroids.size() &&
            std::fread(cellStart.data(), sizeof(int32_t), cellStart.size(), f) == cellStart.size() &&
            std::fread(vecs.data(), sizeof(float), vecs.size(), f) == vecs.size();
        std::fclose(f);
        ok = good; if (!ok) { n = 0; }
        return ok;
    }

    // 1 个 dim 维特征 -> k-NN 加权平均（权重 = (1/平方距离)^2 归一，复刻 RVC）
    void retrieve(const float* q, float* out) const {
        const int K = 8, NPROBE = 8;
        std::vector<std::pair<float, int>> cd(nlist);
        for (int c = 0; c < nlist; ++c) {
            const float* ct = &centroids[(size_t)c * dim];
            float s = 0.f; for (int d = 0; d < dim; ++d) { float t = q[d] - ct[d]; s += t * t; }
            cd[c] = {s, c};
        }
        int np = std::min(NPROBE, nlist);
        std::partial_sort(cd.begin(), cd.begin() + np, cd.end(),
                          [](const std::pair<float, int>& a, const std::pair<float, int>& b) { return a.first < b.first; });
        float bd[8]; int bi[8]; int cnt = 0;
        for (int pi = 0; pi < np; ++pi) {
            int cell = cd[pi].second, s = cellStart[cell], e = cellStart[cell + 1];
            for (int vi = s; vi < e; ++vi) {
                const float* v = &vecs[(size_t)vi * dim];
                float d2 = 0.f; for (int d = 0; d < dim; ++d) { float t = q[d] - v[d]; d2 += t * t; }
                if (cnt < K) { bd[cnt] = d2; bi[cnt] = vi; ++cnt; }
                else { int mx = 0; for (int j = 1; j < K; ++j) if (bd[j] > bd[mx]) mx = j;
                       if (d2 < bd[mx]) { bd[mx] = d2; bi[mx] = vi; } }
            }
        }
        for (int d = 0; d < dim; ++d) out[d] = 0.f;
        if (cnt == 0) { for (int d = 0; d < dim; ++d) out[d] = q[d]; return; }
        float w[8], wsum = 0.f;
        for (int j = 0; j < cnt; ++j) { float s = bd[j] < 1e-8f ? 1e-8f : bd[j]; w[j] = 1.f / (s * s); wsum += w[j]; }
        for (int j = 0; j < cnt; ++j) {
            float wn = w[j] / wsum; const float* v = &vecs[(size_t)bi[j] * dim];
            for (int d = 0; d < dim; ++d) out[d] += wn * v[d];
        }
    }
};

struct Engine::Impl {
    // onnx
    Ort::Env env{ORT_LOGGING_LEVEL_WARNING, "rvc"};
    Ort::SessionOptions so;
    std::unique_ptr<Ort::Session> vec, mdl;
    Ort::AllocatorWithDefaultOptions alloc;
    Ort::MemoryInfo mem = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    std::string vecIn, vecOut;
    bool vecTFirst = true;
    int tgtSr = 48000;
    bool loaded = false;
    bool useGpu = false;     // 期望用 GPU（下次加载生效）
    bool gpuActive = false;  // 实际是否在用 GPU

    // params / stats
    std::atomic<float> pitch{12.0f};
    std::atomic<float> indexRate{0.5f};   // 音色贴合度（检索）
    std::atomic<float> protectV{0.33f};   // 辅音/清音保护
    std::atomic<float> rmsMix{0.25f};     // 响度跟随
    std::atomic<float> rtfv{0.0f}, levelv{0.0f};
    std::atomic<bool> run{false};
    std::string statusText = "未初始化";
    IvfIndex idx;                          // 音色检索（可选，随模型目录的 index.bin）

    // device
    ma_context ctx{}; bool ctxReady = false;
    std::vector<ma_device_id> inIds, outIds;
    std::vector<std::string> inNames, outNames;
    ma_device dev{}; bool devReady = false;

    // audio (device rate fixed 48k mono)
    static constexpr int DEV_SR = 48000;
    std::mutex inMtx, outMtx;
    std::vector<float> inBuf, outBuf;
    std::thread worker;
    std::atomic<float> blockSec{1.0f};

    // streaming state
    std::vector<float> prevInTail;    // 16k context
    std::vector<float> prevOutTail;   // tgtSr crossfade

    // soundboard：独立 ma_engine，把声音文件混入指定输出设备（可与变声同送虚拟声卡）
    ma_engine sbEngine{}; bool sbReady = false; int sbDevIdx = -1; float sbVol = 1.0f;
    bool sbInit(int outIdx) {
        ensureCtx();
        sbShutdown();
        ma_engine_config cfg = ma_engine_config_init();
        if (ctxReady) cfg.pContext = &ctx;
        if (outIdx >= 0 && outIdx < (int)outIds.size()) cfg.pPlaybackDeviceID = &outIds[outIdx];
        if (ma_engine_init(&cfg, &sbEngine) != MA_SUCCESS) { sbReady = false; return false; }
        ma_engine_set_volume(&sbEngine, sbVol);
        sbReady = true; sbDevIdx = outIdx; return true;
    }
    bool sbPlay(const std::string& path) {
        return sbReady && ma_engine_play_sound(&sbEngine, path.c_str(), nullptr) == MA_SUCCESS;
    }
    void sbStopAll() { if (sbReady) { int i = sbDevIdx; ma_engine_uninit(&sbEngine); sbReady = false; sbInit(i); } }
    void sbSetVolume(float v) { sbVol = v < 0 ? 0 : (v > 1 ? 1 : v); if (sbReady) ma_engine_set_volume(&sbEngine, sbVol); }
    void sbShutdown() { if (sbReady) { ma_engine_uninit(&sbEngine); sbReady = false; } }

    ~Impl() { stopAll(); sbShutdown(); if (ctxReady) ma_context_uninit(&ctx); }

    void ensureCtx() {
        if (!ctxReady) { if (ma_context_init(nullptr, 0, nullptr, &ctx) == MA_SUCCESS) ctxReady = true; }
        if (!ctxReady) return;
        ma_device_info* pb; ma_uint32 pbN; ma_device_info* cp; ma_uint32 cpN;
        if (ma_context_get_devices(&ctx, &pb, &pbN, &cp, &cpN) != MA_SUCCESS) return;
        outIds.clear(); outNames.clear();
        for (ma_uint32 i = 0; i < pbN; ++i) { outIds.push_back(pb[i].id); outNames.push_back(pb[i].name); }
        inIds.clear(); inNames.clear();
        for (ma_uint32 i = 0; i < cpN; ++i) { inIds.push_back(cp[i].id); inNames.push_back(cp[i].name); }
    }

    // ---- onnx 管线：16k 窗口 -> tgtSr 音频 ----
    std::vector<float> convertWindow(const float* win, int n) {
        // ContentVec
        int64_t vsh[3] = {1, 1, n};
        Ort::Value vt = Ort::Value::CreateTensor<float>(mem, const_cast<float*>(win), n, vsh, 3);
        const char* vinN[] = {vecIn.c_str()}; const char* voutN[] = {vecOut.c_str()};
        auto vo = vec->Run(Ort::RunOptions{nullptr}, vinN, &vt, 1, voutN, 1);
        float* vd = vo[0].GetTensorMutableData<float>();
        auto vs = vo[0].GetTensorTypeAndShapeInfo().GetShape();
        const int C = 768;
        int T = vecTFirst ? (int)vs[1] : (int)vs[2];
        int L = 2 * T;
        std::vector<float> hub((size_t)L * C);
        for (int tt = 0; tt < L; ++tt) {
            int t = tt / 2;
            for (int c = 0; c < C; ++c)
                hub[(size_t)tt * C + c] = vecTFirst ? vd[(size_t)t * C + c] : vd[(size_t)c * T + t];
        }
        // f0 (WORLD)
        std::vector<double> x(n); for (int i = 0; i < n; ++i) x[i] = win[i];
        DioOption opt; InitializeDioOption(&opt); opt.frame_period = 5.0; opt.f0_floor = 50; opt.f0_ceil = 1100;
        int nf = GetSamplesForDIO(16000, n, opt.frame_period);
        std::vector<double> tp(nf), f0(nf), rf0(nf);
        Dio(x.data(), n, 16000, &opt, tp.data(), f0.data());
        StoneMask(x.data(), n, 16000, tp.data(), f0.data(), nf, rf0.data());
        std::vector<float> pitchf(L);
        double sc = std::pow(2.0, pitch.load() / 12.0);
        for (int i = 0; i < L; ++i) {
            double pos = (nf > 1) ? (double)i / (L - 1) * (nf - 1) : 0.0;
            int i0 = (int)pos, i1 = std::min(i0 + 1, nf - 1); double fr = pos - i0;
            pitchf[i] = (float)((rf0[i0] * (1 - fr) + rf0[i1] * fr) * sc);
        }
        // ---- 音色检索(index_rate) + 辅音保护(protect) ----
        float ir = indexRate.load(), pr = protectV.load();
        bool doIdx = idx.ok && idx.dim == C && ir > 0.001f;
        bool doPro = pr < 0.5f;
        std::vector<float> hub0;
        if (doPro) hub0 = hub;                       // 保存检索前特征
        if (doIdx) {
            parallelFor(L, [&](int tt) {
                float ret[768];
                idx.retrieve(&hub[(size_t)tt * C], ret);
                float* h = &hub[(size_t)tt * C];
                for (int c = 0; c < C; ++c) h[c] = ir * ret[c] + (1.f - ir) * h[c];
            });
        }
        if (doPro) {
            for (int tt = 0; tt < L; ++tt) {
                float m = (pitchf[tt] > 0.f) ? 1.f : pr;   // 浊音保留检索，清音混回原特征
                if (m >= 0.999f) continue;
                float* h = &hub[(size_t)tt * C]; const float* h0 = &hub0[(size_t)tt * C];
                for (int c = 0; c < C; ++c) h[c] = h[c] * m + h0[c] * (1.f - m);
            }
        }
        double mmin = 1127 * std::log(1 + 50.0 / 700), mmax = 1127 * std::log(1 + 1100.0 / 700);
        std::vector<int64_t> pit(L);
        for (int i = 0; i < L; ++i) {
            double fm = 1127 * std::log(1 + pitchf[i] / 700);
            if (fm > 0) fm = (fm - mmin) * 254 / (mmax - mmin) + 1;
            if (fm <= 1) fm = 1; if (fm > 255) fm = 255;
            pit[i] = (int64_t)std::llround(fm);
        }
        std::vector<float> rnd((size_t)192 * L);
        static std::mt19937 rng(1234); std::normal_distribution<float> nd(0.f, 1.f);
        for (auto& v : rnd) v = nd(rng);
        // model
        int64_t plen = L, ds = 0;
        int64_t phsh[3] = {1, L, C}, plsh[1] = {1}, pish[2] = {1, L}, dssh[1] = {1}, rsh[3] = {1, 192, L};
        std::vector<Ort::Value> mi;
        mi.push_back(Ort::Value::CreateTensor<float>(mem, hub.data(), hub.size(), phsh, 3));
        mi.push_back(Ort::Value::CreateTensor<int64_t>(mem, &plen, 1, plsh, 1));
        mi.push_back(Ort::Value::CreateTensor<int64_t>(mem, pit.data(), pit.size(), pish, 2));
        mi.push_back(Ort::Value::CreateTensor<float>(mem, pitchf.data(), pitchf.size(), pish, 2));
        mi.push_back(Ort::Value::CreateTensor<int64_t>(mem, &ds, 1, dssh, 1));
        mi.push_back(Ort::Value::CreateTensor<float>(mem, rnd.data(), rnd.size(), rsh, 3));
        const char* minN[] = {"phone", "phone_lengths", "pitch", "pitchf", "ds", "rnd"};
        const char* moutN[] = {"audio"};
        auto mo = mdl->Run(Ort::RunOptions{nullptr}, minN, mi.data(), 6, moutN, 1);
        float* od = mo[0].GetTensorMutableData<float>();
        auto os = mo[0].GetTensorTypeAndShapeInfo().GetShape();
        size_t M = 1; for (auto d : os) M *= (size_t)d;
        return std::vector<float>(od, od + M);
    }

    // 处理一块新 16k 输入 -> tgtSr 输出（含上下文+交叉淡化）
    std::vector<float> processBlock(const std::vector<float>& new16) {
        const int ov16 = (int)(0.12 * 16000);
        std::vector<float> window;
        window.reserve(prevInTail.size() + new16.size());
        window.insert(window.end(), prevInTail.begin(), prevInTail.end());
        window.insert(window.end(), new16.begin(), new16.end());

        auto t0 = std::chrono::steady_clock::now();
        std::vector<float> conv = convertWindow(window.data(), (int)window.size());
        double winSec = window.size() / 16000.0;
        rtfv.store(winSec > 0 ? (float)(std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count() / winSec) : 0.f);

        int nOut = (int)(blockSec.load() * tgtSr);
        std::vector<float> out;
        if ((int)conv.size() >= nOut) out.assign(conv.end() - nOut, conv.end());
        else out = conv;

        int xf = (int)(0.06 * tgtSr);
        if (xf > 0 && (int)prevOutTail.size() >= xf && (int)out.size() >= xf) {
            for (int i = 0; i < xf; ++i) {
                float a = (float)i / xf;
                out[i] = prevOutTail[prevOutTail.size() - xf + i] * (1 - a) + out[i] * a;
            }
        }
        // ---- 响度跟随 (rms_mix_rate): 输出整体响度向输入靠拢（每块标量增益）----
        float rmsRate = rmsMix.load();
        if (rmsRate < 0.999f && !out.empty() && !new16.empty()) {
            double s1 = 0; for (float v : new16) s1 += (double)v * v;
            double s2 = 0; for (float v : out)   s2 += (double)v * v;
            double rms1 = std::sqrt(s1 / new16.size()), rms2 = std::sqrt(s2 / out.size());
            if (rms2 > 1e-6) {
                double gain = std::pow(rms1 / rms2, 1.0 - (double)rmsRate);
                gain = std::min(std::max(gain, 0.1), 10.0);
                for (float& v : out) v = (float)(v * gain);
            }
        }
        prevInTail.assign(window.size() >= (size_t)ov16 ? window.end() - ov16 : window.begin(), window.end());
        prevOutTail.assign(out.size() >= (size_t)xf ? out.end() - xf : out.begin(), out.end());
        return out;
    }

    static void dataCb(ma_device* d, void* out, const void* in, ma_uint32 n) {
        auto* self = (Impl*)d->pUserData;
        const float* pin = (const float*)in; float* pout = (float*)out;
        // 推入输入
        double s = 0; for (ma_uint32 i = 0; i < n; ++i) s += (double)pin[i] * pin[i];
        self->levelv.store(n ? (float)std::sqrt(s / n) : 0.f);
        { std::lock_guard<std::mutex> lk(self->inMtx); self->inBuf.insert(self->inBuf.end(), pin, pin + n); }
        // 拉出输出
        std::lock_guard<std::mutex> lk(self->outMtx);
        ma_uint32 k = (ma_uint32)std::min((size_t)n, self->outBuf.size());
        for (ma_uint32 i = 0; i < k; ++i) pout[i] = self->outBuf[i];
        for (ma_uint32 i = k; i < n; ++i) pout[i] = 0.f;
        if (k) self->outBuf.erase(self->outBuf.begin(), self->outBuf.begin() + k);
    }

    void workerLoop() {
        while (run.load()) {
            int takeDev = (int)(blockSec.load() * DEV_SR);
            std::vector<float> chunkDev;
            { std::lock_guard<std::mutex> lk(inMtx);
              if ((int)inBuf.size() >= takeDev) { chunkDev.assign(inBuf.begin(), inBuf.begin() + takeDev); inBuf.erase(inBuf.begin(), inBuf.begin() + takeDev); } }
            if (chunkDev.empty()) { std::this_thread::sleep_for(std::chrono::milliseconds(5)); continue; }
            std::vector<float> new16 = resampleLin(chunkDev.data(), chunkDev.size(), DEV_SR, 16000);
            std::vector<float> outT = processBlock(new16);
            std::vector<float> outDev = resampleLin(outT.data(), outT.size(), tgtSr, DEV_SR);
            { std::lock_guard<std::mutex> lk(outMtx); outBuf.insert(outBuf.end(), outDev.begin(), outDev.end()); }
        }
    }

    void stopAll() {
        run.store(false);
        if (worker.joinable()) worker.join();
        if (devReady) { ma_device_uninit(&dev); devReady = false; }
    }
};

Engine::Engine() : p_(std::make_unique<Impl>()) { p_->so.SetIntraOpNumThreads(0); }
Engine::~Engine() = default;

bool Engine::loadModels(const std::string& vecOnnx, const std::string& modelOnnx) {
    try {
        // 每次加载按 CPU/GPU 重建 session options
        Ort::SessionOptions so;
        so.SetIntraOpNumThreads(0);
        p_->gpuActive = false;
        std::string ep = "CPU";
        if (p_->useGpu) {
#ifdef _WIN32
            using DmlFn = OrtStatus* (*)(OrtSessionOptions*, int);
            HMODULE m = GetModuleHandleW(L"onnxruntime.dll");
            DmlFn dml = m ? reinterpret_cast<DmlFn>(GetProcAddress(m, "OrtSessionOptionsAppendExecutionProvider_DML")) : nullptr;
            if (!dml) {
                ep = "CPU(未检测到 DirectML 版 onnxruntime.dll)";
            } else {
                // 双显卡时 device 0 不一定可用，遍历 0..3 取第一个能建 D3D12 设备的适配器
                std::string lastErr = "?";
                for (int dev = 0; dev < 4 && !p_->gpuActive; ++dev) {
                    Ort::SessionOptions trial;
                    trial.SetIntraOpNumThreads(0);
                    trial.DisableMemPattern();
                    trial.SetExecutionMode(ORT_SEQUENTIAL);
                    OrtStatus* st = dml(static_cast<OrtSessionOptions*>(trial), dev);
                    if (!st) { so = std::move(trial); p_->gpuActive = true; ep = "GPU(DirectML dev" + std::to_string(dev) + ")"; }
                    else { const char* msg = Ort::GetApi().GetErrorMessage(st); lastErr = msg ? msg : "?"; Ort::GetApi().ReleaseStatus(st); }
                }
                if (!p_->gpuActive) ep = "CPU(DML无可用GPU:" + lastErr.substr(0, 60) + ")";
            }
#else
            ep = "CPU(仅 Windows 支持 DirectML)";
#endif
        }
        p_->vec = std::make_unique<Ort::Session>(p_->env, wpath(vecOnnx).c_str(), so);
        p_->mdl = std::make_unique<Ort::Session>(p_->env, wpath(modelOnnx).c_str(), so);
        p_->vecIn = p_->vec->GetInputNameAllocated(0, p_->alloc).get();
        p_->vecOut = p_->vec->GetOutputNameAllocated(0, p_->alloc).get();
        // 探测 vec 布局 + 目标采样率（用 1s 静音过一遍管线）
        std::vector<float> probe(16000, 0.f);
        int64_t vsh[3] = {1, 1, 16000};
        Ort::Value vt = Ort::Value::CreateTensor<float>(p_->mem, probe.data(), 16000, vsh, 3);
        const char* vinN[] = {p_->vecIn.c_str()}; const char* voutN[] = {p_->vecOut.c_str()};
        auto vo = p_->vec->Run(Ort::RunOptions{nullptr}, vinN, &vt, 1, voutN, 1);
        auto vs = vo[0].GetTensorTypeAndShapeInfo().GetShape();
        p_->vecTFirst = (vs[2] == 768);
        std::vector<float> conv = p_->convertWindow(probe.data(), 16000);
        int Lprobe = p_->vecTFirst ? 2 * (int)vs[1] : 2 * (int)vs[2];
        p_->tgtSr = Lprobe > 0 ? (int)std::llround((double)conv.size() / Lprobe * 100.0) : 48000;
        p_->loaded = true;
        p_->statusText = "已加载 (tgt_sr=" + std::to_string(p_->tgtSr) + ", " + ep + ")";
        // 同目录 index.bin（音色检索，可选）
        p_->idx = IvfIndex{};
        {
            std::filesystem::path ip = std::filesystem::path(modelOnnx).parent_path() / "index.bin";
            if (p_->idx.load(ip.string()))
                p_->statusText += "  [检索 index ✓ n=" + std::to_string(p_->idx.n) + "]";
            else
                p_->statusText += "  [无 index.bin，音色贴合度无效]";
        }
        return true;
    } catch (const std::exception& e) {
        p_->statusText = std::string("加载失败: ") + e.what();
        p_->loaded = false;
        return false;
    }
}

bool Engine::ready() const { return p_->loaded; }
int  Engine::targetSampleRate() const { return p_->tgtSr; }
void Engine::setUseGpu(bool g) { p_->useGpu = g; }
bool Engine::gpuActive() const { return p_->gpuActive; }

int  Engine::inputDeviceCount() { p_->ensureCtx(); return (int)p_->inNames.size(); }
const char* Engine::inputDeviceName(int i) { return (i >= 0 && i < (int)p_->inNames.size()) ? p_->inNames[i].c_str() : ""; }
int  Engine::outputDeviceCount() { p_->ensureCtx(); return (int)p_->outNames.size(); }
const char* Engine::outputDeviceName(int i) { return (i >= 0 && i < (int)p_->outNames.size()) ? p_->outNames[i].c_str() : ""; }

bool Engine::start(int inDev, int outDev, float blockSec) {
    if (!p_->loaded || p_->run.load()) return p_->run.load();
    p_->ensureCtx();
    p_->blockSec.store(blockSec < 0.3f ? 0.3f : blockSec);
    p_->prevInTail.clear(); p_->prevOutTail.clear();
    { std::lock_guard<std::mutex> a(p_->inMtx), b(p_->outMtx); p_->inBuf.clear(); p_->outBuf.clear(); }

    ma_device_config cfg = ma_device_config_init(ma_device_type_duplex);
    cfg.sampleRate = Impl::DEV_SR;
    cfg.capture.format = ma_format_f32; cfg.capture.channels = 1;
    cfg.capture.pDeviceID = (inDev >= 0 && inDev < (int)p_->inIds.size()) ? &p_->inIds[inDev] : nullptr;
    cfg.playback.format = ma_format_f32; cfg.playback.channels = 1;
    cfg.playback.pDeviceID = (outDev >= 0 && outDev < (int)p_->outIds.size()) ? &p_->outIds[outDev] : nullptr;
    cfg.performanceProfile = ma_performance_profile_low_latency;
    cfg.periodSizeInMilliseconds = 30;
    cfg.dataCallback = &Impl::dataCb;
    cfg.pUserData = p_.get();
    if (ma_device_init(p_->ctxReady ? &p_->ctx : nullptr, &cfg, &p_->dev) != MA_SUCCESS) { p_->statusText = "打开音频设备失败"; return false; }
    if (ma_device_start(&p_->dev) != MA_SUCCESS) { ma_device_uninit(&p_->dev); p_->statusText = "启动设备失败"; return false; }
    p_->devReady = true; p_->run.store(true);
    p_->worker = std::thread([this] { p_->workerLoop(); });
    p_->statusText = "运行中（戴耳机或输出虚拟声卡避免啸叫）";
    return true;
}

void Engine::stop() { p_->stopAll(); p_->statusText = "已停止"; }
bool Engine::running() const { return p_->run.load(); }
float Engine::benchmark(float seconds) {
    if (!p_->loaded || seconds <= 0) return -1.f;
    int n = (int)(seconds * 16000);
    std::vector<float> x(n);
    for (int i = 0; i < n; ++i) x[i] = 0.1f * std::sin(2.f * 3.14159265f * 150.f * i / 16000.f);
    p_->convertWindow(x.data(), n);  // 预热（GPU 首次会编译内核）
    auto t0 = std::chrono::steady_clock::now();
    p_->convertWindow(x.data(), n);
    double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    return (float)(dt / seconds);
}

void Engine::setPitch(float s) { p_->pitch.store(s); }
void Engine::setBlock(float s) { p_->blockSec.store(s < 0.3f ? 0.3f : s); }
void Engine::setIndexRate(float r) { p_->indexRate.store(r < 0.f ? 0.f : (r > 1.f ? 1.f : r)); }
void Engine::setProtect(float p) { p_->protectV.store(p < 0.f ? 0.f : (p > 0.5f ? 0.5f : p)); }
void Engine::setRms(float r) { p_->rmsMix.store(r < 0.f ? 0.f : (r > 1.f ? 1.f : r)); }
bool Engine::hasIndex() const { return p_->idx.ok; }
bool Engine::soundboardInit(int outDev) { return p_->sbInit(outDev); }
bool Engine::soundboardPlay(const std::string& path) { return p_->sbPlay(path); }
void Engine::soundboardStopAll() { p_->sbStopAll(); }
void Engine::soundboardVolume(float v) { p_->sbSetVolume(v); }
void Engine::soundboardShutdown() { p_->sbShutdown(); }
float Engine::rtf() const { return p_->rtfv.load(); }
float Engine::level() const { return p_->levelv.load(); }
const char* Engine::status() { return p_->statusText.c_str(); }

} // namespace rvc
