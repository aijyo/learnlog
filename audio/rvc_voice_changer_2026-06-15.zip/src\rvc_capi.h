// C-ABI 导出，给 C#/WPF P/Invoke。字符串返回为 UTF-8 (C# 用 Marshal.PtrToStringUTF8)。
#pragma once
#ifdef _WIN32
#define RVC_API __declspec(dllexport)
#else
#define RVC_API
#endif

extern "C" {
RVC_API void*       rvc_create();
RVC_API void        rvc_destroy(void* h);
RVC_API void        rvc_set_gpu(void* h, int use_gpu);     // 1=下次加载走 DirectML GPU
RVC_API int         rvc_gpu_active(void* h);               // 1=当前真的在用 GPU
RVC_API int         rvc_load(void* h, const char* vec_onnx, const char* model_onnx); // 1=ok
RVC_API int         rvc_target_sr(void* h);
RVC_API int         rvc_in_count(void* h);
RVC_API const char* rvc_in_name(void* h, int i);
RVC_API int         rvc_out_count(void* h);
RVC_API const char* rvc_out_name(void* h, int i);
RVC_API int         rvc_start(void* h, int in_dev, int out_dev, float block_sec); // 1=ok
RVC_API void        rvc_stop(void* h);
RVC_API int         rvc_running(void* h);
RVC_API void        rvc_set_pitch(void* h, float semitones);
RVC_API void        rvc_set_block(void* h, float sec);
RVC_API void        rvc_set_index(void* h, float rate);    // 0..1 音色贴合度
RVC_API void        rvc_set_protect(void* h, float p);     // <0.5 辅音保护
RVC_API void        rvc_set_rms(void* h, float rate);      // 0..1 响度跟随
RVC_API int         rvc_has_index(void* h);                // 1=当前模型带 index.bin
RVC_API float       rvc_bench(void* h, float seconds);     // 离线测 RTF（CPU/GPU 对比）
RVC_API float       rvc_rtf(void* h);
RVC_API float       rvc_level(void* h);
RVC_API const char* rvc_status(void* h);
// 声音面板
RVC_API int         rvc_sb_init(void* h, int out_dev);     // 1=ok
RVC_API int         rvc_sb_play(void* h, const char* path); // 1=ok
RVC_API void        rvc_sb_stop(void* h);
RVC_API void        rvc_sb_volume(void* h, float v);
RVC_API void        rvc_sb_shutdown(void* h);
}
