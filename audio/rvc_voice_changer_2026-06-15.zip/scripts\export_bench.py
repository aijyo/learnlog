# 导出 RVC 模型 -> onnx，并基准 onnxruntime CPU 的模型 forward 每块耗时。
import os, sys, time
sys.argv = [sys.argv[0]]
import torch
_ol = torch.load
def _pl(*a, **k): k.setdefault("weights_only", False); return _ol(*a, **k)
torch.load = _pl
import numpy as np
from rvc_python.modules.onnx.export import export_onnx

D = r"D:\code\work\research\voice\rvc_demo"
egirl_pth = os.path.join(D, "models", "egirl", "egirl.pth")
egirl_onnx = os.path.join(D, "models", "egirl", "egirl.onnx")
trump_pth = os.path.join(D, "models", "Donald-Trump", "Trump_e160_s7520.pth")
trump_onnx = os.path.join(D, "models", "Donald-Trump", "Trump.onnx")

print("export egirl ->", export_onnx(egirl_pth, egirl_onnx), f"{os.path.getsize(egirl_onnx)//1024//1024}MB")
print("export trump ->", export_onnx(trump_pth, trump_onnx), f"{os.path.getsize(trump_onnx)//1024//1024}MB")

import onnxruntime as ort
print("onnxruntime", ort.__version__, "providers:", ort.get_available_providers())
sess = ort.InferenceSession(egirl_onnx, providers=["CPUExecutionProvider"])
print("model inputs:", [i.name for i in sess.get_inputs()])

def bench(frames, n=6):
    feed = {
        "phone": np.random.rand(1, frames, 768).astype(np.float32),
        "phone_lengths": np.array([frames]).astype(np.int64),
        "pitch": np.random.randint(5, 255, size=(1, frames)).astype(np.int64),
        "pitchf": np.random.rand(1, frames).astype(np.float32),
        "ds": np.array([0]).astype(np.int64),
        "rnd": np.random.rand(1, 192, frames).astype(np.float32),
    }
    out = sess.run(None, feed)  # warmup
    t0 = time.time()
    for _ in range(n): out = sess.run(None, feed)
    dt = (time.time() - t0) / n
    block_sec = frames / 100.0   # hubert 50Hz*repeat2=100Hz -> 100帧≈1s
    print(f"frames={frames} (~{block_sec:.1f}s): 模型onnx forward {dt*1000:.0f}ms  RTF_model={dt/block_sec:.3f}  out={out[0].shape}")

for fr in [100, 200, 400]:
    bench(fr)
