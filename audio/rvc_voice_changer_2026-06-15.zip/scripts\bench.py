# 基准：测不同 index_rate / 块大小下的实时吞吐 RTF (= 单块处理耗时 / 块时长)。<1 才能实时。
import os, sys, time, numpy as np, soundfile as sf
sys.argv = [sys.argv[0]]  # 避免 rt_rvc 误判
from rt_rvc import Engine, resample, list_models, D

eng = Engine()
eng.load("egirl"); eng.out_sr = eng.tgt_sr()
y, sr = sf.read(os.path.join(D, "source_male.wav"))
if y.ndim > 1: y = y.mean(1)
y16 = resample(y.astype(np.float32), sr, 16000)

def bench(ir, hop):
    eng.index_rate = ir; eng.pitch = 12; eng._reset()
    hop16 = int(hop * 16000); times = []
    for i in range(0, len(y16), hop16):
        blk = y16[i:i+hop16]
        if len(blk) < hop16: blk = np.pad(blk, (0, hop16 - len(blk)))
        t0 = time.time(); eng.process(blk, hop); times.append(time.time() - t0)
    times = times[1:] if len(times) > 1 else times   # 去掉首块预热
    avg = sum(times)/len(times)
    print(f"index_rate={ir}  hop={hop}s  ->  单块耗时 {avg:.2f}s  吞吐RTF={avg/hop:.2f}  {'OK实时' if avg/hop<0.95 else '跟不上'}")

for ir in [0.5, 0.0]:
    for hop in [1.0, 1.5, 2.0]:
        bench(ir, hop)
