# RVC 实时变声器（C++ / onnxruntime + WPF）

把 **RVC（Retrieval-based Voice Conversion，检索式音色转换）** 用 **C++ + onnxruntime + WORLD(f0)** 实现，
封装成 **C-ABI DLL**，再用 **WPF(C#) 暗色 UI** 驱动。目标：**纯 CPU 低延迟实时**（麦克风 → 转换 → 扬声器 / 虚拟声卡），
可把变声后的声音送进游戏 / Discord / 直播软件。

> 架构与取舍详见 [DESIGN.md](DESIGN.md)。

**功能**
- 实时变声：你的语音 → 目标音色（换 `.pth` 模型即换人），内容/语调不变。
- 质量参数实时可调：音高(跨性别)、音色贴合度(自写 IVF 检索)、辅音保护、响度跟随。
- GPU/CPU 开关（DirectML）+ 一键测速对比 RTF。
- 声音面板（soundboard）：声音文件 + 可录制全局热键，混入输出设备（进游戏）。

---

## ⚠️ 本包不包含什么（需自行获取）

为控制体积，**大体积的运行库（DLL/SDK）和模型权重没有打包**，按下面说明获取。代码 + 小源码依赖(WORLD/miniaudio) + 文档都在包内。

### A. onnxruntime SDK（编译 C++ 必需）
- 下载 **onnxruntime-win-x64-1.19.2.zip**（CPU 版）
  来源：`https://github.com/microsoft/onnxruntime/releases/tag/v1.19.2`
- 解压到：`third_party/onnxruntime-win-x64-1.19.2/`
  解压后应有 `include/`（头文件）和 `lib/onnxruntime.lib`、`lib/onnxruntime.dll`。
- CMake 已按此路径引用（见 `CMakeLists.txt` 的 `ORT` 变量）。

### B. 运行时 DLL
- **CPU 运行**：`onnxruntime.dll`（来自 A 的 `lib/`）。CMake `POST_BUILD` 会自动把它拷到 exe 目录。
- **GPU 运行（可选，DirectML）**：`wpf/RvcWpf.csproj` 引用了 NuGet 包
  **`Microsoft.ML.OnnxRuntime.DirectML 1.19.2`**，`dotnet build` 时会自动从 nuget.org 还原，
  并把 **DML 版 `onnxruntime.dll` + `DirectML.dll`** 放进输出目录（覆盖 CPU 版，DML 版同时支持 CPU/GPU）。
  > 需要能访问 nuget.org。不想用 GPU 就把该 `<PackageReference>` 删掉，仅用 A 的 CPU `onnxruntime.dll`。

### C. 模型（运行必需，按需下载）
放到一个数据目录（下称 `rvc_demo/`，WPF 里 `MainWindow.xaml.cs` 的 `DEMO` 常量指向它，自行改成你的路径）：

| 文件 | 说明 | 来源 |
|------|------|------|
| `vec-768-layer-12.onnx` (~360MB) | ContentVec 内容编码器（C++ 路径必需） | `https://huggingface.co/NaruseMioShirakana/MoeSS-SUBModel/tree/main` |
| `<voice>.pth` + `<voice>.index` | 目标音色模型 + 检索索引 | `https://voice-models.com/`（RVC 音色聚合站，按需搜） |
| `hubert_base.pt` / `rmvpe.pt` | RVC 基础模型（仅 **Python** 路径用；C++ 用 WORLD 代替 f0，不需要） | `https://huggingface.co/lj1995/VoiceConversionWebUI/tree/main/` |

> 网络备注（实测）：HuggingFace 直连常被墙、hf-mirror 大文件会甩回 HF；github releases / nuget.org / pypi 阿里云镜像可达。
> 上面 HF 的文件靠浏览器/代理/换设备下好后拷进来即可。

### D. 由 .pth 生成 C++ 需要的两个文件
C++ 引擎吃的是 **onnx 模型** 和 **index.bin**（不是 `.pth`/`.index`），用包内 `scripts/` 转换（需要 Python + rvc-python 环境，见下）：
```bash
# 1) .pth -> .onnx（音色模型）
python scripts/onnx_convert.py           # 内部调 rvc_python.modules.onnx.export.export_onnx
# 2) .index(faiss) -> index.bin（自写 IVF 检索用；没有它“音色贴合度”无效）
python scripts/export_index.py
```
> 这些脚本里的路径是写死的示例路径，**用前改成你的实际目录**。

---

## 环境要求
- Windows 10 1903+ / 11，x64。
- Visual Studio 2022（MSVC v143）+ CMake ≥ 3.21。
- .NET SDK 9.0（WPF UI）。
- （可选）虚拟声卡 **VB-Audio Virtual Cable**（进游戏用）：`https://vb-audio.com/Cable/`
- （可选，准备模型用）Python 3.9 + rvc-python（坑见 DESIGN.md：pip 需降到 24.0、torch.load 猴补丁）。

---

## 快速开始
```powershell
# 0) 按上面 A/B/C/D 准备好 onnxruntime SDK、模型、index.bin

# 1) 编译 C++（引擎 DLL + 离线转换器）
cmake -S . -B build -A x64
cmake --build build --config Release
#   产物：build/Release/rvc_engine.dll（实时引擎）、build/Release/rvc-onnx.exe（离线转换器）

# 2) 编译并运行 WPF UI
dotnet build wpf/RvcWpf.csproj -c Release
#   产物：wpf/bin/Release/net9.0-windows/RvcVoiceChanger.exe（自动拷入引擎 DLL + onnxruntime/DirectML DLL）
```
离线转换器单测（验证管线）：
```powershell
build\Release\rvc-onnx.exe <vec.onnx> <model.onnx> <in16k.wav> <out.wav> [f0up=12] [tgt_sr=48000]
```

---

## 目录结构
```
rvc_voice_changer/
  README.md / DESIGN.md          # 文档
  CMakeLists.txt                 # C++ 构建（vendored 依赖，无需 vcpkg）
  src/
    rvc_engine.{h,cpp}           # 实时引擎：onnx 管线 + 分块流式 + miniaudio 双流 + 自写 IVF + soundboard + GPU 路径
    rvc_capi.{h,cpp}             # C-ABI 导出（给 WPF P/Invoke）
    rvc_onnx.cpp                 # 离线转换器（独立 exe，验证用）
    miniaudio_impl.cpp / wav.h   # miniaudio 实现 TU / wav 读写
  wpf/
    RvcWpf.csproj                # net9.0-windows，引 DirectML NuGet
    App.xaml(.cs)                # 暗色主题
    MainWindow.xaml(.cs)         # 双 Tab UI（实时变声 / 声音面板）
    RvcNative.cs                 # P/Invoke 声明
  third_party/
    World/src/                   # WORLD f0 源码（BSD，已含）
    miniaudio.h                  # miniaudio 单头（已含）
    onnxruntime-win-x64-1.19.2/  # ← 需自行下载放此（见上 A）
  scripts/                       # Python 准备/参考脚本（export_index.py / onnx_convert.py / run_rvc.py / rt_rvc.py …）
```

---

## 用法

### 实时变声（Tab1）
1. ContentVec 选 `vec-768-layer-12.onnx`；音色模型选 `<voice>.onnx`。
2. 选输入(麦克风) / 输出(扬声器或虚拟声卡)。
3. 「加载模型」→「开始变声」。对麦说话即变声。
4. 实时参数：
   - **音高**：男→女 +12，女→男 -12，同性别 0。RVC 不自动改音高，跨性别必须手动设。
   - **音色贴合度**(0~1)：拉高更像目标音色（用 `.index` 检索；需 `index.bin`）。
   - **辅音保护**(0~0.5)：越小越保护清音/气声，减少机械感。
   - **响度跟随**(0~1)：0=完全跟你的输入响度，1=保持模型自身响度。
5. **测速**：离线跑 1 秒音频出 RTF（<1 才实时），用于对比 CPU/GPU。

### GPU / CPU 开关（Tab1 顶部）
勾「用 GPU (DirectML)」→「加载模型」生效。需要 B 的 DirectML 运行库。
> 本机实测（i7-13700 / RX550）：**CPU RTF≈0.50（实时富余）vs GPU/RX550 RTF≈1.02（更慢）+ 首次加载编译内核~29s** → 弱 GPU 不值得开，强 CPU 更优。开关供将来换强 N 卡用。

### 进游戏（虚拟声卡）
1. app 输出选 **`CABLE Input`**（别选 "CABLE In 16ch"）。
2. 游戏 / Discord / QQ 的麦克风选 **`CABLE Output`**。
3. 游戏端**关掉噪声抑制/回声消除/自动增益**（会糊变声）；Win 声音设置把 CABLE 两端默认格式都设 **48000Hz**。
> VB-Cable 两端口名字反着用：Input=往里播，Output=从里录。输出进 cable 后自己听不到（可用「侦听此设备」监听）。

### 声音面板（Tab2）
1. 输出设备默认自动选 CABLE Input（进游戏那一路）。
2. 「添加声音…」选 wav/mp3/flac/ogg。
3. 每行点「录制」→ 按任意组合键设为热键；勾「启用全局热键」后在游戏里也能触发。
4. 声音与变声叠加送进 CABLE Input。音量滑块 + 停止全部。

---

## 性能实测（i7-13700, 16 核, 纯 CPU, fp32）
- 离线转换器 / 实时引擎全程 **RTF ≈ 0.45~0.50**（含 WORLD f0），**1s 块实时富余**。
- 对比 PyTorch 分块路径 RTF 1.88 → onnxruntime CPU 快约 4×。
- 自写 IVF 检索每块 ~2-3ms，对 RTF 几乎无影响。
- GPU(DirectML/RX550) RTF≈1.02 慢于 CPU（弱卡），见上。

---

## 伦理与许可
- **声音克隆红线**：音色转换只用**本人**或**已获明确同意**的目标语音；**不得用于伪造、冒充、绕过声纹**。仓库内的公众人物模型仅用于本地自然度测试，请勿用于误导/冒充。
- 依赖许可：onnxruntime(MIT)、WORLD(mmorise, BSD/修改版 BSD)、miniaudio(public domain / MIT-0)、DirectML(微软, 随 NuGet)。RVC 模型与 ContentVec 权重各有其授权，自行遵循来源站点条款。
