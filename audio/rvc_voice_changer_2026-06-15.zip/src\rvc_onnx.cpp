// RVC onnx 离线转换器（C++/onnxruntime + WORLD f0）。移植自验证过的 onnx_inference 管线。
// 用法: rvc-onnx <vec.onnx> <model.onnx> <in16k.wav> <out.wav> [f0up=12] [tgt_sr=48000]
#define NOMINMAX
#include <windows.h>
#include "onnxruntime_cxx_api.h"
#include "world/dio.h"
#include "world/stonemask.h"
#include "wav.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <random>
#include <string>
#include <vector>

static std::wstring wpath(const std::string& s) { return std::filesystem::path(s).wstring(); }

int main(int argc, char** argv) {
    if (argc < 5) {
        std::printf("用法: rvc-onnx <vec.onnx> <model.onnx> <in16k.wav> <out.wav> [f0up=12] [tgt_sr=48000]\n");
        return 1;
    }
    const std::string vecp = argv[1], modelp = argv[2], inp = argv[3], outp = argv[4];
    const int f0up = (argc > 5) ? std::atoi(argv[5]) : 12;
    const int tgt_sr = (argc > 6) ? std::atoi(argv[6]) : 48000;

    std::vector<float> wav; int sr = 0;
    if (!wav::readMonoF32(inp, wav, sr)) { std::printf("读取失败: %s\n", inp.c_str()); return 1; }
    if (sr != 16000) std::printf("警告: 输入 %dHz 非16k(本 demo 期望16k源)\n", sr);
    const int N = (int)wav.size();

    Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "rvc");
    Ort::SessionOptions so; so.SetIntraOpNumThreads(0);
    Ort::Session vec(env, wpath(vecp).c_str(), so);
    Ort::Session mdl(env, wpath(modelp).c_str(), so);
    Ort::AllocatorWithDefaultOptions alloc;
    auto mem = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);

    auto t0 = std::chrono::steady_clock::now();

    // ---- ContentVec: 输入 [1,1,N] -> 输出 [1,T,768] 或 [1,768,T] ----
    std::string vin = vec.GetInputNameAllocated(0, alloc).get();
    std::string vout = vec.GetOutputNameAllocated(0, alloc).get();
    int64_t vsh[3] = {1, 1, N};
    Ort::Value vt = Ort::Value::CreateTensor<float>(mem, wav.data(), N, vsh, 3);
    const char* vinN[] = {vin.c_str()}; const char* voutN[] = {vout.c_str()};
    auto vouts = vec.Run(Ort::RunOptions{nullptr}, vinN, &vt, 1, voutN, 1);
    float* vd = vouts[0].GetTensorMutableData<float>();
    auto vs = vouts[0].GetTensorTypeAndShapeInfo().GetShape();   // [1,d1,d2]
    const int C = 768;
    int T; bool tFirst;
    if (vs[2] == 768) { T = (int)vs[1]; tFirst = true; }   // [1,T,768]
    else              { T = (int)vs[2]; tFirst = false; }  // [1,768,T]
    const int L = 2 * T;
    std::vector<float> hub((size_t)L * C);                  // [L,768]
    for (int tt = 0; tt < L; ++tt) {
        const int t = tt / 2;
        for (int c = 0; c < C; ++c)
            hub[(size_t)tt * C + c] = tFirst ? vd[(size_t)t * C + c] : vd[(size_t)c * T + t];
    }

    // ---- f0: WORLD Dio + StoneMask -> 插值到 L -> 移调 -> mel 量化 ----
    std::vector<double> x(N); for (int i = 0; i < N; ++i) x[i] = wav[i];
    DioOption opt; InitializeDioOption(&opt);
    opt.frame_period = 5.0; opt.f0_floor = 50; opt.f0_ceil = 1100;
    const int nf = GetSamplesForDIO(16000, N, opt.frame_period);
    std::vector<double> tpos(nf), f0(nf), rf0(nf);
    Dio(x.data(), N, 16000, &opt, tpos.data(), f0.data());
    StoneMask(x.data(), N, 16000, tpos.data(), f0.data(), nf, rf0.data());

    std::vector<float> pitchf(L);
    const double scale = std::pow(2.0, f0up / 12.0);
    for (int i = 0; i < L; ++i) {
        double pos = (nf > 1) ? (double)i / (L - 1) * (nf - 1) : 0.0;
        int i0 = (int)pos, i1 = std::min(i0 + 1, nf - 1);
        double fr = pos - i0;
        pitchf[i] = (float)((rf0[i0] * (1 - fr) + rf0[i1] * fr) * scale);
    }
    const double f0min = 50, f0max = 1100;
    const double mmin = 1127 * std::log(1 + f0min / 700), mmax = 1127 * std::log(1 + f0max / 700);
    std::vector<int64_t> pitch(L);
    for (int i = 0; i < L; ++i) {
        double fmel = 1127 * std::log(1 + pitchf[i] / 700);
        if (fmel > 0) fmel = (fmel - mmin) * 254 / (mmax - mmin) + 1;
        if (fmel <= 1) fmel = 1; if (fmel > 255) fmel = 255;
        pitch[i] = (int64_t)std::llround(fmel);
    }

    std::vector<float> rnd((size_t)192 * L);
    std::mt19937 rng(1234); std::normal_distribution<float> nd(0.f, 1.f);
    for (auto& v : rnd) v = nd(rng);

    // ---- 模型 onnx ----
    int64_t plen = L, ds = 0;
    int64_t phsh[3] = {1, L, C}, plsh[1] = {1}, pish[2] = {1, L}, dssh[1] = {1}, rsh[3] = {1, 192, L};
    std::vector<Ort::Value> mins;
    mins.push_back(Ort::Value::CreateTensor<float>(mem, hub.data(), hub.size(), phsh, 3));
    mins.push_back(Ort::Value::CreateTensor<int64_t>(mem, &plen, 1, plsh, 1));
    mins.push_back(Ort::Value::CreateTensor<int64_t>(mem, pitch.data(), pitch.size(), pish, 2));
    mins.push_back(Ort::Value::CreateTensor<float>(mem, pitchf.data(), pitchf.size(), pish, 2));
    mins.push_back(Ort::Value::CreateTensor<int64_t>(mem, &ds, 1, dssh, 1));
    mins.push_back(Ort::Value::CreateTensor<float>(mem, rnd.data(), rnd.size(), rsh, 3));
    const char* minN[] = {"phone", "phone_lengths", "pitch", "pitchf", "ds", "rnd"};
    const char* moutN[] = {"audio"};
    auto mouts = mdl.Run(Ort::RunOptions{nullptr}, minN, mins.data(), 6, moutN, 1);
    float* od = mouts[0].GetTensorMutableData<float>();
    auto os = mouts[0].GetTensorTypeAndShapeInfo().GetShape();
    size_t M = 1; for (auto d : os) M *= (size_t)d;

    const double dt = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    std::vector<float> outf(od, od + M);   // 模型输出已是 [-1,1] float；wav::writeMonoF32 内部 *32767
    wav::writeMonoF32(outp, outf, tgt_sr);
    const double dur = (double)M / tgt_sr;
    std::printf("完成: 音频 %.2fs / 计算 %.2fs / RTF=%.3f  L=%d tgt_sr=%d  -> %s\n",
                dur, dt, dur > 0 ? dt / dur : 0, L, tgt_sr, outp.c_str());
    return 0;
}
