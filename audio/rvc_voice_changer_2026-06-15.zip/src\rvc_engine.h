// RVC 实时引擎：onnxruntime(ContentVec+模型) + WORLD f0 + miniaudio 双流(mic->扬声器)，分块流式+交叉淡化。
#pragma once
#include <memory>
#include <string>

namespace rvc {

class Engine {
public:
    Engine();
    ~Engine();
    Engine(const Engine&) = delete;
    Engine& operator=(const Engine&) = delete;

    void        setUseGpu(bool useGpu);       // 下次加载时是否走 DirectML GPU（需 DML 版 onnxruntime）
    bool        gpuActive() const;            // 当前已加载的是否真的在用 GPU

    // 加载 ContentVec onnx + 模型 onnx（自动探测目标采样率）
    bool        loadModels(const std::string& vecOnnx, const std::string& modelOnnx);
    bool        ready() const;
    int         targetSampleRate() const;

    // 设备枚举（名字 UTF-8）
    int         inputDeviceCount();
    const char* inputDeviceName(int i);
    int         outputDeviceCount();
    const char* outputDeviceName(int i);

    // 实时：inDev/outDev=设备索引(-1默认)，blockSec=块/延迟
    bool        start(int inDev, int outDev, float blockSec);
    void        stop();
    bool        running() const;

    void        setPitch(float semitones);   // 音高 transpose（男->女 +12），实时生效
    void        setBlock(float sec);          // 块/延迟，实时生效（下一块起）
    void        setIndexRate(float rate);     // 0..1 音色贴合度（检索 .index），实时
    void        setProtect(float p);          // <0.5 辅音/清音保护（越小越保护），实时
    void        setRms(float rate);           // 0..1 响度跟随（0=完全跟输入响度），实时
    bool        hasIndex() const;             // 当前模型目录是否带 index.bin

    float       benchmark(float seconds);     // 离线跑一块合成音频测 RTF（含预热），用于 CPU/GPU 对比
    float       rtf() const;                  // 上次块的吞吐 RTF
    float       level() const;                // 输入电平
    const char* status();                     // 状态/错误（UTF-8）

    // 声音面板（soundboard）：把声音文件混入指定输出设备（同变声输出=送进虚拟声卡给游戏）
    bool        soundboardInit(int outDev);   // 选输出设备索引，开/换设备
    bool        soundboardPlay(const std::string& path);  // 触发一个声音（可叠加）
    void        soundboardStopAll();          // 停所有正在播的
    void        soundboardVolume(float v);    // 0..1
    void        soundboardShutdown();

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

} // namespace rvc
