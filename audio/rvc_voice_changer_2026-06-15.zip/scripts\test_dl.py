﻿import requests
url="https://hf-mirror.com/Daswer123/RVC_Base/resolve/main/hubert_base.pt"
try:
    r=requests.get(url, stream=True, timeout=30, allow_redirects=True)
    print("status", r.status_code, "final_url", r.url[:90])
    print("content-length", r.headers.get("content-length"))
    chunk=next(r.iter_content(1024*64))
    print("got first chunk bytes:", len(chunk))
except Exception as e:
    print("ERR", repr(e)[:200])
