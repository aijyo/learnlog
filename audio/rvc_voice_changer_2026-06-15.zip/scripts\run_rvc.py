# RVC 离线推理（带 transpose/音高调节）。男->女必须抬音高(+12)。
import os, time
import torch
_orig_load = torch.load
def _patched_load(*a, **k):
    k.setdefault("weights_only", False)
    return _orig_load(*a, **k)
torch.load = _patched_load
from rvc_python.infer import RVCInference
import soundfile as sf

D = r"D:\code\work\research\voice\rvc_demo"
SRC = os.path.join(D, "source_male.wav")
EGIRL = (r"models\egirl\egirl.pth", r"models\egirl\added_IVF2182_Flat_nprobe_1_egirl.index")
TRUMP = (r"models\Donald-Trump\Trump_e160_s7520.pth", r"models\Donald-Trump\added_IVF1377_Flat_nprobe_1_Trump_v2.index")

# (输出名, (pth,index), 音高半音transpose)
JOBS = [
    ("egirl_up12", EGIRL, 12),   # 男->女：抬一个八度
    ("egirl_up8",  EGIRL, 8),    # 备选：抬少一点
    ("Trump_up0",  TRUMP, 0),    # 男->男：不抬，提高 index_rate 更像
]

def dur(p):
    i = sf.info(p); return i.frames / i.samplerate

sdur = dur(SRC)
print(f"source {sdur:.2f}s")
rvc = RVCInference(device="cpu:0")
for name, (pth, idx), pitch in JOBS:
    rvc.load_model(os.path.join(D, pth), index_path=os.path.join(D, idx))
    rvc.f0method = "rmvpe"
    rvc.f0up_key = pitch        # ★ 音高 transpose
    rvc.index_rate = 0.75       # 更贴目标音色
    rvc.protect = 0.33
    rvc.rms_mix_rate = 0.25     # 更用目标的响度特性
    out = os.path.join(D, f"out_{name}.wav")
    t0 = time.time(); rvc.infer_file(SRC, out); el = time.time() - t0
    od = dur(out)
    print(f"{name} (transpose {pitch:+d}): synth {el:.2f}s / {od:.2f}s  RTF={el/od:.3f}  -> out_{name}.wav")
print("DONE")
