﻿import os
os.environ["HF_ENDPOINT"]="https://hf-mirror.com"
from huggingface_hub import HfApi
api=HfApi()
for repo in ["PhoenixStormJr/RVC-V2-default-voice"]:
    try:
        info=api.model_info(repo)
        print("EXISTS", repo)
        for s in info.siblings:
            print("   ", s.rfilename)
    except Exception as e:
        print("FAIL", repo, "->", repr(e)[:160])
