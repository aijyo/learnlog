# 把 RVC 的 .index(faiss IVF) 导出成自包含的 index.bin，供 C++ 自写倒排检索（无第三方依赖）。
# 布局(小端): int32 magic('RVC1'=0x52564331), n, dim, nlist
#   float32 centroids[nlist*dim]
#   int32   cellStart[nlist+1]   (前缀和，cell c 的向量= [cellStart[c],cellStart[c+1]) )
#   float32 vecs[n*dim]          (按 cell 分组排序)
import os, sys
import numpy as np
try:
    import faiss
except ImportError:
    print("NO faiss —— pip install faiss-cpu"); sys.exit(2)

D = r"D:\code\work\research\voice\rvc_demo\models"
JOBS = [
    ("egirl", r"egirl\added_IVF2182_Flat_nprobe_1_egirl.index"),
    ("Donald-Trump", r"Donald-Trump\added_IVF1377_Flat_nprobe_1_Trump_v2.index"),
]
MAGIC = 0x52564331
for name, rel in JOBS:
    p = os.path.join(D, rel)
    if not os.path.exists(p):
        print("缺索引:", p); continue
    index = faiss.read_index(p)
    nlist = index.nlist
    dim = index.d
    quant = index.quantizer
    centroids = quant.reconstruct_n(0, nlist).astype(np.float32)         # [nlist, dim]
    index.make_direct_map()
    n = index.ntotal
    vecs = index.reconstruct_n(0, n).astype(np.float32)                  # [n, dim]
    _, assign = quant.search(vecs, 1)                                    # 每条向量的最近质心
    assign = assign[:, 0].astype(np.int64)
    order = np.argsort(assign, kind="stable")
    vecs_sorted = vecs[order]
    counts = np.bincount(assign, minlength=nlist).astype(np.int32)
    cellStart = np.zeros(nlist + 1, dtype=np.int32)
    cellStart[1:] = np.cumsum(counts)
    out = os.path.join(D, name, "index.bin")
    with open(out, "wb") as f:
        np.array([MAGIC, n, dim, nlist], dtype=np.int32).tofile(f)
        centroids.tofile(f)
        cellStart.tofile(f)
        vecs_sorted.tofile(f)
    print(f"{name}: n={n} dim={dim} nlist={nlist} -> {out} ({os.path.getsize(out)//1024//1024}MB)")
    old = os.path.join(D, name, "feats.bin")
    if os.path.exists(old): os.remove(old)   # 清理上一版
