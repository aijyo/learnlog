#include "rvc_capi.h"
#include "rvc_engine.h"

static rvc::Engine* E(void* h) { return reinterpret_cast<rvc::Engine*>(h); }

extern "C" {
RVC_API void*       rvc_create() { return new rvc::Engine(); }
RVC_API void        rvc_destroy(void* h) { delete E(h); }
RVC_API void        rvc_set_gpu(void* h, int g) { E(h)->setUseGpu(g != 0); }
RVC_API int         rvc_gpu_active(void* h) { return E(h)->gpuActive() ? 1 : 0; }
RVC_API int         rvc_load(void* h, const char* v, const char* m) { return E(h)->loadModels(v ? v : "", m ? m : "") ? 1 : 0; }
RVC_API int         rvc_target_sr(void* h) { return E(h)->targetSampleRate(); }
RVC_API int         rvc_in_count(void* h) { return E(h)->inputDeviceCount(); }
RVC_API const char* rvc_in_name(void* h, int i) { return E(h)->inputDeviceName(i); }
RVC_API int         rvc_out_count(void* h) { return E(h)->outputDeviceCount(); }
RVC_API const char* rvc_out_name(void* h, int i) { return E(h)->outputDeviceName(i); }
RVC_API int         rvc_start(void* h, int in, int out, float b) { return E(h)->start(in, out, b) ? 1 : 0; }
RVC_API void        rvc_stop(void* h) { E(h)->stop(); }
RVC_API int         rvc_running(void* h) { return E(h)->running() ? 1 : 0; }
RVC_API void        rvc_set_pitch(void* h, float s) { E(h)->setPitch(s); }
RVC_API void        rvc_set_block(void* h, float s) { E(h)->setBlock(s); }
RVC_API void        rvc_set_index(void* h, float r) { E(h)->setIndexRate(r); }
RVC_API void        rvc_set_protect(void* h, float p) { E(h)->setProtect(p); }
RVC_API void        rvc_set_rms(void* h, float r) { E(h)->setRms(r); }
RVC_API int         rvc_has_index(void* h) { return E(h)->hasIndex() ? 1 : 0; }
RVC_API float       rvc_bench(void* h, float s) { return E(h)->benchmark(s); }
RVC_API float       rvc_rtf(void* h) { return E(h)->rtf(); }
RVC_API float       rvc_level(void* h) { return E(h)->level(); }
RVC_API const char* rvc_status(void* h) { return E(h)->status(); }
RVC_API int         rvc_sb_init(void* h, int out) { return E(h)->soundboardInit(out) ? 1 : 0; }
RVC_API int         rvc_sb_play(void* h, const char* p) { return E(h)->soundboardPlay(p ? p : "") ? 1 : 0; }
RVC_API void        rvc_sb_stop(void* h) { E(h)->soundboardStopAll(); }
RVC_API void        rvc_sb_volume(void* h, float v) { E(h)->soundboardVolume(v); }
RVC_API void        rvc_sb_shutdown(void* h) { E(h)->soundboardShutdown(); }
}
