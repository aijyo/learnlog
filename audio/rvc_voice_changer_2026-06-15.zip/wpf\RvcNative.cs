using System;
using System.Runtime.InteropServices;

namespace RvcWpf
{
    static class Native
    {
        const string DLL = "rvc_engine.dll";
        const CallingConvention CC = CallingConvention.Cdecl;

        [DllImport(DLL, CallingConvention = CC)] public static extern IntPtr rvc_create();
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_destroy(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_set_gpu(IntPtr h, int useGpu);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_gpu_active(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_load(IntPtr h,
            [MarshalAs(UnmanagedType.LPUTF8Str)] string vec, [MarshalAs(UnmanagedType.LPUTF8Str)] string model);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_target_sr(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_in_count(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern IntPtr rvc_in_name(IntPtr h, int i);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_out_count(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern IntPtr rvc_out_name(IntPtr h, int i);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_start(IntPtr h, int inDev, int outDev, float blockSec);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_stop(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_running(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_set_pitch(IntPtr h, float semitones);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_set_block(IntPtr h, float sec);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_set_index(IntPtr h, float rate);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_set_protect(IntPtr h, float p);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_set_rms(IntPtr h, float rate);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_has_index(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern float rvc_bench(IntPtr h, float seconds);
        [DllImport(DLL, CallingConvention = CC)] public static extern float rvc_rtf(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern float rvc_level(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern IntPtr rvc_status(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_sb_init(IntPtr h, int outDev);
        [DllImport(DLL, CallingConvention = CC)] public static extern int rvc_sb_play(IntPtr h, [MarshalAs(UnmanagedType.LPUTF8Str)] string path);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_sb_stop(IntPtr h);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_sb_volume(IntPtr h, float v);
        [DllImport(DLL, CallingConvention = CC)] public static extern void rvc_sb_shutdown(IntPtr h);

        public static string Utf8(IntPtr p) => p == IntPtr.Zero ? "" : (Marshal.PtrToStringUTF8(p) ?? "");
    }
}
