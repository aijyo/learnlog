# 设计文档 — RVC 实时变声器

## 1. 目标与约束
- **目标**：纯 CPU 实时把麦克风语音转成目标说话人音色（口到口延迟可接受），可送虚拟声卡进游戏。
- **约束**：本地优先、Windows、强 CPU 无 N 卡（i7-13700 / 无 NVIDIA）；交付为 DLL + WPF，架构对齐用户已有的 SimpleAction（C++ 引擎 + C# UI 经 P/Invoke）。
- **非目标**：不做文字转语音（那是 TTS/克隆）；不做语音降噪分离。RVC 只换音色、不换内容。

## 2. 总体架构（分层）
```
┌─────────────────────────────────────────────┐
│  WPF (C#)  RvcVoiceChanger.exe                │  UI / 设备选择 / 参数滑块 / 全局热键
│   MainWindow.xaml(.cs) · RvcNative.cs(P/Invoke)│
└───────────────┬─────────────────────────────┘
                │  C-ABI (extern "C", __cdecl, UTF-8 字符串)
┌───────────────▼─────────────────────────────┐
│  rvc_engine.dll  (C++)                         │
│   rvc_capi.cpp  → rvc::Engine                  │
│   rvc_engine.cpp:                              │
│     · convertWindow()  RVC 推理管线            │
│     · processBlock()   分块流式 + 交叉淡化     │
│     · IvfIndex         自写 IVF 音色检索        │
│     · ma_device duplex 麦克风↔扬声器双流        │
│     · ma_engine        soundboard 混音          │
└───┬───────────────┬──────────────┬───────────┘
    │ onnxruntime    │ WORLD(f0)    │ miniaudio
    │ (CPU/DirectML) │ Dio+StoneMask│ (采集/播放/解码)
```
**线程模型**：miniaudio 回调线程只做轻量推/拉队列（不能在回调里跑 RVC，太慢）；一个 **worker 线程**从输入队列取块、跑 `processBlock`、把结果塞输出队列。参数用 `std::atomic` 跨线程实时改。

## 3. 实时数据流
```
麦克风(48k) ─回调→ inBuf ─worker→ 重采样16k → processBlock → 重采样48k → outBuf ─回调→ 扬声器/虚拟声卡
                                              │
                                       (soundboard 经独立 ma_engine 混入同一输出设备)
```
- 设备统一 **48k 单声道**；RVC 管线内部用 **16k**（ContentVec 要求），输出按模型的 `tgt_sr`（egirl 48k / Trump 32k，加载时探测）。
- **块大小 = 延迟**（默认 1s，可实时调 0.5~2s）。CPU 上 RTF≈0.5，1s 块实时富余。

## 4. RVC 推理管线（`convertWindow`，移植自 rvc-python 的 onnx_inference）
对一个 16k 窗口：
1. **ContentVec onnx**：`[1,1,N]` → `[1,T,768]`（或 `[1,768,T]`，两种布局都兼容探测）。
2. **repeat2 + transpose**：`hub[2t]=hub[2t+1]=raw[t]` → `[L,768]`，`L=2T`。
3. **f0（WORLD）**：`Dio` 粗估 + `StoneMask` 精修 → 插值到 L → `×2^(f0up/12)` 变调 → **mel 量化**（f0_min50/max1100 公式）→ `pitch`(int64) + `pitchf`(float)。
4. **音色检索 + 保护**（见 §5）。
5. **模型 onnx**（SynthesizerTrnMsNSFsidM）6 输入：`phone[1,L,768] / phone_lengths / pitch / pitchf / ds / rnd[1,192,L]` → `audio[-1,1]`。
6. 输出音频（§6 响度跟随）。

WORLD 替代了 RVC 原本的 rmvpe(神经 f0)，省掉一个模型且纯 CPU 够快。

## 5. 自写 IVF 音色检索（替代 faiss）
**为什么自写**：`index_rate`（音色贴合度）原本靠 faiss 检索目标训练特征。直接引入 faiss/hnswlib 是重依赖（且受“不擅自把第三方代码编进来”约束）。
**做法**：`.index` 本身是 faiss 的 **IVF** 结构，离线用 `scripts/export_index.py`（借 venv 里的 faiss）导出成自包含 `index.bin`：
```
int32 magic('RVC1') n dim nlist | float32 centroids[nlist*dim] | int32 cellStart[nlist+1] | float32 vecs[n*dim](按 cell 分组)
```
C++ 侧 `IvfIndex`（`rvc_engine.cpp`）自己实现倒排检索，每帧：
1. 算到所有 `nlist` 质心的 L2，取最近 **NPROBE=8** 个 cell；
2. 扫这些 cell 内向量取 **K=8** 近邻；
3. 权重 `(1/平方距离)^2` 归一，加权平均 → `retrieved`；
4. 按 `index_rate` 混合：`hub = ir*retrieved + (1-ir)*hub`。

多线程 `parallelFor`（≤8 线程）+ `/arch:AVX2` 自动向量化距离循环。实测 **~2-3ms/块**，对 RTF 几乎无影响（远快于全量暴力检索的内存带宽瓶颈）。

**辅音保护 (protect)**：复刻 RVC——清音帧（`pitchf==0`）把检索前特征 `hub0` 混回：`hub = hub*m + hub0*(1-m)`，浊音 m=1、清音 m=protect。仅在 index>0 时有意义。

## 6. 响度跟随 (rms_mix_rate)
输出整体响度向输入靠拢，每块标量增益：`gain = (rms_source/rms_out)^(1-rate)`（clamp 0.1~10）。`rate=1` 不变，`rate=0` 完全跟输入。复刻 RVC 的 `change_rms` 的流式简化版。

## 7. 分块流式 + 交叉淡化（`processBlock`）
- **上下文**：每块前拼上一块尾巴 `prevInTail`(0.12s @16k) 给 ContentVec/f0 足够上下文，避免块边界突变。
- **交叉淡化**：输出与上一块尾巴 `prevOutTail`(0.06s) 做线性 crossfade，消除接缝。
- 取最后 `blockSec*tgtSr` 个样本作为本块输出。

## 8. Soundboard（声音面板）
独立 **miniaudio `ma_engine`**（高层混音 API），`pPlaybackDeviceID` 选输出设备，`ma_engine_play_sound` fire-and-forget 可叠加。与变声的 duplex 设备**同开 CABLE Input**，靠 WASAPI 共享模式在端点混音 → 游戏听到“变声+音效”。中文文件名 OK（miniaudio 把 char 路径当 UTF-8，内部 `ma_wfopen`）。
全局热键在 C# 侧：`RegisterHotKey` + `MOD_NOREPEAT`，`HwndSource.AddHook` 收 `WM_HOTKEY`；热键可**录制**（`PreviewKeyDown` 捕获任意组合键）。

## 9. GPU 路径（DirectML，可选）
- WPF 引 NuGet `Microsoft.ML.OnnxRuntime.DirectML`，提供 DML 版 `onnxruntime.dll`（CPU 的超集）+ `DirectML.dll`。
- 引擎**不改 build 依赖**：用 `GetProcAddress` 从已加载的 `onnxruntime.dll` 动态找 `OrtSessionOptionsAppendExecutionProvider_DML`——CPU 版无此符号即自动回退；DML 版才有。
- DML 要求 `DisableMemPattern` + `SetExecutionMode(ORT_SEQUENTIAL)`。
- **双显卡坑**：device 0(Intel UHD770) 建 D3D12 报 `C0262002 适配器句柄无效` → 遍历 device 0..3 取第一个能成的（落到 RX550）。
- `rvc_bench(seconds)` 离线测 RTF（含预热，GPU 首次编译内核很慢），UI「测速」按钮调用。

## 10. C-ABI 接口（`rvc_capi.h`）
```
rvc_create / rvc_destroy
rvc_set_gpu / rvc_gpu_active            # GPU 开关
rvc_load(vec_onnx, model_onnx)          # 加载（自动读同目录 index.bin、探测 tgt_sr/布局）
rvc_target_sr
rvc_in_count / rvc_in_name / rvc_out_count / rvc_out_name   # 设备枚举(UTF-8)
rvc_start(inDev, outDev, blockSec) / rvc_stop / rvc_running
rvc_set_pitch / rvc_set_block / rvc_set_index / rvc_set_protect / rvc_set_rms   # 实时参数
rvc_has_index
rvc_bench(seconds) / rvc_rtf / rvc_level / rvc_status        # 测速/状态
rvc_sb_init(outDev) / rvc_sb_play(path) / rvc_sb_stop / rvc_sb_volume / rvc_sb_shutdown   # 声音面板
```

## 11. 关键决策与取舍
| 决策 | 原因 |
|------|------|
| onnxruntime 而非 PyTorch | CPU 上 onnx forward RTF≈0.4 vs torch 分块 1.88，快约 4×，才够实时 |
| WORLD 算 f0 而非 rmvpe | 纯 CPU、无需额外神经模型、Dio+StoneMask 够用 |
| 自写 IVF 而非 faiss/hnswlib | 免重依赖/编译外部代码；IVF 检索简单、够快可实时 |
| 块 ~1s + 上下文 + 交叉淡化 | RVC 逐块固定开销大，太小块 RTF>1；1s 平衡延迟与实时 |
| GPU 留作开关而非默认 | 本机弱 GPU(RX550) RTF1.02 慢于强 CPU0.50；实测决定默认 CPU |
| soundboard 独立 ma_engine | 与变声解耦，不跑变声也能用；共享模式自动混音 |

## 12. 已知限制
- 口到口延迟 ≈ 块大小（CPU 上压不到很低，是 RVC 算力本质瓶颈，低延迟需强 GPU）。
- 仅 any-to-one：每个 `.pth` 一个目标音色，换人要换模型。
- 个别发音/生僻音可能略偏（模型与训练数据限制）。
- DirectML 仅在有合适 DX12 适配器时可用；本机弱 GPU 反而更慢。

## 13. 实测数据（i7-13700 / 32G / RX550 / Win11, fp32, egirl）
| 路径 | RTF(1s 块) | 备注 |
|------|-----------|------|
| onnxruntime CPU | **0.45~0.50** | 实时富余，默认 |
| PyTorch 分块(参考) | 1.88 | 故不用 |
| DirectML / RX550 | 1.02 | 慢于 CPU + 首次加载~29s |
| 自写 IVF 检索增量 | +2~3ms/块 | 可忽略 |
