#pragma once
#pragma once

#ifndef __LIB_EXPORT_H__
#define __LIB_EXPORT_H__

#if defined(LIB_DLL)
#define LIB_EXPORT __declspec(dllexport)
#else
//#define LIB_EXPORT __declspec(dllimport)
#define LIB_EXPORT
#endif

// warning C4251
#pragma warning(disable : 4251)
//warning C4506
#pragma warning(disable : 4506)

#endif // __LIB_EXPORT_H__