#pragma once
#ifndef __X_LIB_TYPES_H__
#define __X_LIB_TYPES_H__

#include <string>

namespace x_util {
// common define
#define SINGLETON_DEFINE(TypeName)             \
	static TypeName *GetInstance()         \
	{                                      \
		static TypeName type_instance; \
		return &type_instance;         \
	}                                      \
                                               \
	TypeName(const TypeName &) = delete;   \
	TypeName &operator=(const TypeName &) = delete

#ifdef _UNICODE
using tstring = std::wstring;
#else
using tstring = std::string;
#endif
}

#endif