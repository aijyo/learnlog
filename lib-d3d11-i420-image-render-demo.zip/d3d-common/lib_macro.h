#pragma once
#ifndef __X_LIB_MACRO_H__
#define __X_LIB_MACRO_H__

namespace lib_d3d {
#define X_PARAM(TypeName, Name)                                 \
public:                                                         \
	const TypeName &get_##Name() const { return Name##_; }  \
	void set_##Name(const TypeName &val) { Name##_ = val; } \
                                                                \
protected:                                                      \
	TypeName Name##_;

#define X_POINTER(TypeName, Name)                        \
public:                                                  \
	TypeName get_##Name() const { return Name##_; }  \
	void set_##Name(TypeName val) { Name##_ = val; } \
                                                         \
protected:                                               \
	TypeName Name##_;

#define X_PARAM_GS(TypeName, Name)                           \
public:                                                      \
	const TypeName &get_##Name() const { return Name_; } \
	void set_##Name(const TypeName &val) { Name_ = val; }

// ------------------------------
// HR��
// ------------------------------
// Debugģʽ�µĴ���������׷��
#if defined(DEBUG) | defined(_DEBUG)
#ifndef HR
#define HR(x)                                                            \
	{                                                                \
		HRESULT hr = (x);                                        \
		if (FAILED(hr)) {                                        \
			XLOG(__FILEW__, (DWORD)__LINE__, hr, L#x, true); \
		}                                                        \
	}
#endif
#else
#ifndef HR
#define HR(x) (x)
#endif
#endif
}

#endif // !__X_LIB_MACRO_H__
