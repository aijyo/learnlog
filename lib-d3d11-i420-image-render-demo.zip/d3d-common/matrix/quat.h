#pragma once
#ifndef __X_QUAT_H__
#define __X_QUAT_H__

#include "matrix.h"

namespace lib_d3d {
class LIB_EXPORT Quat {
public:
	static float quat_dot(const quat *left, const quat *right);
	static void quat_from_axisang(quat &dst, const axisang &aa);
};
}
#endif