#include "matrix.h"

namespace lib_d3d {
#define EPSILON 1e-4f
static inline bool close_float(float f1, float f2, float precision)
{
	return fabsf(f1 - f2) <= precision;
}

void Axisang::axisang_zero(axisang &dst)
{
	DirectX::XMVECTOR data = DirectX::XMVectorZero();
	DirectX::XMStoreFloat4(&dst, data);
	return;
}

void Axisang::axisang_copy(axisang &dst, const axisang &aa)
{
	auto &&data = DirectX::XMLoadFloat4(&aa);

	DirectX::XMStoreFloat4(&dst, data);
}

void Axisang::axisang_set(axisang &dst, float x, float y, float z, float w)
{
	dst = axisang(x, y, z, w);
}

void Axisang::axisang_from_quat(axisang &dst, const quat &q)
{
	DirectX::XMFLOAT3 vc;
	DirectX::XMVECTOR dst1;
	float angle = 0;
	auto &&data = DirectX::XMLoadFloat4(&q);
	DirectX::XMQuaternionToAxisAngle(&dst1, &angle, data);

	DirectX::XMStoreFloat3(&vc, dst1);
	dst.x = vc.x;
	dst.y = vc.y;
	dst.z = vc.z;
	dst.w = angle;

	//float len, leni;

	//len = q->x * q->x + q->y * q->y + q->z * q->z;
	//if (!close_float(len, 0.0f, EPSILON)) {
	//	leni = 1.0f / sqrtf(len);
	//	dst->x = q->x * leni;
	//	dst->y = q->y * leni;
	//	dst->z = q->z * leni;
	//	dst->w = acosf(q->w) * 2.0f;
	//}
	//else {
	//	dst->x = 0.0f;
	//	dst->y = 0.0f;
	//	dst->z = 0.0f;
	//	dst->w = 0.0f;
	//}
}
}