#pragma once
#ifndef __X_MATRIX_4_H__
#define __X_MATRIX_4_H__

#include "matrix.h"
namespace lib_d3d {
class LIB_EXPORT Matrix4 {
public:
	static void matrix4_identity(matrix4 &dst);

	static void matrix4_from_matrix3(matrix4 &dst, const matrix3 &m);
	static void matrix4_from_quat(matrix4 &dst, const quat &q);
	static void matrix4_from_axisang(matrix4 &dst, const axisang &aa);

	static void matrix4_mul(matrix4 &dst, const matrix4 &m1, const matrix4 &m2);

	static float matrix4_determinant(const matrix4 &m);

	static void matrix4_translate3v(matrix4 &dst, const matrix4 &m, const vec3 &v);
	static void matrix4_translate4v(matrix4 &dst, const matrix4 &m, const vec4 &v);
	static void matrix4_rotate(matrix4 &dst, const matrix4 &m, const quat &q);
	static void matrix4_rotate_aa(matrix4 &dst, const matrix4 &m, const axisang &aa);
	static void matrix4_scale(matrix4 &dst, const matrix4 &m, const vec3 &v);
	static bool matrix4_inv(matrix4 &dst, const matrix4 &m);
	static void matrix4_transpose(matrix4 &dst, const matrix4 &m);

	static void matrix4_translate3v_i(matrix4 &dst, const vec3 &v, const matrix4 &m);
	static void matrix4_translate4v_i(matrix4 &dst, const vec4 &v, const matrix4 &m);
	static void matrix4_rotate_i(matrix4 &dst, const quat &q, const matrix4 &m);
	static void matrix4_rotate_aa_i(matrix4 &dst, const axisang &aa, const matrix4 &m);
	static void matrix4_scale_i(matrix4 &dst, const vec3 &v, const matrix4 &m);

	static void matrix4_translate3f(matrix4 &dst, const matrix4 &m, float x, float y, float z);

	static void matrix4_rotate_aa4f(matrix4 &dst, const matrix4 &m, float x, float y, float z,
					float angle);

	static void matrix4_scale3f(matrix4 &dst, const matrix4 &m, float x, float y, float z);
};

}
#endif