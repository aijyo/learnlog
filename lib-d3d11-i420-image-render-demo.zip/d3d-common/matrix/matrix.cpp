#pragma once
#include "matrix.h"
namespace lib_d3d {

int Matrix::MatrixToIdentity(matrix3 &m)
{
	DirectX::XMMATRIX id = DirectX::XMMatrixIdentity();
	DirectX::XMStoreFloat4x3(&m, id);

	return 0;
}

int Matrix::MatrixToIdentity(matrix4 &m)
{
	DirectX::XMMATRIX id = DirectX::XMMatrixIdentity();
	DirectX::XMStoreFloat4x4(&m, id);

	return 0;
}
}