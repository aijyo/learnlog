#pragma once
#ifndef __X_MATRIX_3_H__
#define __X_MATRIX_3_H__

#include "matrix.h"
namespace lib_d3d {

}

#endif