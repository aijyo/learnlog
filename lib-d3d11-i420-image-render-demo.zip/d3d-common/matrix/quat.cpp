#include "quat.h"
#include "matrix.h"

namespace lib_d3d {

float Quat::quat_dot(const quat *left, const quat *right)
{
	float result = 0.0f;
	DirectX::XMVECTOR l = DirectX::XMLoadFloat4(left);
	DirectX::XMVECTOR r = DirectX::XMLoadFloat4(right);
	result = DirectX::XMVectorGetX(DirectX::XMVector4Dot(l, r));
	return result;
}

void Quat::quat_from_axisang(quat &dst, const axisang &aa)
{
	float halfa = aa.w * 0.5f;
	float sine = sinf(halfa);

	dst.x = aa.x * sine;
	dst.y = aa.y * sine;
	dst.z = aa.z * sine;
	dst.w = cosf(halfa);
}
}