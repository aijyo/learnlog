#pragma once
#ifndef __X_AXISANG_H__
#define __X_AXISANG_H__

#include <DirectXMath.h>

namespace lib_d3d {

class Axisang {
public:
	static inline void axisang_zero(axisang &dst);

	static inline void axisang_copy(axisang &dst, const axisang &aa);

	static inline void axisang_set(axisang &dst, float x, float y, float z, float w);

	static void axisang_from_quat(axisang &dst, const quat &q);
};
}

#endif