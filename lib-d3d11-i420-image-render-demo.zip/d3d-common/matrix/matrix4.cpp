#include "matrix.h"
#include "matrix4.h"

namespace lib_d3d {

void Matrix4::matrix4_identity(matrix4 &dst)
{
	DirectX::XMMATRIX id = DirectX::XMMatrixIdentity();
	DirectX::XMStoreFloat4x4(&dst, id);
}

void Matrix4::matrix4_from_matrix3(matrix4 &dst, const matrix3 &m)
{
	matrix4 tmp(m._11, m._12, m._13, 1.0f, m._21, m._22, m._23, 1.0f, m._31, m._32, m._33, 1.0f,
		    1.0f, 1.0f, 1.0f, 1.0f);
	dst = tmp;
}

void Matrix4::matrix4_from_quat(matrix4 &dst, const quat &q)
{
	float norm = Quat::quat_dot(&q, &q);

	float s = (norm > 0.0f) ? (2.0f / norm) : 0.0f;

	float xx = q.x * q.x * s;
	float yy = q.y * q.y * s;
	float zz = q.z * q.z * s;
	float xy = q.x * q.y * s;
	float xz = q.x * q.z * s;
	float yz = q.y * q.z * s;
	float wx = q.w * q.x * s;
	float wy = q.w * q.y * s;
	float wz = q.w * q.z * s;

	DirectX::XMMATRIX tmp(1.0f - (yy + zz), xy + wz, xz - wy, 0.0f, xy - wz, 1.0f - (xx + zz),
			      yz + wx, 0.0f, xz + wy, yz - wx, 1.0f - (xx + yy), 0.0f, 0.0f, 0.0f,
			      0.0f, 1.0f);

	DirectX::XMStoreFloat4x4(&dst, tmp);
}

void Matrix4::matrix4_from_axisang(matrix4 &dst, const axisang &aa)
{
	quat q;
	Quat::quat_from_axisang(q, aa);
	Matrix4::matrix4_from_quat(dst, q);
}

void Matrix4::matrix4_mul(matrix4 &dst, const matrix4 &m1, const matrix4 &m2)
{
	auto &&tm1 = DirectX::XMLoadFloat4x4(&m1);
	auto &&tm2 = DirectX::XMLoadFloat4x4(&m2);
	auto &&result = DirectX::XMMatrixMultiply(tm1, tm2);

	DirectX::XMStoreFloat4x4(&dst, result);
	return;
}

float Matrix4::matrix4_determinant(const matrix4 &m)
{
	auto &&tm = DirectX::XMLoadFloat4x4(&m);
	auto result = DirectX::XMVectorGetX(DirectX::XMMatrixDeterminant(tm));
	return result;
}

void Matrix4::matrix4_translate3v(matrix4 &dst, const matrix4 &m, const vec3 &v)
{
	DirectX::XMMATRIX tmp(1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f,
			      0.0f, v.x, v.y, v.z, 1.0f);

	auto &&tm1 = DirectX::XMLoadFloat4x4(&m);
	auto &&result = DirectX::XMMatrixMultiply(tm1, tmp);

	DirectX::XMStoreFloat4x4(&dst, result);
}

void Matrix4::matrix4_translate4v(matrix4 &dst, const matrix4 &m, const vec4 &v)
{
	DirectX::XMMATRIX tmp(1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f,
			      0.0f, v.x, v.y, v.z, v.w);

	auto &&tm1 = DirectX::XMLoadFloat4x4(&m);
	auto &&result = DirectX::XMMatrixMultiply(tm1, tmp);

	DirectX::XMStoreFloat4x4(&dst, result);
}

void Matrix4::matrix4_rotate(matrix4 &dst, const matrix4 &m, const quat &q)
{
	matrix4 temp;
	Matrix4::matrix4_from_quat(temp, q);
	Matrix4::matrix4_mul(dst, m, temp);
}

void Matrix4::matrix4_rotate_aa(matrix4 &dst, const matrix4 &m, const axisang &aa)
{
	matrix4 temp;
	Matrix4::matrix4_from_axisang(temp, aa);
	Matrix4::matrix4_mul(dst, m, temp);
}

void Matrix4::matrix4_scale(matrix4 &dst, const matrix4 &m, const vec3 &v)
{
	matrix4 temp(v.x, 0.0f, 0.0f, 0.0f, 0.0f, v.y, 0.0f, 0.0f, 0.0f, 0.0f, v.z, 0.0f, 0.0f,
		     0.0f, 0.0f, 1.0f);
	Matrix4::matrix4_mul(dst, m, temp);
}

bool Matrix4::matrix4_inv(matrix4 &dst, const matrix4 &m)
{
	auto &&tm1 = DirectX::XMLoadFloat4x4(&m);
	auto &&result = DirectX::XMMatrixInverse(nullptr, tm1);

	DirectX::XMStoreFloat4x4(&dst, result);
	return true;
}

void Matrix4::matrix4_transpose(matrix4 &dst, const matrix4 &m)
{
	auto &&tm1 = DirectX::XMLoadFloat4x4(&m);
	auto &&result = DirectX::XMMatrixTranspose(tm1);

	DirectX::XMStoreFloat4x4(&dst, result);
	return;
}

void Matrix4::matrix4_translate3v_i(matrix4 &dst, const vec3 &v, const matrix4 &m)
{
	auto &&tmp = DirectX::XMLoadFloat4x4(&m);

	auto &&trans = DirectX::XMMatrixTranslation(v.x, v.y, v.z);

	trans = tmp * trans;

	DirectX::XMStoreFloat4x4(&dst, trans);
	return;
}

void Matrix4::matrix4_translate4v_i(matrix4 &dst, const vec4 &v, const matrix4 &m)
{
	auto &&tmp = DirectX::XMLoadFloat4x4(&m);

	auto &&trans = DirectX::XMMatrixTranslationFromVector(DirectX::XMLoadFloat4(&v));

	trans = tmp * trans;

	DirectX::XMStoreFloat4x4(&dst, trans);
	return;
}

void Matrix4::matrix4_rotate_i(matrix4 &dst, const quat &q, const matrix4 &m)
{
	auto &&tmp = DirectX::XMLoadFloat4x4(&m);

	auto &&trans = DirectX::XMMatrixRotationQuaternion(DirectX::XMLoadFloat4(&q));

	trans = tmp * trans;

	DirectX::XMStoreFloat4x4(&dst, trans);
	return;
}

void Matrix4::matrix4_rotate_aa_i(matrix4 &dst, const axisang &aa, const matrix4 &m)
{
	auto &&tmp = DirectX::XMLoadFloat4x4(&m);

	auto &&trans = DirectX::XMMatrixRotationAxis(DirectX::XMLoadFloat4(&aa), 1.0f);

	trans = tmp * trans;

	DirectX::XMStoreFloat4x4(&dst, trans);

	matrix4 temp;
	Matrix4::matrix4_from_axisang(temp, aa);
	Matrix4::matrix4_mul(dst, temp, m);
	return;
}

void Matrix4::matrix4_scale_i(matrix4 &dst, const vec3 &v, const matrix4 &m)
{
	matrix4 temp(v.x, 0.0f, 0.0f, 0.0f, 0.0f, v.y, 0.0f, 0.0f, 0.0f, 0.0f, v.z, 0.0f, 0.0f,
		     0.0f, 0.0f, 1.0f);
	Matrix4::matrix4_mul(dst, temp, m);
}

void Matrix4::matrix4_translate3f(matrix4 &dst, const matrix4 &m, float x, float y, float z)
{
	vec3 v(x, y, z);
	Matrix4::matrix4_translate3v(dst, m, v);
}

void Matrix4::matrix4_rotate_aa4f(matrix4 &dst, const matrix4 &m, float x, float y, float z,
				  float angle)
{
	axisang aa(x, y, z, angle);
	Matrix4::matrix4_rotate_aa(dst, m, aa);
}

void Matrix4::matrix4_scale3f(matrix4 &dst, const matrix4 &m, float x, float y, float z)
{
	vec3 v(x, y, z);
	matrix4_scale(dst, m, v);
}

}