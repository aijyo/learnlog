#pragma once
#ifndef __X_MATRIX_H__
#define __X_MATRIX_H__

#include <DirectXMath.h>
#include "lib-d3d11/d3d-common/lib-export.h"
namespace lib_d3d {
	// d3d
	using vec2 = DirectX::XMFLOAT2;
	using vec3 = DirectX::XMFLOAT3;
	using vec4 = DirectX::XMFLOAT4;
	using plane = DirectX::FXMVECTOR;
	using matrix3 = DirectX::XMFLOAT4X3;
	using matrix4 = DirectX::XMFLOAT4X4;
	using mat4float = DirectX::XMFLOAT4X4;

	//	qx = ax * sin(angle / 2)
	//	qy = ay * sin(angle / 2)
	//	qz = az * sin(angle / 2)
	//	qw = cos(angle / 2)
	using quat = DirectX::XMFLOAT4;
	//	x y z  angle
	//	angle = 2 * acos(qw)
	//	x = qx / sqrt(1 - qw * qw)
	//	y = qy / sqrt(1 - qw * qw)
	//	z = qz / sqrt(1 - qw * qw)
	using axisang = DirectX::XMFLOAT4;

	using matrix3 = DirectX::XMFLOAT4X3;
	using matrix4 = DirectX::XMFLOAT4X4;

	class LIB_EXPORT Matrix {
	public:
		static int MatrixToIdentity(matrix3& m);

		static int MatrixToIdentity(matrix4& m);
	};

}

#include "quat.h"
#include "axisang.h"
#include "matrix3.h"
#include "matrix4.h"
#endif // ! __X_MATRIX_H__
