#pragma once
#ifndef __X_LIB_COMMON_H__
#define __X_LIB_COMMON_H__

#include "./lib_macro.h"
#include "./lib-types.h"
#include "./lib-export.h"

#include "./graphics/graphics-types.h"
#include "./matrix/matrix.h"

#ifdef _WIN32
#include "./windows/com-ptr.h"

#ifndef SAFE_DELETE
#define SAFE_DELETE(p)                 \
	{                              \
		if (p) {               \
			delete (p);    \
			(p) = nullptr; \
		}                      \
	}
#endif
#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p)           \
	{                              \
		if (p) {               \
			delete[](p);   \
			(p) = nullptr; \
		}                      \
	}
#endif
#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)                 \
	{                               \
		if (p) {                \
			(p)->Release(); \
			(p) = nullptr;  \
		}                       \
	}
#endif

#endif // _WIN32

#define XLOG

enum {
	/**
	 * Use if there's a problem that can potentially affect the program,
	 * but isn't enough to require termination of the program.
	 *
	 * Use in creation functions and core subsystem functions.  Places that
	 * should definitely not fail.
	 */
	LOG_ERROR = 100,

	/**
	 * Use if a problem occurs that doesn't affect the program and is
	 * recoverable.
	 *
	 * Use in places where failure isn't entirely unexpected, and can
	 * be handled safely.
	 */
	LOG_WARNING = 200,

	/**
	  * Informative message to be displayed in the log.
	  */
	LOG_INFO = 300,

	/**
	   * Debug message to be used mostly by developers.
	   */
	LOG_DEBUG = 400
};

#endif
