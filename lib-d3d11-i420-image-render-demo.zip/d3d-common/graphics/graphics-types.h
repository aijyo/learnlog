#pragma once
#ifndef __X_GRAPHIC_TYPES_H__
#define __X_GRAPHIC_TYPES_H__

#include <windows.h>
#include <DirectXMath.h>

#include <vector>
#include <memory>

#include "./../matrix/matrix.h"

namespace lib_d3d {
// macro
/* ---------------------------------------------------
 * graphics subsystem
 * --------------------------------------------------- */

#define GS_MAX_TEXTURES 8

#define GS_CLEAR_COLOR (1 << 0)
#define GS_CLEAR_DEPTH (1 << 1)
#define GS_CLEAR_STENCIL (1 << 2)

#define GS_BUILD_MIPMAPS (1 << 0)
#define GS_DYNAMIC (1 << 1)
#define GS_RENDER_TARGET (1 << 2)
#define GS_GL_DUMMYTEX (1 << 3) /**<< texture with no allocated texture data */
#define GS_DUP_BUFFER \
	(1 << 4) /**<< do not pass buffer ownership when
				 *    creating a vertex/index buffer */
#define GS_SHARED_TEX (1 << 5)
#define GS_SHARED_KM_TEX (1 << 6)

/* ---------------- */
/* global functions */

#define GS_SUCCESS 0
#define GS_ERROR_FAIL -1
#define GS_ERROR_MODULE_NOT_FOUND -2
#define GS_ERROR_NOT_SUPPORTED -3

#define GS_INVALID_HANDLE (HANDLE) - 1

class GSImage;
class GSDevice;

// win32
using gs_canvas = HWND;

using gs_size = SIZE;
class gs_rect : public RECT {
public:
	gs_rect(LONG l = 0, LONG t = 0, LONG r = 0, LONG b = 0)
	{
		left = l;
		top = t;
		right = r;
		bottom = b;
	}

	gs_rect &operator=(const gs_rect &rhs)
	{
		left = rhs.left;
		top = rhs.top;
		right = rhs.right;
		bottom = rhs.bottom;

		return *this;
	}

	bool operator==(const gs_rect &rhs)
	{
		//bool bSame = memcmp((void*)this, (void*)&rhs, sizeof(gs_rect));
		bool bSame = left == rhs.left && top == rhs.top && right == rhs.right &&
			     bottom == rhs.bottom;

		return bSame;
	}

	bool empty() const
	{
		bool isZero = 0 == left && 0 == top && 0 == right && 0 == bottom;
		return isZero;
	}
	int width() const { return right - left; }

	int height() const { return bottom - top; }
};

enum gs_draw_mode {
	GS_POINTS,
	GS_LINES,
	GS_LINESTRIP,
	GS_TRIS,
	GS_TRISTRIP,
};

enum gs_color_format {
	GS_UNKNOWN,
	GS_A8,
	GS_R8,
	GS_RGBA,
	GS_BGRX,
	GS_BGRA,
	GS_R10G10B10A2,
	GS_RGBA16,
	GS_R16,
	GS_RGBA16F,
	GS_RGBA32F,
	GS_RG16F,
	GS_RG32F,
	GS_R16F,
	GS_R32F,
	GS_DXT1,
	GS_DXT3,
	GS_DXT5,
	GS_R8G8,
	GS_RGBA_UNORM,
	GS_BGRX_UNORM,
	GS_BGRA_UNORM,
	GS_RG16,
};

enum gs_color_space {
	GS_CS_SRGB,         /* SDR */
	GS_CS_SRGB_16F,     /* High-precision SDR */
	GS_CS_709_EXTENDED, /* Canvas, Mac EDR (HDR) */
	GS_CS_709_SCRGB,    /* 1.0 = 80 nits, Windows/Linux HDR */
};

enum gs_zstencil_format {
	GS_ZS_NONE,
	GS_Z16,
	GS_Z24_S8,
	GS_Z32F,
	GS_Z32F_S8X24,
};

enum gs_index_type {
	GS_UNSIGNED_SHORT,
	//GS_UNSIGNED_LONG,
};

enum gs_cull_mode {
	GS_BACK,
	GS_FRONT,
	GS_NEITHER,
};

enum gs_blend_type {
	GS_BLEND_ZERO,
	GS_BLEND_ONE,
	GS_BLEND_SRCCOLOR,
	GS_BLEND_INVSRCCOLOR,
	GS_BLEND_SRCALPHA,
	GS_BLEND_INVSRCALPHA,
	GS_BLEND_DSTCOLOR,
	GS_BLEND_INVDSTCOLOR,
	GS_BLEND_DSTALPHA,
	GS_BLEND_INVDSTALPHA,
	GS_BLEND_SRCALPHASAT,
};

enum gs_blend_op_type {
	GS_BLEND_OP_ADD,
	GS_BLEND_OP_SUBTRACT,
	GS_BLEND_OP_REVERSE_SUBTRACT,
	GS_BLEND_OP_MIN,
	GS_BLEND_OP_MAX
};

enum gs_depth_test {
	GS_NEVER,
	GS_LESS,
	GS_LEQUAL,
	GS_EQUAL,
	GS_GEQUAL,
	GS_GREATER,
	GS_NOTEQUAL,
	GS_ALWAYS,
};

enum gs_stencil_side {
	GS_STENCIL_FRONT = 1,
	GS_STENCIL_BACK,
	GS_STENCIL_BOTH,
};

enum gs_stencil_op_type {
	GS_KEEP,
	GS_ZERO,
	GS_REPLACE,
	GS_INCR,
	GS_DECR,
	GS_INVERT,
};

enum gs_cube_sides {
	GS_POSITIVE_X,
	GS_NEGATIVE_X,
	GS_POSITIVE_Y,
	GS_NEGATIVE_Y,
	GS_POSITIVE_Z,
	GS_NEGATIVE_Z,
};

enum gs_sample_filter {
	GS_FILTER_POINT,
	GS_FILTER_LINEAR,
	GS_FILTER_ANISOTROPIC,
	GS_FILTER_MIN_MAG_POINT_MIP_LINEAR,
	GS_FILTER_MIN_POINT_MAG_LINEAR_MIP_POINT,
	GS_FILTER_MIN_POINT_MAG_MIP_LINEAR,
	GS_FILTER_MIN_LINEAR_MAG_MIP_POINT,
	GS_FILTER_MIN_LINEAR_MAG_POINT_MIP_LINEAR,
	GS_FILTER_MIN_MAG_LINEAR_MIP_POINT,
};

enum gs_address_mode {
	GS_ADDRESS_CLAMP,
	GS_ADDRESS_WRAP,
	GS_ADDRESS_MIRROR,
	GS_ADDRESS_BORDER,
	GS_ADDRESS_MIRRORONCE,
};

enum gs_texture_type {
	GS_TEXTURE_2D,
	GS_TEXTURE_3D,
	GS_TEXTURE_CUBE,
};

enum E_GSShaderType {
	GS_SHADER_VERTEX,
	GS_SHADER_PIXEL,
};

enum E_GSShaderParamType {
	GS_SHADER_PARAM_UNKNOWN,
	GS_SHADER_PARAM_BOOL,
	GS_SHADER_PARAM_FLOAT,
	GS_SHADER_PARAM_INT,
	GS_SHADER_PARAM_STRING,
	GS_SHADER_PARAM_VEC2,
	GS_SHADER_PARAM_VEC3,
	GS_SHADER_PARAM_VEC4,
	GS_SHADER_PARAM_INT2,
	GS_SHADER_PARAM_INT3,
	GS_SHADER_PARAM_INT4,
	GS_SHADER_PARAM_MATRIX4X4,
	GS_SHADER_PARAM_TEXTURE,
};

//////////////////////////////////////////////////////////////////////////
using gs_window = HWND;
/* exception-safe RAII wrapper for index buffer data (NOTE: not copy-safe) */
class VoidPtr {
public:
	inline VoidPtr(void *data) : data(data) {}
	inline ~VoidPtr() { free(data); }

public:
	void *data;
};

//////////////////////////////////////////////////////////////////////////
class LIB_EXPORT swapchain_data {
public:
	explicit swapchain_data(gs_window hwnd = NULL);
	~swapchain_data();

	swapchain_data(const swapchain_data &rhs);
	swapchain_data(swapchain_data &&rhs);

	swapchain_data &operator=(const swapchain_data &rhs);
	swapchain_data &operator=(swapchain_data &&rhs);

	bool operator==(const swapchain_data &rhs);
	bool IsRenderToWindow() const { return NULL != window_; }

protected:
	void move(swapchain_data &&rhs);
	void copy(const swapchain_data &rhs);

public:
	gs_window window_ = NULL;
	uint32_t cx_ = 0; // target width
	uint32_t cy_ = 0; // target height
	uint32_t num_backbuffers_ = 1;
	gs_color_format format_ = gs_color_format::GS_BGRA;
	gs_zstencil_format zsformat_ = gs_zstencil_format::GS_Z24_S8;
};

using swapchain_data_ptr = std::shared_ptr<swapchain_data>;
//////////////////////////////////////////////////////////////////////////
//
class LIB_EXPORT gs_sampler_info {
public:
	enum gs_sample_filter filter;
	enum gs_address_mode address_u;
	enum gs_address_mode address_v;
	enum gs_address_mode address_w;
	int max_anisotropy;
	uint32_t border_color;
};
//////////////////////////////////////////////////////////////////////////
class LIB_EXPORT gs_monitor_info {
public:
	gs_monitor_info();
	~gs_monitor_info();

	gs_monitor_info(const gs_monitor_info &rhs);
	gs_monitor_info(gs_monitor_info &&rhs);

	gs_monitor_info &operator=(const gs_monitor_info &rhs);
	gs_monitor_info &operator=(gs_monitor_info &&rhs);

protected:
	void move(gs_monitor_info &&rhs);
	void copy(const gs_monitor_info &rhs);

public:
	int rotation_degrees;
	long x;
	long y;
	long cx;
	long cy;
};

class LIB_EXPORT gs_tvertarray {
public:
	gs_tvertarray();
	~gs_tvertarray();

	gs_tvertarray(const gs_tvertarray &rhs);
	gs_tvertarray(gs_tvertarray &&rhs);

	gs_tvertarray &operator=(const gs_tvertarray &rhs);
	gs_tvertarray &operator=(gs_tvertarray &&rhs);
	gs_tvertarray &operator=(std::vector<vec2> &rhs);

	std::vector<vec2> Data() const;
	const std::vector<vec2> &DataRef() const;

protected:
	void move(gs_tvertarray &&rhs);
	void copy(const gs_tvertarray &rhs);

public:
	size_t width; // default 2
	std::vector<vec2> items_;
	//void *array;
};

#define VERTEX_ELEMENT_WIDTH (2)

class LIB_EXPORT vertex_data {
public:
	using data_type = vec3;
	using vert_array_type = std::vector<vec2>;
	//using vert_array_type = gs_tvertarray;
public:
	vertex_data();
	~vertex_data();

	vertex_data(const vertex_data &rhs);
	vertex_data(vertex_data &&rhs);

	vertex_data &operator=(const vertex_data &rhs);
	vertex_data &operator=(vertex_data &&rhs);

protected:
	void move(vertex_data &&rhs);
	void copy(const vertex_data &rhs);

public:
	std::vector<data_type> points_;
	std::vector<data_type> normals_;
	std::vector<data_type> tangents_;
	std::vector<uint32_t> colors_;
	std::vector<vert_array_type> tvarray_;
};

using vertex_data_ptr = std::shared_ptr<vertex_data>;
//using gs_vb_data_ptr = gs_vb_data*;

using index_data = std::vector<uint16_t>;
using index_data_ptr = std::shared_ptr<index_data>;

static inline enum gs_color_format gs_generalize_format(enum gs_color_format format)
{
	switch (format) {
	case GS_RGBA_UNORM:
		return GS_RGBA;
	case GS_BGRX_UNORM:
		return GS_BGRX;
	case GS_BGRA_UNORM:
		return GS_BGRA;
	default:
		return format;
	}
}
//////////////////////////////////////////////////////////////////////////

class LIB_EXPORT gs_device_loss {
public:
	void (*device_loss_release)(void *data);
	void (*device_loss_rebuild)(void *device, void *data);
	void *data;
};
}
#include "./graphics-types.inl"

#endif