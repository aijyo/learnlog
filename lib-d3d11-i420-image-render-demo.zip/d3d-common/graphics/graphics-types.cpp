#include "graphics-types.h"

namespace lib_d3d {
//////////////////////////////////////////////////////////////////////////
//
swapchain_data::swapchain_data(gs_window hwnd /* = NULL*/) : window_(hwnd)
//, num_backbuffers_(0)
//, format_(gs_color_format::GS_BGRA)
//, zsformat_(gs_zstencil_format::GS_Z24_S8)
{
	RECT rc = {0};
	if (::GetWindowRect(window_, &rc)) {
		cx_ = rc.right - rc.left;
		cy_ = rc.bottom - rc.top;
	}
}
swapchain_data::~swapchain_data() {}

swapchain_data::swapchain_data(const swapchain_data &rhs)
{
	copy(rhs);
}

swapchain_data::swapchain_data(swapchain_data &&rhs)
{
	move(std::forward<swapchain_data>(rhs));
}

swapchain_data &swapchain_data::operator=(const swapchain_data &rhs)
{
	copy(rhs);
	return *this;
}

swapchain_data &swapchain_data::operator=(swapchain_data &&rhs)
{
	move(std::forward<swapchain_data>(rhs));
	return *this;
}

bool swapchain_data::operator==(const swapchain_data &rhs)
{
	bool bSame = window_ == rhs.window_ && cx_ == rhs.cx_ && cy_ == rhs.cy_ &&
		     num_backbuffers_ == rhs.num_backbuffers_ && format_ == rhs.format_ &&
		     zsformat_ == rhs.zsformat_;

	return bSame;
}

void swapchain_data::move(swapchain_data &&rhs)
{
	window_ = std::move(rhs.window_);
	cx_ = std::move(rhs.cx_);
	cy_ = std::move(rhs.cy_);
	num_backbuffers_ = std::move(rhs.num_backbuffers_);
	format_ = std::move(rhs.format_);
	zsformat_ = std::move(rhs.zsformat_);
}
void swapchain_data::copy(const swapchain_data &rhs)
{
	window_ = rhs.window_;
	cx_ = rhs.cx_;
	cy_ = rhs.cy_;
	num_backbuffers_ = rhs.num_backbuffers_;
	format_ = rhs.format_;
	zsformat_ = rhs.zsformat_;
}
//////////////////////////////////////////////////////////////////////////
//
gs_monitor_info::gs_monitor_info() : rotation_degrees(0), x(0), y(0), cx(0), cy(0) {}
gs_monitor_info::~gs_monitor_info() {}

gs_monitor_info::gs_monitor_info(const gs_monitor_info &rhs)
{
	copy(rhs);
}
gs_monitor_info::gs_monitor_info(gs_monitor_info &&rhs)
{
	move(std::forward<gs_monitor_info>(rhs));
}

gs_monitor_info &gs_monitor_info::operator=(const gs_monitor_info &rhs)
{
	copy(rhs);
	return *this;
}

gs_monitor_info &gs_monitor_info::operator=(gs_monitor_info &&rhs)
{
	move(std::forward<gs_monitor_info>(rhs));
	return *this;
}

void gs_monitor_info::move(gs_monitor_info &&rhs)
{
	rotation_degrees = std::move(rhs.rotation_degrees);
	x = std::move(rhs.x);
	y = std::move(rhs.y);
	cx = std::move(rhs.cx);
	cy = std::move(rhs.cy);
}

void gs_monitor_info::copy(const gs_monitor_info &rhs)
{
	rotation_degrees = rhs.rotation_degrees;
	x = rhs.x;
	y = rhs.y;
	cx = rhs.cx;
	cy = rhs.cy;
}

//////////////////////////////////////////////////////////////////////////
// gs_tvertarray
gs_tvertarray::gs_tvertarray() {}
gs_tvertarray::~gs_tvertarray() {}

gs_tvertarray::gs_tvertarray(const gs_tvertarray &rhs)
{
	copy(rhs);
}

gs_tvertarray::gs_tvertarray(gs_tvertarray &&rhs)
{
	move(std::forward<gs_tvertarray>(rhs));
}

gs_tvertarray &gs_tvertarray::operator=(const gs_tvertarray &rhs)
{
	copy(rhs);
	return *this;
}

gs_tvertarray &gs_tvertarray::operator=(gs_tvertarray &&rhs)
{
	move(std::forward<gs_tvertarray>(rhs));
	return *this;
}
gs_tvertarray &gs_tvertarray::operator=(std::vector<vec2> &rhs)
{
	items_ = rhs;
	width = 2;
	return *this;
}

std::vector<vec2> gs_tvertarray::Data() const
{
	return items_;
}

const std::vector<vec2> &gs_tvertarray::DataRef() const
{
	return items_;
}

void gs_tvertarray::move(gs_tvertarray &&rhs)
{
	width = std::move(rhs.width);
	items_ = std::move(rhs.items_);
}

void gs_tvertarray::copy(const gs_tvertarray &rhs)
{
	width = rhs.width;
	items_ = rhs.items_;
}

//////////////////////////////////////////////////////////////////////////
//gs_vb_data

vertex_data::vertex_data() {}

vertex_data::~vertex_data()
{
	points_.clear();
	normals_.clear();
	tangents_.clear();
	colors_.clear();
	tvarray_.clear();
}

vertex_data::vertex_data(const vertex_data &rhs)
{
	copy(rhs);
}
vertex_data::vertex_data(vertex_data &&rhs)
{
	move(std::forward<vertex_data>(rhs));
}

vertex_data &vertex_data::operator=(const vertex_data &rhs)
{
	copy(rhs);
	return *this;
}
vertex_data &vertex_data::operator=(vertex_data &&rhs)
{
	move(std::forward<vertex_data>(rhs));
	return *this;
}

void vertex_data::move(vertex_data &&rhs)
{
	points_ = std::move(rhs.points_);
	normals_ = std::move(rhs.normals_);
	tangents_ = std::move(rhs.tangents_);
	colors_ = std::move(rhs.colors_);
	tvarray_ = std::move(rhs.tvarray_);
}

void vertex_data::copy(const vertex_data &rhs)
{
	points_ = rhs.points_;
	normals_ = rhs.normals_;
	tangents_ = rhs.tangents_;
	colors_ = rhs.colors_;
	tvarray_ = rhs.tvarray_;
}
}