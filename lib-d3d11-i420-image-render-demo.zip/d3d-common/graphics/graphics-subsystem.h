#pragma once
#ifndef __X_GRAPHICS_SUBSYSTEM_H__
#define __X_GRAPHICS_SUBSYSTEM_H__

#include <memory>
#include <functional>
#include <string>

#include "common/lib-types.h"
//using namespace x_util;
namespace lib_d3d {
class GSDevice;
class GSSwapchain;
class GSTexture;
class GSZstencil;
class GSStageSurf;
class GSSamplerState;
class GSShader;
class GSVertexBuffer;
class GSIndexBuffer;
class GSTimer;
class GSTimerRange;

class IGraphicsSubSysmtem {
public:
	using AdapterCallabck = std::function<bool(void *, const std::string &, uint32_t)>;

public:
	IGraphicsSubSysmtem();
	virtual ~IGraphicsSubSysmtem();

public:
	const std::string &GetName(void);
	int GetType(void);
	bool EnumAdapters(AdapterCallabck &&callback, void *userdata);

	const std::string &DevicePreprocessorName() const;
	int DeviceCreate(GSDevice **device, uint32_t adapter);
	int DeviceDestroy(GSDevice *device);
	int DeviceEnterContext(GSDevice *device);
	int DeviceLeaveContext(GSDevice *device);
	void *DeviceGetDeviceObj(GSDevice *device);
	GSSwapchain *DeviceSwapchainCreate(GSDevice *device, const struct swapchain_data *data);
	long DeviceResize(GSDevice *device, uint32_t x, uint32_t y);
	gs_color_space DeviceGetColorSpace(GSDevice *device);
	void DeviceUpdateColorSpace(GSDevice *device);
	void DeviceGetSize(const GSDevice *device, uint32_t *x, uint32_t *y);

	uint32_t DeviceGetWidth(const GSDevice *device);
	uint32_t DeviceGetHeight(const GSDevice *device);
	GSTexture *DeviceTextureCreate(GSDevice *device, uint32_t width, uint32_t height,
				       enum gs_color_format color_format, uint32_t levels,
				       const uint8_t **data, uint32_t flags);
	GSTexture *DeviceCubeTextureCreate(GSDevice *device, uint32_t size,
					   enum gs_color_format color_format, uint32_t levels,
					   const uint8_t **data, uint32_t flags);
	GSTexture *DeviceVolTextureCreate(GSDevice *device, uint32_t width, uint32_t height,
					  uint32_t depth, enum gs_color_format color_format,
					  uint32_t levels, const uint8_t *const *data,
					  uint32_t flags);
	GSZstencil *DeviceZstencilCreate(GSDevice *device, uint32_t width, uint32_t height,
					 enum gs_zstencil_format format);
	GSStageSurf *DeviceStageSurfCreate(GSDevice *device, uint32_t width, uint32_t height,
					   enum gs_color_format color_format);
	GSSamplerState *DeviceSamplerStateCreate(GSDevice *device,
						 const struct gs_sampler_info *info);
	GSShader *DeviceVetextShaderCreate(GSDevice *device, const char *shader, const char *file,
					   char **error_string);
	GSShader *DevicePixelShaderCreate(GSDevice *device, const char *shader, const char *file,
					  char **error_string);
	GSVertexBuffer *DeviceVertexBufferCreate(GSDevice *device, struct vertex_data *data,
						 uint32_t flags);
	GSIndexBuffer *DeviceIndexBufferCreate(GSDevice *device, enum gs_index_type type,
					       void *indices, size_t num, uint32_t flags);
	GSTimer *DeviceTimerCreate(GSDevice *device);
	GSTimerRange *DeviceTimerRangeCreate(GSDevice *device);
	gs_texture_type DeviceGetTextureType(const GSTexture *texture);
	void DeviceLoadVertexBuffer(GSDevice *device, GSVertexBuffer *vertbuffer);
	void DeviceLoadIndexBuffer(GSDevice *device, GSIndexBuffer *indexbuffer);
	void DeviceLoadTexture(GSDevice *device, GSTexture *tex, int unit);
	void DeviceLoadSamplerState(GSDevice *device, GSSamplerState *samplerstate, int unit);
	void DeviceLoadVertexShader(GSDevice *device, GSShader *vertshader);
	void DeviceLoadPixelShader(GSDevice *device, GSShader *pixelshader);
	void DeviceLoadDefaultSamplerState(GSDevice *device, bool b_3d, int unit);
	GSShader *DeviceGetVertexShader(const GSDevice *device);
	GSShader *DeviceGetPixelShader(const GSDevice *device);
	GSTexture *DeviceGetRenderTarget(const GSDevice *device);
	GSZstencil *DeviceGetZstencilTarget(const GSDevice *device);
	void DeviceSetRenderTarget(GSDevice *device, GSTexture *tex, GSZstencil *zstencil);
	void DeviceSetRenderTargetWithColorSpace(GSDevice *device, GSTexture *tex,
						 GSZstencil *zstencil, enum gs_color_space space);
	void DeviceSetCubeRenderTarget(GSDevice *device, GSTexture *cubetex, int side,
				       GSZstencil *zstencil);
	void DeviceEnableFramebBufferSrgb(GSDevice *device, bool enable);
	bool DeviceFramebBufferSrgbEnable(GSDevice *device);
	void DeviceCopyTexture(GSDevice *device, GSTexture *dst, GSTexture *src);
	void DeviceCopyTextureRegion(GSDevice *device, GSTexture *dst, uint32_t dst_x,
				     uint32_t dst_y, GSTexture *src, uint32_t src_x, uint32_t src_y,
				     uint32_t src_w, uint32_t src_h);
	void DeviceStateTexture(GSDevice *device, GSStageSurf *dst, GSTexture *src);
	void DeviceBeginFrame(GSDevice *device);
	void DeviceBeginScene(GSDevice *device);
	void DeviceDraw(GSDevice *device, enum gs_draw_mode draw_mode, uint32_t start_vert,
			uint32_t num_verts);
	void DeviceEndScene(GSDevice *device);
	void DeviceLoadSwapchain(GSDevice *device, GSSwapchain *swaphchain);
	void DeviceClear(GSDevice *device, uint32_t clear_flags, const struct vec4 *color,
			 float depth, uint8_t stencil);
	void DevicePresent(GSDevice *device);
	void DeviceFlush(GSDevice *device);
	void DeviceSetCullMode(GSDevice *device, enum gs_cull_mode mode);
	gs_cull_mode DeviceGetCullMode(const GSDevice *device);
	void DeviceEnableBlending(GSDevice *device, bool enable);
	void DeviceEnableDepthTest(GSDevice *device, bool enable);

	void DeviceEnableStencilTest(GSDevice *device, bool enable);
	void DeviceEnableStencilWrite(GSDevice *device, bool enable);
	void DeviceEnableColor(GSDevice *device, bool red, bool green, bool blue, bool alpha);
	void DeviceBlendFunction(GSDevice *device, enum gs_blend_type src, enum gs_blend_type dest);
	void DeviceBlendFuncitonSeparate(GSDevice *device, enum gs_blend_type src_c,
					 enum gs_blend_type dest_c, enum gs_blend_type src_a,
					 enum gs_blend_type dest_a);
	void DeviceBlendOp(GSDevice *device, enum gs_blend_op_type op);

	void DeviceDepthFunction(GSDevice *device, enum gs_depth_test test);
	void DeviceeStencilFunction(GSDevice *device, enum gs_stencil_side side,
				    enum gs_depth_test test);
	void DeviceStencilOp(GSDevice *device, enum gs_stencil_side side,
			     enum gs_stencil_op_type fail, enum gs_stencil_op_type zfail,
			     enum gs_stencil_op_type zpass);
	void DeviceSetViewPort(GSDevice *device, int x, int y, int width, int height);
	void DeviceGetViewPort(const GSDevice *device, struct gs_rect *rect);
	void DeviceSetScissorRect(GSDevice *device, const struct gs_rect *rect);
	void DeviceOrtho(GSDevice *device, float left, float right, float top, float bottom,
			 float znear, float zfar);
	void DeviceFrustum(GSDevice *device, float left, float right, float top, float bottom,
			   float znear, float zfar);
	void DeviceProjectionPush(GSDevice *device);
	void DeviceProjectionPop(GSDevice *device);

	void SwapchainDestroy(GSSwapchain *swapchain);

	void TextureDestroy(GSTexture *tex);
	uint32_t TextureGetWidth(const GSTexture *tex);
	uint32_t TextureGetHeight(const GSTexture *tex);
	gs_color_format TextureGetColorFormat(const GSTexture *tex);
	bool TextureMap(GSTexture *tex, uint8_t **ptr, uint32_t *linesize);
	void TextureUnmap(GSTexture *tex);
	bool TextureIsRect(const GSTexture *tex);
	void *TextureGetObj(const GSTexture *tex);

	void CubeTextureDestroy(GSTexture *cubetex);
	uint32_t CubeTextureGetSize(const GSTexture *cubetex);
	gs_color_format CubeTextureGetColorFormat(const GSTexture *cubetex);

	void VolTextureDestroy(GSTexture *voltex);
	uint32_t VolTextureGetWidth(const GSTexture *voltex);
	uint32_t VolTextureGetHeight(const GSTexture *voltex);
	uint32_t VolTextureGetDepth(const GSTexture *voltex);
	gs_color_format VolTextureGetColorFormat(const GSTexture *voltex);

	void StagesurfDestroy(GSStageSurf *stagesurf);
	uint32_t StagesurfGetWidth(const GSStageSurf *stagesurf);
	uint32_t StagesurfGetHeight(const GSStageSurf *stagesurf);
	gs_color_format StagesurfGetColorFormat(const GSStageSurf *stagesurf);
	bool StagesurfMap(GSStageSurf *stagesurf, uint8_t **data, uint32_t *linesize);
	void StagesurfUnmap(GSStageSurf *stagesurf);

	void ZstencilDestroy(GSZstencil *zstencil);

	void SamplerStateDestroy(GSSamplerState *samplerstate);

	void VertexbufferDestroy(GSVertexBuffer *vertbuffer);
	void VertexbufferFlush(GSVertexBuffer *vertbuffer);
	void VertexbufferFlushDirect(GSVertexBuffer *vertbuffer, const struct vertex_data *data);
	vertex_data *VertexbufferGetData(const GSVertexBuffer *vertbuffer);

	void (*gs_indexbuffer_destroy)(gs_indexbuffer_t *indexbuffer);
	void (*gs_indexbuffer_flush)(gs_indexbuffer_t *indexbuffer);
	void (*gs_indexbuffer_flush_direct)(gs_indexbuffer_t *indexbuffer, const void *data);
	void *(*gs_indexbuffer_get_data)(const gs_indexbuffer_t *indexbuffer);
	size_t (*gs_indexbuffer_get_num_indices)(const gs_indexbuffer_t *indexbuffer);
	enum gs_index_type (*gs_indexbuffer_get_type)(const gs_indexbuffer_t *indexbuffer);

	void (*gs_timer_destroy)(gs_timer_t *timer);
	void (*gs_timer_begin)(gs_timer_t *timer);
	void (*gs_timer_end)(gs_timer_t *timer);
	bool (*gs_timer_get_data)(gs_timer_t *timer, uint64_t *ticks);
	void (*gs_timer_range_destroy)(gs_timer_range_t *range);
	bool (*gs_timer_range_begin)(gs_timer_range_t *range);
	bool (*gs_timer_range_end)(gs_timer_range_t *range);
	bool (*gs_timer_range_get_data)(gs_timer_range_t *range, bool *disjoint,
					uint64_t *frequency);

	void (*gs_shader_destroy)(gs_shader_t *shader);
	int (*gs_shader_get_num_params)(const gs_shader_t *shader);
	gs_sparam_t *(*gs_shader_get_param_by_idx)(gs_shader_t *shader, uint32_t param);
	gs_sparam_t *(*gs_shader_get_param_by_name)(gs_shader_t *shader, const char *name);
	gs_sparam_t *(*gs_shader_get_viewproj_matrix)(const gs_shader_t *shader);
	gs_sparam_t *(*gs_shader_get_world_matrix)(const gs_shader_t *shader);
	void (*gs_shader_get_param_info)(const gs_sparam_t *param,
					 struct gs_shader_param_info *info);
	void (*gs_shader_set_bool)(gs_sparam_t *param, bool val);
	void (*gs_shader_set_float)(gs_sparam_t *param, float val);
	void (*gs_shader_set_int)(gs_sparam_t *param, int val);
	void (*gs_shader_set_matrix3)(gs_sparam_t *param, const struct matrix3 *val);
	void (*gs_shader_set_matrix4)(gs_sparam_t *param, const struct matrix4 *val);
	void (*gs_shader_set_vec2)(gs_sparam_t *param, const struct vec2 *val);
	void (*gs_shader_set_vec3)(gs_sparam_t *param, const struct vec3 *val);
	void (*gs_shader_set_vec4)(gs_sparam_t *param, const struct vec4 *val);
	void (*gs_shader_set_texture)(gs_sparam_t *param, GSTexture *val);
	void (*gs_shader_set_val)(gs_sparam_t *param, const void *val, size_t size);
	void (*gs_shader_set_default)(gs_sparam_t *param);
	void (*gs_shader_set_next_sampler)(gs_sparam_t *param, gs_samplerstate_t *sampler);

	bool (*device_nv12_available)(GSDevice *device);
	bool (*device_p010_available)(GSDevice *device);

	bool (*device_is_monitor_hdr)(GSDevice *device, void *monitor);

	void (*device_debug_marker_begin)(GSDevice *device, const char *markername,
					  const float color[4]);
	void (*device_debug_marker_end)(GSDevice *device);

#ifdef __APPLE__
	/* OSX/Cocoa specific functions */
	GSTexture *(*device_texture_create_from_iosurface)(GSDevice *dev, void *iosurf);
	GSTexture *(*device_texture_open_shared)(GSDevice *dev, uint32_t handle);
	bool (*gs_texture_rebind_iosurface)(GSTexture *texture, void *iosurf);
	bool (*device_shared_texture_available)(void);

#elif _WIN32
	bool (*device_gdi_texture_available)(void);
	bool (*device_shared_texture_available)(void);

	bool (*device_get_duplicator_monitor_info)(GSDevice *device, int monitor_idx,
						   struct gs_monitor_info *monitor_info);
	int (*device_duplicator_get_monitor_index)(GSDevice *device, void *monitor);

	gs_duplicator_t *(*device_duplicator_create)(GSDevice *device, int monitor_idx);
	void (*gs_duplicator_destroy)(gs_duplicator_t *duplicator);

	bool (*gs_duplicator_update_frame)(gs_duplicator_t *duplicator);
	GSTexture *(*gs_duplicator_get_texture)(gs_duplicator_t *duplicator);

	uint32_t (*gs_get_adapter_count)(void);

	GSTexture *(*device_texture_create_gdi)(GSDevice *device, uint32_t width, uint32_t height);

	void *(*gs_texture_get_dc)(GSTexture *gdi_tex);
	void (*gs_texture_release_dc)(GSTexture *gdi_tex);

	GSTexture *(*device_texture_open_shared)(GSDevice *device, uint32_t handle);
	GSTexture *(*device_texture_open_nt_shared)(GSDevice *device, uint32_t handle);
	uint32_t (*device_texture_get_shared_handle)(GSTexture *tex);
	GSTexture *(*device_texture_wrap_obj)(GSDevice *device, void *obj);
	int (*device_texture_acquire_sync)(GSTexture *tex, uint64_t key, uint32_t ms);
	int (*device_texture_release_sync)(GSTexture *tex, uint64_t key);
	bool (*device_texture_create_nv12)(GSDevice *device, GSTexture **tex_y, GSTexture **tex_uv,
					   uint32_t width, uint32_t height, uint32_t flags);
	bool (*device_texture_create_p010)(GSDevice *device, GSTexture **tex_y, GSTexture **tex_uv,
					   uint32_t width, uint32_t height, uint32_t flags);

	GSStageSurf *(*device_stagesurface_create_nv12)(GSDevice *device, uint32_t width,
							uint32_t height);
	GSStageSurf *(*device_stagesurface_create_p010)(GSDevice *device, uint32_t width,
							uint32_t height);
	void (*device_register_loss_callbacks)(GSDevice *device,
					       const struct gs_device_loss *callbacks);
	void (*device_unregister_loss_callbacks)(GSDevice *device, void *data);
#elif __linux__
	struct gs_texture *(*device_texture_create_from_dmabuf)(
		GSDevice *device, unsigned int width, unsigned int height, uint32_t drm_format,
		enum gs_color_format color_format, uint32_t n_planes, const int *fds,
		const uint32_t *strides, const uint32_t *offsets, const uint64_t *modifiers);
	bool (*device_query_dmabuf_capabilities)(GSDevice *device,
						 enum gs_dmabuf_flags *dmabuf_flags,
						 uint32_t **drm_formats, size_t *n_formats);
	bool (*device_query_dmabuf_modifiers_for_format)(GSDevice *device, uint32_t drm_format,
							 uint64_t **modifiers, size_t *n_modifiers);
	struct gs_texture *(*device_texture_create_from_pixmap)(GSDevice *device, uint32_t width,
								uint32_t height,
								enum gs_color_format color_format,
								uint32_t target, void *pixmap);
#endif
};
}
#endif