#include "directx_render.h"
#include <stdexcept>

D3D11VideoRenderer::D3D11VideoRenderer(HWND hwnd)
{
	InitializeDeviceAndSwapChain(hwnd);
	CreateShaders();
}

D3D11VideoRenderer::~D3D11VideoRenderer()
{
}

void D3D11VideoRenderer::InitializeDeviceAndSwapChain(HWND hwnd)
{
	DXGI_SWAP_CHAIN_DESC sd = {};
	sd.BufferCount = 1;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = hwnd;
	sd.SampleDesc.Count = 1;
	sd.Windowed = TRUE;

	UINT flags = 0;
#if defined(_DEBUG)
	flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

	D3D_FEATURE_LEVEL levels[] = { D3D_FEATURE_LEVEL_11_0 };

	HRESULT hr = D3D11CreateDeviceAndSwapChain(
		nullptr,
		D3D_DRIVER_TYPE_HARDWARE,
		nullptr,
		flags,
		levels, 1,
		D3D11_SDK_VERSION,
		&sd,
		&swapChain_,
		&device_,
		nullptr,
		&context_);

	if (FAILED(hr))
		throw std::runtime_error("Failed to create D3D11 device");

	ComPtr<ID3D11Texture2D> backBuffer;
	swapChain_->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&backBuffer);
	device_->CreateRenderTargetView(backBuffer.Get(), nullptr, &rtv_);
}

void D3D11VideoRenderer::CreateShaders()
{
	const char* vsSrc =
		"struct VS_IN { float2 pos : POSITION; float2 tex : TEXCOORD0; };"
		"struct VS_OUT { float4 pos : SV_POSITION; float2 tex : TEXCOORD0; };"
		"VS_OUT main(VS_IN input) {"
		" VS_OUT o;"
		" o.pos = float4(input.pos,0,1);"
		" o.tex = input.tex;"
		" return o;"
		"}";

	ComPtr<ID3DBlob> vsBlob;
	D3DCompile(vsSrc, strlen(vsSrc), nullptr, nullptr, nullptr,
		"main", "vs_4_0", 0, 0, &vsBlob, nullptr);
	device_->CreateVertexShader(vsBlob->GetBufferPointer(), vsBlob->GetBufferSize(), nullptr, &vertexShader_);

	D3D11_INPUT_ELEMENT_DESC layout[] = {
		{"POSITION",0,DXGI_FORMAT_R32G32_FLOAT,0,0,D3D11_INPUT_PER_VERTEX_DATA,0},
		{"TEXCOORD",0,DXGI_FORMAT_R32G32_FLOAT,0,8,D3D11_INPUT_PER_VERTEX_DATA,0},
	};
	device_->CreateInputLayout(layout, 2, vsBlob->GetBufferPointer(), vsBlob->GetBufferSize(), &inputLayout_);

	const char* psSrc =
		"Texture2D texY : register(t0);"
		"Texture2D texU : register(t1);"
		"Texture2D texV : register(t2);"
		"SamplerState samp : register(s0);"
		"float4 main(float2 t:TEXCOORD0) : SV_Target {"
		" float y = texY.Sample(samp,t).r;"
		" float u = texU.Sample(samp,t).r - 0.5;"
		" float v = texV.Sample(samp,t).r - 0.5;"
		" float r = y + 1.402 * v;"
		" float g = y - 0.344136 * u - 0.714136 * v;"
		" float b = y + 1.772 * u;"
		" return float4(r,g,b,1);"
		"}";

	ComPtr<ID3DBlob> psBlob;
	D3DCompile(psSrc, strlen(psSrc), nullptr, nullptr, nullptr,
		"main", "ps_4_0", 0, 0, &psBlob, nullptr);
	device_->CreatePixelShader(psBlob->GetBufferPointer(), psBlob->GetBufferSize(), nullptr, &pixelShader_);

	D3D11_SAMPLER_DESC samp = {};
	samp.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	samp.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	samp.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	samp.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	device_->CreateSamplerState(&samp, &sampler_);
}

void D3D11VideoRenderer::SetFrame(int width, int height,
	const uint8_t* yPlane,
	const uint8_t* uPlane,
	const uint8_t* vPlane)
{
	if (width != frameW_ || height != frameH_)
	{
		frameW_ = width;
		frameH_ = height;
		needRealloc_ = true;
	}

	yData_.assign(yPlane, yPlane + width * height);
	uData_.assign(uPlane, uPlane + (width / 2) * (height / 2));
	vData_.assign(vPlane, vPlane + (width / 2) * (height / 2));
}

void D3D11VideoRenderer::RecreateTextures()
{
	texY_.Reset(); srvY_.Reset();
	texU_.Reset(); srvU_.Reset();
	texV_.Reset(); srvV_.Reset();

	D3D11_TEXTURE2D_DESC desc = {};
	desc.MipLevels = 1;
	desc.ArraySize = 1;
	desc.Format = DXGI_FORMAT_R8_UNORM;
	desc.Usage = D3D11_USAGE_DYNAMIC;
	desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

	// Y
	desc.Width = frameW_;
	desc.Height = frameH_;
	device_->CreateTexture2D(&desc, nullptr, &texY_);
	device_->CreateShaderResourceView(texY_.Get(), nullptr, &srvY_);

	// U
	desc.Width = frameW_ / 2;
	desc.Height = frameH_ / 2;
	device_->CreateTexture2D(&desc, nullptr, &texU_);
	device_->CreateShaderResourceView(texU_.Get(), nullptr, &srvU_);

	// V
	device_->CreateTexture2D(&desc, nullptr, &texV_);
	device_->CreateShaderResourceView(texV_.Get(), nullptr, &srvV_);

	needRealloc_ = false;
}

void D3D11VideoRenderer::Render()
{
	if (frameW_ <= 0 || frameH_ <= 0)
		return;

	if (needRealloc_)
		RecreateTextures();

	// Upload Y
	D3D11_MAPPED_SUBRESOURCE map;
	context_->Map(texY_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &map);
	for (int y = 0; y < frameH_; ++y)
		memcpy((uint8_t*)map.pData + y * map.RowPitch, yData_.data() + y * frameW_, frameW_);
	context_->Unmap(texY_.Get(), 0);
	// U
	context_->Map(texU_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &map);
	for (int y = 0; y < frameH_ / 2; ++y)
		memcpy((uint8_t*)map.pData + y * map.RowPitch, uData_.data() + y * (frameW_ / 2), frameW_ / 2);
	context_->Unmap(texU_.Get(), 0);
	// V
	context_->Map(texV_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &map);
	for (int y = 0; y < frameH_ / 2; ++y)
		memcpy((uint8_t*)map.pData + y * map.RowPitch, vData_.data() + y * (frameW_ / 2), frameW_ / 2);
	context_->Unmap(texV_.Get(), 0);

	// Render target
	context_->OMSetRenderTargets(1, rtv_.GetAddressOf(), nullptr);
	FLOAT clearColor[4] = { 0,0,0,1 };
	context_->ClearRenderTargetView(rtv_.Get(), clearColor);

	// Input Assembler
	struct Vtx { float x, y, u, v; };
	Vtx quad[4] = {
		{-1,-1,0,1},
		{1,-1,1,1},
		{-1,1,0,0},
		{1,1,1,0},
	};
	ComPtr<ID3D11Buffer> vbo;
	D3D11_BUFFER_DESC vbDesc = { sizeof(quad),D3D11_USAGE_IMMUTABLE,D3D11_BIND_VERTEX_BUFFER };
	D3D11_SUBRESOURCE_DATA initData = { quad };
	device_->CreateBuffer(&vbDesc, &initData, &vbo);
	UINT stride = 16, offset = 0;
	context_->IASetInputLayout(inputLayout_.Get());
	context_->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
	context_->IASetVertexBuffers(0, 1, vbo.GetAddressOf(), &stride, &offset);

	// Shaders
	context_->VSSetShader(vertexShader_.Get(), nullptr, 0);
	context_->PSSetShader(pixelShader_.Get(), nullptr, 0);
	context_->PSSetShaderResources(0, 1, srvY_.GetAddressOf());
	context_->PSSetShaderResources(1, 1, srvU_.GetAddressOf());
	context_->PSSetShaderResources(2, 1, srvV_.GetAddressOf());
	context_->PSSetSamplers(0, 1, sampler_.GetAddressOf());

	context_->Draw(4, 0);

	swapChain_->Present(1, 0);
}
