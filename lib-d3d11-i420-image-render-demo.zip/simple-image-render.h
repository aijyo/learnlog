#pragma once
#ifndef __X_SIMPLE_IMAGE_RENDER_H__
#define __X_SIMPLE_IMAGE_RENDER_H__

//#include "d3d-common/lib-common.h"
#include "./graphics/graphics.h"
//#include "lib-d3d11/effect/effect.h"
#include "./effect/effect-helper.h"
#include "./effect/basic/render-states.h"
//#include "lib-d3d11/render/render-helper.h"
//#include "lib-d3d11/render/render-config.h"
#include <functional>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")
namespace lib_d3d {

	enum class ImageFormat {
		kUnkown = 0,
		kRGBA, // RGBA format
		kBGRA, // BGRA format
		kI420, // I420 format
		kNV12, // NV12 format
	};

	using uid_t = std::uint64_t;
	class I420Frame {
	public:
		I420Frame(int width, int height);
		I420Frame(int width, int height, const uint8_t* src_y, int src_stride_y,
			const uint8_t* src_u, int src_stride_u, const uint8_t* src_v, int src_stride_v);
		~I420Frame();

		I420Frame(const I420Frame&) = delete;
		I420Frame& operator=(const I420Frame&) = delete;

		I420Frame(I420Frame&& other) noexcept;
		I420Frame& operator=(I420Frame&& other) noexcept;

		uint8_t* data_y() const { return data_y_; }
		uint8_t* data_u() const { return data_u_; }
		uint8_t* data_v() const { return data_v_; }

		int width() const { return width_; }
		int height() const { return height_; }
		ImageFormat format() const { return ImageFormat::kI420; }

		int stride_y() const { return width_; }
		int stride_u() const { return width_ / 2; }
		int stride_v() const { return width_ / 2; }

		void clear();

	private:
		void allocate();

		int width_ = 0;
		int height_ = 0;
		uint8_t* data_y_ = nullptr;
		uint8_t* data_u_ = nullptr;
		uint8_t* data_v_ = nullptr;
		std::unique_ptr<uint8_t[]> buffer_;
	};

	class I420Renderer {
	public:
		enum class MirrorType {
			kMirrorNormal = 1,
			kMirrorHorizontal = 2,
			kMirrorVertical = 4,
			kMirrorBoth = 6,
		};

		enum class SourceType {
			kSourceCamera,
			kSourceScreen,
			kSourceFile,
			kSourceStream,
		};

		enum class RotationType {
			kRotation_0 = 0,
			kRotation_90,
			kRotation_180,
			kRotation_270,
		};

		enum class FillType {
			kScaleToFill,     // stretch to fill target
			kScaleAspectFit,  // fit to target, may crop
			kScaleAspectFill, // fill target, may stretch
			kCustomSize,      // custom size
			kOriginalSize,    // original size
		};

		enum class StreamRenderType {
			kNull,
			kCurrentThreadRender, // render not thread safe, only use in current ui thread.
			kSingleRender,        // output size is lowerst zorder stream size
			kMultiRender, // output size config size, if render target is not null, else target size.
			kStreamProcessor,
		};

		//struct view_t {
		//	HWND hwnd = nullptr;      // target window handle
		//	std::uint32_t width = 0;  // target width
		//	std::uint32_t height = 0; // target height
		//};

		using view_t = HWND;

		struct rectangle_t {
			int left = 0;
			int top = 0;
			int right = 0;
			int bottom = 0;
			rectangle_t() = default;
			rectangle_t(int l, int t, int r, int b) : left(l), top(t), right(r), bottom(b) {}
		};

		struct config_t {
			std::thread::id thread_id;
			StreamRenderType type = StreamRenderType::kSingleRender;
			view_t view = { 0 };
			std::uint32_t targetWidth = 0;
			std::uint32_t targetHeight = 0;
			rectangle_t viewport;
			ImageFormat outFormat = ImageFormat::kUnkown;
		};

		struct streamInfo_t {
			SourceType sourceType = SourceType::kSourceCamera;
			uid_t uid = 0;
			ImageFormat input_fmt = ImageFormat::kUnkown;
			int x = 0;
			int y = 0;
			int width = 0;
			int height = 0;

			// camera upside down
			MirrorType mirror = MirrorType::kMirrorNormal;
			/**
	   * The layer of the video frame that ranges from 1 to 100:
	  * - 1: (Default) The lowest layer.
	  * - 100: The highest layer.
	  */
			int zOrder = 1;
			FillType fillType = FillType::kScaleToFill;
			RotationType rotation = RotationType::kRotation_0;
			float scale = 1.0;
			double alpha = 0.0;
		};

		class I420VideoFrame {
		public:
			virtual ~I420VideoFrame() = default;
			virtual int Width() const = 0;
			virtual int Height() const = 0;
			virtual ImageFormat Format() const = 0;
			virtual const uint8_t* YPlane() const = 0;
			virtual const uint8_t* UPlane() const = 0;
			virtual const uint8_t* VPlane() const = 0;
			virtual void SetYPlane(const uint8_t* yPlane) = 0;
			virtual void SetUPlane(const uint8_t* uPlane) = 0;
			virtual void SetVPlane(const uint8_t* vPlane) = 0;
		};
		using ImageType = I420Frame;
		using ImagePtr = std::shared_ptr<ImageType>;

		using ImageCallback = std::function<void(ImagePtr frame)>;
		using StreamCallback = std::function<void(const std::vector<streamInfo_t>&)>;

	public:
		I420Renderer();
		~I420Renderer();

		int Create(HWND hwnd);
		int Destroy();

		int SetFrame(int width, int height, const uint8_t* yPlane, const uint8_t* uPlane,
			const uint8_t* vPlane);
		int SetFrame(int width, int height, const uint8_t* src_y, int src_stride_y,
			const uint8_t* src_u, int src_stride_u, const uint8_t* src_v, int src_stride_v);
		int SetFrame(std::shared_ptr<I420Frame> frame);
		int Render();

		int SetSize(int width, int height);
		int SetView(view_t view, int width = 0, int height = 0);
		int SetOutformat(ImageFormat fmt);
		int SetPosition(int left, int top, int right, int bottom);

	protected:
		// initization and uninitialization graphics
		int initialize_(HWND hwnd);
		int uninitialize_();

		// initization and unitialization draw data
		int initialize_draw_();
		int uninitialize_draw_();

		int OnFrameSizeChange_(int width, int height);

		int InitInputTexture_();
		int UninitInputTexture_();

		int InitOutputTexture_();
		int UninitOutputTexture_();

		int InitSwapchain_();
		int UninitSwapchain_();

		int initialize_data_();
		int uninitialize_data_();

		int initialize_shaders_(Graphics* graphic);
		int uninitialize_shaders_();

		int init_shader_input_();
		int UninitShaderInput_();

		int Update_();

		int PrepareDraw_();
		int DrawFrame_();

		int UploadFrame_(ImagePtr frame);

		//attr

		// render attr
		void UpdateMatrix_();
		void UpdateVertexInput_();
		void UpdateIndexInput_();
		void UpdateRenderTarget_();
		//void UpdateViewPos_();
		//void UpdateInputTex_();

		float CalcScale_(int width, int height);

	private:
		int initialize_graphics_(HWND hwnd);
		int uninitialize_graphics_();
		//int CreateShaders_();
		//int RecreateTextures_();

		bool need_realloc_ = false;

		//
		//config_t config;
		LUID adapter_id_ = { 0 };
		StreamRenderType type_ = StreamRenderType::kNull;

		//std::atomic_bool bInit_ = false;
		bool initialized_ = false;     // graphic etc
		bool tex_initialized_ = false; // initialize when render

		std::string name_;
		//std::atomic_bool bNeedMap_ = true;

		view_t target_ = { 0 };
		std::uint32_t width_ = 0; // default target size, if windows size change, stream need scale.
		std::uint32_t height_ = 0;

		ImageFormat in_fmt_ = ImageFormat::kI420;
		ImageFormat out_fmt_ = ImageFormat::kRGBA;

		std::uint64_t last_time_ = 0;
		gs_rect viewport_ = { 0 };
		float scale_ = 1.0;
		RotationType rotation_ = RotationType::kRotation_0;
		FillType fill_type_ = FillType::kCustomSize;
		MirrorType mirror_ = MirrorType::kMirrorNormal;

		ImagePtr current_frame_ = nullptr; // current frame to render
		ImagePtr out_frame_ = nullptr;     // output frame target

		Graphics* graphics_ = nullptr; // one thread with one graphics

		// render to window
		GSSwapchainPtr swapchain_target_ = nullptr;

		GSTexture2DPtr frame_input_tex_[3] = { 0 };
		GSTexture2DPtr out_targets_[1] = { nullptr };
		//GSStageSurfacePtr out_stages_[1] = {nullptr};

		// image render
		bool need_upload_ = false;
		bool need_update_matrix_ = true;

		// maybe N if needed
		VertexShaderConfig vertex_config_;
		std::vector<D3D11_INPUT_ELEMENT_DESC> vertex_input_descs_ = { {0} };
		GSVertexBufferPtr vertex_buffer_ = nullptr;
		GSIndexBufferPtr index_buffer_ = nullptr;
		vertex_data_ptr vertex_data_ = nullptr;
		index_data_ptr index_data_ = nullptr;

		matrix4 world_;
		matrix4 view_;
		matrix4 projection_;
		matrix4 color_coef_;
		vec4 image_info_;

		// effect
		std::shared_ptr<EffectHelper> pHelper_;
		ID3D11InputLayout* m_pVertexPosTexLayout = nullptr;
		D3D11_PRIMITIVE_TOPOLOGY m_CurrTopology = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;

		//GSVertexBufferPtr vertexBuffer_;
		//GSIndexBufferPtr indexBuffer_;

		std::shared_ptr<IEffectPass> pass_;
		RenderStates states_;
	};

} // namespace lib_d3d
#endif