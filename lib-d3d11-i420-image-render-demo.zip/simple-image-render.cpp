#include "simple-image-render.h"
#include <DirectXColors.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <vector>
#include <string>
#include <iostream>

namespace lib_d3d {
	static bool GetAdapterLuid(UINT index, LUID& outLuid)
	{
		ComPtr<IDXGIFactory> factory;
		HRESULT hr = CreateDXGIFactory(__uuidof(IDXGIFactory), reinterpret_cast<void**>(factory.GetAddressOf()));
		if (FAILED(hr)) {
			std::cerr << "CreateDXGIFactory failed with error: " << std::hex << hr << "\n";
			return false;
		}

		ComPtr<IDXGIAdapter> adapter;
		UINT currentIndex = 0;

		while (factory->EnumAdapters(currentIndex, &adapter) != DXGI_ERROR_NOT_FOUND) {
			if (currentIndex == index) {
				DXGI_ADAPTER_DESC desc;
				if (SUCCEEDED(adapter->GetDesc(&desc))) {
					outLuid = desc.AdapterLuid;
					return true;
				}
				else {
					std::cerr << "GetDesc failed\n";
					return false;
				}
			}
			currentIndex++;
		}

		return false;
	}

	const matrix4 gRgbColorCoef_BT601F_Col = { 1.0f, -0.00093f, 1.401687f, 0.0,
						  1.0f, -0.3437f,  -0.71417f, -0.5,
						  1.0f, 1.77216f,  0.00099f,  -0.5,
						  0.0,  0.0,       0.0,       0.0 };

	const matrix4 gRgbColorCoef_BT601F_Row = { 1.0f,     1.0f, 1.0f,      0.0,       -0.00093f, -0.3437f,
						  1.77216f, -0.5, 1.401687f, -0.71417f, 0.00099f,  -0.5,
						  0.0,      0.0f, 0.0f,      0.0 };

	enum class vertexInputType {
		kPosTex,
		//kPosNormalTex,
	};

	using VertexInputDesc = std::vector<D3D11_INPUT_ELEMENT_DESC>;

	static std::unordered_map<vertexInputType, VertexInputDesc> gEffectVetexInput{
		{vertexInputType::kPosTex,
		 {{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0},
		  {"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 1, 0, D3D11_INPUT_PER_VERTEX_DATA, 0}}},
	};

	//static std::unordered_map<std::string, VertexInputDesc> gEffectVetexInput{
	//	{"image_render",
	//	 {{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0},
	//	  {"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 1, 0, D3D11_INPUT_PER_VERTEX_DATA, 0}}},
	//	{"image_converter",
	//	 {{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0},
	//	  {"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 1, 0, D3D11_INPUT_PER_VERTEX_DATA, 0}}},
	//};

	static HRESULT CreateShaderFromFile(const WCHAR* csoFileNameInOut, const WCHAR* hlslFileName,
		LPCSTR entryPoint, LPCSTR shaderModel, ID3DBlob** ppBlobOut)
	{
		HRESULT hr = S_OK;

		if (csoFileNameInOut && D3DReadFileToBlob(csoFileNameInOut, ppBlobOut) == S_OK) {
			return hr;
		}
		else {
			DWORD dwShaderFlags = D3DCOMPILE_ENABLE_STRICTNESS;
#ifdef _DEBUG
			dwShaderFlags |= D3DCOMPILE_DEBUG;

			dwShaderFlags |= D3DCOMPILE_SKIP_OPTIMIZATION;
#endif
			ID3DBlob* errorBlob = nullptr;
			hr = D3DCompileFromFile(hlslFileName, nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE,
				entryPoint, shaderModel, dwShaderFlags, 0, ppBlobOut,
				&errorBlob);
			if (FAILED(hr)) {
				if (errorBlob != nullptr) {
					OutputDebugStringA(reinterpret_cast<const char*>(
						errorBlob->GetBufferPointer()));
				}
				SAFE_RELEASE(errorBlob);
				return hr;
			}
			if (csoFileNameInOut) {
				return D3DWriteBlobToFile(*ppBlobOut, csoFileNameInOut, FALSE);
			}
		}

		return hr;
	}

	I420Frame::I420Frame(int width, int height) : width_(width), height_(height)
	{
		allocate();
	}

	I420Frame::I420Frame(int width, int height, const uint8_t* src_y, int src_stride_y,
		const uint8_t* src_u, int src_stride_u, const uint8_t* src_v, int src_stride_v)
		: width_(width), height_(height)
	{
		allocate();

		int y_stride = stride_y();
		int u_stride = stride_u();
		int v_stride = stride_v();

		// Copy Y
		for (int i = 0; i < height_; ++i) {
			std::memcpy(data_y_ + i * y_stride, src_y + i * src_stride_y, src_stride_y);
		}
		// Copy U
		for (int i = 0; i < height_ / 2; ++i) {
			std::memcpy(data_u_ + i * u_stride, src_u + i * src_stride_u, src_stride_u);
		}
		// Copy V
		for (int i = 0; i < height_ / 2; ++i) {
			std::memcpy(data_v_ + i * v_stride, src_v + i * src_stride_v, src_stride_v);
		}
	}

	I420Frame::~I420Frame() = default;
	//{
	//	clear();
	//}

	I420Frame::I420Frame(I420Frame&& other) noexcept
	{
		width_ = other.width_;
		height_ = other.height_;
		data_y_ = other.data_y_;
		data_u_ = other.data_u_;
		data_v_ = other.data_v_;
		buffer_ = std::move(other.buffer_);

		other.width_ = 0;
		other.height_ = 0;
		other.data_y_ = nullptr;
		other.data_u_ = nullptr;
		other.data_v_ = nullptr;
	}

	I420Frame& I420Frame::operator=(I420Frame&& other) noexcept
	{
		if (this != &other) {
			width_ = other.width_;
			height_ = other.height_;
			data_y_ = other.data_y_;
			data_u_ = other.data_u_;
			data_v_ = other.data_v_;
			buffer_ = std::move(other.buffer_);

			other.width_ = 0;
			other.height_ = 0;
			other.data_y_ = nullptr;
			other.data_u_ = nullptr;
			other.data_v_ = nullptr;
		}
		return *this;
	}

	void I420Frame::allocate()
	{
		size_t y_size = width_ * height_;
		size_t u_size = (width_ / 2) * (height_ / 2);
		size_t v_size = u_size;

		buffer_ = std::make_unique<uint8_t[]>(y_size + u_size + v_size);
		data_y_ = buffer_.get();
		data_u_ = data_y_ + y_size;
		data_v_ = data_u_ + u_size;
	}

	void I420Frame::clear()
	{
		std::memset(buffer_.get(), 0, width_ * height_ * 3 / 2);
	}

	I420Renderer::I420Renderer() : need_realloc_(false), graphics_(nullptr)
	{
		color_coef_ = gRgbColorCoef_BT601F_Row;
	}

	I420Renderer::~I420Renderer()
	{
		//if (graphics_) {
		//	graphics_->Destroy();
		//	graphics_ = nullptr;
		//}
		//uninitialize_();
		Destroy();
	}

	int I420Renderer::Create(HWND hwnd)
	{
		int result = 0;

		//
		initialize_(hwnd);
		return result;
	}

	int I420Renderer::Destroy()
	{
		int result = 0;

		uninitialize_draw_();
		uninitialize_();
		return result;
	}

	int I420Renderer::SetSize(int width, int height)
	{
		if (width <= 0 || height <= 0) {
			return -1; // Invalid size
		}

		if (width_ == width && height_ == height) {
			return 0; // No change needed
		}

		width_ = width;
		height_ = height;

		SetPosition(0, 0, width_, height_);
		need_update_matrix_ = true;
		need_realloc_ = true;
		return 0; // Success
	}

	int I420Renderer::SetView(view_t view, int width /*= 0*/, int height/* = 0*/)
	{
		if (!view) {
			return -1; // Invalid view
		}

		if (width <= 0 || height <= 0) {
			// If width and height are not specified, use the current window size
			RECT rc;
			if (GetWindowRect(view, &rc)) {
				width = rc.right - rc.left;
				height = rc.bottom - rc.top;
			}
		}
		target_ = view;
		width_ = width;
		height_ = height;

		need_realloc_ = true;
		return 0; // Success
	}

	int I420Renderer::SetOutformat(ImageFormat fmt)
	{
		if (fmt != ImageFormat::kRGBA) {
			return -1; // Unsupported format
		}
		out_fmt_ = fmt;
		//needRealloc_ = true;
		return 0; // Success
	}

	int I420Renderer::SetPosition(int left, int top, int right, int bottom)
	{
		if (left < 0 || top < 0 || right <= left || bottom <= top) {
			return -1; // Invalid position
		}

		if (viewport_.left == left && viewport_.top == top &&
			viewport_.right == right && viewport_.bottom == bottom) {
			return 0; // No change needed
		}

		viewport_.left = left;
		viewport_.top = top;
		viewport_.right = right;
		viewport_.bottom = bottom;
		//needRealloc_ = true;

		need_update_matrix_ = true;
		return 0; // Success
	}

	int I420Renderer::initialize_(HWND hwnd)
	{
		int result = 0;

		result = initialize_graphics_(hwnd);
		if (result != 0) {
			return result; // Failed to initialize device and swapchain
		}

		result = initialize_data_();
		if (result != 0) {
			return result; // Failed to initialize render
		}

		result = initialize_shaders_(graphics_);
		if (result != 0) {
			return result; // Failed to create shaders
		}
		//result = InitInputTexture_();
		//if (result < 0) {
		//	return result; // Failed to initialize input texture
		//}
		//result = InitOutputTexture_();
		//if (result < 0) {
		//	return result; // Failed to initialize output texture
		//}
		//result = InitSwapchain_();
		//if (result < 0) {
		//	return result; // Failed to initialize swapchain
		//}

		initialized_ = true;
		return 0; // Success
	}

	int I420Renderer::uninitialize_()
	{
		int result = 0;
		if (graphics_) {
			result = uninitialize_shaders_();
			//if (result < 0) {
			//	return result; // Failed to uninitialize shaders
			//}

			result = uninitialize_data_();
			//if (result < 0) {
			//	return result; // Failed to uninitialize data
			//}

			result = uninitialize_graphics_();
			//if (result < 0) {
			//	return result; // Failed to uninitialize graphics
			//}

		}
		return 0; // Success
	}

	int I420Renderer::initialize_draw_()
	{
		if (!graphics_) {
			return -1; // Graphics not initialized
		}
		if (need_realloc_) {
			int result = InitInputTexture_();
			if (result < 0) {
				return result; // Failed to initialize input texture
			}
			result = InitOutputTexture_();
			if (result < 0) {
				return result; // Failed to initialize output texture
			}

			need_realloc_ = false;
			tex_initialized_ = true;
		}
		return 0; // Success
	}

	int I420Renderer::uninitialize_draw_()
	{
		if (graphics_) {
			int result = UninitInputTexture_();
			if (result < 0) {
				return result; // Failed to uninitialize input texture
			}
			result = UninitOutputTexture_();
			if (result < 0) {
				return result; // Failed to uninitialize output texture
			}
			tex_initialized_ = false;
		}
		return 0; // Success
	}

	int I420Renderer::OnFrameSizeChange_(int width, int height)
	{
		if (width <= 0 || height <= 0) {
			return -1; // Invalid size
		}
		need_update_matrix_ = true;
		need_realloc_ = true;
		return 0; // Success
	}

	int I420Renderer::InitInputTexture_()
	{
		int result = 0;
		if (!graphics_ || !current_frame_) {
			return -1; // Graphics not initialized
		}
		UninitInputTexture_();

		{
			auto vf = in_fmt_;
			auto num = 3; // Y, U, V planes
			uint32_t levels = 1;
			uint32_t flags = GS_DYNAMIC;
			for (std::int32_t index = 0; index < num; index++) {

				gs_color_format color_format = gs_color_format::GS_R8;
				auto width = current_frame_->width();
				auto height = current_frame_->height();

				if (index != 0) {
					//gs_color_format::GS_R8;
					width = (width + 1) >> 1;
					height = (height + 1) >> 1;
				}

				//data[0] = image[i];
				std::string name = "g_txFrame" + std::to_string(index);
				frame_input_tex_[index] =
					graphics_->TextureCreate(width, height, color_format, levels,
						/*(const uint8_t**)data*/ nullptr, flags);
				if (!frame_input_tex_[index]) {
					result = -100; // Failed to create texture
					break;
				}
				//SetShaderResource(name, texs_[i]->ResourceView());
			}
		}

		// Initialize textures for Y, U, and V planes
		// This is a placeholder; actual texture initialization code goes here
		return result; // Success
	}

	int I420Renderer::UninitInputTexture_()
	{
		if (graphics_) {
			// Uninitialize textures for Y, U, and V planes
			// This is a placeholder; actual texture uninitialization code goes here
			for (size_t i = 0; i < 3; i++) {
				graphics_->TextureDestroy(frame_input_tex_[i]);
				frame_input_tex_[i] = nullptr;
			}
		}
		return 0; // Success
	}

	int I420Renderer::InitOutputTexture_()
	{
		if (!graphics_) {
			return -1; // Graphics not initialized
		}

		InitSwapchain_();

		if (swapchain_target_) {
			out_targets_[0] = &swapchain_target_->target_;
			//return 0; // Success
		}
		else {
			//auto out_fmt = out_fmt_;
			//auto out_num = RenderHelper::OutNumFromFormat(out_fmt);
			//auto frame_width = width_;
			//auto frame_height = height_;

			//for (std::uint32_t i = 0; i < out_num; i++) {
			//	x_util::E_VideoPlanar index = (x_util::E_VideoPlanar)i;
			//	auto w = frame_width;
			//	auto h = frame_height;
			//	RenderHelper::AdjustOutputSize(out_fmt_, index, w, h);
			//	auto fmt = RenderHelper::OutPutColorFromVideoFormat(out_fmt_, index);
			//	auto taret = (GSTexture2DPtr)graphics_->TextureCreate(w, h, fmt, 1, NULL,
			//							      GS_RENDER_TARGET);

			//	out_targets_[i] = taret;
			//}
		}

		return 0; // Success
	}

	int I420Renderer::UninitOutputTexture_()
	{
		if (graphics_) {
			// Uninitialize output texture
			// This is a placeholder; actual output texture uninitialization code goes here
			if (nullptr != swapchain_target_ &&
				out_targets_[0] != &swapchain_target_->target_) {
				graphics_->TextureDestroy(out_targets_[0]);
				out_targets_[0] = nullptr;
			}
			if (out_frame_) {
				out_frame_ = nullptr;
			}

			UninitSwapchain_();
		}
		return 0; // Success
	}

	int I420Renderer::InitSwapchain_()
	{
		if (!graphics_) {
			return -1; // Graphics not initialized
		}

		auto width = width_;
		auto height = height_;
		auto format = gs_color_format::GS_RGBA;
		if (swapchain_target_ && swapchain_target_->hwnd_ == target_) {
			swapchain_target_->Resize(width, height, format);
			return 0; // Success
		}
		else {
			UninitSwapchain_();
		}

		GSTexture2DPtr tex_target = nullptr;
		auto out_window = target_;
		swapchain_data data((HWND)out_window);

		data.cx_ = width;
		data.cy_ = height;
		data.format_ = format;
		swapchain_target_ = graphics_->SwapchainCreate(data);

		out_targets_[0] = &swapchain_target_->target_;

		//if (type_ != StreamRenderType::kMultiRender)
		//	return 0; // Success

		return 0; // Success
	}

	int I420Renderer::UninitSwapchain_()
	{
		if (graphics_) {
			// Uninitialize swapchain
			// This is a placeholder; actual swapchain uninitialization code goes here
			if (swapchain_target_) {
				graphics_->SwapchainDestroy(swapchain_target_);
				swapchain_target_ = nullptr;
			}
		}
		return 0; // Success
	}

	using VertexInputDesc = std::vector<D3D11_INPUT_ELEMENT_DESC>;

	enum class RenderVertexType {
		kNull,
		kPositionTexVertex,
		kPositionNormalVertex,
	};

	static HRESULT VertexInputFromType(std::vector<D3D11_INPUT_ELEMENT_DESC>& input)
	{
		HRESULT result = S_OK;
		vertexInputType t = vertexInputType::kPosTex;

		auto it = gEffectVetexInput.find(t);

		if (it != gEffectVetexInput.end())
			input = it->second;

		return result;
	}

	static HRESULT InitVertexData(vertex_data_ptr data)
	{
		HRESULT result = E_INVALIDARG;

		do {
			if (!data)
				break;
			auto& vbd = data;
			float left = 0;
			float right = 0;
			float top = 0;
			float bottom = 0;

			float fTextureCoordLeft = -1.0f;
			float fTextureCoordRight = 1.0f;
			float fTextureCoordTop = -1.0f;
			float fTextureCoordBottom = 1.0f;
			//update vertex buf
			vbd->points_ = {
				{left, top, 0}, {right, top, 0}, {left, bottom, 0}, {right, bottom, 0} };
			vbd->tvarray_.resize(1);
			vbd->tvarray_[0] = { {fTextureCoordLeft, fTextureCoordTop},
						{fTextureCoordRight, fTextureCoordTop},
						{fTextureCoordLeft, fTextureCoordBottom},
						{fTextureCoordRight, fTextureCoordBottom} };
			result = S_OK;
		} while (false);

		return result;
	}

	static HRESULT InitIndexData(index_data_ptr data)
	{
		HRESULT result = E_INVALIDARG;
		if (data) {
			// todo
			std::vector<uint16_t> index = { 0, 1, 2, 2, 1, 3 };
			*data = index;
			result = S_OK;
		}
		return result;
	}

	int I420Renderer::initialize_data_()
	{
		int result = 0;

		do {
			auto hr = VertexInputFromType(vertex_input_descs_);
			if (FAILED(hr)) {
				result = -1; // Failed to get vertex input
				break;
			}
			// Initialize vertex data
			vertex_data_ptr vertexData = std::make_shared<vertex_data>();
			hr = InitVertexData(vertexData);
			if (FAILED(hr)) {
				result = -2; // Failed to initialize vertex data
				break;
			}

			// Initialize index data
			index_data_ptr indexData = std::make_shared<index_data>();
			hr = InitIndexData(indexData);
			if (FAILED(hr)) {
				result = -3; // Failed to initialize index data
				break;
			}
			uint32_t flags = GS_DYNAMIC;
			// Create vertex buffer
			vertex_buffer_ = graphics_->VertexBufferCreate(vertexData, flags);
			if (!vertex_buffer_) {
				result = -4; // Failed to create vertex buffer
				break;
			}
			// Create index buffer
			index_buffer_ = graphics_->IndexBufferCreate(indexData, flags);
			if (!index_buffer_) {
				result = -5; // Failed to create index buffer
				break;
			}

			vertex_data_ = vertexData;
			index_data_ = indexData;

			// Create shaders

		} while (false);
		return result; // Success
	}

	int I420Renderer::uninitialize_data_()
	{
		// Destroy shaders

		if (graphics_) {
			graphics_->VertexbufferDestroy(vertex_buffer_);
			vertex_buffer_ = nullptr;
			vertex_data_ = nullptr;
			graphics_->IndexbufferDestroy(index_buffer_);
			index_buffer_ = nullptr;
			index_data_ = nullptr;
			initialized_ = false;
		}
		return 0; // Success
	}

	static std::string WStringToString(const std::wstring& wstr)
	{
		std::string str;
		int nLen = (int)wstr.length();
		str.resize(nLen, ' ');
		int nResult = WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)wstr.c_str(), nLen,
			(LPSTR)str.c_str(), nLen, NULL, NULL);
		if (nResult == 0) {
			return "";
		}
		return str;
	}

	static std::wstring GetCurrentCsoDir()
	{
		static std::wstring result;

		do {
			if (!result.empty())
				break;

			HMODULE hModule = NULL;
			wchar_t DLLPATH[MAX_PATH + 1] = { 0 };
			GetModuleHandleEx(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, (LPCTSTR)GetCurrentCsoDir,
				&hModule);

			//----
			::GetModuleFileNameW(hModule, DLLPATH, MAX_PATH);
			int nLen = (int)wcslen(DLLPATH);
			for (int i = nLen - 1; i >= 0; --i) {
				if (DLLPATH[i] == '\\') {
					DLLPATH[i + 1] = 0;
					break;
				}
			}
			result = DLLPATH;
			result += L"cso\\";
		} while (false);
		return result;
	}

	int I420Renderer::initialize_shaders_(Graphics* graphic)
	{
		int result = 0;
		do {
			if (!graphic || !graphic->device_) {
				result = -1; // Invalid graphics object
				break;
			}

			auto device = graphic->device_->device_;

			if (!states_.IsInit()) {
				states_.InitAll(device);
			}

			init_shader_input_();

			ComPtr<ID3DBlob> blob;

			// init effect shaders

			const auto& fileName = std::wstring(L"i420_to_rgba_render");
			const auto& vsFile = fileName + L"_vs.cso";
			const auto& psFile = fileName + L"_ps.cso";

			// vs
			EffectHelperPtr pHelper = std::make_shared<EffectHelper>();

			std::string entryName = "main";
			std::string vsName = entryName + "_vs";
			auto hr = CreateShaderFromFile((GetCurrentCsoDir() + vsFile).c_str(), nullptr,
				entryName.c_str(), "vs_4_0", blob.Assign());
			if (FAILED(hr)) {
				result = -2; // Failed to create vertex shader
				break;
			}
			hr = pHelper->AddShader(vsName, device, blob.Get());

			if (FAILED(hr)) {
				result = -3; // Failed to add vertex shader
				break;
			}

			// ps
			std::string psName = entryName + "_ps";
			hr = CreateShaderFromFile((GetCurrentCsoDir() + psFile).c_str(), nullptr,
				entryName.c_str(), "vs_4_0", blob.Assign());
			if (FAILED(hr)) {
				result = -4; // Failed to create pixel shader
				break;
			}

			hr = pHelper->AddShader(psName, device, blob.Get());

			if (FAILED(hr)) {
				result = -5; // Failed to add pixel shader
				break;
			}

			const auto& name = WStringToString(fileName);
			EffectPassDesc passDesc;
			passDesc.nameVS = vsName;
			passDesc.namePS = psName;
			hr = pHelper->AddEffectPass(name.c_str(), device, &passDesc);
			if (FAILED(hr))
				continue;
			pHelper->SetSamplerStateByName("g_Sam", states_.SSLinearWrap.Get());

			// name is pass name
			auto pass = pHelper->GetEffectPass(name.c_str());

			//pass->SetDepthStencilState(RenderStates::DSSLessEqual.Get(), 0);
			//pass->SetDepthStencilState(states_.DSSNoDepthTestWithStencil.Get(), 0);
			pass->SetDepthStencilState(nullptr, 0);
			pass->SetRasterizerState(states_.RSNoCull.Get());
			pHelper->SetSamplerStateByName("g_Sam", states_.SSLinearWrap.Get());
			pHelper->SetSamplerStateByName("g_SamShadow", states_.SSShadow.Get());

			pHelper->SetDebugObjectName(name);

			// name is pass file name
			pHelper_ = pHelper;
			pass_ = pass;
		} while (false);
		return result;
	}

	int I420Renderer::uninitialize_shaders_()
	{
		int result = 0;
		UninitShaderInput_();

		pass_ = nullptr;
		if (pHelper_) {
			pHelper_->Clear();
			pHelper_ = nullptr;
		}
		return result;
	}

	int I420Renderer::init_shader_input_()
	{
		int result = S_OK;

		do {
			if (!graphics_ || !graphics_->device_) {
				result = E_INVALIDARG;
				break;
			}

			auto device = graphics_->device_->device_;
			if (!states_.IsInit()) {
				states_.InitAll(device);
			}

			pHelper_ = std::make_unique<EffectHelper>();

			ComPtr<ID3DBlob> blob;

			// ʵ�����벼��
			VertexInputDesc vcInputDesc{ {"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0,
							 D3D11_INPUT_PER_VERTEX_DATA, 0},
							{"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 1, 0,
							 D3D11_INPUT_PER_VERTEX_DATA, 0} };

			// �������㲼��
			const UINT layoutCount = (UINT)vcInputDesc.size();

			// vs
			result = CreateShaderFromFile(
				(GetCurrentCsoDir() + L"i420_to_rgba_render_vs.cso").c_str(), nullptr, "main",
				"vs_4_0", blob.Assign());
			if (FAILED(result))
				break;

			result = device->CreateInputLayout(vcInputDesc.data(), layoutCount,
				blob->GetBufferPointer(), blob->GetBufferSize(),
				&m_pVertexPosTexLayout);
			// Create vertex input layout
			vertex_config_.SetInputDesc(vertex_input_descs_);
		} while (false);

		return result;
	}

	int I420Renderer::UninitShaderInput_()
	{
		int result = 0;
		if (m_pVertexPosTexLayout) {
			m_pVertexPosTexLayout->Release();
			m_pVertexPosTexLayout = nullptr;
		}
		return result;
	}

	int I420Renderer::SetFrame(int width, int height, const uint8_t* yPlane, const uint8_t* uPlane,
		const uint8_t* vPlane)
	{

		return SetFrame(width, height, yPlane, width, uPlane, width / 2, vPlane, width / 2);
	}

	int I420Renderer::SetFrame(int width, int height, const uint8_t* src_y, int src_stride_y,
		const uint8_t* src_u, int src_stride_u, const uint8_t* src_v, int src_stride_v)
	{
		int result = 0;
		if (width <= 0 || height <= 0 || !src_y || !src_u || !src_v) {
			return -1; // Invalid parameters
		}
		auto cur_width = current_frame_ ? current_frame_->width() : 0;
		auto cur_height = current_frame_ ? current_frame_->height() : 0;
		if (cur_width != width || cur_height != height) {
			OnFrameSizeChange_(width, height);
			current_frame_ = std::make_shared<I420Frame>(width, height, src_y, width, src_u,
				width / 2, src_v, width / 2);
		}
		else {
			auto data_y = current_frame_->data_y();
			auto data_u = current_frame_->data_u();
			auto data_v = current_frame_->data_v();

			int y_stride = src_stride_y;
			int u_stride = src_stride_u;
			int v_stride = src_stride_v;
			// Copy Y
			for (int i = 0; i < height; ++i) {
				std::memcpy(data_y + i * y_stride, src_y + i * y_stride, y_stride);
			}
			// Copy U
			for (int i = 0; i < height / 2; ++i) {
				std::memcpy(data_u + i * u_stride, src_u + i * u_stride, u_stride);
			}
			// Copy V
			for (int i = 0; i < height / 2; ++i) {
				std::memcpy(data_v + i * v_stride, src_v + i * v_stride, v_stride);
			}
		}
		need_upload_ = true;
		return result;
	}

	int I420Renderer::SetFrame(std::shared_ptr<I420Frame> frame)
	{
		if (!frame || frame->width() <= 0 || frame->height() <= 0) {
			return -1; // Invalid frame
		}
		auto cur_width = current_frame_ ? current_frame_->width() : 0;
		auto cur_height = current_frame_ ? current_frame_->height() : 0;
		if (cur_width != frame->width() || cur_height != frame->height()) {
			OnFrameSizeChange_(frame->width(), frame->height());
		}

		current_frame_ = frame;
		need_upload_ = true;
		return 0; // Success
	}

	int I420Renderer::Update_()
	{
		if (!graphics_) {
			return -1; // Graphics not initialized
		}
		int result = DrawFrame_();
		return 0; // Success
	}

	int I420Renderer::PrepareDraw_()
	{
		if (!graphics_ || !current_frame_) {
			return -1; // Graphics not initialized or no frame set
		}
		if (!tex_initialized_ || need_realloc_) {
			initialize_draw_();
		}
		if (out_frame_) {
			out_frame_->clear();
		}
		return 0; // Success
	}

	int I420Renderer::DrawFrame_()
	{
		if (!graphics_ || !current_frame_) {
			return -1; // Graphics not initialized or no frame set
		}
		// Draw logic here, using graphics_ to render the YUV data
		// This is a placeholder; actual drawing code goes here

		int bClear = PrepareDraw_();
		//if (bClear != 0) {
		//	ClearCurrentRenderTarget_();
		//}

		auto out_tex = out_targets_;
		bool bRenderToWindow = nullptr != target_;

		bool isNull = swapchain_target_ ? swapchain_target_->swapchain_ == nullptr : false;
		if (bRenderToWindow && !isNull) {
			// Set the render target to the swapchain
			graphics_->LoadSwapchain(swapchain_target_);
		}
		else {
			//// Set the render target to the output texture
			//if (out_tex[0]) {
			//	graphics_->SetRenderTarget(out_tex[0]);
			//}
			return -2; // No render target set
		}

		if (need_upload_) {
			auto result =
				UploadFrame_(current_frame_); // Upload the frame data to the input textures

			if (result != 0) {
				return result; // Failed to upload frame
			}
		}

		// apply pass(effect)
		auto effect_num = 1;
		for (int index = 0; index < effect_num; ++index) {
			UpdateRenderTarget_();

			//e->SetVertexBuffer(vertex_buf_);
			//e->SetIndexBuffer(index_buf_);

			// begine render pass
			bool need_update_matrix = need_update_matrix_;
			if (need_update_matrix_) {
				UpdateMatrix_();
				UpdateVertexInput_();
				UpdateIndexInput_();
				need_update_matrix_ = false;
			}

			// apply
			matrix4& W = world_;
			matrix4& V = view_;
			matrix4& P = projection_;
			matrix4& C = color_coef_;

			pHelper_->GetConstantBufferVariable("g_World")->SetFloatMatrix(4, 4, (FLOAT*)&W.m);
			pHelper_->GetConstantBufferVariable("g_ColorCoef")
				->SetFloatMatrix(4, 4, (FLOAT*)&C.m);
			pHelper_->GetConstantBufferVariable("g_View")->SetFloatMatrix(4, 4, (FLOAT*)&V.m);
			pHelper_->GetConstantBufferVariable("g_Proj")->SetFloatMatrix(4, 4, (FLOAT*)&P.m);
			pHelper_->GetConstantBufferVariable("g_ImageInfo")
				->SetFloatVector(4, (FLOAT*)&image_info_);

			for (size_t i = 0; i < 3; i++) {
				std::string name = "g_txFrame" + std::to_string(i);
				// todo
				if (frame_input_tex_[i]) {
					pHelper_->SetShaderResourceByName(
						name.c_str(), frame_input_tex_[i]->ResourceView());
				}
			}

			uint32_t start_vert = 0;
			uint32_t num_verts = 0;
			auto& device = graphics_->device_;
			auto& pd3dImmediateContext = device->context_;
			//UploadParams(pd3dImmediateContext);
			// upload params
			//uint32_t flags = GS_CLEAR_COLOR | GS_CLEAR_DEPTH | GS_CLEAR_STENCIL;
			//vec4 color;
			//DirectX::XMStoreFloat4(&color, DirectX::Colors::MidnightBlue.v);
			//graphics_->Clear(flags, color, 1.0, 0);
			pd3dImmediateContext->IASetInputLayout(m_pVertexPosTexLayout);
			pd3dImmediateContext->IASetPrimitiveTopology(m_CurrTopology);

			// Update variables that change once per frame
			//
			device->LoadVertexBufferData(vertex_buffer_, vertex_config_);
			device->LoadIndexBufferData(index_buffer_);

			// apply
			pass_->Apply(pd3dImmediateContext);
			if (index_buffer_) {
				if (num_verts == 0)
					num_verts = (uint32_t)device->curIndexBuffer_->PointNum();
				pd3dImmediateContext->DrawIndexed(num_verts, start_vert, 0);
			}
			else {
				if (num_verts == 0)
					num_verts = (uint32_t)device->curVertexBuffer_->PointsNum();
				pd3dImmediateContext->Draw(num_verts, start_vert);
			}

			// after render pass
		}

		if (bRenderToWindow && !isNull) {
			graphics_->Present();
			graphics_->LoadSwapchain(nullptr);
		}

		return 0; // Success
	}

	int I420Renderer::UploadFrame_(ImagePtr frame)
	{
		if (!graphics_) {
			return -1; // Graphics not initialized
		}
		if (!frame) {
			return -2; // Invalid frame
		}
		// Upload the frame data to the input textures
		if (frame->format() != ImageFormat::kI420) {
			return -3; // Unsupported frame format
		}

		frame = frame == nullptr ? current_frame_ : frame;

		auto i420_frame = std::dynamic_pointer_cast<I420Frame>(frame);
		if (!i420_frame) {
			return -4; // Invalid I420 frame
		}

		auto num = 3;
		for (size_t index = 0; index < num; index++) {
			auto& tex = frame_input_tex_[index];
			if (!tex) {
				return -5; // Texture not initialized
			}
			const uint8_t* data = nullptr;
			int stride = 0;
			switch (index) {
			case 0: // Y plane
				data = i420_frame->data_y();
				stride = i420_frame->stride_y();
				break;
			case 1: // U plane
				data = i420_frame->data_u();
				stride = i420_frame->stride_u();
				break;
			case 2: // V plane
				data = i420_frame->data_v();
				stride = i420_frame->stride_v();
				break;
			default:
				return -6; // Invalid index
			}
			if (!data || stride <= 0) {
				return -7; // Invalid data or stride
			}
			auto buf = (const uint8_t* const*)&data;
			tex->Flush(/*(const uint8_t* const*)data*/buf, stride);
			need_upload_ = false;
		}
		return 0; // Success
	}

	void I420Renderer::UpdateMatrix_()
	{
		Matrix::MatrixToIdentity(world_);
		Matrix::MatrixToIdentity(view_);
		Matrix::MatrixToIdentity(projection_);

		// rotate world
		// XMMatrixRotationZ rotate clockwise, but frame rotation is anticlockwise.
		float nRadionToRender = (DirectX::XM_PI * -(int)rotation_) / 180.0f;
		DirectX::XMStoreFloat4x4(
			&world_, DirectX::XMMatrixTranspose(DirectX::XMMatrixRotationZ(nRadionToRender)));

		// NDC size is equal to view ,if view is null, equal target size
		auto width = width_;
		auto height = height_;

		DirectX::XMStoreFloat4x4(&projection_,
			DirectX::XMMatrixTranspose(DirectX::XMMatrixOrthographicLH(
				(float)width, (float)height, 0.1f, 1000.0f)));

		DirectX::XMVECTOR sVecEye = DirectX::XMVectorSet(0.0f, 0.0f, -10.0f, 0.0f);
		DirectX::XMVECTOR sVecAt = DirectX::XMVectorSet(0.0f, 0.0f, -9.0f, 0.0f);
		DirectX::XMVECTOR sVecUp = DirectX::XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
		DirectX::XMStoreFloat4x4(&view_, DirectX::XMMatrixTranspose(DirectX::XMMatrixLookAtLH(
			sVecEye, sVecAt, sVecUp)));
	}

	void I420Renderer::UpdateVertexInput_()
	{
		auto frame_width = current_frame_ ? current_frame_->width() : 0;
		auto frame_height = current_frame_ ? current_frame_->height() : 0;
		auto view_width = width_;
		auto view_height = height_;

		float frameWidth = float(frame_width);
		float frameHeight = float(frame_height);
		float textureCx = float(frameWidth);
		float textureCy = float(frameHeight);
		float fViewWidth = float(view_width);
		float fViewHeight = float(view_height);

		float fScaleWidth = fViewWidth / frameWidth;
		float fScaleHeight = fViewHeight / frameHeight;
		float fScaleFactor = 1.0f;

		float left = -textureCx / 2;
		float right = textureCx / 2;
		float top = textureCy / 2;
		float bottom = -textureCy / 2;

		float fTextureCoordLeft = 0.0f;
		float fTextureCoordRight = 1.0f;
		float fTextureCoordTop = 0.0f;
		float fTextureCoordBottom = 1.0f;
		auto fillType = fill_type_;
		switch (fillType) {
		case FillType::kScaleAspectFit: {
			fScaleFactor = max(fScaleWidth, fScaleHeight);
			float fRenderWidth = frameWidth * fScaleFactor;
			if (fRenderWidth > fViewWidth) {
				fTextureCoordLeft = (fRenderWidth - fViewWidth) / 2 / fRenderWidth;
				fTextureCoordRight = 1.0f - fTextureCoordLeft;
				fRenderWidth = fViewWidth;
			}
			right = fRenderWidth / 2;
			left = -right;

			float fRenderHeight = frameHeight * fScaleFactor;
			if (fRenderHeight > fViewHeight) {
				fTextureCoordTop = (fRenderHeight - fViewHeight) / 2 / fRenderHeight;
				fTextureCoordBottom = 1.0f - fTextureCoordTop;
				fRenderHeight = fViewHeight;
			}
			top = fRenderHeight / 2;
			bottom = -top;
			break;
		}
		case FillType::kScaleAspectFill: {
			right = fViewWidth / 2;
			top = fViewHeight / 2;
			left = -right;
			bottom = -top;
			break;
		}
		case FillType::kScaleToFill: {
			fScaleFactor = min(fScaleWidth, fScaleHeight);

			right = (frameWidth / 2) * fScaleFactor;
			left = -right;
			top = (frameHeight / 2) * fScaleFactor;
			bottom = -top;

			float fTextureCoordLeft = 0.0f;
			float fTextureCoordRight = 1.0f;
			break;
		}
		case FillType::kOriginalSize: {
			right = frameWidth / 2;
			top = frameHeight / 2;
			if (frameWidth > fViewWidth) {
				fTextureCoordLeft = (frameWidth - fViewWidth) / 2 / frameWidth;
				fTextureCoordRight = 1.0f - fTextureCoordLeft;
				right = fViewWidth / 2;
			}
			if (frameHeight > fViewHeight) {
				fTextureCoordTop = (frameHeight - fViewHeight) / 2 / frameHeight;
				fTextureCoordBottom = 1.0f - fTextureCoordTop;
				top = fViewHeight / 2;
			}
			left = -right;
			bottom = -top;
			break;
		}
		case FillType::kCustomSize: {
			// scale
			float wScale = frameWidth / fViewWidth;
			float fRenderWidth = fViewWidth * 1.0f;
			//float fRenderWidth = frameWidth * scale_;
			if (fRenderWidth > fViewWidth) {
				fTextureCoordLeft = (fRenderWidth - fViewWidth) / 2 / fRenderWidth;
				fTextureCoordRight = 1.0f - fTextureCoordLeft;
				fRenderWidth = fViewWidth * 1.0f;
			}
			float hScale = frameHeight / fViewWidth;
			float fRenderHeight = fViewWidth * 1.0f;
			//float fRenderHeight = frameHeight * scale_;
			if (fRenderHeight > fViewWidth) {
				fTextureCoordTop = (fRenderHeight - fViewWidth) / 2 / fRenderHeight;
				fTextureCoordBottom = 1.0f - fTextureCoordTop;
				fRenderHeight = fViewWidth * 1.0f;
			}
			right = fRenderWidth / 2;
			top = fRenderHeight / 2;
			left = -right;
			bottom = -top;

			break;
		}

		default:
			break;
		}
		image_info_.x = (right - left) * 1.0f;
		image_info_.y = (bottom - top) * 1.0f;
		image_info_.z = 1.0f / (right - left);
		image_info_.w = 1.0f / (bottom - top);
		{
			//rotate
		}

		{
			auto mirror = (int)mirror_;
			// mirror
			if (mirror & (int)MirrorType::kMirrorHorizontal) {
				std::swap(left, right);
			}

			if (mirror & (int)MirrorType::kMirrorVertical) {
				std::swap(top, bottom);
			}
		}
		auto& vbd = vertex_buffer_->vertex_data_;
		//update vertex buf
		vbd->points_ = { {left, top, 0}, {right, top, 0}, {left, bottom, 0}, {right, bottom, 0} };
		vbd->tvarray_.resize(1);
		vbd->tvarray_[0] = { {fTextureCoordLeft, fTextureCoordTop},
					{fTextureCoordRight, fTextureCoordTop},
					{fTextureCoordLeft, fTextureCoordBottom},
					{fTextureCoordRight, fTextureCoordBottom} };

		if (vertex_buffer_) {
			vertex_buffer_->Flush(nullptr);
		}
	}

	void I420Renderer::UpdateIndexInput_()
	{
		if (/*bIndexInputChange_ && */ index_buffer_) {
			index_buffer_->Flush(nullptr);
		}
	}
	void I420Renderer::UpdateRenderTarget_()
	{
		graphics_->device_->curFramebufferInvalidate_ = true;
		auto pos = viewport_;

		auto target = out_targets_[0];
		if (target) {
			graphics_->SetRenderTarget(target, NULL);
		}

		if (pos.empty()) {
			pos = gs_rect(0, 0, width_, height_);
		}
		graphics_->SetViewPort(pos.left, pos.top, pos.width(), pos.height());
		graphics_->device_->FlushOutputViews();
	}

	//void I420Renderer::UpdateViewPos_()
	//{
	//	// Update the view position based on the current viewport
	//	// This is a placeholder; actual view position update code goes here
	//	// For example, you might set the view matrix or viewport dimensions
	//	// ...
	//	//effect->SetWorldMatrix(world_);
	//	//effect->SetViewMatrix(view_);
	//	//effect->SetProjMatrix(projection_);
	//	//auto color_coef = RenderHelper::ColorMatrixFromEffect(effect->get_type());
	//	//effect->SetColorCoef(color_coef);
	//
	//	//effect->SetImageInfo(image_info_);
	//}
	//
	//void I420Renderer::UpdateInputTex_()
	//{
	//	////effect->SetFrame(cur_frame_);
	//	//effect->SetInputTexture(input_tex_);
	//}

	float I420Renderer::CalcScale_(int width, int height)
	{
		float result = 1.0;

		return result;
	}

	int I420Renderer::Render()
	{
		//if (need_realloc_) {
		//	RecreateTextures_();
		//	need_realloc_ = false;
		//}
		//if (!graphics_) {
		//	return -1; // Graphics not initialized
		//}
		// Render logic here, using graphics_ to draw the YUV data
		// ...

		DrawFrame_();
		return 0; // Success
	}

	int I420Renderer::initialize_graphics_(HWND hwnd)
	{
		// Initialize graphics device and swap chain
		auto graphic = new Graphics();
		auto suc = GetAdapterLuid(0, adapter_id_);

		if (!suc) {
			delete graphic;
			return -1; // Failed to get adapter LUID
		}

		auto hr = graphic->Create(adapter_id_);

		if (FAILED(hr)) {
			delete graphic;
			return -1; // Failed to create graphics device
		}

		graphics_ = graphic;

		SetView(hwnd);
		SetOutformat(ImageFormat::kBGRA);
		SetPosition(0, 0, width_, height_);
		type_ = StreamRenderType::kSingleRender;
		return 0; // Success
	}

	int I420Renderer::uninitialize_graphics_()
	{
		if (graphics_) {
			// Uninitialize graphics device and swap chain
			graphics_->Destroy();
			delete graphics_;
			graphics_ = nullptr;
		}

		return 0; // Success
	}

	//int I420Renderer::CreateShaders_()
	//{
	//	// Create shaders for rendering
	//	// This is a placeholder; actual shader creation code goes here
	//	auto result = initialize_shaders_(graphics_);
	//	return result; // Success
	//}

	//int I420Renderer::RecreateTextures_()
	//{
	//	// Recreate textures based on the new frame data
	//	// This is a placeholder; actual texture recreation code goes here
	//	return 0; // Success
	//}
}