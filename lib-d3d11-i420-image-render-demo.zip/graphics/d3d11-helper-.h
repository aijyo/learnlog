#ifndef __X_D3D11_FORMAT_HELPER_H__
#define __X_D3D11_FORMAT_HELPER_H__

#include "lib-d3d11/d3d-common/lib-common.h"

#include <dxgiformat.h>
#include <dxgi.h>

#include "lib-d3d11/d3d11/d3d11-device.h"

namespace lib_d3d {
	class LIB_EXPORT GrpahicsHelper {
	public:
		static uint32_t gs_get_format_bpp(enum gs_color_format format);
		static uint32_t gs_get_total_levels(uint32_t width, uint32_t height, uint32_t depth);
		static DXGI_FORMAT ConvertGSZStencilFormat(gs_zstencil_format format);

		//////////////////////////////////////////////////////////////////////////

		static bool screen_supports_hdr(GSDevice* device, HMONITOR hMonitor);
		static gs_color_space get_next_space(GSDevice* device, HWND hwnd);
		static gs_color_format get_swap_format_from_space(gs_color_space space,
			gs_color_format sdr_format);

		static gs_color_space make_swap_desc(GSDevice* device, DXGI_SWAP_CHAIN_DESC& desc,
			const swapchain_data_ptr data, DXGI_SWAP_EFFECT effect,
			UINT flags);

		static D3D11_PRIMITIVE_TOPOLOGY ConvertGSTopology(gs_draw_mode mode);
		//////////////////////////////////////////////////////////////////////////

		static bool GetMonitorTarget(const MONITORINFOEX& info,
			DISPLAYCONFIG_TARGET_DEVICE_NAME& target);

		static bool GetOutputDesc1(IDXGIOutput* const output, DXGI_OUTPUT_DESC1* desc1);

		// Returns true if this is an integrated display panel e.g. the screen attached to tablets or laptops.
		static bool IsInternalVideoOutput(
			const DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY VideoOutputTechnologyType);

		// Note: Since an hmon can represent multiple monitors while in clone, this function as written will return
		//  the value for the internal monitor if one exists, and otherwise the highest clone-path priority.
		static HRESULT GetPathInfo(_In_ PCWSTR pszDeviceName,
			_Out_ DISPLAYCONFIG_PATH_INFO* pPathInfo);

		// Overloaded function accepts an HMONITOR and converts to DeviceName
		static HRESULT GetPathInfo(HMONITOR hMonitor, _Out_ DISPLAYCONFIG_PATH_INFO* pPathInfo);
		static ULONG GetSdrWhiteNits(HMONITOR monitor);

		static void LogAdapterMonitors(IDXGIAdapter1* adapter);
		static long LogD3DAdapters();
	};

}
#endif // !__X_D3D11_FORMAT_CONVERTER_H__
