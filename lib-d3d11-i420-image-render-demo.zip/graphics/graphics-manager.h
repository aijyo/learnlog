//#pragma once
//#ifndef __X_GRAPHICS_MANAGER_H__
//#define __X_GRAPHICS_MANAGER_H__
//
//#include "lib-d3d11/third_party.h"
//#include <thread>
//#include <unordered_map>
//
//#include "./graphics.h"
//#include "lib-d3d11/effect/effect-manager.h"
//
//namespace lib_d3d
//{
//	class GraphicsManager
//	{
//	public:
//		~GraphicsManager();
//		GraphicsManager();
//
//		Graphics* GetGraphics(bool bCreate = true);
//		int DestroyGraphics();
//
//		EffectManager* GetEffectManger();
//
//	protected:
//		nbase::NLock lock_;
//		std::unordered_map<std::thread::id, Graphics* > graphics_;
//		std::unordered_map<std::thread::id, EffectManager* > effects_;
//	};
//
//
//	using GraphicsManagerInstance = nbase::Singleton<GraphicsManager>;
//}
//#endif // !__X_GRAPHICS_MANAGER_H__
