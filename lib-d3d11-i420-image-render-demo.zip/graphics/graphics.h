#pragma once
#ifndef __X_GRAPHICS_H__
#define __X_GRAPHICS_H__

#include <stack>
#include <memory>
#include <mutex>
#include <atomic>
#include <unordered_map>

#include "lib-d3d11/d3d11/d3d11-swapchain.h"

#include "lib-d3d11/d3d11/d3d11-device.h"
#include "lib-d3d11/d3d11/d3d11-timer.h"
#include "lib-d3d11/d3d11/d3d11-zstencilbuffer.h"
#include "lib-d3d11/d3d11/d3d11-stagesurf.h"
#include "lib-d3d11/d3d11/d3d11-duplicator.h"

#include "lib-d3d11/d3d-common/lib-common.h"

#include "./graphics-event.h"
namespace lib_d3d {
	//class Graphics
	class GSEffect;
	//https://learn.microsoft.com/zh-cn/windows/win32/direct3d11/overviews-direct3d-11-render-multi-thread-intro
	class LIB_EXPORT Graphics {
	public:
		Graphics();
		~Graphics();

		// graphics event listener
		long AddEventListener(IGSEventListener* listener);
		long RemoveEventListener(IGSEventListener* listener);

		// device op
		const char* PreprocessorName() const;
		long Create(LUID uid);
		int Destroy();

		GSDevicePtr GetDeviceObj();
		GSSwapchainPtr SwapchainCreate(const swapchain_data& data);
		long Resize(uint32_t x, uint32_t y);
		gs_color_space GetColorSpace();
		void UpdateColorSpace();
		void GetSize(uint32_t& x, uint32_t& y);

		uint32_t GetWidth();
		uint32_t GetHeight();

		// gs object create
		GSTexture2DPtr TextureCreate(uint32_t width, uint32_t height, gs_color_format color_format,
			uint32_t levels, const uint8_t** data, uint32_t flags);
		GSTexture2DPtr TextureCreate(HANDLE handle, bool ntHandle = false);

		GSTexturePtr CubeTextureCreate(uint32_t size, gs_color_format color_format, uint32_t levels,
			const uint8_t** data, uint32_t flags);
		GSTexturePtr VolTextureCreate(uint32_t width, uint32_t height, uint32_t depth,
			gs_color_format color_format, uint32_t levels,
			const uint8_t* const* data, uint32_t flags);
		GSZstencilBufferPtr ZstencilCreate(uint32_t width, uint32_t height,
			gs_zstencil_format format);
		GSStageSurfacePtr StageSurfCreate(uint32_t width, uint32_t height,
			gs_color_format color_format);
		GSSamplerStatePtr SamplerStateCreate(const gs_sampler_info& info);
		GSVertexShaderPtr VetextShaderCreate(const string& file, const vector<uint8_t>& inputdata,
			const D3D11_BUFFER_DESC& desc,
			const vector<D3D11_INPUT_ELEMENT_DESC>& layout);
		GSPixelShaderPtr PixelShaderCreate(const string& file, const D3D11_BUFFER_DESC& desc,
			const vector<uint8_t>& inputdata);
		GSVertexBufferPtr VertexBufferCreate(vertex_data_ptr data, uint32_t flags);
		GSIndexBufferPtr IndexBufferCreate(index_data_ptr indices, uint32_t flags);
		GSTimerPtr TimerCreate();
		GSTimerRangePtr TimerRangeCreate();

		// gs object destroy
		long ShaderDestroy(GSShaderPtr shader);
		long SwapchainDestroy(GSSwapchainPtr swapchain);
		long TextureDestroy(GSTexturePtr tex);

		long CubetextureDestroy(GSTexturePtr cubetex);
		long VoltextureDestroy(GSTexturePtr voltex);

		long StagesurfaceDestroy(GSStageSurfacePtr stagesurf);

		long ZstencilDestroy(GSZstencilBufferPtr zstencil);

		long SamplerstateDestroy(GSSamplerStatePtr samplerstate);

		long VertexbufferDestroy(GSVertexBufferPtr vertbuffer);

		long IndexbufferDestroy(GSIndexBufferPtr indexbuffer);

		long TimerDestroy(GSTimerPtr timer);

		long TimerRangeDestroy(GSTimerRangePtr timer);

		long DuplicatorDestroy(GSDuplicatorPtr duplicator);

		// gs object op
		gs_texture_type GetTextureType(const GSTexturePtr texture);
		void LoadVertexBuffer(GSVertexBufferPtr vertbuffer);
		void LoadIndexBuffer(GSIndexBufferPtr indexbuffer);
		void LoadTexture(GSTexturePtr tex, int unit);
		void LoadSamplerState(GSSamplerStatePtr samplerstate, int unit);
		void LoadVertexShader(GSVertexShaderPtr vertshader);
		void LoadPixelShader(GSPixelShaderPtr pixelshader);
		void LoadDefaultSamplerState(bool b_3d, int unit);
		GSVertexShaderPtr GetVertexShader();
		GSPixelShaderPtr GetPixelShader();
		GSTexturePtr GetRenderTarget();
		GSZstencilBufferPtr GetZstencilTarget();
		void SetRenderTarget(GSTexture2DPtr tex, GSZstencilBufferPtr zstencil);
		void SetRenderTargetWithColorSpace(GSTexture2DPtr tex, GSZstencilBufferPtr zstencil,
			gs_color_space space);
		void SetCubeRenderTarget(GSTexture2DPtr cubetex, int side, GSZstencilBufferPtr zstencil);
		void EnableFramebBufferSrgb(bool enable);
		bool DeviceFramebBufferSrgbEnable();
		void CopyTexture(GSTexture2DPtr dst, GSTexture2DPtr src);
		long CopyTextureRegion(GSTexture2DPtr dst, uint32_t dst_x, uint32_t dst_y,
			GSTexture2DPtr src, uint32_t src_x, uint32_t src_y, uint32_t src_w,
			uint32_t src_h);
		long StateTexture(GSStageSurfacePtr dst, GSTexture2DPtr src,
			const gs_rect& pos = gs_rect());
		void BeginFrame();
		void BeginScene();
		long Draw(gs_draw_mode draw_mode, uint32_t start_vert, uint32_t num_verts);
		void EndScene();
		void LoadSwapchain(GSSwapchainPtr swapchain);
		void Clear(uint32_t clear_flags, const vec4& color, float depth, uint8_t stencil);
		void Present();
		void Flush();
		void SetCullMode(gs_cull_mode mode);
		gs_cull_mode GetCullMode();
		void EnableBlending(bool enable);
		void EnableDepthTest(bool enable);

		void EnableStencilTest(bool enable);
		void EnableStencilWrite(bool enable);
		void EnableColor(bool red, bool green, bool blue, bool alpha);
		void BlendFunction(gs_blend_type src, gs_blend_type dest);
		void BlendFuncitonSeparate(gs_blend_type src_c, gs_blend_type dest_c, gs_blend_type src_a,
			gs_blend_type dest_a);
		void BlendOp(gs_blend_op_type op);

		void DepthFunction(gs_depth_test test);
		void StencilFunction(gs_stencil_side side, gs_depth_test test);
		void StencilOp(gs_stencil_side side, gs_stencil_op_type fail, gs_stencil_op_type zfail,
			gs_stencil_op_type zpass);
		void SetViewPort(int x, int y, int width, int height);
		void GetViewPort(gs_rect* rect);
		void SetScissorRect(const gs_rect* rect);
		//
		void Ortho(float left, float right, float top, float bottom, float znear, float zfar);
		void Frustum(float left, float right, float top, float bottom, float znear, float zfar);
		void ProjectionPush();
		void ProjectionPop();

		// static thread graphics op
		// view port

		/** sets the viewport to current swap chain size */
		long reset_viewport(void);

		long viewport_push(void);
		long viewport_pop(void);

		// matrix  matrix stack op
		long matrix_push(void);
		long matrix_pop(void);
		long matrix_identity(void);
		long matrix_transpose(void);
		long matrix_set(const matrix4& matrix);
		long matrix_get(matrix4& dst);
		long matrix_mul(const matrix4& matrix);
		long matrix_rotquat(const quat& rot);
		long matrix_rotaa(const axisang& rot);
		long matrix_translate(const vec3& pos);
		long matrix_scale(const vec3& scale);
		long matrix_rotaa4f(float x, float y, float z, float angle);
		long matrix_translate3f(float x, float y, float z);
		long matrix_scale3f(float x, float y, float z);

		// render
		long render_start(bool b_new);
		long render_stop(enum gs_draw_mode mode);
		GSVertexBufferPtr gs_render_save(void);
		long vertex2f(float x, float y);
		long vertex3f(float x, float y, float z);
		long normal3f(float x, float y, float z);
		long color(uint32_t color);
		long texcoord(float x, float y, int unit);
		long vertex2v(const vec2& v);
		long vertex3v(const vec3& v);
		long normal3v(const vec3& v);
		long color4v(const vec4& v);
		long texcoord2v(const vec2& v, int unit);

		static GSShaderPtr gs_vertexshader_create_from_file(const char* file, char** error_string);
		static GSShaderPtr gs_pixelshader_create_from_file(const char* file, char** error_string);

	public:
		GSDevicePtr device_;

		stack<gs_rect> viewport_stack_;
		stack<matrix4> matrix_stack_;
		size_t cur_matrix;
		matrix4 projection;

		//gs_effect *cur_effect;

		GSVertexBuffer* sprite_buffer;

		bool using_immediate;
		vertex_data_ptr vbd;
		GSVertexBufferPtr immediate_vertbuffer;
		vector<vec3> verts;
		vector<vec3> norms;
		vector<uint32_t> colors;
		//vector<vec2> texverts[16];
		vector<vector<vec2>> texverts;

		//pthread_mutex_t effect_mutex;
		std::mutex effect_lock_;
		//gs_effect *first_effect;
		std::list<GSEffect*> image_out_effects_;

		std::mutex context_lock_;
		volatile std::atomic_long ref_count_;

		BlendState cur_blend_state;
		vector<BlendState> blend_state_stack;

		bool linear_srgb;
		unordered_map<uintptr_t, IGSEventListener*> event_listener_;
	};

}
#endif