#include "graphics.h"
#include <DirectXMath.h>
#include "lib-d3d11/d3d11/d3d11-device.h"
#include "d3d11-helper.h"
#include "lib-d3d11/d3d11/d3d11-device.h"
#include "lib-d3d11/d3d11/d3d11-texture.h"
#include "lib-d3d11/d3d11/d3d11-texture2d.h"
#include "lib-d3d11/d3d11/d3d11-texture3d.h"
#include "lib-d3d11/d3d11/d3d11-zstencilbuffer.h"
#include "lib-d3d11/d3d11/d3d11-stagesurf.h"
#include "lib-d3d11/d3d11/d3d11-duplicator.h"

namespace lib_d3d {

#define TEXVERTS_SIZE (16)
#define IMMEDIATE_COUNT 512

// ID3D11DeviceContext is not thread safe,so before use it, we must lock it(use graphics->EnterContext)
//thread_local Graphics* this = nullptr;

Graphics::Graphics() {}

Graphics::~Graphics() { Destroy(); }

long Graphics::AddEventListener(IGSEventListener *listener)
{
	auto key = (uintptr_t)listener;
	auto it = event_listener_.find(key);
	bool bExist = it != event_listener_.end();
	if (!bExist) {
		event_listener_.insert(std::make_pair(key, listener));
	}
	return bExist ? 1 : 0;
}

long Graphics::RemoveEventListener(IGSEventListener *listener)
{
	auto key = (uintptr_t)listener;
	auto it = event_listener_.find(key);
	bool bExist = it != event_listener_.end();
	if (!bExist) {
		event_listener_.erase(it);
	}
	return bExist ? 0 : 1;
}

static bool IsCurrentThread(Graphics *gs)
{
	//bool result = nullptr != thread_graphics_
	//	&& gs == thread_graphics_;
	//return result;
	return true;
}

const char *Graphics::PreprocessorName() const
{
	return "_D3D11";
}

long Graphics::Create(LUID uid)
{
	int errorcode = GS_SUCCESS;
	HRESULT hr = S_OK;
	do {
		XLOG(LOG_INFO, "---------------------------------");
		XLOG(LOG_INFO, "Initializing D3D11...");
		hr = GrpahicsHelper::LogD3DAdapters();

		if (FAILED(hr)) {
			break;
		}
		auto device = std::make_shared<GSDevice>(uid);

		hr = device->Create();
		if (FAILED(hr)) {
			break;
		}

		device_ = device;
	} while (false);

	return errorcode;
}

int Graphics::Destroy()
{
	if (device_) {
		device_->Destroy();
		device_ = nullptr;
	}

	return S_OK;
}

//
//Graphics* Graphics::EnterContext(Graphics* graphics)
//{
//	Graphics* result = nullptr;
//
//	do
//	{
//		bool is_current = this == graphics;
//		if (this && !is_current)
//		{
//			while (this)
//				LeaveContext();
//		}
//
//		if (!is_current)
//		{
//			std::unique_lock<std::mutex> lock(graphics->context_lock_);
//			//pthread_mutex_lock(&graphics->mutex);
//			//graphics->device_.EnterContext(graphics->device);
//			this = graphics;
//		}
//
//		++graphics->ref_count_;
//
//		result = this;
//	} while (false);
//	return this;
//}
//
//Graphics* Graphics::CurrentGraphics()
//{
//	return this;
//}
//
//int Graphics::LeaveContext()
//{
//	/* does nothing */
//	if (--this->ref_count_ == 0)
//	{
//		Graphics* graphics = this;
//		//graphics->exports.device_leave_context(
//		//	graphics->device);
//		//pthread_mutex_unlock(&graphics->mutex);
//		std::unique_lock<std::mutex> lock(graphics->context_lock_);
//
//		this = nullptr;
//	}
//	return 0;
//}
GSDevicePtr Graphics::GetDeviceObj()
{
	return device_;
}

GSSwapchainPtr Graphics::SwapchainCreate(const swapchain_data &data)
{
	GSSwapchainPtr result = NULL;

	auto ptr = new GSSwapchain(device_.get());
	HRESULT hr = ptr->Create(data);

	if (SUCCEEDED(hr))
		result = ptr;

	return result;
}

static enum gs_color_format get_swap_format_from_space(gs_color_space space,
						       gs_color_format sdr_format)
{
	return (space == GS_CS_709_SCRGB) ? GS_RGBA16F : sdr_format;
}

static void device_resize_internal(GSDevicePtr device, uint32_t cx, uint32_t cy,
				   gs_color_space space)
{
	const gs_color_format format =
		get_swap_format_from_space(space, device->curSwapChain_->initData_.format_);

	device->context_->OMSetRenderTargets(0, NULL, NULL);
	device->curSwapChain_->Resize(cx, cy, format);
	device->curSwapChain_->space_ = space;
	device->curFramebufferInvalidate_ = true;
}
long Graphics::Resize(uint32_t cx, uint32_t cy)
{
	if (!device_->curSwapChain_) {
		XLOG(LOG_WARNING, "device_resize (D3D11): No active swap");
		return E_INVALIDARG;
	}

	gs_color_space next_space =
		GrpahicsHelper::get_next_space(device_.get(), device_->curSwapChain_->hwnd_);
	device_resize_internal(device_, cx, cy, next_space);

	return S_OK;
}

gs_color_space Graphics::GetColorSpace()
{
	return device_->curColorSpace_;
}

void Graphics::UpdateColorSpace()
{
	if (device_->curSwapChain_) {
		const enum gs_color_space next_space = GrpahicsHelper::get_next_space(
			device_.get(), device_->curSwapChain_->hwnd_);
		if (device_->curSwapChain_->space_ != next_space)
			device_resize_internal(device_, 0, 0, next_space);
	} else {
		XLOG(LOG_WARNING, "device_update_color_space (D3D11): No active swap");
	}
}
void Graphics::GetSize(uint32_t &cx, uint32_t &cy)
{
	if (device_->curSwapChain_) {
		cx = device_->curSwapChain_->target_.width_;
		cy = device_->curSwapChain_->target_.height_;
	} else {
		XLOG(LOG_ERROR, "device_get_size (D3D11): no active swap");
		cx = 0;
		cy = 0;
	}
}

uint32_t Graphics::GetWidth()
{
	uint32_t result = 0;
	if (device_->curSwapChain_) {
		result = device_->curSwapChain_->target_.width_;
	} else {
		XLOG(LOG_ERROR, "device_get_size (D3D11): no active swap");
	}
	return result;
}

uint32_t Graphics::GetHeight()
{
	uint32_t result = 0;
	if (device_->curSwapChain_) {
		result = device_->curSwapChain_->target_.height_;
	} else {
		XLOG(LOG_ERROR, "device_get_size (D3D11): no active swap");
	}
	return result;
}

GSTexture2DPtr Graphics::TextureCreate(uint32_t width, uint32_t height,
				       gs_color_format color_format, uint32_t levels,
				       const uint8_t **data, uint32_t flags)
{
	GSTexture2DPtr texture = NULL;

	//if (!IsCurrentThread(thread_graphics_))
	//	return texture;
	Graphics *graphics = this;
	auto device = graphics->device_.get();
	texture = new GSTexture2D(device);
	long result = texture->Create(device, width, height, color_format, levels, data, flags,
				      GS_TEXTURE_2D, false);

	if (result != S_OK) {
		texture = nullptr;
	}
	return texture;
}

GSTexture2DPtr Graphics::TextureCreate(HANDLE handle, bool ntHandle /* = false*/)
{
	GSTexture2DPtr texture = NULL;

	//if (!IsCurrentThread(thread_graphics_))
	//	return texture;
	Graphics *graphics = this;
	auto device = graphics->device_.get();
	texture = new GSTexture2D(device);
	long result = texture->Create(graphics->device_.get(), handle, ntHandle);

	if (result != S_OK) {
		texture = nullptr;
	}
	return texture;
}

GSTexturePtr Graphics::CubeTextureCreate(uint32_t size, gs_color_format color_format,
					 uint32_t levels, const uint8_t **data, uint32_t flags)
{
	GSTexturePtr texture = NULL;
	texture = device_->CubeTextureCreate(size, color_format, levels, data, flags);
	return texture;
}

GSTexturePtr Graphics::VolTextureCreate(uint32_t width, uint32_t height, uint32_t depth,
					gs_color_format color_format, uint32_t levels,
					const uint8_t *const *data, uint32_t flags)
{
	GSTexturePtr texture = NULL;
	//if (!IsCurrentThread(thread_graphics_))
	//	return texture;
	texture =
		device_->VolTextureCreate(width, height, depth, color_format, levels, data, flags);
	return texture;
}

GSZstencilBufferPtr Graphics::ZstencilCreate(uint32_t width, uint32_t height,
					     gs_zstencil_format format)
{
	GSZstencilBufferPtr zstencil = NULL;
	//if (!IsCurrentThread(thread_graphics_))
	//	return zstencil;
	zstencil = device_->ZstencilCreate(width, height, format);
	return zstencil;
}
GSStageSurfacePtr Graphics::StageSurfCreate(uint32_t width, uint32_t height,
					    gs_color_format color_format)
{
	GSStageSurfacePtr result = NULL;

	result = device_->StageSurfCreate(width, height, color_format);

	return result;
}

GSSamplerStatePtr Graphics::SamplerStateCreate(const gs_sampler_info &info)
{
	GSSamplerStatePtr result = NULL;
	result = device_->SamplerStateCreate(info);
	return result;
}

GSVertexShaderPtr Graphics::VetextShaderCreate(const string &file, const vector<uint8_t> &inputdata,
					       const D3D11_BUFFER_DESC &desc,
					       const vector<D3D11_INPUT_ELEMENT_DESC> &layout)
{
	GSVertexShaderPtr result = NULL;

	result = device_->VetextShaderCreate(file, inputdata, desc, layout);
	return result;
}

GSPixelShaderPtr Graphics::PixelShaderCreate(const string &file, const D3D11_BUFFER_DESC &desc,
					     const vector<uint8_t> &inputdata)
{
	GSPixelShaderPtr result = NULL;
	result = device_->PixelShaderCreate(file, desc, inputdata);
	return result;
}

GSVertexBufferPtr Graphics::VertexBufferCreate(vertex_data_ptr data, uint32_t flags)
{
	GSVertexBufferPtr result = NULL;

	result = device_->VertexBufferCreate(data, flags);
	return result;
}

GSIndexBufferPtr Graphics::IndexBufferCreate(index_data_ptr indices, uint32_t flags)
{
	GSIndexBufferPtr result = NULL;

	result = device_->IndexBufferCreate(indices, flags);
	return result;
}

GSTimerPtr Graphics::TimerCreate()
{
	GSTimerPtr timer = NULL;
	timer = device_->TimerCreate();

	return timer;
}

GSTimerRangePtr Graphics::TimerRangeCreate()
{
	GSTimerRangePtr range = nullptr;
	range = device_->TimerRangeCreate();

	return range;
}

long Graphics::ShaderDestroy(GSShaderPtr shader)
{
	HRESULT hr = S_OK;

	device_->ShaderDestroy(shader);

	return hr;
}

//long onEffectDestory();
//long OnTextureRenderDestroy(GSTextureRenderPtr render);
long Graphics::SwapchainDestroy(GSSwapchainPtr swapchain)
{
	HRESULT hr = S_OK;
	Graphics *graphics = this;
	if (graphics->device_->curSwapChain_ == swapchain) {
		graphics->LoadSwapchain(nullptr);
	}
	hr = device_->SwapchainDestroy(swapchain);
	return hr;
}

long Graphics::TextureDestroy(GSTexturePtr tex)
{
	HRESULT hr = S_OK;
	device_->TextureDestroy(tex);
	return hr;
}

long Graphics::CubetextureDestroy(GSTexturePtr cubetex)
{
	HRESULT hr = S_OK;
	device_->CubetextureDestroy(cubetex);
	return hr;
}

long Graphics::VoltextureDestroy(GSTexturePtr voltex)
{
	HRESULT hr = S_OK;
	device_->VoltextureDestroy(voltex);
	return hr;
}

long Graphics::StagesurfaceDestroy(GSStageSurfacePtr stagesurf)
{
	HRESULT hr = S_OK;
	device_->StagesurfaceDestroy(stagesurf);
	return hr;
}

long Graphics::ZstencilDestroy(GSZstencilBufferPtr zstencil)
{
	HRESULT hr = S_OK;
	device_->ZstencilDestroy(zstencil);
	return hr;
}

long Graphics::SamplerstateDestroy(GSSamplerStatePtr samplerstate)
{
	HRESULT hr = S_OK;
	if (!samplerstate)
		return hr;

	device_->SamplerstateDestroy(samplerstate);
	return hr;
}

long Graphics::VertexbufferDestroy(GSVertexBufferPtr vertbuffer)
{
	HRESULT hr = S_OK;
	device_->VertexbufferDestroy(vertbuffer);
	return hr;
}

long Graphics::IndexbufferDestroy(GSIndexBufferPtr indexbuffer)
{
	HRESULT hr = S_OK;
	device_->IndexbufferDestroy(indexbuffer);
	return hr;
}

long Graphics::TimerDestroy(GSTimerPtr timer)
{
	HRESULT hr = S_OK;
	device_->TimerDestroy(timer);
	return hr;
}

long Graphics::TimerRangeDestroy(GSTimerRangePtr timer)
{
	HRESULT hr = S_OK;
	device_->TimerRangeDestroy(timer);
	return hr;
}

long Graphics::DuplicatorDestroy(GSDuplicatorPtr duplicator)
{
	HRESULT hr = S_OK;
	device_->DuplicatorDestroy(duplicator);
	return hr;
}

gs_texture_type Graphics::GetTextureType(const GSTexturePtr texture)
{
	return texture->type_;
}

void Graphics::LoadVertexBuffer(GSVertexBufferPtr vertbuffer)
{
	if (device_->curVertexBuffer_ == vertbuffer)
		return;

	device_->curVertexBuffer_ = vertbuffer;
}

void Graphics::LoadIndexBuffer(GSIndexBufferPtr indexbuffer)
{
	device_->LoadIndexBufferData(indexbuffer);
}

static void device_load_texture_internal(GSDevice *device, GSTexturePtr tex, int unit,
					 ID3D11ShaderResourceView *view)
{
	if (device->curTextures_[unit] == tex)
		return;

	device->curTextures_[unit] = tex;
	device->context_->PSSetShaderResources(unit, 1, &view);
}

void Graphics::LoadTexture(GSTexturePtr tex, int unit)
{
	ID3D11ShaderResourceView *view;
	if (tex)
		view = tex->shaderRes_;
	else
		view = NULL;
	return device_load_texture_internal(device_.get(), tex, unit, view);
}

void Graphics::LoadSamplerState(GSSamplerStatePtr samplerstate, int unit)
{
	ID3D11SamplerState *state = NULL;

	if (device_->curSamplers_[unit] == samplerstate)
		return;

	if (samplerstate)
		state = samplerstate->state_;

	device_->curSamplers_[unit] = samplerstate;
	device_->context_->PSSetSamplers(unit, 1, &state);
}

void Graphics::LoadVertexShader(GSVertexShaderPtr vertshader)
{
	ID3D11VertexShader *shader = NULL;
	ID3D11InputLayout *layout = NULL;
	ID3D11Buffer *constants = NULL;

	if (device_->curVertexShader_ == vertshader)
		return;

	if (vertshader) {
		shader = vertshader->shader_;
		layout = vertshader->layout_;
		constants = vertshader->constants_;
	}

	device_->curVertexShader_ = vertshader;
	device_->context_->VSSetShader(shader, NULL, 0);
	device_->context_->IASetInputLayout(layout);
	device_->context_->VSSetConstantBuffers(0, 1, &constants);
}

static inline void clear_textures(GSDevice *device)
{
	ID3D11ShaderResourceView *views[GS_MAX_TEXTURES];
	memset(views, 0, sizeof(views));
	//memset(device->curTextures, 0, sizeof(device->curTextures));
	device->curTextures_.clear();
	device->context_->PSSetShaderResources(0, GS_MAX_TEXTURES, views);
}
void Graphics::LoadPixelShader(GSPixelShaderPtr pixelshader)
{
	ID3D11PixelShader *shader = NULL;
	ID3D11Buffer *constants = NULL;
	ID3D11SamplerState *states[GS_MAX_TEXTURES];

	if (device_->curPixelShader_ == pixelshader)
		return;

	if (pixelshader) {
		shader = pixelshader->shader_;
		constants = pixelshader->constants_;
		pixelshader->GetSamplerStates(states);
	} else {
		memset(states, 0, sizeof(states));
	}

	clear_textures(device_.get());

	device_->curPixelShader_ = pixelshader;
	device_->context_->PSSetShader(shader, NULL, 0);
	device_->context_->PSSetConstantBuffers(0, 1, &constants);
	device_->context_->PSSetSamplers(0, GS_MAX_TEXTURES, states);

	for (int i = 0; i < GS_MAX_TEXTURES; i++)
		if (device_->curSamplers_[i] && device_->curSamplers_[i]->state_ != states[i])
			device_->curSamplers_[i] = nullptr;
}

void Graphics::LoadDefaultSamplerState(bool b_3d, int unit)
{
	///* TODO */
	//UNUSED_PARAMETER(device);
	//UNUSED_PARAMETER(b_3d);
	//UNUSED_PARAMETER(unit);
}

GSVertexShaderPtr Graphics::GetVertexShader()
{
	return device_->curVertexShader_;
}

GSPixelShaderPtr Graphics::GetPixelShader()
{
	return device_->curPixelShader_;
}

GSTexturePtr Graphics::GetRenderTarget()
{
	if (device_->curRenderTarget_ == &device_->curSwapChain_->target_)
		return NULL;

	return device_->curRenderTarget_;
}

GSZstencilBufferPtr Graphics::GetZstencilTarget()
{
	if (device_->curZStencilBuffer_ == &device_->curSwapChain_->zstencilBuffer_)
		return NULL;

	return device_->curZStencilBuffer_;
}

static void device_set_render_target_internal(GSDevice *device, GSTexture2DPtr tex,
					      GSZstencilBufferPtr zstencil, gs_color_space space)
{
	if (device->curSwapChain_) {
		if (!tex)
		{
			tex = &device->curSwapChain_->target_;
			zstencil = &device->curSwapChain_->zstencilBuffer_;
		}
		//if (!zstencil)
		//	zstencil = &device->curSwapChain_->zstencilBuffer_;
	}

	if (device->curRenderTarget_ == tex && device->curZStencilBuffer_ == zstencil) {
		device->curColorSpace_ = space;
	}

	if (tex && tex->type_ != GS_TEXTURE_2D) {
		XLOG(LOG_ERROR,
		     "device_set_render_target_internal (D3D11): texture is not a 2D texture");
		return;
	}

	GSTexture2D *tex2d = static_cast<GSTexture2D *>(tex);
	if (device->curRenderTarget_ != tex2d || device->curRenderSide_ != 0 ||
	    device->curZStencilBuffer_ != zstencil) {
		device->curRenderTarget_ = tex;
		device->curZStencilBuffer_ = zstencil;
		device->curRenderSide_ = 0;
		device->curColorSpace_ = space;
		device->curFramebufferInvalidate_ = true;
	}
}
void Graphics::SetRenderTarget(GSTexture2DPtr tex, GSZstencilBufferPtr zstencil)
{
	gs_color_space space = GS_CS_SRGB;
	device_set_render_target_internal(device_.get(), tex, zstencil, GS_CS_SRGB);
}

void Graphics::SetRenderTargetWithColorSpace(GSTexture2DPtr tex, GSZstencilBufferPtr zstencil,
					     gs_color_space space)
{
	device_set_render_target_internal(device_.get(), tex, zstencil, space);
}

void Graphics::SetCubeRenderTarget(GSTexture2DPtr cubetex, int side, GSZstencilBufferPtr zstencil)
{
	if (device_->curSwapChain_) {
		if (!cubetex) {
			cubetex = &device_->curSwapChain_->target_;
			side = 0;
		}

		if (!zstencil)
			zstencil = &device_->curSwapChain_->zstencilBuffer_;
	}

	if (device_->curRenderTarget_ == cubetex && device_->curRenderSide_ == side &&
	    device_->curZStencilBuffer_ == zstencil)
		return;

	if (cubetex->type_ != GS_TEXTURE_CUBE) {
		XLOG(LOG_ERROR, "device_set_cube_render_target (D3D11): "
				"texture is not a cube texture");
		return;
	}

	if (device_->curRenderTarget_ != cubetex || device_->curRenderSide_ != side ||
	    device_->curZStencilBuffer_ != zstencil) {
		device_->curRenderTarget_ = cubetex;
		device_->curZStencilBuffer_ = zstencil;
		device_->curRenderSide_ = side;
		device_->curColorSpace_ = GS_CS_SRGB;
		device_->curFramebufferInvalidate_ = true;
	}
}

void Graphics::EnableFramebBufferSrgb(bool enable)
{
	if (device_->curFramebufferSrgb_ != enable) {
		device_->curFramebufferSrgb_ = enable;
		device_->curFramebufferInvalidate_ = true;
	}
}

bool Graphics::DeviceFramebBufferSrgbEnable()
{
	return device_->curFramebufferSrgb_;
}

void Graphics::CopyTexture(GSTexture2DPtr dst, GSTexture2DPtr src)
{
	CopyTextureRegion(dst, 0, 0, src, 0, 0, 0, 0);
}

static DXGI_FORMAT get_copy_compare_format(gs_color_format format)
{
	switch (format) {
	case GS_RGBA_UNORM:
		return DXGI_FORMAT_R8G8B8A8_TYPELESS;
	case GS_BGRX_UNORM:
		return DXGI_FORMAT_B8G8R8X8_TYPELESS;
	case GS_BGRA_UNORM:
		return DXGI_FORMAT_B8G8R8A8_TYPELESS;
	default:
		return ConvertGSTextureFormatResource(format);
	}
}

long Graphics::CopyTextureRegion(GSTexture2DPtr dst, uint32_t dst_x, uint32_t dst_y,
				 GSTexture2DPtr src, uint32_t src_x, uint32_t src_y, uint32_t src_w,
				 uint32_t src_h)
{
	HRESULT hr = S_OK;
	do {
		GSTexture2D *src2d = src;
		GSTexture2D *dst2d = dst;

		if (!src) {
			hr = E_INVALIDARG;
			break;
		}
		if (!dst) {
			hr = E_INVALIDARG;
			break;
		}
		if (get_copy_compare_format(dst->format_) !=
		    get_copy_compare_format(src->format_)) {
			hr = E_INVALIDARG;
			break;
		}

		/* apparently casting to the same type that the variable
		 * already exists as is supposed to prevent some warning
		 * when used with the conditional operator? */
		uint32_t copyWidth = (uint32_t)src_w ? (uint32_t)src_w : (src2d->width_ - src_x);
		uint32_t copyHeight = (uint32_t)src_h ? (uint32_t)src_h : (src2d->height_ - src_y);

		uint32_t dstWidth = dst2d->width_ - dst_x;
		uint32_t dstHeight = dst2d->height_ - dst_y;

		if (dstWidth < copyWidth || dstHeight < copyHeight) {
			hr = E_INVALIDARG;
			break;
		}

		if (dst_x == 0 && dst_y == 0 && src_x == 0 && src_y == 0 && src_w == 0 &&
		    src_h == 0) {
			copyWidth = 0;
			copyHeight = 0;
		}

		device_->CopyTex(dst2d->texture_, dst_x, dst_y, src, src_x, src_y, copyWidth,
				 copyHeight);

	} while (false);

	return hr;
}

long Graphics::StateTexture(GSStageSurfacePtr dst, GSTexture2DPtr src,
			    const gs_rect &pos /* = gs_rect()*/)
{

	HRESULT hr = S_OK;
	do {
		GSTexture2D *src2d = src;

		if (!src) {
			hr = E_INVALIDARG;
			break;
		}
		if (src->type_ != GS_TEXTURE_2D) {
			hr = E_INVALIDARG;
			break;
		}
		if (!dst) {
			hr = E_INVALIDARG;
			break;
		}
		if (dst->format_ != GS_UNKNOWN && dst->format_ != src->format_) {
			hr = E_INVALIDARG;
			break;
		}
		if (dst->get_width() != src2d->width_ || dst->get_height() != src2d->height_) {
			hr = E_INVALIDARG;
			break;
		}

		device_->CopyTex(dst->texture_, 0, 0, src, pos.left, pos.top, pos.width(),
				 pos.height());
	} while (false);

	return hr;
}

void Graphics::BeginFrame()
{
	/* does nothing in D3D11 */
	//UNUSED_PARAMETER(device);

	GSDuplicator::reset_duplicators();
}

//static inline void clear_textures(GSDevice *device)
//{
//	ID3D11ShaderResourceView *views[GS_MAX_TEXTURES];
//	memset(views, 0, sizeof(views));
//	device->curTextures.clear();
//	//memset(device->curTextures, 0, sizeof(device->curTextures));
//	device->context->PSSetShaderResources(0, GS_MAX_TEXTURES, views);
//}
void Graphics::BeginScene()
{
	clear_textures(device_.get());
}

long Graphics::Draw(gs_draw_mode draw_mode, uint32_t start_vert, uint32_t num_verts)
{
	HRESULT hr = S_OK;
	do {
		if (!device_->curVertexShader_) {
			hr = E_INVALIDARG;
			break;
		}

		if (!device_->curPixelShader_) {
			hr = E_INVALIDARG;
			break;
		}

		if (!device_->curVertexBuffer_ && (num_verts == 0)) {
			hr = E_INVALIDARG;
			break;
		}

		if (!device_->curSwapChain_ && !device_->curRenderTarget_) {
			hr = E_INVALIDARG;
			break;
		}

		device_->FlushOutputViews();

		//gs_effect_t *effect = gs_get_effect();
		//if (effect)
		//	gs_effect_update_params(effect);

		device_->LoadVertexBufferData();
		device_->UpdateBlendState();
		device_->UpdateRasterState();
		device_->UpdateZStencilState();
		//gs_matrix_get(&curViewMatrix_);
		matrix4 curViewMatrix;
		matrix_get(curViewMatrix);
		device_->UpdateViewProjMatrix(curViewMatrix);
		device_->curVertexShader_->UploadParams();
		device_->curPixelShader_->UploadParams();

		D3D11_PRIMITIVE_TOPOLOGY newTopology = GrpahicsHelper::ConvertGSTopology(draw_mode);
		if (device_->curToplogy_ != newTopology) {
			device_->context_->IASetPrimitiveTopology(newTopology);
			device_->curToplogy_ = newTopology;
		}

		if (device_->curIndexBuffer_) {
			if (num_verts == 0)
				num_verts = (uint32_t)device_->curIndexBuffer_->PointNum();
			device_->context_->DrawIndexed(num_verts, start_vert, 0);
		} else {
			if (num_verts == 0)
				num_verts = (uint32_t)device_->curVertexBuffer_->numVerts_;
			device_->context_->Draw(num_verts, start_vert);
		}
	} while (false);
	return hr;
}

void Graphics::EndScene()
{
	/* does nothing in D3D11 */
}

void device_set_cube_render_target(GSDevice *device, GSTexture2DPtr tex, int side,
				   GSZstencilBufferPtr zstencil)
{
	if (device->curSwapChain_) {
		if (!tex) {
			tex = &device->curSwapChain_->target_;
			side = 0;
		}

		if (!zstencil)
			zstencil = &device->curSwapChain_->zstencilBuffer_;
	}

	if (device->curRenderTarget_ == tex && device->curRenderSide_ == side &&
	    device->curZStencilBuffer_ == zstencil)
		return;

	if (tex->type_ != GS_TEXTURE_CUBE) {
		XLOG(LOG_ERROR, "device_set_cube_render_target (D3D11): "
				"texture is not a cube texture");
		return;
	}

	if (device->curRenderTarget_ != tex || device->curRenderSide_ != side ||
	    device->curZStencilBuffer_ != zstencil) {
		device->curRenderTarget_ = tex;
		device->curZStencilBuffer_ = zstencil;
		device->curRenderSide_ = side;
		device->curColorSpace_ = GS_CS_SRGB;
		device->curFramebufferInvalidate_ = true;
	}
}
//
//static void device_set_render_target_internal(GSDevice *device, GSTexture2DPtr tex, GSZstencilBufferPtr zstencil, gs_color_space space)
//{
//	if (device->curSwapChain)
//	{
//		if (!tex)
//			tex = device->curSwapChain->target_;
//		if (!zstencil)
//			zstencil = device->curSwapChain->zstencilBuffer_;
//	}
//
//	if (device->curRenderTarget == tex && device->curZStencilBuffer == zstencil)
//	{
//		device->curColorSpace = space;
//	}
//
//	if (device->curRenderTarget != tex
//		|| device->curRenderSide != 0
//		|| device->curZStencilBuffer != zstencil)
//	{
//		device->curRenderTarget = tex;
//		device->curZStencilBuffer = zstencil;
//		device->curRenderSide = 0;
//		device->curColorSpace = space;
//		device->curFramebufferInvalidate = true;
//	}
//}

void Graphics::LoadSwapchain(GSSwapchainPtr swapchain)
{
	auto target = device_->curRenderTarget_;
	auto zs = device_->curZStencilBuffer_;
	bool is_cube = device_->curRenderTarget_
			       ? (device_->curRenderTarget_->type_ == GS_TEXTURE_CUBE)
			       : false;

	if (device_->curSwapChain_) {
		if (target == &device_->curSwapChain_->target_)
			target = NULL;
		if (zs == &device_->curSwapChain_->zstencilBuffer_)
			zs = NULL;
	}

	device_->curSwapChain_ = swapchain;

	if (is_cube) {
		device_set_cube_render_target(device_.get(), target, device_->curRenderSide_, zs);
	} else {
		const gs_color_space space = swapchain ? swapchain->space_ : GS_CS_SRGB;
		device_set_render_target_internal(device_.get(), target, zs, space);
	}
}

void Graphics::Clear(uint32_t clear_flags, const vec4 &color, float depth, uint8_t stencil)
{
	if (clear_flags & GS_CLEAR_COLOR) {
		auto tex = device_->curRenderTarget_;
		if (tex) {
			const int side = device_->curRenderSide_;
			ID3D11RenderTargetView *const rtv = device_->curFramebufferSrgb_
								    ? tex->renderTargetLinear_[side]
								    : tex->renderTarget_[side];
			device_->context_->ClearRenderTargetView(rtv, (float *)&color.x);
		}
	}

	if (device_->curZStencilBuffer_) {
		uint32_t flags = 0;
		if ((clear_flags & GS_CLEAR_DEPTH) != 0)
			flags |= D3D11_CLEAR_DEPTH;
		if ((clear_flags & GS_CLEAR_STENCIL) != 0)
			flags |= D3D11_CLEAR_STENCIL;

		if (flags && device_->curZStencilBuffer_->view_)
			device_->context_->ClearDepthStencilView(device_->curZStencilBuffer_->view_,
								 flags, depth, stencil);
	}
}

void Graphics::Present()
{
	auto curSwapChain = device_->curSwapChain_;
	if (curSwapChain) {
		/* Skip Present at frame limit to avoid stall */
		const HANDLE hWaitable = curSwapChain->hWaitable;
		if ((hWaitable == NULL) || WaitForSingleObject(hWaitable, 0) == WAIT_OBJECT_0) {
			const HRESULT hr =
				curSwapChain->swapchain_->Present(0, curSwapChain->presentFlags_);
			if (hr == DXGI_ERROR_DEVICE_REMOVED || hr == DXGI_ERROR_DEVICE_RESET) {
				device_->RebuildDevice();
			}
		}
	} else {
		XLOG(LOG_WARNING, "device_present (D3D11): No active swap");
	}
}

void Graphics::Flush()
{
	device_->context_->Flush();
}

void Graphics::SetCullMode(enum gs_cull_mode mode)
{
	if (mode == device_->rasterState_.cullMode)
		return;

	device_->rasterState_.cullMode = mode;
	device_->rasterStateChanged_ = true;
}

gs_cull_mode Graphics::GetCullMode()
{
	return device_->rasterState_.cullMode;
}
void Graphics::EnableBlending(bool enable)
{
	if (enable == device_->blendState_.blendEnabled)
		return;

	device_->blendState_.blendEnabled = enable;
	device_->blendStateChanged_ = true;
}

void Graphics::EnableDepthTest(bool enable)
{
	if (enable == device_->zstencilState_.depthEnabled)
		return;

	device_->zstencilState_.depthEnabled = enable;
	device_->zstencilStateChanged_ = true;
}

void Graphics::EnableStencilTest(bool enable)
{
	if (enable == device_->zstencilState_.stencilEnabled)
		return;

	device_->zstencilState_.stencilEnabled = enable;
	device_->zstencilStateChanged_ = true;
}
void Graphics::EnableStencilWrite(bool enable)
{
	if (enable == device_->zstencilState_.stencilWriteEnabled)
		return;

	device_->zstencilState_.stencilWriteEnabled = enable;
	device_->zstencilStateChanged_ = true;
}
void Graphics::EnableColor(bool red, bool green, bool blue, bool alpha)
{
	if (device_->blendState_.redEnabled == red && device_->blendState_.greenEnabled == green &&
	    device_->blendState_.blueEnabled == blue && device_->blendState_.alphaEnabled == alpha)
		return;

	device_->blendState_.redEnabled = red;
	device_->blendState_.greenEnabled = green;
	device_->blendState_.blueEnabled = blue;
	device_->blendState_.alphaEnabled = alpha;
	device_->blendStateChanged_ = true;
}

void Graphics::BlendFunction(gs_blend_type src, gs_blend_type dest)
{
	if (device_->blendState_.srcFactorC == src && device_->blendState_.destFactorC == dest &&
	    device_->blendState_.srcFactorA == src && device_->blendState_.destFactorA == dest)
		return;

	device_->blendState_.srcFactorC = src;
	device_->blendState_.destFactorC = dest;
	device_->blendState_.srcFactorA = src;
	device_->blendState_.destFactorA = dest;
	device_->blendStateChanged_ = true;
}

void Graphics::BlendFuncitonSeparate(gs_blend_type src_c, gs_blend_type dest_c, gs_blend_type src_a,
				     gs_blend_type dest_a)
{
	if (device_->blendState_.srcFactorC == src_c &&
	    device_->blendState_.destFactorC == dest_c &&
	    device_->blendState_.srcFactorA == src_a && device_->blendState_.destFactorA == dest_a)
		return;

	device_->blendState_.srcFactorC = src_c;
	device_->blendState_.destFactorC = dest_c;
	device_->blendState_.srcFactorA = src_a;
	device_->blendState_.destFactorA = dest_a;
	device_->blendStateChanged_ = true;
}

void Graphics::BlendOp(enum gs_blend_op_type op)
{
	if (device_->blendState_.op == op)
		return;

	device_->blendState_.op = op;
	device_->blendStateChanged_ = true;
}

void Graphics::DepthFunction(enum gs_depth_test test)
{
	if (device_->zstencilState_.depthFunc == test)
		return;

	device_->zstencilState_.depthFunc = test;
	device_->zstencilStateChanged_ = true;
}

static inline void update_stencilside_test(GSDevice *device, StencilSide &side, gs_depth_test test)
{
	if (side.test == test)
		return;

	side.test = test;
	device->zstencilStateChanged_ = true;
}

void Graphics::StencilFunction(gs_stencil_side side, gs_depth_test test)
{
	int sideVal = (int)side;
	auto device = device_.get();
	if (sideVal & GS_STENCIL_FRONT)
		update_stencilside_test(device, device_->zstencilState_.stencilFront, test);
	if (sideVal & GS_STENCIL_BACK)
		update_stencilside_test(device, device_->zstencilState_.stencilBack, test);
}

static inline void update_stencilside_op(GSDevice *device, StencilSide &side,
					 gs_stencil_op_type fail, gs_stencil_op_type zfail,
					 gs_stencil_op_type zpass)
{
	if (side.fail == fail && side.zfail == zfail && side.zpass == zpass)
		return;

	side.fail = fail;
	side.zfail = zfail;
	side.zpass = zpass;
	device->zstencilStateChanged_ = true;
}

void Graphics::StencilOp(gs_stencil_side side, gs_stencil_op_type fail, gs_stencil_op_type zfail,
			 gs_stencil_op_type zpass)
{
	int sideVal = (int)side;
	auto device = device_.get();

	if (sideVal & GS_STENCIL_FRONT)
		update_stencilside_op(device, device->zstencilState_.stencilFront, fail, zfail,
				      zpass);
	if (sideVal & GS_STENCIL_BACK)
		update_stencilside_op(device, device->zstencilState_.stencilBack, fail, zfail,
				      zpass);
}

void Graphics::SetViewPort(int x, int y, int width, int height)
{
	D3D11_VIEWPORT vp;

	memset(&vp, 0, sizeof(vp));
	vp.MaxDepth = 1.0f;
	vp.TopLeftX = (float)x;
	vp.TopLeftY = (float)y;
	vp.Width = (float)width;
	vp.Height = (float)height;
	device_->context_->RSSetViewports(1, &vp);

	device_->viewport_.left = x;
	device_->viewport_.top = y;
	device_->viewport_.right = x + width;
	device_->viewport_.bottom = y + height;
}

void Graphics::GetViewPort(gs_rect *rect)
{
	*rect = device_->viewport_;
}

void Graphics::SetScissorRect(const gs_rect *rect)
{
	D3D11_RECT d3drect;

	device_->rasterState_.scissorEnabled = (rect != NULL);

	if (rect != NULL) {
		//d3drect.left = rect->left;
		//d3drect.top = rect->y;
		//d3drect.right = rect->x + rect->cx;
		//d3drect.bottom = rect->y + rect->cy;
		d3drect = *rect;
		device_->context_->RSSetScissorRects(1, &d3drect);
	}

	device_->rasterStateChanged_ = true;
}
void Graphics::Ortho(float left, float right, float top, float bottom, float znear, float zfar)
{
	matrix4 *dst = &device_->curProjMatrix_;

	float rml = right - left;
	float bmt = bottom - top;
	float fmn = zfar - znear;

	// reset
	*dst = matrix4();

	//vec4_zero(&dst->x);
	//vec4_zero(&dst->y);
	//vec4_zero(&dst->z);
	//vec4_zero(&dst->t);

	dst->_11 = 2.0f / rml;
	dst->_41 = (left + right) / -rml;

	dst->_22 = 2.0f / -bmt;
	dst->_42 = (bottom + top) / bmt;

	dst->_33 = 1.0f / fmn;
	dst->_43 = znear / -fmn;

	dst->_44 = 1.0f;
}
void Graphics::Frustum(float left, float right, float top, float bottom, float znear, float zfar)
{
	matrix4 *dst = &device_->curProjMatrix_;

	float rml = right - left;
	float bmt = bottom - top;
	float fmn = zfar - znear;
	float nearx2 = 2.0f * znear;

	// reset
	*dst = matrix4();
	//vec4_zero(&dst->x);
	//vec4_zero(&dst->y);
	//vec4_zero(&dst->z);
	//vec4_zero(&dst->t);

	dst->_11 = nearx2 / rml;
	dst->_31 = (left + right) / -rml;

	dst->_22 = nearx2 / -bmt;
	dst->_32 = (bottom + top) / bmt;

	dst->_33 = zfar / fmn;
	dst->_43 = (zfar * zfar) / -fmn;

	dst->_34 = 1.0f;
}
void Graphics::ProjectionPush()
{
	mat4float mat;
	memcpy(&mat, &device_->curProjMatrix_, sizeof(matrix4));
	device_->projStack_.push_back(mat);
}
void Graphics::ProjectionPop()
{
	if (device_->projStack_.empty())
		return;

	const mat4float &mat = device_->projStack_.back();
	memcpy(&device_->curProjMatrix_, &mat, sizeof(matrix4));
	device_->projStack_.pop_back();
}

//long Graphics::SwapchainDestroy(GSSwapchainPtr swapchain)
//{
//	if (swapchain->device_->curSwapChain_ == swapchain)
//		LoadSwapchain(nullptr);
//}

// viewport
//
long Graphics::reset_viewport(void)
{
	HRESULT hr = S_OK;

	return hr;
}

long Graphics::viewport_push(void)
{
	HRESULT hr = S_OK;

	return hr;
}

long Graphics::viewport_pop(void)
{
	HRESULT hr = S_OK;
	//struct gs_rect* rect;

	//if (!device_->viewport_.empty())
	//{
	//	gs_set_viewport(rect->x, rect->y, rect->cx, rect->cy);
	//}

	//rect = da_end(thread_graphics->viewport_stack);
	//gs_set_viewport(rect->x, rect->y, rect->cx, rect->cy);
	//da_pop_back(thread_graphics->viewport_stack);
	return hr;
}
//////////////////////////////////////////////////////////////////////////
//matrix
//static inline matrix4& top_matrix(Graphics* graphics)
//{
//	return graphics->matrix_stack_.top();
//}

long Graphics::matrix_push(void)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		matrix4 mat = graphics->matrix_stack_.top();
		graphics->matrix_stack_.push(mat);

	} while (false);
	return hr;
}

long Graphics::matrix_pop(void)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;

		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}

		graphics->matrix_stack_.pop();
	} while (false);
	return hr;
}

long Graphics::matrix_identity(void)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		Matrix::MatrixToIdentity(t);

	} while (false);
	return hr;
}

long Graphics::matrix_transpose(void)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		Matrix::MatrixToIdentity(t);

	} while (false);
	return hr;
}

long Graphics::matrix_set(const matrix4 &matrix)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		t = matrix;

	} while (false);
	return hr;
}

long Graphics::matrix_get(matrix4 &dst)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		dst = t;

	} while (false);
	return hr;
}

long Graphics::matrix_mul(const matrix4 &matrix)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		Matrix4::matrix4_mul(t, matrix, t);

	} while (false);
	return hr;
}

long Graphics::matrix_rotquat(const quat &rot)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		Matrix4::matrix4_rotate_i(t, rot, t);

	} while (false);
	return hr;
}

long Graphics::matrix_rotaa(const axisang &rot)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		Matrix4::matrix4_rotate_aa_i(t, rot, t);

	} while (false);
	return hr;
}

long Graphics::matrix_translate(const vec3 &pos)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		Matrix4::matrix4_translate3v_i(t, pos, t);

	} while (false);
	return hr;
}

long Graphics::matrix_scale(const vec3 &scale)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		Matrix4::matrix4_scale_i(t, scale, t);

	} while (false);
	return hr;
}

long Graphics::matrix_rotaa4f(float x, float y, float z, float angle)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		axisang aa(x, y, z, angle);
		Matrix4::matrix4_rotate_aa_i(t, aa, t);

	} while (false);
	return hr;
}

long Graphics::matrix_translate3f(float x, float y, float z)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		vec3 p(x, y, z);
		Matrix4::matrix4_translate3v_i(t, p, t);

	} while (false);
	return hr;
}

long Graphics::matrix_scale3f(float x, float y, float z)
{
	HRESULT hr = S_OK;

	do {
		if (!IsCurrentThread(this)) {
			XLOG(LOG_ERROR, "graphics IsCurrentThread Failed");
			hr = E_FAIL;
			break;
		}
		auto graphics = this;
		if (graphics->matrix_stack_.empty()) {
			XLOG(LOG_ERROR, "Tried to pop last matrix on stack");
			break;
		}
		auto &t = graphics->matrix_stack_.top();

		vec3 p(x, y, z);
		Matrix4::matrix4_scale_i(t, p, t);

	} while (false);
	return hr;
}

// render
//
//static void reset_immediate_arrays(graphics_t* graphics)
//{
//	graphics->verts.clear();
//	graphics->norms.clear();
//	graphics->colors.clear();
//	graphics->texverts.clear();
//	//for (size_t i = 0; i < 16; i++)
//	//	da_init(graphics->texverts[i]);
//}
static inline void reset_immediate_arrays(Graphics *graphics)
{
	graphics->verts.clear();
	graphics->norms.clear();
	graphics->colors.clear();
	for (size_t i = 0; i < graphics->texverts.size(); i++)
		graphics->texverts[i].clear();
}
long Graphics::render_start(bool b_new)
{
	HRESULT hr = S_OK;
	Graphics *graphics = this;

	graphics->using_immediate = !b_new;
	//reset_immediate_arrays(graphics);

	graphics->verts.clear();
	graphics->norms.clear();
	graphics->colors.clear();

	graphics->texverts.resize(TEXVERTS_SIZE, vector<vec2>());
	if (b_new) {
		graphics->vbd = std::make_shared<vertex_data>();
	} else {
		graphics->vbd = graphics->immediate_vertbuffer->Data();
		graphics->vbd->colors_.resize(IMMEDIATE_COUNT, 0xFF);
		graphics->verts = graphics->vbd->points_;
		graphics->norms = graphics->vbd->normals_;
		graphics->colors = graphics->vbd->colors_;

		graphics->texverts = graphics->vbd->tvarray_;
		//for (size_t i = 0; i < 16; i++)
		//	graphics->texverts[0] = graphics->vbd.tvarray_[0];
	}

	return hr;
}

long Graphics::render_stop(enum gs_draw_mode mode)
{
	Graphics *graphics = this;
	size_t num;
	HRESULT hr = S_OK;
	do {
		num = graphics->verts.size();
		if (!num) {
			if (!graphics->using_immediate) {
				graphics->verts.clear();
				graphics->norms.clear();
				graphics->colors.clear();
				graphics->texverts.resize(TEXVERTS_SIZE, vector<vec2>());
				graphics->vbd = std::make_shared<vertex_data>();
			}
			break;
		}

		if (graphics->norms.size() && (graphics->norms.size() != graphics->verts.size())) {
			XLOG(LOG_ERROR, "gs_render_stop: normal count does "
					"not match vertex count");
			num = std::min<size_t>(num, graphics->norms.size());
		}

		if (graphics->colors.size() &&
		    (graphics->colors.size() != graphics->verts.size())) {
			XLOG(LOG_ERROR, "gs_render_stop: color count does "
					"not match vertex count");
			num = std::min<size_t>(num, graphics->colors.size());
		}

		if (graphics->texverts[0].size() &&
		    (graphics->texverts[0].size() != graphics->verts.size())) {
			XLOG(LOG_ERROR, "gs_render_stop: texture vertex count does "
					"not match vertex count");
			num = std::min<size_t>(num, graphics->texverts[0].size());
		}

		if (graphics->using_immediate) {
			//gs_vertexbuffer_flush(graphics->immediate_vertbuffer);
			graphics->immediate_vertbuffer->Flush(nullptr);

			//gs_load_vertexbuffer(graphics->immediate_vertbuffer);
			LoadVertexBuffer(graphics->immediate_vertbuffer);
			//gs_load_indexbuffer(NULL);
			LoadIndexBuffer(nullptr);
			Draw(mode, 0, (uint32_t)num);

			reset_immediate_arrays(graphics);
		} else {
			GSVertexBufferPtr vb = gs_render_save();

			//gs_load_vertexbuffer(vb);
			LoadVertexBuffer(vb);
			//gs_load_indexbuffer(NULL);
			LoadIndexBuffer(nullptr);
			Draw(mode, 0, 0);

			//gs_vertexbuffer_destroy(vb);
			vb->Destroy();
		}

		graphics->vbd = std::make_shared<vertex_data>();
	} while (false);

	return hr;
}

GSVertexBufferPtr Graphics::gs_render_save(void)
{
	Graphics *graphics = this;
	size_t num_tex, i;

	if (graphics->using_immediate)
		return NULL;

	if (!graphics->verts.size()) {
		//gs_vbdata_destroy(graphics->vbd);
		graphics->vbd = std::make_shared<vertex_data>();
		return NULL;
	}

	for (num_tex = 0; num_tex < TEXVERTS_SIZE; num_tex++)
		if (!graphics->texverts[num_tex].size())
			break;

	graphics->vbd->points_ = graphics->verts;
	graphics->vbd->normals_ = graphics->norms;
	graphics->vbd->colors_ = graphics->colors;
	//graphics->vbd->num_ = graphics->verts.size();
	//graphics->vbd->num_tex_ = num_tex;

	if (num_tex) {
		graphics->vbd->tvarray_.resize(num_tex);

		for (i = 0; i < num_tex; i++) {
			//graphics->vbd.tvarray_[i].width = 2;
			graphics->vbd->tvarray_[i] = graphics->texverts[i];
		}
	}

	reset_immediate_arrays(graphics);

	return VertexBufferCreate(graphics->vbd, 0);
}

long Graphics::vertex2f(float x, float y)
{
	vec3 v3 = {x, y, 0.0f};

	return vertex3v(v3);
}

long Graphics::vertex3f(float x, float y, float z)
{
	vec3 v3 = {x, y, z};

	return vertex3v(v3);
}

long Graphics::normal3f(float x, float y, float z)
{
	vec3 v3 = {x, y, z};
	return normal3v(v3);
}

static inline bool validvertsize(Graphics *graphics, size_t num, const char *name)
{
	if (graphics->using_immediate && num == IMMEDIATE_COUNT) {
		XLOG(LOG_ERROR,
		     "%s: tried to use over %u "
		     "for immediate rendering",
		     name, IMMEDIATE_COUNT);
		return false;
	}

	return true;
}
long Graphics::color(uint32_t color)
{
	Graphics *graphics = this;

	if (!validvertsize(graphics, graphics->colors.size(), "gs_color"))
		return E_FAIL;

	graphics->colors.push_back(color);

	return S_OK;
}

long Graphics::texcoord(float x, float y, int unit)
{
	vec2 v2 = {x, y};

	return texcoord2v(v2, unit);
}

long Graphics::vertex2v(const vec2 &v)
{
	vec3 v3 = {v.x, v.y, 0.0f};

	return vertex3v(v3);
}

long Graphics::vertex3v(const vec3 &v)
{
	Graphics *graphics = this;

	if (!validvertsize(graphics, graphics->verts.size(), "gs_vertex"))
		return E_FAIL;

	graphics->verts.push_back(v);
	return S_OK;
}

long Graphics::normal3v(const vec3 &v)
{
	Graphics *graphics = this;

	if (!validvertsize(graphics, graphics->norms.size(), "gs_normal"))
		return E_FAIL;

	graphics->norms.push_back(v);
	return S_OK;
}

long Graphics::color4v(const vec4 &v)
{
	/* TODO */
	//UNUSED_PARAMETER(v);
	return S_OK;
}

long Graphics::texcoord2v(const vec2 &v, int unit)
{
	Graphics *graphics = this;

	if (!validvertsize(graphics, graphics->texverts[unit].size(), "gs_texcoord"))
		return E_FAIL;

	graphics->texverts[unit].push_back(v);
	return S_OK;
}

}