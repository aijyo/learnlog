//#include <windows.h>
#include "d3d11-helper.h"

namespace lib_d3d {
	uint32_t GrpahicsHelper::gs_get_format_bpp(enum gs_color_format format)
	{
		switch (format) {
		case GS_DXT1:
			return 4;
		case GS_A8:
		case GS_R8:
		case GS_DXT3:
		case GS_DXT5:
			return 8;
		case GS_R16:
		case GS_R16F:
		case GS_R8G8:
			return 16;
		case GS_RGBA:
		case GS_BGRX:
		case GS_BGRA:
		case GS_R10G10B10A2:
		case GS_RG16F:
		case GS_R32F:
		case GS_RGBA_UNORM:
		case GS_BGRX_UNORM:
		case GS_BGRA_UNORM:
		case GS_RG16:
			return 32;
		case GS_RGBA16:
		case GS_RGBA16F:
		case GS_RG32F:
			return 64;
		case GS_RGBA32F:
			return 128;
		case GS_UNKNOWN:
			return 0;
		}

		return 0;
	}

	uint32_t GrpahicsHelper::gs_get_total_levels(uint32_t width, uint32_t height, uint32_t depth)
	{
		uint32_t size = width > height ? width : height;
		size = size > depth ? size : depth;
		uint32_t num_levels = 1;

		while (size > 1) {
			size /= 2;
			num_levels++;
		}

		return num_levels;
	}

	DXGI_FORMAT GrpahicsHelper::ConvertGSZStencilFormat(gs_zstencil_format format)
	{
		switch (format) {
		case GS_ZS_NONE:
			return DXGI_FORMAT_UNKNOWN;
		case GS_Z16:
			return DXGI_FORMAT_D16_UNORM;
		case GS_Z24_S8:
			return DXGI_FORMAT_D24_UNORM_S8_UINT;
		case GS_Z32F:
			return DXGI_FORMAT_D32_FLOAT;
		case GS_Z32F_S8X24:
			return DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
		}

		return DXGI_FORMAT_UNKNOWN;
	}

	//////////////////////////////////////////////////////////////////////////

	bool GrpahicsHelper::screen_supports_hdr(GSDevice* device, HMONITOR hMonitor)
	{
		IDXGIFactory1* factory1 = device->factory_;
		if (!factory1->IsCurrent()) {
			device->InitFactory();
			factory1 = device->factory_;
			device->monitor_to_hdr_.clear();
		}

		for (const std::pair<HMONITOR, bool>& pair : device->monitor_to_hdr_) {
			if (pair.first == hMonitor)
				return pair.second;
		}

		ComPtr<IDXGIAdapter> adapter;
		ComPtr<IDXGIOutput> output;
		ComPtr<IDXGIOutput6> output6;
		for (UINT adapterIndex = 0; SUCCEEDED(factory1->EnumAdapters(adapterIndex, &adapter));
			++adapterIndex) {
			for (UINT outputIndex = 0; SUCCEEDED(adapter->EnumOutputs(outputIndex, &output));
				++outputIndex) {
				if (SUCCEEDED(output->QueryInterface(&output6))) {
					DXGI_OUTPUT_DESC1 desc1;
					if (SUCCEEDED(output6->GetDesc1(&desc1)) &&
						(desc1.Monitor == hMonitor)) {
						const bool hdr = desc1.ColorSpace ==
							DXGI_COLOR_SPACE_RGB_FULL_G2084_NONE_P2020;
						device->monitor_to_hdr_.emplace_back(hMonitor, hdr);
						return hdr;
					}
				}
			}
		}

		return false;
	}

	//static gs_color_space get_next_space(GSDevice *device, HWND hwnd)
	//{
	//	enum gs_color_space next_space = GS_CS_SRGB;
	//	const HMONITOR hMonitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
	//	if (hMonitor) {
	//		if (screen_supports_hdr(device, hMonitor))
	//			next_space = GS_CS_709_SCRGB;
	//	}
	//
	//	return next_space;
	//}

	gs_color_format GrpahicsHelper::get_swap_format_from_space(gs_color_space space,
		gs_color_format sdr_format)
	{
		return (space == GS_CS_709_SCRGB) ? GS_RGBA16F : sdr_format;
	}

	gs_color_space GrpahicsHelper::get_next_space(GSDevice* device, HWND hwnd)
	{
		enum gs_color_space next_space = GS_CS_SRGB;
		const HMONITOR hMonitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
		if (hMonitor) {
			if (screen_supports_hdr(device, hMonitor))
				next_space = GS_CS_709_SCRGB;
		}

		return next_space;
	}

	//gs_color_space GrpahicsHelper::make_swap_desc(GSDevice* device
	//	, DXGI_SWAP_CHAIN_DESC& desc
	//	, const swapchain_data& data
	//	, DXGI_SWAP_EFFECT effect, UINT flags)
	//{
	//	const HWND hwnd = (HWND)data.window_;
	//	const gs_color_space space = get_next_space(device, hwnd);
	//	const gs_color_format format = get_swap_format_from_space(space, data.format_);
	//
	//	memset(&desc, 0, sizeof(desc));
	//	desc.BufferDesc.Width = data.cx_;
	//	desc.BufferDesc.Height = data.cy_;
	//	desc.BufferDesc.Format = ConvertGSTextureFormatView(format);
	//	desc.SampleDesc.Count = 1;
	//	desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	//	desc.BufferCount = data.num_backbuffers_;
	//	desc.OutputWindow = hwnd;
	//	desc.Windowed = TRUE;
	//	desc.SwapEffect = effect;
	//	desc.Flags = flags;
	//
	//	return space;
	//}
	//static bool screen_supports_hdr(GSDevice* device, HMONITOR hMonitor)
	//{
	//	IDXGIFactory1 *factory1 = device->factory_;
	//	if (!factory1->IsCurrent())
	//	{
	//		device->InitFactory();
	//		factory1 = device->factory_;
	//		device->monitor_to_hdr_.clear();
	//	}
	//
	//	for (const std::pair<HMONITOR, bool> &pair : device->monitor_to_hdr_)
	//	{
	//		if (pair.first == hMonitor)
	//			return pair.second;
	//	}
	//
	//	ComPtr<IDXGIAdapter> adapter;
	//	ComPtr<IDXGIOutput> output;
	//	ComPtr<IDXGIOutput6> output6;
	//	for (UINT adapterIndex = 0; SUCCEEDED(factory1->EnumAdapters(adapterIndex, &adapter)); ++adapterIndex) {
	//		for (UINT outputIndex = 0; SUCCEEDED(adapter->EnumOutputs(outputIndex, &output)); ++outputIndex) {
	//			if (SUCCEEDED(output->QueryInterface(&output6)))
	//			{
	//				DXGI_OUTPUT_DESC1 desc1;
	//				if(SUCCEEDED(output6->GetDesc1(&desc1)) && (desc1.Monitor == hMonitor)) {
	//					const bool hdr = desc1.ColorSpace == DXGI_COLOR_SPACE_RGB_FULL_G2084_NONE_P2020;
	//					device->monitor_to_hdr_.emplace_back(hMonitor, hdr);
	//					return hdr;
	//				}
	//			}
	//		}
	//	}
	//
	//	return false;
	//}

	//gs_color_space GrpahicsHelper::get_next_space(GSDevice* device, HWND hwnd)
	//{
	//	enum gs_color_space next_space = GS_CS_SRGB;
	//	const HMONITOR hMonitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
	//	if (hMonitor) {
	//		if (screen_supports_hdr(device, hMonitor))
	//			next_space = GS_CS_709_SCRGB;
	//	}
	//
	//	return next_space;
	//}
	//
	//gs_color_format GrpahicsHelper::get_swap_format_from_space(gs_color_space space, gs_color_format sdr_format)
	//{
	//	return (space == GS_CS_709_SCRGB) ? GS_RGBA16F : sdr_format;
	//}

	gs_color_space GrpahicsHelper::make_swap_desc(GSDevice* device, DXGI_SWAP_CHAIN_DESC& desc,
		const swapchain_data& data, DXGI_SWAP_EFFECT effect,
		UINT flags)
	{
		const HWND hwnd = (HWND)data.window_;
		const gs_color_space space = get_next_space(device, hwnd);
		const gs_color_format format = get_swap_format_from_space(space, data.format_);

		memset(&desc, 0, sizeof(desc));
		desc.BufferDesc.Width = data.cx_;
		desc.BufferDesc.Height = data.cy_;
		desc.BufferDesc.Format = ConvertGSTextureFormatView(format);
		desc.SampleDesc.Count = 1;
		desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		desc.BufferCount = data.num_backbuffers_;
		desc.OutputWindow = hwnd;
		desc.Windowed = TRUE;
		desc.SwapEffect = effect;
		desc.Flags = flags;

		return space;
	}

	D3D11_PRIMITIVE_TOPOLOGY GrpahicsHelper::ConvertGSTopology(gs_draw_mode mode)
	{
		switch (mode) {
		case GS_POINTS:
			return D3D11_PRIMITIVE_TOPOLOGY_POINTLIST;
		case GS_LINES:
			return D3D11_PRIMITIVE_TOPOLOGY_LINELIST;
		case GS_LINESTRIP:
			return D3D11_PRIMITIVE_TOPOLOGY_LINESTRIP;
		case GS_TRIS:
			return D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
		case GS_TRISTRIP:
			return D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP;
		}

		return D3D11_PRIMITIVE_TOPOLOGY_POINTLIST;
	}

	//////////////////////////////////////////////////////////////////////////

	bool GrpahicsHelper::GetMonitorTarget(const MONITORINFOEX& info,
		DISPLAYCONFIG_TARGET_DEVICE_NAME& target)
	{
		bool found = false;

		UINT32 numPath, numMode;
		if (GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, &numPath, &numMode) ==
			ERROR_SUCCESS) {
			std::vector<DISPLAYCONFIG_PATH_INFO> paths(numPath);
			std::vector<DISPLAYCONFIG_MODE_INFO> modes(numMode);
			if (QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, &numPath, paths.data(), &numMode,
				modes.data(), nullptr) == ERROR_SUCCESS) {
				paths.resize(numPath);
				for (size_t i = 0; i < numPath; ++i) {
					const DISPLAYCONFIG_PATH_INFO& path = paths[i];

					DISPLAYCONFIG_SOURCE_DEVICE_NAME
						source;
					source.header.type = DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME;
					source.header.size = sizeof(source);
					source.header.adapterId = path.sourceInfo.adapterId;
					source.header.id = path.sourceInfo.id;
					if (DisplayConfigGetDeviceInfo(&source.header) == ERROR_SUCCESS &&
						wcscmp(info.szDevice, source.viewGdiDeviceName) == 0) {
						target.header.type =
							DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME;
						target.header.size = sizeof(target);
						target.header.adapterId = path.sourceInfo.adapterId;
						target.header.id = path.targetInfo.id;
						found = DisplayConfigGetDeviceInfo(&target.header) ==
							ERROR_SUCCESS;
						break;
					}
				}
			}
		}

		return found;
	}

	bool GrpahicsHelper::GetOutputDesc1(IDXGIOutput* const output, DXGI_OUTPUT_DESC1* desc1)
	{
		ComPtr<IDXGIOutput6> output6;
		HRESULT hr = output->QueryInterface(IID_PPV_ARGS(output6.Assign()));
		bool success = SUCCEEDED(hr);
		if (success) {
			hr = output6->GetDesc1(desc1);
			success = SUCCEEDED(hr);
			if (!success) {
				XLOG(LOG_WARNING, "IDXGIOutput6::GetDesc1 failed: 0x%08lX", hr);
			}
		}

		return success;
	}

	// Returns true if this is an integrated display panel e.g. the screen attached to tablets or laptops.
	bool GrpahicsHelper::IsInternalVideoOutput(
		const DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY VideoOutputTechnologyType)
	{
		switch (VideoOutputTechnologyType) {
		case DISPLAYCONFIG_OUTPUT_TECHNOLOGY_INTERNAL:
		case DISPLAYCONFIG_OUTPUT_TECHNOLOGY_DISPLAYPORT_EMBEDDED:
		case DISPLAYCONFIG_OUTPUT_TECHNOLOGY_UDI_EMBEDDED:
			return TRUE;

		default:
			return FALSE;
		}
	}

	// Note: Since an hmon can represent multiple monitors while in clone, this function as written will return
	//  the value for the internal monitor if one exists, and otherwise the highest clone-path priority.
	HRESULT GrpahicsHelper::GetPathInfo(_In_ PCWSTR pszDeviceName,
		_Out_ DISPLAYCONFIG_PATH_INFO* pPathInfo)
	{
		HRESULT hr = S_OK;
		UINT32 NumPathArrayElements = 0;
		UINT32 NumModeInfoArrayElements = 0;
		DISPLAYCONFIG_PATH_INFO* PathInfoArray = nullptr;
		DISPLAYCONFIG_MODE_INFO* ModeInfoArray = nullptr;

		do {
			// In case this isn't the first time through the loop, delete the buffers allocated
			delete[] PathInfoArray;
			PathInfoArray = nullptr;

			delete[] ModeInfoArray;
			ModeInfoArray = nullptr;

			hr = HRESULT_FROM_WIN32(GetDisplayConfigBufferSizes(
				QDC_ONLY_ACTIVE_PATHS, &NumPathArrayElements, &NumModeInfoArrayElements));
			if (FAILED(hr)) {
				break;
			}

			PathInfoArray = new (std::nothrow) DISPLAYCONFIG_PATH_INFO[NumPathArrayElements];
			if (PathInfoArray == nullptr) {
				hr = E_OUTOFMEMORY;
				break;
			}

			ModeInfoArray = new (std::nothrow)
				DISPLAYCONFIG_MODE_INFO[NumModeInfoArrayElements];
			if (ModeInfoArray == nullptr) {
				hr = E_OUTOFMEMORY;
				break;
			}

			hr = HRESULT_FROM_WIN32(QueryDisplayConfig(
				QDC_ONLY_ACTIVE_PATHS, &NumPathArrayElements, PathInfoArray,
				&NumModeInfoArrayElements, ModeInfoArray, nullptr));
		} while (hr == HRESULT_FROM_WIN32(ERROR_INSUFFICIENT_BUFFER));

		INT DesiredPathIdx = -1;

		if (SUCCEEDED(hr)) {
			// Loop through all sources until the one which matches the 'monitor' is found.
			for (UINT PathIdx = 0; PathIdx < NumPathArrayElements; ++PathIdx) {
				DISPLAYCONFIG_SOURCE_DEVICE_NAME SourceName = {};
				SourceName.header.type = DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME;
				SourceName.header.size = sizeof(SourceName);
				SourceName.header.adapterId = PathInfoArray[PathIdx].sourceInfo.adapterId;
				SourceName.header.id = PathInfoArray[PathIdx].sourceInfo.id;

				hr = HRESULT_FROM_WIN32(DisplayConfigGetDeviceInfo(&SourceName.header));
				if (SUCCEEDED(hr)) {
					if (wcscmp(pszDeviceName, SourceName.viewGdiDeviceName) == 0) {
						// Found the source which matches this hmonitor. The paths are given in path-priority order
						// so the first found is the most desired, unless we later find an internal.
						if (DesiredPathIdx == -1 ||
							IsInternalVideoOutput(
								PathInfoArray[PathIdx]
								.targetInfo.outputTechnology)) {
							DesiredPathIdx = PathIdx;
						}
					}
				}
			}
		}

		if (DesiredPathIdx != -1) {
			*pPathInfo = PathInfoArray[DesiredPathIdx];
		}
		else {
			hr = E_INVALIDARG;
		}

		delete[] PathInfoArray;
		PathInfoArray = nullptr;

		delete[] ModeInfoArray;
		ModeInfoArray = nullptr;

		return hr;
	}

	// Overloaded function accepts an HMONITOR and converts to DeviceName
	HRESULT GrpahicsHelper::GetPathInfo(HMONITOR hMonitor, _Out_ DISPLAYCONFIG_PATH_INFO* pPathInfo)
	{
		HRESULT hr = S_OK;

		// Get the name of the 'monitor' being requested
		MONITORINFOEXW ViewInfo;
		RtlZeroMemory(&ViewInfo, sizeof(ViewInfo));
		ViewInfo.cbSize = sizeof(ViewInfo);
		if (!GetMonitorInfoW(hMonitor, &ViewInfo)) {
			// Error condition, likely invalid monitor handle, could log error
			hr = HRESULT_FROM_WIN32(GetLastError());
		}

		if (SUCCEEDED(hr)) {
			hr = GetPathInfo(ViewInfo.szDevice, pPathInfo);
		}

		return hr;
	}

	ULONG GrpahicsHelper::GetSdrWhiteNits(HMONITOR monitor)
	{
		ULONG nits = 0;

		DISPLAYCONFIG_PATH_INFO info;
		if (SUCCEEDED(GetPathInfo(monitor, &info))) {
			const DISPLAYCONFIG_PATH_TARGET_INFO& targetInfo = info.targetInfo;

			DISPLAYCONFIG_SDR_WHITE_LEVEL level;
			DISPLAYCONFIG_DEVICE_INFO_HEADER& header = level.header;
			header.type = DISPLAYCONFIG_DEVICE_INFO_GET_SDR_WHITE_LEVEL;
			header.size = sizeof(level);
			header.adapterId = targetInfo.adapterId;
			header.id = targetInfo.id;
			if (DisplayConfigGetDeviceInfo(&header) == ERROR_SUCCESS)
				nits = (level.SDRWhiteLevel * 80) / 1000;
		}

		return nits;
	}

	void GrpahicsHelper::LogAdapterMonitors(IDXGIAdapter1* adapter)
	{
		UINT i;
		ComPtr<IDXGIOutput> output;

		for (i = 0; adapter->EnumOutputs(i, &output) == S_OK; ++i) {
			DXGI_OUTPUT_DESC desc;
			if (FAILED(output->GetDesc(&desc)))
				continue;

			unsigned refresh = 0;

			bool target_found = false;
			DISPLAYCONFIG_TARGET_DEVICE_NAME target;

			MONITORINFOEX info;
			info.cbSize = sizeof(info);
			if (GetMonitorInfo(desc.Monitor, &info)) {
				target_found = GetMonitorTarget(info, target);

				DEVMODE mode;
				mode.dmSize = sizeof(mode);
				mode.dmDriverExtra = 0;
				if (EnumDisplaySettings(info.szDevice, ENUM_CURRENT_SETTINGS, &mode)) {
					refresh = mode.dmDisplayFrequency;
				}
			}

			if (!target_found) {
				target.monitorFriendlyDeviceName[0] = 0;
			}

			DXGI_COLOR_SPACE_TYPE type = DXGI_COLOR_SPACE_RGB_FULL_G22_NONE_P709;
			FLOAT min_luminance = 0.f;
			FLOAT max_luminance = 0.f;
			FLOAT max_full_frame_luminance = 0.f;
			DXGI_OUTPUT_DESC1 desc1;
			if (GetOutputDesc1(output, &desc1)) {
				type = desc1.ColorSpace;
				min_luminance = desc1.MinLuminance;
				max_luminance = desc1.MaxLuminance;
				max_full_frame_luminance = desc1.MaxFullFrameLuminance;
			}

			const char* space = "Unknown";
			switch (type) {
			case DXGI_COLOR_SPACE_RGB_FULL_G22_NONE_P709:
				space = "RGB_FULL_G22_NONE_P709";
				break;
			case DXGI_COLOR_SPACE_RGB_FULL_G2084_NONE_P2020:
				space = "RGB_FULL_G2084_NONE_P2020";
				break;
			default:
				XLOG(LOG_WARNING, "Unexpected DXGI_COLOR_SPACE_TYPE: %u", (unsigned)type);
			}

			const RECT& rect = desc.DesktopCoordinates;
			const ULONG nits = GetSdrWhiteNits(desc.Monitor);
			XLOG(LOG_INFO,
				"\t  output %u:\n"
				"\t    name=%ls\n"
				"\t    pos={%d, %d}\n"
				"\t    size={%d, %d}\n"
				"\t    attached=%s\n"
				"\t    refresh=%u\n"
				"\t    space=%s\n"
				"\t    sdr_white_nits=%lu\n"
				"\t    nit_range=[min=%f, max=%f, max_full_frame=%f]",
				i, target.monitorFriendlyDeviceName, rect.left, rect.top,
				rect.right - rect.left, rect.bottom - rect.top,
				desc.AttachedToDesktop ? "true" : "false", refresh, space, nits, min_luminance,
				max_luminance, max_full_frame_luminance);
		}
	}
	long GrpahicsHelper::LogD3DAdapters()
	{
		ComPtr<IDXGIFactory1> factory;
		ComPtr<IDXGIAdapter1> adapter;
		HRESULT hr = S_OK;
		UINT i;

		XLOG(LOG_INFO, "Available Video Adapters: ");

		do {
			hr = CreateDXGIFactory1(IID_PPV_ARGS(&factory));
			if (FAILED(hr)) {
				XLOG("Failed to create DXGIFactory", hr);
				break;
			}

			for (i = 0; factory->EnumAdapters1(i, adapter.Assign()) == S_OK; ++i) {
				DXGI_ADAPTER_DESC desc;
				char name[512] = "";

				hr = adapter->GetDesc(&desc);
				if (FAILED(hr))
					continue;

				/* ignore Microsoft's 'basic' renderer' */
				if (desc.VendorId == 0x1414 && desc.DeviceId == 0x8c)
					continue;

				//os_wcs_to_utf8(desc.Description, 0, name, sizeof(name));
				//XLOG(LOG_INFO, "\tAdapter %u: %s", i, name);
				//XLOG(LOG_INFO, "\t  Dedicated VRAM: %u", desc.DedicatedVideoMemory);
				//XLOG(LOG_INFO, "\t  Shared VRAM:    %u", desc.SharedSystemMemory);
				//XLOG(LOG_INFO, "\t  PCI ID:         %x:%x", desc.VendorId, desc.DeviceId);

				/* driver version */
				LARGE_INTEGER umd;
				hr = adapter->CheckInterfaceSupport(__uuidof(IDXGIDevice), &umd);
				if (SUCCEEDED(hr)) {
					const uint64_t version = umd.QuadPart;
					const uint16_t aa = (version >> 48) & 0xffff;
					const uint16_t bb = (version >> 32) & 0xffff;
					const uint16_t ccccc = (version >> 16) & 0xffff;
					const uint16_t ddddd = version & 0xffff;
					//XLOG(LOG_INFO, "\t  Driver Version: %" PRIu16 ".%" PRIu16 ".%" PRIu16 ".%" PRIu16, aa, bb, ccccc, ddddd);
				}
				else {
					//XLOG(LOG_INFO, "\t  Driver Version: Unknown (0x%X)", (unsigned)hr);
				}

				LogAdapterMonitors(adapter);
			}
		} while (false);
		return hr;
	}

}