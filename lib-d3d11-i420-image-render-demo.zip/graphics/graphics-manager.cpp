//#include "graphics-manager.h"
//#include "lib-d3d11/render/device-manager.h"
//#include "lib-d3d11/config/d3d11-configuration.h"
//
//namespace lib_d3d
//{
//
//	GraphicsManager::GraphicsManager()
//	{
//
//	}
//
//	GraphicsManager::~GraphicsManager()
//	{
//
//	}
//
//	Graphics* GraphicsManager::GetGraphics(bool bCreate/* = true*/)
//	{
//		Graphics* result = nullptr;
//		auto id = std::this_thread::get_id();
//
//		nbase::NAutoLock lock(&lock_);
//
//		auto it = graphics_.find(id);
//
//		do
//		{
//			if (it == graphics_.end() && bCreate)
//			{
//				auto graphic = new Graphics();
//				LUID uid = D3d11ConfigurationInstance::GetInstance()->GetAdapterId();
//				auto hr = graphic->Create(uid);
//
//				if (hr) break;
//
//				EffectManager* effectMgr = new EffectManager();
//				hr = effectMgr->Init(graphic);
//				if (hr) break;
//
//				result = graphic;
//
//				// new
//				graphics_[id] = graphic;
//				effects_[id] = effectMgr;
//			}
//
//			if (it != graphics_.end())
//			{
//				result = it->second;
//			}
//		} while (false);
//
//		return result;
//	}
//
//	int GraphicsManager::DestroyGraphics()
//	{
//		auto id = std::this_thread::get_id();
//		nbase::NAutoLock lock(&lock_);
//
//		auto it = graphics_.find(id);
//		if (it != graphics_.end())
//		{
//			auto graphic = it->second;
//
//			SAFE_DELETE(graphic);
//
//			graphics_.erase(it);
//		}
//
//		return 0;
//	}
//
//	EffectManager* GraphicsManager::GetEffectManger()
//	{
//		EffectManager* result = nullptr;
//		auto id = std::this_thread::get_id();
//
//		nbase::NAutoLock lock(&lock_);
//
//		auto it = effects_.find(id);
//
//		if (it != effects_.end())
//		{
//			result = it->second;
//		}
//
//		return result;
//	}
//}