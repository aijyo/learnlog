#pragma once
#ifndef __X_GRAPHICS_EVENT_H__
#define __X_GRAPHICS_EVENT_H__

#include <d3d11.h>

#include "lib-d3d11/d3d-common/lib-common.h"
namespace lib_d3d {
	class LIB_EXPORT IGSEventListener {
	public:
		long OnDeviceCreated(ID3D11Device* pd3dDevice,
			const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext);
		long OnDeviceDestroy(void* pUserContext);
		long OnDeviceRemoved(void* pUserContext);

		long OnSwapChainResized(ID3D11Device* pd3dDevice, IDXGISwapChain* pSwapChain,
			const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc,
			void* pUserContext);
		long onSwapChainReleasing(void* pUserContext);
		long OnFrameRender(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pd3dImmediateContext,
			double fTime, float fElapsedTime, void* pUserContext);
	};

}

#endif