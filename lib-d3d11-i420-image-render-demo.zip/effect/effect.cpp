//#include "effect.h"
//#include "basic/render-states.h"
//#include <DirectXColors.h>
//#include "lib-d3d11/render/thread/render-loop.h"
//
//namespace lib_d3d {
//Effect::Effect(Graphics *graphics)
//	: graphics_(graphics), m_pass(nullptr), pHelper_(nullptr), type_(EffectType::kNull)
//{
//}
//
//Effect::~Effect() {}
//long Effect::Create(EffectType type, std::shared_ptr<IEffectPass> pass)
//{
//	HRESULT hr = S_OK;
//	set_type(type);
//	m_pass = pass;
//	pHelper_ = pass->GetEffectHelper();
//	Rebuild();
//	return hr;
//}
//
//long Effect::Destory()
//{
//	HRESULT hr = S_OK;
//	Release();
//	return hr;
//}
//
//long Effect::Rebuild()
//{
//	HRESULT hr = S_OK;
//
//	return hr;
//}
//
//long Effect::Release()
//{
//	HRESULT hr = S_OK;
//	m_pass = nullptr;
//	pHelper_ = nullptr;
//	m_pVertexInputLayout.Clear();
//	set_type(EffectType::kNull);
//	return hr;
//}
//
////
//// IEffectTransform
//
//void Effect::SetVertexInput(x_util::win32::ComPtr<ID3D11InputLayout> layout,
//			    std::vector<D3D11_INPUT_ELEMENT_DESC> desc)
//{
//	m_pVertexInputLayout = layout;
//	vertex_config_.SetInputDesc(desc);
//}
//
//void Effect::SetVertexBuffer(GSVertexBufferPtr buf)
//{
//	vertexBuffer_ = buf;
//}
//
//void Effect::SetIndexBuffer(GSIndexBufferPtr buf)
//{
//	indexBuffer_ = buf;
//}
//
//void Effect::SetWorldMatrix(matrix4 W)
//{
//	m_World = W;
//}
//
//void Effect::SetViewMatrix(matrix4 V)
//{
//	m_View = V;
//}
//
//void Effect::SetProjMatrix(matrix4 P)
//{
//	m_Proj = P;
//}
//
//void Effect::SetColorCoef(matrix4 C)
//{
//	m_colorCoef = C;
//}
//
//void Effect::SetImageInfo(const vec4 &info)
//{
//	pHelper_->GetConstantBufferVariable("g_ImageInfo")->SetFloatVector(4, (FLOAT *)&info);
//}
//
//void Effect::SetShaderResource(const std::string &name, ID3D11ShaderResourceView *tex)
//{
//	pHelper_->SetShaderResourceByName(name.c_str(), tex);
//}
//
//// Ĭ��״̬������
//void Effect::UploadParams(ID3D11DeviceContext *deviceContext)
//{
//	//uint32_t flags = GS_CLEAR_COLOR | GS_CLEAR_DEPTH | GS_CLEAR_STENCIL;
//	//vec4 color;
//	//DirectX::XMStoreFloat4(&color, DirectX::Colors::MidnightBlue.v);
//	//graphics_->Clear(flags, color, 1.0, 0);
//
//	deviceContext->IASetInputLayout(m_pVertexInputLayout.Get());
//	deviceContext->IASetPrimitiveTopology(m_CurrTopology);
//
//	auto device = graphics_->device_;
//	auto pd3dImmediateContext = device->context_;
//	// Update variables that change once per frame
//	//
//	device->LoadVertexBufferData(vertexBuffer_, vertex_config_);
//	device->LoadIndexBufferData(indexBuffer_);
//}
//
//void Effect::SetTextureUsed(bool isUsed)
//{
//	pHelper_->GetConstantBufferVariable("g_TextureUsed")->SetSInt(isUsed);
//}
//
//// Ӧ�ó�����������������Դ�ı��
//void Effect::Apply(ID3D11DeviceContext *context)
//{
//	matrix4 &W = m_World;
//	matrix4 &V = m_View;
//	matrix4 &P = m_Proj;
//	matrix4 &C = m_colorCoef;
//
//	pHelper_->GetConstantBufferVariable("g_World")->SetFloatMatrix(4, 4, (FLOAT *)&W.m);
//	pHelper_->GetConstantBufferVariable("g_ColorCoef")->SetFloatMatrix(4, 4, (FLOAT *)&C.m);
//	pHelper_->GetConstantBufferVariable("g_View")->SetFloatMatrix(4, 4, (FLOAT *)&V.m);
//	pHelper_->GetConstantBufferVariable("g_Proj")->SetFloatMatrix(4, 4, (FLOAT *)&P.m);
//
//	uint32_t start_vert = 0;
//	uint32_t num_verts = 0;
//	auto &device = graphics_->device_;
//	auto &pd3dImmediateContext = device->context_;
//	UploadParams(pd3dImmediateContext);
//
//	m_pass->Apply(pd3dImmediateContext);
//
//	if (indexBuffer_) {
//		if (num_verts == 0)
//			num_verts = (uint32_t)device->curIndexBuffer_->PointNum();
//		pd3dImmediateContext->DrawIndexed(num_verts, start_vert, 0);
//	} else {
//		if (num_verts == 0)
//			num_verts = (uint32_t)device->curVertexBuffer_->PointsNum();
//		pd3dImmediateContext->Draw(num_verts, start_vert);
//	}
//}
//}