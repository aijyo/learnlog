//#pragma once
//#ifndef __X_EFFECT_H__
//
//#include "./IEffect.h"
//#include "lib-d3d11/d3d11/d3d11-vertexbuffer.h"
//#include "lib-d3d11/d3d11/d3d11-indexbuffer.h"
//#include "lib-d3d11/graphics/graphics.h"
//
//#include "d3d-common/lib-common.h"
//#include "./effect-helper.h"
//#include "./effect-info.h"
//
//namespace lib_d3d {
//class RenderLoop;
//
//
//// effect <==> pass
//class LIB_EXPORT Effect : public IEffect,
//			  public IEffectTransform /*, public IEffectFrame*/
//{
//public:
//	//// vs && ps file
//	using EffectShaderVec = std::vector<EffectShaderInfo>;
//
//public:
//	Effect(Graphics *graphics);
//	~Effect();
//
//	virtual long Create(EffectType type, std::shared_ptr<IEffectPass> pass);
//	virtual long Destory();
//
//	long Rebuild();
//	long Release();
//
//	//
//	// IEffectTransform
//	//
//	void SetVertexInput(x_util::win32::ComPtr<ID3D11InputLayout> layout,
//			    std::vector<D3D11_INPUT_ELEMENT_DESC> desc);
//	void SetVertexBuffer(GSVertexBufferPtr buf);
//	void SetIndexBuffer(GSIndexBufferPtr buf);
//	void SetWorldMatrix(matrix4 W);
//	void SetViewMatrix(matrix4 V);
//	void SetProjMatrix(matrix4 P);
//	void SetColorCoef(matrix4 C);
//	//(width, height, 1.0/width, 1.0/height)
//	void SetImageInfo(const vec4 &info);
//
//	void SetShaderResource(const std::string &name, ID3D11ShaderResourceView *tex);
//
//	//
//	// IEffectTextureDiffuse
//	//
//
//	//void SetFrame(VideoFrame frame) override;
//
//	// Ĭ��״̬������
//	virtual void UploadParams(ID3D11DeviceContext *deviceContext);
//
//	void SetTextureUsed(bool isUsed);
//
//	//void SetEyePos(const matrix3& eyePos);
//
//	//
//	// IEffect
//	//
//
//	// Ӧ�ó�����������������Դ�ı��
//	void Apply(ID3D11DeviceContext *deviceContext);
//
//protected:
//	X_PARAM(EffectType, type);
//	X_POINTER(Graphics *, graphics);
//
//	EffectHelper *pHelper_;
//	ComPtr<ID3D11InputLayout> m_pVertexInputLayout;
//	D3D11_PRIMITIVE_TOPOLOGY m_CurrTopology = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
//
//	VertexShaderConfig vertex_config_;
//	GSVertexBufferPtr vertexBuffer_;
//	GSIndexBufferPtr indexBuffer_;
//
//	matrix4 m_World{}, m_View{}, m_Proj{}, m_colorCoef{};
//
//	std::shared_ptr<IEffectPass> m_pass;
//};
//}
//
//#endif // !__X_EFFECT_H__
