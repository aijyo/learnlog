#pragma once

#include <d3d11.h>
#include <dxgi1_2.h>
#include <d3dcompiler.h>
#include <wrl/client.h>
#include <cstdint>
#include <vector>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")


using Microsoft::WRL::ComPtr;

class D3D11VideoRenderer
{
public:
	D3D11VideoRenderer(HWND hwnd);
	~D3D11VideoRenderer();

	void SetFrame(int width, int height,
		const uint8_t* yPlane,
		const uint8_t* uPlane,
		const uint8_t* vPlane);

	void Render();

private:
	void InitializeDeviceAndSwapChain(HWND hwnd);
	void CreateShaders();
	void RecreateTextures();

	ComPtr<ID3D11Device> device_;
	ComPtr<ID3D11DeviceContext> context_;
	ComPtr<IDXGISwapChain> swapChain_;
	ComPtr<ID3D11RenderTargetView> rtv_;

	ComPtr<ID3D11VertexShader> vertexShader_;
	ComPtr<ID3D11PixelShader> pixelShader_;
	ComPtr<ID3D11InputLayout> inputLayout_;
	ComPtr<ID3D11SamplerState> sampler_;

	ComPtr<ID3D11Texture2D> texY_;
	ComPtr<ID3D11Texture2D> texU_;
	ComPtr<ID3D11Texture2D> texV_;
	ComPtr<ID3D11ShaderResourceView> srvY_;
	ComPtr<ID3D11ShaderResourceView> srvU_;
	ComPtr<ID3D11ShaderResourceView> srvV_;

	int frameW_ = 0;
	int frameH_ = 0;
	bool needRealloc_ = false;

	std::vector<uint8_t> yData_;
	std::vector<uint8_t> uData_;
	std::vector<uint8_t> vData_;
};
