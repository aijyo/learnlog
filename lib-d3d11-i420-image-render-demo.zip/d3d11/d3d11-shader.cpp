#include "./d3d11-shader.h"

#include <fstream>

#include "d3d11-device.h"
namespace lib_d3d {
using ShaderData = std::vector<uint8_t>;
static std::shared_ptr<ShaderData> FileLoader(const std::string &shaderFileName)
{
	std::ifstream inputStream;
	std::shared_ptr<ShaderData> ptrShaderData = std::shared_ptr<ShaderData>();

	inputStream.open(shaderFileName.c_str(), std::ios::binary);

	if (inputStream.fail()) {
		XLOG(LOG_WARNING, "File not found, file name:%ls", shaderFileName.c_str());
		inputStream.close();

		return NULL;
	}

	inputStream.seekg(0, std::ios::end);
	DWORD readSize = (DWORD)inputStream.tellg();

	ptrShaderData->resize(readSize);

	inputStream.seekg(0, std::ios::beg);
	inputStream.read((char *)(ptrShaderData->data()), readSize);

	if (inputStream.fail()) {
		XLOG(LOG_WARNING, "File i/o error, file name:%ls", shaderFileName.c_str());
		inputStream.close();
		ptrShaderData->clear();

		return NULL;
	}

	return ptrShaderData;
}

void GSVertexShader::GetBuffersExpected(const vector<D3D11_INPUT_ELEMENT_DESC> &inputs)
{
	for (size_t i = 0; i < inputs.size(); i++) {
		const D3D11_INPUT_ELEMENT_DESC &input = inputs[i];
		if (strcmp(input.SemanticName, "NORMAL") == 0)
			config.hasNormals_ = true;
		else if (strcmp(input.SemanticName, "TANGENT") == 0)
			config.hasTangents_ = true;
		else if (strcmp(input.SemanticName, "COLOR") == 0)
			config.hasColors_ = true;
		else if (strcmp(input.SemanticName, "TEXCOORD") == 0)
			config.nTexUnits_++;
	}
}

GSVertexShader::GSVertexShader(GSDevice *device, const string &file,
			       const vector<uint8_t> &inputdata, const D3D11_BUFFER_DESC &desc,
			       const vector<D3D11_INPUT_ELEMENT_DESC> &layout)
	: GSShader(device, E_GSType::kvertex_shader, GS_SHADER_VERTEX, desc, inputdata),
	  shader_file_(file)
{
	config.hasNormals_ = false;
	config.hasColors_ = false;
	config.hasTangents_ = false;
	config.nTexUnits_ = 0;
	config.layoutDesc_ = layout;
}

int GSVertexShader::SetInputLayoutDesc(const vector<D3D11_INPUT_ELEMENT_DESC> &layout)
{
	config.layoutDesc_ = layout;
	return 0;
}

long GSVertexShader::Create()
{
	HRESULT result = S_OK;
	ComPtr<ID3D10Blob> shaderBlob;
	string outputString;
	BuildConstantBuffer();

	auto dataPtr = FileLoader(shader_file_);
	if (dataPtr) {
		shaderData_ = std::move(*dataPtr);
		dataPtr = nullptr;
	}
	do {
		result = device_->device_->CreateVertexShader(
			shaderData_.data(), shaderData_.size(), NULL, shader_.Assign());
		if (FAILED(result)) {
			device_->SetLastError(result);
			XLOG("Failed to create vertex shader", result);
			break;
		}

		const UINT layoutSize = (UINT)config.layoutDesc_.size();
		if (layoutSize > 0) {
			result = device_->device_->CreateInputLayout(
				config.layoutDesc_.data(), (UINT)layoutSize, shaderData_.data(),
				shaderData_.size(), layout_.Assign());
			if (FAILED(result)) {
				device_->SetLastError(result);
				XLOG("Failed to create input layout", result);
				break;
			}
		}
	} while (false);

	//viewProj_ = gs_shader_get_param_by_name(this, "ViewProj");
	//world_ = gs_shader_get_param_by_name(this, "World");
	return result;
}
long GSVertexShader::Destroy()
{
	HRESULT result = S_OK;
	if (device_->lastVertexShader_ == this)
		device_->lastVertexShader_ = nullptr;
	return result;
}

long GSVertexShader::Rebuild(ID3D11Device *dev)
{
	HRESULT hr = S_OK;
	do {
		hr = dev->CreateVertexShader(shaderData_.data(), shaderData_.size(), nullptr,
					     &shader_);
		if (FAILED(hr)) {
			XLOG("Failed to create vertex shader", hr);
			break;
		}

		const UINT layoutSize = (UINT)config.layoutDesc_.size();
		if (layoutSize > 0) {
			hr = dev->CreateInputLayout(config.layoutDesc_.data(), layoutSize,
						    shaderData_.data(), shaderData_.size(),
						    &layout_);
			if (FAILED(hr)) {
				XLOG("Failed to create input layout", hr);
				break;
			}
		}

		if (constantSize_) {
			hr = dev->CreateBuffer(&bufDesc_, NULL, &constants_);
			if (FAILED(hr)) {
				XLOG("Failed to create constant buffer", hr);
				break;
			}
		}
	} while (false);
	return hr;
}

GSPixelShader::GSPixelShader(GSDevice *device, const string &file, const D3D11_BUFFER_DESC &desc,
			     const vector<uint8_t> &inputdata)
	: GSShader(device, E_GSType::kpixel_shader, GS_SHADER_PIXEL, desc, inputdata),
	  shader_file_(file)
{
}

long GSPixelShader::Create()
{

	HRESULT result = S_OK;

	auto dataPtr = FileLoader(shader_file_);
	if (dataPtr) {
		shaderData_ = std::move(*dataPtr);
		dataPtr = nullptr;
	}
	do {
		result = device_->device_->CreatePixelShader(shaderData_.data(), shaderData_.size(),
							     NULL, shader_.Assign());
		if (FAILED(result)) {
			device_->SetLastError(result);
			XLOG("Failed to create pixel shader", result);
			break;
		}

	} while (false);
	return result;
}

long GSPixelShader::Destroy()
{
	HRESULT result = S_OK;

	return result;
}

long GSPixelShader::Rebuild(ID3D11Device *dev)
{
	HRESULT hr = S_OK;
	do {
		hr = dev->CreatePixelShader(shaderData_.data(), shaderData_.size(), nullptr,
					    &shader_);
		if (FAILED(hr)) {
			XLOG("Failed to create pixel shader", hr);
			break;
		}

		if (constantSize_) {
			hr = dev->CreateBuffer(&bufDesc_, NULL, &constants_);
			if (FAILED(hr)) {
				XLOG("Failed to create constant buffer", hr);
				break;
			}
		}
	} while (false);

	return hr;
}
//////////////////////////////////////////////////////////////////////////
//
GSShader::GSShader(GSDevice *device, E_GSType obj_type, E_GSShaderType type,
		   const D3D11_BUFFER_DESC &desc, const vector<uint8_t> &inputdata)
	: GSObject(device, obj_type), type_(type), constantSize_(0), constData_(inputdata)
{
	bufDesc_ = desc;
	//memcpy((void*)&bufDesc_, (void*)&desc, sizeof(D3D11_BUFFER_DESC));
	//BuildConstantBuffer();
}

GSShader::~GSShader() {}

long GSShader::Create()
{
	return S_OK;
}

long GSShader::Destroy()
{
	HRESULT result = S_OK;
	if (device_->lastVertexShader_ == this)
		device_->lastVertexShader_ = nullptr;
	return result;
}

long GSShader::BuildConstantBuffer()
{
	HRESULT result = device_->device_->CreateBuffer(&bufDesc_, NULL, constants_.Assign());
	if (FAILED(result))
		XLOG("Failed to create constant buffer", result);

	return result;
}

inline void GSShader::UpdateParam(const vector<uint8_t> &constData)
{
	constData_ = constData;
}

long GSShader::UploadParams()
{
	D3D11_MAPPED_SUBRESOURCE map;
	HRESULT hr = S_OK;

	do {
		hr = device_->context_->Map(constants_, 0, D3D11_MAP_WRITE_DISCARD, 0, &map);
		if (FAILED(hr)) {
			XLOG("Could not lock constant buffer", hr);
			break;
		}

		memcpy(map.pData, constData_.data(), constData_.size());
		device_->context_->Unmap(constants_, 0);
	} while (false);

	return S_OK;
}
//
//
//gs_sparam_t *gs_shader_get_viewproj_matrix(const gs_shader_t *shader)
//{
//	if (shader->type != GS_SHADER_VERTEX)
//		return NULL;
//
//	return static_cast<const gs_vertex_shader *>(shader)->viewProj;
//}
//
//gs_sparam_t *gs_shader_get_world_matrix(const gs_shader_t *shader)
//{
//	if (shader->type != GS_SHADER_VERTEX)
//		return NULL;
//
//	return static_cast<const gs_vertex_shader *>(shader)->world;
//}
//
//void gs_shader_get_param_info(const gs_sparam_t *param, struct gs_shader_param_info *info)
//{
//	if (!param)
//		return;
//
//	info->name = param->name.c_str();
//	info->type = param->type;
//}
//
//static inline void shader_setval_inline(gs_shader_param *param, const void *data, size_t size)
//{
//	assert(param);
//	if (!param)
//		return;
//
//	bool size_changed = param->curValue.size() != size;
//	if (size_changed)
//		param->curValue.resize(size);
//
//	if (size_changed || memcmp(param->curValue.data(), data, size) != 0) {
//		memcpy(param->curValue.data(), data, size);
//		param->changed = true;
//	}
//}
//
//void gs_shader_set_bool(gs_sparam_t *param, bool val)
//{
//	int b_val = (int)val;
//	shader_setval_inline(param, &b_val, sizeof(int));
//}
//
//void gs_shader_set_float(gs_sparam_t *param, float val)
//{
//	shader_setval_inline(param, &val, sizeof(float));
//}
//
//void gs_shader_set_int(gs_sparam_t *param, int val)
//{
//	shader_setval_inline(param, &val, sizeof(int));
//}
//
//void gs_shader_set_matrix3(gs_sparam_t *param, const struct matrix3 *val)
//{
//	struct matrix4 mat;
//	matrix4_from_matrix3(&mat, val);
//	shader_setval_inline(param, &mat, sizeof(matrix4));
//}
//
//void gs_shader_set_matrix4(gs_sparam_t *param, const struct matrix4 *val)
//{
//	shader_setval_inline(param, val, sizeof(matrix4));
//}
//
//void gs_shader_set_vec2(gs_sparam_t *param, const struct vec2 *val)
//{
//	shader_setval_inline(param, val, sizeof(vec2));
//}
//
//void gs_shader_set_vec3(gs_sparam_t *param, const struct vec3 *val)
//{
//	shader_setval_inline(param, val, sizeof(float) * 3);
//}
//
//void gs_shader_set_vec4(gs_sparam_t *param, const struct vec4 *val)
//{
//	shader_setval_inline(param, val, sizeof(vec4));
//}
//
//void gs_shader_set_texture(gs_sparam_t *param, gs_texture_t *val)
//{
//	shader_setval_inline(param, &val, sizeof(gs_texture_t *));
//}
//
//void gs_shader_set_val(gs_sparam_t *param, const void *val, size_t size)
//{
//	shader_setval_inline(param, val, size);
//}
//
//void gs_shader_set_default(gs_sparam_t *param)
//{
//	if (param->defaultValue.size())
//		shader_setval_inline(param, param->defaultValue.data(), param->defaultValue.size());
//}
//
//void gs_shader_set_next_sampler(gs_sparam_t *param, gs_samplerstate_t *sampler)
//{
//	param->nextSampler = sampler;
//}

}
