#include "d3d11-texture3d.h"
#include "d3d11-device.h"
#include "lib-d3d11/graphics/d3d11-helper.h"

namespace lib_d3d {

	void GSTexture3D::InitSRD(vector<D3D11_SUBRESOURCE_DATA>& srd)
	{
		uint32_t rowSizeBits = width * GrpahicsHelper::gs_get_format_bpp(format_);
		uint32_t sliceSizeBytes = height * rowSizeBits / 8;
		uint32_t actual_levels = levels_;

		if (!actual_levels)
			actual_levels = GrpahicsHelper::gs_get_total_levels(width, height, depth);

		uint32_t newRowSize = rowSizeBits / 8;
		uint32_t newSlizeSize = sliceSizeBytes;

		for (uint32_t level = 0; level < actual_levels; ++level) {
			D3D11_SUBRESOURCE_DATA newSRD;
			newSRD.pSysMem = data_[level].data();
			newSRD.SysMemPitch = newRowSize;
			newSRD.SysMemSlicePitch = newSlizeSize;
			srd.push_back(newSRD);

			newRowSize /= 2;
			newSlizeSize /= 4;
		}
	}

	void GSTexture3D::BackupTexture(const uint8_t* const* data)
	{
		this->data_.resize(levels_);

		uint32_t w = width;
		uint32_t h = height;
		uint32_t d = depth;
		const uint32_t bbp = GrpahicsHelper::gs_get_format_bpp(format_);

		for (uint32_t i = 0; i < levels_; i++) {
			if (!data[i])
				break;

			const uint32_t texSize = bbp * w * h * d / 8;
			this->data_[i].resize(texSize);

			vector<uint8_t>& subData = this->data_[i];
			memcpy(&subData[0], data[i], texSize);

			if (w > 1)
				w /= 2;
			if (h > 1)
				h /= 2;
			if (d > 1)
				d /= 2;
		}
	}

	void GSTexture3D::GetSharedHandle(IDXGIResource* dxgi_res)
	{
		HANDLE handle;
		HRESULT hr;

		hr = dxgi_res->GetSharedHandle(&handle);
		if (FAILED(hr)) {
			XLOG(LOG_WARNING,
				"GetSharedHandle: Failed to "
				"get shared handle: %08lX",
				hr);
		}
		else {
			sharedHandle = handle;
		}
	}

	void GSTexture3D::RebuildSharedTextureFallback()
	{
		static const gs_color_format format = GS_BGRA;
		static const DXGI_FORMAT dxgi_format_resource = ConvertGSTextureFormatResource(format);
		static const DXGI_FORMAT dxgi_format_view = ConvertGSTextureFormatView(format);
		static const DXGI_FORMAT dxgi_format_view_linear = ConvertGSTextureFormatViewLinear(format);

		texture_desc_ = {};
		texture_desc_.Width = 2;
		texture_desc_.Height = 2;
		texture_desc_.Depth = 2;
		texture_desc_.MipLevels = 1;
		texture_desc_.Format = dxgi_format_resource;
		texture_desc_.BindFlags = D3D11_BIND_SHADER_RESOURCE;

		width = texture_desc_.Width;
		height = texture_desc_.Height;
		depth = texture_desc_.Depth;
		dxgiFormatResource = dxgi_format_resource;
		dxgiFormatView = dxgi_format_view;
		dxgiFormatViewLinear = dxgi_format_view_linear;
		levels_ = 1;

		viewDesc_ = {};
		viewDesc_.Format = dxgi_format_view;
		viewDesc_.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE3D;
		viewDesc_.Texture3D.MostDetailedMip = 0;
		viewDesc_.Texture3D.MipLevels = 1;

		viewDescLinear_ = viewDesc_;
		viewDescLinear_.Format = dxgi_format_view_linear;

		isShared = false;
	}

	long GSTexture3D::Rebuild(ID3D11Device* dev)
	{
		HRESULT hr = S_OK;

		do {
			if (isShared) {
				hr = dev->OpenSharedResource((HANDLE)(uintptr_t)sharedHandle,
					__uuidof(ID3D11Texture3D), (void**)&texture);
				if (FAILED(hr)) {
					XLOG(LOG_WARNING, "Failed to rebuild shared texture: 0x%08lX", hr);
					RebuildSharedTextureFallback();
				}
			}

			if (!isShared) {
				hr = dev->CreateTexture3D(&texture_desc_,
					data_.size() ? source_data_.data() : nullptr,
					&texture);
				if (FAILED(hr)) {
					XLOG("Failed to create 3D texture", hr);
					break;
				}
			}

			hr = dev->CreateShaderResourceView(texture, &viewDesc_, &shaderRes_);
			if (FAILED(hr)) {
				XLOG("Failed to create 3D SRV", hr);
				break;
			}

			if (viewDesc_.Format == viewDescLinear_.Format) {
				shaderResLinear_ = shaderRes_;
			}
			else {
				hr = dev->CreateShaderResourceView(texture, &viewDescLinear_,
					&shaderResLinear_);
				if (FAILED(hr)) {
					XLOG("Failed to create linear 3D SRV", hr);
					break;
				}
			}

			acquired = false;

			if ((texture_desc_.MiscFlags & D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX) != 0) {
				ComQIPtr<IDXGIResource> dxgi_res(texture);
				if (dxgi_res)
					GetSharedHandle(dxgi_res);
				// return -1 only texture 2d
				//texture_acquire_sync(this, 0, INFINITE);
			}
		} while (false);
		return hr;
	}

	long GSTexture3D::RebuildNV12_Y(ID3D11Device* dev)
	{
		// Do nothing
		return S_OK;
	}

	long GSTexture3D::RebuildNV12_UV(ID3D11Device* dev)
	{
		// Do nothing
		return S_OK;
	}

	void GSTexture3D::InitTexture(const uint8_t* const* data)
	{
		HRESULT hr;

		memset(&texture_desc_, 0, sizeof(texture_desc_));
		texture_desc_.Width = width;
		texture_desc_.Height = height;
		texture_desc_.Depth = depth;
		texture_desc_.MipLevels = genMipmaps ? 0 : levels_;
		texture_desc_.Format = dxgiFormatResource;
		texture_desc_.BindFlags = D3D11_BIND_SHADER_RESOURCE;
		texture_desc_.CPUAccessFlags = isDynamic ? D3D11_CPU_ACCESS_WRITE : 0;
		texture_desc_.Usage = isDynamic ? D3D11_USAGE_DYNAMIC : D3D11_USAGE_DEFAULT;

		if (type_ == GS_TEXTURE_CUBE)
			texture_desc_.MiscFlags |= D3D11_RESOURCE_MISC_TEXTURECUBE;

		if ((flags & GS_SHARED_KM_TEX) != 0)
			texture_desc_.MiscFlags |= D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
		else if ((flags & GS_SHARED_TEX) != 0)
			texture_desc_.MiscFlags |= D3D11_RESOURCE_MISC_SHARED;

		if (data) {
			BackupTexture(data);
			InitSRD(source_data_);
		}

		do {
			hr = device_->device_->CreateTexture3D(
				&texture_desc_, data ? source_data_.data() : NULL, texture.Assign());
			if (FAILED(hr)) {
				device_->SetLastError(hr);
				XLOG("Failed to create 3D texture", hr);
				break;
			}

			if (isShared) {
				ComPtr<IDXGIResource> dxgi_res;

				texture->SetEvictionPriority(DXGI_RESOURCE_PRIORITY_MAXIMUM);

				hr = texture->QueryInterface(__uuidof(IDXGIResource), (void**)&dxgi_res);
				if (FAILED(hr)) {
					XLOG(LOG_WARNING,
						"InitTexture: Failed to query "
						"interface: %08lX",
						hr);
				}
				else {
					GetSharedHandle(dxgi_res);

					if (flags & GS_SHARED_KM_TEX) {
						ComPtr<IDXGIKeyedMutex> km;
						hr = texture->QueryInterface(__uuidof(IDXGIKeyedMutex),
							(void**)&km);
						if (FAILED(hr)) {
							device_->SetLastError(hr);
							XLOG("Failed to query "
								"IDXGIKeyedMutex",
								hr);
							break;
						}

						km->AcquireSync(0, INFINITE);
						acquired = true;
					}
				}
			}
		} while (false);
		return;
	}

	void GSTexture3D::InitResourceView()
	{
		HRESULT hr;

		memset(&viewDesc_, 0, sizeof(viewDesc_));
		viewDesc_.Format = dxgiFormatView;

		viewDesc_.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE3D;
		viewDesc_.Texture3D.MostDetailedMip = 0;
		viewDesc_.Texture3D.MipLevels = genMipmaps || !levels_ ? -1 : levels_;

		do {
			hr = device_->device_->CreateShaderResourceView(texture, &viewDesc_,
				shaderRes_.Assign());
			if (FAILED(hr)) {
				device_->SetLastError(hr);
				XLOG("Failed to create 3D SRV", hr);
				break;
			}

			viewDescLinear_ = viewDesc_;
			viewDescLinear_.Format = dxgiFormatViewLinear;

			if (dxgiFormatView == dxgiFormatViewLinear) {
				shaderResLinear_ = shaderRes_;
			}
			else {
				hr = device_->device_->CreateShaderResourceView(texture, &viewDescLinear_,
					shaderResLinear_.Assign());
				if (FAILED(hr)) {
					device_->SetLastError(hr);
					XLOG("Failed to create linear 3D SRV", hr);
					break;
				}
			}
		} while (false);
		return;
	}

#define SHARED_FLAGS (GS_SHARED_TEX | GS_SHARED_KM_TEX)

	GSTexture3D::GSTexture3D(GSDevice* device, uint32_t width, uint32_t height, uint32_t depth,
		gs_color_format colorFormat, uint32_t levels, const uint8_t* const* data,
		uint32_t flags_)
		: GSTexture(device, E_GSType::ktexture_3d, GS_TEXTURE_3D, levels, colorFormat),
		width(width),
		height(height),
		depth(depth),
		flags(flags_),
		dxgiFormatResource(ConvertGSTextureFormatResource(format_)),
		dxgiFormatView(ConvertGSTextureFormatView(format_)),
		dxgiFormatViewLinear(ConvertGSTextureFormatViewLinear(format_)),
		isDynamic((flags_& GS_DYNAMIC) != 0),
		isShared((flags_& SHARED_FLAGS) != 0),
		genMipmaps((flags_& GS_BUILD_MIPMAPS) != 0),
		sharedHandle(GS_INVALID_HANDLE)
	{
		InitTexture(data);
		InitResourceView();
	}

	GSTexture3D::GSTexture3D(GSDevice* device, HANDLE handle)
		: GSTexture(device, E_GSType::ktexture_3d, GS_TEXTURE_3D),
		isShared(true),
		sharedHandle(handle)
	{
		HRESULT hr = S_OK;

		do {
			hr = device_->device_->OpenSharedResource((HANDLE)(uintptr_t)handle,
				IID_PPV_ARGS(texture.Assign()));

			if (FAILED(hr)) {
				device_->SetLastError(hr);
				XLOG("Failed to open shared 3D texture", hr);
				break;
			}

			texture->GetDesc(&texture_desc_);

			const gs_color_format format = ConvertDXGITextureFormat(texture_desc_.Format);

			this->type_ = GS_TEXTURE_3D;
			this->format_ = format;
			this->levels_ = 1;
			this->device_ = device;

			this->width = texture_desc_.Width;
			this->height = texture_desc_.Height;
			this->depth = texture_desc_.Depth;
			this->dxgiFormatResource = ConvertGSTextureFormatResource(format);
			this->dxgiFormatView = ConvertGSTextureFormatView(format);
			this->dxgiFormatViewLinear = ConvertGSTextureFormatViewLinear(format);

			InitResourceView();
		} while (false);
	}

}
