#pragma once
#ifndef __X_D3D11_DEVICE_H__
#define __X_D3D11_DEVICE_H__

#include <vector>
#include <list>

#include <windows.h>
#include <dxgi1_6.h>
#include <d3d11_1.h>
#include <d3dcompiler.h>

//#include "lib-d3d11-types.h"

#include "lib-d3d11/d3d11/d3d11-texture.h"
#include "lib-d3d11/d3d11/d3d11-texture2d.h"
#include "lib-d3d11/d3d11/d3d11-texture3d.h"
#include "lib-d3d11/d3d11/d3d11-zstencilbuffer.h"
#include "lib-d3d11/d3d11/d3d11-stagesurf.h"
#include "lib-d3d11/d3d11/d3d11-duplicator.h"
#include "lib-d3d11/d3d11/d3d11-texture2d.h"
#include "lib-d3d11/d3d11/d3d11-zstencilbuffer.h"
#include "lib-d3d11/d3d11/d3d11-indexbuffer.h"
#include "lib-d3d11/d3d11/d3d11-vertexbuffer.h"
#include "lib-d3d11/d3d11/d3d11-timer.h"
#include "lib-d3d11/d3d11/d3d11-swapchain.h"
#include "lib-d3d11/d3d11/d3d11-duplicator.h"

#include "lib-d3d11/d3d-common/lib-common.h"

namespace lib_d3d {
	class LIB_EXPORT IDeviceEventListener {
	public:
		virtual long OnDeviceCreated(ID3D11Device* pd3dDevice,
			const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc,
			void* pUserContext)
		{
			return S_OK;
		};
		virtual long OnDeviceDestroy(void* pUserContext) { return S_OK; };
		// DXGI_ERROR_DEVICE_REMOVED || DXGI_ERROR_DEVICE_RESET
		virtual long OnDeviceRemoved(void* pUserContext) { return S_OK; };
		virtual long OnDeviceRebuild(ID3D11Device* pd3dDevice, void* pUserContext) { return S_OK; };

		virtual long OnSwapChainResized(ID3D11Device* pd3dDevice, IDXGISwapChain* pSwapChain,
			const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc,
			void* pUserContext)
		{
			return S_OK;
		};
		virtual long onSwapChainReleasing(void* pUserContext) { return S_OK; };
		virtual long OnFrameRender(ID3D11Device* pd3dDevice,
			ID3D11DeviceContext* pd3dImmediateContext, double fTime,
			float fElapsedTime, void* pUserContext)
		{
			return S_OK;
		};

		virtual long OnError(HRESULT error, const std::string& desc) { return S_OK; };
	};

	//ID3D11Device  thread safe but ID3D11DeviceContext not
	class LIB_EXPORT GSDevice {
	public:
		GSDevice(uint32_t adapterIdx = 0);
		GSDevice(LUID uid);
		~GSDevice();

		long Create();
		long Destroy();
		// GSObject operation
		// GSObject create
		GSTexture2DPtr TextureCreate(uint32_t width, uint32_t height, gs_color_format color_format,
			uint32_t levels, const uint8_t** data, uint32_t flags);
		GSTexturePtr CubeTextureCreate(uint32_t size, gs_color_format color_format, uint32_t levels,
			const uint8_t** data, uint32_t flags);
		GSTexturePtr VolTextureCreate(uint32_t width, uint32_t height, uint32_t depth,
			gs_color_format color_format, uint32_t levels,
			const uint8_t* const* data, uint32_t flags);
		GSZstencilBufferPtr ZstencilCreate(uint32_t width, uint32_t height,
			gs_zstencil_format format);
		GSStageSurfacePtr StageSurfCreate(uint32_t width, uint32_t height,
			gs_color_format color_format);
		GSSamplerStatePtr SamplerStateCreate(const gs_sampler_info& info);
		GSVertexShaderPtr VetextShaderCreate(const string& file, const vector<uint8_t>& inputdata,
			const D3D11_BUFFER_DESC& desc,
			const vector<D3D11_INPUT_ELEMENT_DESC>& layout);
		GSPixelShaderPtr PixelShaderCreate(const string& file, const D3D11_BUFFER_DESC& desc,
			const vector<uint8_t>& inputdata);
		GSVertexBufferPtr VertexBufferCreate(vertex_data_ptr data, uint32_t flags);
		//GSIndexBufferPtr IndexBufferCreate(gs_index_type type, void* indices, size_t num, uint32_t flags);
		GSIndexBufferPtr IndexBufferCreate(index_data_ptr indices, uint32_t flags);
		GSTimerPtr TimerCreate();
		GSTimerRangePtr TimerRangeCreate();

		// gs object destroy
		long ShaderDestroy(GSShaderPtr shader);
		//long EffectDestory();
		//long TextureRenderDestroy(GSTextureRenderPtr render);
		long SwapchainDestroy(GSSwapchainPtr swapchain);
		long TextureDestroy(GSTexturePtr tex);
		long CubetextureDestroy(GSTexturePtr cubetex);
		long VoltextureDestroy(GSTexturePtr voltex);
		long StagesurfaceDestroy(GSStageSurfacePtr stagesurf);
		long ZstencilDestroy(GSZstencilBufferPtr zstencil);
		long SamplerstateDestroy(GSSamplerStatePtr samplerstate);
		long VertexbufferDestroy(GSVertexBufferPtr vertbuffer);
		long IndexbufferDestroy(GSIndexBufferPtr indexbuffer);
		long TimerDestroy(GSTimerPtr timer);
		long TimerRangeDestroy(GSTimerRangePtr timer);
		long DuplicatorDestroy(GSDuplicatorPtr duplicator);

		bool AddListener(IDeviceEventListener* listener);
		bool RemoveListener(IDeviceEventListener* listener);

		//void InitCompiler();
		long InitFactory();
		void ReorderAdapters(uint32_t& adapterIdx);
		long InitAdapter(uint32_t adapterIdx);
		long InitDevice(uint32_t adapterIdx);

		ID3D11DepthStencilState* AddZStencilState();
		ID3D11RasterizerState* AddRasterState();
		ID3D11BlendState* AddBlendState();
		void UpdateZStencilState();
		void UpdateRasterState();
		void UpdateBlendState();

		void LoadVertexBufferData();

		void LoadVertexBufferData(GSVertexBufferPtr buf, const VertexShaderConfig& config);
		void LoadIndexBufferData(GSIndexBufferPtr buf);

		void CopyTex(ID3D11Texture2D* dst, uint32_t dst_x, uint32_t dst_y,
			GSTexture2DPtr src, uint32_t src_x, uint32_t src_y, uint32_t src_w,
			uint32_t src_h);

		void UpdateViewProjMatrix(const matrix4& viewMatrix);

		void FlushOutputViews();

		long RebuildDevice();

		bool HasBadNV12Output();

		long SetLastError(long err);
		long GetLastError() const;

	protected:
		long SetRenderTarget(GSTexture2DPtr tex, GSZstencilBufferPtr zstencil,
			gs_color_space space = GS_CS_SRGB);

	public:
		// d3d internal error code (HRESULT,single thread device)
		long last_error_ = 0;
		ComPtr<IDXGIFactory1> factory_;
		ComPtr<IDXGIAdapter1> adapter_;
		ComPtr<ID3D11Device> device_;
		ComPtr<ID3D11DeviceContext> context_;
		uint32_t adpIdx_ = 0;
		LUID uid_ = { 0 };
		bool nv12Supported_ = false;
		bool p010Supported_ = false;

		GSTexture2DPtr curRenderTarget_ = nullptr;
		GSZstencilBufferPtr curZStencilBuffer_ = nullptr;
		int curRenderSide_ = 0;
		enum gs_color_space curColorSpace_ = GS_CS_SRGB;
		bool curFramebufferSrgb_ = false;
		bool curFramebufferInvalidate_ = false;
		//GSTexture* curTextures[GS_MAX_TEXTURES];
		vector<GSTexturePtr> curTextures_{ GS_MAX_TEXTURES };
		//GSSamplerState* curSamplers[GS_MAX_TEXTURES];
		vector<GSSamplerStatePtr> curSamplers_;
		GSVertexBufferPtr curVertexBuffer_ = nullptr;
		GSIndexBufferPtr curIndexBuffer_ = nullptr;
		GSVertexShaderPtr curVertexShader_ = nullptr;
		GSPixelShaderPtr curPixelShader_ = nullptr;
		GSSwapchainPtr curSwapChain_ = nullptr;

		GSVertexBufferPtr lastVertexBuffer_ = nullptr;
		GSVertexShaderPtr lastVertexShader_ = nullptr;

		bool zstencilStateChanged_ = true;
		bool rasterStateChanged_ = true;
		bool blendStateChanged_ = true;
		ZStencilState zstencilState_;
		RasterState rasterState_;
		BlendState blendState_;
		vector<SavedZStencilState> zstencilStates_;
		vector<SavedRasterState> rasterStates_;
		vector<SavedBlendState> blendStates_;
		ID3D11DepthStencilState* curDepthStencilState_ = nullptr;
		ID3D11RasterizerState* curRasterState_ = nullptr;
		ID3D11BlendState* curBlendState_ = nullptr;
		D3D11_PRIMITIVE_TOPOLOGY curToplogy_;

		gs_rect viewport_;

		vector<mat4float> projStack_;

		matrix4 curWorldMatrix_; // world
		matrix4 curViewMatrix_;  // view
		matrix4 curProjMatrix_;  // projection

		vector<IDeviceEventListener*> event_callbacks_;
		//GSObject *objects_ = nullptr;
		std::list<GSObject*> objects_;

		vector<std::pair<HMONITOR, bool>> monitor_to_hdr_;
	};

	using GSDevicePtr = std::shared_ptr<GSDevice>;
	//using GSDevicePtr = GSDevice*;
}
#endif