#pragma once
#ifndef __X_D3D11_OBJECT_H__
#define __X_D3D11_OBJECT_H__

#include "lib-d3d11/d3d-common/lib-common.h"
#include <d3d11.h>
namespace lib_d3d {
	class GSDevice;

	enum E_GSType {
		kvertex_buffer,
		kindex_buffer,
		ktexture_2d,
		kzstencil_buffer,
		kstage_surface,
		ksampler_state,
		kvertex_shader,
		kpixel_shader,
		kduplicator,
		kswap_chain,
		ktimer,
		ktimer_range,
		ktexture_3d,
	};
	//////////////////////////////////////////////////////////////////////////
	class LIB_EXPORT GSObject {
	public:
		inline GSObject() : device_(nullptr) {}

		GSObject(GSDevice* device, E_GSType type);
		virtual ~GSObject();

		//GSObject(const GSObject& rhs);
		//GSObject(GSObject&& rhs);
		//GSObject& operator=(const GSObject& rhs);
		//GSObject& operator=(GSObject&& rhs);

		virtual long Create() { return 0; };
		virtual long Destroy() { return 0; };

		virtual long Release() { return 0; };
		virtual long Rebuild(ID3D11Device* dev) { return 0; }; // create?

		//protected:
		//	virtual void copy(const GSObject& rhs);
		//	virtual void move(GSObject&& rhs);

	public:
		GSDevice* device_;
		E_GSType obj_type_;

		GSObject* next_;
		GSObject** prev_next_;
	};
}

#endif
