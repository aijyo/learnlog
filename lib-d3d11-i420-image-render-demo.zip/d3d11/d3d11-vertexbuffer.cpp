#include "d3d11-subsystem.h"

#include "lib-d3d11/d3d-common/lib-common.h"
#include "d3d11-vertexbuffer.h"
#include "d3d11-device.h"

namespace lib_d3d {
	long GSVertexBuffer::Create(vertex_data_ptr data)
	{
		long result = 0;
		vertex_data_ = data;
		numVerts_ = data->tvarray_.size();
		do {
			if (!vertex_data_) {
				result = E_INVALIDARG;
				break;
			}

			auto& vbd = *vertex_data_;
			if (vbd.points_.empty()) {
				result = E_INVALIDARG;
				break;
			}

			result = BuildBuffers();
		} while (false);

		return result;
	}

	long GSVertexBuffer::Destroy()
	{
		HRESULT result = S_OK;
		Release();
		return result;
	}

	vertex_data_ptr GSVertexBuffer::Data() const
	{
		return vertex_data_;
	}

	static inline void PushBuffer(UINT* refNumBuffers, ID3D11Buffer** buffers, uint32_t* strides,
		ID3D11Buffer* buffer, size_t elementSize, const char* name)
	{
		const UINT numBuffers = *refNumBuffers;
		if (buffer) {
			buffers[numBuffers] = buffer;
			strides[numBuffers] = (uint32_t)elementSize;
			*refNumBuffers = numBuffers + 1;
		}
		else {
			XLOG(LOG_ERROR, "This vertex shader requires a %s buffer", name);
		}
	}

	void GSVertexBuffer::FlushBuffer(ID3D11Buffer* buffer, void* data, size_t elementSize)
	{
		D3D11_MAPPED_SUBRESOURCE msr;
		HRESULT hr = S_OK;

		do {
			if (FAILED(hr = device_->context_->Map(buffer, 0, D3D11_MAP_WRITE_DISCARD, 0,
				&msr))) {
				XLOG("Failed to map buffer", hr);
				break;
			}
			auto num = PointsNum();
			memcpy(msr.pData, data, elementSize * num);
			device_->context_->Unmap(buffer, 0);
		} while (false);
		return;
	}

	UINT GSVertexBuffer::MakeBufferList(const VertexShaderConfig& config, ID3D11Buffer** buffers,
		uint32_t* strides)
	{
		UINT numBuffers = 0;
		PushBuffer(&numBuffers, buffers, strides, vertexBuffer_, sizeof(vec3), "point");

		if (config.hasNormals_)
			PushBuffer(&numBuffers, buffers, strides, normalBuffer_, sizeof(vec3), "normal");
		if (config.hasColors_)
			PushBuffer(&numBuffers, buffers, strides, colorBuffer_, sizeof(uint32_t), "color");
		if (config.hasTangents_)
			PushBuffer(&numBuffers, buffers, strides, tangentBuffer_, sizeof(vec3), "tangent");
		if (config.nTexUnits_ <= uvBuffers_.size()) {
			for (size_t i = 0; i < config.nTexUnits_; i++) {
				buffers[numBuffers] = uvBuffers_[i];
				strides[numBuffers] = (uint32_t)uvSizes_[i];
				++numBuffers;
			}
		}
		else {
			XLOG(LOG_ERROR,
				"This vertex shader requires at least %u "
				"texture buffers.",
				(uint32_t)config.nTexUnits_);
		}

		return numBuffers;
	}

	long GSVertexBuffer::InitBuffer(const size_t elementSize, const size_t numVerts, void* array,
		ID3D11Buffer** buffer)
	{
		D3D11_BUFFER_DESC bd;
		D3D11_SUBRESOURCE_DATA srd;
		HRESULT hr = S_OK;

		memset(&bd, 0, sizeof(bd));
		memset(&srd, 0, sizeof(srd));

		bd.Usage = dynamic_ ? D3D11_USAGE_DYNAMIC : D3D11_USAGE_DEFAULT;
		bd.CPUAccessFlags = dynamic_ ? D3D11_CPU_ACCESS_WRITE : 0;
		bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		bd.ByteWidth = UINT(elementSize * numVerts);
		srd.pSysMem = array;

		hr = device_->device_->CreateBuffer(&bd, &srd, buffer);
		if (FAILED(hr)) {
			device_->SetLastError(hr);
			XLOG("Failed to create buffer", hr);
		}

		return hr;
	}

	long GSVertexBuffer::BuildBuffers()
	{
		HRESULT hr = S_OK;
		do {
			if (!vertex_data_) {
				hr = E_FAIL;
				break;
			}
			auto& vbd = *vertex_data_;
			auto num = vbd.points_.size();
			hr = InitBuffer(sizeof(vec3), num, vbd.points_.data(), &vertexBuffer_);

			if (FAILED(hr))
				break;

			if (!vbd.normals_.empty())
				hr = InitBuffer(sizeof(vec3), num, vbd.normals_.data(), &normalBuffer_);
			if (FAILED(hr))
				break;
			if (!vbd.tangents_.empty())
				hr = InitBuffer(sizeof(vec3), num, vbd.tangents_.data(), &tangentBuffer_);

			if (FAILED(hr))
				break;
			if (!vbd.colors_.empty())
				hr = InitBuffer(sizeof(uint32_t), num, vbd.colors_.data(), &colorBuffer_);

			if (FAILED(hr))
				break;
			auto num_tex = vbd.tvarray_.size();
			for (size_t i = 0; i < num_tex; i++) {
				const auto& tverts = vbd.tvarray_[i];

				//if (tverts.width != 2 && tverts.width != 4)
				//	hr = E_INVALIDARG;
				if (tverts.empty())
					hr = E_INVALIDARG;
				if (FAILED(hr))
					break;

				ComPtr<ID3D11Buffer> buffer;
				hr = InitBuffer(VERTEX_ELEMENT_WIDTH * sizeof(float), num,
					(void*)tverts.data(), &buffer);
				if (FAILED(hr))
					break;

				uvBuffers_.push_back(buffer);
				uvSizes_.push_back(VERTEX_ELEMENT_WIDTH * sizeof(float));
			}

			if (FAILED(hr))
				break;
		} while (false);

		return hr;
	}

	GSVertexBuffer::GSVertexBuffer(GSDevice* device, uint32_t flags)
		: GSObject(device, E_GSType::kvertex_buffer),
		dynamic_((flags& GS_DYNAMIC) != 0),
		vertex_data_(nullptr),
		numVerts_(0)
	{
	}

	GSVertexBuffer::~GSVertexBuffer()
	{
		Release();
	}

	inline long GSVertexBuffer::Release()
	{
		HRESULT result = S_OK;
		vertexBuffer_.Release();
		normalBuffer_.Release();
		colorBuffer_.Release();
		tangentBuffer_.Release();
		uvBuffers_.clear();

		return result;
	}

	long GSVertexBuffer::Rebuild(ID3D11Device* dev)
	{
		uvBuffers_.clear();
		uvSizes_.clear();
		return BuildBuffers();
	}

	long GSVertexBuffer::Flush(vertex_data_ptr data)
	{
		HRESULT hr = S_OK;

		do {
			if (data == nullptr) {
				data = vertex_data_;
			}

			if (data == nullptr)
				break;

			size_t num_tex = data->tvarray_.size() < uvBuffers_.size() ? data->tvarray_.size()
				: uvBuffers_.size();

			if (!dynamic_) {
				XLOG(LOG_ERROR, "gs_vertexbuffer_flush: vertex buffer is "
					"not dynamic");
				break;
			}

			if (vertexBuffer_ && data->points_.size())
				FlushBuffer(vertexBuffer_, (void*)data->points_.data(),
					sizeof(vertex_data::data_type));

			if (normalBuffer_ && data->normals_.size())
				FlushBuffer(normalBuffer_, (void*)data->normals_.data(),
					sizeof(vertex_data::data_type));

			if (tangentBuffer_ && data->tangents_.size())
				FlushBuffer(tangentBuffer_, (void*)data->tangents_.data(),
					sizeof(vertex_data::data_type));

			if (colorBuffer_ && data->colors_.size())
				FlushBuffer(colorBuffer_, (void*)data->colors_.data(), sizeof(uint32_t));

			for (size_t i = 0; i < num_tex; i++) {
				const auto& items_ = data->tvarray_[i];
				FlushBuffer(uvBuffers_[i], (void*)items_.data(),
					/*tv.width * sizeof(float)*/ sizeof(vec2));
			}
		} while (false);
		return hr;
	}
}