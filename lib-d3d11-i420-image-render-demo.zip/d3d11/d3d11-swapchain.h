#pragma once
#ifndef __X_D3D11_SWAPCHAIN_H__
#define __X_D3D11_SWAPCHAIN_H__

#include "./d3d11-subsystem.h"
#include "./d3d11-texture2d.h"
#include "./d3d11-zstencilbuffer.h"

namespace lib_d3d {
class LIB_EXPORT GSSwapchain : public GSObject {
public:
	GSSwapchain(GSDevice *device);
	virtual ~GSSwapchain();

	long Create(const swapchain_data &data);
	long Destroy();

	int InitTarget(uint32_t cx, uint32_t cy);
	int InitZStencilBuffer(uint32_t cx, uint32_t cy);
	int Resize(uint32_t cx, uint32_t cy, gs_color_format format);
	int Init();

	long Rebuild(ID3D11Device *dev);

	inline long Release();

public:
	HWND hwnd_;
	swapchain_data initData_;
	DXGI_SWAP_CHAIN_DESC swapDesc_ = {};
	gs_color_space space_;
	UINT presentFlags_ = 0;

	GSTexture2D target_;
	GSZstencilBuffer zstencilBuffer_;
	ComPtr<IDXGISwapChain> swapchain_;
	HANDLE hWaitable = NULL;
};

//using GSSwapchainPtr = std::shared_ptr<GSSwapchain>;
using GSSwapchainPtr = GSSwapchain *;
}
#endif
