#pragma once
#ifndef __X_D3D11_TEXTURE3D_H__
#define __X_D3D11_TEXTURE3D_H__

#include "./d3d11-subsystem.h"
#include "./d3d11-texture.h"

namespace lib_d3d {
class LIB_EXPORT GSTexture3D : public GSTexture {
public:
	void InitSRD(vector<D3D11_SUBRESOURCE_DATA> &srd);
	void InitTexture(const uint8_t *const *data);
	void InitResourceView();
	void BackupTexture(const uint8_t *const *data);
	void GetSharedHandle(IDXGIResource *dxgi_res);

	void RebuildSharedTextureFallback();
	long Rebuild(ID3D11Device *dev);
	long RebuildNV12_Y(ID3D11Device *dev);
	long RebuildNV12_UV(ID3D11Device *dev);

	inline long Release()
	{
		texture.Release();
		shaderRes_.Release();
		return 0;
	}

	inline GSTexture3D() : GSTexture(GS_TEXTURE_3D, 0, GS_UNKNOWN) {}

	GSTexture3D(GSDevice *device, uint32_t width, uint32_t height, uint32_t depth,
		    gs_color_format colorFormat, uint32_t levels, const uint8_t *const *data,
		    uint32_t flags);

	GSTexture3D(GSDevice *device, HANDLE handle);

public:
	ComPtr<ID3D11Texture3D> texture;

	uint32_t width = 0, height = 0, depth = 0;
	uint32_t flags = 0;
	DXGI_FORMAT dxgiFormatResource = DXGI_FORMAT_UNKNOWN;
	DXGI_FORMAT dxgiFormatView = DXGI_FORMAT_UNKNOWN;
	DXGI_FORMAT dxgiFormatViewLinear = DXGI_FORMAT_UNKNOWN;
	bool isDynamic = false;
	bool isShared = false;
	bool genMipmaps = false;
	HANDLE sharedHandle = GS_INVALID_HANDLE;

	bool chroma = false;
	bool acquired = false;

	vector<vector<uint8_t>> data_;
	vector<D3D11_SUBRESOURCE_DATA> source_data_;
	D3D11_TEXTURE3D_DESC texture_desc_ = {};
};
//using GSTexture3DPtr = std::shared_ptr<GSTexture3D>;
using GSTexture3DPtr = GSTexture3D *;
}
#endif