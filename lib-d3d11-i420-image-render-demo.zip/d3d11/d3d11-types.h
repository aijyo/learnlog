#pragma once
#ifndef __X_D3D11_TYPES_H__
#define __X_D3D11_TYPES_H__

#include <dxgi.h>

namespace lib_d3d {
using gs_color_format = DXGI_FORMAT;
using gs_color_format = DXGI_FORMAT;

}

#endif