#pragma once
#ifndef __X_D3D11_ZSTENCILBUFFER_H__
#define __X_D3D11_ZSTENCILBUFFER_H__

#include "./d3d11-subsystem.h"

namespace lib_d3d {
class GSDevice;

class LIB_EXPORT GSZstencilBuffer : public GSObject {
public:
	long Create();
	long Destroy();

	long InitBuffer();

	long Rebuild(ID3D11Device *dev);
	inline long Release();

	inline GSZstencilBuffer() : width_(0), height_(0), dxgiFormat_(DXGI_FORMAT_UNKNOWN) {}

	GSZstencilBuffer(GSDevice *device, uint32_t width, uint32_t height,
			 gs_zstencil_format format);

public:
	ComPtr<ID3D11Texture2D> texture_;
	ComPtr<ID3D11DepthStencilView> view_;

	uint32_t width_, height_;
	gs_zstencil_format format_;
	DXGI_FORMAT dxgiFormat_;

	D3D11_TEXTURE2D_DESC texture_desc_ = {};
	D3D11_DEPTH_STENCIL_VIEW_DESC dsvd_ = {};
};

//using GSZstencilBufferPtr = std::shared_ptr<GSZstencilBuffer>;
using GSZstencilBufferPtr = GSZstencilBuffer *;
}
#endif