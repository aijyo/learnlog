#pragma once
#ifndef __X_D3D11_VERTEXBUFFER_H__
#define __X_D3D11_VERTEXBUFFER_H__

#include "./d3d11-subsystem.h"
#include "d3d11-shader.h"
namespace lib_d3d {
class LIB_EXPORT GSVertexBuffer : public GSObject {
public:
	long Create(vertex_data_ptr data);
	long Destroy();

	vertex_data_ptr Data() const;

	void FlushBuffer(ID3D11Buffer *buffer, void *data, size_t elementSize);

	UINT MakeBufferList(const VertexShaderConfig &config, ID3D11Buffer **buffers,
			    uint32_t *strides);

	long InitBuffer(const size_t elementSize, const size_t numVerts, void *array,
			ID3D11Buffer **buffer);

	long BuildBuffers();

	inline long Release();
	long Rebuild(ID3D11Device *dev);

	// if data is null ptr, use default.
	long Flush(vertex_data_ptr data);

	std::uint32_t PointsNum() const
	{
		return vertex_data_ ? (uint32_t)vertex_data_->points_.size() : 0;
	}
	GSVertexBuffer(GSDevice *device, uint32_t flags);
	~GSVertexBuffer();

public:
	ComPtr<ID3D11Buffer> vertexBuffer_;
	ComPtr<ID3D11Buffer> normalBuffer_;
	ComPtr<ID3D11Buffer> colorBuffer_;
	ComPtr<ID3D11Buffer> tangentBuffer_;
	vector<ComPtr<ID3D11Buffer>> uvBuffers_;

	bool dynamic_;
	vertex_data_ptr vertex_data_; // backup data
	size_t numVerts_;
	vector<size_t> uvSizes_;
};

//using GSVertexBufferPtr = std::shared_ptr<GSVertexBuffer>;
using GSVertexBufferPtr = GSVertexBuffer *;
}
#endif