/******************************************************************************
	Copyright (C) 2013 by Hugh Bailey <obs.jim@gmail.com>

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
******************************************************************************/

#include "d3d11-subsystem.h"
#include <unordered_map>

#include "lib-d3d11/d3d-common/lib-common.h"
#include "d3d11-duplicator.h"
#include "d3d11-device.h"
#include "lib-d3d11/graphics/graphics.h"
#include "lib-d3d11/d3d11/d3d11-texture2d.h"

namespace lib_d3d {
	static inline long get_monitor(GSDevice* device, int monitor_idx, IDXGIOutput** dxgiOutput)
	{
		HRESULT hr;

		hr = device->adapter_->EnumOutputs(monitor_idx, dxgiOutput);
		//if (FAILED(hr))
		//{
		//	if (hr == DXGI_ERROR_NOT_FOUND)
		//		return false;

		//	throw HRError("Failed to get output", hr);
		//}

		return hr;
	}

	GSDuplicator::GSDuplicator(GSDevice* device_, int monitor_idx)
		: GSObject(device_, E_GSType::kduplicator),
		texture(nullptr),
		idx(monitor_idx),
		refs(1),
		updated(false)
	{
		Start();
	}

	GSDuplicator::~GSDuplicator()
	{
		delete texture;
	}

	long GSDuplicator::Start()
	{
		ComPtr<IDXGIOutput5> output5;
		ComPtr<IDXGIOutput1> output1;
		ComPtr<IDXGIOutput> output;
		HRESULT hr = S_OK;

		do {
			hr = get_monitor(device_, idx, output.Assign());
			if (FAILED(hr)) {
				break;
				//throw "Invalid monitor index";
			}

			hr = output->QueryInterface(IID_PPV_ARGS(output5.Assign()));
			if (SUCCEEDED(hr)) {
				constexpr DXGI_FORMAT supportedFormats[]{
					DXGI_FORMAT_R16G16B16A16_FLOAT,
					DXGI_FORMAT_B8G8R8A8_UNORM,
				};
				hr = output5->DuplicateOutput1(device_->device_, 0,
					_countof(supportedFormats), supportedFormats,
					duplicator.Assign());
				if (FAILED(hr)) {
					break;
					//throw HRError("Failed to DuplicateOutput1", hr);
				}
			}
			else {
				hr = output->QueryInterface(IID_PPV_ARGS(output1.Assign()));
				if (FAILED(hr)) {
					break;
					//throw HRError("Failed to query IDXGIOutput1", hr);
				}

				hr = output1->DuplicateOutput(device_->device_, duplicator.Assign());
				if (FAILED(hr)) {
					break;
					//throw HRError("Failed to DuplicateOutput", hr);
				}
			}
		} while (false);
		if (FAILED(hr)) {
			device_->SetLastError(hr);
		}
		return hr;
	}

	long GSDuplicator::Create()
	{
		HRESULT result = S_OK;

		return result;
	}

	long GSDuplicator::Destroy()
	{
		HRESULT result = S_OK;

		return result;
	}

	long GSDuplicator::device_get_duplicator_monitor_info(GSDevice* device, int monitor_idx,
		gs_monitor_info* info)
	{
		DXGI_OUTPUT_DESC desc;
		HRESULT hr = S_OK;

		do {
			ComPtr<IDXGIOutput> output;
			hr = get_monitor(device, monitor_idx, output.Assign());
			if (FAILED(hr)) {
				break;
			}
			hr = output->GetDesc(&desc);
			if (FAILED(hr)) {
				break;
			}

			switch (desc.Rotation) {
			case DXGI_MODE_ROTATION_UNSPECIFIED:
			case DXGI_MODE_ROTATION_IDENTITY:
				info->rotation_degrees = 0;
				break;

			case DXGI_MODE_ROTATION_ROTATE90:
				info->rotation_degrees = 90;
				break;

			case DXGI_MODE_ROTATION_ROTATE180:
				info->rotation_degrees = 180;
				break;

			case DXGI_MODE_ROTATION_ROTATE270:
				info->rotation_degrees = 270;
				break;
			}

			info->x = desc.DesktopCoordinates.left;
			info->y = desc.DesktopCoordinates.top;
			info->cx = desc.DesktopCoordinates.right - info->x;
			info->cy = desc.DesktopCoordinates.bottom - info->y;

		} while (false);

		return hr;
	}

	int GSDuplicator::device_duplicator_get_monitor_index(GSDevice* device, void* monitor)
	{
		const HMONITOR handle = (HMONITOR)monitor;

		int index = -1;

		UINT output = 0;
		while (index == -1) {
			IDXGIOutput* pOutput;
			const HRESULT hr = device->adapter_->EnumOutputs(output, &pOutput);
			if (hr == DXGI_ERROR_NOT_FOUND)
				break;

			if (SUCCEEDED(hr)) {
				DXGI_OUTPUT_DESC desc;
				if (SUCCEEDED(pOutput->GetDesc(&desc))) {
					if (desc.Monitor == handle)
						index = output;
				}
				else {
					XLOG(LOG_ERROR,
						"device_duplicator_get_monitor_index: "
						"Failed to get desc (%08lX)",
						hr);
				}

				pOutput->Release();
			}
			else if (hr == DXGI_ERROR_NOT_FOUND) {
				XLOG(LOG_ERROR,
					"device_duplicator_get_monitor_index: "
					"Failed to get output (%08lX)",
					hr);
			}

			++output;
		}

		return index;
	}

	static std::unordered_map<int, GSDuplicator*> instances;

	void GSDuplicator::reset_duplicators(void)
	{
		for (std::pair<const int, GSDuplicator*>& pair : instances) {
			pair.second->updated = false;
		}
	}

	GSDuplicator* GSDuplicator::device_duplicator_create(GSDevice* device, int monitor_idx)
	{
		GSDuplicator* duplicator = nullptr;
		HRESULT hr = S_OK;

		const auto it = instances.find(monitor_idx);
		if (it != instances.end()) {
			duplicator = it->second;
			duplicator->refs++;
			return duplicator;
		}

		do {
			duplicator = new GSDuplicator(device, monitor_idx);
			hr = duplicator->Create();
			if (FAILED(hr)) {
				delete duplicator;
				break;
			}
			instances[monitor_idx] = duplicator;
		} while (false);
		return duplicator;
	}

	void GSDuplicator::gs_duplicator_destroy(GSDuplicator* duplicator)
	{
		if (--duplicator->refs == 0) {
			instances.erase(duplicator->idx);
			delete duplicator;
		}
	}

	void GSDuplicator::copy_texture(GSDuplicator* d, ID3D11Texture2D* tex)
	{
		D3D11_TEXTURE2D_DESC desc;
		tex->GetDesc(&desc);
		const gs_color_format format = ConvertDXGITextureFormat(desc.Format);
		const gs_color_format general_format = gs_generalize_format(format);

		if (!d->texture || (d->texture->width_ != desc.Width) ||
			(d->texture->height_ != desc.Height) || (d->texture->format_ != general_format)) {

			d->device_->TextureDestroy(d->texture);
			d->texture = d->device_->TextureCreate(desc.Width, desc.Height, general_format, 1,
				nullptr, 0);
		}

		if (d->texture)
			d->device_->context_->CopyResource(d->texture->texture_, tex);
	}

	bool GSDuplicator::gs_duplicator_update_frame(GSDuplicator* d)
	{
		DXGI_OUTDUPL_FRAME_INFO info;
		ComPtr<ID3D11Texture2D> tex;
		ComPtr<IDXGIResource> res;
		HRESULT hr;

		if (!d->duplicator) {
			return false;
		}
		if (d->updated) {
			return true;
		}

		hr = d->duplicator->AcquireNextFrame(0, &info, res.Assign());
		if (hr == DXGI_ERROR_ACCESS_LOST) {
			return false;

		}
		else if (hr == DXGI_ERROR_WAIT_TIMEOUT) {
			return true;

		}
		else if (FAILED(hr)) {
			XLOG(LOG_ERROR,
				"gs_duplicator_update_frame: Failed to update "
				"frame (%08lX)",
				hr);
			return true;
		}

		hr = res->QueryInterface(__uuidof(ID3D11Texture2D), (void**)tex.Assign());
		if (FAILED(hr)) {
			XLOG(LOG_ERROR,
				"gs_duplicator_update_frame: Failed to query "
				"ID3D11Texture2D (%08lX)",
				hr);
			d->duplicator->ReleaseFrame();
			return true;
		}

		copy_texture(d, tex);
		d->duplicator->ReleaseFrame();
		d->updated = true;
		return true;
	}

	GSTexture* GSDuplicator::gs_duplicator_get_texture(GSDuplicator* duplicator)
	{
		return duplicator->texture;
	}
}