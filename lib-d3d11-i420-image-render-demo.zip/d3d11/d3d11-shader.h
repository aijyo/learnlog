#pragma once
#ifndef __X_D3D11_SHADER_H__
#define __X_D3D11_SHADER_H__

#include <vector>

#include "./d3d11-subsystem.h"
#include "lib-d3d11/d3d-common/lib-common.h"
#include "./d3d11-samplerstate.h"

namespace lib_d3d {
	enum shader_var_type {
		SHADER_VAR_NONE,
		SHADER_VAR_IN = SHADER_VAR_NONE,
		SHADER_VAR_INOUT,
		SHADER_VAR_OUT,
		SHADER_VAR_UNIFORM,
		SHADER_VAR_CONST
	};

	class LIB_EXPORT ShaderSampler {
	public:
		string name;
		GSSamplerState sampler;

		inline ShaderSampler(const char* name, GSDevice* device, GSSamplerInfo& info)
			: name(name), sampler(device, info)
		{
		}
	};

	//////////////////////////////////////////////////////////////////////////
	class LIB_EXPORT shader_var {
	public:
		char* type;
		char* name;
		char* mapping;
		enum shader_var_type var_type;
		int array_count;
		size_t gl_sampler_id; /* optional: used/parsed by GL */

		std::vector<uint8_t> default_val;
	};

	class LIB_EXPORT gs_shader_param {
	public:
		string name;
		E_GSShaderParamType type;

		uint32_t textureID;
		GSSamplerState* nextSampler = nullptr;

		int arrayCount;

		size_t pos;

		vector<uint8_t> curValue;
		vector<uint8_t> defaultValue;
		bool changed;

		gs_shader_param(shader_var& var, uint32_t& texCounter);
	};

	// gs shader create from hlsl  cso file
	class LIB_EXPORT GSShader : public GSObject {
	public:
		long Create();
		long Destroy();

		inline void UpdateParam(const vector<uint8_t>& constData);
		long UploadParams();

		long BuildConstantBuffer();

		inline GSShader(GSDevice* device, E_GSType obj_type, E_GSShaderType type,
			const D3D11_BUFFER_DESC& desc, const vector<uint8_t>& inputdata);
		virtual ~GSShader();

	public:
		E_GSShaderType type_;
		vector<uint8_t> constData_;
		ComPtr<ID3D11Buffer> constants_;
		size_t constantSize_;

		D3D11_BUFFER_DESC bufDesc_ = {};
		vector<uint8_t> shaderData_;
	};

	//using GSShaderPtr = std::shared_ptr<GSShader>;
	using GSShaderPtr = GSShader*;
	//////////////////////////////////////////////////////////////////////////
	class LIB_EXPORT GSPixelShader : public GSShader {
	public:
		long Create();
		long Destroy();
		long Rebuild(ID3D11Device* dev);

		inline long Release()
		{
			shader_.Release();
			constants_.Release();
			return S_OK;
		}

		inline void GetSamplerStates(ID3D11SamplerState** states)
		{
			size_t i;
			for (i = 0; i < samplers.size(); i++)
				states[i] = samplers[i]->sampler.state_;
			for (; i < GS_MAX_TEXTURES; i++)
				states[i] = NULL;
		}

		GSPixelShader(GSDevice* device, const string& cso_file, const D3D11_BUFFER_DESC& desc,
			const vector<uint8_t>& inputdata);

	public:
		ComPtr<ID3D11PixelShader> shader_;
		vector<std::shared_ptr<ShaderSampler>> samplers;
		std::string shader_file_;
	};

	//using GSPixelShaderPtr = std::shared_ptr<GSPixelShader>;
	using GSPixelShaderPtr = GSPixelShader*;
	//////////////////////////////////////////////////////////////////////////
	class LIB_EXPORT VertexShaderConfig {
	public:
		VertexShaderConfig(
			vector<D3D11_INPUT_ELEMENT_DESC> inputs = vector<D3D11_INPUT_ELEMENT_DESC>())
			: layoutDesc_(inputs)
		{
			SetInputDesc(inputs);
		}

		void SetInputDesc(vector<D3D11_INPUT_ELEMENT_DESC> inputs)
		{
			layoutDesc_ = inputs;
			for (size_t i = 0; i < inputs.size(); i++) {
				const D3D11_INPUT_ELEMENT_DESC& input = inputs[i];
				if (strcmp(input.SemanticName, "NORMAL") == 0)
					hasNormals_ = true;
				else if (strcmp(input.SemanticName, "TANGENT") == 0)
					hasTangents_ = true;
				else if (strcmp(input.SemanticName, "COLOR") == 0)
					hasColors_ = true;
				else if (strcmp(input.SemanticName, "TEXCOORD") == 0)
					nTexUnits_++;
			}
		}

	public:
		vector<D3D11_INPUT_ELEMENT_DESC> layoutDesc_;

		bool hasNormals_ = false;
		bool hasColors_ = false;
		bool hasTangents_ = false;
		uint32_t nTexUnits_ = false;
	};

	class LIB_EXPORT GSVertexShader : public GSShader {
	public:
		long Create();
		long Destroy();

		long Rebuild(ID3D11Device* dev);

		inline long Release()
		{
			shader_.Release();
			layout_.Release();
			constants_.Release();
			return S_OK;
		}

		inline uint32_t NumBuffersExpected() const
		{
			uint32_t count = config.nTexUnits_ + 1;
			if (config.hasNormals_)
				count++;
			if (config.hasColors_)
				count++;
			if (config.hasTangents_)
				count++;

			return count;
		}

		void GetBuffersExpected(const vector<D3D11_INPUT_ELEMENT_DESC>& inputs);

		GSVertexShader(GSDevice* device, const string& cso_file, const vector<uint8_t>& inputdata,
			const D3D11_BUFFER_DESC& desc,
			const vector<D3D11_INPUT_ELEMENT_DESC>& layout);

		int SetInputLayoutDesc(const vector<D3D11_INPUT_ELEMENT_DESC>& layout);

	public:
		ComPtr<ID3D11VertexShader> shader_;
		ComPtr<ID3D11InputLayout> layout_;
		std::string shader_file_;

		matrix4 world_;
		matrix4 view_;
		matrix4 projection_;
		//gs_shader_param* world_, * viewProj_;

		VertexShaderConfig config;
	};

	//using GSVertexShaderPtr = std::shared_ptr<GSVertexShader>;
	using GSVertexShaderPtr = GSVertexShader*;
}
#endif