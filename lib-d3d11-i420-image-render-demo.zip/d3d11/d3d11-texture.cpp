#include "d3d11-texture.h"

namespace lib_d3d {
//GSTexture::GSTexture(const GSTexture& rhs)
//	: GSTexture(rhs.device_, rhs.obj_type_, rhs.type_, rhs.levels_, rhs.format_)
//{

//}

//GSTexture::GSTexture(GSTexture&& rhs)
//	: GSTexture(rhs.device_, rhs.obj_type_, rhs.type_, rhs.levels_, rhs.format_)
//{
//	move(std::forward<GSTexture>(rhs));
//}

//GSTexture& GSTexture::operator=(const GSTexture& rhs)
//{
//	copy(rhs);
//}

//GSTexture& GSTexture::operator=(GSTexture&& rhs)
//{
//	move(std::forward<GSTexture>(rhs));
//}

//void GSTexture::copy(const GSTexture& rhs)
//{
//	__super::copy(rhs);
//	//gs_texture_type type_;
//	//uint32_t levels_;
//	//gs_color_format format_;

//	//ComPtr<ID3D11ShaderResourceView> shaderRes_;
//	//ComPtr<ID3D11ShaderResourceView> shaderResLinear_;
//	type_ = rhs.type_;
//	levels_ = rhs.levels_;
//	format_ = rhs.format_;
//	shaderRes_ = rhs.shaderRes_;
//	shaderResLinear_ = rhs.shaderResLinear_;
//}

//void GSTexture::move(GSTexture&& rhs)
//{
//	__super::move(std::forward<GSObject>(rhs));
//	gs_texture_type type_;
//	uint32_t levels_;
//	gs_color_format format_;

//	ComPtr<ID3D11ShaderResourceView> shaderRes_;
//	ComPtr<ID3D11ShaderResourceView> shaderResLinear_;
//}
}