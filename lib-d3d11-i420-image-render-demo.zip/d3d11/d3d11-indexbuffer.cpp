#include "d3d11-indexbuffer.h"
#include "d3d11-device.h"

namespace lib_d3d {

GSIndexBuffer::GSIndexBuffer(GSDevice *device, uint32_t flags)
	: GSObject(device, E_GSType::kindex_buffer), dynamic_((flags & GS_DYNAMIC) != 0)
//, indexType_(type)
//, num_(num)
{
	//switch (type)
	//{
	//case GS_UNSIGNED_SHORT:
	//	indexSize_ = 2;
	//	break;
	//case GS_UNSIGNED_LONG:
	//	indexSize_ = 4;
	//	break;
	//}
}

GSIndexBuffer::~GSIndexBuffer() {}

long GSIndexBuffer::Create(index_data_ptr data)
{
	Destroy();
	index_data_ = data;
	//num_ = data->size();
	return InitBuffer();
}

long GSIndexBuffer::Destroy()
{
	return Release();
}

long GSIndexBuffer::InitBuffer()
{
	HRESULT hr = S_OK;

	auto data_len = index_data_ ? index_data_->size() : 0;
	auto data_size = data_len * sizeof(index_data::value_type);

	memset(&bufDesc_, 0, sizeof(bufDesc_));
	memset(&sourceData_, 0, sizeof(sourceData_));

	bufDesc_.Usage = dynamic_ ? D3D11_USAGE_DYNAMIC : D3D11_USAGE_DEFAULT;
	bufDesc_.CPUAccessFlags = dynamic_ ? D3D11_CPU_ACCESS_WRITE : 0;
	bufDesc_.BindFlags = D3D11_BIND_INDEX_BUFFER;
	bufDesc_.ByteWidth = UINT(data_size);
	sourceData_.pSysMem = index_data_ ? index_data_->data() : nullptr;

	hr = device_->device_->CreateBuffer(&bufDesc_, &sourceData_, indexBuffer_.Assign());
	if (FAILED(hr)) {
		device_->SetLastError(hr);
		XLOG("Failed to create buffer", hr);
	}

	return hr;
}

long GSIndexBuffer::Rebuild(ID3D11Device *dev)
{
	HRESULT hr = dev->CreateBuffer(&bufDesc_, &sourceData_, &indexBuffer_);
	if (FAILED(hr))
		XLOG("Failed to create buffer", hr);

	return hr;
}

long GSIndexBuffer::Flush(index_data_ptr data)
{
	HRESULT hr = S_OK;

	do {
		if (!dynamic_)
			break;
		if (data == nullptr) {
			data = index_data_;
		} else {
			index_data_ = data;
			//num_ = index_data_->size();
		}

		if (!data)
			break;

		D3D11_MAPPED_SUBRESOURCE map;
		hr = device_->context_->Map(indexBuffer_, 0, D3D11_MAP_WRITE_DISCARD, 0, &map);
		if (FAILED(hr))
			break;

		memcpy(map.pData, data->data(), data->size() * sizeof(index_data::value_type));

		device_->context_->Unmap(indexBuffer_, 0);

	} while (false);

	return hr;
}

long GSIndexBuffer::Release()
{
	if (indexBuffer_) {
		indexBuffer_.Release();
		indexBuffer_ = nullptr;
	}
	return 0;
}

//
//
////////////////////////////////////////////////////////////////////////////
////
//GSIndexBufferShort::GSIndexBufferShort(GSDevice* device, indexDataTypeShortPtr indices, uint32_t flags)
//: GSIndexBuffer(device, gs_index_type::GS_UNSIGNED_SHORT, indices->size(), flags)
//, indices_(indices)
//{
//	InitBuffer_(indices_->data());
//}
//
//
//long GSIndexBufferShort::Create()
//{
//	return InitBuffer();
//}
//
//long GSIndexBufferShort::Destroy()
//{
//	return Release();
//}
//
//void* GSIndexBufferShort::Data() const
//{
//	return indices_? (void*)indices_->data() : nullptr;
//}
//
////////////////////////////////////////////////////////////////////////////
//GSIndexBufferLong::GSIndexBufferLong(GSDevice *device, std::shared_ptr<indexDataTypeLong> indices, uint32_t flags)
//	: GSIndexBuffer(device, gs_index_type::GS_UNSIGNED_LONG, indices->size(), flags)
//	, indices_(indices)
//{
//	InitBuffer_(indices_->data());
//}
//
//long GSIndexBufferLong::Create()
//{
//	return InitBuffer();
//}
//
//long GSIndexBufferLong::Destroy()
//{
//	return Release();
//}
//
//void* GSIndexBufferLong::Data() const
//{
//	return indices_ ? (void*)indices_->data() : nullptr;
//}
}