#pragma once
#ifndef __X_D3D11_STATESURF_H__
#define __X_D3D11_STATESURF_H__

#include "./d3d11-subsystem.h"
namespace lib_d3d {
class LIB_EXPORT GSStageSurface : public GSObject {
public:
	long Create();
	long Destroy();

	long Rebuild(ID3D11Device *dev);

	inline long Release();

	GSStageSurface(GSDevice *device, uint32_t width, uint32_t height,
		       gs_color_format colorFormat);
	GSStageSurface(GSDevice *device, uint32_t width, uint32_t height, bool p010);

	long Map(uint8_t **data, uint32_t &linesize);
	long Unmap();

public:
	ComPtr<ID3D11Texture2D> texture_;
	D3D11_TEXTURE2D_DESC texture_desc_ = {};

	//uint32_t width_, height_;
	gs_color_format format_;
	DXGI_FORMAT dxgiFormat_;

	X_PARAM(uint32_t, width);
	X_PARAM(uint32_t, height);
};

//using GSStateSurfacePtr = std::shared_ptr<GSStageSurface>;
using GSStageSurfacePtr = GSStageSurface *;
}
#endif