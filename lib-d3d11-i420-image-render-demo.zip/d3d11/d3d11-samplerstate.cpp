/******************************************************************************
    Copyright (C) 2013 by Hugh Bailey <obs.jim@gmail.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
******************************************************************************/

#include <float.h>

#include "d3d11-samplerstate.h"
#include "d3d11-device.h"

namespace lib_d3d {
static inline D3D11_TEXTURE_ADDRESS_MODE ConvertGSAddressMode(gs_address_mode mode)
{
	switch (mode) {
	case GS_ADDRESS_WRAP:
		return D3D11_TEXTURE_ADDRESS_WRAP;
	case GS_ADDRESS_CLAMP:
		return D3D11_TEXTURE_ADDRESS_CLAMP;
	case GS_ADDRESS_MIRROR:
		return D3D11_TEXTURE_ADDRESS_MIRROR;
	case GS_ADDRESS_BORDER:
		return D3D11_TEXTURE_ADDRESS_BORDER;
	case GS_ADDRESS_MIRRORONCE:
		return D3D11_TEXTURE_ADDRESS_MIRROR_ONCE;
	}

	return D3D11_TEXTURE_ADDRESS_WRAP;
}

static inline D3D11_FILTER ConvertGSFilter(gs_sample_filter filter)
{
	switch (filter) {
	case GS_FILTER_POINT:
		return D3D11_FILTER_MIN_MAG_MIP_POINT;
	case GS_FILTER_LINEAR:
		return D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	case GS_FILTER_MIN_MAG_POINT_MIP_LINEAR:
		return D3D11_FILTER_MIN_MAG_POINT_MIP_LINEAR;
	case GS_FILTER_MIN_POINT_MAG_LINEAR_MIP_POINT:
		return D3D11_FILTER_MIN_POINT_MAG_LINEAR_MIP_POINT;
	case GS_FILTER_MIN_POINT_MAG_MIP_LINEAR:
		return D3D11_FILTER_MIN_POINT_MAG_MIP_LINEAR;
	case GS_FILTER_MIN_LINEAR_MAG_MIP_POINT:
		return D3D11_FILTER_MIN_LINEAR_MAG_MIP_POINT;
	case GS_FILTER_MIN_LINEAR_MAG_POINT_MIP_LINEAR:
		return D3D11_FILTER_MIN_LINEAR_MAG_POINT_MIP_LINEAR;
	case GS_FILTER_MIN_MAG_LINEAR_MIP_POINT:
		return D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT;
	case GS_FILTER_ANISOTROPIC:
		return D3D11_FILTER_ANISOTROPIC;
	}

	return D3D11_FILTER_MIN_MAG_MIP_POINT;
}

long GSSamplerState::Create()
{
	return Rebuild(device_->device_);
}
long GSSamplerState::Destroy()
{
	return Release();
}

static inline float gs_u8_to_float(uint8_t u)
{
	return (float)u / 255.0f;
}

static inline void gs_u8x4_to_float4(float *f, const uint8_t *u)
{
	f[0] = gs_u8_to_float(u[0]);
	f[1] = gs_u8_to_float(u[1]);
	f[2] = gs_u8_to_float(u[2]);
	f[3] = gs_u8_to_float(u[3]);
}

static inline void vec4_from_rgba(vec4 &dst, uint32_t rgba)
{
	uint8_t u[4];
	memcpy(u, &rgba, sizeof(u));
	gs_u8x4_to_float4(&dst.x, u);
}

GSSamplerState::GSSamplerState(GSDevice *device, const GSSamplerInfo &info)
	: GSObject(device, E_GSType::ksampler_state), info_(info)
{
	vec4 v4;
	memset(&sampler_desc_, 0, sizeof(sampler_desc_));
	sampler_desc_.AddressU = ConvertGSAddressMode(info.address_u);
	sampler_desc_.AddressV = ConvertGSAddressMode(info.address_v);
	sampler_desc_.AddressW = ConvertGSAddressMode(info.address_w);
	sampler_desc_.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
	sampler_desc_.Filter = ConvertGSFilter(info.filter);
	sampler_desc_.MaxAnisotropy = info.max_anisotropy;
	sampler_desc_.MaxLOD = FLT_MAX;

	vec4_from_rgba(v4, info.border_color);
	memcpy(sampler_desc_.BorderColor, &v4.x, sizeof(v4));
}

long GSSamplerState::Rebuild(ID3D11Device *dev)
{
	HRESULT hr = dev->CreateSamplerState(&sampler_desc_, state_.Assign());
	if (FAILED(hr))
		XLOG("Failed to create sampler state", hr);
	return hr;
}

inline long GSSamplerState::Release()
{
	state_.Release();
	return 0;
}

}
