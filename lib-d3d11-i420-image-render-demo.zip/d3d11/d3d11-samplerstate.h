#pragma once
#ifndef __X_D3D11_SAMPLERSTATE_H__
#define __X_D3D11_SAMPLERSTATE_H__

#include "./d3d11-subsystem.h"
namespace lib_d3d {

using GSSamplerInfo = gs_sampler_info;
class LIB_EXPORT GSSamplerState : public GSObject {
public:
	long Create();
	long Destroy();

	long Rebuild(ID3D11Device *dev);

	inline long Release();

	GSSamplerState(GSDevice *device, const GSSamplerInfo &info);

public:
	ComPtr<ID3D11SamplerState> state_;
	D3D11_SAMPLER_DESC sampler_desc_ = {};
	GSSamplerInfo info_;
};

//using GSSamplerStatePtr = std::shared_ptr<GSSamplerState>;
using GSSamplerStatePtr = GSSamplerState *;
}
#endif