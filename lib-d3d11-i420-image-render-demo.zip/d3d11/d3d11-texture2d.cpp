#include "d3d11-texture2d.h"
#include "d3d11-device.h"
#include "lib-d3d11/graphics/d3d11-helper.h"

namespace lib_d3d {

#define SHARED_FLAGS (GS_SHARED_TEX | GS_SHARED_KM_TEX)
	//long GSTexture2D::Create()
	//{
	//	HRESULT result = S_OK;
	//	do
	//	{
	//		result = InitTexture(nullptr); // use constructor data
	//		if (FAILED(result))
	//			break;
	//		result = InitResourceView();
	//		if (FAILED(result))
	//			break;

	//		if (isRenderTarget_)
	//			result = InitRenderTargets();
	//		if (FAILED(result))
	//			break;
	//	} while (false);
	//	return result;
	//}

	long GSTexture2D::Create(GSDevice* device, uint32_t width, uint32_t height,
		gs_color_format colorFormat, uint32_t levels, const uint8_t* const* data,
		uint32_t flags, gs_texture_type type, bool gdiCompatible,
		bool twoPlane /* = false*/)
	{
		HRESULT hr = S_OK;
		levels_ = levels;
		format_ = colorFormat;
		width_ = width;
		height_ = height;
		flags_ = flags;
		dxgiFormatResource_ = ConvertGSTextureFormatResource(format_);
		dxgiFormatView_ = ConvertGSTextureFormatView(format_);
		dxgiFormatViewLinear_ = ConvertGSTextureFormatViewLinear(format_);
		isRenderTarget_ = (flags & GS_RENDER_TARGET) != 0;
		isGDICompatible_ = gdiCompatible;
		isDynamic_ = (flags & GS_DYNAMIC) != 0;
		isShared_ = (flags & SHARED_FLAGS) != 0;
		genMipmaps_ = (flags & GS_BUILD_MIPMAPS) != 0;
		sharedHandle_ = GS_INVALID_HANDLE;
		twoPlane_ = twoPlane;

		if (data)
			BackupTexture(data);
		do {
			hr = InitTexture(nullptr); // use constructor data
			if (FAILED(hr))
				break;
			hr = InitResourceView();
			if (FAILED(hr))
				break;

			if (isRenderTarget_)
				hr = InitRenderTargets();
			if (FAILED(hr))
				break;
		} while (false);

		return hr;
	}

	long GSTexture2D::Create(GSDevice* device, ID3D11Texture2D* nv12tex, uint32_t flags_)
	{
		HRESULT hr = S_OK;
		isRenderTarget_ = (flags_ & GS_RENDER_TARGET) != 0;
		isDynamic_ = (flags_ & GS_DYNAMIC) != 0;
		isShared_ = (flags_ & SHARED_FLAGS) != 0;
		genMipmaps_ = (flags_ & GS_BUILD_MIPMAPS) != 0;
		twoPlane_ = true;
		texture_ = nv12tex;
		texture_->GetDesc(&texutre_desc_);

		const bool p010 = texutre_desc_.Format == DXGI_FORMAT_P010;
		const DXGI_FORMAT dxgi_format = p010 ? DXGI_FORMAT_R16G16_UNORM : DXGI_FORMAT_R8G8_UNORM;

		this->type_ = GS_TEXTURE_2D;
		this->format_ = p010 ? GS_RG16 : GS_R8G8;
		this->flags_ = flags_;
		this->levels_ = 1;
		this->device_ = device;
		this->chroma_ = true;
		this->width_ = texutre_desc_.Width / 2;
		this->height_ = texutre_desc_.Height / 2;
		this->dxgiFormatResource_ = dxgi_format;
		this->dxgiFormatView_ = dxgi_format;
		this->dxgiFormatViewLinear_ = dxgi_format;

		InitResourceView();
		if (isRenderTarget_)
			InitRenderTargets();

		return hr;
	}

	long GSTexture2D::Create(GSDevice* device, HANDLE handle, bool ntHandle)
	{
		HRESULT hr = S_OK;
		isShared_ = true;
		sharedHandle_ = handle;
		if (ntHandle) {
			ComQIPtr<ID3D11Device1> dev = (IUnknown*)device_->device_;
			hr = dev->OpenSharedResource1((HANDLE)(uintptr_t)handle, __uuidof(ID3D11Texture2D),
				(void**)texture_.Assign());
		}
		else {
			hr = device_->device_->OpenSharedResource((HANDLE)(uintptr_t)handle,
				__uuidof(ID3D11Texture2D),
				(void**)texture_.Assign());
		}

		if (SUCCEEDED(hr)) {
			texture_->GetDesc(&texutre_desc_);

			const gs_color_format format = ConvertDXGITextureFormat(texutre_desc_.Format);

			this->type_ = GS_TEXTURE_2D;
			this->format_ = format;
			this->levels_ = 1;
			this->device_ = device;

			this->width_ = texutre_desc_.Width;
			this->height_ = texutre_desc_.Height;
			this->dxgiFormatResource_ = ConvertGSTextureFormatResource(format);
			this->dxgiFormatView_ = ConvertGSTextureFormatView(format);
			this->dxgiFormatViewLinear_ = ConvertGSTextureFormatViewLinear(format);

			InitResourceView();
		}
		else {

			XLOG("Failed to open shared 2D texture", hr);
			device_->SetLastError(hr);
		}
		return hr;
	}

	long GSTexture2D::Create(GSDevice* device, ID3D11Texture2D* obj)
	{
		HRESULT hr = S_OK;
		texture_ = obj;

		texture_->GetDesc(&texutre_desc_);

		const gs_color_format format = ConvertDXGITextureFormat(texutre_desc_.Format);

		this->type_ = GS_TEXTURE_2D;
		this->format_ = format;
		this->levels_ = 1;
		this->device_ = device;

		this->width_ = texutre_desc_.Width;
		this->height_ = texutre_desc_.Height;
		this->dxgiFormatResource_ = ConvertGSTextureFormatResource(format);
		this->dxgiFormatView_ = ConvertGSTextureFormatView(format);
		this->dxgiFormatViewLinear_ = ConvertGSTextureFormatViewLinear(format);

		InitResourceView();

		return hr;
	}

	long GSTexture2D::Destroy()
	{
		HRESULT result = S_OK;
		result = Release();
		return result;
	}
	long GSTexture2D::InitSRD(vector<D3D11_SUBRESOURCE_DATA>& srd)
	{
		uint32_t rowSizeBytes = width_ * GrpahicsHelper::gs_get_format_bpp(format_);
		uint32_t texSizeBytes = height_ * rowSizeBytes / 8;
		size_t textures = type_ == GS_TEXTURE_2D ? 1 : 6;
		uint32_t actual_levels = levels_;
		size_t curTex = 0;

		if (!actual_levels)
			actual_levels = GrpahicsHelper::gs_get_total_levels(width_, height_, 1);

		rowSizeBytes /= 8;

		for (size_t i = 0; i < textures; i++) {
			uint32_t newRowSize = rowSizeBytes;
			uint32_t newTexSize = texSizeBytes;

			for (uint32_t j = 0; j < actual_levels; j++) {
				D3D11_SUBRESOURCE_DATA newSRD;
				newSRD.pSysMem = data_[curTex++].data();
				newSRD.SysMemPitch = newRowSize;
				newSRD.SysMemSlicePitch = newTexSize;
				srd.push_back(newSRD);

				newRowSize /= 2;
				newTexSize /= 4;
			}
		}
		HRESULT hr = S_OK;

		return hr;
	}

	long GSTexture2D::BackupTexture(DataType data)
	{
		uint32_t textures = type_ == GS_TEXTURE_CUBE ? 6 : 1;
		uint32_t bbp = GrpahicsHelper::gs_get_format_bpp(format_);

		this->data_.resize(levels_ * textures);

		for (uint32_t t = 0; t < textures; t++) {
			uint32_t w = width_;
			uint32_t h = height_;

			for (uint32_t lv = 0; lv < levels_; lv++) {
				uint32_t i = levels_ * t + lv;
				if (!data[i])
					break;

				uint32_t texSize = bbp * w * h / 8;

				vector<uint8_t>& subData = this->data_[i];
				subData.resize(texSize);
				memcpy(&subData[0], data[i], texSize);

				if (w > 1)
					w /= 2;
				if (h > 1)
					h /= 2;
			}
		}
		return 0;
	}

	long GSTexture2D::GetSharedHandle(IDXGIResource* dxgi_res)
	{
		HANDLE handle = INVALID_HANDLE_VALUE;
		HRESULT hr = S_OK;

		hr = dxgi_res->GetSharedHandle(&handle);
		if (FAILED(hr)) {
			XLOG(LOG_WARNING,
				"GetSharedHandle: Failed to "
				"get shared handle: %08lX",
				hr);
		}
		else {
			sharedHandle_ = handle;
		}

		return hr;
	}

	void GSTexture2D::RebuildSharedTextureFallback()
	{
		static const gs_color_format format = GS_BGRA;
		static const DXGI_FORMAT dxgi_format_resource = ConvertGSTextureFormatResource(format);
		static const DXGI_FORMAT dxgi_format_view = ConvertGSTextureFormatView(format);
		static const DXGI_FORMAT dxgi_format_view_linear = ConvertGSTextureFormatViewLinear(format);

		texutre_desc_ = {};
		texutre_desc_.Width = 2;
		texutre_desc_.Height = 2;
		texutre_desc_.MipLevels = 1;
		texutre_desc_.Format = dxgi_format_resource;
		texutre_desc_.ArraySize = 1;
		texutre_desc_.SampleDesc.Count = 1;
		texutre_desc_.BindFlags = D3D11_BIND_SHADER_RESOURCE;

		width_ = texutre_desc_.Width;
		height_ = texutre_desc_.Height;
		dxgiFormatResource_ = dxgi_format_resource;
		dxgiFormatView_ = dxgi_format_view;
		dxgiFormatViewLinear_ = dxgi_format_view_linear;
		levels_ = 1;

		viewDesc_ = {};
		viewDesc_.Format = dxgi_format_view;
		viewDesc_.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
		viewDesc_.Texture2D.MipLevels = 1;

		viewDescLinear_ = viewDesc_;
		viewDescLinear_.Format = dxgi_format_view_linear;

		isShared_ = false;
	}

	int texture_acquire_sync(GSTexture2D* tex, uint64_t key, uint32_t ms)
	{

		if (tex->acquired_)
			return 0;

		ComQIPtr<IDXGIKeyedMutex> keyedMutex(tex->texture_);
		if (!keyedMutex)
			return -1;

		HRESULT hr = keyedMutex->AcquireSync(key, ms);
		if (hr == S_OK) {
			tex->acquired_ = true;
			return 0;
		}
		else if (hr == WAIT_TIMEOUT) {
			return ETIMEDOUT;
		}

		return -1;
	}

	long GSTexture2D::Rebuild(ID3D11Device* dev)
	{
		HRESULT hr;
		if (isShared_) {
			hr = dev->OpenSharedResource((HANDLE)(uintptr_t)sharedHandle_,
				__uuidof(ID3D11Texture2D), (void**)&texture_);
			if (FAILED(hr)) {
				XLOG(LOG_WARNING, "Failed to rebuild shared texture: 0x%08lX", hr);
				RebuildSharedTextureFallback();
			}
		}

		do {
			if (!isShared_) {
				hr = dev->CreateTexture2D(&texutre_desc_,
					data_.size() ? subsource_data_.data() : nullptr,
					&texture_);
				if (FAILED(hr)) {
					XLOG("Failed to create 2D texture", hr);
					break;
				}
			}

			hr = dev->CreateShaderResourceView(texture_, &viewDesc_, &shaderRes_);
			if (FAILED(hr)) {
				XLOG("Failed to create SRV", hr);
				break;
			}

			if (viewDesc_.Format == viewDescLinear_.Format) {
				shaderResLinear_ = shaderRes_;
			}
			else {
				hr = dev->CreateShaderResourceView(texture_, &viewDescLinear_,
					&shaderResLinear_);
				if (FAILED(hr)) {
					XLOG("Failed to create linear SRV", hr);
					break;
				}
			}

			if (isRenderTarget_)
				InitRenderTargets();

			if (isGDICompatible_) {
				hr = texture_->QueryInterface(__uuidof(IDXGISurface1),
					(void**)&gdiSurface_);
				if (FAILED(hr)) {
					XLOG("Failed to create GDI surface", hr);
					break;
				}
			}

			acquired_ = false;

			if ((texutre_desc_.MiscFlags & D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX) != 0) {
				ComQIPtr<IDXGIResource> dxgi_res(texture_);
				if (dxgi_res)
					GetSharedHandle(dxgi_res);
				// sub system
				texture_acquire_sync(this, 0, INFINITE);
			}
		} while (false);

		return hr;
	}

	long GSTexture2D::RebuildPaired_Y(ID3D11Device* dev)
	{
		GSTexture2D* tex_uv = pairedTexture_;
		HRESULT hr = S_OK;

		do {
			hr = dev->CreateTexture2D(&texutre_desc_, nullptr, &texture_);
			if (FAILED(hr)) {
				XLOG("Failed to create 2D texture", hr);
				break;
			}

			hr = dev->CreateShaderResourceView(texture_, &viewDesc_, &shaderRes_);
			if (FAILED(hr)) {
				XLOG("Failed to create Y SRV", hr);
				break;
			}

			if (viewDesc_.Format == viewDescLinear_.Format) {
				shaderResLinear_ = shaderRes_;
			}
			else {
				hr = dev->CreateShaderResourceView(texture_, &viewDescLinear_,
					&shaderResLinear_);
				if (FAILED(hr)) {
					XLOG("Failed to create linear Y SRV", hr);
					break;
				}
			}

			if (isRenderTarget_)
				hr = InitRenderTargets();
			if (FAILED(hr)) {
				XLOG("Failed to InitRenderTargets", hr);
				break;
			}

			tex_uv->RebuildPaired_UV(dev);

			acquired_ = false;

			if ((texutre_desc_.MiscFlags & D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX) != 0) {
				ComQIPtr<IDXGIResource> dxgi_res(texture_);
				if (dxgi_res)
					GetSharedHandle(dxgi_res);
				texture_acquire_sync(this, 0, INFINITE);
			}
		} while (false);
		return hr;
	}

	long GSTexture2D::RebuildPaired_UV(ID3D11Device* dev)
	{
		GSTexture2D* tex_y = pairedTexture_;
		HRESULT hr = S_OK;

		texture_ = tex_y->texture_;

		do {
			hr = dev->CreateShaderResourceView(texture_, &viewDesc_, &shaderRes_);
			if (FAILED(hr)) {
				XLOG("Failed to create UV SRV", hr);
				break;
			}

			if (viewDesc_.Format == viewDescLinear_.Format) {
				shaderResLinear_ = shaderRes_;
			}
			else {
				hr = dev->CreateShaderResourceView(texture_, &viewDescLinear_,
					&shaderResLinear_);
				if (FAILED(hr)) {
					XLOG("Failed to create linear UV SRV", hr);
					break;
				}
			}

			if (isRenderTarget_)
				hr = InitRenderTargets();
			if (FAILED(hr)) {
				XLOG("Failed to InitRenderTargets", hr);
				break;
			}
		} while (false);

		return hr;
	}

	long GSTexture2D::Map(uint8_t** ptr, uint32_t& linesize)
	{
		D3D11_MAPPED_SUBRESOURCE map;
		HRESULT hr = device_->context_->Map(texture_, 0, D3D11_MAP_WRITE_DISCARD, 0, &map);
		if (FAILED(hr))
			return false;

		*ptr = (uint8_t*)map.pData;
		linesize = map.RowPitch;

		return hr;
	}

	long GSTexture2D::Unmap()
	{
		device_->context_->Unmap(texture_, 0);
		HRESULT hr = S_OK;

		return hr;
	}

	long GSTexture2D::Flush(const uint8_t* const* data, uint32_t linesize /* = 0*/)
	{

		HRESULT hr = S_OK;
		const uint8_t* src = data[0];
		uint8_t* pData = nullptr;
		uint32_t gpuLinesize = 0;

		Map(&pData, gpuLinesize);

		do {
			if (gpuLinesize == 0)
				break;

			uint32_t w = width_;
			uint32_t h = height_;
			uint32_t bbp = GrpahicsHelper::gs_get_format_bpp(format_);
			uint32_t texSize = bbp * w * h / 8;

			if (gpuLinesize == linesize) {
				memcpy(pData, src, texSize);
			}
			else {
				for (uint32_t i = 0; i < h; ++i) {
					memcpy(pData, src, bbp * w / 8);
					pData += gpuLinesize;
					src += linesize;
				}
			}

		} while (false);

		Unmap();
		return hr;
	}
	ID3D11ShaderResourceView* GSTexture2D::ResourceView() const
	{
		return shaderRes_;
	}

	long GSTexture2D::InitTexture(DataType data /* = nullptr */)
	{
		HRESULT hr = S_OK;

		memset(&texutre_desc_, 0, sizeof(texutre_desc_));
		texutre_desc_.Width = width_;
		texutre_desc_.Height = height_;
		texutre_desc_.MipLevels = genMipmaps_ ? 0 : levels_;
		texutre_desc_.ArraySize = type_ == GS_TEXTURE_CUBE ? 6 : 1;
		texutre_desc_.Format = twoPlane_
			? ((format_ == GS_R16) ? DXGI_FORMAT_P010 : DXGI_FORMAT_NV12)
			: dxgiFormatResource_;
		texutre_desc_.BindFlags = D3D11_BIND_SHADER_RESOURCE;
		texutre_desc_.SampleDesc.Count = 1;
		texutre_desc_.CPUAccessFlags = isDynamic_ ? D3D11_CPU_ACCESS_WRITE : 0;
		texutre_desc_.Usage = isDynamic_ ? D3D11_USAGE_DYNAMIC : D3D11_USAGE_DEFAULT;

		if (type_ == GS_TEXTURE_CUBE)
			texutre_desc_.MiscFlags |= D3D11_RESOURCE_MISC_TEXTURECUBE;

		if (isRenderTarget_ || isGDICompatible_)
			texutre_desc_.BindFlags |= D3D11_BIND_RENDER_TARGET;

		if (isGDICompatible_)
			texutre_desc_.MiscFlags |= D3D11_RESOURCE_MISC_GDI_COMPATIBLE;

		if ((flags_ & GS_SHARED_KM_TEX) != 0)
			texutre_desc_.MiscFlags |= D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
		else if ((flags_ & GS_SHARED_TEX) != 0)
			texutre_desc_.MiscFlags |= D3D11_RESOURCE_MISC_SHARED;

		do {

			if (data) {
				BackupTexture(data); // back to data_
			}
			if (!data_.empty()) {
				InitSRD(subsource_data_);
			}

			hr = device_->device_->CreateTexture2D(
				&texutre_desc_, data ? subsource_data_.data() : NULL, texture_.Assign());
			if (FAILED(hr)) {
				XLOG("Failed to create 2D texture", hr);
				break;
			}

			if (isGDICompatible_) {
				hr = texture_->QueryInterface(__uuidof(IDXGISurface1),
					(void**)gdiSurface_.Assign());
				if (FAILED(hr)) {
					XLOG("Failed to create GDI surface", hr);
					break;
				}
			}

			if (isShared_) {
				ComPtr<IDXGIResource> dxgi_res;

				texture_->SetEvictionPriority(DXGI_RESOURCE_PRIORITY_MAXIMUM);

				hr = texture_->QueryInterface(__uuidof(IDXGIResource), (void**)&dxgi_res);
				if (FAILED(hr)) {
					XLOG(LOG_WARNING,
						"InitTexture: Failed to query "
						"interface: %08lX",
						hr);
					break;
				}
				else {
					hr = GetSharedHandle(dxgi_res);

					if (FAILED(hr)) {
						break;
					}
					if (flags_ & GS_SHARED_KM_TEX) {
						ComPtr<IDXGIKeyedMutex> km;
						hr = texture_->QueryInterface(__uuidof(IDXGIKeyedMutex),
							(void**)&km);
						if (FAILED(hr)) {
							XLOG("Failed to query "
								"IDXGIKeyedMutex",
								hr);
							break;
						}

						km->AcquireSync(0, INFINITE);
						acquired_ = true;
					}
				}
			}
		} while (false);

		if (FAILED(hr)) {
			device_->SetLastError(hr);
		}

		return hr;
	}

	long GSTexture2D::InitResourceView()
	{
		HRESULT hr = S_OK;

		memset(&viewDesc_, 0, sizeof(viewDesc_));
		viewDesc_.Format = dxgiFormatView_;

		if (type_ == GS_TEXTURE_CUBE) {
			viewDesc_.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE;
			viewDesc_.TextureCube.MipLevels = genMipmaps_ || !levels_ ? -1 : levels_;
		}
		else {
			viewDesc_.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
			viewDesc_.Texture2D.MipLevels = genMipmaps_ || !levels_ ? -1 : levels_;
		}

		do {
			hr = device_->device_->CreateShaderResourceView(texture_, &viewDesc_,
				shaderRes_.Assign());
			if (FAILED(hr)) {
				XLOG("Failed to create SRV", hr);
				break;
			}

			viewDescLinear_ = viewDesc_;
			viewDescLinear_.Format = dxgiFormatViewLinear_;

			if (dxgiFormatView_ == dxgiFormatViewLinear_) {
				shaderResLinear_ = shaderRes_;
			}
			else {
				hr = device_->device_->CreateShaderResourceView(texture_, &viewDescLinear_,
					shaderResLinear_.Assign());
				if (FAILED(hr)) {
					XLOG("Failed to create linear SRV", hr);
					break;
				}
			}
		} while (false);
		if (FAILED(hr)) {
			device_->SetLastError(hr);
		}
		return hr;
	}

	long GSTexture2D::InitRenderTargets()
	{
		HRESULT hr = S_OK;

		do {
			if (type_ == GS_TEXTURE_2D) {
				D3D11_RENDER_TARGET_VIEW_DESC rtv;
				rtv.Format = dxgiFormatView_;
				rtv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
				rtv.Texture2D.MipSlice = 0;

				hr = device_->device_->CreateRenderTargetView(texture_, &rtv,
					renderTarget_[0].Assign());
				if (FAILED(hr)) {
					XLOG("Failed to create RTV", hr);
					break;
				}
				if (dxgiFormatView_ == dxgiFormatViewLinear_) {
					renderTargetLinear_[0] = renderTarget_[0];
				}
				else {
					rtv.Format = dxgiFormatViewLinear_;
					hr = device_->device_->CreateRenderTargetView(
						texture_, &rtv, renderTargetLinear_[0].Assign());
					if (FAILED(hr)) {
						XLOG("Failed to create linear RTV", hr);
						break;
					}
				}
			}
			else {
				D3D11_RENDER_TARGET_VIEW_DESC rtv;
				rtv.Format = dxgiFormatView_;
				rtv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DARRAY;
				rtv.Texture2DArray.MipSlice = 0;
				rtv.Texture2DArray.ArraySize = 1;

				for (UINT i = 0; i < 6; i++) {
					rtv.Texture2DArray.FirstArraySlice = i;
					hr = device_->device_->CreateRenderTargetView(
						texture_, &rtv, renderTarget_[i].Assign());
					if (FAILED(hr)) {
						XLOG("Failed to create cube RTV", hr);
						break;
					}
					if (dxgiFormatView_ == dxgiFormatViewLinear_) {
						renderTargetLinear_[i] = renderTarget_[i];
					}
					else {
						rtv.Format = dxgiFormatViewLinear_;
						hr = device_->device_->CreateRenderTargetView(
							texture_, &rtv, renderTargetLinear_[i].Assign());
						if (FAILED(hr)) {
							XLOG("Failed to create linear cube RTV", hr);
							break;
						}
					}
				}
			}
		} while (false);

		if (FAILED(hr)) {
			device_->SetLastError(hr);
		}
		return hr;
	}

	//GSTexture2D::GSTexture2D(GSDevice* device, uint32_t width, uint32_t height, gs_color_format colorFormat, uint32_t levels, const uint8_t* const* data, uint32_t flags, gs_texture_type type,
	//	bool gdiCompatible, bool twoPlane_)
	//	: GSTexture(device, E_GSType::ktexture_2d, type, levels, colorFormat),
	//	width_(width),
	//	height_(height),
	//	flags_(flags),
	//	dxgiFormatResource_(ConvertGSTextureFormatResource(format_)),
	//	dxgiFormatView_(ConvertGSTextureFormatView(format_)),
	//	dxgiFormatViewLinear_(ConvertGSTextureFormatViewLinear(format_)),
	//	isRenderTarget_((flags& GS_RENDER_TARGET) != 0),
	//	isGDICompatible_(gdiCompatible),
	//	isDynamic_((flags& GS_DYNAMIC) != 0),
	//	isShared_((flags& SHARED_FLAGS) != 0),
	//	genMipmaps_((flags& GS_BUILD_MIPMAPS) != 0),
	//	sharedHandle_(GS_INVALID_HANDLE),
	//	twoPlane_(twoPlane_)
	//{
	//	if (data)
	//		BackupTexture(data);
	//}

	//GSTexture2D::GSTexture2D(GSDevice* device, ID3D11Texture2D* nv12tex, uint32_t flags_)
	//	: GSTexture(device, E_GSType::ktexture_2d, GS_TEXTURE_2D),
	//	isRenderTarget_((flags_& GS_RENDER_TARGET) != 0),
	//	isDynamic_((flags_& GS_DYNAMIC) != 0),
	//	isShared_((flags_& SHARED_FLAGS) != 0),
	//	genMipmaps_((flags_& GS_BUILD_MIPMAPS) != 0),
	//	twoPlane_(true),
	//	texture_(nv12tex)
	//{
	//	texture_->GetDesc(&texutre_desc_);

	//	const bool p010 = texutre_desc_.Format == DXGI_FORMAT_P010;
	//	const DXGI_FORMAT dxgi_format = p010 ? DXGI_FORMAT_R16G16_UNORM : DXGI_FORMAT_R8G8_UNORM;

	//	this->type_ = GS_TEXTURE_2D;
	//	this->format_ = p010 ? GS_RG16 : GS_R8G8;
	//	this->flags_ = flags_;
	//	this->levels_ = 1;
	//	this->device_ = device;
	//	this->chroma_ = true;
	//	this->width_ = texutre_desc_.Width / 2;
	//	this->height_ = texutre_desc_.Height / 2;
	//	this->dxgiFormatResource_ = dxgi_format;
	//	this->dxgiFormatView_ = dxgi_format;
	//	this->dxgiFormatViewLinear_ = dxgi_format;

	//	InitResourceView();
	//	if (isRenderTarget_)
	//		InitRenderTargets();
	//}

	//GSTexture2D::GSTexture2D(GSDevice* device, uint32_t handle, bool ntHandle)
	//	: GSTexture(device, E_GSType::ktexture_2d, GS_TEXTURE_2D)
	//	, isShared_(true)
	//	, sharedHandle_(handle)
	//{
	//	HRESULT hr = S_OK;
	//	if (ntHandle)
	//	{
	//		ComQIPtr<ID3D11Device1> dev = (IUnknown*)device_->device_;
	//		hr = dev->OpenSharedResource1((HANDLE)(uintptr_t)handle, __uuidof(ID3D11Texture2D), (void**)texture_.Assign());
	//	}
	//	else
	//	{
	//		hr = device_->device_->OpenSharedResource((HANDLE)(uintptr_t)handle, __uuidof(ID3D11Texture2D), (void**)texture_.Assign());
	//	}

	//	if (SUCCEEDED(hr))
	//	{
	//		texture_->GetDesc(&texutre_desc_);

	//		const gs_color_format format = ConvertDXGITextureFormat(texutre_desc_.Format);

	//		this->type_ = GS_TEXTURE_2D;
	//		this->format_ = format;
	//		this->levels_ = 1;
	//		this->device_ = device;

	//		this->width_ = texutre_desc_.Width;
	//		this->height_ = texutre_desc_.Height;
	//		this->dxgiFormatResource_ = ConvertGSTextureFormatResource(format);
	//		this->dxgiFormatView_ = ConvertGSTextureFormatView(format);
	//		this->dxgiFormatViewLinear_ = ConvertGSTextureFormatViewLinear(format);

	//		InitResourceView();
	//	}
	//	else
	//	{

	//		XLOG("Failed to open shared 2D texture", hr);
	//		device_->SetLastError(hr);
	//	}

	//}

	//GSTexture2D::GSTexture2D(GSDevice* device, ID3D11Texture2D* obj)
	//	: GSTexture(device, E_GSType::ktexture_2d, GS_TEXTURE_2D)
	//{
	//	texture_ = obj;

	//	texture_->GetDesc(&texutre_desc_);

	//	const gs_color_format format = ConvertDXGITextureFormat(texutre_desc_.Format);

	//	this->type_ = GS_TEXTURE_2D;
	//	this->format_ = format;
	//	this->levels_ = 1;
	//	this->device_ = device;

	//	this->width_ = texutre_desc_.Width;
	//	this->height_ = texutre_desc_.Height;
	//	this->dxgiFormatResource_ = ConvertGSTextureFormatResource(format);
	//	this->dxgiFormatView_ = ConvertGSTextureFormatView(format);
	//	this->dxgiFormatViewLinear_ = ConvertGSTextureFormatViewLinear(format);

	//	InitResourceView();
	//}

	//GSTexture2D::GSTexture2D(const GSTexture2D& rhs)
	//	: GSTexture(rhs)
	//{
	//	copy(rhs);
	//}

	//GSTexture2D::GSTexture2D(GSTexture2D&& rhs)
	//	: GSTexture(rhs)
	//{
	//	move(std::forward<GSTexture2D>(rhs));
	//}

	//GSTexture2D& GSTexture2D::operator=(const GSTexture2D& rhs)
	//{
	//	copy(rhs);
	//}

	//GSTexture2D& GSTexture2D::operator=(GSTexture2D&& rhs)
	//{
	//	move(std::forward<GSTexture2D>(rhs));
	//}

	//void GSTexture2D::copy(const GSTexture2D& rhs)
	//{

	//}

	//void GSTexture2D::move(GSTexture2D&& rhs)
	//{

	//}
}