#include "d3d11-timer.h"
#include "d3d11-device.h"

namespace lib_d3d {

GSTimer::GSTimer(GSDevice *device) : GSObject(device, E_GSType::ktimer) {}

GSTimer::~GSTimer() {}

long GSTimer::Create()
{
	HRESULT result = S_OK;
	result = Rebuild(device_->device_);
	return result;
}
long GSTimer::Destroy()
{
	HRESULT result = S_OK;

	return result;
}

long GSTimer::Rebuild(ID3D11Device *dev)
{
	HRESULT result = S_OK;
	D3D11_QUERY_DESC desc;
	desc.Query = D3D11_QUERY_TIMESTAMP;
	desc.MiscFlags = 0;

	do {
		result = dev->CreateQuery(&desc, &query_begin);
		if (FAILED(result)) {
			XLOG("Failed to create timer", result);
			break;
		}
		result = dev->CreateQuery(&desc, &query_end);
		if (FAILED(result)) {
			XLOG("Failed to create timer", result);
			break;
		}
	} while (false);

	return result;
}

long GSTimer::Release()
{
	HRESULT result = S_OK;
	query_begin.Release();
	query_end.Release();
	return result;
}

long GSTimer::Begin()
{
	HRESULT hr = S_OK;
	device_->context_->End(query_begin);
	return hr;
}

long GSTimer::End()
{
	HRESULT hr = S_OK;
	device_->context_->End(query_end);
	return hr;
}

long GSTimer::GetTicks(uint64_t &ticks)
{
	HRESULT hr = S_OK;
	do {
		uint64_t begin, end;
		do {
			hr = device_->context_->GetData(query_begin, &begin, sizeof(begin), 0);
		} while (hr == S_FALSE);

		if (FAILED(hr))
			break;
		do {
			hr = device_->context_->GetData(query_end, &end, sizeof(end), 0);
		} while (hr == S_FALSE);

		if (FAILED(hr))
			break;
		ticks = end - begin;
	} while (false);
	return hr;
}
//////////////////////////////////////////////////////////////////////////

GSTimerRange::GSTimerRange(GSDevice *device) : GSObject(device, E_GSType::ktimer_range) {}
GSTimerRange::~GSTimerRange() {}

long GSTimerRange::Create()
{

	return Rebuild(device_->device_);
}

long GSTimerRange::Destroy()
{
	return Release();
}

long GSTimerRange::Begin()
{
	HRESULT hr = S_OK;
	device_->context_->Begin(query_disjoint);
	return hr;
}

long GSTimerRange::End()
{
	HRESULT hr = S_OK;
	device_->context_->End(query_disjoint);
	return hr;
}

long GSTimerRange::GetTicks(bool &disjoint, uint64_t &frequency)
{
	HRESULT hr = S_OK;

	do {
		D3D11_QUERY_DATA_TIMESTAMP_DISJOINT timestamp_disjoint;
		do {
			hr = device_->context_->GetData(query_disjoint, &timestamp_disjoint,
							sizeof(timestamp_disjoint), 0);
		} while (hr == S_FALSE);

		if (FAILED(hr))
			break;
		disjoint = timestamp_disjoint.Disjoint;
		frequency = timestamp_disjoint.Frequency;

	} while (false);
	return hr;
}

long GSTimerRange::Rebuild(ID3D11Device *dev)
{
	D3D11_QUERY_DESC desc;
	desc.Query = D3D11_QUERY_TIMESTAMP_DISJOINT;
	desc.MiscFlags = 0;
	HRESULT hr = dev->CreateQuery(&desc, &query_disjoint);
	if (FAILED(hr))
		XLOG("Failed to create timer", hr);

	return hr;
}

inline long GSTimerRange::Release()
{
	query_disjoint.Release();
	return 0;
}
}