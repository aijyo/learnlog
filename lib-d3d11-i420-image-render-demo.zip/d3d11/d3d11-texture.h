#pragma once
#ifndef __X_D3D11_TEXTURE_H__
#define __X_D3D11_TEXTURE_H__

#include "./d3d11-subsystem.h"

namespace lib_d3d {
class LIB_EXPORT GSTexture : public GSObject {
public:
	using TextureData = std::vector<std::vector<uint8_t>>;
	//using TextureDataPtr = std::shared_ptr<TextureData>;
public:
	long Rebuild(ID3D11Device *dev) { return S_OK; };

	inline GSTexture(gs_texture_type type, uint32_t levels, gs_color_format format)
		: type_(type), levels_(levels), format_(format)
	{
	}

	inline GSTexture(GSDevice *device, E_GSType obj_type, gs_texture_type type)
		: GSObject(device, obj_type), type_(type)
	{
	}

	inline GSTexture(GSDevice *device, E_GSType obj_type, gs_texture_type type, uint32_t levels,
			 gs_color_format format)
		: GSObject(device, obj_type), type_(type), levels_(levels), format_(format)
	{
	}

	//	inline GSTexture(const GSTexture& rhs);
	//	inline GSTexture(GSTexture&& rhs);

	//	GSTexture& operator=(const GSTexture& rhs);
	//	GSTexture& operator=(GSTexture&& rhs);

	//protected:
	//	virtual void copy(const GSTexture& rhs);
	//	virtual void move(GSTexture&& rhs);

public:
	gs_texture_type type_;
	uint32_t levels_;
	gs_color_format format_;

	ComPtr<ID3D11ShaderResourceView> shaderRes_;
	ComPtr<ID3D11ShaderResourceView> shaderResLinear_;
	D3D11_SHADER_RESOURCE_VIEW_DESC viewDesc_{};
	D3D11_SHADER_RESOURCE_VIEW_DESC viewDescLinear_{};
};

//using GSTexturePtr = std::shared_ptr<GSTexture>;
using GSTexturePtr = GSTexture *;
}
#endif