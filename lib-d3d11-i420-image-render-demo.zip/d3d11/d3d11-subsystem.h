#pragma once
#ifndef __D3D11_SUBSYSTEM_H__
#define __D3D11_SUBSYSTEM_H__

#include <vector>
#include <cstdint>
#include <memory>

#include <windows.h>
#include <dxgi1_6.h>
#include <d3d11_1.h>
#include <d3dcompiler.h>

#include "lib-d3d11/d3d-common/lib-common.h"
//#include "lib-d3d11-types.h"
#include "lib-d3d11/d3d11/d3d11-object.h"

using namespace std;
using namespace x_util::win32;

namespace lib_d3d {

	// class
	class GSDevice;
	class GSTexture;
	class GSVertexData;

	//////////////////////////////////////////////////////////////////////////
	class LIB_EXPORT BlendState {
	public:
		inline BlendState()
			: blendEnabled(true),
			srcFactorC(GS_BLEND_SRCALPHA),
			destFactorC(GS_BLEND_INVSRCALPHA),
			srcFactorA(GS_BLEND_ONE),
			destFactorA(GS_BLEND_INVSRCALPHA),
			op(GS_BLEND_OP_ADD),
			redEnabled(true),
			greenEnabled(true),
			blueEnabled(true),
			alphaEnabled(true)
		{
		}

		inline BlendState(const BlendState& state)
			: blendEnabled(state.blendEnabled),
			srcFactorC(state.srcFactorC),
			destFactorC(state.destFactorC),
			srcFactorA(state.srcFactorA),
			destFactorA(state.destFactorA),
			op(state.op),
			redEnabled(state.redEnabled),
			greenEnabled(state.greenEnabled),
			blueEnabled(state.blueEnabled),
			alphaEnabled(state.alphaEnabled)
		{
		}

	public:
		bool blendEnabled;
		gs_blend_type srcFactorC;
		gs_blend_type destFactorC;
		gs_blend_type srcFactorA;
		gs_blend_type destFactorA;
		gs_blend_op_type op;

		bool redEnabled;
		bool greenEnabled;
		bool blueEnabled;
		bool alphaEnabled;
	};

	class LIB_EXPORT SavedBlendState : public BlendState {
	public:
		long Rebuild(ID3D11Device* dev);

		inline long Release()
		{
			state.Release();
			return S_OK;
		}

		inline SavedBlendState(const BlendState& val, D3D11_BLEND_DESC& desc)
			: BlendState(val), bd(desc)
		{
		}

	public:
		ComPtr<ID3D11BlendState> state;
		D3D11_BLEND_DESC bd;
	};

	//////////////////////////////////////////////////////////////////////////
	//
	class LIB_EXPORT StencilSide {
	public:
		inline StencilSide() : test(GS_ALWAYS), fail(GS_KEEP), zfail(GS_KEEP), zpass(GS_KEEP) {}

	public:
		gs_depth_test test;
		gs_stencil_op_type fail;
		gs_stencil_op_type zfail;
		gs_stencil_op_type zpass;
	};

	class LIB_EXPORT ZStencilState {
	public:
		inline ZStencilState()
			: depthEnabled(true),
			depthWriteEnabled(true),
			depthFunc(GS_LESS),
			stencilEnabled(false),
			stencilWriteEnabled(true)
		{
		}

		inline ZStencilState(const ZStencilState& state)
		{
			memcpy(this, &state, sizeof(ZStencilState));
		}

	public:
		bool depthEnabled;
		bool depthWriteEnabled;
		gs_depth_test depthFunc;

		bool stencilEnabled;
		bool stencilWriteEnabled;
		StencilSide stencilFront;
		StencilSide stencilBack;
	};

	class LIB_EXPORT SavedZStencilState : public ZStencilState {
	public:
		ComPtr<ID3D11DepthStencilState> state;
		D3D11_DEPTH_STENCIL_DESC dsd;

		long Rebuild(ID3D11Device* dev);

		inline long Release()
		{
			state.Release();
			return S_OK;
		}

		inline SavedZStencilState(const ZStencilState& val, D3D11_DEPTH_STENCIL_DESC desc)
			: ZStencilState(val), dsd(desc)
		{
		}
	};

	//////////////////////////////////////////////////////////////////////////
	class LIB_EXPORT RasterState {
	public:
		gs_cull_mode cullMode;
		bool scissorEnabled;

		inline RasterState() : cullMode(GS_BACK), scissorEnabled(false) {}

		inline RasterState(const RasterState& state) { memcpy(this, &state, sizeof(RasterState)); }
	};

	class LIB_EXPORT SavedRasterState : RasterState {
	public:
		ComPtr<ID3D11RasterizerState> state;
		D3D11_RASTERIZER_DESC rd;

		long Rebuild(ID3D11Device* dev);

		inline long Release()
		{
			state.Release();
			return S_OK;
		}

		inline SavedRasterState(const RasterState& val, D3D11_RASTERIZER_DESC& desc)
			: RasterState(val), rd(desc)
		{
		}
	};

	// translate

	static inline D3D11_COMPARISON_FUNC ConvertGSDepthTest(gs_depth_test test)
	{
		switch (test) {
		case GS_NEVER:
			return D3D11_COMPARISON_NEVER;
		case GS_LESS:
			return D3D11_COMPARISON_LESS;
		case GS_LEQUAL:
			return D3D11_COMPARISON_LESS_EQUAL;
		case GS_EQUAL:
			return D3D11_COMPARISON_EQUAL;
		case GS_GEQUAL:
			return D3D11_COMPARISON_GREATER_EQUAL;
		case GS_GREATER:
			return D3D11_COMPARISON_GREATER;
		case GS_NOTEQUAL:
			return D3D11_COMPARISON_NOT_EQUAL;
		case GS_ALWAYS:
			return D3D11_COMPARISON_ALWAYS;
		}

		return D3D11_COMPARISON_NEVER;
	}

	static inline D3D11_STENCIL_OP ConvertGSStencilOp(gs_stencil_op_type op)
	{
		switch (op) {
		case GS_KEEP:
			return D3D11_STENCIL_OP_KEEP;
		case GS_ZERO:
			return D3D11_STENCIL_OP_ZERO;
		case GS_REPLACE:
			return D3D11_STENCIL_OP_REPLACE;
		case GS_INCR:
			return D3D11_STENCIL_OP_INCR;
		case GS_DECR:
			return D3D11_STENCIL_OP_DECR;
		case GS_INVERT:
			return D3D11_STENCIL_OP_INVERT;
		}

		return D3D11_STENCIL_OP_KEEP;
	}

	static inline D3D11_CULL_MODE ConvertGSCullMode(gs_cull_mode mode)
	{
		switch (mode) {
		case GS_BACK:
			return D3D11_CULL_BACK;
		case GS_FRONT:
			return D3D11_CULL_FRONT;
		case GS_NEITHER:
			return D3D11_CULL_NONE;
		}

		return D3D11_CULL_BACK;
	}

	static inline D3D11_BLEND_OP ConvertGSBlendOpType(gs_blend_op_type type)
	{
		switch (type) {
		case GS_BLEND_OP_ADD:
			return D3D11_BLEND_OP_ADD;
		case GS_BLEND_OP_SUBTRACT:
			return D3D11_BLEND_OP_SUBTRACT;
		case GS_BLEND_OP_REVERSE_SUBTRACT:
			return D3D11_BLEND_OP_REV_SUBTRACT;
		case GS_BLEND_OP_MIN:
			return D3D11_BLEND_OP_MIN;
		case GS_BLEND_OP_MAX:
			return D3D11_BLEND_OP_MAX;
		}

		return D3D11_BLEND_OP_ADD;
	}

	static inline D3D11_BLEND ConvertGSBlendType(gs_blend_type type)
	{
		switch (type) {
		case GS_BLEND_ZERO:
			return D3D11_BLEND_ZERO;
		case GS_BLEND_ONE:
			return D3D11_BLEND_ONE;
		case GS_BLEND_SRCCOLOR:
			return D3D11_BLEND_SRC_COLOR;
		case GS_BLEND_INVSRCCOLOR:
			return D3D11_BLEND_INV_SRC_COLOR;
		case GS_BLEND_SRCALPHA:
			return D3D11_BLEND_SRC_ALPHA;
		case GS_BLEND_INVSRCALPHA:
			return D3D11_BLEND_INV_SRC_ALPHA;
		case GS_BLEND_DSTCOLOR:
			return D3D11_BLEND_DEST_COLOR;
		case GS_BLEND_INVDSTCOLOR:
			return D3D11_BLEND_INV_DEST_COLOR;
		case GS_BLEND_DSTALPHA:
			return D3D11_BLEND_DEST_ALPHA;
		case GS_BLEND_INVDSTALPHA:
			return D3D11_BLEND_INV_DEST_ALPHA;
		case GS_BLEND_SRCALPHASAT:
			return D3D11_BLEND_SRC_ALPHA_SAT;
		}

		return D3D11_BLEND_ONE;
	}

	static inline DXGI_FORMAT ConvertGSTextureFormatResource(gs_color_format format)
	{
		switch (format) {
		case GS_UNKNOWN:
			return DXGI_FORMAT_UNKNOWN;
		case GS_A8:
			return DXGI_FORMAT_A8_UNORM;
		case GS_R8:
			return DXGI_FORMAT_R8_UNORM;
		case GS_RGBA:
			return DXGI_FORMAT_R8G8B8A8_TYPELESS;
		case GS_BGRX:
			return DXGI_FORMAT_B8G8R8X8_TYPELESS;
		case GS_BGRA:
			return DXGI_FORMAT_B8G8R8A8_TYPELESS;
		case GS_R10G10B10A2:
			return DXGI_FORMAT_R10G10B10A2_UNORM;
		case GS_RGBA16:
			return DXGI_FORMAT_R16G16B16A16_UNORM;
		case GS_R16:
			return DXGI_FORMAT_R16_UNORM;
		case GS_RGBA16F:
			return DXGI_FORMAT_R16G16B16A16_FLOAT;
		case GS_RGBA32F:
			return DXGI_FORMAT_R32G32B32A32_FLOAT;
		case GS_RG16F:
			return DXGI_FORMAT_R16G16_FLOAT;
		case GS_RG32F:
			return DXGI_FORMAT_R32G32_FLOAT;
		case GS_R16F:
			return DXGI_FORMAT_R16_FLOAT;
		case GS_R32F:
			return DXGI_FORMAT_R32_FLOAT;
		case GS_DXT1:
			return DXGI_FORMAT_BC1_UNORM;
		case GS_DXT3:
			return DXGI_FORMAT_BC2_UNORM;
		case GS_DXT5:
			return DXGI_FORMAT_BC3_UNORM;
		case GS_R8G8:
			return DXGI_FORMAT_R8G8_UNORM;
		case GS_RGBA_UNORM:
			return DXGI_FORMAT_R8G8B8A8_UNORM;
		case GS_BGRX_UNORM:
			return DXGI_FORMAT_B8G8R8X8_UNORM;
		case GS_BGRA_UNORM:
			return DXGI_FORMAT_B8G8R8A8_UNORM;
		case GS_RG16:
			return DXGI_FORMAT_R16G16_UNORM;
		}

		return DXGI_FORMAT_UNKNOWN;
	}
	static inline DXGI_FORMAT ConvertGSTextureFormatView(gs_color_format format)
	{
		switch (format) {
		case GS_RGBA:
			return DXGI_FORMAT_R8G8B8A8_UNORM;
		case GS_BGRX:
			return DXGI_FORMAT_B8G8R8X8_UNORM;
		case GS_BGRA:
			return DXGI_FORMAT_B8G8R8A8_UNORM;
		default:
			return ConvertGSTextureFormatResource(format);
		}
	}

	static inline DXGI_FORMAT ConvertGSTextureFormatViewLinear(gs_color_format format)
	{
		switch (format) {
		case GS_RGBA:
			return DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
		case GS_BGRX:
			return DXGI_FORMAT_B8G8R8X8_UNORM_SRGB;
		case GS_BGRA:
			return DXGI_FORMAT_B8G8R8A8_UNORM_SRGB;
		default:
			return ConvertGSTextureFormatResource(format);
		}
	}

	static inline gs_color_format ConvertDXGITextureFormat(DXGI_FORMAT format)
	{
		switch ((unsigned long)format) {
		case DXGI_FORMAT_A8_UNORM:
			return GS_A8;
		case DXGI_FORMAT_R8_UNORM:
			return GS_R8;
		case DXGI_FORMAT_R8G8_UNORM:
			return GS_R8G8;
		case DXGI_FORMAT_R8G8B8A8_TYPELESS:
			return GS_RGBA;
		case DXGI_FORMAT_B8G8R8X8_TYPELESS:
			return GS_BGRX;
		case DXGI_FORMAT_B8G8R8A8_TYPELESS:
			return GS_BGRA;
		case DXGI_FORMAT_R10G10B10A2_UNORM:
			return GS_R10G10B10A2;
		case DXGI_FORMAT_R16G16B16A16_UNORM:
			return GS_RGBA16;
		case DXGI_FORMAT_R16_UNORM:
			return GS_R16;
		case DXGI_FORMAT_R16G16B16A16_FLOAT:
			return GS_RGBA16F;
		case DXGI_FORMAT_R32G32B32A32_FLOAT:
			return GS_RGBA32F;
		case DXGI_FORMAT_R16G16_FLOAT:
			return GS_RG16F;
		case DXGI_FORMAT_R32G32_FLOAT:
			return GS_RG32F;
		case DXGI_FORMAT_R16_FLOAT:
			return GS_R16F;
		case DXGI_FORMAT_R32_FLOAT:
			return GS_R32F;
		case DXGI_FORMAT_BC1_UNORM:
			return GS_DXT1;
		case DXGI_FORMAT_BC2_UNORM:
			return GS_DXT3;
		case DXGI_FORMAT_BC3_UNORM:
			return GS_DXT5;
		case DXGI_FORMAT_R8G8B8A8_UNORM:
			return GS_RGBA_UNORM;
		case DXGI_FORMAT_B8G8R8X8_UNORM:
			return GS_BGRX_UNORM;
		case DXGI_FORMAT_B8G8R8A8_UNORM:
			return GS_BGRA_UNORM;
		case DXGI_FORMAT_R16G16_UNORM:
			return GS_RG16;
		}

		return GS_UNKNOWN;
	}

}

#endif