#pragma once
#ifndef __X_D3D11_DUPLICATOR_H__
#define __X_D3D11_DUPLICATOR_H__

#include "./d3d11-subsystem.h"
namespace lib_d3d {
class GSTexture;
class GSTexture2D;

class LIB_EXPORT GSDuplicator : public GSObject {
public:
	GSDuplicator(GSDevice *device, int monitor_idx);
	~GSDuplicator();

	long Start();

	long Create();
	long Destroy();
	inline long Release()
	{
		duplicator.Release();
		return S_OK;
	}

	// static
	static long device_get_duplicator_monitor_info(GSDevice *device, int monitor_idx,
						       gs_monitor_info *info);
	static int device_duplicator_get_monitor_index(GSDevice *device, void *monitor);
	static void reset_duplicators(void);
	static GSDuplicator *device_duplicator_create(GSDevice *device, int monitor_idx);
	static void gs_duplicator_destroy(GSDuplicator *duplicator);
	static void copy_texture(GSDuplicator *d, ID3D11Texture2D *tex);
	static bool gs_duplicator_update_frame(GSDuplicator *d);
	static GSTexture *gs_duplicator_get_texture(GSDuplicator *duplicator);

protected:
	ComPtr<IDXGIOutputDuplication> duplicator;
	GSTexture2D *texture;
	int idx;
	long refs;
	bool updated;
};

using GSDuplicatorPtr = GSDuplicator *;
}
#endif