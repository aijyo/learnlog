#include "d3d11-swapchain.h"
#include <dxgi.h>
#include <algorithm>

#include "./../graphics/d3d11-helper.h"
#include "d3d11-device.h"

namespace lib_d3d {
GSSwapchain::GSSwapchain(GSDevice *device)
	: GSObject(device, E_GSType::kswap_chain), space_(GS_CS_SRGB), target_(device)
{
}

GSSwapchain::~GSSwapchain() {}

long GSSwapchain::Create(const swapchain_data &data)
{
	DXGI_SWAP_EFFECT effect = DXGI_SWAP_EFFECT_DISCARD;
	//DXGI_SWAP_EFFECT effect = DXGI_SWAP_EFFECT_SEQUENTIAL;
	UINT flags = 0;
	HRESULT hr = S_OK;

	do {
		// destroy old
		Destroy();

		initData_ = data;
		hwnd_ = data.window_;

		ComQIPtr<IDXGIFactory5> factory5 = (IUnknown *)device_->factory_;
		if (factory5) {
			initData_.num_backbuffers_ =
				std::max<std::uint32_t>(initData_.num_backbuffers_, 2);

			effect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
			//effect = DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
			flags |= DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT;

			BOOL featureSupportData = FALSE;
			const HRESULT hr = factory5->CheckFeatureSupport(
				DXGI_FEATURE_PRESENT_ALLOW_TEARING, &featureSupportData,
				sizeof(featureSupportData));
			if (SUCCEEDED(hr) && featureSupportData) {
				presentFlags_ |= DXGI_PRESENT_ALLOW_TEARING;

				flags |= DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING;
			}
		}

		space_ = GrpahicsHelper::make_swap_desc(device_, swapDesc_, initData_, effect,
							flags);
		HRESULT hr = device_->factory_->CreateSwapChain(device_->device_, &swapDesc_,
								swapchain_.Assign());
		if (FAILED(hr)) {
			XLOG("Failed to create swap chain", hr);
			break;
		}

		/* Ignore Alt+Enter */
		device_->factory_->MakeWindowAssociation(hwnd_, DXGI_MWA_NO_ALT_ENTER);

		if (flags & DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT) {
			ComPtr<IDXGISwapChain2> swap2 = ComQIPtr<IDXGISwapChain2>(swapchain_);
			hWaitable = swap2->GetFrameLatencyWaitableObject();
			if (hWaitable) {
				hr = swap2->SetMaximumFrameLatency(40);
				if (FAILED(hr)) {
					XLOG("Could not relax frame latency", hr);
					break;
				}
			}
		}

		Init();
		//hr = target_.Create();
		//if (!hr)
		//{
		//	break;
		//}

		//hr = zstencilBuffer_.Create();
		//if (!hr)
		//{
		//	break;
		//}
	} while (false);
	return hr;
}

long GSSwapchain::Destroy()
{
	target_.Destroy();
	zstencilBuffer_.Destroy();
	if (hWaitable)
		CloseHandle(hWaitable);

	return 0;
}

int GSSwapchain::InitTarget(uint32_t cx, uint32_t cy)
{
	HRESULT hr = S_OK;

	target_.width_ = cx;
	target_.height_ = cy;

	do {
		hr = swapchain_->GetBuffer(0, __uuidof(ID3D11Texture2D),
					   (void **)target_.texture_.Assign());
		if (FAILED(hr)) {
			break;
		}

		D3D11_RENDER_TARGET_VIEW_DESC rtv;
		rtv.Format = target_.dxgiFormatView_;
		rtv.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
		rtv.Texture2D.MipSlice = 0;
		hr = device_->device_->CreateRenderTargetView(target_.texture_, &rtv,
							      target_.renderTarget_[0].Assign());
		if (FAILED(hr)) {
			break;
		}
		if (target_.dxgiFormatView_ == target_.dxgiFormatViewLinear_) {
			target_.renderTargetLinear_[0] = target_.renderTarget_[0];
		} else {
			rtv.Format = target_.dxgiFormatViewLinear_;
			hr = device_->device_->CreateRenderTargetView(
				target_.texture_, &rtv, target_.renderTargetLinear_[0].Assign());
			if (FAILED(hr)) {
				break;
			}
		}
	} while (false);
	return hr;
}

int GSSwapchain::InitZStencilBuffer(uint32_t cx, uint32_t cy)
{
	HRESULT hr = S_OK;

	auto &zstencilBuffer = zstencilBuffer_;
	zstencilBuffer.width_ = cx;
	zstencilBuffer.height_ = cy;
	//hr = zstencilBuffer_.Create();

	if (zstencilBuffer.format_ != GS_ZS_NONE && cx != 0 && cy != 0) {
		zstencilBuffer.InitBuffer();
	} else {
		zstencilBuffer.texture_.Clear();
		zstencilBuffer.view_.Clear();
	}
	return hr;
}

int GSSwapchain::Resize(uint32_t cx, uint32_t cy, gs_color_format format)
{
	RECT clientRect;
	HRESULT hr = S_OK;

	auto &target = target_;
	auto &zstencilBuffer = zstencilBuffer_;
	target.texture_.Clear();
	target.renderTarget_[0].Clear();
	target.renderTargetLinear_[0].Clear();
	zstencilBuffer.texture_.Clear();
	zstencilBuffer.view_.Clear();

	initData_.cx_ = cx;
	initData_.cy_ = cy;

	if (cx == 0 || cy == 0) {
		GetClientRect(hwnd_, &clientRect);
		if (cx == 0)
			cx = clientRect.right;
		if (cy == 0)
			cy = clientRect.bottom;
	}

	do {
		const DXGI_FORMAT dxgi_format = ConvertGSTextureFormatView(format);
		hr = swapchain_->ResizeBuffers(swapDesc_.BufferCount, cx, cy, dxgi_format,
					       swapDesc_.Flags);
		if (FAILED(hr)) {
			break;
		}
		ComQIPtr<IDXGISwapChain3> swap3 = (IUnknown *)swapchain_;
		if (swap3) {
			const DXGI_COLOR_SPACE_TYPE dxgi_space =
				(format == GS_RGBA16F) ? DXGI_COLOR_SPACE_RGB_FULL_G10_NONE_P709
						       : DXGI_COLOR_SPACE_RGB_FULL_G22_NONE_P709;
			hr = swap3->SetColorSpace1(dxgi_space);
			if (FAILED(hr)) {
				break;
			}
		}

		target.dxgiFormatResource_ = ConvertGSTextureFormatResource(format);
		target.dxgiFormatView_ = dxgi_format;
		target.dxgiFormatViewLinear_ = ConvertGSTextureFormatViewLinear(format);
		InitTarget(cx, cy);
		InitZStencilBuffer(cx, cy);
	} while (false);

	return hr;
}

int GSSwapchain::Init()
{
	HRESULT hr = S_OK;
	const gs_color_format format = GrpahicsHelper::get_swap_format_from_space(
		GrpahicsHelper::get_next_space(device_, hwnd_), initData_.format_);
	auto &target = target_;
	target.device_ = device_;
	target.isRenderTarget_ = true;
	target.format_ = initData_.format_;
	target.dxgiFormatResource_ = ConvertGSTextureFormatResource(format);
	target.dxgiFormatView_ = ConvertGSTextureFormatView(format);
	target.dxgiFormatViewLinear_ = ConvertGSTextureFormatViewLinear(format);
	InitTarget(initData_.cx_, initData_.cy_);

	auto &zs = zstencilBuffer_;
	zs.device_ = device_;
	zs.format_ = initData_.zsformat_;
	zs.dxgiFormat_ = GrpahicsHelper::ConvertGSZStencilFormat(initData_.zsformat_);
	InitZStencilBuffer(initData_.cx_, initData_.cy_);
	return hr;
}

long GSSwapchain::Rebuild(ID3D11Device *dev)
{
	HRESULT hr = S_OK;
	do {
		hr = device_->factory_->CreateSwapChain(dev, &swapDesc_, &swapchain_);
		if (FAILED(hr)) {
			XLOG("Failed to create swap chain", hr);
			break;
		}
		hr = Init();
		if (FAILED(hr)) {
			XLOG("Failed to Init", hr);
			break;
		}
	} while (false);
	return hr;
}

//inline long GSSwapchain::Release()
//{
//	target_->Release();
//	zstencilBuffer_->Release();
//	if (hWaitable) {
//		CloseHandle(hWaitable);
//		hWaitable = NULL;
//	}
//	swapchain_.Clear();

//	return 0;
//}

long GSSwapchain::Release()
{
	HRESULT result = S_OK;
	auto &target = target_;
	auto &zstencilBuffer = zstencilBuffer_;
	target.Release();
	zstencilBuffer.Release();
	if (hWaitable) {
		CloseHandle(hWaitable);
		hWaitable = NULL;
	}
	swapchain_.Clear();

	return result;
}
}