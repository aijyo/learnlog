#pragma once
#ifndef __X_D3D11_TEXTURE2D_H__
#define __X_D3D11_TEXTURE2D_H__

#include "./d3d11-subsystem.h"

#include "./d3d11-texture.h"
namespace lib_d3d {
class LIB_EXPORT GSTexture2D : public GSTexture {
public:
	using TextureData = vector<vector<uint8_t>>;
	using DataType = const uint8_t *const *;

public:
	//long Create();	// default constructor
	long Create(GSDevice *device, uint32_t width, uint32_t height, gs_color_format colorFormat,
		    uint32_t levels, const uint8_t *const *data, uint32_t flags,
		    gs_texture_type type, bool gdiCompatible, bool twoPlane = false);
	long Create(GSDevice *device, ID3D11Texture2D *nv12, uint32_t flags);
	long Create(GSDevice *device, HANDLE handle, bool ntHandle = false);
	long Create(GSDevice *device, ID3D11Texture2D *obj);
	long Destroy();

	long InitSRD(vector<D3D11_SUBRESOURCE_DATA> &srd);
	long InitTexture(DataType data = nullptr);
	long InitResourceView();
	long InitRenderTargets();
	long BackupTexture(DataType data);
	long GetSharedHandle(IDXGIResource *dxgi_res);

	void RebuildSharedTextureFallback();
	long Rebuild(ID3D11Device *dev);
	long RebuildPaired_Y(ID3D11Device *dev);
	long RebuildPaired_UV(ID3D11Device *dev);

	long Map(uint8_t **ptr, uint32_t &linesize);
	long Unmap();

	long Flush(const uint8_t *const *data, uint32_t linesize = 0);

	ID3D11ShaderResourceView *ResourceView() const;

	inline long Release()
	{
		texture_.Release();
		for (ComPtr<ID3D11RenderTargetView> &rt : renderTarget_)
			rt.Release();
		for (ComPtr<ID3D11RenderTargetView> &rt : renderTargetLinear_)
			rt.Release();
		gdiSurface_.Release();
		shaderRes_.Release();
		shaderResLinear_.Release();
		return 0;
	}

	inline GSTexture2D(GSDevice *device)
		: GSTexture(device, E_GSType::ktexture_2d, GS_TEXTURE_2D)
	{
	}

public:
	ComPtr<ID3D11Texture2D> texture_;
	ComPtr<ID3D11RenderTargetView> renderTarget_[6];
	ComPtr<ID3D11RenderTargetView> renderTargetLinear_[6];
	ComPtr<IDXGISurface1> gdiSurface_;

	uint32_t width_ = 0, height_ = 0;
	uint32_t flags_ = 0;
	DXGI_FORMAT dxgiFormatResource_ = DXGI_FORMAT_UNKNOWN;
	DXGI_FORMAT dxgiFormatView_ = DXGI_FORMAT_UNKNOWN;
	DXGI_FORMAT dxgiFormatViewLinear_ = DXGI_FORMAT_UNKNOWN;
	bool isRenderTarget_ = false;
	bool isGDICompatible_ = false;
	bool isDynamic_ = false;
	bool isShared_ = false;
	bool genMipmaps_ = false;
	HANDLE sharedHandle_ = GS_INVALID_HANDLE;

	GSTexture2D *pairedTexture_ = nullptr;
	bool twoPlane_ = false;
	bool chroma_ = false;
	bool acquired_ = false;

	TextureData data_;
	vector<D3D11_SUBRESOURCE_DATA> subsource_data_;
	D3D11_TEXTURE2D_DESC texutre_desc_ = {};
};

//using GSTexture2DPtr = std::shared_ptr<GSTexture2D>;
using GSTexture2DPtr = GSTexture2D *;
}
#endif