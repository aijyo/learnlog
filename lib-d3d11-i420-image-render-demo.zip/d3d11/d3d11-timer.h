#pragma once
#ifndef __X_D3D11_TIMER_H__
#define __X_D3D11_TIMER_H__

#include "./d3d11-subsystem.h"

namespace lib_d3d {
class GSDevice;

class LIB_EXPORT GSTimer : public GSObject {
public:
	GSTimer(GSDevice *device);
	~GSTimer();

	long Create();
	long Destroy();

	long Rebuild(ID3D11Device *dev);
	inline long Release();

	long Begin();
	long End();
	long GetTicks(uint64_t &ticks);

public:
	ComPtr<ID3D11Query> query_begin;
	ComPtr<ID3D11Query> query_end;

protected:
};

//using GSTimerPtr = std::shared_ptr<GSTimer>;
using GSTimerPtr = GSTimer *;
//////////////////////////////////////////////////////////////////////////
class LIB_EXPORT GSTimerRange : public GSObject {
public:
	GSTimerRange(GSDevice *device);
	~GSTimerRange();

	long Create();
	long Destroy();

	long Begin();
	long End();
	long GetTicks(bool &disjoint, uint64_t &frequency);

	long Rebuild(ID3D11Device *dev);
	inline long Release();

public:
	ComPtr<ID3D11Query> query_disjoint;
};

//using GSTimerRangePtr = std::shared_ptr<GSTimerRange>;
using GSTimerRangePtr = GSTimerRange *;
}
#endif