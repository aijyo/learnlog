#pragma once
#ifndef __X_D3D11_SHADERPROCESSOR_H__
#define __X_D3D11_SHADERPROCESSOR_H__

#include "./d3d11-subsystem.h"
namespace lib_d3d {

//struct ShaderParser : shader_parser {
//	inline ShaderParser() { shader_parser_init(this); }
//	inline ~ShaderParser() { shader_parser_free(this); }
//};

//struct ShaderProcessor {
//	gs_device_t* device;
//	ShaderParser parser;

//	void BuildInputLayout(vector<D3D11_INPUT_ELEMENT_DESC>& inputs);
//	void BuildParams(vector<gs_shader_param>& params);
//	void BuildSamplers(vector<unique_ptr<ShaderSampler>>& samplers);
//	void BuildString(string& outputString);
//	void Process(const char* shader_string, const char* file);

//	inline ShaderProcessor(gs_device_t* device) : device(device) {}
//};

}
#endif