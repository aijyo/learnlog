#include "d3d11-device.h"
#include <tchar.h>
//#include "d3d-common/matrix/matrix.h"
namespace lib_d3d {
	GSDevice::GSDevice(uint32_t adapterIdx /*= 0*/)
		: curToplogy_(D3D11_PRIMITIVE_TOPOLOGY_UNDEFINED), adpIdx_(adapterIdx)
	{
		Matrix::MatrixToIdentity(curWorldMatrix_);
		Matrix::MatrixToIdentity(curViewMatrix_);
		Matrix::MatrixToIdentity(curProjMatrix_);

		//InitCompiler();
	}
	GSDevice::GSDevice(LUID uid)
		: curToplogy_(D3D11_PRIMITIVE_TOPOLOGY_UNDEFINED)
		, uid_(uid)
	{
		Matrix::MatrixToIdentity(curWorldMatrix_);
		Matrix::MatrixToIdentity(curViewMatrix_);
		Matrix::MatrixToIdentity(curProjMatrix_);

		//InitCompiler();
	}

	GSDevice::~GSDevice() { Destroy(); }

	long GSDevice::Create()
	{
		HRESULT hr = S_OK;
		do {
			hr = InitFactory();
			if (FAILED(hr))
				break;

			ReorderAdapters(adpIdx_);

			hr = InitAdapter(adpIdx_);
			if (FAILED(hr))
				break;

			hr = InitDevice(adpIdx_);
			if (FAILED(hr))
				break;
			SetRenderTarget(NULL, NULL);
		} while (false);

		return hr;
	}

	long GSDevice::Destroy()
	{
#if defined(DEBUG) || defined(_DEBUG)
		if (device_)
		{
			ID3D11Debug* d3dDebug;
			HRESULT hr = device_->QueryInterface(__uuidof(ID3D11Debug), reinterpret_cast<void**>(&d3dDebug));
			if (SUCCEEDED(hr))
			{
				hr = d3dDebug->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
			}
			if (d3dDebug != nullptr)			d3dDebug->Release();
		}
#endif
		if (context_)
		{
			context_->ClearState();
			context_ = nullptr;
		}
		if (device_)
		{
			device_ = nullptr;
		}
		return S_OK;
	}

	GSTexture2DPtr GSDevice::TextureCreate(uint32_t width, uint32_t height,
		gs_color_format color_format, uint32_t levels,
		const uint8_t** data, uint32_t flags)
	{
		auto texture = new GSTexture2D(this);
		long result = texture->Create(this, width, height, color_format, levels, data, flags,
			GS_TEXTURE_2D, false);

		if (result != S_OK) {
			SAFE_DELETE(texture);
		}
		return texture;
	}

	GSTexturePtr GSDevice::CubeTextureCreate(uint32_t size, gs_color_format color_format,
		uint32_t levels, const uint8_t** data, uint32_t flags)
	{

		auto texture = new GSTexture2D(this);
		long result = texture->Create(this, size, size, color_format, levels, data, flags,
			GS_TEXTURE_CUBE, false);
		if (FAILED(result)) {
			SAFE_DELETE(texture);
		}
		return texture;
	}

	GSTexturePtr GSDevice::VolTextureCreate(uint32_t width, uint32_t height, uint32_t depth,
		gs_color_format color_format, uint32_t levels,
		const uint8_t* const* data, uint32_t flags)
	{

		auto texture =
			new GSTexture3D(this, width, height, depth, color_format, levels, data, flags);
		long result = texture->Create();
		if (FAILED(result)) {
			SAFE_DELETE(texture);
		}
		return texture;
	}

	GSZstencilBufferPtr GSDevice::ZstencilCreate(uint32_t width, uint32_t height,
		gs_zstencil_format format)
	{
		auto result = new GSZstencilBuffer(this, width, height, format);
		long hr = result->Create();
		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSStageSurfacePtr GSDevice::StageSurfCreate(uint32_t width, uint32_t height,
		gs_color_format color_format)
	{
		auto result = new GSStageSurface(this, width, height, color_format);
		long hr = result->Create();
		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSSamplerStatePtr GSDevice::SamplerStateCreate(const gs_sampler_info& info)
	{
		auto result = new GSSamplerState(this, info);
		long hr = result->Create();
		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSVertexShaderPtr GSDevice::VetextShaderCreate(const string& file, const vector<uint8_t>& inputdata,
		const D3D11_BUFFER_DESC& desc,
		const vector<D3D11_INPUT_ELEMENT_DESC>& layout)
	{
		auto result = new GSVertexShader(this, file, inputdata, desc, layout);
		long hr = result->Create();
		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSPixelShaderPtr GSDevice::PixelShaderCreate(const string& file, const D3D11_BUFFER_DESC& desc,
		const vector<uint8_t>& inputdata)
	{

		auto result = new GSPixelShader(this, file, desc, inputdata);
		long hr = result->Create();
		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSVertexBufferPtr GSDevice::VertexBufferCreate(vertex_data_ptr data, uint32_t flags)
	{
		auto result = new GSVertexBuffer(this, flags);
		HRESULT hr = result->Create(data);

		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSIndexBufferPtr GSDevice::IndexBufferCreate(index_data_ptr indices, uint32_t flags)
	{
		auto result = new GSIndexBuffer(this, flags);
		HRESULT hr = result->Create(indices);

		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSTimerPtr GSDevice::TimerCreate()
	{
		auto result = new GSTimer(this);
		HRESULT hr = result->Create();

		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	GSTimerRangePtr GSDevice::TimerRangeCreate()
	{
		auto result = new GSTimerRange(this);
		HRESULT hr = result->Create();

		if (FAILED(hr)) {
			SAFE_DELETE(result);
		}
		return result;
	}

	long GSDevice::ShaderDestroy(GSShaderPtr shader)
	{
		SAFE_DELETE(shader);
		return S_OK;
	}
	//long EffectDestory();
	//long TextureRenderDestroy(GSTextureRenderPtr render);
	long GSDevice::SwapchainDestroy(GSSwapchainPtr swapchain)
	{
		SAFE_DELETE(swapchain);
		return S_OK;
	}

	long GSDevice::TextureDestroy(GSTexturePtr tex)
	{
		SAFE_DELETE(tex);
		return S_OK;
	}

	long GSDevice::CubetextureDestroy(GSTexturePtr cubetex)
	{
		SAFE_DELETE(cubetex);
		return S_OK;
	}

	long GSDevice::VoltextureDestroy(GSTexturePtr voltex)
	{
		SAFE_DELETE(voltex);
		return S_OK;
	}

	long GSDevice::StagesurfaceDestroy(GSStageSurfacePtr stagesurf)
	{
		SAFE_DELETE(stagesurf);
		return S_OK;
	}

	long GSDevice::ZstencilDestroy(GSZstencilBufferPtr zstencil)
	{
		SAFE_DELETE(zstencil);
		return S_OK;
	}

	long GSDevice::SamplerstateDestroy(GSSamplerStatePtr samplerstate)
	{
		for (int i = 0; i < GS_MAX_TEXTURES; i++)
			if (curSamplers_[i] == samplerstate)
				curSamplers_[i] = nullptr;
		SAFE_DELETE(samplerstate);
		return S_OK;
	}

	long GSDevice::VertexbufferDestroy(GSVertexBufferPtr vertbuffer)
	{
		if (vertbuffer && lastVertexBuffer_ == vertbuffer)
			lastVertexBuffer_ = nullptr;
		SAFE_DELETE(vertbuffer);
		return S_OK;
	}
	long GSDevice::IndexbufferDestroy(GSIndexBufferPtr indexbuffer)
	{
		SAFE_DELETE(indexbuffer);
		return S_OK;
	}

	long GSDevice::TimerDestroy(GSTimerPtr timer)
	{
		SAFE_DELETE(timer);
		return S_OK;
	}

	long GSDevice::TimerRangeDestroy(GSTimerRangePtr timer)
	{
		SAFE_DELETE(timer);
		return S_OK;
	}

	long GSDevice::DuplicatorDestroy(GSDuplicatorPtr duplicator)
	{
		SAFE_DELETE(duplicator);
		return S_OK;
	}

	bool GSDevice::AddListener(IDeviceEventListener* listener)
	{
		auto it = std::find(event_callbacks_.begin(), event_callbacks_.end(), listener);
		bool bPush = it == event_callbacks_.end();
		if (bPush) {
			event_callbacks_.push_back(listener);
		}
		return bPush;
	}

	bool GSDevice::RemoveListener(IDeviceEventListener* listener)
	{
		auto it = std::find(event_callbacks_.begin(), event_callbacks_.end(), listener);
		bool bFind = it != event_callbacks_.end();
		if (bFind) {
			event_callbacks_.erase(it);
		}

		return bFind;
	}

	long GSDevice::InitFactory()
	{
		last_error_ = CreateDXGIFactory1(IID_PPV_ARGS(&factory_));
		return last_error_;
	}

#define VENDOR_ID_INTEL 0x8086
#define IGPU_MEM (512 * 1024 * 1024)
	void GSDevice::ReorderAdapters(uint32_t& adapterIdx)
	{
		std::vector<uint32_t> adapterOrder;
		ComPtr<IDXGIAdapter> adapter;
		DXGI_ADAPTER_DESC desc;
		uint32_t iGPUIndex = 0;
		bool hasIGPU = false;
		bool hasDGPU = false;
		int idx = 0;
		bool bFind = false;

		do
		{
			while (SUCCEEDED(factory_->EnumAdapters(idx, &adapter))) {

				if (SUCCEEDED(adapter->GetDesc(&desc))) {
					if (desc.VendorId == VENDOR_ID_INTEL) {
						if (desc.DedicatedVideoMemory <= IGPU_MEM) {
							hasIGPU = true;
							iGPUIndex = (uint32_t)idx;
						}
						else {
							hasDGPU = true;
						}
					}

				}

				if (desc.AdapterLuid.LowPart == uid_.LowPart
					&& desc.AdapterLuid.HighPart == uid_.HighPart)
				{
					adapterIdx = idx;
					bFind = true;
				}
				adapterOrder.push_back((uint32_t)idx++);
				if (bFind) break;
			}

			// find user special adapter 
			if (bFind)
				break;

			/* Intel specific adapter check for Intel integrated and Intel
				 * dedicated. If both exist, then change adapter priority so that the
				 * integrated comes first for the sake of improving overall
				 * performance */
			if (hasIGPU && hasDGPU) {
				adapterOrder.erase(adapterOrder.begin() + iGPUIndex);
				adapterOrder.insert(adapterOrder.begin(), iGPUIndex);
				adapterIdx = adapterOrder[adapterIdx];
			}
		} while (false);
	}

	long GSDevice::InitAdapter(uint32_t adapterIdx)
	{

		last_error_ = factory_->EnumAdapters1(adapterIdx, &adapter_);
		return last_error_;
	}

	const static D3D_FEATURE_LEVEL featureLevels[] = {
		D3D_FEATURE_LEVEL_11_0,
		D3D_FEATURE_LEVEL_10_1,
		D3D_FEATURE_LEVEL_10_0,
	};

	static bool increase_maximum_frame_latency(ID3D11Device* device)
	{
		bool result = false;
		do {
			ComQIPtr<IDXGIDevice1> dxgiDevice(device);
			if (!dxgiDevice) {
				XLOG(LOG_DEBUG, "%s: Failed to get IDXGIDevice1", __FUNCTION__);
				break;
			}

			const HRESULT hr = dxgiDevice->SetMaximumFrameLatency(16);
			if (FAILED(hr)) {
				XLOG(LOG_DEBUG, "%s: SetMaximumFrameLatency failed", __FUNCTION__);
				break;
			}

			XLOG(LOG_INFO, "DXGI increase maximum frame latency success");
			result = true;

		} while (false);
		return true;
	}

#if USE_GPU_PRIORITY
	static bool set_priority(ID3D11Device* device)
	{
		typedef enum _D3DKMT_SCHEDULINGPRIORITYCLASS {
			D3DKMT_SCHEDULINGPRIORITYCLASS_IDLE,
			D3DKMT_SCHEDULINGPRIORITYCLASS_BELOW_NORMAL,
			D3DKMT_SCHEDULINGPRIORITYCLASS_NORMAL,
			D3DKMT_SCHEDULINGPRIORITYCLASS_ABOVE_NORMAL,
			D3DKMT_SCHEDULINGPRIORITYCLASS_HIGH,
			D3DKMT_SCHEDULINGPRIORITYCLASS_REALTIME
		} D3DKMT_SCHEDULINGPRIORITYCLASS;

		ComQIPtr<IDXGIDevice> dxgiDevice(device);
		if (!dxgiDevice) {
			blog(LOG_DEBUG, "%s: Failed to get IDXGIDevice", __FUNCTION__);
			return false;
		}

		HMODULE gdi32 = GetModuleHandleW(L"GDI32");
		if (!gdi32) {
			blog(LOG_DEBUG, "%s: Failed to get GDI32", __FUNCTION__);
			return false;
		}

		NTSTATUS(WINAPI * d3dkmt_spspc)(HANDLE, D3DKMT_SCHEDULINGPRIORITYCLASS);
		d3dkmt_spspc = (decltype(d3dkmt_spspc))GetProcAddress(
			gdi32, "D3DKMTSetProcessSchedulingPriorityClass");
		if (!d3dkmt_spspc) {
			blog(LOG_DEBUG, "%s: Failed to get d3dkmt_spspc", __FUNCTION__);
			return false;
		}

		NTSTATUS status =
			d3dkmt_spspc(GetCurrentProcess(), D3DKMT_SCHEDULINGPRIORITYCLASS_REALTIME);
		if (status != 0) {
			blog(LOG_DEBUG, "%s: Failed to set process priority class: %d", __FUNCTION__,
				(int)status);
			return false;
		}

		HRESULT hr = dxgiDevice->SetGPUThreadPriority(GPU_PRIORITY_VAL);
		if (FAILED(hr)) {
			blog(LOG_DEBUG, "%s: SetGPUThreadPriority failed", __FUNCTION__);
			return false;
		}

		blog(LOG_INFO, "D3D11 GPU priority setup success");
		return true;
	}

#endif

	static bool CheckFormat(ID3D11Device* device, DXGI_FORMAT format)
	{
		constexpr UINT required = D3D11_FORMAT_SUPPORT_TEXTURE2D |
			D3D11_FORMAT_SUPPORT_RENDER_TARGET;

		UINT support = 0;
		return SUCCEEDED(device->CheckFormatSupport(format, &support)) &&
			((support & required) == required);
	}

	long GSDevice::InitDevice(uint32_t adapterIdx)
	{
		x_util::tstring adapterName;
		DXGI_ADAPTER_DESC desc;
		D3D_FEATURE_LEVEL levelUsed = D3D_FEATURE_LEVEL_10_0;
		HRESULT hr = last_error_;

		adpIdx_ = adapterIdx;

		uint32_t createFlags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
#ifdef _DEBUG
		createFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

		adapterName = (adapter_->GetDesc(&desc) == S_OK) ? desc.Description : _T("<unknown>");

		do {
			hr = D3D11CreateDevice(adapter_, D3D_DRIVER_TYPE_UNKNOWN, NULL, createFlags,
				featureLevels,
				sizeof(featureLevels) / sizeof(D3D_FEATURE_LEVEL),
				D3D11_SDK_VERSION, device_.Assign(), &levelUsed,
				context_.Assign());
			if (FAILED(hr)) {
				break;
			}

			/* prevent stalls sometimes seen in Present calls */
			if (!increase_maximum_frame_latency(device_)) {
				XLOG(LOG_INFO, "DXGI increase maximum frame latency failed");
			}

			/* adjust gpu thread priority on non-intel GPUs */
#if USE_GPU_PRIORITY
			if (desc.VendorId != 0x8086 && !set_priority(device_)) {
				XLOG(LOG_INFO, "D3D11 GPU priority setup "
					"failed (not admin?)");
			}
#endif

			/* ---------------------------------------- */
			/* check for nv12 texture output support    */

			nv12Supported_ = false;
			p010Supported_ = false;

			/* WARP NV12 support is suspected to be buggy on older Windows */
			if (desc.VendorId == 0x1414 && desc.DeviceId == 0x8c) {
				break;
			}

			ComQIPtr<ID3D11Device1> d3d11_1(device_);
			if (!d3d11_1) {
				break;
			}

			/* needs to support extended resource sharing */
			D3D11_FEATURE_DATA_D3D11_OPTIONS opts = {};
			hr = d3d11_1->CheckFeatureSupport(D3D11_FEATURE_D3D11_OPTIONS, &opts, sizeof(opts));
			if (FAILED(hr) || !opts.ExtendedResourceSharing) {
				break;
			}

			nv12Supported_ = CheckFormat(device_, DXGI_FORMAT_NV12) && !HasBadNV12Output();
			p010Supported_ = nv12Supported_ && CheckFormat(device_, DXGI_FORMAT_P010);
		} while (false);

		last_error_ = hr;
		return last_error_;
	}

	static inline void ConvertStencilSide(D3D11_DEPTH_STENCILOP_DESC& desc, const StencilSide& side)
	{
		desc.StencilFunc = ConvertGSDepthTest(side.test);
		desc.StencilFailOp = ConvertGSStencilOp(side.fail);
		desc.StencilDepthFailOp = ConvertGSStencilOp(side.zfail);
		desc.StencilPassOp = ConvertGSStencilOp(side.zpass);
	}

	ID3D11DepthStencilState* GSDevice::AddZStencilState()
	{
		HRESULT hr;
		D3D11_DEPTH_STENCIL_DESC dsd;
		ID3D11DepthStencilState* state = NULL;

		dsd.DepthEnable = zstencilState_.depthEnabled;
		dsd.DepthFunc = ConvertGSDepthTest(zstencilState_.depthFunc);
		dsd.DepthWriteMask = zstencilState_.depthWriteEnabled ? D3D11_DEPTH_WRITE_MASK_ALL
			: D3D11_DEPTH_WRITE_MASK_ZERO;
		dsd.StencilEnable = zstencilState_.stencilEnabled;
		dsd.StencilReadMask = D3D11_DEFAULT_STENCIL_READ_MASK;
		dsd.StencilWriteMask = zstencilState_.stencilWriteEnabled ? D3D11_DEFAULT_STENCIL_WRITE_MASK
			: 0;
		ConvertStencilSide(dsd.FrontFace, zstencilState_.stencilFront);
		ConvertStencilSide(dsd.BackFace, zstencilState_.stencilBack);

		SavedZStencilState savedState(zstencilState_, dsd);
		hr = device_->CreateDepthStencilState(&dsd, savedState.state.Assign());
		if (SUCCEEDED(hr)) {
			state = savedState.state;
			zstencilStates_.push_back(savedState);
		}
		else {
			last_error_ = hr;
		}

		return state;
	}

	ID3D11RasterizerState* GSDevice::AddRasterState()
	{
		HRESULT hr;
		D3D11_RASTERIZER_DESC rd;
		ID3D11RasterizerState* state = NULL;

		memset(&rd, 0, sizeof(rd));
		/* use CCW to convert to a right-handed coordinate system */
		rd.FrontCounterClockwise = true;
		rd.FillMode = D3D11_FILL_SOLID;
		rd.CullMode = ConvertGSCullMode(rasterState_.cullMode);
		rd.DepthClipEnable = true;
		rd.ScissorEnable = rasterState_.scissorEnabled;

		SavedRasterState savedState(rasterState_, rd);
		hr = device_->CreateRasterizerState(&rd, savedState.state.Assign());

		if (SUCCEEDED(hr)) {
			state = savedState.state;
			rasterStates_.push_back(savedState);
		}
		else {
			last_error_ = hr;
		}

		return state;
	}

	ID3D11BlendState* GSDevice::AddBlendState()
	{
		HRESULT hr;
		D3D11_BLEND_DESC bd;
		ID3D11BlendState* state = NULL;

		memset(&bd, 0, sizeof(bd));
		for (int i = 0; i < 8; i++) {
			bd.RenderTarget[i].BlendEnable = blendState_.blendEnabled;
			bd.RenderTarget[i].BlendOp = ConvertGSBlendOpType(blendState_.op);
			bd.RenderTarget[i].BlendOpAlpha = ConvertGSBlendOpType(blendState_.op);
			bd.RenderTarget[i].SrcBlend = ConvertGSBlendType(blendState_.srcFactorC);
			bd.RenderTarget[i].DestBlend = ConvertGSBlendType(blendState_.destFactorC);
			bd.RenderTarget[i].SrcBlendAlpha = ConvertGSBlendType(blendState_.srcFactorA);
			bd.RenderTarget[i].DestBlendAlpha = ConvertGSBlendType(blendState_.destFactorA);
			bd.RenderTarget[i].RenderTargetWriteMask =
				(blendState_.redEnabled ? D3D11_COLOR_WRITE_ENABLE_RED : 0) |
				(blendState_.greenEnabled ? D3D11_COLOR_WRITE_ENABLE_GREEN : 0) |
				(blendState_.blueEnabled ? D3D11_COLOR_WRITE_ENABLE_BLUE : 0) |
				(blendState_.alphaEnabled ? D3D11_COLOR_WRITE_ENABLE_ALPHA : 0);
		}

		SavedBlendState savedState(blendState_, bd);
		hr = device_->CreateBlendState(&bd, savedState.state.Assign());
		if (SUCCEEDED(hr)) {
			state = savedState.state;
			blendStates_.push_back(savedState);
		}
		else {
			last_error_ = hr;
		}
		return state;
	}

	void GSDevice::UpdateZStencilState()
	{
		ID3D11DepthStencilState* state = NULL;

		do {
			if (!zstencilStateChanged_)
				break;

			for (size_t i = 0; i < zstencilStates_.size(); i++) {
				SavedZStencilState& s = zstencilStates_[i];
				if (memcmp(&s, &zstencilState_, sizeof(zstencilState_)) == 0) {
					state = s.state;
					break;
				}
			}

			if (!state)
				state = AddZStencilState();

			if (state != curDepthStencilState_) {
				context_->OMSetDepthStencilState(state, 0);
				curDepthStencilState_ = state;
			}

			zstencilStateChanged_ = false;
		} while (false);
		return;
	}

	void GSDevice::UpdateRasterState()
	{
		ID3D11RasterizerState* state = NULL;

		do {
			if (!rasterStateChanged_)
				break;

			for (size_t i = 0; i < rasterStates_.size(); i++) {
				SavedRasterState& s = rasterStates_[i];
				if (memcmp(&s, &rasterState_, sizeof(rasterState_)) == 0) {
					state = s.state;
					break;
				}
			}

			if (!state)
				state = AddRasterState();

			if (state != curRasterState_) {
				context_->RSSetState(state);
				curRasterState_ = state;
			}

			rasterStateChanged_ = false;
		} while (false);
		return;
	}

	void GSDevice::UpdateBlendState()
	{
		ID3D11BlendState* state = NULL;

		do {
			if (!blendStateChanged_)
				break;

			for (size_t i = 0; i < blendStates_.size(); i++) {
				SavedBlendState& s = blendStates_[i];
				if (memcmp(&s, &blendState_, sizeof(blendState_)) == 0) {
					state = s.state;
					break;
				}
			}

			if (!state)
				state = AddBlendState();

			if (state != curBlendState_) {
				float f[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
				context_->OMSetBlendState(state, f, 0xFFFFFFFF);
				curBlendState_ = state;
			}

			blendStateChanged_ = false;
		} while (false);
		return;
	}

	void GSDevice::LoadVertexBufferData()
	{
		if (curVertexBuffer_ == lastVertexBuffer_ && curVertexShader_ == lastVertexShader_)
			return;

		ID3D11Buffer* buffers[D3D11_IA_VERTEX_INPUT_RESOURCE_SLOT_COUNT];
		uint32_t strides[D3D11_IA_VERTEX_INPUT_RESOURCE_SLOT_COUNT];
		uint32_t offsets[D3D11_IA_VERTEX_INPUT_RESOURCE_SLOT_COUNT];
		UINT numBuffers{};

		assert(curVertexShader_->NumBuffersExpected() <= _countof(buffers));
		assert(curVertexShader_->NumBuffersExpected() <= _countof(strides));
		assert(curVertexShader_->NumBuffersExpected() <= _countof(offsets));

		if (curVertexBuffer_ && curVertexShader_) {
			numBuffers = curVertexBuffer_->MakeBufferList(curVertexShader_->config, buffers,
				strides);
		}
		else {
			numBuffers = curVertexShader_ ? curVertexShader_->NumBuffersExpected() : 0;
			std::fill_n(buffers, numBuffers, nullptr);
			std::fill_n(strides, numBuffers, 0);
		}

		std::fill_n(offsets, numBuffers, 0);
		context_->IASetVertexBuffers(0, numBuffers, buffers, strides, offsets);

		lastVertexBuffer_ = curVertexBuffer_;
		lastVertexShader_ = curVertexShader_;
	}

	void GSDevice::LoadVertexBufferData(GSVertexBufferPtr buf, const VertexShaderConfig& config)
	{
		//if(curVertexBuffer_ == buf) return;

		ID3D11Buffer* buffers[D3D11_IA_VERTEX_INPUT_RESOURCE_SLOT_COUNT];
		uint32_t strides[D3D11_IA_VERTEX_INPUT_RESOURCE_SLOT_COUNT];
		uint32_t offsets[D3D11_IA_VERTEX_INPUT_RESOURCE_SLOT_COUNT];
		UINT numBuffers{};

		if (buf) {
			numBuffers = buf->MakeBufferList(config, buffers, strides);
		}
		else {
			numBuffers = 0;
			std::fill_n(buffers, numBuffers, nullptr);
			std::fill_n(strides, numBuffers, 0);
		}

		std::fill_n(offsets, numBuffers, 0);
		context_->IASetVertexBuffers(0, numBuffers, buffers, strides, offsets);

		lastVertexBuffer_ = curVertexBuffer_;
		curVertexBuffer_ = buf;
		//lastVertexShader_ = nullptr;
	}

	void GSDevice::LoadIndexBufferData(GSIndexBufferPtr indexbuffer)
	{
		DXGI_FORMAT format;
		ID3D11Buffer* buffer;

		//if (curIndexBuffer_ == indexbuffer)
		//	return;

		if (indexbuffer) {
			switch (sizeof(index_data::value_type)) {
			case 2:
				format = DXGI_FORMAT_R16_UINT;
				break;
			default:
			case 4:
				format = DXGI_FORMAT_R32_UINT;
				break;
			}

			buffer = indexbuffer->indexBuffer_;
		}
		else {
			buffer = NULL;
			format = DXGI_FORMAT_R32_UINT;
		}

		curIndexBuffer_ = indexbuffer;
		context_->IASetIndexBuffer(buffer, format, 0);
	}

	void GSDevice::CopyTex(ID3D11Texture2D* dst, uint32_t dst_x, uint32_t dst_y,
		GSTexture2DPtr src, uint32_t src_x, uint32_t src_y, uint32_t src_w,
		uint32_t src_h)
	{

		GSTexture2D* tex2d = src;

		if (dst_x == 0 && dst_y == 0 && src_x == 0 && src_y == 0 && src_w == 0 && src_h == 0) {
			context_->CopyResource(dst, tex2d->texture_);
		}
		else {
			D3D11_BOX sbox;

			sbox.left = src_x;
			if (src_w > 0)
				sbox.right = src_x + src_w;
			else
				sbox.right = tex2d->width_ - 1;

			sbox.top = src_y;
			if (src_h > 0)
				sbox.bottom = src_y + src_h;
			else
				sbox.bottom = tex2d->height_ - 1;

			sbox.front = 0;
			sbox.back = 1;

			context_->CopySubresourceRegion(dst, 0, dst_x, dst_y, 0, tex2d->texture_, 0, &sbox);
		}
	}

	void GSDevice::UpdateViewProjMatrix(const matrix4& viewMatrix)
	{
		// graphics view matirx?
		curViewMatrix_ = viewMatrix;
		//gs_matrix_get(&curViewMatrix_);

		/* negate Z col of the view matrix for right-handed coordinate system */
		curViewMatrix_._13 = -curViewMatrix_._13;
		curViewMatrix_._23 = -curViewMatrix_._23;
		curViewMatrix_._33 = -curViewMatrix_._33;
		curViewMatrix_._43 = -curViewMatrix_._43;

		//matrix4_mul(curViewProjMatrix_, curViewMatrix_, curProjMatrix_);
		//matrix4_transpose(curViewProjMatrix_, curViewProjMatrix_);
		curVertexShader_->view_ = curViewMatrix_;
		//if (curVertexShader_->viewProj_)
		//	gs_shader_set_matrix4(curVertexShader_->viewProj_, &curViewProjMatrix_);
	}

	void GSDevice::FlushOutputViews()
	{
		if (curFramebufferInvalidate_) {
			ID3D11RenderTargetView* rtv = nullptr;
			if (curRenderTarget_) {
				const int i = curRenderSide_;
				rtv = curFramebufferSrgb_ ? curRenderTarget_->renderTargetLinear_[i].Get()
					: curRenderTarget_->renderTarget_[i].Get();
				if (!rtv) {
					XLOG(LOG_ERROR,
						"device_draw (D3D11): texture is not a render target");
					return;
				}
			}
			ID3D11DepthStencilView* dsv = nullptr;
			if (curZStencilBuffer_)
				dsv = curZStencilBuffer_->view_;
			context_->OMSetRenderTargets(1, &rtv, dsv);
			curFramebufferInvalidate_ = false;
		}
	}

	long GSDevice::RebuildDevice()
	{
		ID3D11Device* dev = nullptr;
		HRESULT hr = S_OK;

		XLOG(LOG_WARNING, "Device Remove/Reset!  Rebuilding all assets...");

		/* ----------------------------------------------------------------- */

		do {
			for (IDeviceEventListener* item : event_callbacks_)
				item->OnDeviceRemoved(nullptr);

			//GSObject* obj = objects_;

			//while (obj) {
			//	obj->Release();
			//	obj = obj->next_;
			//}
			auto it = objects_.begin();
			while (it != objects_.end())
			{
				auto obj = *it;
				obj->Release();
				++it;
			}

			for (auto& state : zstencilStates_)
				state.Release();
			for (auto& state : rasterStates_)
				state.Release();
			for (auto& state : blendStates_)
				state.Release();

			context_->ClearState();
			context_->Flush();

			context_.Clear();
			device_.Clear();
			adapter_.Clear();
			factory_.Clear();

			/* ----------------------------------------------------------------- */

			InitFactory();
			InitAdapter(adpIdx_);

			uint32_t createFlags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
			hr = D3D11CreateDevice(adapter_, D3D_DRIVER_TYPE_UNKNOWN, nullptr, createFlags,
				featureLevels,
				sizeof(featureLevels) / sizeof(D3D_FEATURE_LEVEL),
				D3D11_SDK_VERSION, &device_, nullptr, &context_);
			if (FAILED(hr)) {
				XLOG("Failed to create device", hr);
				break;
			}

			dev = device_;

			// rebuild all objects_
			it = objects_.begin();
			while (it != objects_.end()) {
				auto obj = *it;
				switch (obj->obj_type_) {
				case E_GSType::ktexture_2d: {
					GSTexture2D* tex = (GSTexture2D*)obj;
					if (!tex->pairedTexture_) {
						tex->Rebuild(dev);
					}
					else if (!tex->chroma_) {
						tex->RebuildPaired_Y(dev);
					}
					break;
				}
				case E_GSType::kduplicator: {
					long result = ((GSDuplicator*)obj)->Start();
					if (result)
						((GSDuplicator*)obj)->Release();
					break;
				}
				default:
					obj->Rebuild(dev);
					break;
				}
				//obj = obj->next_;
				++it;
			}

			curRenderTarget_ = nullptr;
			curZStencilBuffer_ = nullptr;
			curRenderSide_ = 0;
			memset(&curTextures_, 0, sizeof(curTextures_));
			memset(&curSamplers_, 0, sizeof(curSamplers_));
			curVertexBuffer_ = nullptr;
			curIndexBuffer_ = nullptr;
			curVertexShader_ = nullptr;
			curPixelShader_ = nullptr;
			curSwapChain_ = nullptr;
			zstencilStateChanged_ = true;
			rasterStateChanged_ = true;
			blendStateChanged_ = true;
			curDepthStencilState_ = nullptr;
			curRasterState_ = nullptr;
			curBlendState_ = nullptr;
			curToplogy_ = D3D11_PRIMITIVE_TOPOLOGY_UNDEFINED;

			for (auto& state : zstencilStates_)
				state.Rebuild(dev);
			for (auto& state : rasterStates_)
				state.Rebuild(dev);
			for (auto& state : blendStates_)
				state.Rebuild(dev);

			for (IDeviceEventListener* item : event_callbacks_)
				item->OnDeviceRebuild(device_, nullptr);
		} while (false);

		return hr;
	}

#define NV12_CX 128
#define NV12_CY 128
	bool GSDevice::HasBadNV12Output()
	{
		return true;
		//try {
		//	vec3 points[4] = {
		//		{ -1.0f, -1.0f, 0.0f}
		//		, {-1.0f, 1.0f, 0.0f}
		//		, {1.0f, -1.0f, 0.0f}
		//		, {1.0f, 1.0f, 0.0f}
		//	};

		//	GSTexture2D nv12_y(this, NV12_CX, NV12_CY, GS_R8, 1, nullptr, GS_RENDER_TARGET | GS_SHARED_KM_TEX, GS_TEXTURE_2D, false, true);
		//	GSTexture2D nv12_uv(this, nv12_y.texture, GS_RENDER_TARGET | GS_SHARED_KM_TEX);
		//	GSVertexShader nv12_vs(this, "", NV12_VS);
		//	GSPixelShader nv12_y_ps(this, "", NV12_Y_PS);
		//	GSPixelShader nv12_uv_ps(this, "", NV12_UV_PS);
		//	GSStageSurface nv12_stage(this, NV12_CX, NV12_CY, false);

		//	gs_vb_data *vbd = gs_vbdata_create();
		//	vbd->num = 4;
		//	vbd->points = (vec3 *)bmemdup(&points, sizeof(points));

		//	gs_vertex_buffer buf(this, vbd, 0);

		//	device_load_vertexbuffer(this, &buf);
		//	device_load_vertexshader(this, &nv12_vs);

		//	context_->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);

		//	device_set_viewport(this, 0, 0, NV12_CX, NV12_CY);
		//	device_set_cull_mode(this, GS_NEITHER);
		//	device_enable_depth_test(this, false);
		//	device_enable_blending(this, false);
		//	LoadVertexBufferData();

		//	device_set_render_target(this, &nv12_y, nullptr);
		//	device_load_pixelshader(this, &nv12_y_ps);
		//	UpdateBlendState();
		//	UpdateRasterState();
		//	UpdateZStencilState();
		//	FlushOutputViews();
		//	context_->Draw(4, 0);

		//	device_set_viewport(this, 0, 0, NV12_CX / 2, NV12_CY / 2);
		//	device_set_render_target(this, &nv12_uv, nullptr);
		//	device_load_pixelshader(this, &nv12_uv_ps);
		//	UpdateBlendState();
		//	UpdateRasterState();
		//	UpdateZStencilState();
		//	FlushOutputViews();
		//	context_->Draw(4, 0);

		//	device_load_pixelshader(this, nullptr);
		//	device_load_vertexbuffer(this, nullptr);
		//	device_load_vertexshader(this, nullptr);
		//	device_set_render_target(this, nullptr, nullptr);

		//	device_stage_texture(this, &nv12_stage, &nv12_y);

		//	uint8_t *data;
		//	uint32_t linesize;
		//	bool bad_driver = false;

		//	if (gs_stagesurface_map(&nv12_stage, &data, &linesize)) {
		//		bad_driver = data[linesize * NV12_CY] == 0;
		//		gs_stagesurface_unmap(&nv12_stage);
		//	} else {
		//		throw "Could not map surface";
		//	}

		//	if (bad_driver) {
		//		blog(LOG_WARNING, "Bad NV12 texture handling detected!  "
		//				  "Disabling NV12 texture support.");
		//	}
		//	return bad_driver;

		//} catch (const HRError &error) {
		//	blog(LOG_WARNING, "HasBadNV12Output failed: %s (%08lX)", error.str, error.hr);
		//	return false;
		//} catch (const char *error) {
		//	blog(LOG_WARNING, "HasBadNV12Output failed: %s", error);
		//	return false;
		//}
	}

	long GSDevice::SetLastError(long err)
	{
		long result = last_error_;
		last_error_ = err;
		return result;
	}

	long GSDevice::GetLastError() const
	{
		return last_error_;
	}

	long GSDevice::SetRenderTarget(GSTexture2DPtr tex, GSZstencilBufferPtr zstencil,
		gs_color_space space /* = GS_CS_SRGB*/)
	{
		if (curSwapChain_) {
			if (!tex)
				tex = &curSwapChain_->target_;
			if (!zstencil)
				zstencil = &curSwapChain_->zstencilBuffer_;
		}

		if (curRenderTarget_ == tex && curZStencilBuffer_ == zstencil) {
			curColorSpace_ = space;
		}

		if (!tex) {
			XLOG(LOG_ERROR,
				"device_set_render_target_internal (D3D11): texture is not a 2D texture");
			return E_INVALIDARG;
		}

		//GSTexture2D *const tex2d = static_cast<GSTexture2D *>(tex);
		if (curRenderTarget_ != tex || curRenderSide_ != 0 || curZStencilBuffer_ != zstencil) {
			curRenderTarget_ = tex;
			curZStencilBuffer_ = zstencil;
			curRenderSide_ = 0;
			curColorSpace_ = space;
			curFramebufferInvalidate_ = true;
		}

		return S_OK;
	}

}