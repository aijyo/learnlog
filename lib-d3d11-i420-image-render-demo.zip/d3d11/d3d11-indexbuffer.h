#pragma once
#ifndef __X_D3D11_INDEXBUFFER_H__
#define __X_D3D11_INDEXBUFFER_H__

#include <cstdint>
#include "./d3d11-subsystem.h"
namespace lib_d3d {

//class VertexPosNormalTex {
//public:
//	VertexPosNormalTex() = default;
//
//	VertexPosNormalTex(const VertexPosNormalTex &) = default;
//	VertexPosNormalTex &operator=(const VertexPosNormalTex &) = default;
//
//	VertexPosNormalTex(VertexPosNormalTex &&) = default;
//	VertexPosNormalTex &operator=(VertexPosNormalTex &&) = default;
//
//	constexpr VertexPosNormalTex(const DirectX::XMFLOAT3 &_pos, const DirectX::XMFLOAT3 &_normal, const DirectX::XMFLOAT2 &_tex) : pos(_pos), normal(_normal), tex(_tex) {}
//
//	DirectX::XMFLOAT3 pos;
//	DirectX::XMFLOAT3 normal;
//	DirectX::XMFLOAT2 tex;
//	static const D3D11_INPUT_ELEMENT_DESC inputLayout[3];
//};

//using indexDataTypeLong = std::vector<uint32_t>;
//using indexDataTypeLongPtr = std::shared_ptr<indexDataTypeLong>;
//using indexDataTypeShort = std::vector<uint16_t>;
//using indexDataTypeShortPtr = std::shared_ptr<indexDataTypeShort>;
class LIB_EXPORT GSIndexBuffer : public GSObject {
public:
	GSIndexBuffer(GSDevice *device, uint32_t flags);
	virtual ~GSIndexBuffer();

	long Create(index_data_ptr data);
	long Destroy();

	uint32_t PointNum() const { return (uint32_t)index_data_->size(); }

	long InitBuffer();
	virtual long Rebuild(ID3D11Device *dev);
	virtual long Flush(index_data_ptr data);

	inline long Release();

public:
	ComPtr<ID3D11Buffer> indexBuffer_;
	bool dynamic_;

	index_data_ptr index_data_;
	//gs_index_type indexType_;
	//size_t indexSize_;

	D3D11_BUFFER_DESC bufDesc_ = {};
	D3D11_SUBRESOURCE_DATA sourceData_ = {};
};

//using GSIndexBufferPtr = std::shared_ptr<GSIndexBuffer>;
using GSIndexBufferPtr = GSIndexBuffer *;
////////////////////////////////////////////////////////////////////////////
//class GSIndexBufferShort : public GSIndexBuffer
//{
//public:
//public:
//	GSIndexBufferShort(GSDevice *device, indexDataTypeShortPtr indices, uint32_t flags);
//	~GSIndexBufferShort();

//	long Create();
//	long Destroy();

//	long InitBuffer();
//protected:
//	void* Data() const;
//public:
//	indexDataTypeShortPtr indices_;
//};

////////////////////////////////////////////////////////////////////////////
//class GSIndexBufferLong : public GSIndexBuffer
//{

//public:
//	GSIndexBufferLong(GSDevice *device, std::shared_ptr<indexDataTypeLong> indices, uint32_t flags);
//	~GSIndexBufferLong();

//	long Create();
//	long Destroy();

//protected:
//	void* Data() const;
//public:
//	indexDataTypeLongPtr indices_;

//};
}
#endif