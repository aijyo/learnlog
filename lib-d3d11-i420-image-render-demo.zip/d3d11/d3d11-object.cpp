#include "d3d11-object.h"
#include "d3d11-device.h"
namespace lib_d3d {
GSObject::GSObject(GSDevice *device_, E_GSType type) : device_(device_), obj_type_(type)
{
	//prev_next = &device->first_obj;
	//next = device->first_obj;
	//device->first_obj = this;
	//if (next)
	//	next->prev_next = &next;
	device_->objects_.emplace_back(this);
}

GSObject::~GSObject()
{
	//if (prev_next_) {
	//	*prev_next_ = next_;
	//	//prev_next_ = nullptr;
	//}
	//if (next_) {
	//	next_->prev_next_ = prev_next_;
	//	//next_ = nullptr;
	//}
	device_->objects_.remove(this);
	Destroy();
}

//GSObject::GSObject(const GSObject& rhs)
//	: GSObject(rhs.device_, rhs.obj_type_)
//{

//}

//GSObject::GSObject(GSObject&& rhs)
//	: GSObject(rhs.device_, rhs.obj_type_)
//{
//	move(std::forward<GSObject>(rhs));
//}

//GSObject& GSObject::operator=(const GSObject& rhs)
//{
//	copy(rhs);
//}

//GSObject& GSObject::operator=(GSObject&& rhs)
//{
//	move(std::forward<GSObject>(rhs));
//}

//void GSObject::copy(const GSObject& rhs)
//{
//	device_ = rhs.device_;
//	obj_type_ = rhs.obj_type_;
//}

//void GSObject::move(GSObject&& rhs)
//{
//	device_ = rhs.device_;
//	obj_type_ = rhs.obj_type_;

//	if (prev_next_)
//		*prev_next_ = next_;
//	if (next_)
//		next_->prev_next_ = prev_next_;

//	rhs.next_ = nullptr;
//	rhs.prev_next_ = nullptr;
//}
}