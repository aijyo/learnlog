#include "d3d11-zstencilbuffer.h"
#include "d3d11-device.h"
#include "lib-d3d11/graphics/d3d11-helper.h"

namespace lib_d3d {

	long GSZstencilBuffer::Create()
	{
		long result = InitBuffer();
		return result;
	}

	long GSZstencilBuffer::Destroy()
	{

		return 0;
	}

	long GSZstencilBuffer::InitBuffer()
	{
		HRESULT hr = S_OK;

		memset(&texture_desc_, 0, sizeof(texture_desc_));
		texture_desc_.Width = width_;
		texture_desc_.Height = height_;
		texture_desc_.MipLevels = 1;
		texture_desc_.ArraySize = 1;
		texture_desc_.Format = dxgiFormat_;
		texture_desc_.BindFlags = D3D11_BIND_DEPTH_STENCIL;
		texture_desc_.SampleDesc.Count = 1;
		texture_desc_.Usage = D3D11_USAGE_DEFAULT;

		do {
			hr = device_->device_->CreateTexture2D(&texture_desc_, NULL, texture_.Assign());
			if (FAILED(hr)) {
				device_->SetLastError(hr);
				XLOG("Failed to create depth stencil texture", hr);
				break;
			}

			memset(&dsvd_, 0, sizeof(dsvd_));
			dsvd_.Format = dxgiFormat_;
			dsvd_.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;

			hr = device_->device_->CreateDepthStencilView(texture_, &dsvd_, view_.Assign());
			if (FAILED(hr)) {

				device_->SetLastError(hr);
				XLOG("Failed to create depth stencil view", hr);
				break;
			}
		} while (false);
		return hr;
	}

	GSZstencilBuffer::GSZstencilBuffer(GSDevice* device, uint32_t width, uint32_t height,
		gs_zstencil_format format)
		: GSObject(device, E_GSType::kzstencil_buffer),
		width_(width),
		height_(height),
		format_(format),
		dxgiFormat_(GrpahicsHelper::ConvertGSZStencilFormat(format))
	{
	}

	long GSZstencilBuffer::Rebuild(ID3D11Device* dev)
	{
		HRESULT hr = S_OK;

		do {
			hr = dev->CreateTexture2D(&texture_desc_, nullptr, &texture_);
			if (FAILED(hr)) {
				XLOG("Failed to create depth stencil texture", hr);
				break;
			}

			hr = dev->CreateDepthStencilView(texture_, &dsvd_, &view_);
			if (FAILED(hr)) {
				XLOG("Failed to create depth stencil view", hr);
				break;
			}
		} while (false);
		return hr;
	}

	long GSZstencilBuffer::Release()
	{
		texture_.Release();
		view_.Release();

		return 0;
	}
}