# run_mesh_interactive.ps1 — launch the interactive eCDN mesh in separate windows.
#   Opens: 1 scheduler, 1 origin, 2 super nodes (primary+backup), 2 normal nodes — all in LAN "A".
# To see failover: focus the "SN-A (primary)" window and press Ctrl-C. Watch the two NN windows
# print "parent lost -> auto_switch_parent" and resume streaming from SN-A2.
$ErrorActionPreference = "Stop"
$rel = (Resolve-Path "$PSScriptRoot\build\Release").Path
function win($title, $exe, $argline) {
  Start-Process cmd.exe -ArgumentList '/k', "title $title & `"$rel\$exe`" $argline"
}
win "SCHEDULER"        "mesh_scheduler.exe" ""
Start-Sleep -Milliseconds 700
win "ORIGIN (cloud)"   "mesh_origin.exe"    ""
Start-Sleep -Milliseconds 700
win "SN-A (primary)"   "mesh_node.exe"      "--id sn-a  --lan A"
win "SN-A2 (backup)"   "mesh_node.exe"      "--id sn-a2 --lan A"
Start-Sleep -Milliseconds 700
win "NN-A1"            "mesh_node.exe"      "--id nn-a1 --lan A"
win "NN-A2"            "mesh_node.exe"      "--id nn-a2 --lan A"
Write-Host ""
Write-Host "Launched 6 windows in LAN 'A' (scheduler + origin + 2 super nodes + 2 normal nodes)."
Write-Host "FAILOVER TEST: click the 'SN-A (primary)' window, press Ctrl-C to kill it," -ForegroundColor Yellow
Write-Host "               then watch NN-A1 / NN-A2 re-parent to SN-A2 and keep streaming." -ForegroundColor Yellow
Write-Host "Add more viewers any time:  build\Release\mesh_node.exe --id nn-a3 --lan A"
Write-Host "Second LAN (independent super node):  ... --id sn-b --lan B   and   --id nn-b1 --lan B"
