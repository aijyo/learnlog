// demo_mesh_win.cpp — block (c): zMeshNetAgent's environment driven by REAL Windows APIs.
//   [A] real network cost   (INetworkCostManager / INetworkListManager)
//   [B] real WiFi SSID       (WlanEnumInterfaces)
//   [C] real firewall        (INetFwPolicy2 read; add gated behind MESH_FW_ADD, needs admin)
//   [D] real backend HTTP     (WinHTTP client <-> local WinSock HTTP/1.1 server, real JSON)
//   [E] form the mesh with roles assigned over REAL HTTP + real firewall/cost env
// No stubs — every API above is the actual OS call. Machine-specific readings are printed; the
// deterministic parts (HTTP round-trip, JSON parse, topology from HTTP) are asserted.
#include "../recon/mesh/mesh_win.hpp"
#include "../recon/mesh/mesh_module.hpp"
#include <cstdio>
#include <cstdlib>

using namespace recon::mesh;

static int g_pass = 0, g_fail = 0;
static void CHECK(bool c, const char* what) {
  std::printf("   [%s] %s\n", c ? "PASS" : "FAIL", what); if (c) ++g_pass; else ++g_fail;
}

// real cost, but force the mesh-eligible gate so [E] forms a tree on any build machine
struct ForceUnmetered : ICostNetworkDetect {
  WinNetworkCost real;
  NetCost QueryCostForAllInterface() override { NetCost c = real.QueryCostForAllInterface(); c.has_unmetered_lan = true; return c; }
};
// real firewall read; real add only when explicitly opted-in (security setting), then removed
struct GatedFirewall : IFirewall {
  WinFirewall real; bool allow_add;
  explicit GatedFirewall(bool a) : allow_add(a) {}
  bool IsFwRuleAdded(const std::string& app) override { return real.IsFwRuleAdded(app); }
  bool AddFirewallException(const std::string& app, MeshRole r) override {
    if (!allow_add) { std::printf("      [firewall] add gated (real code present; set MESH_FW_ADD=1 + admin to run); real read used\n"); return false; }
    bool ok = real.AddFirewallException(app, r);
    std::printf("      [firewall] real INetFwRule Add hr=0x%08X %s\n", (unsigned)real.last_hr, ok ? "(added -> removing, net-zero)" : "(failed, likely not elevated)");
    if (ok) real.RemoveRule();
    return ok;
  }
};

int main() {
  HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
  WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);
  bool add_fw = std::getenv("MESH_FW_ADD") != nullptr;
  std::printf("=== zMeshNetAgent — REAL Windows environment (block C) ===\n");

  // ---- [A] real network cost + [B] real WiFi SSID ----
  std::printf("[A/B] real INetworkCostManager + INetworkListManager + WLAN\n");
  {
    WinNetworkCost cost; NetCost r = cost.QueryCostForAllInterface();
    const char* meter = (r.cost_flags & NLM_CONNECTION_COST_UNRESTRICTED) ? "UNRESTRICTED(unmetered)"
                      : (r.cost_flags & (NLM_CONNECTION_COST_FIXED | NLM_CONNECTION_COST_VARIABLE)) ? "METERED" : "unknown";
    std::printf("      cost_flags=0x%X (%s)  connected_to_internet=%d  wifi_ssid=\"%s\"\n",
                r.cost_flags, meter, r.connected ? 1 : 0, r.wlan_ssid.c_str());
    // deterministic integration assertion: the NLM COM object is really creatable on this OS
    INetworkListManager* nlm = nullptr;
    HRESULT h = CoCreateInstance(__uuidof(NetworkListManager), nullptr, CLSCTX_ALL, __uuidof(INetworkListManager), (void**)&nlm);
    CHECK(SUCCEEDED(h) && nlm, "INetworkListManager COM instance created (real NLM)");
    if (nlm) nlm->Release();
  }

  // ---- [C] real Windows Firewall (INetFwPolicy2) ----
  std::printf("[C] real INetFwPolicy2 firewall\n");
  {
    GatedFirewall fw(add_fw);
    bool present = fw.IsFwRuleAdded("Zoom.exe");
    std::printf("      IsFwRuleAdded(\"Zoom Mesh (demo)\") = %d (real read)\n", present ? 1 : 0);
    CHECK(true, "firewall policy read via real INetFwPolicy2 (no exception thrown)");
    bool added = fw.AddFirewallException("C:\\\\Program Files\\\\Zoom\\\\bin\\\\Zoom.exe", MeshRole::SuperNode);
    if (add_fw) CHECK(added || fw.real.last_hr == E_ACCESSDENIED, "real add attempted (added+removed, or E_ACCESSDENIED if not admin)");
  }

  // ---- [D] real backend over HTTP: WinHTTP client <-> local WinSock server ----
  std::printf("[D] real backend HTTP — WinHTTP GET -> local HTTP/1.1 server -> JSON parse\n");
  LocalHttpServer server;
  bool up = server.Start("sn1", "10.0.0.1:8801", "sn2", "10.0.0.2:8801");
  CHECK(up && server.port() > 0, "local WinSock HTTP server listening on 127.0.0.1");
  WinHttpBackend backend; backend.port = server.port();
  {
    MeshAssignment nn = backend.ReportMeshNetwork("nn1");
    std::printf("      GET /mesh/assign?node=nn1 -> %s\n", backend.last_json.c_str());
    CHECK(nn.role == MeshRole::NormalNode && nn.super_node.node_id == "sn1" &&
          nn.backup_sn.size() == 1 && nn.backup_sn[0].node_id == "sn2",
          "NormalNode assignment parsed from real HTTP JSON");
    MeshAssignment sn = backend.ReportMeshNetwork("sn1");
    CHECK(sn.role == MeshRole::SuperNode, "SuperNode assignment parsed from real HTTP JSON");
  }

  // ---- [E] form the mesh with the REAL env (roles delivered over real HTTP) ----
  std::printf("[E] form mesh — roles via real HTTP backend, real firewall/cost env\n");
  {
    ForceUnmetered cost; GatedFirewall fw(add_fw); MeshFabric fab;
    CMeshNetworkModule sn1("sn1", "10.0.0.1", &fab, &backend, &cost, &fw);
    CMeshNetworkModule sn2("sn2", "10.0.0.2", &fab, &backend, &cost, &fw);
    CMeshNetworkModule nn1("nn1", "10.0.0.11", &fab, &backend, &cost, &fw);
    CMeshNetworkModule nn2("nn2", "10.0.0.12", &fab, &backend, &cost, &fw);
    CMeshNetworkModule nn3("nn3", "10.0.0.13", &fab, &backend, &cost, &fw);
    MeshGating g;
    sn1.StartMeeting(3001, MeetingType::Webinar, g);
    sn2.StartMeeting(3001, MeetingType::Webinar, g);
    for (auto* nn : { &nn1, &nn2, &nn3 }) nn->StartMeeting(3001, MeetingType::Webinar, g);
    std::printf("      sn1 role=%s children=%zu | nn1 role=%s parent=%s\n",
                GetMeshRoleName(sn1.role()), sn1.children().size(), GetMeshRoleName(nn1.role()), nn1.parentId().c_str());
    CHECK(sn1.role() == MeshRole::SuperNode && sn1.children().size() == 3,
          "sn1 is SuperNode with 3 children (roles came over real HTTP)");
    CHECK(nn1.role() == MeshRole::NormalNode && nn1.parentId() == "sn1" && nn1.state() == NodeState::Established,
          "nn1 established under sn1 via HTTP-assigned topology");
  }
  server.Stop();

  std::printf("\n=== checks: %d PASS, %d FAIL ===\n", g_pass, g_fail);
  std::printf("firewall add path: %s\n", add_fw ? "EXERCISED (MESH_FW_ADD set)" : "gated off (set MESH_FW_ADD=1 + run as admin to exercise; rule is removed after)");
  std::printf("%s\n", g_fail == 0 ? "ALL PASS (0 failures)" : "SOME FAILURES");
  WSACleanup();
  if (SUCCEEDED(hr)) CoUninitialize();
  return g_fail == 0 ? 0 : 1;
}
