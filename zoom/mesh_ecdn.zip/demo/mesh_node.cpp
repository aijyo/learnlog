// mesh_node.exe — a mesh client you launch yourself. It asks the scheduler for a role, then:
//   SuperNode : pulls the live stream from the origin ONCE and relays every frame to its LAN peers.
//   NormalNode: receives the stream from its assigned SuperNode; if that SN dies, it re-parents to
//               the backup (auto_switch_parent) and resumes — kill an SN process to see it live.
//
//   Usage: mesh_node --id <id> --lan <A> [--sched 127.0.0.1:7000] [--origin 127.0.0.1:7001]
#include "../recon/mesh/mesh_cli.hpp"
#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

using namespace recon::mesh;

static std::string seq_of(const std::string& frame) { auto t = split(frame); return t.size() >= 2 ? t[1] : "?"; }

int main(int argc, char** argv) {
  net_init();
  std::string id = arg(argc, argv, "--id", "node1");
  std::string lan = arg(argc, argv, "--lan", "A");
  auto sched = hostport(arg(argc, argv, "--sched", "127.0.0.1:7000"), 7000);
  auto origin = hostport(arg(argc, argv, "--origin", "127.0.0.1:7001"), 7001);
  logl("[" + id + "] joining mesh (LAN " + lan + ")  scheduler=" + sched.first + ":" + std::to_string(sched.second));

  std::string role = rpc(sched.first, sched.second, "JOIN " + id + " " + lan);
  if (role.empty()) { logl("[" + id + "] scheduler unreachable"); return 2; }

  // ================= SUPER NODE =================
  if (role.rfind("ROLE SN", 0) == 0) {
    int relayPort = 0;
    SOCKET relay = listen_on(0, relayPort);
    if (relay == INVALID_SOCKET) { logl("[" + id + "] relay bind failed"); return 2; }
    // hold a control connection open = liveness signal to the scheduler
    SOCKET ctrl = connect_host(sched.first, sched.second);
    std::string ok;
    if (ctrl == INVALID_SOCKET || !write_msg(ctrl, "SN_UP " + id + " " + lan + " 127.0.0.1 " + std::to_string(relayPort)) || !read_msg(ctrl, ok)) {
      logl("[" + id + "] SN_UP failed"); return 2;
    }
    logl("[" + id + "] role=SuperNode, relay listening on 127.0.0.1:" + std::to_string(relayPort) + " — pulling from origin");

    SOCKET up = connect_host(origin.first, origin.second);
    if (up == INVALID_SOCKET) { logl("[" + id + "] cannot reach origin"); return 2; }

    std::vector<SOCKET> children; std::mutex cmu;
    // accept LAN peers concurrently
    std::thread([&] {
      for (;;) { SOCKET c = accept(relay, nullptr, nullptr); if (c == INVALID_SOCKET) break;
        std::lock_guard<std::mutex> g(cmu); children.push_back(c);
        logl("[" + id + "] normal node connected  (serving " + std::to_string(children.size()) + " LAN peers)"); }
    }).detach();

    // pull frames from origin, fan out to LAN peers
    for (;;) {
      std::string frame;
      if (!read_msg(up, frame)) { logl("[" + id + "] origin connection lost — exiting"); break; }
      std::lock_guard<std::mutex> g(cmu);
      for (size_t i = 0; i < children.size();) {
        if (write_msg(children[i], frame)) ++i;
        else { closesocket(children[i]); children.erase(children.begin() + i); logl("[" + id + "] a LAN peer dropped  (now " + std::to_string(children.size()) + ")"); }
      }
      if (seq_of(frame) != "?" && (atoi(seq_of(frame).c_str()) % 5 == 0))
        logl("[" + id + "] relayed frame " + seq_of(frame) + " -> " + std::to_string(children.size()) + " LAN peers");
    }
    return 0;
  }

  // ================= NORMAL NODE =================
  logl("[" + id + "] role=NormalNode");
  for (;;) {
    // ask the scheduler for the current (live) super node for this LAN
    std::string host; int port = 0;
    for (int tries = 0; tries < 200; ++tries) {
      std::string p = rpc(sched.first, sched.second, "REPARENT " + id + " " + lan);
      auto t = split(p);
      if (t.size() >= 3 && t[0] == "SN") { host = t[1]; port = atoi(t[2].c_str()); break; }
      std::this_thread::sleep_for(std::chrono::milliseconds(200));   // WAIT: no live SN yet
    }
    if (port == 0) { logl("[" + id + "] no super node available; giving up"); return 2; }

    SOCKET sn = connect_host(host, port);
    if (sn == INVALID_SOCKET) { logl("[" + id + "] super node " + host + ":" + std::to_string(port) + " unreachable — retrying"); std::this_thread::sleep_for(std::chrono::milliseconds(300)); continue; }
    logl("[" + id + "] connected to super node " + host + ":" + std::to_string(port) + " — receiving stream");

    for (;;) {
      std::string frame;
      if (!read_msg(sn, frame)) break;                     // parent died
      logl("[" + id + "] got frame " + seq_of(frame) + " via " + host + ":" + std::to_string(port));
    }
    closesocket(sn);
    logl("[" + id + "] *** parent lost — auto_switch_parent (re-parenting to backup) ***");
  }
}
