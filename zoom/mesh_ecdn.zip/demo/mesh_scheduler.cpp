// mesh_scheduler.exe — the eCDN mesh coordinator. Assigns roles (first N joiners per LAN become
// Super Nodes, rest Normal Nodes), holds each Super Node's control connection for liveness, and on
// a Super Node's death promotes the next backup + re-points Normal Nodes. Real TCP.
//
//   Protocol (length-prefixed text):
//     JOIN <node> <lan>       -> "ROLE SN"  |  "ROLE NN <host> <port>"  |  "ROLE NN WAIT"
//     SN_UP <node> <lan> <host> <port>  (held open = liveness) -> "OK"
//     REPARENT <node> <lan>   -> "SN <host> <port>"  |  "WAIT"
#include "../recon/mesh/mesh_cli.hpp"
#include <atomic>
#include <map>
#include <mutex>
#include <thread>
#include <vector>

using namespace recon::mesh;

static const int SN_PER_LAN = 2;   // primary + backup

struct Sn { std::string node, host; int port = 0; bool announced = false, alive = false; };
struct Lan { std::vector<Sn> sns; std::vector<std::string> nns; };

static std::map<std::string, Lan> g_lans;
static std::mutex g_mu;
static int first_alive_index(const Lan& l);   // fwd

static void print_topology() {
  std::string s = "---- topology ----";
  for (auto& kv : g_lans) {
    s += "\n  LAN " + kv.first + ":";
    for (size_t i = 0; i < kv.second.sns.size(); ++i) {
      auto& n = kv.second.sns[i];
      const char* tag = !n.alive ? "DOWN" : (first_alive_index(kv.second) == (int)i ? "PRIMARY" : "BACKUP");
      s += "  [SN " + n.node + "/" + tag + "]";
    }
    for (auto& nn : kv.second.nns) s += "  (NN " + nn + ")";
  }
  logl(s);
}
static int first_alive_index(const Lan& l) { for (size_t i = 0; i < l.sns.size(); ++i) if (l.sns[i].alive && l.sns[i].announced) return (int)i; return -1; }

static std::string primary_reply(Lan& l) {
  int i = first_alive_index(l);
  if (i < 0) return "WAIT";
  return "SN " + l.sns[i].host + " " + std::to_string(l.sns[i].port);
}

static void handle(SOCKET c) {
  std::string line; if (!read_msg(c, line)) { closesocket(c); return; }
  auto t = split(line);
  if (t.empty()) { closesocket(c); return; }

  if (t[0] == "JOIN" && t.size() >= 3) {
    std::string node = t[1], lan = t[2]; std::string reply;
    { std::lock_guard<std::mutex> g(g_mu); Lan& L = g_lans[lan];
      int sn_count = (int)L.sns.size();
      if (sn_count < SN_PER_LAN) { L.sns.push_back(Sn{ node, "", 0, false, false }); reply = "ROLE SN"; logl("[join] " + node + " LAN " + lan + " -> SuperNode slot " + std::to_string(sn_count)); }
      else { L.nns.push_back(node); std::string p = primary_reply(L); reply = (p == "WAIT") ? "ROLE NN WAIT" : ("ROLE NN " + p.substr(3)); logl("[join] " + node + " LAN " + lan + " -> NormalNode (parent " + (p == "WAIT" ? "WAIT" : p.substr(3)) + ")"); }
    }
    write_msg(c, reply); closesocket(c); return;
  }

  if (t[0] == "REPARENT" && t.size() >= 3) {
    std::string lan = t[2], reply;
    { std::lock_guard<std::mutex> g(g_mu); reply = primary_reply(g_lans[lan]); }
    logl("[reparent] " + t[1] + " LAN " + lan + " -> " + (reply == "WAIT" ? "WAIT" : reply.substr(3)));
    write_msg(c, reply); closesocket(c); return;
  }

  if (t[0] == "SN_UP" && t.size() >= 5) {
    std::string node = t[1], lan = t[2], host = t[3]; int port = atoi(t[4].c_str());
    { std::lock_guard<std::mutex> g(g_mu); Lan& L = g_lans[lan];
      for (auto& s : L.sns) if (s.node == node) { s.host = host; s.port = port; s.announced = true; s.alive = true; }
      logl("[sn-up] " + node + " LAN " + lan + " relay " + host + ":" + std::to_string(port)); print_topology(); }
    write_msg(c, "OK");
    // hold the connection open — its closure means the Super Node died
    std::string ignore; while (read_msg(c, ignore)) {}
    { std::lock_guard<std::mutex> g(g_mu); Lan& L = g_lans[lan];
      for (auto& s : L.sns) if (s.node == node) s.alive = false;
      logl("[DOWN] SuperNode " + node + " LAN " + lan + " lost — promoting backup"); print_topology(); }
    closesocket(c); return;
  }
  closesocket(c);
}

int main(int argc, char** argv) {
  net_init();
  int want = atoi(arg(argc, argv, "--port", "7000").c_str()), port = 0;
  SOCKET ls = listen_on(want, port);
  if (ls == INVALID_SOCKET) { logl("scheduler: bind failed on port " + std::to_string(want)); return 2; }
  logl("mesh scheduler listening on 127.0.0.1:" + std::to_string(port) + "  (SN_PER_LAN=" + std::to_string(SN_PER_LAN) + ")");
  for (;;) {
    SOCKET c = accept(ls, nullptr, nullptr);
    if (c == INVALID_SOCKET) break;
    std::thread(handle, c).detach();
  }
  return 0;
}
