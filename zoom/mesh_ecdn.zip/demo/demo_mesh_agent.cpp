// demo_mesh_agent.cpp — runnable, testable reconstruction of zMeshNetAgent's control plane.
//
// Simulates the full eCDN mesh lifecycle across real CMeshNetworkModule instances wired through
// an in-process fabric: gating -> cost detect -> backend role assignment -> SN/NN handshake tree
// -> super-node crash -> auto_switch_parent failover -> role promotion. Pure C++, no deps.
#include "../recon/mesh/mesh_module.hpp"
#include <cstdio>
#include <memory>
#include <string>
#include <vector>

using namespace recon::mesh;

static int g_pass = 0, g_fail = 0;
static void CHECK(bool c, const char* what) {
  std::printf("   [%s] %s\n", c ? "PASS" : "FAIL", what);
  if (c) ++g_pass; else ++g_fail;
}
static std::string join(const std::vector<std::string>& v) {
  std::string s; for (size_t i = 0; i < v.size(); ++i) { if (i) s += ","; s += v[i]; } return s;
}
static void dump(CMeshNetworkModule& n) {
  std::printf("      %-4s role=%-10s parent=%-4s children=[%s] state=%s\n",
              n.id().c_str(), GetMeshRoleName(n.role()),
              n.parentId().empty() ? "-" : n.parentId().c_str(),
              join(n.children()).c_str(), StateName(n.state()));
}
static bool traced(CMeshNetworkModule& n, const std::string& needle) {
  for (auto& l : n.trace()) if (l.find(needle) != std::string::npos) return true;
  return false;
}

int main() {
  std::printf("=== zMeshNetAgent — eCDN mesh control plane (reconstructed, runnable) ===\n");

  // ---- 1. gating: account without eCDN -> no mesh ----
  std::printf("[1] gating — IsMeshEnable (account plan / GPO / user option / meeting type)\n");
  {
    MeshFabric fab; PeerNodeInfo sn{"sn","10.0.0.1:8801",MeshRole::SuperNode}, bk{"bk","10.0.0.2:8801",MeshRole::SuperNode};
    MockMeshServer web(sn, bk); MockCost cost(true); MockFirewall fw;
    CMeshNetworkModule n("nnX", "10.0.0.9", &fab, &web, &cost, &fw);
    MeshGating g; g.account_ecdn = false;                       // account not enabled for eCDN
    bool engaged = n.StartMeeting(1001, MeetingType::Webinar, g);
    CHECK(!engaged && traced(n, "Account not enable mesh"), "account without eCDN -> mesh not engaged");
  }

  // ---- 2. cost gate: metered / no LAN -> no mesh ----
  std::printf("[2] cost detect — CCostNetworkDetect (metered/cellular -> skip)\n");
  {
    MeshFabric fab; PeerNodeInfo sn{"sn","10.0.0.1:8801",MeshRole::SuperNode}, bk{"bk","10.0.0.2:8801",MeshRole::SuperNode};
    MockMeshServer web(sn, bk); MockCost metered(/*unmetered*/false); MockFirewall fw;
    CMeshNetworkModule n("nnY", "10.0.0.9", &fab, &web, &metered, &fw);
    bool engaged = n.StartMeeting(1002, MeetingType::Webinar, MeshGating{});
    CHECK(!engaged && traced(n, "skip mesh"), "metered / no unmetered LAN -> mesh not engaged");
  }

  // ---- 3-5. a real webinar mesh: 2 super nodes + 3 normal nodes ----
  std::printf("[3] topology formation — 2 SN + 3 NN handshake into a tree\n");
  MeshFabric fab;
  PeerNodeInfo p_sn{"sn1", "10.0.0.1:8801", MeshRole::SuperNode};
  PeerNodeInfo b_sn{"sn2", "10.0.0.2:8801", MeshRole::SuperNode};
  MockMeshServer web(p_sn, b_sn); MockCost cost(true); MockFirewall fw;

  CMeshNetworkModule sn1("sn1", "10.0.0.1", &fab, &web, &cost, &fw);
  CMeshNetworkModule sn2("sn2", "10.0.0.2", &fab, &web, &cost, &fw);
  CMeshNetworkModule nn1("nn1", "10.0.0.11", &fab, &web, &cost, &fw);
  CMeshNetworkModule nn2("nn2", "10.0.0.12", &fab, &web, &cost, &fw);
  CMeshNetworkModule nn3("nn3", "10.0.0.13", &fab, &web, &cost, &fw);

  MeshGating g;  // all enabled
  sn1.StartMeeting(2001, MeetingType::Webinar, g);   // super nodes come up first
  sn2.StartMeeting(2001, MeetingType::Webinar, g);
  for (auto* nn : { &nn1, &nn2, &nn3 }) nn->StartMeeting(2001, MeetingType::Webinar, g);

  std::printf("   topology:\n"); for (auto* n : { &sn1,&sn2,&nn1,&nn2,&nn3 }) dump(*n);
  CHECK(sn1.role() == MeshRole::SuperNode && sn1.listening() && fw.IsFwRuleAdded("Zoom.exe"),
        "sn1 is SuperNode, listening, firewall exception added");
  CHECK(nn1.role() == MeshRole::NormalNode && nn1.parentId() == "sn1" && nn1.state() == NodeState::Established,
        "nn1 handshook and established under sn1");
  CHECK(sn1.children().size() == 3, "sn1 has 3 children (nn1,nn2,nn3)");
  CHECK(traced(nn1, "Signal connection established with super node: sn1"), "nn1 completed the handshake sequence");

  // ---- 4. super node crash -> failover to backup ----
  std::printf("[4] failover — sn1 crashes; normal nodes auto_switch_parent to backup sn2\n");
  fab.CrashNode("sn1");                              // heartbeat detects loss -> children re-parent
  std::printf("   topology after failover:\n"); for (auto* n : { &sn2,&nn1,&nn2,&nn3 }) dump(*n);
  CHECK(nn1.parentId() == "sn2" && nn2.parentId() == "sn2" && nn3.parentId() == "sn2",
        "all normal nodes re-parented to backup sn2");
  CHECK(sn2.children().size() == 3, "sn2 now has the 3 children");
  CHECK(traced(nn1, "auto_switch_parent") && traced(nn1, "Receive downstream broken"),
        "nn1 logged downstream-broken + auto_switch_parent");

  // ---- 5. role change: promote nn2 to super node ----
  std::printf("[5] role change — backend promotes nn2 to SuperNode\n");
  nn2.ApplyRole(MeshRole::SuperNode);
  CHECK(nn2.role() == MeshRole::SuperNode && nn2.listening(), "nn2 promoted to SuperNode + listening");
  CHECK(traced(nn2, "Node change from NormalNode to SuperNode"), "nn2 logged the role transition");

  // ---- 6. wire format: messages serialize/parse (the fabric routed real bytes above) ----
  std::printf("[6] wire format — MeshWire encode/parse round-trip + fabric transported bytes\n");
  {
    MeshMessage m{ MsgType::BackupSNList, "sn1", "nn1" };
    m.backup_sn = { { "sn2", "10.0.0.2:8801", MeshRole::SuperNode } };
    m.note = "backup list";
    MeshMessage r = MeshWire::decode(MeshWire::encode(m));
    CHECK(r.type == m.type && r.from == "sn1" && r.to == "nn1" &&
          r.backup_sn.size() == 1 && r.backup_sn[0].node_id == "sn2" && r.note == "backup list",
          "MeshWire encode/decode preserves the message");
    std::printf("      fabric routed %zu serialized bytes across the handshakes/failover\n", fab.wire_bytes());
    CHECK(fab.wire_bytes() > 0, "fabric transported real serialized frames (not struct passing)");
  }

  // ---- 7. observer -> diagnostic snapshot (CMeshDataObserver -> CMeshDiagnosticProvider) ----
  std::printf("[7] observer/diagnostic — state changes fan out to the diagnostic snapshot\n");
  {
    std::printf("      nn1 %s\n", nn1.diagnostics().ToString().c_str());
    std::printf("      nn2 %s\n", nn2.diagnostics().ToString().c_str());
    std::printf("      sn2 %s\n", sn2.diagnostics().ToString().c_str());
    CHECK(nn1.diagnostics().established_count == 2, "nn1 diagnostic recorded 2 establishes (initial + failover)");
    CHECK(nn2.diagnostics().role == MeshRole::SuperNode && nn2.diagnostics().role_changes >= 2,
          "nn2 diagnostic captured the role promotion");
    CHECK(sn2.diagnostics().children == 3, "sn2 diagnostic reflects 3 children after failover");
  }

  std::printf("\n=== checks: %d PASS, %d FAIL ===\n", g_pass, g_fail);
  std::printf("%s\n", g_fail == 0 ? "ALL PASS (0 failures)" : "SOME FAILURES");
  return g_fail == 0 ? 0 : 1;
}
