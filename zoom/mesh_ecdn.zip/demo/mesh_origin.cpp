// mesh_origin.exe — the origin (Zoom cloud). Streams a live "webinar" (a frame every 300 ms) to
// each connection. Only Super Nodes connect here, so the active-connection count == the WAN pulls:
// that's the eCDN saving made visible (N viewers, few WAN pulls).
#include "../recon/mesh/mesh_cli.hpp"
#include <atomic>
#include <chrono>
#include <string>
#include <thread>

using namespace recon::mesh;

static std::atomic<int> g_pulls{0};
static std::atomic<long long> g_bytes{0};

static void stream(SOCKET c) {
  int n = ++g_pulls;
  logl("[origin] WAN pull opened  (active super-node pulls = " + std::to_string(n) + ")");
  std::string payload(1000, 'x');            // ~1 KB media payload per frame
  for (uint32_t seq = 0;; ++seq) {
    std::string frame = "FRAME " + std::to_string(seq) + " " + payload;
    if (!write_msg(c, frame)) break;
    g_bytes += (long long)frame.size();
    std::this_thread::sleep_for(std::chrono::milliseconds(300));
  }
  int m = --g_pulls;
  logl("[origin] WAN pull closed  (active super-node pulls = " + std::to_string(m) + ")");
  closesocket(c);
}

int main(int argc, char** argv) {
  net_init();
  int want = atoi(arg(argc, argv, "--port", "7001").c_str()), port = 0;
  SOCKET ls = listen_on(want, port);
  if (ls == INVALID_SOCKET) { logl("origin: bind failed on port " + std::to_string(want)); return 2; }
  logl("origin (cloud) streaming on 127.0.0.1:" + std::to_string(port) + "  — a frame every 300ms per pull");
  std::thread([] { for (;;) { std::this_thread::sleep_for(std::chrono::seconds(5)); logl("[origin] served " + std::to_string((long long)g_bytes / 1024) + " KB total to " + std::to_string(g_pulls.load()) + " active WAN pulls"); } }).detach();
  for (;;) { SOCKET c = accept(ls, nullptr, nullptr); if (c == INVALID_SOCKET) break; std::thread(stream, c).detach(); }
  return 0;
}
