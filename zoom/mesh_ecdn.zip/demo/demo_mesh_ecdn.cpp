// demo_mesh_ecdn.cpp — complete eCDN mesh demo built on the recovered principle, over real sockets.
//
//   ORIGIN (Zoom cloud)  --pull once per Super Node-->  SUPER NODE  --relay over LAN-->  NORMAL NODEs
//
// A SCHEDULER assigns roles/topology (real TCP RPC). Two "LANs", each = 1 Super Node + 2 Normal
// Nodes. The Super Node pulls the webinar segment ONCE from the origin and relays it to its LAN
// peers; the Normal Nodes never touch the origin. We MEASURE the origin (WAN) egress to prove the
// bandwidth saving: WAN bytes = (#super nodes) x stream, not (#clients) x stream.
#include "../recon/mesh/mesh_ecdn.hpp"
#include "../recon/mesh/mesh_types.hpp"
#include <cstdio>
#include <thread>
#include <vector>

using namespace recon::mesh;

static int g_pass = 0, g_fail = 0;
static void CHECK(bool c, const char* what) {
  std::printf("   [%s] %s\n", c ? "PASS" : "FAIL", what); if (c) ++g_pass; else ++g_fail;
}

int main() {
  WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);
  std::printf("=== zMeshNetAgent eCDN — scheduler + origin + mesh clients (real sockets) ===\n");

  // the webinar segment served by the origin (Zoom cloud)
  MediaStream origin = MediaStream::make(/*chunks*/300, /*chunkSize*/1024);   // ~300 KB
  const uint64_t STREAM = origin.payloadBytes();

  OriginServer originSrv;
  Scheduler sched;
  if (!originSrv.start(&origin)) { std::printf("origin start failed\n"); return 2; }
  sched.configure_sn("LAN-A", "a0");        // backend decides who is the Super Node per LAN
  sched.configure_sn("LAN-B", "b0");
  if (!sched.start()) { std::printf("scheduler start failed\n"); return 2; }
  std::printf("origin@%d  scheduler@%d  stream=%llu bytes/client\n",
              originSrv.port(), sched.port(), (unsigned long long)STREAM);

  // topology: 2 LANs x (1 SN + 2 NN) = 6 clients
  struct Cfg { const char* node; const char* lan; int expect; };
  Cfg cfg[6] = { {"a0","LAN-A",2},{"a1","LAN-A",0},{"a2","LAN-A",0},
                 {"b0","LAN-B",2},{"b1","LAN-B",0},{"b2","LAN-B",0} };
  ClientResult res[6];

  std::vector<std::thread> ts;
  // start the two super nodes first so they can announce their relay endpoints
  for (int i : {0, 3}) ts.emplace_back(run_client, &res[i], cfg[i].node, cfg[i].lan, sched.port(), originSrv.port(), cfg[i].expect);
  std::this_thread::sleep_for(std::chrono::milliseconds(40));
  for (int i : {1, 2, 4, 5}) ts.emplace_back(run_client, &res[i], cfg[i].node, cfg[i].lan, sched.port(), originSrv.port(), cfg[i].expect);
  for (auto& t : ts) t.join();

  // ---- results ----
  std::printf("\n  roles + delivery:\n");
  for (int i = 0; i < 6; ++i)
    std::printf("    %-3s (%s) role=%-10s recv=%llu B  checksum_ok=%d  relayed=%llu B to %d peers\n",
                res[i].node.c_str(), res[i].lan.c_str(), GetMeshRoleName(res[i].role),
                (unsigned long long)res[i].recv_bytes, res[i].recv_checksum == origin.checksum,
                (unsigned long long)res[i].relayed_bytes, res[i].served_children);

  // everyone received the full stream, intact
  bool all_ok = true, all_intact = true;
  for (int i = 0; i < 6; ++i) { all_ok &= res[i].ok; all_intact &= (res[i].recv_checksum == origin.checksum); }
  CHECK(all_ok, "all 6 clients completed");
  CHECK(all_intact, "all 6 clients received the complete stream (checksum == origin)");

  // roles came from the scheduler
  CHECK(res[0].role == MeshRole::SuperNode && res[3].role == MeshRole::SuperNode, "a0/b0 assigned SuperNode by scheduler");
  CHECK(res[1].role == MeshRole::NormalNode && res[2].role == MeshRole::NormalNode &&
        res[4].role == MeshRole::NormalNode && res[5].role == MeshRole::NormalNode, "a1/a2/b1/b2 assigned NormalNode");

  // each SN relayed the pulled stream to its 2 LAN peers
  CHECK(res[0].served_children == 2 && res[0].relayed_bytes == 2 * STREAM, "a0 relayed the stream to 2 normal nodes over the LAN");
  CHECK(res[3].served_children == 2 && res[3].relayed_bytes == 2 * STREAM, "b0 relayed the stream to 2 normal nodes over the LAN");

  // THE PRINCIPLE: origin (WAN) egress = (#super nodes) x stream, NOT (#clients) x stream
  std::printf("\n  bandwidth accounting:\n");
  std::printf("    origin (WAN) pulls = %d ; origin bytes served = %llu B\n", originSrv.pulls(), (unsigned long long)originSrv.bytes_served());
  uint64_t naive = 6 * STREAM, mesh = originSrv.bytes_served();
  std::printf("    without mesh: 6 clients x %llu = %llu B over WAN\n", (unsigned long long)STREAM, (unsigned long long)naive);
  std::printf("    with mesh   : 2 super nodes x %llu = %llu B over WAN  (rest relayed on the LAN)\n", (unsigned long long)STREAM, (unsigned long long)mesh);
  std::printf("    WAN egress reduced %.1fx (saved %llu B)\n", (double)naive / (double)mesh, (unsigned long long)(naive - mesh));
  CHECK(originSrv.pulls() == 2 && originSrv.bytes_served() == 2 * STREAM,
        "WAN egress == 2 x stream (normal nodes pulled from the LAN super node, not the origin)");

  sched.stop(); originSrv.stop();
  std::printf("\n=== checks: %d PASS, %d FAIL ===\n", g_pass, g_fail);
  std::printf("%s\n", g_fail == 0 ? "ALL PASS (0 failures)" : "SOME FAILURES");
  WSACleanup();
  return g_fail == 0 ? 0 : 1;
}
