# zoom-mesh-ecdn — Zoom eCDN mesh, clean-room reconstruction (runnable)

A standalone, buildable reconstruction of the **control plane** of Zoom's `zMeshNetAgent.dll` — the
enterprise-CDN (eCDN) "mesh networking" agent used for webinars & large meetings. Reverse-engineered
clean-room (behaviour, not verbatim code) and rebuilt into real, runnable C++.

**The principle:** instead of every client on a corporate LAN independently pulling the webinar stream
from the Zoom cloud (N × WAN bandwidth), a few clients are elected **Super Nodes** that pull once and
**relay to their LAN peers** (Normal Nodes) over the local network. WAN egress drops from *#viewers* to
*#super-nodes*. It's a **two-tier relay tree**, centrally scheduled, locally relayed — not P2P, and it
needs no NAT traversal (same-LAN direct connect). See `docs/zoom-ecdn-mesh-internals.html` for the full
principle + technical details, and `docs/MESH_AGENT.md` / `docs/MESH_INTERACTIVE.md`.

## Build (Windows + MSVC)
```powershell
cmake -S . -B build
cmake --build build --config Release
```
Everything is Windows-only (WinSock/COM/WinHTTP/WLAN, auto-linked). No external dependencies.

## Run — batch self-tests (each asserts + returns 0/1, CI-friendly)
```powershell
.\build\Release\demo_mesh_agent.exe    # gating / SN-NN handshake tree / auto_switch_parent failover
                                       #   / wire serialization / observer->diagnostic   (16/16)
.\build\Release\demo_mesh_ecdn.exe     # scheduler + origin + SN/NN over real TCP; measures the WAN
                                       #   saving (2 super-node pulls serve 6 viewers -> 3.0x)  (7/7)
.\build\Release\demo_mesh_win.exe      # REAL Windows env: INetworkCostManager + WLAN + INetFwPolicy2
                                       #   + WinHTTP<->local WinSock HTTP server                (7/7)
```

## Run — interactive multi-process mesh (the fun one)
```powershell
.\run_mesh_interactive.ps1
```
Opens a scheduler, an origin, 2 super nodes and 2 normal nodes, each in its own window. **Ctrl-C the
`SN-A (primary)` window** and watch the normal nodes print `auto_switch_parent` and resume streaming
from the backup — live failover. Add viewers with `build\Release\mesh_node.exe --id nn-a3 --lan A`;
open a second LAN with `--lan B`. Full guide: `docs/MESH_INTERACTIVE.md`.

## Layout
```
recon/mesh/     reconstructed headers (control plane + real-env impls)
  mesh_types.hpp   roles, gating (IsMeshEnable), messages
  mesh_diag.hpp    CMeshDataObserver<T> + CMeshDiagnosticProvider (reactive state -> snapshot)
  mesh_wire.hpp    signaling message (de)serialization
  mesh_env.hpp     ICostNetworkDetect / IFirewall / ISBWebServiceAPI (+ mocks)
  mesh_module.hpp  CMeshNetworkModule state machine + in-process MeshFabric
  mesh_win.hpp     REAL Windows env: WinNetworkCost / WinFirewall / WinHttpBackend + LocalHttpServer
  mesh_ecdn.hpp    real-socket OriginServer / Scheduler / Super+Normal client (bandwidth demo)
  mesh_cli.hpp     shared TCP/message/logging plumbing for the interactive CLI
demo/           the 3 batch demos + the 3 interactive CLI programs
docs/           MESH_AGENT.md, MESH_INTERACTIVE.md, zoom-ecdn-mesh-internals.html
run_mesh_interactive.ps1
```

## Scope & honesty
- **Reconstructed & runnable**: role assignment, gating (account/GPO/user/meeting-type), network-cost &
  WLAN detection, firewall check, the SN/NN handshake tree, `auto_switch_parent` failover, backup super
  nodes, role change, message serialization, reactive observer + diagnostics, and a real scheduler +
  origin + relay with measured WAN savings.
- **Boundaries** (marked in the docs): the real **media data plane** rides Zoom's transport (`tp`) —
  here the "stream" is a synthetic frame feed to demonstrate relay; the exact **byte layout** of Zoom's
  signaling messages was not recovered (modeled by shape); adding a Windows Firewall rule is **gated**
  (`MESH_FW_ADD=1` + admin) because it modifies a security setting. **No NAT traversal** — verified
  absent in the binary (intra-LAN direct connect).
- Clean-room, for interop / security-research / education. Not Zoom's source; not byte-identical.
