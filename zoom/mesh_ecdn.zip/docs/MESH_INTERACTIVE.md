# Interactive eCDN mesh — real multi-process demo

Three standalone programs you run yourself, in separate terminals, over real TCP. Launch and kill
node processes to watch the Super Node / Normal Node tree **form and fail over live** — this is a real
distributed system, not a self-test script.

| exe | role |
|---|---|
| `mesh_scheduler.exe` | the mesh coordinator: assigns roles (first 2 joiners per LAN = Super Nodes, rest = Normal Nodes), holds each Super Node's control connection for **liveness**, and on a Super Node's death **promotes the backup** + re-points Normal Nodes. Prints the live topology. |
| `mesh_origin.exe` | the origin (Zoom cloud): streams a "webinar" frame every 300 ms to each connection. Only Super Nodes connect here, so its active-pull count == **WAN egress**. |
| `mesh_node.exe --id <id> --lan <A>` | a client you launch. Gets a role from the scheduler; a Super Node pulls from the origin and relays to its LAN peers; a Normal Node receives from its Super Node and, if it dies, **re-parents to the backup** and resumes. |

## Quickest way (one script, 6 windows)
```powershell
cd D:\code\work\bin2cpp-output
.\run_mesh_interactive.ps1
```
Then **click the `SN-A (primary)` window and press Ctrl-C**. Watch `NN-A1` / `NN-A2` print
`*** parent lost — auto_switch_parent ***` and resume streaming from `SN-A2`.

## Manual (type it yourself — one per terminal)
```
build\Release\mesh_scheduler.exe
build\Release\mesh_origin.exe
build\Release\mesh_node.exe --id sn-a  --lan A       (becomes SuperNode / PRIMARY)
build\Release\mesh_node.exe --id sn-a2 --lan A       (becomes SuperNode / BACKUP)
build\Release\mesh_node.exe --id nn-a1 --lan A       (NormalNode under sn-a)
build\Release\mesh_node.exe --id nn-a2 --lan A       (NormalNode under sn-a)
```
Options: `--sched 127.0.0.1:7000` `--origin 127.0.0.1:7001` (defaults shown).

## Things to try
- **Failover**: Ctrl-C the primary Super Node → the scheduler logs `DOWN … promoting backup`; the
  Normal Nodes re-parent to the backup and keep receiving frames (verified: `nn-a1` resumed on the
  backup within one frame).
- **Add viewers**: launch more `--lan A` nodes; the 3rd+ become Normal Nodes and attach to the Super Node.
- **Second LAN**: `--id sn-b --lan B`, `--id nn-b1 --lan B` — an independent tree; each LAN pulls from
  the origin on its own (WAN egress = number of LANs × active super nodes, not number of viewers).
- **Bandwidth**: the origin window shows `active super-node pulls = N` — that's the WAN cost. Watch it
  stay small (= #super nodes) while you add many Normal-Node viewers.

## Notes
- Real WinSock TCP on 127.0.0.1 (loopback). Ports 7000 (scheduler) / 7001 (origin) fixed; Super Node
  relay ports are ephemeral and announced to the scheduler.
- SN_PER_LAN = 2 (primary + backup, both hot-standby pulling from origin) so failover is instant. A
  Normal Node re-parents by asking the scheduler for the current live Super Node.
- This is the interactive counterpart to the batch demos (`demo_mesh_ecdn` measures the bandwidth
  saving; `demo_mesh_agent` unit-tests the control logic).
