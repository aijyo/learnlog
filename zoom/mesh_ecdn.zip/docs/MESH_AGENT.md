# zMeshNetAgent.dll — runnable eCDN mesh control plane

Clean-room reconstruction of Zoom's **eCDN / mesh networking agent** (webinars & large meetings): a
two-tier **Super Node / Normal Node** tree formed on the enterprise LAN so one client pulls from the
Zoom cloud and relays to same-LAN peers, cutting WAN egress. zMeshNetAgent is the **control/signaling
plane** — it decides *who connects to whom* and heals the topology; the media rides the transport.

This reconstruction runs the whole lifecycle across real `CMeshNetworkModule` instances wired through an
in-process fabric, so the SN/NN handshake and failover **actually execute and are tested**.

## What it does (last run — `demo_mesh_agent.exe`, 16/16 PASS)
```
[1] gating (account eCDN / GPO / user option / meeting type)  -> account off => not engaged   PASS
[2] cost detect (metered / no unmetered LAN)                  -> metered => not engaged        PASS
[3] topology: 2 SN + 3 NN handshake into a tree
        sn1 role=SuperNode children=[nn1,nn2,nn3]
        nn1 role=NormalNode parent=sn1 state=Established                                        PASS x4
[4] failover: sn1 crashes -> all NN auto_switch_parent -> sn2 children=[nn1,nn2,nn3]            PASS x3
[5] role change: promote nn2 -> SuperNode ("Node change from NormalNode to SuperNode")          PASS x2
[6] wire format: MeshWire encode/parse round-trip; fabric routed 360 real serialized bytes     PASS x2
[7] observer/diagnostic: CMeshDataObserver -> CMeshDiagnosticProvider snapshot
        nn1 established:2 (failover) ; nn2 role:SuperNode role_changes:2 ; sn2 children:3       PASS x3
```

## Block C — REAL Windows environment (`demo_mesh_win.exe`, 7/7 PASS)
Not stubs: `recon/mesh/mesh_win.hpp` implements the environment interfaces against the actual OS APIs
zMeshNetAgent uses, and `demo_mesh_win` drives them on the live machine:
```
[A/B] INetworkCostManager::GetCost + INetworkListManager + WlanEnumInterfaces
        -> cost_flags=0x1 (UNRESTRICTED/unmetered)  connected=1  wifi_ssid="<real>"
[C]   INetFwPolicy2 firewall real READ (rule present? ) ; real INetFwRule Add is GATED
        (present in code; runs only with MESH_FW_ADD=1 + admin, and is removed after — net-zero,
         because adding a firewall rule modifies a security setting)
[D]   WinHTTP GET  <->  local WinSock HTTP/1.1 server  -> real JSON -> MeshAssignment  (round-trip)
[E]   the mesh forms with node roles delivered over REAL HTTP + real firewall/cost env
```
`WinNetworkCost` / `WinFirewall` / `WinHttpBackend` are the real impls; the pure-logic `demo_mesh_agent`
uses the mocks so it stays deterministic/cross-platform. Real net/COM libs (`ws2_32`, `winhttp`,
`wlanapi`, `ole32`, `oleaut32`) auto-link via `#pragma comment(lib)`.

## The eCDN principle, end-to-end (`demo_mesh_ecdn.exe`, 7/7 PASS)
A complete real-socket demo of *why* the mesh exists — scheduler + origin + Super/Normal mesh
clients, measuring the WAN bandwidth saved by LAN relay (`recon/mesh/mesh_ecdn.hpp`):
```
ORIGIN (Zoom cloud) --pull once per Super Node--> SUPER NODE --relay over LAN--> NORMAL NODEs
  * SCHEDULER assigns roles/topology over real TCP RPC (a0/b0 -> SuperNode; rest -> NormalNode)
  * 2 LANs x (1 SN + 2 NN); each SN pulls the 300 KB segment ONCE from origin, relays to its 2 peers
  * all 6 clients get the complete stream (checksum == origin)
  * WAN egress: without mesh 6x300KB=1.8MB ; with mesh 2x300KB=0.6MB  -> 3.0x reduction
```
Everything is real WinSock TCP across threads: real scheduler RPC, real origin pull, real SN→NN
relay, real byte accounting. `pulls()==2` proves normal nodes fetched from the LAN super node, not
the origin — the whole point of eCDN.

## Reconstructed (Zoom-own) — string/body-verified
| piece | file | zMeshNetAgent evidence |
|---|---|---|
| roles, gating, messages | `recon/mesh/mesh_types.hpp` | `MeshNetworkRole`/`GetMeshRoleName`, `EnableMeshNetworking`/`EnableGuestMesh` GPO, account webinar/meeting mesh, `cdn_sn_addr`/`cdn_sn_node_id`, Node Event / Backup Super Node List / AskChildDrop |
| environment interfaces | `recon/mesh/mesh_env.hpp` | `CCostNetworkDetect::QueryCostForAllInterface` (+ Wlan*), `IsFwRuleAddedImpl`/`CheckAddFirewallException`, `SB_webservice::ISBWebServiceAPI` (`ReportMeshNetwork`/`OnGetMeshSvrResponse`) |
| the agent state machine | `recon/mesh/mesh_module.hpp` | `CMeshNetworkModule`: gating→cost→report→role; SN listen+firewall; NN handshake `Requesting→Confirming→Established` (`sub_18000FF1C`/`sub_180018338`); `auto_switch_parent` (`sub_18000D358`), downstream-broken/`HandleAskChildDropMsg`, Backup Super Node List, "Node change from X to Y" |
| **message wire format** | `recon/mesh/mesh_wire.hpp` | signaling messages (Node Event / Backup SN List / handshake) — the fabric transports serialized frames per hop (byte layout modeled, `[推断]`) |
| **reactive state + diagnostics** | `recon/mesh/mesh_diag.hpp` | `CMeshDataObserver<T>` (InitDataObservers) → `CMeshDiagnosticProvider` (VCMeshDiagnosticInfo) snapshot: role/state/parent/children + role-change & establish counters |

## The handshake state machine (both sides, from the trace strings)
```
Normal Node : Connecting -> Requesting handshake -> (recv accept) Confirming -> (recv) Established
Super Node  : Accept connection <- request -> Response handshake -> (recv confirm) Finish -> Established
Resilience  : parent lost -> "Receive downstream broken" -> auto_switch_parent -> next backup SN
```

## Build & run
```powershell
cmake -S . -B build
cmake --build build --config Release --target demo_mesh_agent
.\build\Release\demo_mesh_agent.exe        # -> ALL PASS (11/11) ; pure C++, no deps
```

## Scope / boundary (honest)
- **Reconstructed & runnable**: the full **control plane** — gating, cost/eligibility, backend role
  assignment, the SN/NN handshake tree, `auto_switch_parent` failover, backup-SN list, role change,
  firewall/listen gating, the **message wire serialization** (fabric routes real bytes), and the
  **reactive observer + diagnostic** system (`CMeshDataObserver` → `CMeshDiagnosticProvider`). The
  Windows env (network-cost NLM, WLAN, Firewall INetFwRule) and the backend are behind interfaces with
  test mocks (a real build injects the OS/`ISBWebServiceAPI` impls).
- **`[推断]` (not in this module)**: the **media data plane** — meeting media relayed SN→NN rides the
  transport (`tp`); zMeshNetAgent establishes the *signaling* topology, not the pixels/audio. The exact
  **byte layout** of the signaling messages (`Node Event Message`, `Backup Super Node List Message`) was
  not recovered — message *types* and *sequence* are verified, wire format is modeled by shape.
- **No NAT traversal `[实证]`**: a fingerprint scan found **no STUN / TURN / ICE / UPnP / hole-punching**
  (all matches were substring false positives — `no_re`**`turn`**, `dev`**`ice`**, `Allocate`Sid). Nor a
  raw socket stack (`socket`/`bind`/`listen`/`WSA*`/`recvfrom` absent; only logical `connect` + `tcp`).
  This is by design: eCDN mesh forms **within an enterprise LAN** (same subnet / WiFi SSID via WLAN
  detection), where peers are directly reachable — the super node adds a firewall exception and listens
  on a port range, normal nodes `connect` to the backend-provided `cdn_sn_addr`, and the actual socket
  I/O is delegated to `ssb::net_adaptors_t` / the transport. NAT traversal is only needed to cross NATs
  on the public internet; intra-LAN mesh doesn't need it.
