"""Train the Zoom-shaped residual AEC directly from farend/mic/target triplets.

Example:
  python train_zoom_aec_target.py --dataset D:\\AEC48K\\synthetic-fullband-v1 \
      --output runs\\zoom_aec_target --epochs 40 --batch-size 4
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader

from zoom_aec_data import (FFT_SIZE, HOP_SIZE, SyntheticFullbandAec,
                           complex_magnitude, istft_ri, stft_ri)
from zoom_nets.zoom_aec import ZoomAecNet, apply_complex_mask


def si_sdr(estimate: Tensor, target: Tensor, eps: float = 1.0e-8) -> Tensor:
    target_energy = target.square().sum(-1, keepdim=True).clamp_min(eps)
    projection = (estimate * target).sum(-1, keepdim=True) * target / target_energy
    noise = estimate - projection
    return 10.0 * torch.log10(projection.square().sum(-1).clamp_min(eps) /
                              noise.square().sum(-1).clamp_min(eps))


def objective(model: ZoomAecNet, mic: Tensor, far: Tensor, target: Tensor,
              window: Tensor) -> tuple[Tensor, dict[str, float], Tensor]:
    mic_ri, far_ri, target_ri = (stft_ri(x, window) for x in (mic, far, target))
    mask, _ = model(mic_ri, far_ri)
    estimate_ri = apply_complex_mask(mic_ri, mask)
    estimate = istft_ri(estimate_ri, window, mic.shape[-1])

    spec_l1 = F.l1_loss(estimate_ri, target_ri)
    logmag = F.l1_loss(torch.log1p(complex_magnitude(estimate_ri)),
                       torch.log1p(complex_magnitude(target_ri)))
    wave_l1 = F.l1_loss(estimate, target)
    sdr_loss = -si_sdr(estimate, target).clamp(-30.0, 30.0).mean() / 30.0
    smooth_f = (mask[..., 1:] - mask[..., :-1]).abs().mean()
    smooth_t = ((mask[:, 1:] - mask[:, :-1]).abs().mean()
                if mask.shape[1] > 1 else mask.new_zeros(()))
    loss = spec_l1 + 0.5 * logmag + 0.5 * wave_l1 + 0.1 * sdr_loss
    loss = loss + 0.002 * (smooth_f + smooth_t)

    with torch.no_grad():
        residual_before = (mic - target).square().mean(dim=-1)
        residual_after = (estimate - target).square().mean(dim=-1)
        erle = 10.0 * torch.log10((residual_before + 1e-8) /
                                  (residual_after + 1e-8)).mean()
        metrics = {"loss": float(loss), "spec_l1": float(spec_l1),
                   "logmag": float(logmag), "wave_l1": float(wave_l1),
                   "si_sdr_db": float(si_sdr(estimate, target).mean()),
                   "residual_erle_db": float(erle)}
    return loss, metrics, estimate


def aggregate(rows: list[dict[str, float]]) -> dict[str, float]:
    return {key: sum(row[key] for row in rows) / len(rows) for key in rows[0]}


@torch.no_grad()
def validate(model, loader, window, device, max_batches):
    model.eval()
    rows = []
    for step, (mic, far, target, _) in enumerate(loader):
        if step >= max_batches:
            break
        _, metrics, _ = objective(model, mic.to(device), far.to(device),
                                  target.to(device), window)
        rows.append(metrics)
    return aggregate(rows)


def save_checkpoint(path: Path, model, optimizer, scheduler, epoch, best, args, metrics):
    torch.save({"arch": "ZoomAecNet", "state_dict": model.state_dict(),
                "optimizer": optimizer.state_dict(), "epoch": epoch,
                "scheduler": scheduler.state_dict(),
                "best_val_loss": best, "params": sum(p.numel() for p in model.parameters()),
                "args": vars(args), "metrics": metrics}, path)


def main() -> int:
    ap = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--dataset", default=r"D:\AEC48K\synthetic-fullband-v1")
    ap.add_argument("--output", default="runs/zoom_aec_target")
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--batch-size", type=int, default=4)
    ap.add_argument("--chunk-seconds", type=float, default=3.2)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--val-batches", type=int, default=50)
    ap.add_argument("--grad-clip", type=float, default=5.0)
    ap.add_argument("--seed", type=int, default=20260907)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--resume", default="")
    ap.add_argument("--max-train-items", type=int, default=0, help="smoke-test limiter; 0 uses all")
    ap.add_argument("--max-cv-items", type=int, default=0, help="smoke-test limiter; 0 uses all")
    ap.add_argument("--no-meta-delay", action="store_true")
    args = ap.parse_args()

    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    device = torch.device(args.device)
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    train_set = SyntheticFullbandAec(args.dataset, "train", args.chunk_seconds,
                                     not args.no_meta_delay, args.max_train_items)
    cv_set = SyntheticFullbandAec(args.dataset, "cv", args.chunk_seconds,
                                  not args.no_meta_delay, args.max_cv_items)
    train_loader = DataLoader(train_set, args.batch_size, shuffle=True,
                              num_workers=args.workers, pin_memory=device.type == "cuda",
                              drop_last=True)
    cv_loader = DataLoader(cv_set, args.batch_size, shuffle=False,
                           num_workers=args.workers, pin_memory=device.type == "cuda")
    model = ZoomAecNet().to(device)
    model.check_contract()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, args.epochs)
    window = torch.hamming_window(FFT_SIZE, periodic=True, device=device)
    start, best = 1, math.inf
    history_path = out / "history.json"
    history = []
    if args.resume:
        ckpt = torch.load(args.resume, map_location=device, weights_only=False)
        model.load_state_dict(ckpt["state_dict"]); optimizer.load_state_dict(ckpt["optimizer"])
        start, best = int(ckpt["epoch"]) + 1, float(ckpt["best_val_loss"])
        if "scheduler" in ckpt:
            scheduler.load_state_dict(ckpt["scheduler"])
        else:
            scheduler.last_epoch = int(ckpt["epoch"])
        if history_path.exists():
            history = json.loads(history_path.read_text(encoding="utf-8"))

    print(f"device={device} params={sum(p.numel() for p in model.parameters()):,} "
          f"train={len(train_set)} cv={len(cv_set)}")
    for epoch in range(start, args.epochs + 1):
        model.train(); rows = []; began = time.perf_counter()
        for step, (mic, far, target, _) in enumerate(train_loader, 1):
            mic, far, target = mic.to(device), far.to(device), target.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss, metrics, _ = objective(model, mic, far, target, window)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            optimizer.step(); rows.append(metrics)
            if step % 50 == 0:
                now = aggregate(rows[-50:])
                print(f"epoch {epoch:03d} step {step:04d}/{len(train_loader)} "
                      f"loss={now['loss']:.4f} erle={now['residual_erle_db']:.2f}dB "
                      f"sisdr={now['si_sdr_db']:.2f}dB")
        scheduler.step()
        train_metrics = aggregate(rows)
        val_metrics = validate(model, cv_loader, window, device, args.val_batches)
        record = {"epoch": epoch, "seconds": time.perf_counter() - began,
                  "lr": optimizer.param_groups[0]["lr"], "train": train_metrics,
                  "cv": val_metrics}
        history.append(record)
        history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
        is_best = val_metrics["loss"] < best
        best = min(best, val_metrics["loss"])
        save_checkpoint(out / "last.pt", model, optimizer, scheduler, epoch, best, args, record)
        if is_best:
            save_checkpoint(out / "best.pt", model, optimizer, scheduler, epoch, best, args, record)
        print(f"epoch {epoch:03d} train={train_metrics['loss']:.4f} "
              f"cv={val_metrics['loss']:.4f} cv_erle={val_metrics['residual_erle_db']:.2f}dB "
              f"best={best:.4f} time={record['seconds']:.1f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
