"""Model B -- SNAC, Zoom's neural speech codec, rebuilt in PyTorch from the recovered architecture.

CORRECTED 2026-09-01: viperex!sub_1801445D0 and its dense/GRU graph belong to
CompanionMic, not SNAC.  The real SNAC encoder is the convolutional object graph
constructed by viper!sub_180237830 and executed by viper!sub_180238010.

WHAT IS FAITHFUL (read from binary):
  * Input TemporalConv1dC: 1->32, kernel 7, stride 1, dilation 1, groups 1
  * Four EncoderLayer objects: 32->64/s3, 64->128/s4, 128->256/s5,
    256->512/s8.  Each contains residual dilations [1,3,9], kernel 7,
    depthwise first convolution, then Snake1dC and a 2*stride downsampler.
  * Output TemporalConv1dC: 512->512, kernel 3, stride 1, groups 512
  * MultiResolutionRVQ constructor: max 12 quantizers, 512 channels,
    1024-entry codebooks, code dimension 8
  * PitchDNN: xcorr(224) + IF(88) -> period, including the four formerly
    misidentified dense_downsampler/dense_*_upsampler layers
  * RVQ stages are ordered residual quantizers; the outer encoder transmits the
    first SNAC_CODES_PER_FRAME indices (2), with no stride pooling or scoring.
  * Decoder: RVQ.from_codes -> depthwise k7 -> pointwise k1 -> four decoder
    layers (512->256/s8, 256->128/s5, 128->64/s4, 64->32/s3) -> Snake ->
    32->1/k7 -> tanh. Each decoder layer is Snake -> transposed convolution
    -> NoiseBlock -> residual dilations [1,3,9].

CODEC BODY STATUS:
  Encoder, RVQ, Decoder, Snake1dC, causal/transposed-convolution state and
  NoiseBlock inference are BODY-verified. The 480 PCM -> 2 codes -> 480 PCM
  path is executable end to end with clean-room parameters.

NOT INCLUDED: Zoom's trained weights or codebooks.

Legacy CondNet/SigNet experiments remain below as separate research components; they
are not part of the BODY-verified convolutional SNAC codec path.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------------------------------------------------------------- bitstream, read from engine
SNAC_PAYLOAD_TYPE = 121
SNAC_FRAME_MS = 20
SNAC_CODE_BITS = 10
SNAC_CODEBOOK_ENTRIES = 1 << SNAC_CODE_BITS      # 1024
SNAC_CODES_PER_FRAME = 2                          # 2 codebooks per 20ms frame
SNAC_CODEBOOK_POOL = 12                           # 12 total codebooks to choose from
SNAC_SEND_FREQ = 50                               # frames/s
SNAC_REPEAT_TIMES = 1
SNAC_BITS_PER_FRAME = SNAC_CODE_BITS * SNAC_CODES_PER_FRAME        # 20
SNAC_BYTES_PER_FRAME = (SNAC_BITS_PER_FRAME + 7) // 8             # 3
SNAC_BITRATE_BPS = SNAC_BITS_PER_FRAME * SNAC_SEND_FREQ             # 1000
SNAC_WIRE_BITRATE_BPS = SNAC_BITRATE_BPS * (SNAC_REPEAT_TIMES + 1)  # 2000

# cond_net dims (read from descriptor table)
COND_PEMBED_N = 224      # pitch bins 0..223 == clamp(period-32, 0, 223)
COND_PEMBED_D = 12       # embed dim
COND_FDENSE1_IN = 32     # = 20(latent subset) + 12(pembed)
COND_FDENSE1_OUT = 64
COND_FCONV1_IN = 192     # = 64 * 3 frames (fdense1 output * 3)
COND_FCONV1_OUT = 128
COND_FDENSE2_OUT = 320   # cond per FARGAN frame, split into 4 subframes x 80

# sig_net dims — VERIFIED 2026-08-24 against FARGAN reference (xiph/opus dnn/fargan.c).
# Zoom's sig_net_* layer names + dims map 1:1 onto run_fargan_subframe().
SIG_COND_SIZE = 80               # per-subframe conditioning (320 / 4 subframes)
SIG_N_SUBFRAMES = 4
SIG_SUBFRAME = 40                # 40 samples = 2.5 ms @ 16 kHz
SIG_FRAME = SIG_N_SUBFRAMES * SIG_SUBFRAME   # 160 samples = 10 ms
SIG_PITCH_MAX = 256              # pitch history buffer
SIG_DEEMPHASIS = 0.85
SIG_NET_INPUT = SIG_COND_SIZE + 2 * SIG_SUBFRAME + 4   # 164 = cond(80)+pred(44)+prev(40)
SIG_NET_FWC0_IN = 328            # 2 x 164 (causal conv, kernel=2 frames: state+current)
SIG_FWC0_CONV_OUT = 192
SIG_GRU_HIDDEN = (160, 128, 128) # gru1/gru2/gru3 state widths
SIG_DENSE_OUT = 40               # pcm per subframe, tanh * gain
SIG_GAIN_OUT = 4                 # pitch_gate (sigmoid), 4 taps: 3 GRU injections + skip
SIG_COND_GAIN_OUT = 1            # = dense(cond80)->1, then exp()

# Pitch estimator dimensions recovered from descriptors and cross-checked against
# neural-pitch PitchDNN. Tensor layout/padding below is the runnable T2 model.
PITCH_XCORR_BINS = 224
PITCH_IF_FEATURES = 88
PITCH_HIDDEN = 64
PITCH_CLASSES = 192
PITCH_MIN_PERIOD = 32
PITCH_MAX_PERIOD = 255


def pitch_period_to_index(period):
    """Map a pitch period in samples to cond_net_pembed's [0, 223] index."""
    return (period - PITCH_MIN_PERIOD).clamp(0, COND_PEMBED_N - 1).long()


def pitch_index_to_period(index):
    """Map a cond_net_pembed index back to a valid pitch period in samples."""
    return (index.long() + PITCH_MIN_PERIOD).clamp(PITCH_MIN_PERIOD,
                                                   PITCH_MAX_PERIOD)

# ---------------------------------------------------------------- quantiser
class CosineSimCodebook(nn.Module):
    """Zoom lookup: normalise one input vector, raw-dot every stored embedding."""

    def __init__(self, dim, size, eps=1.0e-8):
        super().__init__()
        self.dim = dim
        self.size = size
        self.eps = eps
        self.embed = nn.Parameter(F.normalize(torch.randn(size, dim), dim=-1))

    def forward(self, z):
        if z.ndim != 3 or z.shape[1] != self.dim or z.shape[2] != 1:
            raise ValueError(
                f"CosineSimCodebook expects (B,{self.dim},1), got {tuple(z.shape)}"
            )
        vector = z.squeeze(-1)
        norm = torch.linalg.vector_norm(vector, dim=-1, keepdim=True)
        normalized = torch.where(norm > self.eps, vector / norm.clamp_min(self.eps),
                                 torch.zeros_like(vector))
        indices = (normalized @ self.embed.t()).argmax(dim=-1)
        return self.embed[indices].unsqueeze(-1), indices

    def from_codes(self, indices):
        return self.embed[indices.long()].unsqueeze(-1)


class VectorQuantize(nn.Module):
    """1x1 project-in -> cosine codebook -> 1x1 project-out."""

    def __init__(self, dim, code_dim, size, commitment_weight=0.25):
        super().__init__()
        self.dim = dim
        self.code_dim = code_dim
        self.commitment_weight = commitment_weight
        self.project_in = TemporalConv1dC(dim, code_dim, 1)
        self.project_out = TemporalConv1dC(code_dim, dim, 1)
        self.codebook = CosineSimCodebook(code_dim, size)

    def forward(self, x):
        z = self.project_in(x)
        q, idx = self.codebook(z)
        codebook_loss = F.mse_loss(q, z.detach())
        commitment = F.mse_loss(z, q.detach())
        q_st = z + (q - z).detach()
        return self.project_out(q_st), idx, (
            codebook_loss + self.commitment_weight * commitment
        )

    def from_codes(self, indices):
        return self.project_out(self.codebook.from_codes(indices))


class MultiResolutionRVQ(nn.Module):
    """Ordered residual VQ; Zoom owns 12 stages and transmits the first N indices."""

    def __init__(self, dim, code_dim=8, size=SNAC_CODEBOOK_ENTRIES,
                 n_stages=SNAC_CODEBOOK_POOL):
        super().__init__()
        self.dim = dim
        self.code_dim = code_dim
        self.size = size
        self.stages = nn.ModuleList(
            [VectorQuantize(dim, code_dim, size) for _ in range(n_stages)])

    def forward(self, x, n_active=None):
        if x.ndim != 3 or x.shape[1] != self.dim or x.shape[2] != 1:
            raise ValueError(f"RVQ expects (B,{self.dim},1), got {tuple(x.shape)}")
        n = len(self.stages) if n_active is None or n_active <= 0 else n_active
        n = min(n, len(self.stages))
        residual = x
        quantized = torch.zeros_like(x)
        codes, losses = [], []
        for vq in self.stages[:n]:
            q, idx, loss = vq(residual)
            quantized = quantized + q
            residual = residual - q
            codes.append(idx)
            losses.append(loss)
        return quantized, torch.stack(codes, dim=1), torch.stack(losses).mean()

    def from_codes(self, codes):
        if not torch.is_tensor(codes):
            codes = torch.stack(codes, dim=1)
        if codes.ndim != 2 or codes.shape[1] == 0:
            raise ValueError("codes must have shape (B,N) with N > 0")
        n = min(codes.shape[1], len(self.stages))
        decoded = None
        still_active = torch.ones(codes.shape[0], dtype=torch.bool, device=codes.device)
        for i in range(n):
            still_active = still_active & (codes[:, i] >= 0)
            safe_indices = codes[:, i].clamp_min(0)
            q = self.stages[i].from_codes(safe_indices)
            q = q * still_active.view(-1, 1, 1)
            decoded = q if decoded is None else decoded + q
        return decoded


# ---------------------------------------------------------------- cores
class TemporalConv1dC(nn.Conv1d):
    """Causal temporal convolution; offline calls use Zoom's zero-initial history."""

    def __init__(self, chan_in, chan_out, kernel_size, stride=1, dilation=1, groups=1):
        super().__init__(chan_in, chan_out, kernel_size, stride=stride,
                         padding=0, dilation=dilation, groups=groups)
        # viper!sub_18023C580 stores this total padding value in the object.
        self.total_padding = dilation * (kernel_size - 1) - stride + 1

    def forward(self, x, history=None, return_history=False):
        if self.total_padding > 0:
            expected = (x.shape[0], x.shape[1], self.total_padding)
            if history is None:
                history = torch.zeros(
                    expected, device=x.device, dtype=x.dtype
                )
            elif tuple(history.shape) != expected:
                raise ValueError(
                    f"temporal-convolution history must have shape {expected}"
                )
            merged = torch.cat([history, x], dim=-1)
            next_history = merged[..., -self.total_padding:]
        else:
            merged = x
            next_history = x[..., :0]
        output = super().forward(merged)
        if return_history:
            return output, next_history
        return output


class TemporalConvTranspose1dC(nn.ConvTranspose1d):
    """Zoom causal transposed convolution with one input sample of history."""

    def __init__(self, chan_in, chan_out, stride):
        self.zoom_stride = stride
        super().__init__(chan_in, chan_out, 2 * stride, stride=stride, padding=0)

    def forward(self, x, history=None, return_history=False):
        if history is None:
            history = torch.zeros(
                x.shape[0], x.shape[1], 1, device=x.device, dtype=x.dtype
            )
        expected = (x.shape[0], x.shape[1], 1)
        if tuple(history.shape) != expected:
            raise ValueError(
                f"transposed-convolution history must have shape {expected}"
            )
        merged = torch.cat([history, x], dim=-1)
        raw = super().forward(merged)
        start = self.zoom_stride
        output = raw[..., start:start + x.shape[-1] * self.zoom_stride]
        next_history = x[..., -1:]
        if return_history:
            return output, next_history
        return output


class Snake1dC(nn.Module):
    """Snake1dC parameter inventory recovered from viper!sub_18023E790."""

    def __init__(self, channels):
        super().__init__()
        self.channels = channels
        self.alpha = nn.Parameter(torch.ones(channels))
        self.beta = nn.Parameter(torch.ones(channels))
        self.gamma = nn.Parameter(torch.zeros(channels))

    def forward(self, x):
        alpha = self.alpha.view(1, -1, 1)
        beta = self.beta.view(1, -1, 1)
        gamma = self.gamma.view(1, -1, 1)
        return x + beta / (alpha + 1.0e-9) * torch.sin(alpha * x).square() - gamma


class SnacResidualUnit(nn.Module):
    """Snake -> depthwise dilated conv -> Snake -> pointwise conv + residual."""

    def __init__(self, channels, dilation, kernel_size=7):
        super().__init__()
        self.channels = channels
        self.dilation = dilation
        self.snake1 = Snake1dC(channels)
        self.conv1 = TemporalConv1dC(
            channels, channels, kernel_size, dilation=dilation, groups=channels)
        self.snake2 = Snake1dC(channels)
        self.conv2 = TemporalConv1dC(channels, channels, 1)

    def forward(self, x, state=None, return_state=False):
        state = {} if state is None else state
        y, conv1_history = self.conv1(
            self.snake1(x), history=state.get("conv1"), return_history=True
        )
        y, conv2_history = self.conv2(
            self.snake2(y), history=state.get("conv2"), return_history=True
        )
        output = x + y
        next_state = {"conv1": conv1_history, "conv2": conv2_history}
        if return_state:
            return output, next_state
        return output


class SnacEncoderLayer(nn.Module):
    """Three residual units followed by Snake and a strided temporal convolution."""

    def __init__(self, chan_in, chan_out, stride, residual_kernel=7):
        super().__init__()
        self.chan_in = chan_in
        self.chan_out = chan_out
        self.stride = stride
        self.residual_units = nn.ModuleList([
            SnacResidualUnit(chan_in, dilation, residual_kernel)
            for dilation in (1, 3, 9)
        ])
        self.snake = Snake1dC(chan_in)
        self.downsample = TemporalConv1dC(
            chan_in, chan_out, 2 * stride, stride=stride)

    def forward(self, x, state=None, return_state=False):
        state = {} if state is None else state
        residual_states = state.get("residual_units", [None] * 3)
        next_residual_states = []
        for unit, unit_state in zip(self.residual_units, residual_states):
            x, unit_next = unit(x, state=unit_state, return_state=True)
            next_residual_states.append(unit_next)
        x, downsample_history = self.downsample(
            self.snake(x), history=state.get("downsample"), return_history=True
        )
        next_state = {
            "residual_units": next_residual_states,
            "downsample": downsample_history,
        }
        if return_state:
            return x, next_state
        return x


class SnacNoiseBlock(nn.Module):
    """Learned per-channel noise scale added to a decoder activation."""

    def __init__(self, channels):
        super().__init__()
        self.channels = channels
        self.projection = TemporalConv1dC(channels, channels, 1)

    def forward(self, x, noise=None):
        if noise is None:
            noise = torch.randn(
                x.shape[0], 1, x.shape[-1], device=x.device, dtype=x.dtype
            )
        if tuple(noise.shape) != (x.shape[0], 1, x.shape[-1]):
            raise ValueError("noise must have shape (B,1,T)")
        return x + self.projection(x) * noise


class SnacDecoderLayer(nn.Module):
    """Snake -> causal transposed conv -> noise -> three residual units."""

    def __init__(self, chan_in, chan_out, stride, residual_kernel=7,
                 use_noise=True):
        super().__init__()
        self.chan_in = chan_in
        self.chan_out = chan_out
        self.stride = stride
        self.snake = Snake1dC(chan_in)
        self.upsample = TemporalConvTranspose1dC(chan_in, chan_out, stride)
        self.noise = SnacNoiseBlock(chan_out) if use_noise else None
        self.residual_units = nn.ModuleList([
            SnacResidualUnit(chan_out, dilation, residual_kernel)
            for dilation in (1, 3, 9)
        ])

    def forward(self, x, state=None, return_state=False):
        state = {} if state is None else state
        x, upsample_history = self.upsample(
            self.snake(x), history=state.get("upsample"), return_history=True
        )
        if self.noise is not None:
            x = self.noise(x)
        residual_states = state.get("residual_units", [None] * 3)
        next_residual_states = []
        for unit, unit_state in zip(self.residual_units, residual_states):
            x, unit_next = unit(x, state=unit_state, return_state=True)
            next_residual_states.append(unit_next)
        next_state = {
            "upsample": upsample_history,
            "residual_units": next_residual_states,
        }
        if return_state:
            return x, next_state
        return x


class SnacEncoder(nn.Module):
    """BODY-verified Zoom SNAC encoder with ordered residual RVQ."""

    def __init__(self):
        super().__init__()
        self.input_layer = TemporalConv1dC(1, 32, 7)
        self.encoder_layers = nn.ModuleList([
            SnacEncoderLayer(32, 64, 3),
            SnacEncoderLayer(64, 128, 4),
            SnacEncoderLayer(128, 256, 5),
            SnacEncoderLayer(256, 512, 8),
        ])
        self.output_layer = TemporalConv1dC(512, 512, 3, groups=512)
        self.rvq_config = {
            "max_quantizers": 12,
            "channels": 512,
            "codebook_size": 1024,
            "code_dim": 8,
        }
        self.rvq = MultiResolutionRVQ(
            dim=512,
            code_dim=self.rvq_config["code_dim"],
            size=self.rvq_config["codebook_size"],
            n_stages=self.rvq_config["max_quantizers"],
        )

    def encode_features(self, x, state=None, return_state=False):
        """Run the BODY-verified convolutional path with explicit causal state."""
        state = {} if state is None else state
        x, input_history = self.input_layer(
            x, history=state.get("input_layer"), return_history=True
        )
        layer_states = state.get("encoder_layers", [None] * 4)
        next_layer_states = []
        for layer, layer_state in zip(self.encoder_layers, layer_states):
            x, layer_next = layer(
                x, state=layer_state, return_state=True
            )
            next_layer_states.append(layer_next)
        x, output_history = self.output_layer(
            x, history=state.get("output_layer"), return_history=True
        )
        next_state = {
            "input_layer": input_history,
            "encoder_layers": next_layer_states,
            "output_layer": output_history,
        }
        if return_state:
            return x, next_state
        return x

    def forward(self, x, n_active=SNAC_CODES_PER_FRAME, return_details=False,
                state=None, return_state=False):
        features, next_state = self.encode_features(
            x, state=state, return_state=True
        )
        # Zoom's core evaluates all 12 ordered stages.  The inference wrapper
        # transmits only the configured first N indices.
        quantized, all_codes, loss = self.rvq(features)
        n = len(self.rvq.stages) if n_active is None or n_active <= 0 else n_active
        codes = all_codes[:, :min(n, len(self.rvq.stages))]
        if return_details:
            if return_state:
                return codes, quantized, loss, next_state
            return codes, quantized, loss
        if return_state:
            return codes, next_state
        return codes


class CondNet(nn.Module):
    """Standalone descriptor-table experiment; not in the viper SNAC codec BODY.

    cond_net_pembed(224,12) + fdense1(32,64) + fconv1(64,128) + fdense2(128,320).

    Dimensions read from descriptor table (recovered.SNAC_DIMS).
    pembed: 224 pitch bins, 12-dim embedding.
    fdense1: 32 inputs = 20 (latent subset) + 12 (pembed), float.
    fconv1: 192 in = 64 (fdense1) * 3 frames, out 128, k=3.
    fdense2: 128 -> 320.
    """

    PEMBED_N = COND_PEMBED_N
    PEMBED_D = COND_PEMBED_D
    FDENSE1_IN = COND_FDENSE1_IN
    FDENSE1_OUT = COND_FDENSE1_OUT
    FCONV1_IN = COND_FCONV1_IN
    FCONV1_OUT = COND_FCONV1_OUT
    FDENSE2_OUT = COND_FDENSE2_OUT

    def __init__(self, fconv_kernel=3):
        super().__init__()
        self.pembed = nn.Embedding(self.PEMBED_N, self.PEMBED_D)
        self.fdense1 = nn.Linear(self.FDENSE1_IN, self.FDENSE1_OUT)  # float
        self.fconv1 = nn.Conv1d(self.FDENSE1_OUT, self.FCONV1_OUT,
                                kernel_size=fconv_kernel, padding=fconv_kernel // 2)
        self.fdense2 = nn.Linear(self.FCONV1_OUT, self.FDENSE2_OUT)

    def forward(self, z, side=None):
        """z: (B, T, 24) latent; side: (B, T) pitch-bin indices in [0,223].

        Returns (B, T, 320) conditioning signal for the standalone SigNet model.
        """
        if side is None:
            side = torch.zeros(z.shape[0], z.shape[1], dtype=torch.long, device=z.device)
        z_cond = z[..., :self.FDENSE1_IN - self.PEMBED_D]
        h = torch.cat([z_cond, self.pembed(side)], dim=-1)
        h = F.gelu(self.fdense1(h))
        h = self.fconv1(h.transpose(1, 2)).transpose(1, 2)
        h = F.gelu(h)
        return self.fdense2(h)


class SnacDecoder(nn.Module):
    """BODY-verified Zoom decoder from 12 code slots to 480 PCM samples."""

    def __init__(self, rvq=None, use_noise=True):
        super().__init__()
        self.rvq = rvq if rvq is not None else MultiResolutionRVQ(dim=512)
        self.input_depthwise = TemporalConv1dC(512, 512, 7, groups=512)
        self.input_pointwise = TemporalConv1dC(512, 512, 1)
        self.decoder_layers = nn.ModuleList([
            SnacDecoderLayer(512, 256, 8, use_noise=use_noise),
            SnacDecoderLayer(256, 128, 5, use_noise=use_noise),
            SnacDecoderLayer(128, 64, 4, use_noise=use_noise),
            SnacDecoderLayer(64, 32, 3, use_noise=use_noise),
        ])
        self.output_snake = Snake1dC(32)
        self.output_layer = TemporalConv1dC(32, 1, 7)

    def decode_latent(self, latent, state=None, return_state=False):
        state = {} if state is None else state
        x, depthwise_history = self.input_depthwise(
            latent, history=state.get("input_depthwise"), return_history=True
        )
        x, pointwise_history = self.input_pointwise(
            x, history=state.get("input_pointwise"), return_history=True
        )
        layer_states = state.get("decoder_layers", [None] * 4)
        next_layer_states = []
        for layer, layer_state in zip(self.decoder_layers, layer_states):
            x, layer_next = layer(
                x, state=layer_state, return_state=True
            )
            next_layer_states.append(layer_next)
        x, output_history = self.output_layer(
            self.output_snake(x),
            history=state.get("output_layer"),
            return_history=True,
        )
        pcm = torch.tanh(x)
        next_state = {
            "input_depthwise": depthwise_history,
            "input_pointwise": pointwise_history,
            "decoder_layers": next_layer_states,
            "output_layer": output_history,
        }
        if return_state:
            return pcm, next_state
        return pcm

    def forward(self, codes, state=None, return_state=False):
        if codes.ndim != 2 or codes.shape[1] != SNAC_CODEBOOK_POOL:
            raise ValueError("Zoom decoder expects exactly 12 code slots")
        return self.decode_latent(
            self.rvq.from_codes(codes), state=state,
            return_state=return_state,
        )


class SigNet(nn.Module):
    """Standalone FARGAN-shaped experiment; not in the viper SNAC codec BODY.

    Its forward was checked against FARGAN run_fargan_subframe() in 2026-08-24.

    Zoom's descriptor names and dims map exactly onto xiph/opus dnn/fargan.c:

      gain      = exp(cond_gain_dense(cond80))            # (1,80) float, LINEAR + exp
      pred[44]  = clamp(gain_1 * pitch_buf[256-period-2+i]) with period wraparound
      prev[40]  = clamp(gain_1 * pitch_buf.tail  (40))
      fwc0_in   = [cond80, pred44, prev40]                # 164 per subframe
      gru1_in   = glu( tanh( fwc0_conv(cat(state164, fwc0_in)) ) )     # conv k=2 -> 192
      pitch_gate= sigmoid(gain_dense_out(gru1_in))        # (4,192) float
      gru1_in   = [gru1_in, gate[0]*pred[2:42], prev40]   # 272
      h1        = GRU(272->160);  gru2_in = [glu(h1,160), gate[1]*pred, prev]  # 240
      h2        = GRU(240->128);  gru3_in = [glu(h2,128), gate[2]*pred, prev]  # 208
      h3        = GRU(208->128);  glu3 = glu(h3,128)
      skip_cat  = [gru2_in[:160], gru3_in[:128], glu3, gru1_in[:192],
                    gate[3]*pred[2:42], prev]             # 688
      skip_out  = glu( tanh( skip_dense(skip_cat) ) )     # 128
      pcm       = tanh(sig_dense_out(skip_out)) * gain    # 40 samples
      pitch_buf.advance(40, pcm); deemphasis(pcm, 0.85)

    States carried across calls: pitch_buf(256), fwc0_mem(164), h1/h2/h3, deemph.
    GRUCells stand in for the opus GRU (gate order r-z-n vs z-r-n differs — as weights
    are trained from scratch this is inconsequential).
    """

    COND = SIG_COND_SIZE
    SUB = SIG_SUBFRAME
    NSUB = SIG_N_SUBFRAMES
    PITCH_MAX = SIG_PITCH_MAX
    DEEMPH = SIG_DEEMPHASIS

    def __init__(self):
        super().__init__()
        self.cond_gain_dense = nn.Linear(self.COND, 1)                    # float
        self.fwc0_conv = nn.Conv1d(SIG_NET_INPUT, SIG_FWC0_CONV_OUT, 2)   # int8, k=2
        self.fwc0_glu_gate = nn.Linear(SIG_FWC0_CONV_OUT, SIG_FWC0_CONV_OUT)  # int8
        self.gain_dense_out = nn.Linear(SIG_FWC0_CONV_OUT, SIG_GAIN_OUT)  # float
        h1, h2, h3 = SIG_GRU_HIDDEN
        self.gru1 = nn.GRUCell(SIG_FWC0_CONV_OUT + 2 * self.SUB, h1)      # 272 -> 160
        self.gru2 = nn.GRUCell(h1 + 2 * self.SUB, h2)                     # 240 -> 128
        self.gru3 = nn.GRUCell(h2 + 2 * self.SUB, h3)                     # 208 -> 128
        self.gru1_glu = nn.Linear(h1, h1)
        self.gru2_glu = nn.Linear(h2, h2)
        self.gru3_glu = nn.Linear(h3, h3)
        skip_in = h1 + h2 + h3 + SIG_FWC0_CONV_OUT + 2 * self.SUB         # 688
        self.skip_dense = nn.Linear(skip_in, 128)                         # int8
        self.skip_glu = nn.Linear(128, 128)                               # int8
        self.sig_dense_out = nn.Linear(128, self.SUB)                     # int8

    def init_state(self, batch, device, dtype=torch.float32):
        return {
            "pitch": torch.zeros(batch, self.PITCH_MAX, device=device, dtype=dtype),
            "fwc0":  torch.zeros(batch, SIG_NET_INPUT, device=device, dtype=dtype),
            "h1": torch.zeros(batch, SIG_GRU_HIDDEN[0], device=device, dtype=dtype),
            "h2": torch.zeros(batch, SIG_GRU_HIDDEN[1], device=device, dtype=dtype),
            "h3": torch.zeros(batch, SIG_GRU_HIDDEN[2], device=device, dtype=dtype),
            "deemph": torch.zeros(batch, device=device, dtype=dtype),
        }

    def _glu(self, x, gate):
        return x * torch.sigmoid(gate(x))

    def _pred(self, st, gain_1, period):
        """pred[i] = clamp(gain_1 * pitch_buf[256-period-2+i], +/-1), wrapped at 256."""
        B = st["pitch"].shape[0]
        pos = (self.PITCH_MAX - period - 2).clamp(0, self.PITCH_MAX - 1)   # (B,)
        outs = []
        for i in range(self.SUB + 4):
            v = st["pitch"].gather(1, pos.unsqueeze(1)).squeeze(1)
            outs.append((gain_1 * v).clamp(-1.0, 1.0))
            pos = pos + 1
            wrapped = pos >= self.PITCH_MAX
            pos = torch.where(wrapped, pos - period, pos)
        return torch.stack(outs, dim=1)                                    # (B,44)

    def subframe(self, cond, period, st):
        """One 40-sample subframe. cond: (B,80). period: (B,) long tensor."""
        gain = torch.exp(self.cond_gain_dense(cond)).squeeze(-1)           # (B,)
        gain_1 = 1.0 / (1e-5 + gain)
        pred = self._pred(st, gain_1, period)                              # (B,44)
        prev = (gain_1.unsqueeze(-1) * st["pitch"][:, -self.SUB:]).clamp(-1, 1)  # (B,40)

        fwc0_in = torch.cat([cond, pred, prev], dim=-1)                    # (B,164)
        conv_in = torch.stack([st["fwc0"], fwc0_in], dim=-1)               # (B,164,2)
        st["fwc0"] = fwc0_in
        gru1_in = self._glu(torch.tanh(self.fwc0_conv(conv_in).squeeze(-1)),
                            self.fwc0_glu_gate)                            # (B,192)
        gate = torch.sigmoid(self.gain_dense_out(gru1_in))                 # (B,4)

        p = pred[:, 2:self.SUB + 2]                                        # (B,40)
        gru1_in = torch.cat([gru1_in, gate[:, 0:1] * p, prev], dim=-1)     # (B,272)
        st["h1"] = self.gru1(gru1_in, st["h1"])
        gru2_in = torch.cat([self._glu(st["h1"], self.gru1_glu),
                             gate[:, 1:2] * p, prev], dim=-1)              # (B,240)
        st["h2"] = self.gru2(gru2_in, st["h2"])
        gru3_in = torch.cat([self._glu(st["h2"], self.gru2_glu),
                             gate[:, 2:3] * p, prev], dim=-1)              # (B,208)
        st["h3"] = self.gru3(gru3_in, st["h3"])

        skip_cat = torch.cat([gru2_in[:, :SIG_GRU_HIDDEN[0]],
                              gru3_in[:, :SIG_GRU_HIDDEN[1]],
                              self._glu(st["h3"], self.gru3_glu),
                              gru1_in[:, :SIG_FWC0_CONV_OUT],
                              gate[:, 3:4] * p, prev], dim=-1)             # (B,688)
        skip_out = self._glu(torch.tanh(self.skip_dense(skip_cat)), self.skip_glu)

        pcm = torch.tanh(self.sig_dense_out(skip_out)) * gain.unsqueeze(-1)  # (B,40)
        st["pitch"] = torch.cat([st["pitch"][:, self.SUB:], pcm], dim=1)
        de = pcm + self.DEEMPH * st["deemph"].unsqueeze(-1)                # de-emphasis
        st["deemph"] = de[:, -1]
        return de

    def forward(self, cond, period, state=None):
        """One 10 ms FARGAN frame (4 subframes = 160 samples).

        cond:   (B, 320)  — CondNet output for this frame (split 4 x 80 internally).
        period: (B,) long — pitch period in samples; period-32 must lie in [0,223].
        Returns ((B, 160) de-emphasised PCM, state).
        """
        B = cond.shape[0]
        if state is None:
            state = self.init_state(B, cond.device, cond.dtype)
        c = cond.view(B, self.NSUB, self.COND)
        pcm = torch.cat([self.subframe(c[:, s], period, state)
                         for s in range(self.NSUB)], dim=1)
        return pcm, state


# ---------------------------------------------------------------- main codec
class Snac(nn.Module):
    """Zoom-compatible convolutional SNAC codec for one 480-sample frame."""

    def __init__(self, dim=257, code_dim=8, n_stages=SNAC_CODES_PER_FRAME):
        super().__init__()
        if code_dim != 8:
            raise ValueError("Zoom SNAC code_dim is fixed at 8")
        if not 1 <= n_stages <= SNAC_CODEBOOK_POOL:
            raise ValueError("n_stages must be in [1, 12]")
        self.encoder = SnacEncoder()
        self.rvq = self.encoder.rvq
        self.decoder = SnacDecoder(rvq=self.rvq)
        self.n_stages = n_stages

    def encode(self, pcm, n_active=None, return_details=False, state=None,
               return_state=False):
        n = self.n_stages if n_active is None else n_active
        return self.encoder(
            pcm, n_active=n, return_details=return_details,
            state=state, return_state=return_state,
        )

    def forward(self, pcm, n_active=None, return_details=False, state=None,
                return_state=False):
        return self.encode(
            pcm, n_active=n_active, return_details=return_details,
            state=state, return_state=return_state,
        )

    def pad_codes(self, codes):
        if codes.ndim != 2 or not 1 <= codes.shape[1] <= SNAC_CODEBOOK_POOL:
            raise ValueError("codes must have shape (B,N), 1 <= N <= 12")
        if codes.shape[1] == SNAC_CODEBOOK_POOL:
            return codes
        padding = torch.full(
            (codes.shape[0], SNAC_CODEBOOK_POOL - codes.shape[1]),
            -1, dtype=codes.dtype, device=codes.device,
        )
        return torch.cat([codes, padding], dim=1)

    def decode_latent(self, codes):
        return self.rvq.from_codes(self.pad_codes(codes))

    def decode(self, codes, state=None, return_state=False):
        return self.decoder(
            self.pad_codes(codes), state=state, return_state=return_state
        )

    def from_codes(self, codes):
        return self.decode(codes)

    def roundtrip(self, pcm, n_active=None):
        codes = self.forward(pcm, n_active=n_active)
        return codes, self.decode(codes)

    def bits_per_frame(self):
        import math
        return self.n_stages * math.log2(SNAC_CODEBOOK_ENTRIES)


class SnacReconstruction(Snac):
    """Backward-compatible name for the body-verified codec reconstruction."""

    LATENT_DIM = 512

    def __init__(self, dim=257, **kw):
        super().__init__(dim, **kw)
        self.recovered_widths = True

    @classmethod
    def from_recovered(cls, dim=257, n_stages=SNAC_CODES_PER_FRAME,
                       codebook=SNAC_CODEBOOK_ENTRIES):
        if codebook != SNAC_CODEBOOK_ENTRIES:
            raise ValueError("Zoom SNAC codebook size is fixed at 1024")
        m = cls(dim=dim, n_stages=n_stages)
        m.recovered_widths = True
        return m

    def bits_per_frame(self):
        return super().bits_per_frame()

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    @staticmethod
    def provenance():
        return {
            "body_verified": [
                "convolutional encoder object hierarchy and causal state",
                "12-stage ordered residual RVQ and raw-dot codebook search",
                "convolutional decoder hierarchy, transposed-conv crop/state, and noise multiply-add",
                "two wire codes padded with -1 to the decoder's 12 input slots",
            ],
            "anchors": [
                "viper.dll:180238010 encoder forward",
                "viper.dll:18023D390/18023D920 RVQ forward/from_codes",
                "viper.dll:180238DA0/1802394C0 decoder ctor/forward",
                "viper.dll:18023BC70/18023C0A0 decoder-layer ctor/forward",
                "viper.dll:180247FD0 transposed-conv state/crop",
                "viper.dll:1802477D0 noise multiply-add kernel",
            ],
            "not_in_snac_main_path": ["CondNet", "SigNet", "PitchDNN"],
            "boundary": "trained Zoom weights and codebooks are not included",
        }


# ---------------------------------------------------------------- PitchDNN (structure recovered 2026-08-24)
class PitchDNN(nn.Module):
    """Standalone pitch experiment; not reached by the viper SNAC codec BODY.

    IF+xcorr→period frontend. conv2d_1/2 + gru_1 + 4 dense_* layers.

    descriptor dims: dense_if_upsampler_1(88→64), _2(64→64), downsampler(288→64),
    final_upsampler(64→192). conv2d_1: Conv2d(1→4,3); conv2d_2: Conv2d(4→1,3).
    gru_1: GRU(64→64).
    Output f = soft_argmax(exp(192))/60 - 1.5; period = floor(0.5+256·2^{-(f+1.5)}).
    cond_net_pembed idx = clamp(period-32, 0, 223).
    """

    def __init__(self):
        super().__init__()
        self.if_up1 = nn.Linear(PITCH_IF_FEATURES, PITCH_HIDDEN)
        self.if_up2 = nn.Linear(PITCH_HIDDEN, PITCH_HIDDEN)
        self.down = nn.Linear(PITCH_XCORR_BINS + PITCH_HIDDEN, PITCH_HIDDEN)
        self.gru = nn.GRU(PITCH_HIDDEN, PITCH_HIDDEN, batch_first=True)
        self.final_up = nn.Linear(PITCH_HIDDEN, PITCH_CLASSES)
        # T2 reconstruction: preserve time and all 224 xcorr bins because the
        # recovered downsampler consumes 224 + 64 IF features = 288 inputs.
        self.conv2d_1 = nn.Conv2d(1, 4, 3, padding=1, bias=True)
        self.conv2d_2 = nn.Conv2d(4, 1, 3, padding=1, bias=True)

    def forward(self, xcorr, if_feat):
        """xcorr: (B, T, 224) 224-bin normalised cross-correlation (NB_XCORR).
        if_feat: (B, T, 88) instantaneous-frequency features.
        Returns (B, T) float of period in [32, 255].
        """
        if xcorr.ndim != 3 or xcorr.shape[-1] != PITCH_XCORR_BINS:
            raise ValueError(f"xcorr must have shape (B, T, {PITCH_XCORR_BINS})")
        if if_feat.ndim != 3 or if_feat.shape[:2] != xcorr.shape[:2] or \
                if_feat.shape[-1] != PITCH_IF_FEATURES:
            raise ValueError(f"if_feat must have shape (B, T, {PITCH_IF_FEATURES}) "+
                             "with the same B and T as xcorr")

        if1 = torch.tanh(self.if_up1(if_feat))
        if2 = torch.tanh(self.if_up2(if1))
        x = xcorr.unsqueeze(1)  # (B, 1, T, 224)
        x = torch.tanh(self.conv2d_1(x))
        x = torch.tanh(self.conv2d_2(x)).squeeze(1)  # (B, T, 224)
        d = torch.tanh(self.down(torch.cat([x, if2], -1)))
        s, _ = self.gru(d)
        out = self.final_up(s)
        bins = torch.arange(PITCH_CLASSES, device=out.device, dtype=out.dtype)
        f = (F.softmax(out, dim=-1) * bins).sum(-1)
        f = f / 60. - 1.5
        period = (0.5 + SIG_PITCH_MAX / 2 ** (f + 1.5)).floor()
        period = period.clamp(PITCH_MIN_PERIOD, PITCH_MAX_PERIOD)
        return period
