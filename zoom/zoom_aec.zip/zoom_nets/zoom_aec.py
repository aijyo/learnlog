"""Clean-room, trainable reconstruction of Zoom 7.1's neural residual-AEC shape.

The frequency sizes, channel sizes, grouped convolutions, skip topology and shared
per-frequency GRU are factual observations from viperex.dll.  The eight input
features, floating-point ELU realization and complex-mask training head are our
training/deployment choices; Zoom's Q16 weights and lookup tables are not copied.

Contract:
    mic_ri, far_ri: (batch, frames, 2, 257), real/imaginary STFT bins
    state:          (batch, 4, 64), optional recurrent state
    complex_mask:   (batch, frames, 2, 257)
    state_out:      (batch, 4, 64)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import torch
from torch import Tensor, nn
import torch.nn.functional as F


@dataclass(frozen=True)
class ZoomAecContract:
    fft_size: int = 512
    bins: int = 257
    feature_bins: int = 256
    hop_size: int = 160
    input_channels: int = 8
    bottleneck_bins: int = 4
    recurrent_channels: int = 64


class AsymmetricConv1d(nn.Module):
    """Conv1d with explicit left/right frequency padding."""

    def __init__(self, in_ch: int, out_ch: int, kernel: int, stride: int = 1,
                 left: int = 0, right: int = 0, groups: int = 1,
                 activate: bool = True) -> None:
        super().__init__()
        self.left, self.right = left, right
        self.conv = nn.Conv1d(in_ch, out_ch, kernel, stride=stride,
                              padding=0, groups=groups)
        self.activate = activate

    def forward(self, x: Tensor) -> Tensor:
        y = self.conv(F.pad(x, (self.left, self.right)))
        return F.elu(y) if self.activate else y


class ZoomAecNet(nn.Module):
    """Frequency U-Net matching the recovered Zoom AEC tensor topology.

    The convolutional encoder runs independently per audio frame.  At the four-bin
    bottleneck a single 64x64 GRU is shared by all frequency positions and advances
    over time.  The decoder restores 257 bins and emits a complex ratio mask.
    """

    contract = ZoomAecContract()
    frequency_ladder = (256, 128, 64, 32, 16, 8, 8, 4)
    encoder_channels = (8, 8, 16, 32, 64, 64, 64, 64)
    decoder_frequency = (4, 8, 16, 32, 64, 128, 255, 257)
    decoder_temporal_channels = ((32, 64), (32, 32), (32, 32),
                                 (32, 32), (32, 16), (16, 8))
    decoder_mix_channels = ((128, 32), (96, 32), (64, 32),
                            (48, 32), (24, 16))

    def __init__(self, mask_limit: float = 2.0) -> None:
        super().__init__()
        self.mask_limit = float(mask_limit)

        # Descriptor rows: [frequency-in, frequency-out, out-ch, in-ch/group,
        #                   kernel, stride, left-pad, right-pad].
        self.encoder = nn.ModuleList([
            AsymmetricConv1d(8, 8, 5, 2, 1, 2),
            AsymmetricConv1d(8, 16, 5, 2, 1, 2),
            AsymmetricConv1d(16, 32, 5, 2, 1, 2),
            AsymmetricConv1d(32, 64, 5, 2, 1, 2, groups=4),
            AsymmetricConv1d(64, 64, 5, 2, 1, 2, groups=64),
            AsymmetricConv1d(64, 64, 1),
            AsymmetricConv1d(64, 64, 5, 2, 1, 2),
        ])

        # One shared one-layer GRU, evaluated as B*4 independent frequency streams.
        self.gru = nn.GRU(64, 64, num_layers=1, batch_first=True)
        self.bridge = nn.Conv1d(128, 32, 1)

        up_specs = [(32, 64), (32, 32), (32, 32),
                    (32, 32), (32, 16), (16, 8)]
        self.up = nn.ModuleList([
            nn.ConvTranspose1d(a, b, 5, stride=2, padding=2,
                               output_padding=(0 if i == 5 else 1))
            for i, (a, b) in enumerate(up_specs)
        ])
        self.mix = nn.ModuleList([
            nn.Conv1d(128, 32, 1),
            nn.Conv1d(96, 32, 1),
            nn.Conv1d(64, 32, 1),
            nn.Conv1d(48, 32, 1),
            nn.Conv1d(24, 16, 1),
        ])
        # 255 -> 257: (255-1)*1 - 2*1 + 5 = 257.
        self.head = nn.ConvTranspose1d(8, 2, 5, stride=1, padding=1)

    @staticmethod
    def build_features(mic_ri: Tensor, far_ri: Tensor) -> Tensor:
        """Build a bounded, scale-robust eight-channel clean-room feature set."""
        if mic_ri.shape != far_ri.shape or mic_ri.ndim != 4 or mic_ri.shape[2:] != (2, 257):
            raise ValueError("mic_ri and far_ri must both have shape (B,T,2,257)")
        eps = 1.0e-7
        mr, mi = mic_ri[:, :, 0], mic_ri[:, :, 1]
        fr, fi = far_ri[:, :, 0], far_ri[:, :, 1]
        mm = torch.sqrt(mr.square() + mi.square() + eps)
        fm = torch.sqrt(fr.square() + fi.square() + eps)
        cross_scale = (mm * fm).clamp_min(eps)
        features = torch.stack([
            torch.log1p(mm), torch.log1p(fm),
            mr / mm.clamp_min(eps), mi / mm.clamp_min(eps),
            fr / fm.clamp_min(eps), fi / fm.clamp_min(eps),
            (mr * fr + mi * fi) / cross_scale,
            (mi * fr - mr * fi) / cross_scale,
        ], dim=2)
        return features[..., :256]

    def initial_state(self, batch: int, *, device=None, dtype=None) -> Tensor:
        return torch.zeros(batch, 4, 64, device=device, dtype=dtype)

    def forward(self, mic_ri: Tensor, far_ri: Tensor,
                state: Optional[Tensor] = None) -> Tuple[Tensor, Tensor]:
        features = self.build_features(mic_ri, far_ri)
        batch, frames = features.shape[:2]
        x = features.reshape(batch * frames, 8, 256)

        skips = []
        for layer in self.encoder:
            x = layer(x)
            skips.append(x)

        if x.shape[-2:] != (64, 4):
            raise RuntimeError(f"encoder contract broken: got {tuple(x.shape)}")
        bottleneck = x.reshape(batch, frames, 64, 4)
        seq = bottleneck.permute(0, 3, 1, 2).reshape(batch * 4, frames, 64)
        if state is None:
            state = self.initial_state(batch, device=x.device, dtype=x.dtype)
        if state.shape != (batch, 4, 64):
            raise ValueError(f"state must be {(batch, 4, 64)}, got {tuple(state.shape)}")
        h0 = state.reshape(batch * 4, 64).unsqueeze(0).contiguous()
        recurrent, hn = self.gru(seq, h0)
        recurrent = recurrent.reshape(batch, 4, frames, 64).permute(0, 2, 3, 1)
        recurrent = recurrent.reshape(batch * frames, 64, 4)
        x = F.elu(self.bridge(torch.cat([x, recurrent], dim=1)))

        # Forward buffers a1+488,480,472,464,456 map to encoder indices
        # 5,3,2,1,0 (the depthwise length-8 output at index 4 is not retained).
        skip_indices = (5, 3, 2, 1, 0)
        for i, up in enumerate(self.up):
            x = F.elu(up(x))
            if i < 5:
                skip = skips[skip_indices[i]]
                x = F.elu(self.mix[i](torch.cat([x, skip], dim=1)))

        mask = self.mask_limit * torch.tanh(self.head(x))
        mask = mask.reshape(batch, frames, 2, 257)
        state_out = hn.squeeze(0).reshape(batch, 4, 64)
        return mask, state_out

    def check_contract(self) -> bool:
        parameter = next(self.parameters())
        with torch.no_grad():
            z = torch.zeros(2, 3, 2, 257, device=parameter.device,
                            dtype=parameter.dtype)
            y, state = self(z, z)
        assert y.shape == (2, 3, 2, 257)
        assert state.shape == (2, 4, 64)
        return True


def apply_complex_mask(mic_ri: Tensor, mask_ri: Tensor) -> Tensor:
    """Complex multiplication, returning (B,T,2,F)."""
    mr, mi = mic_ri[:, :, 0], mic_ri[:, :, 1]
    cr, ci = mask_ri[:, :, 0], mask_ri[:, :, 1]
    return torch.stack((mr * cr - mi * ci, mr * ci + mi * cr), dim=2)
