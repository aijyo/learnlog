"""PyTorch reconstructions of the two neural models recovered from Zoom's viperex.dll.

  denoise_net.DenoiseNet   257 -> 257 mask estimator (the denoise module, NOTES.md 19.15-19.18)
  snac.Snac                neural speech codec (SNAC, NOTES.md 19.22 / zoom-audio-denoise-weaknet 10)
  recovered                the architecture facts, with read-vs-inferred marked per item
  quant                    the int8 affine + block-sparse scheme SNAC uses, for export

Architectures are reproduced; Zoom's trained weights are not extracted or redistributed. Train these
on your own data. See README.md in the parent directory.
"""
from . import recovered            # noqa: F401
from .denoise_net import DenoiseNet, AuxHead          # noqa: F401
from .snac import Snac, SnacEncoder, SnacDecoder, MultiResolutionRVQ, CosineSimCodebook  # noqa: F401
from .sed import SedNet, FilterBank                   # noqa: F401
from .campp import CamppNet, OsdNet, FCM, CAM, spectral_cluster, cosine_affinity  # noqa: F401
from .aec_pvad import AecNet, PvadDecision, PvadNet   # noqa: F401
from .zoom_aec import ZoomAecNet, ZoomAecContract, apply_complex_mask  # noqa: F401
# PvadNet is an alias for PvadDecision: PVAD has no network of its own, it is a
# decision layer over CamppNet. See aec_pvad.py.

__all__ = ["recovered",
           "DenoiseNet", "AuxHead",
           "Snac", "SnacEncoder", "SnacDecoder", "MultiResolutionRVQ", "CosineSimCodebook",
           "SedNet", "FilterBank",
           "CamppNet", "OsdNet", "FCM", "CAM", "spectral_cluster", "cosine_affinity",
           "AecNet", "PvadDecision", "PvadNet",
           "ZoomAecNet", "ZoomAecContract", "apply_complex_mask"]
