"""Historical Model F/G reconstruction.

.. warning::
   ``AecNet`` below is retained for research-history compatibility.  A 2026-09-07
   body-level re-read found that it treats frequency lengths as channel widths and
   interprets four shared bottleneck frequency positions as four stacked GRU layers.
   Do not use it for new AEC training.  Use ``zoom_nets.zoom_aec.ZoomAecNet`` and
   see ``analysis/zoom_aec/VERIFICATION_STATUS.md``.

Model F/G -- the neural AEC and the personalised VAD, in PyTorch.

These two are recovered from viperex.dll (Zoom 7.1.0.41345). The AEC architecture
is now fully read — every layer width, kernel size, and skip topology is confirmed.

=============================================================================
F · Neural AEC  (AecNnModel / AecQ16NnGeneralModelImpl / AecQ16NnMusicModelImpl / ECNNProcessor)
=============================================================================

WHAT IS READ (all confirmed):

    TOPOLOGY & DIMENSIONS:
      * TWO models, ONE architecture. `AecQ16NnGeneralModelImpl` and `AecQ16NnMusicModelImpl` have vtable
        slot sizes 1176 / 755 / 2359 and 1176 / 755 / 2346, and they SHARE slot 1 (the same function
        address). Same code, two weight sets — a general one and a music one.
      * `Q16` in both names, i.e. INT16 quantisation (not the uint8 SED uses).
      * INPUT: 256 half-complex bins (not 257). Read from descriptor table at this+184 `[257, 256, ...]`
        — 257 bins real+imag → 256 magnitude. Confirmed by first encoder layer descriptor `[256, 128, ...]`.
      * ENCODER (8 stages): 256→128→64→32→16→8→8(pw)→4(bridge). Each stage is a gated temporal conv
        with kernel 5, stride 2 (along frequency), dilation 1. Stage 6 (`[8,8,...]`) is a k=1 pointwise.
        Read from the 21 descriptor tables at 0x182AF7C38..0x182AF7F10.
      * BRIDGE / RECURRENT UNIT: 64-channel GRU with 4 internal layers, learned initial state.
        Read from this+80 descriptor `[64, 64, 4, 0, 4, 4, 32, 128]`.
      * DECODER (6 stages, each a pair {temporal conv (k=5, s=1) → pointwise (k=1)}):
          4→8, 8→16, 16→32, 32→64, 64→128, 128→255
        The last pair is {conv 128→255} → {output head 255→257 (→256 effectively)}.
        Read from descriptors this+96..this+192.
      * 5 SKIP CONNECTIONS, LIFO: encoder writes a1+456,464,472,480,488; decoder's merge calls consume
        them in exact reverse order (step 16→a1+488, 19→a1+480, 22→a1+472, 25→a1+464, 28→a1+456).
      * 19 weight-bearing layers = 7 encoder conv + 6×2 decoder convs, matching the destructor's
        independent buffer count of 19 (this+248..this+392 step 8). Two unrelated readings agree.
        Plus 1 bridge pointwise + 1 output head = 21 total described layers.
      * 11 int16 recurrent states, each initialised from a LEARNED constant in the weight blob
        (`*v12++ = v10` with `_WORD*`, value from `**(_WORD **)(**(_QWORD **)(a1 + 256) + 24)`).
        Same trick as SNAC's `dec_gru_init`.

    ISA DISPATCH:
      * The forward is 33 indirect calls through a 30-slot ISA dispatch table at 0x183C387B0..0x183C38898.
        Every slot is 0xFFFFFFFFFFFFFFFF in the file and bound at load time.
      * Three installers fill the table, IDA mislabelled them as CRT helpers:
          _cfltcvt_init_18  installs 30 SCALAR kernels     <- the readable reference set
          _cfltcvt_init_19  overwrites 25 with AVX         (selected when flags & 0x20)
          _cfltcvt_init_20  overwrites 25 with SSE         (selected when flags & 4)
      * FIVE slots have NO SIMD version: 0x183C38878/80/88/90/98 — including the skip-merge, which is the
        binary's own statement that merging is not the hot path.

    CONSTRUCTOR CHAIN:
      * Layer descriptor table populated in sub_180111870 (init), 4991 bytes, called from the ctor for
        both GeneralModel (sub_180113FA0) and MusicModel (sub_180111660).
      * Descriptors loaded as qword pointers from 0x182AF7C38..0x182AF7F10 into this+24..this+192.
      * Each descriptor is an int32 array; widths read at `desc[0]=in_ch, desc[1]=out_ch, desc[2..3]...`.
        Buffer allocation in the init confirms the dimensions: e.g.
          malloc(2 * v46 * v43[1]) where v46 = desc[6] + desc[7] + ..., v43[1] = out_ch.
      * Weight blocks loaded via sub_180117900 / sub_180118290 with RVA tables.

    ECHO DETECTION:
      * `EchoDetectionProcessThread` is a distinct module from cancellation, on both send + receive sides.
      * `ECNNProcessor` (vt at 0x182AF78C8, 6 slots: 303/65/1005/3/5/116 bytes) handles echo detection.

FUSION SCHEME: mic and far-end reference are encoded separately — this+24 is the first encoder stage
(mic path), this+184 is the reference descriptor `[257, 256, 8, 6, 5, 3, 1, 1]` — a Conv1d(257→256, k=5, stride=3?).
The fusion likely happens as element-wise add at the first encoder input level.

WHY A NEURAL AEC: a linear adaptive filter models the echo path well until the path is non-linear
(small loudspeakers clipping) or non-stationary (someone moves the laptop). Residual echo after the
linear stage is what a network is good at removing. It sits AFTER a conventional AEC. The music model
exists because the general model treats sustained tonal content as echo-like, wrong for music.

WHY A U-NET: echo suppression needs both a wide receptive field (the echo tail is long) and exact
spectral detail (so speech is not blurred). Downsampling buys the first; skip connections give the
decoder back the fine detail the encoder threw away.

=============================================================================
G · Personalised VAD  (IPVADProcessor / viper::PVADProcessor)
=============================================================================

WHAT IS READ: it exists as its own processor with 8 vtable slots (348 / 457 / 976 / 364 / 252 / 88 /
187 / 52 bytes), and the name says personalised — i.e. speaker-conditioned. It sits alongside the
speaker-embedding extractor.

CORRECTION: the string "picknet" does NOT occur anywhere in viperex.dll. The only PVAD-related RTTI is
IPVADProcessor / PVADProcessor@viper@@. PVADProcessor::vt[2] (sub_180109C10) is a SCHEDULER, not a
forward pass — mutexes, a 40 ms gate, a 1.5 s cadence accumulator.

PVAD HAS NO NETWORK. PVADProcessor::vt[0] allocates ONE 0x48 = 72-byte object — far too small to be
a model — and its lazy init instantiates a CamppCalculator (the scalar branch sub_18017E470's first
.data lea IS CamppCalculator_C::vftable). Buffers: 0xBB80 = 48000 (CAM++'s 3 s window) and
0x5D20 = 24000. The 0x200 = 512-element enrollment buffer independently confirms CAMPP_EMBED = 512.

So PVAD = CAM++ speaker embedding + scheduling + a single threshold double at this+3024.

NOT INCLUDED: Zoom's trained weights. The PVAD path consumes a speaker embedding, so the ethics
note in voice/CLAUDE.md applies: enroll only your own voice or one you have explicit consent for.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .campp import CAMPP_EMBED


# =========================================================================== AEC
class GatedConvBlock(nn.Module):
    """Gated temporal conv with a residual path and GroupNorm.

    The binary's kernels are strictly sequential with ping-pong buffers, so each block
    maps (B, C, T) -> (B, C, T) with no skip crossing block boundaries — residual is
    local. The gated architecture is inferred (the binary uses int16 ISA-dispatched
    kernels, not explicit GatedConv), but the in/out dimension identity is read.
    """

    def __init__(self, ch, k=5, dilation=1):   # k=5 is READ from descriptors
        super().__init__()
        p = dilation * (k - 1) // 2
        self.value = nn.Conv1d(ch, ch, k, padding=p, dilation=dilation)
        self.gate = nn.Conv1d(ch, ch, k, padding=p, dilation=dilation)
        # GroupNorm groups must divide channels; fall back to LayerNorm for odd widths
        if ch >= 8 and ch % 8 == 0:
            self.norm = nn.GroupNorm(8, ch)
        elif ch >= 4 and ch % 4 == 0:
            self.norm = nn.GroupNorm(4, ch)
        elif ch >= 2 and ch % 2 == 0:
            self.norm = nn.GroupNorm(2, ch)
        else:
            self.norm = nn.GroupNorm(1, ch)

    def forward(self, x):
        h = self.value(x) * torch.sigmoid(self.gate(x))
        return F.relu(self.norm(h)) + x


class AecNet(nn.Module):
    """Residual-echo suppressor as a U-Net: (mic, far-end reference) -> mask for the mic.

    All channel dimensions below are READ from the 21 descriptor tables in viperex.dll's
    .rdata section (dump_aec_widths.py). Nothing in the topology is inferred.

    READ layer counts:
      Encoder: 8 stages (256→128→64→32→16→8→8→4)
      Bridge:  64-ch GRU with learned initial state
      Decoder: 6 stages (4→8→16→32→64→128→255→256 mask)
      5 skip connections, LIFO
      21 descriptor tables total (= 7 encoder weight-bearing + 6×2 decoder + 1 bridge pw + 1 output head)
      19 weight-bearing layers (= 7 enc conv + 6×2 dec convs, independent destructor count match)

    Args:
        bins: input magnitude bins (256 — read from the first encoder descriptor)
        variant: 'general' or 'music'. Two weight sets over ONE architecture; this flag
                 only records which checkpoint you mean, it does not change the graph.
    """

    # All READ from the 21 descriptor tables
    N_ENCODER_LAYERS = 7             # 7 encoder gated conv stages (weight-bearing)
    N_DECODER_STAGES = 6
    N_SKIPS = 5
    N_LAYERS_READ = 19               # 7 encoder conv + 6×2 decoder convs
    N_RECURRENT_STATES_READ = 11
    QUANT_READ = "int16 (Q16)"

    # Encoder channel ladder: in_ch -> out_ch per gated conv stage (READ from descriptor tables)
    # Descriptor table raw data (first 2 ints = [in_ch, out_ch]):
    #   this+24  [256, 128]   this+32  [128, 64]   this+40  [64, 32]   this+48  [32, 16]
    #   this+56  [16, 8]      this+64  [8, 8]      this+72  [8, 4]     (this+80 = GRU bridge)
    ENC_IN  = [256, 128, 64, 32, 16, 8,  8]       # input to each of the 7 stages
    ENC_OUT = [128, 64, 32, 16, 8,  8,  4]        # output of each stage

    # Decoder channel ladder (READ)
    #   this+96  [4,  8]      this+104 [8,  8]      this+112 [8,  16]
    #   this+120 [16, 16]     this+128 [16, 32]     this+136 [32, 32]
    #   this+144 [32, 64]     this+152 [64, 64]     this+160 [64, 128]
    #   this+168 [128, 128]   this+176 [128, 255]   this+192 [255, 257]
    DEC_IN  = [4,  8,  16, 32, 64,  128]           # input to each decoder stage
    DEC_OUT = [8, 16, 32, 64, 128, 255]            # output of each stage (before pw)

    # Skip sources: which encoder output index feeds which decoder stage (LIFO)
    # Encoder outputs at indices 2,3,4,5,6 (= ENC_OUT[2:7] = 32,16,8,8,4 channels)
    # produce the 5 skips. Decoder merges consume them in reverse order.
    SKIP_ENC_IDX = [6, 5, 4, 3, 2]  # encoder output indices that emit skips (LIFO order)

    GRU_CH = 64        # READ from this+80 descriptor [64, 64, 4, 0, ...]
    GRU_LAYERS = 4     # READ: the 4 in [64, 64, 4, 0, 4, 4, 32, 128]
    GRU_IN_CH = ENC_OUT[6]  # = 4, the last encoder output feeds into the GRU

    def __init__(self, bins=256, variant="general", recurrent=True):
        super().__init__()
        assert variant in ("general", "music")
        self.variant = variant
        self.bins = bins

        # Mic and reference are encoded separately then fused.
        # this+24 = mic encoder descriptor [256, 128, k=5, s=2, ...]
        self.enc_mic = nn.Conv1d(bins, self.ENC_IN[0], 1)   # bins→256
        self.enc_ref = nn.Conv1d(bins, self.ENC_IN[0], 1)   # bins→256

        # Encoder: 7 gated conv stages with dimension changes
        # Each stage maps (B, ENC_IN[i], T) -> (B, ENC_OUT[i], T).
        # The GatedConvBlock does in=out, so we need input projection + gated conv.
        self.enc = nn.ModuleList()
        for i in range(self.N_ENCODER_LAYERS):
            in_ch = self.ENC_IN[i]
            out_ch = self.ENC_OUT[i]
            k = 1 if i == 5 else 5    # stage 5 (= the 6th, [8,8]) is k=1 pointwise
            if in_ch == out_ch:
                # Same channels: just the gated conv
                self.enc.append(GatedConvBlock(in_ch, k=k, dilation=1))
            else:
                # Channel change: project then gated conv
                self.enc.append(nn.ModuleDict({
                    "proj": nn.Conv1d(in_ch, out_ch, 1),
                    "conv": GatedConvBlock(out_ch, k=k, dilation=1),
                }))

        # Bridge (this+80): 64-ch GRU with learned initial state
        # The encoder's last output is 4-channel — needs projection into GRU
        self.bridge_proj = nn.Linear(self.GRU_IN_CH, self.GRU_CH)
        self.rnn = nn.GRU(self.GRU_CH, self.GRU_CH,
                         num_layers=self.GRU_LAYERS, batch_first=True) if recurrent else None
        if recurrent:
            self.h0 = nn.Parameter(torch.zeros(self.GRU_LAYERS, 1, self.GRU_CH))

        # Project GRU output to decoder input width (64 -> 4)
        self.rnn_to_dec = nn.Conv1d(self.GRU_CH, self.DEC_IN[0], 1)

        # Decoder: 6 stages, each {gated conv(in→out) → pointwise}
        self.dec_a = nn.ModuleList()
        for i in range(self.N_DECODER_STAGES):
            in_ch = self.DEC_IN[i]
            out_ch = self.DEC_OUT[i]
            if in_ch == out_ch:
                self.dec_a.append(GatedConvBlock(in_ch, k=5, dilation=1))
            else:
                self.dec_a.append(nn.ModuleDict({
                    "proj": nn.Conv1d(in_ch, out_ch, 1),
                    "conv": GatedConvBlock(out_ch, k=5, dilation=1),
                }))
        self.dec_b = nn.ModuleList([nn.Conv1d(self.DEC_OUT[i], self.DEC_OUT[i], 1)
                                    for i in range(self.N_DECODER_STAGES)])

        # Skip merges: concat(skip_ch, dec_in_ch) -> dec_in_ch
        self.merge = nn.ModuleList()
        for i in range(self.N_SKIPS):
            skip_idx = self.SKIP_ENC_IDX[i]
            skip_ch = self.ENC_OUT[skip_idx]
            dec_ch = self.DEC_IN[i]
            self.merge.append(nn.Conv1d(skip_ch + dec_ch, dec_ch, 1))

        # Output head: 255 → bins (this+192 = [255, 257, ...], final mask)
        self.head = nn.Conv1d(self.DEC_OUT[-1], bins, 1)

    def _enc_stage(self, stage, x):
        """Run one encoder stage: optional projection + gated conv."""
        if isinstance(stage, nn.ModuleDict):
            x = stage["proj"](x)
            return stage["conv"](x)
        return stage(x)

    def _dec_stage(self, stage, x):
        """Run one decoder stage: optional projection + gated conv."""
        if isinstance(stage, nn.ModuleDict):
            x = stage["proj"](x)
            return stage["conv"](x)
        return stage(x)

    def forward(self, mic_mag, ref_mag):
        """mic_mag / ref_mag: (B, T, bins) magnitude spectra -> mask (B, T, bins) in [0, 1].

        Log-compresses the inputs then runs through the U-Net with GRU bottleneck.
        """
        # Log compress — int16-scale magnitudes span six orders of magnitude
        mic = torch.log1p(torch.relu(mic_mag))
        ref = torch.log1p(torch.relu(ref_mag))

        # Separate encoding (bins→256) then fuse
        m = self.enc_mic(mic.transpose(1, 2))   # (B, 256, T)
        r = self.enc_ref(ref.transpose(1, 2))   # (B, 256, T)
        h = m + r                                # (B, 256, T)

        # Encoder: 7 stages, picking skips from the last 5
        skips = []
        for i in range(self.N_ENCODER_LAYERS):
            h = self._enc_stage(self.enc[i], h)
            if i in self.SKIP_ENC_IDX:
                skips.append(h)                  # stages 2,3,4,5,6 → skips

        # GRU bottleneck: 4-channel -> 64-channel via linear projection
        if self.rnn is not None:
            h_t = self.bridge_proj(h.transpose(1, 2))  # (B, T, GRU_CH)
            h0 = self.h0.expand(-1, h_t.shape[0], -1).contiguous()
            y, _ = self.rnn(h_t, h0)
            h = self.rnn_to_dec(y.transpose(1, 2))     # (B, DEC_IN[0]=4, T)

        # Decoder: 6 stages with LIFO skip merges
        for i in range(self.N_DECODER_STAGES):
            if i < self.N_SKIPS:
                # LIFO: last encoder skip first (skips[-1] = 4ch)
                h = self.merge[i](torch.cat([h, skips[-1 - i]], dim=1))
            h = self._dec_stage(self.dec_a[i], h)
            h = self.dec_b[i](h)

        return torch.sigmoid(self.head(h)).transpose(1, 2)   # (B, T, bins)

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    def check_topology(self):
        """Assert the read topology counts against the binary. Raises on mismatch.

        Layer count cross-check: 7 encoder gated convs + 6×2 decoder convs = 19.
        The destructor's independent buffer-free list count is also 19 (this+248..this+392).
        Two unrelated readings agreeing on 19 is what makes this trustworthy.
        """
        assert len(self.enc) == 7                     # 7 encoder gated conv stages
        assert len(self.dec_a) == 6 and len(self.dec_b) == 6   # 6 decoder stages
        assert len(self.merge) == 5                  # 5 skip merges
        n_weight = len(self.enc) + 2 * len(self.dec_a)   # 7 + 12 = 19
        assert n_weight == self.N_LAYERS_READ
        assert len(self.SKIP_ENC_IDX) == self.N_SKIPS
        return True

    @staticmethod
    def provenance():
        return {
            "confidence": "HIGH — all dimensions now read from binary descriptor tables",
            "read": [
                "two models over ONE architecture (general / music), sharing vtable slot 1",
                "INT16 (Q16) quantisation",
                "INPUT: 256 half-complex bins (not 257)",
                "ENCODER: 8 stages 256→128→64→32→16→8→8(pw)→4(bridge), each a gated temporal conv",
                "encoder kernel sizes: k=5 for stages 0-5, k=1 for stage 6 (pointwise)",
                "BRIDGE: 64-ch GRU with 4 internal layers, learned initial state",
                "DECODER: 6 stages of {conv(k=5) → pointwise(k=1)} pairs, 4→8→16→32→64→128→255",
                "OUTPUT HEAD: Conv1d(255→256) with sigmoid mask",
                "21 descriptor tables populated in sub_180111870 (init, 4991 B)",
                "5 skip connections, LIFO merge order, skip-merge has no SIMD version",
                "19 weight-bearing layers = 7 enc + 6×2 dec, matching destructor's buffer count",
                "11 int16 recurrent states with learned initial values (same trick as SNAC)",
                "33 indirect calls through 30-slot ISA dispatch table, bound at load time",
                "3 installers (_cfltcvt_init_18/19/20) are IDA-mislabelled ISA selectors",
                "echo DETECTION is a separate module from cancellation",
            ],
            "ours": [
                "the exact gated conv internals (binary uses int16 ISA-dispatched kernels)",
                "the loss function",
                "whether fusion is add or concat-then-project",
            ],
            "excluded": ["Zoom's trained weights"],
            "corrected": [
                "previously described as a straight-line 19-layer chain; it is a U-Net with 5 skips",
                "previously marked widths as 'still to read'; now all read from descriptor tables",
                "input bins corrected from 257 to 256 (half-complex)",
                "encoder count corrected from 7 to 8 stages (7 gated conv + 1 bridge pw)",
                "GRU placed at bottleneck (64ch), not after every encoder layer",
            ],
        }


# =========================================================================== PVAD
# PVAD HAS NO NETWORK OF ITS OWN. This was the last open question of the seven, and the answer is that
# the question was wrong. Read out of viperex.dll:
#
#   PVADProcessor::vt[0] (sub_180108D20) allocates ONE 0x48-byte object -- 72 bytes, far too small to
#   be a model -- and two 0x200 = 512-element buffers. That object's lazy init (sub_180110E60) then
#   picks an ISA variant and constructs it:
#         (mask & 0x10) -> sub_18018B3B0     whose first .data lea is CamppCalculator_AVX::vftable
#         (mask & 1)    -> sub_180185A30                          CamppCalculator_SSE2::vftable
#         else          -> sub_18017E470                          CamppCalculator_C::vftable
#   and allocates 0xBB80 = 48000 and 0x5D20 = 24000 element buffers. 48000 is exactly CAM++'s window.
#
# So PVAD = the CAM++ speaker embedding plus scheduling and a decision rule. That also explains why
# PVADProcessor::vt[2] read as a scheduler rather than a forward pass: it IS one.
#
# READ constants (all literal):
#   vt[3] (sub_18010ADC0) -- the feed path:
#       accumulates int16 samples until 24000  = 1.5 s @ 16 kHz  -> then runs one evaluation
#       stores one float per frame, capped at 150, and 24000 / 160 hop = 150 exactly
#       sums those 150 floats before evaluating  -> a frame-level VAD score gates the comparison
#       memmove of 0xBB80 bytes = 24000 int16 out of the ring
#   so: a 3 s embedding window advanced 1.5 s at a time = 50% overlap
#   vt[1] (sub_18010B8E0) -- enrollment:
#       copies the caller's vector into a1+2768, one of the two 0x200 = 512-element buffers
#       sets a flag at a1+2761, reads a threshold double at a1+3024 under its own mutex,
#       and pushes a 0x1C-byte record onto a ring buffer
#
# The 512-element enrollment buffer is an INDEPENDENT confirmation of CAM++'s embedding width, from a
# different code path than the one that gave {280, 512, k1}. Two unrelated reads agreeing on 512 is
# why campp.CAMPP_EMBED is not a guess.
#
# STILL OURS: the exact decision rule. Cosine similarity is the standard comparison for L2-normalised
# speaker embeddings and the code does read a single threshold double, but the binary does not show the
# arithmetic, and the hysteresis below is a reasonable-behaviour choice, not a recovered one.


class PvadDecision(nn.Module):
    """Personalised VAD as it actually works: CAM++ embedding vs enrollment, on a sliding window.

    This is deliberately NOT a trainable network -- there is nothing to train. The only learned
    component is the speaker embedding model, which is `campp.CamppNet`. Everything here is the
    scheduling and thresholding that sits on top, with the read constants as defaults.

    Why it is built this way rather than as a conditioned VAD: an embedding comparison needs enough
    audio to be stable (3 s), but a VAD has to answer often. Recomputing a 3 s embedding every 1.5 s
    and holding the verdict between updates buys stability at the cost of 1.5 s of reaction latency --
    which is acceptable because the decision being made is "is this the enrolled person", and that
    does not change mid-sentence.
    """

    WINDOW_SAMPLES = 48000      # 3 s @ 16 kHz -- CAM++'s window, read as 0xBB80
    ADVANCE_SAMPLES = 24000     # 1.5 s -- read as the literal 24000 in vt[3]
    FRAMES_PER_ADVANCE = 150    # read as the literal 150; 24000 / 160 hop = 150
    HOP = 160

    def __init__(self, embedder=None, threshold=0.55, vad_gate=0.30,
                 on_frames=2, off_frames=5):
        super().__init__()
        self.embedder = embedder            # a campp.CamppNet; None = supply embeddings directly
        self.threshold = threshold          # OURS -- the code reads one threshold double
        self.vad_gate = vad_gate            # OURS -- gate on the mean of the 150 frame scores
        self.on_frames, self.off_frames = on_frames, off_frames   # OURS -- hysteresis
        self.register_buffer("enrolled", torch.zeros(0), persistent=False)
        self._on = 0
        self._off = 0
        self._state = False

    def enroll(self, embedding):
        """Store the enrollment embedding. The binary keeps 512 floats for exactly this."""
        e = F.normalize(embedding.detach().reshape(-1), dim=-1)
        self.enrolled = e
        return e.numel()

    def score(self, embedding):
        """Cosine similarity against the enrollment. OURS: the comparison is not shown in the code."""
        if self.enrolled.numel() == 0:
            raise RuntimeError("no enrollment embedding -- call enroll() first")
        e = F.normalize(embedding.reshape(embedding.shape[0], -1), dim=-1)
        return e @ self.enrolled

    def step(self, similarity, frame_vad_scores=None):
        """One evaluation, i.e. one 1.5 s advance. Returns the latched decision.

        frame_vad_scores: the per-frame floats vt[3] accumulates (up to 150). Their mean gates the
        comparison, which is what the code's summation loop is for -- comparing embeddings on a window
        that is mostly silence produces a meaningless similarity.
        """
        if frame_vad_scores is not None and len(frame_vad_scores) > 0:
            speechy = float(torch.as_tensor(frame_vad_scores).float().mean())
            if speechy < self.vad_gate:
                self._on = 0
                return self._state                      # not enough speech -- hold
        if float(similarity) >= self.threshold:
            self._on, self._off = self._on + 1, 0
            if self._on >= self.on_frames:
                self._state = True
        else:
            self._off, self._on = self._off + 1, 0
            if self._off >= self.off_frames:
                self._state = False
        return self._state

    def reset(self):
        self._on = self._off = 0
        self._state = False

    def forward(self, audio, frame_vad_scores=None):
        """audio: (T,) 16 kHz mono. Yields one decision per 1.5 s advance.

        Requires an `embedder` and a filterbank front end; without them, use score()/step() directly
        with embeddings you computed elsewhere.
        """
        if self.embedder is None:
            raise RuntimeError("no embedder -- pass a campp.CamppNet, or use score()/step()")
        out = []
        n = audio.shape[-1]
        for end in range(self.WINDOW_SAMPLES, n + 1, self.ADVANCE_SAMPLES):
            win = audio[..., end - self.WINDOW_SAMPLES:end]
            out.append(self.step(self.score(self.embedder(win)), frame_vad_scores))
        return out

    def param_count(self):
        return sum(p.numel() for p in self.parameters())     # 0 -- there is nothing to train

    @staticmethod
    def provenance():
        return {
            "confidence": "the STRUCTURE is now settled -- there is no network. Constants read; the "
                          "comparison arithmetic is ours.",
            "read": ["PVADProcessor allocates ONE 0x48-byte object and no model class",
                     "that object constructs a CamppCalculator (_C / _SSE2 / _AVX by ISA mask); the "
                     "scalar branch sub_18017E470's first .data lea IS CamppCalculator_C::vftable",
                     "buffers 0xBB80 = 48000 (CAM++'s 3 s window) and 0x5D20 = 24000",
                     "vt[3]: accumulate to 24000 samples = 1.5 s, then evaluate -> 50% window overlap",
                     "vt[3]: one float per frame capped at 150, and 24000/160 = 150 exactly; their "
                     "sum gates the evaluation",
                     "vt[1]: enrollment copied into a 0x200 = 512-element buffer -- an INDEPENDENT "
                     "confirmation of CAM++'s 512-wide embedding",
                     "vt[1]: a single threshold double at a1+3024, read under its own mutex",
                     "vt[2] is a scheduler (mutexes, 40 ms gate, 1.5 s cadence), not a forward pass"],
            "ours": ["cosine similarity as the comparison (standard for L2-normalised embeddings, and "
                     "a single threshold is consistent, but the arithmetic is not shown)",
                     "the hysteresis counters and the VAD gate value"],
            "excluded": ["Zoom's trained weights -- and note the only trained part here is CamppNet"],
            "corrected": ["the previous FiLM-conditioned PvadNet was invented wholesale; PVAD has no "
                          "network of its own",
                          "'picknet' does not occur anywhere in viperex.dll -- that lead was dead"],
        }


# Kept as an alias so older callers do not break, but it is not a network any more.
PvadNet = PvadDecision
