"""The architecture facts recovered from viperex.dll, kept as data with their provenance.

Nothing in this file is invented. Every table below is transcribed from the binary, and every place
where a field's MEANING is inferred rather than read is marked INFERRED with the reason. That
distinction is the whole point of the file: the models in this package are only as trustworthy as the
line between "read" and "guessed", and three wrong conclusions in this project came from blurring it.

Source: Zoom 7.1.0.41345, viperex.dll, IDA 7.5 headless. Addresses are image-base 0x180000000.
See voice/denoise/NOTES.md 19.15-19.18 for how each item was obtained.

WHAT IS NOT HERE: trained weights. The architecture is recoverable and reproducible; the weights are
data, not code, and are deliberately not extracted or redistributed.
"""

# ---------------------------------------------------------------------------
# Framing. Read from the constructor call sub_180001CD0(obj, 512, 160) and from
# malloc(0x808) = 2056 B = 514 float = 257 complex bins.
# ---------------------------------------------------------------------------
SAMPLE_RATE = 16000
N_FFT = 512
HOP_ZOOM = 160          # Zoom's hop: 10 ms at 16 kHz
HOP_OURS = 256          # ns_core.hpp uses fft/2; kept so metrics stay comparable
N_BINS = N_FFT // 2 + 1  # 257


# ---------------------------------------------------------------------------
# The 21 layer descriptor tables, verbatim.
#
# Populated by sub_1800E7BA0 into a2[1..21] (a2 = this+7928), each pointing at an int32 array in
# .rdata. Transcribed as-is; the first ten ints of each are shown because that is what was dumped.
#
# READ (not inferred):
#   cols[0], cols[1]  -- the in/out FEATURE WIDTH ladder. Confirmed independently: sub_1800E2F00
#                        sizes its buffers from these fields --
#                          malloc(8 * *(int*)a2[1])            -> 8 * 257
#                          malloc(4 * *(int*)a2[1])            -> 4 * 257
#                          malloc(4 * a2[1][1] * a2[1][2])     -> 4 * 128 * 8
#                        so cols[0]=257 and cols[1]*cols[2]=128*8 are certainly real quantities.
#   cols[4..7]        -- three distinct repeating signatures that partition the layers into types:
#                          (5,2,1,2)  rows 1,2,3,4,5      kernel 5, stride 2   -> downsampling
#                          (5,4,1,2)  row  7              kernel 5, stride 4   -> stronger downsample
#                          (1,1,0,0)  rows 6,9,11,13,15,17,19   kernel 1        -> pointwise
#                          (3,1,1,1)  rows 10,12,14,16,18       kernel 3 same   -> decoder conv
#                          (3,1,1,2)  row 20
#                          (1,1,1,1)  row 21
#                        The PARTITION is read. The NAMES (kernel/stride/pad/dilation) are INFERRED
#                        from the values' positions and self-consistency, see LAYER_FIELD_NOTE.
#
#   cols[2]           -- OUTPUT CHANNEL COUNT. Resolved, and confirmed by the malloc above:
#                        4 * cols[1] * cols[2] = 4 * 128 * 8 bytes = freq_out x channels x float.
#                        The sequence is 8, 16, 32, 64, 64, 64, 128 going down and
#                        64, 64, 32, 32, 32, 16, 8, 8, 1 coming back -- doubling as frequency halves
#                        and shrinking as it grows, i.e. an ordinary conv encoder-decoder.
#
# STILL INFERRED:
#   cols[3]           -- varies (3, 8, 16, 8, 1, 64, 64 ...) with no clean reading. Unused.
#   the axis          -- frequency, argued from the 200 ms ring buffers rather than read. Six
#                        stride-2 stages along TIME would need >=128 frames of context; the buffers
#                        hold 20 frames at Zoom's hop. See denoise_net.py's docstring.
# ---------------------------------------------------------------------------
LAYER_FIELD_NOTE = (
    "PARTLY RESOLVED (2026-07-30). The audit's open question was 'what OPERATION connects consecutive "
    "cols[0]->cols[1] entries'. It is a QUANTISED DENSE MATMUL: see DENOISE_QUANT_IDIOM. Reading the "
    "scalar kernels shows a 2-way-unrolled int16 dot product, a Q31 requantise "
    "(mult*acc + bias) >> 31 >> shift, a zero-point add, a clamp whose low bound is -4095 in all eight "
    "kernels, and a TABLE-LOOKUP activation at the identical byte offset 8206 in all eight. "
    "That also explains the audit's negative result: because the op is a matmul, no convolution "
    "output-size formula has to hold, which is why 13 of 14 tables failed it and why the ladder is an "
    "exact halving of an odd 257 -- successive projections, not strided convolutions. "
    "STILL NOT RESOLVED: the per-slot in/out widths, i.e. which table row belongs to which slot."
)


# row index here == a2[i] index in the binary (1-based), so LAYER_TABLES[1] is a2[1].
LAYER_TABLES = {
    1:  (257, 128,   8,   3,  5, 2, 1, 2,   0,   0),
    2:  (128,  64,  16,   8,  5, 2, 1, 2,  64,  32),
    3:  ( 64,  32,  32,  16,  5, 2, 1, 2,  32,  16),
    4:  ( 32,  16,  64,   8,  5, 2, 1, 2,   4,   0),
    5:  ( 16,   8,  64,   1,  5, 2, 1, 2,   8,   8),
    6:  (  8,   8,  64,  64,  1, 1, 0, 0,   8,   4),
    7:  (  4,   1, 128,  64,  5, 4, 1, 2, 128, 128),
    8:  (128, 128,   1,   0,  1, 1, 128, 256, 1,  1),
    9:  (  1,   1, 128, 256,  1, 1, 0, 0, 128, 128),
    10: (  1,   4,  64, 128,  3, 1, 1, 1,   1,   0),
    11: (  8,   8,  64, 128,  1, 1, 0, 0,  64,  64),
    12: (  8,  16,  32,  64,  3, 1, 1, 1,   1,   0),
    13: ( 16,  16,  32,  96,  1, 1, 0, 0,  64,  32),
    14: ( 16,  32,  32,  32,  3, 1, 1, 1,   1,   0),
    15: ( 32,  32,  32,  64,  1, 1, 0, 0,  32,  32),
    16: ( 32,  64,  16,  32,  3, 1, 1, 1,   1,   0),
    17: ( 64,  64,  32,  32,  1, 1, 0, 0,  16,  16),
    18: ( 64, 128,  16,  32,  3, 1, 1, 1,   1,   0),
    19: (128, 128,   8,  24,  1, 1, 0, 0,   8,  16),
    20: (128, 258,   8,   8,  3, 1, 1, 2,   1,   0),
    21: (258, 257,   1,   4,  1, 1, 1, 1,  16, 128),
}

# The feature-width ladder, read straight off cols[0..1] in table order.
#   encoder: 257 -> 128 -> 64 -> 32 -> 16 -> 8            (rows 1-5, then 6 pointwise)
#   bridge : rows 7/8/9 are the odd ones (4->1, 128->128, 1->1)
#   decoder: 1 -> 4 -> 8 -> 16 -> 32 -> 64 -> 128 -> 258 -> 257   (rows 10..21)
ENCODER_LADDER = [257, 128, 64, 32, 16, 8]
DECODER_LADDER = [1, 4, 8, 16, 32, 64, 128, 258, 257]

# INFERRED: the tables contain no 8 -> 4 transition, yet row 7 takes 4 as its input. Either a table
# was missed in the dump or the step happens in a kernel without its own descriptor. The model
# inserts one 8 -> 4 layer here so the graph connects; it is the single structural addition made.
MISSING_TRANSITION = (8, 4)


# ---------------------------------------------------------------------------
# The kernel dispatch table. 40 slots at 0x183C37450..0x183C375B0, filled by one of three installers
# selected on CPU features. Only 9 functions in the whole module reference it: the 3 installers and
# 6 members of the denoise chain.
#
# Installer selection, read from sub_1800E6C30:
#   cfltcvt_init_16 @ 0x1800FB5A0   baseline      (IDA misnamed these; they are not CRT functions)
#   cfltcvt_init_15 @ 0x1800F1140   cpu_flags & 0x20
#   cfltcvt_init_17 @ 0x180104DA0   cpu_flags & 0x04
# ---------------------------------------------------------------------------
KERNEL_SLOTS = {
    0: "sub_1800D1050", 1: "sub_1800F4B50", 2: "sub_1800F3050", 3: "sub_1800F3910",
    4: "sub_1800F3D90", 5: "sub_1800F4210", 6: "sub_1800F4690", 7: "sub_1800F6BE0",
    8: "sub_1800F5010", 9: "sub_1800F5B20", 10: "sub_1800F7140", 11: "sub_1800EBE60",
    12: "sub_1800FA990", 13: "sub_1800F7D60", 14: "sub_1800F83F0", 15: "sub_1800F8A80",
    16: "sub_1800F9110", 17: "sub_1800FB7E0", 18: "sub_1800FB240", 19: "sub_18006FAB0",
    20: "sub_1800D0CB0", 21: "sub_1800CA050", 22: "sub_1800C9790",
}

# slot 17 was read line by line. Its signature fixes the weight interface for the whole engine:
#     int kernel(const float *in, float *out, std::vector<float*> *params, const int *dims)
#         W = (*params)[0];  B = (*params)[1];        <- both plain float*, NOT quantised
#         lda=dims[0]  K=dims[1]  Cout=dims[2]  Cin=dims[3]  wstride=dims[4]
#         K == 1  -> fully connected;  K > 1 -> convolution along one axis
#     ...and it FREES *params on exit, which is why the caller copies the vector every call.
KERNEL17_SIGNATURE = "kernel(in, out, vector<float*>{W,B}, int dims[5]); dims[1]==1 => dense"

# Layer execution order of the main forward pass sub_1800E4340 (15 layers), with the kernel slots
# each one loads. The two "cluster" rows are loops that select a kernel per iteration; note that
# slot k and slot k+10 always appear paired there.
MAIN_FORWARD = [
    (1,  [0]), (2, [31]), (3, [32]), (4, [33]),
    (5,  [7, 8, 10, 11, 1, 37, 9, 17]),
    (6,  [19]), (7, [19]),
    (8,  [2, 12, 38, 39, 3, 13, 4, 14, 5, 15, 6, 16, 20]),
    (9,  [34]), (10, [35]), (11, [36]), (12, [21]),
    (13, []), (14, [17]), (15, [17]),
]

# 16 std::vector<void*> layer-parameter slots at this+4616 + 24*i, counted from the destructor
# sub_1800E0910. vec[4..14] are used exactly by the three auxiliary heads, contiguously.
N_PARAM_VECTORS = 16
AUX_HEADS = {
    "head1_sub_1800E1CB0": {"vecs": [4, 5, 6],            "kernels": [17, 18, 17]},
    "head2_sub_1800E21F0": {"vecs": [7, 8, 9],            "kernels": [17, 18, 17]},
    "head3_sub_1800E27C0": {"vecs": [10, 11, 12, 14, 13], "kernels": [17, 18, 17, 19, 17]},
}
AUX_HEAD_WIDTH = 16       # each head's intermediate width, read from the 4x __m128 output buffers
AUX_HEAD_HISTORY = 10     # 16 x 10 float history ring (this[5016] = 0x280 = 160 floats)
AUX_HEAD_STRIDE = 10      # output layer runs every 10th frame -> 100 ms at Zoom's hop


# ---------------------------------------------------------------------------
# The two 2-state Gaussian HMM classifiers, from sub_1800DC1F0 / sub_1800DC150.
#
# All READ. The initialiser makes the semantics unambiguous:
#   this[0]=N=2; this[4]=M=1
#   for (i<N) this[16+4i] = 1.0f/N            uniform prior
#   this[24..28] = this[32..36] = means[2]    means stored TWICE => current + init => they adapt
#   this[60] = sd[0]*sd[0]                    squared on the way in => the arg is sd, not variance
#   if (a10) { this[84..96] = {0.99,0.01,0.01,0.99}; this[100..108] = 0.5 }
# ---------------------------------------------------------------------------
HMM = {
    "ratio_domain": {   # this+5076
        "means": (25.0, 45.0), "sds": (12.0, 10.0), "range": (12.0, 72.0),
        "threshold_param": 12.0, "level_ladder": (24.0, 30.0, 36.0, 42.0), "domain_flag": 0,
    },
    "db_domain": {      # this+5244
        "means": (-44.0, -25.0), "sds": (10.0, 8.0), "range": (-55.0, -15.0),
        "threshold_param": 14.0, "level_ladder": (-48.0, -44.0, -40.0, -36.0), "domain_flag": 1,
    },
    "transition": ((0.99, 0.01), (0.01, 0.99)),
    "prior": (0.5, 0.5),
    "cov_diag_init": 144.0,
    # per model-kind variation, kind = this[5072] in {10, 11, 12, 14}
    "per_kind": {10: dict(ratio=1.5, coef=0.05, tau=(0.002, 0.005), thr=(30.0, -44.0)),
                 11: dict(ratio=1.2, coef=0.10, tau=(0.001, 0.005), thr=(30.0, -42.0)),
                 12: dict(ratio=1.3, coef=0.10, tau=(0.001, 0.005), thr=(30.0, -42.0)),
                 14: dict(ratio=1.5, coef=0.05, tau=(0.002, 0.005), thr=(30.0, -44.0))},
}
# The level ladders are FOUR entries per classifier and they move the CLASSIFIER's decision point.
# Worth stating because our own level knob moved the gain floor instead.
HMM_LADDER_NOTE = "Zoom's 4-entry level ladder biases the HMM decision point, not the gain floor."


# ---------------------------------------------------------------------------
# Neural tables adjacent to the SNAC pipeline.  CORRECTED 2026-09-01: the enc_dense/enc_gru/
# enc_conv family below belongs to the viperex CompanionMic graph, not the convolutional SNAC
# Encoder instantiated in viper.dll.  Keep the recovered descriptor facts, but do not use them to
# construct SnacInferenceEncoderAVX.
#
# Attribution: Zoom's own. Evidence is the RTTI (MultiResolutionRVQ / VectorQuantize /
# CosineSimCodebook / SnacInferenceEncoderAVX) and the SNAC_* configuration constants. The layer
# NAMES alone are shared across the whole LPCNet-descended family and are NOT sufficient to attribute
# lineage -- attributing them to Opus DRED+FARGAN on name similarity alone was a mistake, corrected
# in NOTES.md 19.22.
# ---------------------------------------------------------------------------
SNAC_LAYERS = {
    "companionmic_feature_encoder": [
        "enc_conv1", "enc_conv2", "enc_conv3", "enc_conv4", "enc_conv5",
        "enc_dense1", "enc_zdense",
        "enc_gru1", "enc_gru2", "enc_gru3", "enc_gru4", "enc_gru5",
    ],
    "quantizer": ["MultiResolutionRVQ", "VectorQuantize", "CosineSimCodebook"],
    "cond_net": ["cond_net_pembed", "cond_net_fdense1", "cond_net_fconv1", "cond_net_fdense2"],
    "decoder": ["dec_dense1", "dec_glu1", "dec_glu2", "dec_glu3", "dec_glu4", "dec_glu5",
                "dec_gru_init", "dec_hidden_init",
                "dec_gru1", "dec_gru2", "dec_gru3", "dec_gru4", "dec_gru5",
                "dec_conv1", "dec_conv2", "dec_conv3", "dec_conv4", "dec_conv5",
                "dec_output"],
    "resampler": ["dense_downsampler", "dense_if_upsampler_1", "dense_if_upsampler_2",
                  "dense_final_upsampler"],
    "gain": ["gdense1", "gdense2"],
}
# Every int8 tensor carries _scale and _subias -> affine quantisation with zero-point compensation.
# Every *_gru*_input additionally carries _weights_idx -> block-sparse input matrix.
SNAC_QUANT = {"weights": "int8", "per_tensor": ["_scale", "_subias"],
              "sparse_marker": "_weights_idx", "float_layers": ["enc_dense1", "cond_net_fdense1"]}
SNAC_CONFIG_CONSTANTS = ["SNAC_CODEBOOK_SIZE", "SNAC_MAX_CODEBOOK_NUM", "SNAC_CODES_PER_FRMS",
                         "SNAC_NUM_20MS_PER_FRM", "SNAC_PAYLOAD_TYPE", "SNAC_SEND_FREQ",
                         "SNAC_REPEAT_TIME", "SNAC_LBTCP"]
SNAC_ASSERT = "DecoderLayer::forward: input time must equal num_quantizers"

# --------------------------------------------------------------------------
# SNAC per-layer DIMENSIONS -- recovered, and the method is worth reusing.
#
# I first wrote "the binary gives layer names and kinds, not dimensions". That was wrong: the
# dimensions are in the descriptor table, they just have to be read out of the entry SIZES rather than
# assumed. Each entry is {const char* name, type|size, const void* data}, and:
#       bias size / 4                  = output width      (one float per output)
#       weights size / out / itemsize  = input width       (itemsize 1 for int8, 4 for float)
# 67 of 71 layers solve exactly this way. The four that do not are the sparse GRU inputs, where
# weight bytes != out * in BY CONSTRUCTION because the matrix is block-sparse -- so even the failures
# are informative: they confirm which layers carry _weights_idx.
#
# (out, in) per layer. GRU rows give out = 3 * hidden, because the three gates share one matrix.
# --------------------------------------------------------------------------
SNAC_DIMS = {
    # CompanionMic feature graph; these are not SnacInferenceEncoderAVX dimensions.
    "enc_dense1": (64, 40),            # float, kept unquantised in the original
    "enc_gru1_input": (192, 64), "enc_gru1_recurrent": (192, 64),
    "enc_gru2_input": (192, 224), "enc_gru2_recurrent": (192, 64),
    "enc_gru3_input": (192, 384), "enc_gru3_recurrent": (192, 64),
    "enc_gru4_input": (192, 544), "enc_gru4_recurrent": (192, 64),
    "enc_gru5_input": (192, 704), "enc_gru5_recurrent": (192, 64),
    "enc_conv1": (96, 256), "enc_conv2": (96, 576), "enc_conv3": (96, 896),
    "enc_conv4": (96, 1216), "enc_conv5": (96, 1536),
    "enc_zdense": (24, 864),           # <- the LATENT is 24-dimensional
    "gdense1": (128, 864), "gdense2": (24, 128),      # second 24-d path (gain)
    # decoder
    "dec_dense1": (96, 23),            # float
    "dec_glu1": (96, 96), "dec_glu2": (96, 96), "dec_glu3": (96, 96),
    "dec_glu4": (96, 96), "dec_glu5": (96, 96),
    "dec_gru1_recurrent": (288, 96), "dec_gru2_recurrent": (288, 96),
    "dec_gru3_recurrent": (288, 96), "dec_gru4_recurrent": (288, 96),
    "dec_gru5_recurrent": (288, 96),
    "dec_gru4_input": (288, 144),      # the only dec GRU input that is dense
    "dec_hidden_init": (128, 18),      # float
    "dec_gru_init": (480, 128),        # 480 == 5 * 96 -> all five decoder GRU init states at once
    "dec_conv1": (32, 384), "dec_conv2": (32, 640), "dec_conv3": (32, 896),
    "dec_conv4": (32, 1152), "dec_conv5": (32, 1408),
    "dec_output": (80, 736),           # 80 samples == 5 ms @ 16 kHz -> a subframe
    # conditioning
    "cond_net_pembed": (12, 224), "cond_net_fdense1": (64, 32),
    "cond_net_fconv1": (128, 192), "cond_net_fdense2": (320, 128),
    # signal path
    "sig_net_fwc0_conv": (192, 328), "sig_net_fwc0_glu_gate": (192, 192),
    "sig_net_gru1_input": (480, 272), "sig_net_gru1_recurrent": (480, 160),
    "sig_net_gru2_input": (384, 240), "sig_net_gru2_recurrent": (384, 128),
    "sig_net_gru3_input": (384, 208), "sig_net_gru3_recurrent": (384, 128),
    "sig_net_gru1_glu_gate": (160, 160), "sig_net_gru2_glu_gate": (128, 128),
    "sig_net_gru3_glu_gate": (128, 128),
    "sig_net_skip_glu_gate": (128, 128), "sig_net_skip_dense": (128, 688),
    "sig_net_sig_dense_out": (40, 128), "sig_net_gain_dense_out": (4, 192),
    "sig_net_cond_gain_dense": (1, 80),
    # resamplers
    "dense_downsampler": (64, 288),
    "dense_if_upsampler_1": (64, 88), "dense_if_upsampler_2": (64, 64),
}
# Sparse GRU inputs: weight bytes are LESS than out * in because of block sparsity. The shortfall is
# the sparsity, so these rows quantify it rather than failing to resolve.
SNAC_SPARSE = {
    "dec_gru1_input": 16576, "dec_gru2_input": 38720,
    "dec_gru3_input": 60832, "dec_gru5_input": 52544,
}
# Derived, and each one is a structural fact rather than a number:
SNAC_DERIVED = {
    "enc_gru_hidden": 64,        # 192 / 3 gates
    "dec_gru_hidden": 96,        # 288 / 3
    "sig_gru_hidden": (160, 128, 128),
    "latent_dim": 24,            # enc_zdense output
    "enc_dense_growth": 160,     # per encoder stage = GRU 64 + conv 96 -> densely connected
    "dec_subframe": 80,          # dec_output width, 5 ms @ 16 kHz
    "gru_init_bundle": "dec_gru_init 480 = 5 x 96, i.e. all five decoder GRU states from one layer",
}


# ---------------------------------------------------------------------------
# SED -- sound event detection. The best-recovered of the three models: every dimension was read AND
# cross-checked against an independently-read constant.
#
# The lever was `viper::SedModelCalculate_C`, a scalar reference implementation sitting beside _SSE2
# and _AVX2 (535 bytes vs 5267 and 4707). Same algorithm, no vectorisation, readable.
#
#   vtables:  SedModelCalculate_C    0x182AF8E18   vt[1] sub_18015BB10  vt[2] sub_18015B8F0
#             SedModelCalculate_SSE2 0x182AF8E48   vt[1] sub_18015BB10  vt[2] sub_18015CDC0
#             SedModelCalculate_AVX2 0x182AF8F48   vt[1] sub_180160D30  vt[2] sub_18015FAC0
#   vt[1] is SHARED between C and SSE2 -> it is the float-domain front end, not the hot kernel.
#   vt[2] is the SIMD-specialised quantised CNN.
#
#   processors: SEDProcessorSD 0x182AF8C98 (kind 5)  SEDProcessorHQ 0x182AF8D00 (kinds 6/7/9)
#               SEDProcessorMD 0x182AF8D68 (kind 8)  SEDProcessor   0x182AF8C30
#   smoothers : SedSmooth / SingleSedSmooth / MultiSedSmooth / HighQualitySmooth
# ---------------------------------------------------------------------------
SED = {
    "input": (100, 40),          # frames x bands. 100 frames x 10 ms = 1 s -> a scene classifier.
    "convs": [(1, 25, (3, 5), (1, 2)),     # -> 98 x 18
              (25, 20, (3, 5), (1, 1)),    # -> 96 x 14
              (20, 10, (5, 5), (2, 2))],   # -> 46 x  5
    "out_map": (10, 46, 5),      # = 2300, the dequantiser's element count
    "quant_in": "uint8 affine: q = zp + round_half_away(x/scale), clamp [0,255]",
    "requant": "(bias_i64 + mult_q31 * acc) >> 31 >> shift, clamp [0,255]  -- the clamp IS the ReLU",
    "dequant": "(q - zero_point) * scale, over 2300 values as 10 x 230",
}
# Why this one is trustworthy where the denoise net's tables were not -- each number is confirmed by a
# constant read somewhere else entirely:
SED_CROSSCHECKS = {
    1764: "L2 input-channel stride (v14 += 1764) == 98 x 18, L1's output",
    1344: "L3 input-channel stride (v14 += 1344) == 96 x 14, L2's output",
    750:  "L2 per-output-channel weight stride (a4 += 750) == 25 ic x 15 wts x 2 B => 3x5 kernel",
    1000: "L3 per-output-channel weight stride (a4 += 1000) == 20 ic x 25 wts x 2 B => 5x5 kernel",
    1288: "L3 row loop bound == 46 rows x 28 B (14 cols x 2 B) => 46 rows, i.e. row stride 2",
    2300: "dequantiser element count == 10 x 230, and 230 == 46 x 5",
    4000: "input quantiser loop, 1000 iterations x 4 unrolled == 100 x 40",
    9200: "0x23F0, three front-end buffers of 2300 floats each",
}
# OURS, not read: the classifier head (the recovered code stops at 2300 dequantised floats; how they
# become event classes is in the processor's vt[11] / smoothing stages), the filterbank warping (40
# bands is read, mel-vs-linear is not), and that the 10 channels ARE the classes.


# ---------------------------------------------------------------------------
# Capture-chain per-frame state, from the CSV telemetry header Zoom's release build writes
# (sub_18031A9E0). The format string gives the TYPE of each field, which is itself informative.
# ---------------------------------------------------------------------------
CAPTURE_TELEMETRY = [
    ("FrameNumber", "int"), ("micVol", "int"), ("echo", "int"), ("agcMode", "int"),
    ("bForBeamformer", "int"),
    ("firstStageGain", "int"), ("firstStageGainInAddMic", "int"),
    ("firstStageGainAfterAec", "int"), ("extraGain", "int"),
    ("harmonicity", "float"), ("ncVoiceProb", "float"), ("snrProb", "float"), ("SNR", "float"),
    ("bVoiceDecision", "float"),          # logged as %f despite the b-prefix => a SOFT decision
    ("estimatedNoiseMu2", "float"),
    ("voiceLevel", "int"), ("noiseLevel", "int"), ("convergeStatus", "int"),
    ("AdaptiveGain", "float"),
]
CAPTURE_NOTE = (
    "Four first-stage gains are ints (integer steps) while AdaptiveGain is float. There is a "
    "separate gain for the companion mic (InAddMic) and one applied AFTER the AEC, so gain is staged "
    "around the echo canceller rather than applied once."
)


# --------------------------------------------------------------------------------------------------
# CAM++ / OSD -- read out completely (DTDNN_CAMDense family). See campp.py for the PyTorch build.
#
# Route: RTTI gives DTDNN_CAMDense{,_C,_SSE2,_AVX} and DTDNN_CAMDense_OSD{,_C,_SSE2}. The `_C` scalar
# reference forwards are 1550 / 1835 bytes and contain the whole backbone as literal stage calls.
# Widths come from `resize(buf, bytes_per_frame * n_frames)`; kernels and dilations come from static
# 6-int config structs {in, out, kernel, stride, pad, dilation}.
CAMPP = {
    "classes": ["DTDNN_CAMDense", "_C", "_SSE2", "_AVX", "DTDNN_CAMDense_OSD", "_C", "_SSE2"],
    "forward_C": 0x180205B20,          # 1550 B -- the whole backbone, straight-line
    "init": 0x1801FC100,               # 30819 B -- 1066 push_backs into 29 weight-view vectors
    "stage_ops": {
        "dense_block": 0x180203970,    # (this, num_layers, in_ch, in, out, 6 weight views)
        "transition": 0x1802064C0,     # BN+act then 1x1 conv
        "dense_layer": 0x180204260,    # BN-act -> conv1x1->32 -> BN-act -> CAM
        "cam": 0x180204550,            # segment+global context -> 32->16->8 -> sigmoid -> multiply
        "bn_act": 0x180204B20,
        "conv": 0x1802052E0,
        "stats_pool": 0x180206130,
        "embedding": 0x180205750,
    },
    "framing": "(48000 - 320) / 160 + 1 = 299 frames; the stem's stride 2 halves it to 150",
    "fcm_flat": 320,                   # = 10 bands x 32 ch, from malloc(1280 * n_frames)
    "stem": {"in": 320, "out": 128, "k": 5, "stride": 2, "pad": 2},
    "widths": [128, 224, 112, 304, 152, 280, 140],
    "num_layers": [12, 24, 16],
    "growth": 8,                       # buffer diffs, `v16 + 8` in code, and the config in-ladder
    "bottleneck": 32,                  # buffer n<<7 = 32 floats/frame
    "kernel": 3,
    "dilation": [1, 2, 2],             # {32,8,3,1,1,1} then {32,8,3,1,2,2} twice
    "cam_segment_frames": 100,         # literal `v20 == 100 * (v20 / 100)`
    "cam_bottleneck": [32, 16, 8],
    "pool": "mean+std, 140 -> 280 (buffer 0x460, the only non-per-frame buffer)",
    "embed": 512,
    "params_rebuilt": 909573,
}

# The init's push counts per weight-view vector. This is the verification: block b must contribute
# {1 bottleneck w, 1 cfg, 8 BN w, 2 BN cfg, 5 CAM w, 3 CAM cfg} per layer. All fourteen match.
CAMPP_PUSH_COUNTS = {
    240: 12, 264: 12, 288: 96, 312: 24, 336: 60, 360: 36,      # block 1, 12 layers
    384: 24, 408: 24, 432: 192, 456: 48, 480: 120, 504: 72,    # block 2, 24 layers
    528: 16, 552: 16, 576: 128, 600: 32, 624: 80, 648: 48,     # block 3, 16 layers
    672: 4, 696: 1, 720: 4, 744: 1, 768: 4, 792: 1,            # three transitions
    816: 4, 840: 2, 864: 1,                                    # final BN, embedding w+b, embed cfg
}

OSD = {
    "forward_C": 0x1802134C0,          # 1835 B
    "init": 0x18020DDB0,               # 13787 B
    "fcm_flat": 120,                   # = 10 x 12, and it IS the stem's read input width
    "stem": {"in": 120, "out": 128, "k": 5, "stride": 2, "pad": 2},
    "widths": [128, 164, 82, 130, 65],
    "num_layers": [6, 8],              # push counts 6/6/48/12/30/18 and 8/8/64/16/40/24
    "growth": 6,                       # 128+6*6 = 164 and 82+8*6 = 130, both read as configs
    "head": "four 1x1 convs at width 128, ending in {128, 2} -> two classes",
    "head_is_pooled": True,            # buffers 0x410 = 2x130 and 0x200 = 128 are CONSTANTS
    "params_rebuilt": 228274,
}

# The FCM weight ladder, read from the blob pointer arrays (32-ch at 0x1837DDE60, 12-ch at
# 0x1837E1380). Both are 72 tensors with an identical shape -- that identity is what proves OSD is the
# same architecture at a different width rather than a different model.
FCM_LADDER = {
    "tensors": 72,
    "floats": {32: 15468, 12: 3168},   # blob-array span; includes 16-byte per-tensor padding
    "stem": "depthwise 3x3 on 1 channel (9 floats) + pointwise 1->C (C) + BN (4 x C)",
    "block": "BN (4 x C) + depthwise 3x3 (9 x C) + pointwise (C x C)",
    "n_blocks": 11,
    "pointwise_only_blocks": [3, 8],   # these two lack the 9C tensor and carry an extra C-vector
    "closing": "BN (4 x C)",
    "ours": "where the three stride-2 steps sit; 80 -> 10 forces exactly three halvings",
}

# --------------------------------------------------------------------------------------------------
# AEC -- still open, but the init narrowed it. sub_180116FC0 reads every dimension from the LAYER
# objects at runtime (`*(int *)(*(_QWORD *)(a1 + 80) + 4)`), so the literals are in the constructor
# chain, not here. What the init does establish:
AEC_INIT = {
    "func": 0x180116FC0,
    "recurrent_states": 11,            # buffers at a1+456,464,472,480,488,512,520,528,536,544,552
    "state_dtype": "int16",            # `*v12++ = v10` with _WORD*, not float
    "state_init": "each filled from a LEARNED constant read out of the weight blob "
                  "(**(_WORD **)(**(_QWORD **)(a1 + 256) + 24)), i.e. learned initial states -- the "
                  "same trick SNAC uses with dec_gru_init",
    "layer_ptrs": [24, 32, 40, 48, 64, 72, 80, 88, 104, 120, 136, 152, 168, 176, 184, 192],
    "dims_at": "layer[+4] and layer[+8]",
    "still_needed": "the constructor chain that sets layer[+4]/[+8]",
}

# --------------------------------------------------------------------------------------------------
# The self-describing-weight boundary. This is a REAL limit, not an unread gap: a full scan of the PE
# finds exactly one named descriptor table (SNAC's, at 0x180221980) and exactly three blob pointer
# arrays (CAM++ FCM, OSD FCM, and one mixed run at the head of .data). Everything else in the 38.3 MB
# of weights is reached by base pointer plus offsets computed in code, so no static scan can recover
# those dimensions -- they have to come from decompiled init/forward code.
WEIGHT_DISCOVERY = {
    "named_descriptor_tables": {0x180221980: "SNAC, 270 entries, 71 layers"},
    "blob_pointer_arrays": {0x1837DDE60: "CAM++ FCM, 72 tensors, 15468 floats",
                            0x1837E1380: "OSD FCM, 72 tensors, 3168 floats",
                            0x182B166B0: "mixed run at the head of .data, 52 pointers"},
    "rule": "'the binary does not give X' and 'I have not read X' are different claims, and the "
            "first has a much higher bar. Descriptor tables, size fields, loop bounds and buffer "
            "release lists all encode dimensions silently. Read those before concluding.",
}


# --------------------------------------------------------------------------------------------------
# AEC -- the topology is now read. It is a symmetric U-Net, not the straight-line chain first recorded.
#
# The forward makes 33 indirect calls through a 30-slot dispatch table at 0x183C387B0..0x183C38898.
# Every slot is 0xFFFFFFFFFFFFFFFF in the file and bound at load time, which is exactly why no static
# scan could see it. Three installers fill the table and IDA mislabelled all three as CRT helpers:
AEC_ISA_INSTALLERS = {
    0x180120080: "_cfltcvt_init_18 -- installs 30 SCALAR kernels; the readable reference set",
    0x180127840: "_cfltcvt_init_19 -- overwrites 25 with AVX, chosen when (flags & 0x20)",
    0x180131670: "_cfltcvt_init_20 -- overwrites 25 with SSE, chosen when (flags & 4)",
}
AEC_SCALAR_ONLY_SLOTS = [6505597048, 6505597056, 6505597064, 6505597072, 6505597080]   # no SIMD version exists -- includes the skip-merge
AEC_MERGE_KERNEL = 0x180120230            # 13 args, called 5 times: the skip-connection merge

# encoder writes these buffers; the decoder's merges consume them in EXACT reverse order
AEC_SKIP_BUFFERS = [456, 464, 472, 480, 488]
AEC_SKIP_STEPS = {16: 488, 19: 480, 22: 472, 25: 464, 28: 456}
AEC_TOPOLOGY = {
    "kind": "U-Net",
    "encoder_layers": 7,
    "decoder_stages": 6,          # each is {conv, second op, merge}; the last has no merge
    "skips": 5,
    "weight_layers": 19,          # 7 + 6*2 -- and the destructor independently frees 19 buffers
    "recurrent_states": 11,       # int16, each from a learned constant in the weight blob
    "quant": "int16 (Q16)",
    "variants": ["general", "music"],   # two weight sets, one architecture, sharing vtable slot 1
    "still_ours": "every layer WIDTH -- read at runtime from layer[+4]/[+8], so the literals are in "
                  "the constructor chain, which is the one outstanding read",
}
# slot -> scalar kernel, in the order the forward calls them
AEC_CALL_ORDER = [('0x183C387D0', 'sub_180121460'), ('0x183C387B8', 'sub_180121C10'), ('0x183C38878', 'sub_1801231E0'), ('0x183C38818', 'sub_180119540'), ('0x183C38820', 'sub_180119FF0'), ('0x183C38828', 'sub_180119A80'), ('0x183C38858', 'sub_18011E8F0'), ('0x183C38870', 'sub_18011E430'), ('0x183C387E0', 'sub_18011C050'), ('0x183C38830', 'sub_180118FE0'), ('0x183C38888', 'sub_1801209C0'), ('0x183C387C0', 'sub_1801225A0'), ('0x183C38880', 'sub_180122E60'), ('0x183C387E8', 'sub_18011C510'), ('0x183C38838', 'sub_18011A560'), ('0x183C38890', 'sub_180120230'), ('0x183C387F0', 'sub_18011CA40'), ('0x183C38860', 'sub_18011F040'), ('0x183C38890', 'sub_180120230'), ('0x183C387F8', 'sub_18011CF70'), ('0x183C38840', 'sub_18011AC40'), ('0x183C38890', 'sub_180120230'), ('0x183C38800', 'sub_18011D4A0'), ('0x183C38868', 'sub_18011F860'), ('0x183C38890', 'sub_180120230'), ('0x183C38808', 'sub_18011D9D0'), ('0x183C38848', 'sub_18011B300'), ('0x183C38890', 'sub_180120230'), ('0x183C38810', 'sub_18011DF00'), ('0x183C38850', 'sub_18011B9C0'), ('0x183C38898', 'sub_180120B50'), ('0x183C387C8', 'sub_1801221D0'), ('0x183C387D8', 'sub_1801229A0')]

# --------------------------------------------------------------------------------------------------
# PVAD -- resolved, and the resolution is that THERE IS NO NETWORK.
#
# PVADProcessor::vt[0] allocates one 0x48-byte object (72 bytes -- far too small for a model) plus two
# 0x200 = 512-element buffers. That object's lazy init picks an ISA variant and constructs it, and the
# constructed class is CamppCalculator: the scalar branch sub_18017E470's first .data lea IS
# CamppCalculator_C::vftable. So PVAD is the speaker embedding plus scheduling and a threshold.
PVAD = {
    "has_own_network": False,
    "wraps": "CamppCalculator (_C / _SSE2 / _AVX by ISA mask)",
    "ctor_by_isa": {0x18018B3B0: "CamppCalculator_AVX", 0x180185A30: "CamppCalculator_SSE2",
                    0x18017E470: "CamppCalculator_C"},
    "window_samples": 48000,          # 0xBB80 -- exactly CAM++'s window
    "advance_samples": 24000,         # 1.5 s @ 16 kHz -> 50% window overlap
    "frames_per_advance": 150,        # literal cap, and 24000 / 160 hop = 150 exactly
    "enrollment_floats": 512,         # 0x200 buffer -- an INDEPENDENT confirmation of CAMPP embed=512
    "threshold": "a single double at this+3024, read under its own mutex",
    "vt2_is": "a scheduler (mutexes, 40 ms gate, 1.5 s cadence), not a forward pass",
    "picknet": "does NOT occur anywhere in viperex.dll -- zero hits in a full byte scan",
    "ours": "the comparison arithmetic (cosine similarity) and the hysteresis",
}

# The complete inventory of SIMD-dispatched compute families. `_C` marks the scalar reference, which is
# always the readable one -- this table is therefore a map of what can still be read cheaply.
SIMD_FAMILIES = {
    "CamppCalculator": ["_C", "_SSE2", "_AVX"],
    "CamppOsdCalculator": ["_C", "_SSE2"],
    "DTDNN_CAMDense": ["_C", "_SSE2", "_AVX"],
    "DTDNN_CAMDense_OSD": ["_C", "_SSE2"],
    "SedModelCalculate": ["_C", "_SSE2", "_AVX2"],
    "CompanionMicFeatureCalculate": ["_C", "_AVX2"],   # not yet read -- the InAddMic gain path
    "EigenDecomposition": ["_C"],                      # scalar only == not a hot path
    "SpectralCluster": ["_C"],
    "Conv2dTd": ["_SSE2", "_AVX"],                     # templates, NO scalar reference
    "DepthWise_FcmTd": ["_SSE2", "_AVX"],
    "DepthWise_BasicResBlockTd": ["_SSE2", "_AVX"],
    "DepthWise_BasicResBlockScTd": ["_SSE2", "_AVX"],
}
SIMD_FAMILIES_NOTE = (
    "Only 12 families exist, and neither the denoise net nor the AEC is among them -- both dispatch "
    "through function-pointer tables instead of RTTI-named classes. That is why RTTI alone never "
    "found them, and why the dispatch-table installers had to be read instead."
)


# --------------------------------------------------------------------------------------------------
# DENOISE NET -- the operator semantics the audit left open are now READ.
#
# Route (generalised from the AEC discovery, and it found every table in the binary at once): the pair
#     48 8D 05 <rel32>   lea  rax, <function>
#     48 89 05 <rel32>   mov  [rip+<slot>], rax
# is mechanical, so sliding over .text and clustering the hits finds every ISA dispatch-table installer
# with no IDA at all. Seven tables exist, each with exactly three installers:
DISPATCH_TABLES = {
    0x183C37450: {"slots": 40, "scalar": 0x1800FB5A0, "avx": 0x1800F1140, "sse": 0x180104DA0,
                  "owner": "denoise net"},
    0x183C36E90: {"slots": 39, "scalar": 0x1800D0A80, "avx": 0x1800C6B30, "sse": 0x1800D9D40},
    0x183C35F70: {"slots": 35, "scalar": 0x1800B1180, "avx": 0x18009B260, "sse": 0x1800A81B0},
    0x183C387B0: {"slots": 30, "scalar": 0x180120080, "avx": 0x180127840, "sse": 0x180131670,
                  "owner": "AEC"},
    0x183C35150: {"slots": 19, "scalar": 0x180051580, "avx": 0x1800457D0, "sse": 0x180058110},
    0x183C35EE0: {"slots": 13, "scalar": 0x180083210, "avx": 0x180080797, "sse": 0x180084DE7},
    0x183C35DF0: {"slots": 10, "scalar": 0x18006ECD0, "avx": 0x180069D30, "sse": 0x180072FF0},
}
# Which installer is scalar is not guessed -- it is read from the caller's branch structure, the same
# shape the AEC init has. For the denoise table the three calls sit at 1800E6C7B / 8A / 95:
#     call 1800FB5A0                       <- UNCONDITIONAL  => SCALAR
#     mov eax,[rbx+0x1EEC]; test al,0x20; jz +7
#     call 1800F1140                       <- (flags & 0x20) => AVX
#     jmp +9; test al,4; jz +5
#     call 180104DA0                       <- (flags & 4)    => SSE
DENOISE_ISA_SITE = 0x1800E6C7B
DENOISE_ISA_FLAGS = {0x20: "AVX", 0x04: "SSE", 0: "scalar (unconditional)"}

# The full 40-slot SCALAR map. The previous KERNEL_SLOTS had only 23 entries and slot 22 was WRONG:
# it recorded sub_1800C9790, which is actually slot 29. Slots 0..21 were right.
KERNEL_SLOTS_SCALAR = {
    0: 0x1800D1050, 1: 0x1800F4B50, 2: 0x1800F3050, 3: 0x1800F3910, 4: 0x1800F3D90,
    5: 0x1800F4210, 6: 0x1800F4690, 7: 0x1800F6BE0, 8: 0x1800F5010, 9: 0x1800F5B20,
    10: 0x1800F7140, 11: 0x1800EBE60, 12: 0x1800FA990, 13: 0x1800F7D60, 14: 0x1800F83F0,
    15: 0x1800F8A80, 16: 0x1800F9110, 17: 0x1800FB7E0, 18: 0x1800FB240, 19: 0x18006FAB0,
    20: 0x1800D0CB0, 21: 0x1800CA050, 22: 0x18006ED60, 23: 0x18006C4F0, 24: 0x18006C1C0,
    25: 0x1800F6080, 26: 0x1800F6630, 27: 0x1800F97A0, 28: 0x1800FA0A0, 29: 0x1800C9790,
    30: 0x18006F590, 31: 0x1800C9030, 32: 0x1800C9030, 33: 0x1800C9030, 34: 0x1800C9030,
    35: 0x1800C9030, 36: 0x1800C9030, 37: 0x1800F5570, 38: 0x1800F3490, 39: 0x1800F76C0,
}
KERNEL_SLOTS_CORRECTION = (
    "slot 22 was recorded as sub_1800C9790; that function is slot 29. Slots 0-21 were correct, and "
    "the kernel read earlier (slot 17 = sub_1800FB7E0) WAS from the scalar installer -- confirmed by "
    "the caller's branch structure -- so that read did not need redoing."
)

# ---- THE OPERATOR IDIOM. This is what the audit could not resolve, and it is identical in all eight
# weight-bearing kernels read so far (slots 1, 2, 3, 11, 13, 37, 38, 39):
DENOISE_QUANT_IDIOM = {
    "storage": "int16 in the 40-slot variant. NOT a replacement for the uint8 reading -- see DENOISE_VARIANTS: the 39-slot variant really is uint8 with clamp[0,255] as ReLU. Two variants of one operator, not one scheme misread.",
    "accumulate": "2-way unrolled dot product: two int16 inputs per step at stride 4, 16 int16 of "
                  "weights consumed per step feeding 8 accumulators -> weights are stored "
                  "output-major with two inputs interleaved",
    "requantise": "acc = (int)((uint64)(mult_q31 * acc + bias_i64) >> 31) >> shift",
    "zero_point": "added after the shift, read from *(__int16 *)(cfg[2] + 4)",
    "clamp_low": -4095,          # verified in ALL eight kernels
    "clamp_high": 4096,          # read directly in slot 3; the other kernels' high bound not re-read
    "activation": "TABLE LOOKUP: out = *(int16 *)(lut + 2 * y + 8206). The byte offset 8206 = 2 * 4103 "
                  "is IDENTICAL in all eight kernels, i.e. ONE shared activation LUT for the whole "
                  "network, indexed so 4103 <-> y = 0. This is why no closed-form activation was ever "
                  "found: there isn't one.",
    "why_it_matters": "the connecting operation is a quantised MATMUL, so no convolution output-size "
                      "formula has to hold -- which is exactly why the audit found 13 of 14 tables "
                      "failing that formula. The ladder is successive projections, not strided convs.",
}

# ---- where the int16 core begins and ends, read from the kernels' own arithmetic ----
DENOISE_PRECISION_MAP = {
    "pure_int16": [1, 2, 3, 11, 37, 38],
    "int16_weights_with_float_arith": [13, 39],
    "pure_float": [31, 32, 33, 34, 35, 36, "post-processor sub_1800E61D0"],
    "structure": "slots 31-36 are SIX COPIES of one float function (sub_1800C9030), and MAIN_FORWARD "
                 "uses 31/32/33 at stages 2-4 and 34/35/36 at stages 9-11 -- symmetrically around the "
                 "int16 stages 5-8. So the pipeline is float pre -> int16 network -> float post, and "
                 "the six identical slots are the quantisation boundary.",
}

# ---- slot 11 is not ISA-specialised ----
DENOISE_NO_SIMD_SLOTS = [11]   # sub_1800EBE60 is slot 11 in BOTH the scalar and AVX installers,
                               # i.e. the binary itself says this one is not worth vectorising --
                               # the same signal the AEC's skip-merge gives.


# --------------------------------------------------------------------------------------------------
# THE DENOISE NET HAS TWO QUANTISATION VARIANTS, and this reconciles a contradiction I created.
#
# Attributing the seven dispatch tables showed that the 39-slot table shares SLOT 0 (sub_1800D1050)
# and ten kernels total with the denoise 40-slot table, and that its slot-1 kernel (sub_1800A1D00) is
# STRUCTURALLY THE SAME OPERATOR as the 40-slot table's slot 3 (sub_1800F3910) -- identical 8x8 loop
# nest, identical 2-way-unrolled int16 dot product, identical 16-int16 weight step, identical Q31
# requantise -- differing ONLY in the output stage:
DENOISE_VARIANTS = {
    0x183C37450: {
        "slots": 40, "isa_site": 0x1800E6C7B, "init": 0x1800E6C30,
        "inner_loop": 64,
        "clamp": (-4095, 4096),
        "activation": "*(int16 *)(lut + 2*y + 8206)   -- int16 LUT, stride 2, offset 8206 = 2*4103",
        "act_precision": "13-bit signed",
        "example_kernel": 0x1800F3910,
    },
    0x183C36E90: {
        "slots": 39, "isa_site": 0x1800BBB3F, "init": 0x1800BBB30,
        "inner_loop": 32,
        "clamp": (0, 255),
        "activation": "*(uint8 *)(y + lut + 16)       -- uint8 LUT, stride 1, offset 16",
        "act_precision": "8-bit unsigned; the clamp's lower bound of 0 doubles as ReLU",
        "example_kernel": 0x1800A1D00,
    },
}
DENOISE_VARIANT_NOTE = (
    "So the net ships in an 8-bit and a 13-bit flavour over the same operator, which fits the "
    "CPU-adaptive degradation recorded earlier: the cheap variant is not a different architecture, it "
    "is the same one with a narrower activation. IMPORTANT CORRECTION TO MY OWN EARLIER NOTE: NOTES "
    "19.31 said 'int16 throughout, NOT the uint8 scheme' -- that was an OVER-correction. The original "
    "uint8 / clamp[0,255]-as-ReLU reading was right, it just came from the 39-slot variant, while the "
    "int16 / clamp[-4095,4096] reading is the 40-slot variant. Both are real. What was actually wrong "
    "was assuming there was only one scheme to find."
)

# Table attribution, as far as it goes. The five previously-unowned tables' init functions are NOT in
# any vtable (non-virtual classes), so the MSVC RTTI walk that names AecQ16NnGeneralModelImpl::vt[0]
# for the AEC table returns nothing for them. Kernel SHARING is what attributes them instead.
DISPATCH_TABLE_OWNERS = {
    0x183C37450: "denoise net, int16 variant (40 slots)",
    0x183C36E90: "denoise net, uint8 variant (39 slots) -- shares slot 0 + 10 kernels with the above",
    0x183C35DF0: "shared sub-module (10 slots) -- 5 of its kernels are also denoise slots "
                 "(19/22/23/24/30), all in the 0x18006xxxx block",
    0x183C387B0: "AEC (30 slots) -- AecQ16NnGeneralModelImpl::vt[0], the only one the RTTI walk names",
    0x183C35F70: "unowned (35 slots), kernels 180052830..1800B47D0, no kernel shared with denoise",
    0x183C35150: "unowned (19 slots), kernels 1800458E0..180057630",
    0x183C35EE0: "unowned (13 slots), kernels 180051690..180084880; shares kernels with the 19-slot "
                 "table (sub_180051690, sub_180052440), so those two are probably siblings",
}
DISPATCH_ATTRIBUTION_METHOD = (
    "Three routes, in decreasing reliability: (1) the MSVC RTTI walk -- find the init function's "
    "address inside a vtable, then vtable[-1] -> complete object locator -> COL+12 -> type descriptor. "
    "Works only for virtual classes; named the AEC table. (2) kernel sharing -- two tables listing the "
    "same kernel function belong to the same pipeline; this is what identified the two denoise "
    "variants. (3) address neighbourhood, weakest, used only to corroborate."
)


# --------------------------------------------------------------------------------------------------
# THE STFT FRONT END -- read out of sub_180001CD0 (18 KB of pseudocode). This was "batch B".
#
# It is NOT a plain Hann window. It is an ASYMMETRIC LOW-DELAY window pair, built from two half-Hanns
# of DIFFERENT periods, and that is the whole point: it buys a short algorithmic delay out of a
# 512-point transform.
STFT_FRONT_END = {
    "func": 0x180001CD0,
    "frame": 512,                 # a2, supplied by the caller
    "hop": 160,                   # a3
    "bins": 257,                  # the FFT work buffer is resized to frame + 2 = 514 floats
    "ola_terms": 4,               # the OLA sum has exactly 4 terms, and frame/hop + 1 = 512/160 + 1 = 4
    "smoothing_const": 0.97,      # stored at this+296 as 0x3F7851EC
}

# The analysis window: two pieces, each the sqrt of a half-Hann, with DIFFERENT periods.
#   piece 1   samples   0..351   sqrt(0.5 - 0.5*cos(i * 2pi / 705))    i = 0..351
#   piece 2   samples 352..511   sqrt(0.5 - 0.5*cos(n * 2pi / 321))    n = 160..319
# Note 705 = 2*352 + 1 and 321 = 2*160 + 1, so each piece is exactly one half of a Hann whose period
# is set to twice that piece's length. Piece 1 is the RISING half of a long Hann; piece 2 is the
# FALLING half of a short one. 352 + 160 = 512.
STFT_ANALYSIS_WINDOW = {
    "length": 512,
    "pieces": [
        {"samples": (0, 352), "form": "sqrt(hann)", "period": 705, "index_from": 0,
         "role": "long rising edge"},
        {"samples": (352, 512), "form": "sqrt(hann)", "period": 321, "index_from": 160,
         "role": "short falling edge"},
    ],
    "why": "A symmetric 512 window costs half the window in look-ahead (256 samples = 16 ms at "
           "16 kHz). Making the fall short and the rise long moves the delay onto the RISE, which is "
           "already-received audio, so the look-ahead is only the 160-sample tail = 10 ms. Same "
           "frequency resolution as a 512 transform, 6 ms less delay. This is why the window looks "
           "lopsided -- it is a latency decision, not a spectral one.",
    "cost": "the long rise has poorer time localisation on onsets, and the two halves do not have "
            "matching sidelobes, so the effective analysis filter is not the textbook Hann response.",
}

# The synthesis window, written into its own 512-float buffer but NONZERO ONLY over the last 320
# samples (float offset 192 = byte offset 768):
#   syn[192 + k] = (0.5 - 0.5*cos(k * 2pi / 321)) / ana[192 + k]      k = 0..319
# i.e. the WOLA dual: a Hann numerator divided by the analysis window, so that analysis * synthesis
# sums to the Hann across hops. The division is why the analysis window is stored as a SQRT.
STFT_SYNTHESIS_WINDOW = {
    "buffer_length": 512,
    "nonzero_range": (192, 512),
    "length": 320,
    "form": "hann(period 321) / analysis_window, elementwise",
    "note": "the analysis window being sqrt(hann) and the synthesis being hann/sqrt(hann) is the "
            "standard WOLA factorisation -- their product is hann, which is what has to sum to a "
            "constant across hops.",
}

# The squared analysis window is stored alongside, and normalised by the 4-term OLA sum:
#   w2[n] = w[n]^2 ; ola[n] = w2[n] + w2[n+hop] + w2[n+2*hop] + w2[n+3*hop] ; then w2 /= ola
STFT_OLA_NORMALISATION = (
    "w2[n] = w[n]^2, then ola[n] = sum over 4 hops of w2, then an _mm_div_ps loop divides w2 by ola. "
    "The 4 terms are not a magic number: frame/hop + 1 = 512/160 + 1 = 4 is computed a few lines "
    "earlier, and the loop is specialised to that count."
)
