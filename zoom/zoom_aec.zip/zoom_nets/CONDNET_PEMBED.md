# SNAC CondNet pembed — 完整维度分析与代码修正

> 2026-08-18，基于 `recovered.SNAC_DIMS` 的逐层分析

## pembed 是什么

`cond_net_pembed` 的权重表尺寸是 **(12, 224)**（输出维度 12，嵌入表大小 224）。

```
bias  = 48 B  → 48/4  = 12  = embed_dim
weight = 2688 B → 2688/12/1 = 224 = n_embed
```

所以 `pembed = nn.Embedding(224, 12)` — 一个 224 行的查找表，每行 12 维。

二进制里 `cond_net_pembed` 描述符附近发现了一个 `(PITCH)` 字符串（弱命中），所以这个 side-channel 大概率是**基音周期（pitch period）的量化索引**。224 个 bin 在 16 kHz 下约等于每 bin ≈ 2.22 Hz（对数间距下覆盖 40–550 Hz）。

不过严格来说这个 string hit 是「弱证据」，所以重建里把 `side` 暴露为泛型整数，调用方决定传什么。

## 你问的 `h = torch.cat([z, self.pembed(side)], dim=-1)` 详解

这行是对的——**在语义上**。但它之前的维度全是错的，所以我把整条 CondNet 都修了。

### 修正前的错误（v1）

```python
# 旧代码
class CondNet(nn.Module):
    def __init__(self, latent=64, width=128, n_embed=256, embed_dim=32):
        self.pembed = nn.Embedding(256, 32)
        self.fdense1 = nn.Linear(64+32=96, 128)   # ✗ 应该是 32→64
        self.fconv1 = nn.Conv1d(128, 128, 3)       # ✗ 应该是 64→128
        self.fdense2 = nn.Linear(128, 128)          # ✗ 应该是 128→320
```

四个数字全错：
- `n_embed`: 256 → 实际读出来是 **224**
- `embed_dim`: 32 → 实际读出来是 **12**
- `fdense1`: 96→128 → 实际是 **32→64**（float，不量化）
- `fdense2`: 128→128 → 实际是 **128→320**

### 修正后（v2，已写入 snac.py）

读出来的维度链：

```
z[..., :20]    →  20 维（从 24 维潜变量取前 20）
pembed(side)   →  12 维（224 个可能的 pitch bin）
  concat       →  32 维
fdense1(32→64) →  64 维（float = 浮点，原实现里保留不量化）
fconv1(64→128) → 128 维（Conv1d，k=3，跨 3 帧 = 3×64=192 输入通道）
fdense2(128→320)→ 320 维（最终条件信号）
```

其中 `fconv1` 的 192 输入通道含义：fdense1 输出 64 维 × 3 个相邻帧 = 192。这是 Conv1d(in=64, out=128, k=3) 的权重形状 `(128, 64, 3) = 24576` 字节，从 descriptor table 反推吻合。

### 为什么 fdense1 输入是 32，而不是 36

这是关键。潜变量 `enc_zdense` 输出是 24 维，而 `fdense1` 输入是 32 维。如果直接 `[z | embed]` = 24 + 12 = 36 ≠ 32。

答案：**CondNet 只拿 24 维潜变量的前 20 维。** 20 + 12 = 32 ✓。

那剩下 4 维去哪了？可能是全局增益路径（`gdense1/gdense2` 产出第二条 24 维）。24 - 20 = 4，刚好对得上 `sig_net_gain_dense_out: (4, 192)` 里的 4 维增益。

## 潜变量 → 解码器和 CondNet 是两条独立路径

另一个重大修正：**解码器不拿 CondNet 的 320 维输出。** 证据是 `dec_dense1: (96, 23)` — 解码器第一层只收 23 维输入。

解码器路径：

```
q[..., :23]              → 23 维（24 维潜变量去掉 1 维）
dec_dense1(23→96)        → 96 维
dec_glu1..5(96→96)       → 96 维
dec_gru1..5(hidden=96)   → 96 维（learned init state）
dec_conv1..5             → 32 维
dec_output(736→80)       → 80 采样 = 5 ms @16 kHz
```

而 CondNet 的 320 维输出送到 sig_net（独立的信号精炼网）：

```
sig_net_fwc0_conv(328→192)    ← 328 = 320(cond) + 8
sig_net_gru1..3(hidden 160/128/128)
sig_dense_out(128→40)         → 40 维（精炼后的信号）
sig_gain_dense_out(192→4)     → 4 维（精炼后的增益）
```

所以完整管线是：

```
音频 → encoder → z(24)
                  ├→ gdense1/gdense2 → g(24)  [增益路径]
                  ├→ RVQ → q(24)                          [量化路径]
                  │        ├→ q[:23] → decoder → 80采样  [解码]
                  │        └→ q[:20] + pembed(side,12) → CondNet → 320 [条件]
                  └→ sig_net(decoder_out(80) + cond(320)) → 精炼输出 [后处理]
```

## `side` 究竟是什么

结论：**很可能是基音周期量化索引，但证据是弱级别的。**

证据：
- 描述符附近有 `(PITCH)` 字符串（弱强度，不是强关联）
- 224 bins 是合理的 pitch 量化粒度
- 12 维 embedding 足够承载 pitch 的信息含量
- 编码器的设计（5 conv + 5 GRU + 稠密连接）是典型声码器，pitch 作为 conditioning 是标准做法

不能排除的其他可能：VAD 判决、语音/非语音标志、或是 SNR 量化等级。没有强证据锁定就是 pitch，所以代码里暴露为泛型 `side: LongTensor`。

## 需要 IDA 验证的剩余问题

1. **fconv1 的 kernel size**: descriptor table 只给宽度不给感受野。k=3 是我们的假设（LPCNet 风格）。
2. **CondNet → sig_net 的确切连接**: 读出了 fwc0_conv 输入 328 = 320 + 8，但 8 是什么（pooled decoder output？额外嵌入？）需要 IDA 读 sig_net init/forward。
3. **24 维潜变量的语义**: 前 20 进 CondNet、前 23 进解码器、维度如何分割，需要 IDA 读 condition 函数。
4. **pitch extraction 前端**: `side` 索引是在编码器外部的 DSP 前端算出的，不在 SNAC 网络里。

## 代码状态

`snac.py` 已更新：CondNet、SnacEncoder、SnacDecoder、Snac 全都改用从 descriptor table 读出的实际宽度。`CondNet` 现在可独立实例化和测试：

```python
from train.zoom_nets.snac import CondNet
import torch

net = CondNet()  # 自动用 224×12 embed, 32→64, 64→128 conv, 128→320
print(f"Params: {sum(p.numel() for p in net.parameters()):,}")

z = torch.randn(2, 50, 24)      # batch=2, frames=50, latent=24
side = torch.randint(0, 224, (2, 50))  # batch=2, frames=50, indices=0..223
c = net(z, side)
print(f"Output: {c.shape}")     # (2, 50, 320)
```

---

## 补遗（2026-08-24，来源 FARGAN 参考 dnn/fargan.c）

`side` 的精确语义已解决：pembed 索引 = `clamp(period - 32, 0, 223)`，其中 period
是 pitch 周期（采样数），编码于特征维 f：`period = floor(0.5 + 256·2^{-(f+1.5)})`。
所以 224 个 bin **在周期域是均匀的**（period 32..255），不是对数域：
period=32 → F0=500 Hz，period=255 → F0≈62.7 Hz。上面"每 bin ≈ 2.22 Hz"的
说法作废。训练时你自己的 pitch tracker 给出 period 后取 `side = period - 32`。

若用 `side` 反推 period（snac.py 里 SigNet 调用处）：`period = side + 32`。

另纠正本文档第 83 行：`sig_net_fwc0_conv` 输入 328 ≠ 320+8，而是
**2×164 因果卷积窗**（cond80 + pred44 + prev40，kernel=2 帧）。
完整推导见 `cdn/snac_signet_forward_verified.md`。
