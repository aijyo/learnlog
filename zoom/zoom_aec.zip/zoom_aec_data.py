"""Dataset and spectral helpers for direct target-supervised AEC training."""
from __future__ import annotations

import csv
import random
import wave
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset


SAMPLE_RATE = 48_000
FFT_SIZE = 512
HOP_SIZE = 160


def read_pcm16_mono(path: Path) -> Tensor:
    with wave.open(str(path), "rb") as wav:
        if wav.getnchannels() != 1 or wav.getsampwidth() != 2:
            raise ValueError(f"expected mono PCM16 WAV: {path}")
        if wav.getframerate() != SAMPLE_RATE:
            raise ValueError(f"expected {SAMPLE_RATE} Hz WAV: {path}")
        raw = wav.readframes(wav.getnframes())
    return torch.from_numpy(np.frombuffer(raw, dtype="<i2").copy()).float().div_(32768.0)


def write_pcm16_mono(path: Path, samples: Tensor) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = (samples.detach().cpu().clamp(-1.0, 0.999969) * 32768.0).round()
    raw = pcm.to(torch.int16).numpy().astype("<i2", copy=False).tobytes()
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(SAMPLE_RATE)
        wav.writeframes(raw)


def load_ids(path: Path) -> list[str]:
    return [line.strip() for line in path.read_text(encoding="utf-8-sig").splitlines()
            if line.strip()]


def load_delays(path: Path) -> Dict[str, float]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return {row["file_id"]: float(row["echo_delay"])
                for row in csv.DictReader(handle)}


def delay_signal(x: Tensor, samples: int) -> Tensor:
    """Move far-end audio later so it lines up with the echo observed at the mic."""
    if samples <= 0:
        return x
    if samples >= x.numel():
        return torch.zeros_like(x)
    return torch.cat((torch.zeros(samples, dtype=x.dtype), x[:-samples]))


class SyntheticFullbandAec(Dataset):
    def __init__(self, root: str | Path, split: str, chunk_seconds: float = 3.2,
                 align_far_from_meta: bool = True, max_items: int = 0) -> None:
        self.root = Path(root)
        if split not in ("train", "cv"):
            raise ValueError("split must be train or cv")
        self.split = split
        self.ids = load_ids(self.root / f"{split}.list")
        if max_items:
            self.ids = self.ids[:max_items]
        self.delays = load_delays(self.root / "meta.csv")
        self.chunk_samples = max(FFT_SIZE, int(round(chunk_seconds * SAMPLE_RATE)))
        self.align_far = align_far_from_meta

    def __len__(self) -> int:
        return len(self.ids)

    def __getitem__(self, index: int) -> Tuple[Tensor, Tensor, Tensor, str]:
        file_id = self.ids[index]
        base = self.root / "data" / file_id
        far = read_pcm16_mono(Path(str(base) + "_farend.wav"))
        mic = read_pcm16_mono(Path(str(base) + "_mic.wav"))
        target = read_pcm16_mono(Path(str(base) + "_target.wav"))
        size = min(far.numel(), mic.numel(), target.numel())
        far, mic, target = far[:size], mic[:size], target[:size]
        if self.align_far:
            delay = int(round(self.delays.get(file_id, 0.0) * SAMPLE_RATE / 1000.0))
            far = delay_signal(far, delay)

        n = self.chunk_samples
        if size < n:
            pad = n - size
            far, mic, target = (torch.nn.functional.pad(x, (0, pad))
                                for x in (far, mic, target))
        else:
            start = random.randint(0, size - n) if self.split == "train" else (size - n) // 2
            far, mic, target = (x[start:start + n] for x in (far, mic, target))

        # One shared scale preserves the physical mic/far/target relationship.
        scale = torch.stack((far.square().mean(), mic.square().mean(),
                             target.square().mean())).max().sqrt().clamp_min(1.0e-4)
        return mic / scale, far / scale, target / scale, file_id


def stft_ri(waveform: Tensor, window: Tensor) -> Tensor:
    # center=False is streaming-friendly. Pad only the tail so the final frame also
    # covers the original final sample; istft_ri later trims back to exact length.
    samples = waveform.shape[-1]
    tail = (-(samples - FFT_SIZE)) % HOP_SIZE if samples >= FFT_SIZE else FFT_SIZE - samples
    if tail:
        waveform = torch.nn.functional.pad(waveform, (0, tail))
    spec = torch.stft(waveform, FFT_SIZE, HOP_SIZE, FFT_SIZE, window,
                      center=False, return_complex=True)
    return torch.view_as_real(spec.transpose(1, 2)).permute(0, 1, 3, 2).contiguous()


def ri_to_complex(x: Tensor) -> Tensor:
    return torch.view_as_complex(x.permute(0, 1, 3, 2).contiguous()).transpose(1, 2)


def istft_ri(x: Tensor, window: Tensor, length: int) -> Tensor:
    return torch.istft(ri_to_complex(x), FFT_SIZE, HOP_SIZE, FFT_SIZE, window,
                       center=False, length=length)


def complex_magnitude(x: Tensor) -> Tensor:
    return torch.sqrt(x[:, :, 0].square() + x[:, :, 1].square() + 1.0e-8)
