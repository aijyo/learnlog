[CmdletBinding()]
param(
  [ValidateSet('verify','setup','smoke','train','resume','export','infer')]
  [string]$Action = 'verify',
  [string]$Dataset = 'D:\AEC48K\synthetic-fullband-v1',
  [string]$RunDir = "$PSScriptRoot\runs\zoom_aec_target",
  [string]$Python = 'C:\Users\CT10266\AppData\Local\Programs\Python\Python39\python.exe',
  [string]$Checkpoint = '',
  [string]$Mic = '',
  [string]$Far = '',
  [string]$Target = '',
  [string]$OutputWav = "$PSScriptRoot\runs\zoom_aec_target\processed.wav",
  [double]$FarDelayMs = 0,
  [int]$Epochs = 40,
  [int]$BatchSize = 4,
  [int]$Workers = 0,
  [double]$ChunkSeconds = 3.2,
  [double]$LearningRate = 0.0003,
  [int]$ValidationBatches = 50,
  [string]$Device = '',
  [string]$MnnConvert = 'D:\code\work\_build\MNN\build_conv\Release\MNNConvert.exe'
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Python)) { throw "Python not found: $Python" }
if (-not $Checkpoint) { $Checkpoint = Join-Path $RunDir 'best.pt' }
$trainCommon = @('--dataset',$Dataset,'--output',$RunDir,'--epochs',([string]$Epochs),
                 '--batch-size',([string]$BatchSize),'--workers',([string]$Workers),
                 '--chunk-seconds',([string]$ChunkSeconds),'--lr',([string]$LearningRate),
                 '--val-batches',([string]$ValidationBatches))
if ($Device) { $trainCommon += @('--device',$Device) }

switch ($Action) {
  'setup' {
    & $Python -m pip install -r (Join-Path $PSScriptRoot 'requirements-zoom-aec.txt')
  }
  'verify' {
    Push-Location (Split-Path -Parent $PSScriptRoot)
    try { & $Python -m unittest train.tests.test_zoom_aec -v } finally { Pop-Location }
  }
  'smoke' {
    & $Python (Join-Path $PSScriptRoot 'train_zoom_aec_target.py') `
      --dataset $Dataset --output (Join-Path $RunDir 'smoke') --epochs 1 `
      --batch-size 1 --chunk-seconds 0.1 --max-train-items 2 --max-cv-items 2 --val-batches 1
  }
  'train' {
    & $Python (Join-Path $PSScriptRoot 'train_zoom_aec_target.py') @trainCommon
  }
  'resume' {
    & $Python (Join-Path $PSScriptRoot 'train_zoom_aec_target.py') @trainCommon --resume $Checkpoint
  }
  'export' {
    $onnx = Join-Path $RunDir 'zoom_aec_target.onnx'
    $mnn = Join-Path $RunDir 'zoom_aec_target.mnn'
    & $Python (Join-Path $PSScriptRoot 'export_zoom_aec.py') --checkpoint $Checkpoint --onnx $onnx
    if ($LASTEXITCODE -ne 0) { throw "ONNX export failed: $LASTEXITCODE" }
    if (-not (Test-Path -LiteralPath $MnnConvert)) { throw "MNNConvert not found: $MnnConvert" }
    & $MnnConvert -f ONNX --modelFile $onnx --MNNModel $mnn --bizCode ZOOM_AEC_TARGET
    if ($LASTEXITCODE -ne 0) { throw "MNN conversion failed: $LASTEXITCODE" }
    Get-FileHash -LiteralPath $Checkpoint,$onnx,$mnn -Algorithm SHA256 | Format-Table Path,Hash -AutoSize
  }
  'infer' {
    foreach ($required in @($Checkpoint,$Mic,$Far)) {
      if (-not (Test-Path -LiteralPath $required)) { throw "Input not found: $required" }
    }
    $args = @('--checkpoint',$Checkpoint,'--mic',$Mic,'--far',$Far,'--out',$OutputWav,
              '--far-delay-ms',([string]$FarDelayMs))
    if ($Target) { $args += @('--target',$Target) }
    & $Python (Join-Path $PSScriptRoot 'infer_zoom_aec.py') @args
  }
}
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
