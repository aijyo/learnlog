# Final AEC weight extraction: General + Music models.
#
# General: init sub_180111870, per-layer addrs 0x1836DD4C0..0x183719A60
# Music:   init sub_1801145E0 (5027 bytes), per-layer addrs 0x18371A660..0x18371E???
#
# GRU weights are loaded by sub_180117900 and NOT in the per-layer tables.
# The sub_180117900 weight loader returns a blob with ALL weights including GRU.

import os, struct
import numpy as np
import torch

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "models")
os.makedirs(OUT_DIR, exist_ok=True)

d = open(P, "rb").read()

pe_off = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe_off + 6)[0]
opt = struct.unpack_from("<H", d, pe_off + 20)[0]
base = struct.unpack_from("<Q", d, pe_off + 24 + 24)[0]
SECS = []
for i in range(nsec):
    o = pe_off + 24 + opt + 40 * i
    nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
    vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
    SECS.append((nm, base + va, max(vsz, rsz), raw))

def _off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return raw + (va - v)
    return None

def dump_i16(va, n):
    o = _off(va); return np.frombuffer(d[o:o+2*n], dtype=np.int16).copy() if o else None
def dump_f32(va, n):
    o = _off(va); return np.frombuffer(d[o:o+4*n], dtype=np.float32).copy() if o else None

# === GENERAL MODEL ===
# From sub_180111870 (init), 19 sub_180118290 call sites
GEN_LAYERS = [
    ("enc.enc_mic", 256,128,5, 0x1836DD4C0,0x1836DD740), ("enc.enc_1", 128,64,5,  0x1836DD780,0x1836DDC80),
    ("enc.enc_2",    64,32,5, 0x1836DDD10,0x1836DF110), ("enc.enc_3",  32,16,5,  0x1836DF1B0,0x1836E05B0),
    ("enc.enc_4",    16,8,5,  0x1836E0B00,0x1836E0D80), ("enc.enc_5",   8,8,1,   0x1836E0ED0,0x1836E2ED0),
    ("enc.enc_6",     8,4,5,  0x1836E2FF0,0x1836ECFF0),
    ("dec.dec_1a",    4,8,5,  0x183705710,0x183707710), ("dec.dec_1b",  8,8,1,   0x1837077E0,0x18370D7E0),
    ("dec.dec_2a",    8,16,5, 0x18370D900,0x18370F900), ("dec.dec_2b", 16,16,1,  0x18370F9D0,0x1837105D0),
    ("dec.dec_3a",   16,32,5, 0x1837108A0,0x1837120A0), ("dec.dec_3b", 32,32,1,  0x183712140,0x183715140),
    ("dec.dec_4a",   32,64,5, 0x183715210,0x183716210), ("dec.dec_4b", 64,64,1,  0x1837162B0,0x183716EB0),
    ("dec.dec_5a",   64,128,5,0x183717180,0x183717D80), ("dec.dec_5b",128,128,1, 0x183717E50,0x183719650),
    ("dec.dec_6a",  128,255,5,0x1837196B0,0x1837199B0), ("head",      255,256,1, 0x183719A60,0x183719A28),
]

# === MUSIC MODEL ===
# From sub_1801145E0 (5027 bytes), same structure, different addresses.
# Layer 0: v114[0]=qword_18371A660, v114[1]=qword_18371A8E0, desc at this+32
# Layer 1: v116[0]=qword_18371A920, v116[1]=qword_18371AE20
# Layer 2: v118[0]=qword_18371AEB0, v118[1]=qword_18371C2B0
# Layer 3: v120[0]=qword_18371C350, v120[1]=qword_18371D750
# ... etc
#
# The pseudocode shows at least the first 7 encoder layers, matching general.
# Let me extract the first 3 layers as a test, then extrapolate:
MUS_LAYERS = [
    ("enc.enc_mic", 256,128,5, 0x18371A660,0x18371A8E0),
    ("enc.enc_1",   128,64,5,  0x18371A920,0x18371AE20),
    ("enc.enc_2",    64,32,5,  0x18371AEB0,0x18371C2B0),
    ("enc.enc_3",    32,16,5,  0x18371C350,0x18371D750),
    ("enc.enc_4",    16,8,5,   0x18371DCA0,0x18371DF20),
    ("enc.enc_5",     8,8,1,   0x18371E070,0x183720070),
    ("enc.enc_6",     8,4,5,   0x183720190,0x18372A190),
]

# Compute offset from general to music
offset = 0x18371A660 - 0x1836DD4C0
print(f"Music table offset from general: {offset:#X}")

# Verify first music layer exists
i16 = dump_i16(0x1836DD4C0 + offset, 16)
if i16 is not None and abs(i16).max() > 500:
    print(f"  verify: enc_mic music at {0x1836DD4C0+offset:X}: {i16[:8]}  ✓")
else:
    print(f"  verify: enc_mic music at {0x1836DD4C0+offset:X}: NOT valid weight data")

# Build full music layer list from general + offset
MUS_LAYERS = [(name, in_ch, out_ch, k, gen_w + offset, gen_s + offset)
              for name, in_ch, out_ch, k, gen_w, gen_s in GEN_LAYERS]

# Verify first music layer exists at computed address
i16 = dump_i16(0x1836DD4C0 + offset, 16)
if i16 is not None and abs(i16).max() > 500:
    print(f"  verify: enc_mic music at {0x1836DD4C0+offset:X}: {i16[:8]}  ✓")
else:
    print(f"  verify: enc_mic music at {0x1836DD4C0+offset:X}: NOT valid weight data")

# Build full music layer list
MUS_LAYERS = []
for name, in_ch, out_ch, k, gen_w, gen_s in GEN_LAYERS:
    MUS_LAYERS.append((name, in_ch, out_ch, k, gen_w + offset, gen_s + offset))

def extract(layers, label):
    sd = {}
    for name, in_ch, out_ch, k, w_va, s_va in layers:
        w = dump_i16(w_va, out_ch * in_ch * k)
        if w is None: print(f"  ✗ {label}/{name}: NO DATA @{w_va:X}"); continue
        w_t = torch.from_numpy(w.astype(np.float32)).reshape(out_ch, in_ch, k)
        sd[f"{name}.weight"] = w_t
        s = dump_f32(s_va, 16)
        if s is not None and abs(s).max() > 0: sd[f"{name}.scale"] = torch.from_numpy(s[:8])
        nz = int((w != 0).sum()); pct = 100*nz/len(w)
        print(f"  ✓ {label}/{name:<14} {in_ch:>4}→{out_ch:<4} k={k} {len(w):>8} [{w.min():>6}..{w.max():>6}] {pct:.0f}%")
    return sd

print("=== General model ===")
gen = extract(GEN_LAYERS, "gen")
torch.save({"sd": gen, "variant": "general"}, os.path.join(OUT_DIR, "aec_general.pt"))

print("\n=== Music model ===")
mus = extract(MUS_LAYERS, "mus")
torch.save({"sd": mus, "variant": "music"}, os.path.join(OUT_DIR, "aec_music.pt"))

# Verify: general and music weights should differ (they share architecture but not values)
gen_w0 = gen["enc.enc_mic.weight"].numpy()
mus_w0 = mus["enc.enc_mic.weight"].numpy()
diff = np.abs(gen_w0.astype(float) - mus_w0.astype(float)).mean()
print(f"\nGeneral vs Music enc_mic weight diff: {diff:.2f}")
print("Same model? " + ("YES (unexpected)" if diff < 10 else "NO — two distinct weight sets ✓"))

print("\nDone. Files:")
for f in ["aec_general.pt", "aec_music.pt", "aec_general_conv.pt"]:
    p = os.path.join(OUT_DIR, f)
    if os.path.exists(p):
        sz = os.path.getsize(p)
        print(f"  {p}  ({sz/1024:.0f} KB)")
