"""Export a trained ZoomAecNet core to fixed-one-frame ONNX for MNN conversion."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch

from zoom_nets.zoom_aec import ZoomAecNet


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--onnx", required=True)
    ap.add_argument("--opset", type=int, default=16)
    args = ap.parse_args()
    ckpt = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    if ckpt.get("arch") != "ZoomAecNet":
        raise SystemExit(f"wrong checkpoint architecture: {ckpt.get('arch')!r}")
    model = ZoomAecNet().eval()
    model.load_state_dict(ckpt["state_dict"])
    mic = torch.zeros(1, 1, 2, 257)
    far = torch.zeros_like(mic)
    state = torch.zeros(1, 4, 64)
    output = Path(args.onnx); output.parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(model, (mic, far, state), str(output), opset_version=args.opset,
                      input_names=["mic_ri", "far_ri", "state_in"],
                      output_names=["complex_mask", "state_out"],
                      dynamic_axes=None, do_constant_folding=True)
    import onnx
    onnx.checker.check_model(onnx.load(str(output)))
    import onnxruntime as ort
    session = ort.InferenceSession(str(output), providers=["CPUExecutionProvider"])
    rng = np.random.default_rng(7)
    feed = {"mic_ri": rng.normal(size=(1, 1, 2, 257)).astype(np.float32),
            "far_ri": rng.normal(size=(1, 1, 2, 257)).astype(np.float32),
            "state_in": np.zeros((1, 4, 64), np.float32)}
    got = session.run(None, feed)
    with torch.no_grad():
        expected = model(*(torch.from_numpy(feed[n]) for n in ("mic_ri", "far_ri", "state_in")))
    worst = max(float(np.max(np.abs(a - b.numpy()))) for a, b in zip(got, expected))
    if worst > 1e-4:
        raise SystemExit(f"ONNX parity failed: max_abs={worst}")
    print(f"wrote {output}  max_abs={worst:.3e}")
    print("contract: mic_ri/far_ri/state_in -> complex_mask/state_out")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

