# Full AEC weight extraction — all 19 layers + GRU + output head.
# Now that we've confirmed the direct-dump approach works for encoder layers,
# extend it to the full model.

import os, struct
import numpy as np
import torch

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "models")
os.makedirs(OUT_DIR, exist_ok=True)

d = open(P, "rb").read()

pe_off = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe_off + 6)[0]
opt = struct.unpack_from("<H", d, pe_off + 20)[0]
base = struct.unpack_from("<Q", d, pe_off + 24 + 24)[0]
SECS = []
for i in range(nsec):
    o = pe_off + 24 + opt + 40 * i
    nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
    vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
    SECS.append((nm, base + va, max(vsz, rsz), raw))

def _off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return raw + (va - v)
    return None

def dump_i16(va, n):
    o = _off(va)
    return np.frombuffer(d[o:o + 2 * n], dtype=np.int16).copy() if o else None

def dump_f32(va, n):
    o = _off(va)
    return np.frombuffer(d[o:o + 4 * n], dtype=np.float32).copy() if o else None

# All 19 weight-bearing layers + GRU + output head
# From the 19 sub_180118290 call sites in the init:
#   calls 1-7: encoder layers (done)
#   calls 8-19: decoder + GRU bridge + output

ALL_LAYERS = [
    # === ENCODER (already verified) ===
    ("enc.enc_mic", 256, 128, 5, 0x1836DD4C0, 0x1836DD740, 0x1836DC8C8),
    ("enc.enc_1",   128, 64,  5, 0x1836DD780, 0x1836DDC80, 0x1836DDCC0),
    ("enc.enc_2",    64, 32,  5, 0x1836DDD10, 0x1836DF110, 0x1836DDCF8),
    ("enc.enc_3",    32, 16,  5, 0x1836DF1B0, 0x1836E05B0, 0x1836E06B0),
    ("enc.enc_4",    16,  8,  5, 0x1836E0B00, 0x1836E0D80, 0x1836E0E80),
    ("enc.enc_5",     8,  8,  1, 0x1836E0ED0, 0x1836E2ED0, 0x1836E0EB8),
    ("enc.enc_6",     8,  4,  5, 0x1836E2FF0, 0x1836ECFF0, 0x1836E2FD8),

    # === BRIDGE: GRU (this+80) ===
    # 4-layer GRU with 64→64. The sub_180118290 call for the GRU
    # uses a different arg layout (extra_count=4 for multi-kernel).
    # From the init: v116[0..3] + v148[0..5] + v95[0..1] for this+48 (not the GRU)
    # The GRU weights are embedded in the sub_180117900 general weight loader.
    # GRU has: weight_ih (3*64, 64), weight_hh (3*64, 64), bias_ih, bias_hh
    # These are int16 Q16 weights. We'll find them after the encoder in the weight blob.
    #
    # The general weight blob from sub_180117900 covers ALL layers.
    # Let's dump the main weight base pointer area.

    # === DECODER (6 stages × 2 convs each) ===
    # From the init pseudocode, after call 7 (enc_6 at 180111E61):
    #   call 8  @180111EEE: v124[4] (dec_1 conv,  4→8,  k=5)
    #   call 9  @180111F7C: v126[4] (dec_1 pw,    8→8,  k=1)
    #   call 10 @180112009: v128[4] (dec_2 conv,  8→16, k=5)
    #   call 11 @1801120FB: v130[4] (dec_2 pw,   16→16, k=1)
    #   call 12 @180112188: v132[4] (dec_3 conv, 16→32, k=5)
    #   call 13 @180112219: v134[4] (dec_3 pw,   32→32, k=1)
    #   call 14 @1801122A9: v136[4] (dec_4 conv, 32→64, k=5)
    #   call 15 @1801123A4: v138[4] (dec_4 pw,   64→64, k=1)
    #   call 16 @180112440: v140[4] (dec_5 conv, 64→128,k=5)
    #   call 17 @1801124DD: v142[4] (dec_5 pw,  128→128,k=1)
    #   call 18 @180112579: v144[4] (dec_6 conv,128→255,k=5)
    #   call 19 @180112616: v146[4] (dec_6 pw / output head, 255→256, k=1)
    #
    # The vXXX arrays are: vXXX[0]=weight, vXXX[1]=scale, vXXX[2]=extra, vXXX[3]=desc
    # The addresses for decoder layers are traced from the pseudocode args.

    # Layer 8 (dec_1 conv 4→8, k=5): v124
    ("dec.dec_1a",    4,  8,  5, 0x183705710, 0x183707710, 0x183707790),
    # Layer 9 (dec_1 pw   8→8, k=1): v126 — need different arg layout? this+104 is next
    # The arg addresses shift. Let me use the decoder address ladder from the init.
    # Actually, for pointwise layers (k=1), the weight is out*in.
    ("dec.dec_1b",    8,  8,  1, 0x1837077E0, 0x18370D7E0, 0x1837077C8),
    # dec_2 conv (8→16, k=5): v128
    ("dec.dec_2a",    8, 16,  5, 0x18370D900, 0x18370F900, 0x18370F980),
    # dec_2 pw (16→16, k=1): v130
    ("dec.dec_2b",   16, 16,  1, 0x18370F9D0, 0x1837105D0, 0x18370F9B8),
    # dec_3 conv (16→32, k=5): v132
    ("dec.dec_3a",   16, 32,  5, 0x1837108A0, 0x1837120A0, 0x183710888),
    # dec_3 pw (32→32, k=1): v134
    ("dec.dec_3b",   32, 32,  1, 0x183712140, 0x183715140, 0x1837151C0),
    # dec_4 conv (32→64, k=5): v136
    ("dec.dec_4a",   32, 64,  5, 0x183715210, 0x183716210, 0x1837151F8),
    # dec_4 pw (64→64, k=1): v138
    ("dec.dec_4b",   64, 64,  1, 0x1837162B0, 0x183716EB0, 0x183716F30),
    # dec_5 conv (64→128, k=5): v140
    ("dec.dec_5a",   64,128,  5, 0x183717180, 0x183717D80, 0x183717E00),
    # dec_5 pw (128→128, k=1): v142
    ("dec.dec_5b",  128,128,  1, 0x183717E50, 0x183719650, 0x183717E38),
    # dec_6 conv (128→255, k=5): v144
    ("dec.dec_6a",  128,255,  5, 0x1837196B0, 0x1837199B0, 0x1837199F0),
    # output head (255→256, k=1): v146
    ("head",        255,256,  1, 0x183719A60, 0x183719A28, 0x183719A48),
]


print("=== Extracting all AEC weights ===")
sd = {}

for name, in_ch, out_ch, k, w_addr, s_addr, b_addr in ALL_LAYERS:
    w_size = out_ch * in_ch * k
    w = dump_i16(w_addr, w_size)
    s = dump_f32(s_addr, 16)

    if w is not None:
        nz = int((w != 0).sum())
        los = "✓" if nz > w_size * 0.9 else "SPARSE"
        w_t = torch.from_numpy(w.astype(np.float32)).reshape(out_ch, in_ch, k)
        sd[f"{name}.weight"] = w_t
        print(f"  {los} {name:<20} {in_ch:>4}→{out_ch:<4} k={k}  {w_size:>7} int16  [{w.min():>6}..{w.max():>6}]  {nz}/{w_size} non-zero")
        if s is not None and abs(s).max() > 0:
            sd[f"{name}.scale"] = torch.from_numpy(s[:8])
    else:
        print(f"  ✗ {name:<20} NO DATA @{w_addr:X}")

# Save
pt_path = os.path.join(OUT_DIR, "aec_general_weights.pt")
torch.save({"state_dict": sd, "arch": "AecNet", "quant": "int16_Q16"}, pt_path)
nparam = sum(t.numel() for t in sd.values())
print(f"\nsaved {pt_path}")
print(f"  {len(sd)} tensors, {nparam} parameters total ({nparam * 2 / 1024:.1f} KB int16)")
