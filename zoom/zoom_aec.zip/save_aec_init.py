# Save AecNet architecture weights as a reference snapshot.
# These are RANDOM initialisation values, not Zoom's trained weights.
# Zoom's trained weights are int16 data in viperex.dll and are not extracted.
#
# Usage:
#   python save_aec_init.py
# Output: models/aec_init.pt, models/aec_init.onnx

import os, sys
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from zoom_nets.aec_pvad import AecNet

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "models")
os.makedirs(OUT_DIR, exist_ok=True)

torch.manual_seed(42)

model = AecNet(bins=256, variant="general")
model.eval()

nparam = model.param_count()
print("AecNet(bins=256): %d parameters (%.2f MB fp32)" % (nparam, nparam * 4 / 1e6))
print("provenance confidence: %s" % model.provenance()["confidence"])

# Sanity: forward pass
near = torch.rand(1, 4, 256) * 5000
far  = torch.rand(1, 4, 256) * 5000
with torch.no_grad():
    mask = model(near, far)
print("forward: mask %s [%.4f, %.4f]" % (tuple(mask.shape), mask.min().item(), mask.max().item()))

# Topology check
assert model.check_topology()
print("topology: OK (7 enc + 6×2 dec = 19 weight layers)")

# Save .pt
pt_path = os.path.join(OUT_DIR, "aec_init.pt")
torch.save({
    "state_dict": model.state_dict(),
    "arch": type(model).__name__,
    "bins": 256,
    "variant": "general",
    "params": nparam,
    "provenance": model.provenance(),
}, pt_path)
print("saved %s" % pt_path)

# Save .onnx (T=2 so GroupNorm doesn't fail on single-frame trace)
onnx_path = os.path.join(OUT_DIR, "aec_init.onnx")
near = torch.zeros(1, 2, 256)
far  = torch.zeros(1, 2, 256)
torch.onnx.export(
    model, (near, far), onnx_path,
    input_names=["mic_mag", "ref_mag"],
    output_names=["mask"],
    dynamo=False,
    dynamic_axes={"mic_mag": {1: "frames"}, "ref_mag": {1: "frames"},
                  "mask": {1: "frames"}},
    opset_version=17,
)
print("saved %s" % onnx_path)

# Also save "music" variant (same architecture, different seed for illustration)
torch.manual_seed(99)
model_m = AecNet(bins=256, variant="music")
model_m.eval()
pt_path_m = os.path.join(OUT_DIR, "aec_init_music.pt")
torch.save({
    "state_dict": model_m.state_dict(),
    "arch": type(model_m).__name__,
    "bins": 256,
    "variant": "music",
    "params": model_m.param_count(),
    "provenance": model_m.provenance(),
}, pt_path_m)
print("saved %s" % pt_path_m)
