"""Run a ZoomAecNet checkpoint on paired mic/far WAV files and optionally score target."""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import torch

from train_zoom_aec_target import si_sdr
from zoom_aec_data import (FFT_SIZE, SAMPLE_RATE, complex_magnitude, delay_signal,
                           istft_ri, read_pcm16_mono, stft_ri, write_pcm16_mono)
from zoom_nets.zoom_aec import ZoomAecNet, apply_complex_mask


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--mic", required=True)
    ap.add_argument("--far", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--target", default="")
    ap.add_argument("--far-delay-ms", type=float, default=0.0)
    ap.add_argument("--frames-per-call", type=int, default=100)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()
    device = torch.device(args.device)
    ckpt = torch.load(args.checkpoint, map_location=device, weights_only=False)
    model = ZoomAecNet().to(device).eval(); model.load_state_dict(ckpt["state_dict"])
    mic, far = read_pcm16_mono(Path(args.mic)), read_pcm16_mono(Path(args.far))
    length = min(mic.numel(), far.numel()); mic, far = mic[:length], far[:length]
    delay = int(round(args.far_delay_ms * SAMPLE_RATE / 1000.0))
    far = delay_signal(far, delay)
    scale = torch.stack((mic.square().mean(), far.square().mean())).max().sqrt().clamp_min(1e-4)
    window = torch.hamming_window(FFT_SIZE, periodic=True, device=device)
    mic_ri, far_ri = stft_ri((mic / scale).unsqueeze(0).to(device), window), \
                     stft_ri((far / scale).unsqueeze(0).to(device), window)
    outputs, state = [], None
    with torch.no_grad():
        for start in range(0, mic_ri.shape[1], args.frames_per_call):
            stop = start + args.frames_per_call
            mask, state = model(mic_ri[:, start:stop], far_ri[:, start:stop], state)
            outputs.append(apply_complex_mask(mic_ri[:, start:stop], mask))
    estimate = istft_ri(torch.cat(outputs, dim=1), window, length)[0].cpu() * scale
    write_pcm16_mono(Path(args.out), estimate)
    print(f"wrote {args.out}; samples={length}; delay={args.far_delay_ms:.3f} ms")
    if args.target:
        target = read_pcm16_mono(Path(args.target))[:length]
        before = (mic - target).square().mean()
        after = (estimate - target).square().mean()
        erle = 10.0 * torch.log10((before + 1e-8) / (after + 1e-8))
        print(f"SI-SDR={float(si_sdr(estimate[None], target[None]).mean()):.3f} dB")
        print(f"residual ERLE={float(erle):.3f} dB (mic-target vs output-target)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

