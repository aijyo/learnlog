import unittest

import torch

from train.zoom_nets.snac import (
    CosineSimCodebook,
    MultiResolutionRVQ,
    PitchDNN,
    Snake1dC,
    Snac,
    SnacDecoder,
    SnacDecoderLayer,
    SnacEncoder,
    SnacNoiseBlock,
    SnacReconstruction,
    TemporalConv1dC,
    TemporalConvTranspose1dC,
    VectorQuantize,
    pitch_index_to_period,
    pitch_period_to_index,
)


class PitchDNNTests(unittest.TestCase):
    def test_layer_shapes_match_recovered_descriptor_dimensions(self):
        model = PitchDNN()

        self.assertEqual(model.if_up1.weight.shape, (64, 88))
        self.assertEqual(model.if_up2.weight.shape, (64, 64))
        self.assertEqual(model.down.weight.shape, (64, 288))
        self.assertEqual(model.final_up.weight.shape, (192, 64))
        self.assertEqual(model.conv2d_1.weight.shape, (4, 1, 3, 3))
        self.assertEqual(model.conv2d_2.weight.shape, (1, 4, 3, 3))

    def test_preserves_batch_and_time_axes_and_returns_valid_periods(self):
        model = PitchDNN().eval()
        xcorr = torch.randn(2, 5, 224)
        if_features = torch.randn(2, 5, 88)

        with torch.no_grad():
            period = model(xcorr, if_features)

        self.assertEqual(period.shape, (2, 5))
        self.assertTrue(torch.all(period >= 32))
        self.assertTrue(torch.all(period <= 255))

    def test_period_and_embedding_index_boundary_mapping(self):
        periods = torch.tensor([0, 32, 96, 255, 300])
        indices = pitch_period_to_index(periods)

        self.assertTrue(torch.equal(indices, torch.tensor([0, 0, 64, 223, 223])))
        self.assertTrue(torch.equal(
            pitch_index_to_period(torch.tensor([-5, 0, 64, 223, 300])),
            torch.tensor([32, 32, 96, 255, 255]),
        ))


class SnacEncoderTests(unittest.TestCase):
    @staticmethod
    def _set_identity_vq(vq):
        with torch.no_grad():
            vq.project_in.weight.zero_()
            vq.project_out.weight.zero_()
            vq.project_in.bias.zero_()
            vq.project_out.bias.zero_()
            for i in range(2):
                vq.project_in.weight[i, i, 0] = 1.0
                vq.project_out.weight[i, i, 0] = 1.0
            vq.codebook.embed.copy_(torch.eye(2))

    def test_codebook_normalizes_input_and_uses_raw_embedding_dot_product(self):
        codebook = CosineSimCodebook(2, 2)
        with torch.no_grad():
            codebook.embed.copy_(torch.tensor([[0.5, 0.0], [2.0, 0.0]]))

        quantized, indices = codebook(torch.tensor([[[3.0], [0.0]]]))

        self.assertTrue(torch.equal(indices, torch.tensor([1])))
        self.assertTrue(torch.equal(quantized, torch.tensor([[[2.0], [0.0]]])))

    def test_residual_quantizers_and_from_codes_are_inverse_at_code_level(self):
        rvq = MultiResolutionRVQ(dim=2, code_dim=2, size=2, n_stages=2)
        for stage in rvq.stages:
            self._set_identity_vq(stage)
        x = torch.tensor([[[1.0], [1.0]]])

        quantized, codes, loss = rvq(x, n_active=2)
        decoded = rvq.from_codes(codes)

        self.assertTrue(torch.equal(codes, torch.tensor([[0, 1]])))
        self.assertTrue(torch.allclose(quantized, x))
        self.assertTrue(torch.allclose(decoded, quantized))
        self.assertEqual(loss.ndim, 0)

    def test_vector_quantize_parameter_shapes_match_zoom_constructor(self):
        vq = VectorQuantize(dim=512, code_dim=8, size=1024)

        self.assertEqual(tuple(vq.project_in.weight.shape), (8, 512, 1))
        self.assertEqual(tuple(vq.project_out.weight.shape), (512, 8, 1))
        self.assertEqual(tuple(vq.codebook.embed.shape), (1024, 8))

    def test_active_stage_bounds_and_negative_code_termination(self):
        rvq = MultiResolutionRVQ(dim=2, code_dim=2, size=2, n_stages=2)
        for stage in rvq.stages:
            self._set_identity_vq(stage)
        x = torch.tensor([[[1.0], [1.0]]])

        _, all_codes, _ = rvq(x, n_active=0)
        _, clamped_codes, _ = rvq(x, n_active=99)
        decoded = rvq.from_codes(torch.tensor([[0, -1]]))
        first_stage = rvq.stages[0].from_codes(torch.tensor([0]))

        self.assertEqual(all_codes.shape, (1, 2))
        self.assertEqual(clamped_codes.shape, (1, 2))
        self.assertTrue(torch.allclose(decoded, first_stage))

    def test_clean_room_training_loss_reaches_encoder_and_codebook(self):
        rvq = MultiResolutionRVQ(dim=4, code_dim=2, size=8, n_stages=2)
        x = torch.randn(2, 4, 1, requires_grad=True)

        quantized, _, loss = rvq(x, n_active=2)
        (quantized.square().mean() + loss).backward()

        self.assertIsNotNone(x.grad)
        self.assertIsNotNone(rvq.stages[0].project_in.weight.grad)
        self.assertIsNotNone(rvq.stages[0].project_out.weight.grad)
        self.assertIsNotNone(rvq.stages[0].codebook.embed.grad)

    def test_snake1dc_matches_body_verified_alpha_beta_gamma_formula(self):
        snake = Snake1dC(2)
        with torch.no_grad():
            snake.alpha.copy_(torch.tensor([2.0, 0.5]))
            snake.beta.copy_(torch.tensor([3.0, 4.0]))
            snake.gamma.copy_(torch.tensor([0.25, -0.5]))
        x = torch.tensor([[[0.1, -0.2], [0.3, -0.4]]])

        y = snake(x)
        alpha = snake.alpha.view(1, -1, 1)
        beta = snake.beta.view(1, -1, 1)
        gamma = snake.gamma.view(1, -1, 1)
        expected = x + beta / (alpha + 1.0e-9) * torch.sin(alpha * x).square() - gamma

        self.assertTrue(torch.allclose(y, expected))

    def test_body_verified_convolutional_object_hierarchy(self):
        model = SnacEncoder()

        self.assertEqual(tuple(model.input_layer.weight.shape), (32, 1, 7))
        self.assertEqual(model.input_layer.stride, (1,))
        self.assertEqual(
            [(layer.chan_in, layer.chan_out, layer.stride)
             for layer in model.encoder_layers],
            [(32, 64, 3), (64, 128, 4), (128, 256, 5), (256, 512, 8)],
        )
        for layer in model.encoder_layers:
            self.assertEqual([unit.dilation for unit in layer.residual_units], [1, 3, 9])
            for unit in layer.residual_units:
                self.assertEqual(tuple(unit.conv1.weight.shape), (layer.chan_in, 1, 7))
                self.assertEqual(tuple(unit.conv2.weight.shape), (layer.chan_in, layer.chan_in, 1))
            self.assertEqual(
                tuple(layer.downsample.weight.shape),
                (layer.chan_out, layer.chan_in, 2 * layer.stride),
            )

        self.assertEqual(tuple(model.output_layer.weight.shape), (512, 1, 3))
        self.assertTrue(torch.equal(model.encoder_layers[0].snake.gamma,
                                    torch.zeros(32)))
        self.assertEqual(model.rvq_config, {
            "max_quantizers": 12,
            "channels": 512,
            "codebook_size": 1024,
            "code_dim": 8,
        })
        self.assertEqual(len(model.rvq.stages), 12)

    def test_offline_encoder_feature_path_has_zoom_total_stride(self):
        model = SnacEncoder().eval()
        with torch.no_grad():
            features = model.encode_features(torch.randn(2, 1, 480))

        self.assertEqual(features.shape, (2, 512, 1))

    def test_encoder_explicit_state_matches_two_frame_whole_stream(self):
        model = SnacEncoder().eval()
        pcm = torch.randn(1, 1, 960)
        with torch.no_grad():
            whole = model.encode_features(pcm)
            first, state = model.encode_features(
                pcm[..., :480], return_state=True
            )
            second, state = model.encode_features(
                pcm[..., 480:], state=state, return_state=True
            )

        self.assertTrue(
            torch.allclose(torch.cat([first, second], dim=-1), whole, atol=1e-6)
        )
        self.assertEqual(len(state["encoder_layers"]), 4)

    def test_encoder_forward_returns_zoom_default_two_codes(self):
        model = SnacEncoder()
        calls = []
        hooks = [stage.register_forward_hook(
            lambda _module, _args, _output, stage=i: calls.append(stage)
        ) for i, stage in enumerate(model.rvq.stages)]

        try:
            codes, quantized, loss = model(
                torch.randn(1, 1, 480), return_details=True
            )
        finally:
            for hook in hooks:
                hook.remove()
        self.assertEqual(codes.shape, (1, 2))
        self.assertEqual(quantized.shape, (1, 512, 1))
        self.assertEqual(loss.ndim, 0)
        self.assertEqual(calls, list(range(12)))

    def test_snac_wrapper_reuses_the_encoder_rvq(self):
        codec = Snac(n_stages=2)

        codes = codec(torch.randn(1, 1, 480))
        decoded = codec.from_codes(codes)

        self.assertIs(codec.rvq, codec.encoder.rvq)
        self.assertIs(codec.rvq, codec.decoder.rvq)
        self.assertEqual(codes.shape, (1, 2))
        self.assertEqual(decoded.shape, (1, 1, 480))
        self.assertEqual(codec.bits_per_frame(), 20.0)

    def test_full_codec_roundtrip_wires_two_wire_codes_into_twelve_slots(self):
        codec = Snac(n_stages=2).eval()
        with torch.no_grad():
            codes, reconstructed = codec.roundtrip(torch.randn(2, 1, 480))

        self.assertEqual(codes.shape, (2, 2))
        self.assertEqual(reconstructed.shape, (2, 1, 480))
        padded = codec.pad_codes(codes)
        self.assertTrue(torch.equal(padded[:, :2], codes))
        self.assertTrue(torch.equal(padded[:, 2:], torch.full((2, 10), -1)))

    def test_reconstruction_rejects_non_zoom_codebook_size(self):
        with self.assertRaisesRegex(ValueError, "fixed at 1024"):
            SnacReconstruction.from_recovered(codebook=512)

    def test_body_verified_decoder_object_hierarchy(self):
        model = SnacDecoder()

        self.assertEqual(len(model.rvq.stages), 12)
        self.assertEqual(tuple(model.input_depthwise.weight.shape), (512, 1, 7))
        self.assertEqual(tuple(model.input_pointwise.weight.shape), (512, 512, 1))
        self.assertEqual(
            [(layer.chan_in, layer.chan_out, layer.stride)
             for layer in model.decoder_layers],
            [(512, 256, 8), (256, 128, 5), (128, 64, 4), (64, 32, 3)],
        )
        for layer in model.decoder_layers:
            self.assertIsInstance(layer, SnacDecoderLayer)
            self.assertIsInstance(layer.upsample, TemporalConvTranspose1dC)
            self.assertEqual(
                tuple(layer.upsample.weight.shape),
                (layer.chan_in, layer.chan_out, 2 * layer.stride),
            )
            self.assertIsNotNone(layer.noise)
            self.assertEqual(
                [unit.dilation for unit in layer.residual_units], [1, 3, 9]
            )
        self.assertEqual(tuple(model.output_layer.weight.shape), (1, 32, 7))

    def test_decoder_consumes_twelve_slots_and_outputs_one_zoom_frame(self):
        model = SnacDecoder().eval()
        codes = torch.full((1, 12), -1, dtype=torch.long)
        codes[:, :2] = torch.tensor([[0, 1]])

        with torch.no_grad():
            pcm = model(codes)

        self.assertEqual(pcm.shape, (1, 1, 480))
        self.assertTrue(torch.isfinite(pcm).all())
        with self.assertRaisesRegex(ValueError, "12 code slots"):
            model(codes[:, :2])

    def test_decoder_explicit_state_matches_two_frame_whole_stream(self):
        model = SnacDecoder(use_noise=False).eval()
        codes_a = torch.full((1, 12), -1, dtype=torch.long)
        codes_b = torch.full((1, 12), -1, dtype=torch.long)
        codes_a[:, :2] = torch.tensor([[0, 1]])
        codes_b[:, :2] = torch.tensor([[2, 3]])
        with torch.no_grad():
            latent = torch.cat([
                model.rvq.from_codes(codes_a),
                model.rvq.from_codes(codes_b),
            ], dim=-1)
            whole = model.decode_latent(latent)
            first, state = model.decode_latent(
                latent[..., :1], return_state=True
            )
            second, state = model.decode_latent(
                latent[..., 1:], state=state, return_state=True
            )

        self.assertTrue(
            torch.allclose(torch.cat([first, second], dim=-1), whole, atol=1e-6)
        )
        self.assertEqual(len(state["decoder_layers"]), 4)

    def test_noise_block_matches_body_verified_multiply_add(self):
        block = SnacNoiseBlock(2)
        with torch.no_grad():
            block.projection.weight.copy_(torch.eye(2).unsqueeze(-1))
            block.projection.bias.zero_()
        x = torch.tensor([[[1.0, 2.0], [3.0, 4.0]]])
        noise = torch.tensor([[[0.5, -0.25]]])

        actual = block(x, noise=noise)

        self.assertTrue(torch.allclose(actual, x + x * noise))

    def test_temporal_convolution_explicit_history_matches_whole_stream(self):
        conv = TemporalConv1dC(2, 3, 3, dilation=2)
        x = torch.randn(1, 2, 10)

        whole = conv(x)
        first, history = conv(x[..., :4], return_history=True)
        second, history = conv(
            x[..., 4:], history=history, return_history=True
        )

        self.assertTrue(torch.allclose(torch.cat([first, second], dim=-1), whole))
        self.assertEqual(history.shape, (1, 2, conv.total_padding))

    def test_transposed_convolution_explicit_history_matches_whole_stream(self):
        conv = TemporalConvTranspose1dC(2, 3, 3)
        x = torch.randn(1, 2, 3)

        whole = conv(x)
        first, history = conv(x[..., :1], return_history=True)
        second, history = conv(
            x[..., 1:], history=history, return_history=True
        )

        self.assertTrue(torch.allclose(torch.cat([first, second], dim=-1), whole))
        self.assertEqual(history.shape, (1, 2, 1))


if __name__ == "__main__":
    unittest.main()
