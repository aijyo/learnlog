import pathlib
import sys
import unittest

import torch

TRAIN = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TRAIN))

from zoom_nets.zoom_aec import ZoomAecNet, apply_complex_mask


class ZoomAecTests(unittest.TestCase):
    def test_descriptor_shapes_and_output(self):
        model = ZoomAecNet().eval()
        self.assertTrue(model.check_contract())
        self.assertEqual(model.frequency_ladder, (256, 128, 64, 32, 16, 8, 8, 4))
        self.assertEqual(model.decoder_frequency, (4, 8, 16, 32, 64, 128, 255, 257))

    def test_streaming_state_matches_whole_sequence(self):
        torch.manual_seed(7)
        model = ZoomAecNet().eval()
        mic = torch.randn(1, 4, 2, 257)
        far = torch.randn(1, 4, 2, 257)
        with torch.no_grad():
            whole, whole_state = model(mic, far)
            state = None
            pieces = []
            for t in range(4):
                y, state = model(mic[:, t:t + 1], far[:, t:t + 1], state)
                pieces.append(y)
            streamed = torch.cat(pieces, dim=1)
        torch.testing.assert_close(streamed, whole, rtol=1e-5, atol=1e-6)
        torch.testing.assert_close(state, whole_state, rtol=1e-5, atol=1e-6)

    def test_identity_complex_mask(self):
        x = torch.randn(2, 3, 2, 257)
        mask = torch.zeros_like(x)
        mask[:, :, 0] = 1.0
        torch.testing.assert_close(apply_complex_mask(x, mask), x)


if __name__ == "__main__":
    unittest.main()
