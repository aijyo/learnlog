// audio_frame.hpp — one buffer of captured audio + its format. Parallel to video_frame.hpp.
// WASAPI hands us interleaved PCM at the device's mix format (usually 32-bit float, 48 kHz, stereo);
// we keep the raw bytes plus enough format info for the encoder/preprocess stages downstream.
#pragma once
#include <cstdint>
#include <vector>

namespace avp {

// The device mix format is almost always IEEE-float; capture PCM (16-bit) shows up after conversion.
struct AudioFormat {
  int  sample_rate = 48000;   // Hz
  int  channels    = 2;
  int  bits        = 32;      // bits per sample
  bool is_float    = true;    // true = IEEE float32, false = signed integer PCM
  int  frame_bytes() const { return channels * (bits / 8); }   // bytes for one sample across all channels
};

// A chunk of interleaved samples (channel0, channel1, channel0, channel1, ...).
struct AudioFrame {
  AudioFormat          format;
  int64_t              timestamp_us = 0;    // capture time of the first sample (QPC-derived)
  int                  frames = 0;          // sample-frames in this chunk (data.size()/format.frame_bytes())
  std::vector<uint8_t> data;                // raw interleaved PCM bytes
  bool valid() const { return frames > 0 && !data.empty(); }
  double seconds() const { return format.sample_rate ? double(frames) / format.sample_rate : 0.0; }
};

}  // namespace avp
