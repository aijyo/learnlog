// vp9_svc.hpp — TRUE spatial-SVC VP9 encoder (libvpx low-level SVC API) + superframe layer tools, shared
// by svc_test and the mini-SFU. One encode produces a VP9 SUPERFRAME per input frame = [spatial-layer-0
// (base)][spatial-layer-1 (enh)]...[superframe-index]. An SFU/receiver keeps only the layers it needs by
// forwarding a prefix of the sub-frames — no re-encode (Zoom §3.2). libvpx is used directly because
// avcodec can't drive SVC. Link vcpkg vpx.lib (/MT).
#pragma once
#include "preprocess/video_convert.hpp"   // avp::I420Image
#include <cstdint>
#include <vector>
extern "C" {
#include "vpx/vpx_encoder.h"
#include "vpx/vp8cx.h"
}

namespace avp {

// parse a VP9 superframe index -> byte size of each contained sub-frame (base first). false if not one.
inline bool vp9_split_superframe(const uint8_t* d, size_t n, std::vector<size_t>& sizes) {
  sizes.clear();
  if (n < 2) return false;
  uint8_t m = d[n - 1];
  if ((m & 0xe0) != 0xc0) return false;
  int per = ((m >> 3) & 3) + 1, frames = (m & 7) + 1;
  size_t idx = 2 + (size_t)frames * per;
  if (n < idx || d[n - idx] != m) return false;
  const uint8_t* p = d + n - idx + 1;
  for (int i = 0; i < frames; ++i) { size_t s = 0; for (int b = 0; b < per; ++b) s |= (size_t)p[b] << (8 * b); p += per; sizes.push_back(s); }
  return true;
}

// prune a superframe to the first `keep` spatial layers, returning a decodable byte blob:
//   keep >= total -> the whole superframe; keep == 1 -> just the base sub-frame; otherwise the first
//   `keep` sub-frames wrapped in a fresh 1-byte-size superframe index.
inline std::vector<uint8_t> vp9_prune(const std::vector<uint8_t>& sf, int keep) {
  std::vector<size_t> sz;
  if (keep <= 0 || !vp9_split_superframe(sf.data(), sf.size(), sz) || keep >= (int)sz.size()) return sf;
  size_t bytes = 0; for (int i = 0; i < keep; ++i) bytes += sz[i];
  std::vector<uint8_t> out(sf.begin(), sf.begin() + bytes);
  if (keep == 1) return out;                                  // single frame: no index needed
  uint8_t marker = 0xc0 | ((4 - 1) << 3) | (keep - 1);        // 4 bytes/size, keep frames
  out.push_back(marker);
  for (int i = 0; i < keep; ++i) { uint32_t s = (uint32_t)sz[i]; for (int b = 0; b < 4; ++b) out.push_back((s >> (8 * b)) & 0xFF); }
  out.push_back(marker);
  return out;
}

class Vp9SvcEncoder {
public:
  // ss spatial layers (2 supported here: base = 1/2 scale, enh = full). kbps = cumulative per layer.
  bool open(int w, int h, int ss, int base_kbps, int full_kbps, int cpu_used = 7) {
    w_ = w; h_ = h; ss_ = ss;
    if (vpx_codec_enc_config_default(vpx_codec_vp9_cx(), &cfg_, 0)) return false;
    cfg_.g_w = w; cfg_.g_h = h; cfg_.g_timebase.num = 1; cfg_.g_timebase.den = 30;
    cfg_.rc_target_bitrate = full_kbps; cfg_.rc_end_usage = VPX_CBR; cfg_.g_lag_in_frames = 0; cfg_.g_error_resilient = 1;
    cfg_.kf_mode = VPX_KF_AUTO; cfg_.kf_min_dist = 0; cfg_.kf_max_dist = 30;   // periodic keyframes so a layer/speaker switch resyncs (Zoom SubscribeChange -> min keyframe)
    cfg_.ss_number_layers = ss; cfg_.ts_number_layers = 1; cfg_.ts_rate_decimator[0] = 1;
    cfg_.layer_target_bitrate[0] = base_kbps; cfg_.layer_target_bitrate[1] = full_kbps;
    if (vpx_codec_enc_init(&enc_, vpx_codec_vp9_cx(), &cfg_, 0)) return false;
    vpx_codec_control(&enc_, VP9E_SET_SVC, 1);
    vpx_svc_extra_cfg_t svc{};
    svc.scaling_factor_num[0] = 1; svc.scaling_factor_den[0] = 2;   // base 1/2
    svc.scaling_factor_num[1] = 1; svc.scaling_factor_den[1] = 1;   // enh full
    for (int i = 0; i < ss; ++i) { svc.max_quantizers[i] = 56; svc.min_quantizers[i] = 4; svc.speed_per_layer[i] = cpu_used; }
    vpx_codec_control(&enc_, VP9E_SET_SVC_PARAMETERS, &svc);
    vpx_codec_control(&enc_, VP8E_SET_CPUUSED, cpu_used);
    vpx_img_alloc(&img_, VPX_IMG_FMT_I420, w, h, 1);
    ok_ = true; return true;
  }
  int spatial_layers() const { return ss_; }
  // encode one full-res I420 frame -> the superframe bytes (all spatial layers)
  bool encode(const I420Image& in, int64_t pts, std::vector<uint8_t>& out) {
    out.clear(); if (!ok_) return false;
    for (int y = 0; y < h_; ++y) { int sy = y < in.h ? y : in.h - 1;
      uint8_t* d = img_.planes[0] + (size_t)y * img_.stride[0];
      for (int x = 0; x < w_; ++x) { int sx = x < in.w ? x : in.w - 1; d[x] = in.y[(size_t)sy * in.w + sx]; } }
    int cw = w_ / 2, chh = h_ / 2;
    for (int y = 0; y < chh; ++y) { int sy = y < in.ch() ? y : in.ch() - 1;
      uint8_t* du = img_.planes[1] + (size_t)y * img_.stride[1]; uint8_t* dv = img_.planes[2] + (size_t)y * img_.stride[2];
      for (int x = 0; x < cw; ++x) { int sx = x < in.cw() ? x : in.cw() - 1; du[x] = in.u[(size_t)sy * in.cw() + sx]; dv[x] = in.v[(size_t)sy * in.cw() + sx]; } }
    if (vpx_codec_encode(&enc_, &img_, pts, 1, 0, VPX_DL_REALTIME)) return false;
    vpx_codec_iter_t it = nullptr; const vpx_codec_cx_pkt_t* pkt;
    while ((pkt = vpx_codec_get_cx_data(&enc_, &it)))
      if (pkt->kind == VPX_CODEC_CX_FRAME_PKT) { const uint8_t* b = (const uint8_t*)pkt->data.frame.buf; out.insert(out.end(), b, b + pkt->data.frame.sz); }
    return !out.empty();
  }
  ~Vp9SvcEncoder() { if (ok_) { vpx_img_free(&img_); vpx_codec_destroy(&enc_); } }
private:
  vpx_codec_ctx_t enc_{}; vpx_codec_enc_cfg_t cfg_{}; vpx_image_t img_{};
  int w_ = 0, h_ = 0, ss_ = 2; bool ok_ = false;
};

}  // namespace avp
