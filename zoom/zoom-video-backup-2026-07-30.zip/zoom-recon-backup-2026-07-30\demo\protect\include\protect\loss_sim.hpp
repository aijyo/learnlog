// loss_sim.hpp — a deterministic lossy channel to exercise FEC/NACK/PLC. Two models:
//   * random (Bernoulli p): independent per-packet loss — FEC's best case.
//   * Gilbert-Elliott: a 2-state (good/bad) burst model — bursts wipe whole FEC groups, which is the
//     case §4 says defeats FEC and needs NACK. Seeded LCG so runs are reproducible.
#pragma once
#include <cstdint>

namespace avp {

class RandomLoss {
public:
  RandomLoss(double p, uint32_t seed = 0x1234) : p_(p), s_(seed ? seed : 1) {}
  bool drop() { return next() < p_; }
private:
  double next() { s_ = s_ * 1664525u + 1013904223u; return (s_ >> 8) / (double)(1u << 24); }
  double p_; uint32_t s_;
};

// Gilbert-Elliott burst-loss model.
class BurstLoss {
public:
  BurstLoss(double p_good_to_bad = 0.02, double p_bad_to_good = 0.5,
            double loss_good = 0.0, double loss_bad = 0.6, uint32_t seed = 0xBEEF)
      : pgb_(p_good_to_bad), pbg_(p_bad_to_good), lg_(loss_good), lb_(loss_bad), s_(seed ? seed : 1) {}
  bool drop() {
    double lr = bad_ ? lb_ : lg_;
    bool d = next() < lr;
    if (bad_) { if (next() < pbg_) bad_ = false; }        // maybe recover to good
    else      { if (next() < pgb_) bad_ = true;  }        // maybe degrade to bad
    return d;
  }
  bool in_bad() const { return bad_; }
private:
  double next() { s_ = s_ * 1664525u + 1013904223u; return (s_ >> 8) / (double)(1u << 24); }
  double pgb_, pbg_, lg_, lb_; bool bad_ = false; uint32_t s_;
};

}  // namespace avp
