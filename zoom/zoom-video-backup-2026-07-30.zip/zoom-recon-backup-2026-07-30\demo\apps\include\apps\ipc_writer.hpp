// ipc_writer.hpp — tiny helper to publish a POD struct into a named shared-memory mapping the WPF
// monitor reads. Create once, write fields, it stays live until the process exits.
#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <cstring>

namespace avp { namespace ipc {

template <typename T>
class ShmPublisher {
public:
  bool open(const wchar_t* name) {
    map_ = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(T), name);
    if (!map_) return false;
    view_ = (T*)MapViewOfFile(map_, FILE_MAP_WRITE, 0, 0, sizeof(T));
    if (view_) std::memset(view_, 0, sizeof(T));
    return view_ != nullptr;
  }
  T* operator->() { return view_; }
  T* get() { return view_; }
  ~ShmPublisher() { if (view_) UnmapViewOfFile(view_); if (map_) CloseHandle(map_); }
private:
  HANDLE map_ = nullptr; T* view_ = nullptr;
};

// Read-only view of a mapping another process created (e.g. the monitor's control block).
template <typename T>
class ShmReader {
public:
  bool open(const wchar_t* name) {
    map_ = OpenFileMappingW(FILE_MAP_READ, FALSE, name);
    if (!map_) return false;
    view_ = (const T*)MapViewOfFile(map_, FILE_MAP_READ, 0, 0, sizeof(T));
    return view_ != nullptr;
  }
  bool valid() const { return view_ != nullptr; }
  const T* operator->() const { return view_; }
  const T* get() const { return view_; }
  ~ShmReader() { if (view_) UnmapViewOfFile((void*)view_); if (map_) CloseHandle(map_); }
private:
  HANDLE map_ = nullptr; const T* view_ = nullptr;
};

}}  // namespace avp::ipc
