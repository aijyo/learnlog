import idc, ida_hexrays, ida_funcs, idautils
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
def decomp(ea, label):
    f = ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x (%s)" % (ea, label)); return
    try:
        L.append("\n// ===== %s  %s  (0x%x) =====" % (label, idc.get_func_name(f.start_ea), f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e:
        L.append("// FAILED 0x%x: %s" % (ea, e))
def dumpvt(vt, label, ndecomp=3):
    slots = []; ea = vt
    for i in range(12):
        p = idc.get_qword(ea)
        if not ida_funcs.get_func(p): break
        slots.append(p); ea += 8
    L.append("\n// ==== VTABLE %s 0x%x: %d slots ====" % (label, vt, len(slots)))
    for i, s in enumerate(slots):
        L.append("//  [%d] 0x%x  %s" % (i, s, idc.get_func_name(s)))
    seen=set()
    for i,s in enumerate(slots[:ndecomp+2]):
        if s in seen: continue
        seen.add(s); decomp(s, "%s.slot%d"%(label,i))
dumpvt(0x180504f28, "zltCCLAHE", 4)          # verify clip constant
dumpvt(0x180502728, "zltCRoiAdaptQuant", 3)  # perceptual QP per-region
dumpvt(0x180502e18, "zltCBuQpCalc", 3)       # per-unit QP calc (connects T1)
open(out, "w", encoding="utf-8", errors="replace").write("\n".join(L))
idc.qexit(0)
