// opus_codec.hpp — real Opus via libopus DIRECTLY (not avcodec), so we can use in-band FEC (LBRR) the
// way Zoom's viper does ("maxlbrr"): the encoder sets OPUS_SET_INBAND_FEC + OPUS_SET_PACKET_LOSS_PERC, so
// each packet carries a low-bitrate re-encode of the PREVIOUS frame; on loss the decoder recovers that
// lost frame from the NEXT packet via opus_decode(..., decode_fec=1) — the actual LBRR reconstruction
// (avcodec can't expose decode_fec, which is why we link libopus). Classic PLC (NULL packet) is the
// fallback when even the next packet is gone. Neural DRED/deep-PLC (opus 1.5) is left off = ⛔W boundary.
#pragma once
#ifdef AVP_WITH_OPUS
#include "opus.h"
#include <cstdint>
#include <vector>

namespace avp {

class OpusAudioEnc {
public:
  bool open(int sample_rate = 48000, int channels = 1, int bitrate = 24000,
            bool inband_fec = false, int expected_loss_pct = 0, bool dtx = false) {
    int err = 0; enc_ = opus_encoder_create(sample_rate, channels, OPUS_APPLICATION_VOIP, &err);
    if (err != OPUS_OK || !enc_) return false;
    sr_ = sample_rate; ch_ = channels; fs_ = sample_rate / 50;   // 20 ms
    opus_encoder_ctl(enc_, OPUS_SET_BITRATE(bitrate));
    opus_encoder_ctl(enc_, OPUS_SET_INBAND_FEC(inband_fec ? 1 : 0));      // LBRR on/off
    opus_encoder_ctl(enc_, OPUS_SET_PACKET_LOSS_PERC(expected_loss_pct)); // how much LBRR redundancy
    // DTX (discontinuous transmission) — Zoom pairs its viper VAD with Opus DTX: on detected silence the
    // encoder stops emitting speech frames and sends only a periodic tiny SID/CNG update (~1-2 B every
    // ~400 ms). The decoder fills the gap with comfort noise. Needs VBR (VOIP default) to actually gate.
    if (dtx) opus_encoder_ctl(enc_, OPUS_SET_DTX(1));
    return true;
  }
  int frame_size() const { return fs_; }
  int channels()   const { return ch_; }
  // Returns bytes written; 1..2 bytes is a DTX/SID frame ("nothing new to transmit this 20 ms" — the
  // caller may drop it and let the far decoder's PLC/CNG cover the gap). The bool is just success.
  bool encode(const float* pcm, std::vector<uint8_t>& out) {
    out.resize(4000);
    int n = opus_encode_float(enc_, pcm, fs_, out.data(), (int)out.size());
    if (n < 0) { out.clear(); return false; }
    out.resize(n); return true;
  }
  ~OpusAudioEnc() { if (enc_) opus_encoder_destroy(enc_); }
private:
  OpusEncoder* enc_ = nullptr; int sr_ = 48000, ch_ = 1, fs_ = 960;
};

class OpusAudioDec {
public:
  bool open(int sample_rate = 48000, int channels = 1) {
    int err = 0; dec_ = opus_decoder_create(sample_rate, channels, &err);
    sr_ = sample_rate; ch_ = channels; fs_ = sample_rate / 50;
    return err == OPUS_OK && dec_;
  }
  int frame_size() const { return fs_; }
  // normal in-order decode
  int decode(const uint8_t* data, int n, std::vector<float>& out) {
    out.resize((size_t)fs_ * ch_);
    int r = opus_decode_float(dec_, data, n, out.data(), fs_, 0);
    if (r < 0) { out.clear(); return 0; } out.resize((size_t)r * ch_); return r;
  }
  // LBRR: reconstruct the LOST previous frame from the NEXT packet's in-band FEC (decode_fec=1)
  int decode_fec(const uint8_t* next, int n, std::vector<float>& out) {
    out.resize((size_t)fs_ * ch_);
    int r = opus_decode_float(dec_, next, n, out.data(), fs_, 1);
    if (r < 0) { out.clear(); return 0; } out.resize((size_t)r * ch_); return r;
  }
  // PLC: no packet available at all (classic concealment)
  int conceal(std::vector<float>& out) {
    out.resize((size_t)fs_ * ch_);
    int r = opus_decode_float(dec_, nullptr, 0, out.data(), fs_, 0);
    if (r < 0) { out.clear(); return 0; } out.resize((size_t)r * ch_); return r;
  }
  ~OpusAudioDec() { if (dec_) opus_decoder_destroy(dec_); }
private:
  OpusDecoder* dec_ = nullptr; int sr_ = 48000, ch_ = 1, fs_ = 960;
};

}  // namespace avp
#endif  // AVP_WITH_OPUS
