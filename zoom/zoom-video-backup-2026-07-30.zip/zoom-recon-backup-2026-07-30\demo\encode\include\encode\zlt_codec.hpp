// zlt_codec.hpp — the zlt CAMERA codec family: real H.264 / H.265 via libx264 / libx265, replacing the
// minih264 *baseline* stand-in. Zoom's `zlt` module IS an H.264/H.265 SVC video codec (§3.1-3.3); its
// coding kernel is a standard H.264/265 encoder — a ⛔K boundary whose reference implementation is exactly
// libx264 / libx265 — wrapped with Zoom's control: adaptive QP by texture/motion (reconstructed in
// preprocess/algo/zlt_adaptive_qp.hpp; here realized through the encoder's variance AQ), IIR denoise
// (preprocess), and temporal references. Real High-profile + CABAC + adaptive QP is a generational step
// over minih264 baseline (no CABAC, 4x4 transforms only). `tune=zerolatency` keeps the two-way conference
// low-delay. Decode = avcodec H.264 / HEVC. Only built when the BtbN FFmpeg (libx264/libx265) is present.
#pragma once
#include "encode/screen_codec.hpp"
#if defined(AVP_WITH_FFMPEG) && defined(AVP_WITH_AOM)
#include <cstring>
#include <cstdarg>
#include <string>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/opt.h>
#include <libavutil/imgutils.h>
#include <libavutil/frame.h>   // AVRegionOfInterest for adaptive-QP injection
}

namespace avp {

// This FFmpeg build does NOT populate AVFrame::decode_error_flags / AV_FRAME_FLAG_CORRUPT (verified: always
// 0), so a frame that avcodec decoded to MOSAIC (a lost/missing reference it silently concealed) is
// indistinguishable from a clean one by frame metadata. But the decoder DOES log its concealment ("concealing
// N errors", "Missing reference picture", "error while decoding MB", ...). We install a log callback that sets
// a THREAD-LOCAL flag when such a message fires; decode() is single-threaded (thread_count=1) so the message
// is emitted synchronously on the decode thread during send/receive of the current packet, and we read the
// flag right after to mark that frame corrupt. This is what lets freeze-on-loss catch the whole-picture-lost
// case (no reassembler eviction) — the mosaic that was reaching the screen.
inline thread_local int g_zlt_dec_err = 0;
inline void zlt_dec_log_cb(void* avcl, int level, const char* fmt, va_list vl) {
  // NOTE: FFmpeg logs H.264 error CONCEALMENT at AV_LOG_INFO (not ERROR) — "concealing %d DC, %d AC, %d MV
  // errors" — so we must accept up to INFO here (gating at WARNING silently dropped exactly the frames we
  // needed). The substrings are specific corruption indicators, so matching at INFO level is safe.
  if (fmt && level <= AV_LOG_INFO &&
      (std::strstr(fmt, "conceal") || std::strstr(fmt, "Missing reference") || std::strstr(fmt, "error while decoding") ||
       std::strstr(fmt, "corrupt") || std::strstr(fmt, "bytestream") || std::strstr(fmt, "decode_slice") ||
       std::strstr(fmt, "illegal") || std::strstr(fmt, "out of range") || std::strstr(fmt, "no frame")))
    g_zlt_dec_err = 1;
  av_log_default_callback(avcl, level, fmt, vl);   // keep normal logging behavior
}

// Real H.264/H.265 encoder (zlt codec family). `hevc=false` -> libx264, `hevc=true` -> libx265.
class ZltAvcEncoder : public IScreenEncoder {
public:
  explicit ZltAvcEncoder(bool hevc) : hevc_(hevc) {}
  bool open(const ScreenEncParams& p) override {
    p_ = p;
    const char* nm = hevc_ ? "libx265" : "libx264";
    const AVCodec* enc = avcodec_find_encoder_by_name(nm);
    if (!enc) return false;
    c_ = avcodec_alloc_context3(enc);
    if (!c_) return false;
    const int fps = p.fps <= 0 ? 15 : p.fps;
    c_->width = p.width; c_->height = p.height;
    c_->time_base = AVRational{1, fps};
    c_->framerate = AVRational{fps, 1};
    c_->pix_fmt = AV_PIX_FMT_YUV420P;
    c_->bit_rate = (int64_t)p.kbps * 1000;
    c_->qmin = p.qmin; c_->qmax = p.qmax;
    c_->gop_size = p.gop;
    c_->max_b_frames = 0;                        // low delay for the interactive conference
    c_->flags |= AV_CODEC_FLAG_LOW_DELAY;
    // real-time, low-latency; High profile + CABAC come by default (not baseline).
    av_opt_set(c_->priv_data, "preset", "veryfast", 0);
    av_opt_set(c_->priv_data, "tune", "zerolatency", 0);
    // adaptive QP by texture/motion. Default: the encoder's own variance AQ (aq-mode=2). But when an
    // external map is injected (Zoom's zlt TextureMotion via set_qp_map), turn the codec's AQ OFF so the
    // injected ROI map is the SOLE adaptive-QP mechanism (§3.3 — Zoom's decision, not the codec's).
    const char* aq = p.ext_qp_map ? "aq-mode=0" : "aq-mode=2:aq-strength=1.0";
    // NOTE: intra-refresh (GDR) was tried for loss resilience but it REMOVES IDR keyframes, and the
    // receiver's freeze-on-loss recovery needs a clean IDR to un-freeze (with GDR, force_key only restarts
    // the refresh wave — no I-frame — so the freeze times out on a still-corrupt frame = mosaic + long
    // stalls). We chose freeze-over-mosaic, so we KEEP real IDR keyframes here: freeze holds the last good
    // frame, PLI forces a (bulletproof-FEC) IDR, the IDR un-freezes cleanly. Robust FEC lives in peer_main.
    if (hevc_) { std::string ps = std::string(aq) + ":bframes=0:rc-lookahead=0"; av_opt_set(c_->priv_data, "x265-params", ps.c_str(), 0); }
    else       av_opt_set(c_->priv_data, "x264-params", aq, 0);
    if (avcodec_open2(c_, enc, nullptr) != 0) return false;
    f_ = av_frame_alloc();
    f_->format = AV_PIX_FMT_YUV420P; f_->width = p.width; f_->height = p.height;
    if (av_frame_get_buffer(f_, 32) != 0) return false;
    return true;
  }

  void set_qp_map(const std::vector<int>& delta, int bw, int bh, int block) override {
    qp_delta_ = delta; qp_bw_ = bw; qp_bh_ = bh; qp_block_ = block > 0 ? block : 16;
  }

  bool encode(const I420Image& in, bool force_key, std::vector<uint8_t>& out, bool& key) override {
    out.clear(); key = false;
    if (!c_ || !f_) return false;
    if (av_frame_make_writable(f_) != 0) return false;
    copy_i420(in);
    // Zoom §3.3 adaptive-QP: attach the reconstructed per-block QP-delta as an encoder ROI map, so the
    // codec quantizes flat/smooth blocks finer (sharp) and busy blocks coarser (save bits) exactly where
    // zlt's TextureMotion ladder decided — instead of the encoder's own generic AQ.
    av_frame_remove_side_data(f_, AV_FRAME_DATA_REGIONS_OF_INTEREST);
    if (!qp_delta_.empty() && qp_bw_ > 0 && qp_bh_ > 0 && (int)qp_delta_.size() >= qp_bw_ * qp_bh_) {
      int nb = qp_bw_ * qp_bh_;
      AVFrameSideData* sd = av_frame_new_side_data(f_, AV_FRAME_DATA_REGIONS_OF_INTEREST, (size_t)nb * sizeof(AVRegionOfInterest));
      if (sd) {
        AVRegionOfInterest* r = (AVRegionOfInterest*)sd->data;
        for (int by = 0; by < qp_bh_; ++by) for (int bx = 0; bx < qp_bw_; ++bx) {
          AVRegionOfInterest& e = r[by * qp_bw_ + bx];
          e.self_size = sizeof(AVRegionOfInterest);
          e.top = by * qp_block_; e.left = bx * qp_block_;
          e.bottom = (by + 1) * qp_block_ < c_->height ? (by + 1) * qp_block_ : c_->height;
          e.right  = (bx + 1) * qp_block_ < c_->width  ? (bx + 1) * qp_block_ : c_->width;
          e.qoffset = AVRational{ qp_delta_[by * qp_bw_ + bx], 4 };   // neg (flat) = sharper, pos (busy) = coarser
        }
      }
    }
    f_->pts = pts_++;
    f_->pict_type = force_key ? AV_PICTURE_TYPE_I : AV_PICTURE_TYPE_NONE;
    if (avcodec_send_frame(c_, f_) != 0) return false;
    AVPacket* pkt = av_packet_alloc();
    bool got = false;
    while (avcodec_receive_packet(c_, pkt) == 0) {
      out.insert(out.end(), pkt->data, pkt->data + pkt->size);
      if (pkt->flags & AV_PKT_FLAG_KEY) key = true;
      got = true;
      av_packet_unref(pkt);
    }
    av_packet_free(&pkt);
    return got;
  }
  void set_bitrate(int bps) override { if (c_ && bps > 0) { c_->bit_rate = bps; av_opt_set_int(c_->priv_data, "b", bps, 0); } }
  const char* name() const override { return hevc_ ? "H.265/HEVC (libx265, High + AQ — zlt family)" : "H.264/AVC (libx264, High + CABAC + AQ — zlt family)"; }
  ~ZltAvcEncoder() override { if (f_) av_frame_free(&f_); if (c_) avcodec_free_context(&c_); }

private:
  void copy_i420(const I420Image& img) {
    const int w = c_->width, h = c_->height, cw = w / 2, chh = h / 2;
    for (int j = 0; j < h; ++j) {
      int sj = j < img.h ? j : img.h - 1; uint8_t* dst = f_->data[0] + (size_t)j * f_->linesize[0];
      for (int i = 0; i < w; ++i) { int si = i < img.w ? i : img.w - 1; dst[i] = img.y[(size_t)sj * img.w + si]; }
    }
    for (int j = 0; j < chh; ++j) {
      int sj = j < img.ch() ? j : img.ch() - 1;
      uint8_t* du = f_->data[1] + (size_t)j * f_->linesize[1];
      uint8_t* dv = f_->data[2] + (size_t)j * f_->linesize[2];
      for (int i = 0; i < cw; ++i) {
        int si = i < img.cw() ? i : img.cw() - 1;
        du[i] = img.u[(size_t)sj * img.cw() + si];
        dv[i] = img.v[(size_t)sj * img.cw() + si];
      }
    }
  }
  bool hevc_;
  ScreenEncParams p_;
  AVCodecContext* c_ = nullptr;
  AVFrame* f_ = nullptr;
  int64_t pts_ = 0;
  std::vector<int> qp_delta_; int qp_bw_ = 0, qp_bh_ = 0, qp_block_ = 16;   // injected adaptive-QP map
};

class ZltAvcDecoder : public IScreenDecoder {
public:
  explicit ZltAvcDecoder(bool hevc) : hevc_(hevc) {}
  bool open() override {
    const AVCodec* dec = avcodec_find_decoder(hevc_ ? AV_CODEC_ID_HEVC : AV_CODEC_ID_H264);
    if (!dec) return false;
    c_ = avcodec_alloc_context3(dec);
    if (!c_) return false;
    c_->thread_count = 1;
    c_->flags |= AV_CODEC_FLAG_LOW_DELAY;
    av_log_set_level(AV_LOG_INFO);         // concealment is logged at INFO — guarantee it reaches our callback
    av_log_set_callback(zlt_dec_log_cb);   // capture the decoder's own error-concealment log (corrupt-frame detection)
    return avcodec_open2(c_, dec, nullptr) == 0;
  }
  bool decode(const std::vector<uint8_t>& au, I420Image& out) override {
    if (!c_) return false;
    std::vector<uint8_t> padded(au);
    padded.resize(au.size() + AV_INPUT_BUFFER_PADDING_SIZE, 0);
    AVPacket* pkt = av_packet_alloc(); pkt->data = padded.data(); pkt->size = (int)au.size();
    AVFrame* f = av_frame_alloc();
    bool got = false;
    g_zlt_dec_err = 0;   // reset before decode; the log callback sets it if avcodec conceals errors in THIS packet
    if (avcodec_send_packet(c_, pkt) == 0) {
      while (avcodec_receive_frame(c_, f) == 0) {
        out.w = f->width; out.h = f->height;
        out.keyframe = (f->pict_type == AV_PICTURE_TYPE_I);   // intra frame = clean recovery point (freeze-on-loss exit)
        // A picture whose packets were ALL lost leaves no trace for the reassembler to evict, so the next
        // P-frame here decodes against a missing reference and avcodec silently CONCEALS it to mosaic. This
        // build doesn't set decode_error_flags, so we read the log-callback flag: it was raised iff the decoder
        // logged a concealment/error for this packet. Surface it so the receiver FREEZES on it instead of
        // showing it — catches every loss path (whole-frame-lost, truncated AU, bad reference) uniformly.
        out.corrupt = (g_zlt_dec_err != 0);
        out.y.assign((size_t)out.w * out.h, 0);
        out.u.assign((size_t)out.cw() * out.ch(), 128);
        out.v.assign((size_t)out.cw() * out.ch(), 128);
        for (int j = 0; j < out.h; ++j) memcpy(&out.y[(size_t)j * out.w], f->data[0] + (size_t)j * f->linesize[0], out.w);
        for (int j = 0; j < out.ch(); ++j) {
          memcpy(&out.u[(size_t)j * out.cw()], f->data[1] + (size_t)j * f->linesize[1], out.cw());
          memcpy(&out.v[(size_t)j * out.cw()], f->data[2] + (size_t)j * f->linesize[2], out.cw());
        }
        got = true;
      }
    }
    av_frame_free(&f); av_packet_free(&pkt);
    return got;
  }
  const char* name() const override { return hevc_ ? "H.265 (FFmpeg HEVC decoder)" : "H.264 (FFmpeg decoder)"; }
  ~ZltAvcDecoder() override { if (c_) avcodec_free_context(&c_); }
private:
  bool hevc_;
  AVCodecContext* c_ = nullptr;
};

}  // namespace avp
#endif  // AVP_WITH_FFMPEG && AVP_WITH_AOM
