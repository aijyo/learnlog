import idc, ida_hexrays, ida_funcs, ida_bytes
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
def decomp(ea, label):
    f = ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x (%s)"%(ea,label)); return
    try:
        L.append("\n// ===== %s  %s  (0x%x) ====="%(label, idc.get_func_name(f.start_ea), f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e:
        L.append("// FAIL 0x%x: %s"%(ea,e))
decomp(0x1800E7C90, "texture_metric_setup")   # processes v2 (texture array)
decomp(0x1800E7610, "threshold_build")        # builds the 6+6 thresholds from table
# dump the threshold table qword_1803FBDE0: first ~48 int16 (a few modes x 12 entries)
tbl = 0x1803FBDE0
vals = []
for i in range(48):
    vals.append(idc.get_wibble if False else ida_bytes.get_word(tbl + 2*i))
L.append("\n// threshold table qword_1803FBDE0 (int16 x48): " + ", ".join(str(v) for v in vals))
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
