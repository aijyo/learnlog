// vp9_screen.hpp — the VP9 SCREEN-CONTENT backend for IScreenEncoder/IScreenDecoder, driven through
// the already-linked FFmpeg/libvpx. The one line that makes screen text sharp is
//   av_opt_set(priv, "tune-content", "screen", 0)   ->  VP9E_SET_TUNE_CONTENT = VP9E_CONTENT_SCREEN
// which turns on libvpx's screen-content tools (aggressive intra / static-block handling), the same
// class of coding Zoom's AV1 SC core uses. Real-time settings (deadline=realtime, cpu-used, no
// lag-in-frames) keep two peers encoding + decoding live. Decode is FFmpeg's native VP9 decoder.
//
// This is the drop-in-now backend; the AV1 SC backend (zbt core = libaom) plugs into the SAME factory
// below under AVP_WITH_AOM once an AV1 encoder is available, so `--codec av1` switches with no other
// change. Only compiled when AVP_WITH_FFMPEG is defined (the peer/receiver build).
#pragma once
#include "encode/screen_codec.hpp"
#ifdef AVP_WITH_FFMPEG
#include <cstdio>
#include <cstring>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/opt.h>
#include <libavutil/imgutils.h>
}

namespace avp {

class Vp9ScreenEncoder : public IScreenEncoder {
public:
  bool open(const ScreenEncParams& p) override {
    p_ = p;
    const AVCodec* enc = avcodec_find_encoder_by_name("libvpx-vp9");
    if (!enc) return false;
    c_ = avcodec_alloc_context3(enc);
    if (!c_) return false;
    c_->width = p.width; c_->height = p.height;
    c_->time_base = AVRational{1, p.fps <= 0 ? 12 : p.fps};
    c_->framerate = AVRational{p.fps <= 0 ? 12 : p.fps, 1};
    c_->pix_fmt = AV_PIX_FMT_YUV420P;
    c_->bit_rate = (int64_t)p.kbps * 1000;
    c_->qmin = p.qmin; c_->qmax = p.qmax;        // quality-first: cap worst-case QP so motion can't blur text
    c_->gop_size = p.gop;                        // periodic keyframes so a lost key recovers
    c_->max_b_frames = 0;                        // no B-frames — low delay, simpler ref chain
    c_->thread_count = 0;                        // 0 = let libvpx pick
    c_->flags |= AV_CODEC_FLAG_LOW_DELAY;
    // libvpx-vp9 private options (the real-time + screen-content knobs)
    av_opt_set(c_->priv_data, "deadline", "realtime", 0);   // VPX_DL_REALTIME
    av_opt_set_int(c_->priv_data, "cpu-used", 8, 0);        // fastest real-time preset (0..8)
    av_opt_set_int(c_->priv_data, "lag-in-frames", 0, 0);   // no lookahead -> no encode delay
    av_opt_set_int(c_->priv_data, "row-mt", 1, 0);          // row-based multithreading
    av_opt_set_int(c_->priv_data, "error-resilient", 1, 0); // each frame more self-contained (lossy link)
    if (p.screen_content)
      av_opt_set(c_->priv_data, "tune-content", "screen", 0);   // <<< the screen-content-coding switch
    if (avcodec_open2(c_, enc, nullptr) != 0) return false;
    f_ = av_frame_alloc();
    f_->format = AV_PIX_FMT_YUV420P; f_->width = p.width; f_->height = p.height;
    if (av_frame_get_buffer(f_, 32) != 0) return false;
    return true;
  }

  bool encode(const I420Image& in, bool force_key, std::vector<uint8_t>& out, bool& key) override {
    out.clear(); key = false;
    if (!c_ || !f_) return false;
    if (av_frame_make_writable(f_) != 0) return false;
    copy_i420(in);
    f_->pts = pts_++;
    f_->pict_type = force_key ? AV_PICTURE_TYPE_I : AV_PICTURE_TYPE_NONE;   // I -> libvpx VPX_EFLAG_FORCE_KF
    if (avcodec_send_frame(c_, f_) != 0) return false;
    AVPacket* pkt = av_packet_alloc();
    bool got = false;
    last_pkt_count = 0;
    while (avcodec_receive_packet(c_, pkt) == 0) {
      out.insert(out.end(), pkt->data, pkt->data + pkt->size);   // one VP9 frame == one access unit
      if (pkt->flags & AV_PKT_FLAG_KEY) key = true;
      got = true; ++last_pkt_count;
      av_packet_unref(pkt);
    }
    av_packet_free(&pkt);
    return got;
  }

  void set_bitrate(int bps) override {
    if (c_ && bps > 0) { c_->bit_rate = bps; av_opt_set_int(c_->priv_data, "b", bps, 0); }
  }
  const char* name() const override { return "VP9 screen-content (libvpx, tune=screen)"; }
  int last_pkt_count = 0;   // avcodec packets emitted by the last encode() — >1 means multiple frames
  ~Vp9ScreenEncoder() override { if (f_) av_frame_free(&f_); if (c_) avcodec_free_context(&c_); }

private:
  // copy an avp::I420Image into the encoder's YUV420P AVFrame (crop/clamp to the coded w x h).
  void copy_i420(const I420Image& img) {
    const int w = c_->width, h = c_->height, cw = w / 2, chh = h / 2;
    for (int j = 0; j < h; ++j) {
      int sj = j < img.h ? j : img.h - 1; uint8_t* dst = f_->data[0] + (size_t)j * f_->linesize[0];
      for (int i = 0; i < w; ++i) { int si = i < img.w ? i : img.w - 1; dst[i] = img.y[(size_t)sj * img.w + si]; }
    }
    for (int j = 0; j < chh; ++j) {
      int sj = j < img.ch() ? j : img.ch() - 1;
      uint8_t* du = f_->data[1] + (size_t)j * f_->linesize[1];
      uint8_t* dv = f_->data[2] + (size_t)j * f_->linesize[2];
      for (int i = 0; i < cw; ++i) {
        int si = i < img.cw() ? i : img.cw() - 1;
        du[i] = img.u[(size_t)sj * img.cw() + si];
        dv[i] = img.v[(size_t)sj * img.cw() + si];
      }
    }
  }
  ScreenEncParams p_;
  AVCodecContext* c_ = nullptr;
  AVFrame* f_ = nullptr;
  int64_t pts_ = 0;
};

class Vp9ScreenDecoder : public IScreenDecoder {
public:
  bool open() override {
    const AVCodec* dec = avcodec_find_decoder(AV_CODEC_ID_VP9);
    if (!dec) return false;
    c_ = avcodec_alloc_context3(dec);
    if (!c_) return false;
    c_->thread_count = 1;                     // no frame-threading -> no multi-frame output delay
    c_->flags |= AV_CODEC_FLAG_LOW_DELAY;
    return avcodec_open2(c_, dec, nullptr) == 0;
  }
  bool decode(const std::vector<uint8_t>& au, I420Image& out) override {
    if (!c_) return false;
    std::vector<uint8_t> padded(au);
    padded.resize(au.size() + AV_INPUT_BUFFER_PADDING_SIZE, 0);
    AVPacket* pkt = av_packet_alloc(); pkt->data = padded.data(); pkt->size = (int)au.size();
    AVFrame* f = av_frame_alloc();
    bool got = false;
    if (avcodec_send_packet(c_, pkt) == 0) {
      while (avcodec_receive_frame(c_, f) == 0) {
        out.w = f->width; out.h = f->height;
        out.y.assign((size_t)out.w * out.h, 0);
        out.u.assign((size_t)out.cw() * out.ch(), 128);
        out.v.assign((size_t)out.cw() * out.ch(), 128);
        for (int j = 0; j < out.h; ++j) memcpy(&out.y[(size_t)j * out.w], f->data[0] + (size_t)j * f->linesize[0], out.w);
        for (int j = 0; j < out.ch(); ++j) {
          memcpy(&out.u[(size_t)j * out.cw()], f->data[1] + (size_t)j * f->linesize[1], out.cw());
          memcpy(&out.v[(size_t)j * out.cw()], f->data[2] + (size_t)j * f->linesize[2], out.cw());
        }
        got = true;
      }
    }
    av_frame_free(&f); av_packet_free(&pkt);
    return got;
  }
  const char* name() const override { return "VP9 (FFmpeg native decoder)"; }
  ~Vp9ScreenDecoder() override { if (c_) avcodec_free_context(&c_); }
private:
  AVCodecContext* c_ = nullptr;
};

}  // namespace avp
#ifdef AVP_WITH_AOM
#include "encode/av1_screen.hpp"   // Av1ScreenEncoder/Av1ScreenDecoder (Zoom-exact zbt SC core / libaom)
#include "encode/zlt_codec.hpp"    // ZltAvcEncoder/Decoder (zlt camera codec family: libx264/libx265)
#endif
#ifdef AVP_WITH_VPX
#include "encode/vp9_ltr.hpp"      // Vp9LtrEncoder — libvpx-direct VP9 with golden-frame LTR loss recovery
#endif
namespace avp {

// ---- factory ------------------------------------------------------------------------------------
// Routes each ScreenCodec to its backend when AVP_WITH_AOM (BtbN FFmpeg = libaom + libx264/libx265) is
// built: AV1 -> zbt SC core (libaom), H264/H265 -> zlt family (libx264/libx265). Without AVP_WITH_AOM
// everything degrades to the VP9 backend so the switch never breaks the demo.
inline std::unique_ptr<IScreenEncoder> MakeScreenEncoder(ScreenCodec c) {
#ifdef AVP_WITH_AOM
  if (c == ScreenCodec::AV1)  return std::make_unique<Av1ScreenEncoder>();       // zbt SC / libaom
  if (c == ScreenCodec::H264) return std::make_unique<ZltAvcEncoder>(false);     // zlt / libx264
  if (c == ScreenCodec::H265) return std::make_unique<ZltAvcEncoder>(true);      // zlt / libx265
#else
  (void)c;
#endif
#ifdef AVP_WITH_VPX
  if (c == ScreenCodec::VP9) return std::make_unique<Vp9LtrEncoder>();   // libvpx-direct: adds golden-frame LTR loss recovery
#endif
  return std::make_unique<Vp9ScreenEncoder>();   // avcodec VP9 (no ref control) — fallback / non-peer targets
}
inline std::unique_ptr<IScreenDecoder> MakeScreenDecoder(ScreenCodec c) {
#ifdef AVP_WITH_AOM
  if (c == ScreenCodec::AV1)  return std::make_unique<Av1ScreenDecoder>();        // dav1d
  if (c == ScreenCodec::H264) return std::make_unique<ZltAvcDecoder>(false);      // H.264
  if (c == ScreenCodec::H265) return std::make_unique<ZltAvcDecoder>(true);       // H.265
#else
  (void)c;
#endif
#ifdef AVP_WITH_VPX
  if (c == ScreenCodec::VP9) return std::make_unique<Vp9LtrDecoder>();   // libvpx direct — matches the LTR encoder + reports keyframe/corrupt
#endif
  return std::make_unique<Vp9ScreenDecoder>();   // avcodec VP9 (fallback / non-peer targets)
}

}  // namespace avp
#endif  // AVP_WITH_FFMPEG
