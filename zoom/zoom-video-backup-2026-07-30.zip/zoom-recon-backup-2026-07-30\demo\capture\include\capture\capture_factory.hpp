// capture_factory.hpp — capability-probe + priority fallback for screen capture, exactly the shape
// of Zoom's backend selection (WGC -> Magnification/Duplication -> injection). We try the best
// available backend first and fall back; the chosen backend and any skips are reported.
//
//   priority:  WGC (opt-in, Win10 2004+, per-window, GPU)   [AVP_WITH_WGC]
//           -> DXGI Desktop Duplication (Win8+, whole-monitor, GPU)
//           -> GDI BitBlt (universal, CPU)
#pragma once
#include "screen_dxgi.hpp"
#include "screen_gdi.hpp"
#include "screen_mag.hpp"
#include "screen_shared.hpp"
#ifdef AVP_WITH_WGC
#include "screen_wgc.hpp"
#endif
#include <memory>
#include <string>

namespace avp {

inline std::unique_ptr<IVideoSource> CreateBestScreenSource(const CaptureConfig& cfg, std::string& notes) {
  notes.clear();
#ifdef AVP_WITH_WGC
  { auto s = std::make_unique<WgcScreenSource>(); if (s->open(cfg)) return s; notes += "WGC unavailable -> "; }
#else
  notes += "WGC not built (AVP_WITH_WGC off) -> ";
#endif
  { auto s = std::make_unique<DxgiScreenSource>(); if (s->open(cfg)) return s; notes += "DXGI-Duplication unavailable -> "; }
  { auto s = std::make_unique<GdiScreenSource>();  if (s->open(cfg)) return s; notes += "GDI failed"; }
  return nullptr;
}

// Select a specific backend by name (for testing individual paths):
//   auto | wgc | dxgi | gdi | mag-cb (Magnification callback) | mag-dx (Magnification direct-read)
inline std::unique_ptr<IVideoSource> CreateNamedScreenSource(const std::string& name, const CaptureConfig& cfg, std::string& notes) {
  notes.clear();
  auto ok = [&](std::unique_ptr<IVideoSource> s, const char* fail) -> std::unique_ptr<IVideoSource> {
    if (s && s->open(cfg)) return s; notes = fail; return nullptr;
  };
  if (name == "gdi")    return ok(std::make_unique<GdiScreenSource>(), "GDI open failed");
  if (name == "dxgi")   return ok(std::make_unique<DxgiScreenSource>(), "DXGI-Duplication open failed");
  if (name == "mag-cb") return ok(std::make_unique<MagnifierScreenSource>(MagMode::Callback),   "Magnification(callback) open failed");
  if (name == "mag-dx") return ok(std::make_unique<MagnifierScreenSource>(MagMode::DirectRead), "Magnification(direct-read) open failed");
  if (name == "shared") return ok(std::make_unique<SharedSurfaceSource>(), "shared surface not found (is present_target.exe running?)");
#ifdef AVP_WITH_WGC
  if (name == "wgc")    return ok(std::make_unique<WgcScreenSource>(), "WGC open failed");
#endif
  return CreateBestScreenSource(cfg, notes);   // "auto" / unknown
}

}  // namespace avp
