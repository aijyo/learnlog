# scan Names() for substrings (idc.ARGV[1]=out, idc.ARGV[2..]=substrings, case-insensitive)
import idc, idautils
out = idc.ARGV[1]; subs = [s.lower() for s in idc.ARGV[2:]]
L = []
for ea, nm in idautils.Names():
    low = nm.lower()
    if any(s in low for s in subs):
        L.append("0x%x  %s" % (ea, nm))
open(out, "w", encoding="utf-8", errors="replace").write("\n".join(L))
idc.qexit(0)
