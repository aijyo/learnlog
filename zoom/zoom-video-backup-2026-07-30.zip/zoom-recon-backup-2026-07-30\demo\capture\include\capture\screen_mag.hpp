// screen_mag.hpp — Magnification API screen capture (Zoom's backend ②, from CptHost).
// Two modes, matching the two branches recovered from the binary:
//   Callback   : MagSetImageScalingCallback -> the source bitmap is handed to us per refresh.
//   DirectRead : after MagSetWindowSource + update, read the magnifier host's rendered output
//                directly (BitBlt of the mag window) — the practical form of the "DX9 direct
//                surface read" branch.
// Distinctive vs WGC/DXGI: MagSetWindowFilterList can EXCLUDE our own windows (no "mirror-in-mirror"
// when sharing). Needs a message pump + an interactive desktop session (window-based API).
#pragma once
#include "video_source.hpp"
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <magnification.h>
#pragma comment(lib, "magnification.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

namespace avp {

enum class MagMode { Callback, DirectRead };

class MagnifierScreenSource : public IVideoSource {
public:
  explicit MagnifierScreenSource(MagMode mode) : mode_(mode) {}

  bool open(const CaptureConfig& cfg) override {
    if (!MagInitialize()) return false;
    w_ = GetSystemMetrics(SM_CXSCREEN);
    h_ = GetSystemMetrics(SM_CYSCREEN);
    HINSTANCE hinst = GetModuleHandle(nullptr);
    WNDCLASSEXW wc{}; wc.cbSize = sizeof(wc); wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = hinst; wc.lpszClassName = L"AvpMagHost";
    RegisterClassExW(&wc);
    // host: layered + transparent so it doesn't disturb the user, but present so the magnifier renders
    host_ = CreateWindowExW(WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW, L"AvpMagHost", L"",
                            WS_POPUP, 0, 0, w_, h_, nullptr, nullptr, hinst, nullptr);
    if (!host_) { MagUninitialize(); return false; }
    SetLayeredWindowAttributes(host_, 0, 1, LWA_ALPHA);   // ~invisible
    ShowWindow(host_, SW_SHOWNA);
    mag_ = CreateWindowW(WC_MAGNIFIERW, L"AvpMag", WS_CHILD | WS_VISIBLE, 0, 0, w_, h_, host_, nullptr, hinst, nullptr);
    if (!mag_) { close(); return false; }

    // exclude our own host window from what the magnifier reflects (Zoom's anti-mirror feature)
    HWND excl[1] = { host_ };
    MagSetWindowFilterList(mag_, MW_FILTERMODE_EXCLUDE, 1, excl);

    RECT src{ 0, 0, w_, h_ };
    if (!MagSetWindowSource(mag_, src)) { close(); return false; }

    if (mode_ == MagMode::Callback) {
      g_active = this;
      if (!MagSetImageScalingCallback(mag_, &ScalingCallback)) { /* deprecated; may fail on some builds */ }
    }
    return w_ > 0 && h_ > 0;
  }

  bool grab(VideoFrame& out) override {
    pump_();
    RECT src{ 0, 0, w_, h_ };
    MagSetWindowSource(mag_, src);      // trigger a fresh reflect (+ callback in Callback mode)
    InvalidateRect(mag_, nullptr, TRUE); UpdateWindow(mag_);
    pump_();

    if (mode_ == MagMode::Callback) {
      if (!have_cb_) return false;
      out = cb_frame_; out.timestamp_us = now_us();
      return out.valid();
    }
    // DirectRead: read the magnifier window's rendered client area
    return read_window_(mag_, out);
  }

  void close() override {
    if (mode_ == MagMode::Callback && mag_) MagSetImageScalingCallback(mag_, nullptr);
    if (mag_) { DestroyWindow(mag_); mag_ = nullptr; }
    if (host_) { DestroyWindow(host_); host_ = nullptr; }
    if (g_active == this) g_active = nullptr;
    MagUninitialize();
  }
  const char* backend() const override { return mode_ == MagMode::Callback ? "Magnification-Callback" : "Magnification-DirectRead"; }
  int width() const override { return w_; }
  int height() const override { return h_; }

private:
  static int64_t now_us() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return c.QuadPart * 1000000 / f.QuadPart; }
  static void pump_() { MSG m; for (int i = 0; i < 32 && PeekMessage(&m, nullptr, 0, 0, PM_REMOVE); ++i) { TranslateMessage(&m); DispatchMessage(&m); } }

  // Callback: MagSetImageScalingCallback hands us the SOURCE bitmap for each refresh.
  static BOOL CALLBACK ScalingCallback(HWND, void* srcdata, MAGIMAGEHEADER srch,
                                       void*, MAGIMAGEHEADER, RECT, RECT, HRGN) {
    MagnifierScreenSource* self = g_active;
    if (self && srcdata && srch.width && srch.height) {
      int stride = (int)srch.stride ? (int)srch.stride : (int)srch.width * 4;   // 32bpp source
      VideoFrame& f = self->cb_frame_;
      f.width = (int)srch.width; f.height = (int)srch.height; f.stride = (int)srch.width * 4;
      f.format = PixelFormat::BGRA;
      f.data.resize((size_t)f.stride * f.height);
      const uint8_t* s = (const uint8_t*)srcdata;
      for (int y = 0; y < f.height; ++y) memcpy(&f.data[(size_t)y * f.stride], s + (size_t)y * stride, (size_t)f.width * 4);
      self->have_cb_ = true;
    }
    return TRUE;
  }

  bool read_window_(HWND wnd, VideoFrame& out) {
    HDC wdc = GetDC(wnd);
    if (!wdc) return false;
    HDC mem = CreateCompatibleDC(wdc);
    BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w_; bi.bmiHeader.biHeight = -h_; bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr; HBITMAP dib = CreateDIBSection(wdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    bool ok = false;
    if (dib && bits) {
      HGDIOBJ old = SelectObject(mem, dib);
      if (BitBlt(mem, 0, 0, w_, h_, wdc, 0, 0, SRCCOPY)) {
        out.width = w_; out.height = h_; out.stride = w_ * 4; out.format = PixelFormat::BGRA; out.timestamp_us = now_us();
        out.data.assign((uint8_t*)bits, (uint8_t*)bits + (size_t)out.stride * h_);
        ok = true;
      }
      SelectObject(mem, old);
    }
    if (dib) DeleteObject(dib);
    DeleteDC(mem); ReleaseDC(wnd, wdc);
    return ok;
  }

  MagMode mode_;
  HWND host_ = nullptr, mag_ = nullptr;
  int w_ = 0, h_ = 0;
  VideoFrame cb_frame_;
  bool have_cb_ = false;
  static MagnifierScreenSource* g_active;
};

inline MagnifierScreenSource* MagnifierScreenSource::g_active = nullptr;

}  // namespace avp
#endif
