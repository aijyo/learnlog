// video_frame.hpp — the unit that flows out of any capture source into the rest of the A/V
// pipeline (the next module, encode, consumes these). Kept transport-agnostic and copyable.
#pragma once
#include <cstdint>
#include <vector>

namespace avp {

enum class PixelFormat { BGRA, NV12 };   // capture yields BGRA; NV12 is what encoders want (later module)

inline const char* to_string(PixelFormat f) { return f == PixelFormat::NV12 ? "NV12" : "BGRA"; }

struct VideoFrame {
  int          width = 0;
  int          height = 0;
  int          stride = 0;              // bytes per row (>= width*bpp; rows may be padded)
  PixelFormat  format = PixelFormat::BGRA;
  int64_t      timestamp_us = 0;        // capture time, microseconds
  std::vector<uint8_t> data;            // owns pixels, size == stride * height

  int  bpp() const { return format == PixelFormat::BGRA ? 4 : 1; }
  bool valid() const { return width > 0 && height > 0 && !data.empty(); }
};

}  // namespace avp
