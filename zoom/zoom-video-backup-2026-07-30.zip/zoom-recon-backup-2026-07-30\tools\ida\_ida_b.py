import idc, ida_hexrays, ida_funcs, idautils
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
def decomp(ea, label):
    f = ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x (%s)"%(ea,label)); return
    try:
        L.append("\n// ===== %s  %s  (0x%x) ====="%(label, idc.get_func_name(f.start_ea), f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e:
        L.append("// FAIL 0x%x: %s"%(ea,e))
def ctors(vt, label):
    dtor = idc.get_qword(vt)
    refs = sorted(set(idc.get_func_attr(x, idc.FUNCATTR_START) for x in idautils.DataRefsTo(vt)))
    L.append("\n// ==== %s vtable 0x%x  dtor=0x%x  ctors/refs: %s ===="%(
        label, vt, dtor, ", ".join("0x%x"%c for c in refs if c!=idc.BADADDR)))
    for c in refs:
        if c!=idc.BADADDR and c!=dtor:
            decomp(c, "%s.ref"%label)
ctors(0x180502738, "TextureMotion")
ctors(0x180502728, "Roi")
ctors(0x180502798, "Static")
ctors(0x180502718, "Background")
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
