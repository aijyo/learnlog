# Fresh-analyze a DLL into an .i64 (creates DB) then run a script against it.
# Usage: powershell -f _buildida.ps1 <target.dll> <script.py> <out.txt> [extra args...]
param([string]$Target, [string]$Script, [string]$Out, [Parameter(ValueFromRemainingArguments=$true)]$Rest)
$ida = "D:\solft\IDA Pro 7.5.20.1028 SP3 Portable + All decompilers (Windows)\IDA Pro 7.5.20.1028 SP3 Portable\idat64.exe"
$py  = "C:\Users\CT10266\AppData\Local\Programs\Python\Python39"
$log = "$env:TEMP\_ida_build.log"
$env:PYTHONHOME = $py
$env:PATH = "$py;$py\DLLs;" + $env:PATH
$env:_NT_SYMBOL_PATH = $env:TEMP
$sarg = ($Script + " " + $Out + " " + ($Rest -join " ")).Trim()
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $ida
# -c creates a fresh DB next to the target (<target>.i64); -A autonomous; run script after autoanalysis.
$psi.Arguments = '-A -c -S"' + $sarg + '" -L"' + $log + '" "' + $Target + '"'
$psi.UseShellExecute = $false
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
Write-Host "ARGS: $($psi.Arguments)"
$sw = [System.Diagnostics.Stopwatch]::StartNew()
$p = [System.Diagnostics.Process]::Start($psi)
$p.WaitForExit()
$sw.Stop()
Write-Host "exit=$($p.ExitCode) elapsed=$([int]$sw.Elapsed.TotalSeconds)s"
if (Test-Path $Out) { Write-Host "OK -> $Out ($((Get-Item $Out).Length) bytes)" } else { Write-Host "NO OUTPUT"; Get-Content $log -Tail 20 }
