# Module 3 — encode

The codec stage from `AV_PIPELINE_DETAILS.html §3`: turn the preprocessed frames/audio (module 2) into
a coded bitstream, under SVC layer control, the keyframe/reference request model, and codec switching.

```
module-2 I420 + QP map ─► H.264 encode (minih264) ─► Annex-B + temporal-id  ─► [SFU prunes per receiver]
module-2 20 ms audio   ─► AAC-LC encode (FFmpeg)  ─► packets                (Opus/SNAC = boundaries)
```

## Video (`h264_encoder.hpp`, `svc_layers.hpp`, `screen_content.hpp`)

| piece | file | Zoom mapping (§3) | boundary |
|---|---|---|---|
| H.264 encode | `h264_encoder.hpp` + `third_party/minih264` | real pixels→bitstream | **minih264 baseline** stands in for zlt's engine (⛔K) |
| SVC control surface | `algo/zlt_svc_encoder.hpp` | `SetKeyPictureRequest` dispatcher, 96-byte layer struct (§3.2/§3.3) | real, body-verified |
| temporal layering | `svc_layers.hpp` | dyadic ×0.5 cascade 30→15→7.5 (§3.2) | real |
| **layered references** | `h264_encoder.hpp` (`LayeredRefScheduler`) | **really-droppable** temporal SVC via LTR (§3.2) | real (minih264 CUSTOM+LTR) |
| keyframe / LTR / IDR | `h264_encoder.hpp` (via control) | IDR, key-recovery, new-attendee I, bitrate (§3.3) | real control; layered refs need the SVC engine |
| screen-content detect | `screen_content.hpp` | natural vs screen → AV1 SC core `(mode&0xF)==2` (§3.4) | detection real; AV1 SC tools need libaom/SVT (not installed) |
| decode-verify | `h264_decode_verify.hpp` | — | FFmpeg H.264 decode + PSNR (`AVP_WITH_FFMPEG`) |

The `algo/*.hpp` are vendored from the body-verified `bin2cpp-output` reconstruction (the H.264 backend
gets one av-pipeline extension: `EncodeFrameCustom`, minih264's `CUSTOM` frame type + LTR control).

**Really-droppable temporal layers (`layered_refs=true`):** `LayeredRefScheduler` builds a true dyadic
reference structure using minih264's long-term-reference slots — t0 anchors in LTR slot 1, t1 in slot 2,
and t2 frames reference a lower layer and are marked **droppable** (non-reference, `long_term_idx_update
= -1`). Dropping every t2 frame leaves the t0/t1 reference chains intact, so the sub-stream decodes
clean. Verified by `layered_svc_demo` (below): the t≤1 sub-stream decodes at **44.8 dB**, whereas the
same frames dropped from a plain annotated IPPP stream collapse to **8.0 dB** (dangling refs / frame_num
gaps). This is the difference between *labeling* layers and making them *actually* prunable.

Screen-content detection is real; the recommended AV1 SC core is an advisory (no AV1 encoder installed).

## Audio (`audio_encoder.hpp`)

| piece | technique | boundary |
|---|---|---|
| codec-switch control | AI-codec 121 gate, 0x4 control-word bit, SNAC decode SM, SNAC-TCP→Opus fallback (§3.5) | real, body-verified (`algo/viper_codec_control.hpp`) |
| audio encode | AAC-LC (FFmpeg native), `AVP_WITH_FFMPEG` | **Opus/SNAC = ⛔** (no libopus; SNAC is neural weights) — AAC exercises the data path |

## Build & run
```powershell
cmake -S . -B build -DAVP_WITH_WGC=ON              # minih264 H.264 + control (no external codec libs)
cmake --build build --config Release
.\build\encode\Release\video_encode_demo.exe
.\build\encode\Release\audio_encode_demo.exe
# optional: real decode loop (PSNR) + real AAC via vcpkg static FFmpeg
cmake -S . -B build-ff -DAVP_WITH_FFMPEG=ON
cmake --build build-ff --config Release --target video_encode_demo audio_encode_demo
```

## Verified (this machine)
```
VIDEO
  SVC temporal ids     0 2 1 2 0 2 1 2   fps @ L0/L1/L2 = 7.5 / 15 / 30
  layered droppable    layered_svc_demo: t<=1 sub-stream 44.8 dB (clean) vs annotated 8.0 dB (breaks)
  H.264 (minih264)     f0 IDR [SPS PPS IDR], P frames; request_idr()@f8 -> IDR   16 frames 97,514 B
  SFU pruning          L0 4/16 (32%, 7.5fps)   L1 8/16 (53%, 15fps)   L2 16/16 (100%, 30fps)
  rate control         3.0 Mbps -> 211,526 B    vs   0.3 Mbps -> 14,572 B
  screen-content       natural score 0.00 -> normal   |   screen score 0.67 -> AV1 SC advice
  encode->decode loop  FFmpeg H.264 decode, mean luma PSNR = 37.7 dB / 16 frames   (AVP_WITH_FFMPEG)
  end to end           capture_frame0.bmp -> preprocess -> encode: IDR 922 B (640x352)
AUDIO
  codec-switch control 121 gate (113 Ok / 100 -302 / 0 -301 / no-121 -304); ctrl-word 0x4; SNAC SM; TCP fallback
  real AAC encode      module-2 audio 48 kHz 2.96 s -> 140 packets, 24,091 B  vs 284,160 B PCM16 = 11.8x
```

Clean-room, following Zoom's *design* (not its code). Real codec engines (zlt/AV1 SC), Opus, and SNAC
weights are boundaries; minih264 and FFmpeg AAC are the real stand-in encoders. For interop / education.
