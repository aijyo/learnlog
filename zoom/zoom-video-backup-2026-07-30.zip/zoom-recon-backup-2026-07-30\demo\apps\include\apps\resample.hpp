#pragma once
// resample.hpp — Zoom-fidelity image resampler for the capture -> encode-resolution downscale.
//
// Reverse-engineered from zlt.dll  ns_vpp::zltCResample / ns_vpp::zltCGvdownsample (Zoom's VPP scaler).
// Zoom downsamples a captured 4K/native frame to the encode tier (<=1080p) with a *polyphase, separable,
// scale-adaptive bicubic* resampler — NOT a box average and NOT plain bilinear. What we mirror here:
//
//   * KERNEL = bicubic Keys convolution, a = -0.5  (Catmull-Rom).  zlt fn sub_1801BCCA0:
//         k(x) =  1.5|x|^3 - 2.5|x|^2 + 1           for |x| < 1
//                -0.5|x|^3 + 2.5|x|^2 - 4|x| + 2    for 1 <= |x| < 2
//                 0                                  for |x| >= 2      (support radius 2 -> 4 taps at unity)
//     (Zoom also ships a Lanczos-4 kernel sub_1801BCE40 as a higher-quality option; bicubic a=-0.5 is the
//      default and is the kernel hard-wired into the dedicated downsampler zltCGvdownsample.)
//
//   * SCALE-ADAPTIVE ANTI-ALIASING.  zlt fn sub_1801BC400 sets the filter support to
//         support = 2 * max(1, src/dst)     (per axis)
//     i.e. when shrinking, the kernel footprint is stretched by the downscale factor so it low-passes the
//     source and does not alias; the kernel argument is the pixel distance divided by that same factor.
//     Tap count = ceil(2*support) therefore grows with the shrink ratio. On upscale the support is clamped
//     to the base radius (max(1,.) == 1), so it reduces to ordinary bicubic interpolation. At unity scale
//     Catmull-Rom passes exactly through the samples, so a same-size "resize" is a bit-exact copy.
//
//   * SEPARABLE 1-D passes (horizontal then vertical), per-output-pixel normalized weights.  zlt fn
//     sub_1801BCF00 accumulates the kernel over the support window and normalizes the taps to sum = 16384
//     (Q14 fixed point); we normalize to 1.0 in float — functionally identical.
//
// This is a clean-room reimplementation of the *algorithm* only. No Zoom code is reproduced; the weights,
// data layout (BGRA, alpha forced 255) and code are ours.  [实证: kernel math, support law, separability,
// normalization — all from decompile.  推断: exact half-pixel origin convention — we use the standard
// center = (out+0.5)*src/dst - 0.5, which Zoom's (out + phase)/ratio mapping is equivalent to.]

#include <vector>
#include <cmath>
#include <cstdint>
#include <utility>

namespace avp { namespace resample {

// Bicubic Catmull-Rom (Keys a = -0.5) reconstruction kernel, weight as a function of signed distance.
// Matches zlt.dll sub_1801BCCA0 term for term. Zero at every nonzero integer -> interpolating (sharp).
inline double CubicCatmullRom(double x) {
  double a = x < 0.0 ? -x : x;                       // |x|
  if (a < 1.0) return (1.5 * a - 2.5) * a * a + 1.0;                 //  1.5|x|^3 - 2.5|x|^2 + 1
  if (a < 2.0) return ((-0.5 * a + 2.5) * a - 4.0) * a + 2.0;        // -0.5|x|^3 + 2.5|x|^2 - 4|x| + 2
  return 0.0;
}

// One axis of the separable polyphase filter: for each of dst_len outputs, the first source tap index and
// its normalized weights. `support` widens with the shrink factor (anti-aliasing), per sub_1801BC400.
struct AxisTaps { int start; std::vector<float> w; };

inline void BuildAxis(int src_len, int dst_len, std::vector<AxisTaps>& out) {
  out.assign(dst_len > 0 ? dst_len : 0, AxisTaps{});
  if (src_len <= 0 || dst_len <= 0) return;
  const double ratio  = (double)dst_len / (double)src_len;   // dst/src  (Zoom's a6)
  const double fscale = ratio < 1.0 ? 1.0 / ratio : 1.0;     // max(1, src/dst): widen filter on downscale
  const double support = 2.0 * fscale;                       // bicubic radius 2, stretched
  const double invf = 1.0 / fscale;                          // kernel arg = pixel_distance / fscale
  for (int o = 0; o < dst_len; ++o) {
    const double center = ((double)o + 0.5) / ratio - 0.5;   // output pixel center in source coordinates
    int lo = (int)std::ceil(center - support);
    int hi = (int)std::floor(center + support);
    AxisTaps t; t.start = lo; t.w.reserve((size_t)(hi - lo + 1));
    double sum = 0.0;
    for (int s = lo; s <= hi; ++s) { double w = CubicCatmullRom((s - center) * invf); t.w.push_back((float)w); sum += w; }
    if (sum != 0.0) { float inv = (float)(1.0 / sum); for (float& w : t.w) w *= inv; }  // Zoom: Q14 sum=16384
    out[o] = std::move(t);
  }
}

// Resize the BGR channels of a BGRA source (srcW x srcH, srcStride bytes/row) into a contiguous dstW x dstH
// BGRA buffer (row stride dstW*4, alpha forced 255). Bicubic Catmull-Rom, separable, anti-aliased on shrink.
inline void ResizeBGRA(const uint8_t* src, int srcW, int srcH, int srcStride,
                       uint8_t* dst, int dstW, int dstH) {
  if (srcW <= 0 || srcH <= 0 || dstW <= 0 || dstH <= 0) return;
  std::vector<AxisTaps> tx, ty;
  BuildAxis(srcW, dstW, tx);
  BuildAxis(srcH, dstH, ty);

  // Pass 1 — horizontal: (srcH x dstW) intermediate in float, BGR only.
  std::vector<float> tmp((size_t)srcH * dstW * 3, 0.0f);
  for (int y = 0; y < srcH; ++y) {
    const uint8_t* srow = src + (size_t)y * srcStride;
    float* trow = tmp.data() + (size_t)y * dstW * 3;
    for (int x = 0; x < dstW; ++x) {
      const AxisTaps& t = tx[x];
      float b = 0, g = 0, r = 0;
      for (size_t k = 0; k < t.w.size(); ++k) {
        int sx = t.start + (int)k; sx = sx < 0 ? 0 : (sx >= srcW ? srcW - 1 : sx);   // clamp to edge
        const uint8_t* p = srow + (size_t)sx * 4; float w = t.w[k];
        b += p[0] * w; g += p[1] * w; r += p[2] * w;
      }
      float* d = trow + (size_t)x * 3; d[0] = b; d[1] = g; d[2] = r;
    }
  }

  // Pass 2 — vertical: (dstH x dstW) BGRA out, clamp bicubic overshoot to [0,255].
  for (int y = 0; y < dstH; ++y) {
    const AxisTaps& t = ty[y];
    uint8_t* drow = dst + (size_t)y * dstW * 4;
    for (int x = 0; x < dstW; ++x) {
      float b = 0, g = 0, r = 0;
      for (size_t k = 0; k < t.w.size(); ++k) {
        int sy = t.start + (int)k; sy = sy < 0 ? 0 : (sy >= srcH ? srcH - 1 : sy);   // clamp to edge
        const float* p = tmp.data() + ((size_t)sy * dstW + x) * 3; float w = t.w[k];
        b += p[0] * w; g += p[1] * w; r += p[2] * w;
      }
      auto clamp8 = [](float v) -> uint8_t { v += 0.5f; return v <= 0 ? 0 : (v >= 255.0f ? 255 : (uint8_t)v); };
      uint8_t* d = drow + (size_t)x * 4;
      d[0] = clamp8(b); d[1] = clamp8(g); d[2] = clamp8(r); d[3] = 255;
    }
  }
}

}} // namespace avp::resample
