// video_preproc_demo.cpp — exercises + quantitatively verifies the module-2 video preprocess:
//   1) temporal IIR denoise (α=0.37): known clean frame + injected noise -> denoise -> measure the
//      per-pixel error vs clean drops (noise actually removed, not just "ran").
//   2) adaptive-QP (TextureMotion 6-threshold): a frame that is FLAT on the left, BUSY on the right
//      -> the QP map must give the busy side a coarser (more positive) offset than the flat side.
//   3) RAISR apply path: downscale 2x then upscale 2x; with a synthetic sharpening bank injected the
//      apply path must change pixels vs bilinear (structure real). Real trained bank = ⛔ boundary.
// Also runs the full chain on capture_frame0.bmp if present (real captured frame -> preprocessed BMP).
#include "preprocess/video_preprocess.hpp"
#include "preprocess/algo/zlt_raisr.hpp"
#include "capture/video_frame.hpp"
#include "capture/bmp_writer.hpp"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

using namespace avp;

// deterministic pseudo-noise (no RNG needed; stable across runs)
static uint32_t s_rng = 0x1234567u;
static int noise(int amp) { s_rng = s_rng * 1664525u + 1013904223u; return (int)((s_rng >> 9) % (2 * amp + 1)) - amp; }

// build a BGRA frame from a luma pattern (gray R=G=B=Y)
static VideoFrame gray_frame(const std::vector<uint8_t>& y, int w, int h) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA;
  f.data.resize((size_t)w * h * 4);
  for (int i = 0; i < w * h; ++i) { f.data[i * 4 + 0] = f.data[i * 4 + 1] = f.data[i * 4 + 2] = y[i]; f.data[i * 4 + 3] = 255; }
  return f;
}

// a synthetic RAISR filter bank: mild sharpening kernel for every bucket (exercises the apply path).
struct SharpenBank : recon::zlt::IFilterBank {
  int p; std::vector<float> k;
  explicit SharpenBank(int patch = 11) : p(patch), k((size_t)patch * patch, 0.f) {
    int c = p / 2; for (int i = 0; i < p * p; ++i) k[i] = 0.f;
    k[c * p + c] = 2.0f;                       // center +2
    k[(c - 1) * p + c] = k[(c + 1) * p + c] = k[c * p + c - 1] = k[c * p + c + 1] = -0.25f;  // minus neighbors
  }
  const float* filter(int) const override { return k.data(); }
  int patch() const override { return p; }
};

static double mean_abs_err(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b) {
  double s = 0; size_t n = a.size() < b.size() ? a.size() : b.size();
  for (size_t i = 0; i < n; ++i) s += std::abs((int)a[i] - (int)b[i]);
  return n ? s / n : 0;
}

int main() {
  std::printf("=== AV pipeline / module 2: VIDEO preprocess ===\n\n");
  const int W = 256, H = 256;

  // ---- 1) DENOISE: clean pattern + injected noise, run several frames, measure error vs clean ----
  // Compare in the LUMA domain: the clean reference is the noise-free frame's BT.601 luma (denoise
  // runs on that plane), so we isolate noise removal from the RGB->luma range compression.
  std::vector<uint8_t> clean((size_t)W * H);
  for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) clean[(size_t)y * W + x] = (uint8_t)((x ^ y) & 0xFF);  // static texture
  I420Image clean_luma; BgraToI420(gray_frame(clean, W, H), clean_luma);
  VideoPreprocessConfig dcfg; dcfg.denoise = true; dcfg.adaptive_qp = false; dcfg.raisr = false;
  VideoPreprocessor denoiser(dcfg);
  double noisy_err = 0, den_err = 0; const int FR = 24, WARM = 6;
  for (int t = 0; t < FR; ++t) {
    std::vector<uint8_t> noisy((size_t)W * H);
    for (size_t i = 0; i < noisy.size(); ++i) { int v = clean[i] + noise(24); noisy[i] = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v); }
    I420Image noisy_luma; BgraToI420(gray_frame(noisy, W, H), noisy_luma);          // noisy luma (pre-denoise)
    VideoPreprocessResult r; denoiser.Process(gray_frame(noisy, W, H), r);          // r.frame.y = denoised luma
    if (t >= WARM) { noisy_err += mean_abs_err(noisy_luma.y, clean_luma.y); den_err += mean_abs_err(r.frame.y, clean_luma.y); }
  }
  noisy_err /= (FR - WARM); den_err /= (FR - WARM);
  std::printf("1) temporal IIR denoise (alpha=0.37, zltCIIRDenoise)\n");
  std::printf("   luma mean|noisy-clean| = %.2f   ->   mean|denoised-clean| = %.2f   (%.0f%% noise removed)\n\n",
              noisy_err, den_err, 100.0 * (noisy_err - den_err) / (noisy_err > 0 ? noisy_err : 1));

  // ---- 2) ADAPTIVE-QP: flat left half, busy+moving right half. Two frames so the motion metric has
  //         a reference: the busy half is re-randomized between frames (texture AND motion), the flat
  //         half is static. Busy blocks should get a coarser (more positive) QP; flat blocks finer. ----
  auto make_split = [&](int seedmix) {
    std::vector<uint8_t> s((size_t)W * H);
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x)
      s[(size_t)y * W + x] = (x < W / 2) ? 128 : (uint8_t)(128 + noise(90) + seedmix * 0);  // flat | busy(random)
    return s;
  };
  VideoPreprocessConfig qcfg; qcfg.denoise = false; qcfg.adaptive_qp = true; qcfg.raisr = false; qcfg.qp_block = 16;
  VideoPreprocessor qp(qcfg);
  VideoPreprocessResult q0, qr;
  qp.Process(gray_frame(make_split(0), W, H), q0);   // frame 1 (establishes motion reference)
  qp.Process(gray_frame(make_split(1), W, H), qr);   // frame 2 (busy half moved) -> use this map
  double flat_sum = 0, busy_sum = 0; int flat_n = 0, busy_n = 0;
  for (int by = 0; by < qr.qp_bh; ++by) for (int bx = 0; bx < qr.qp_bw; ++bx) {
    int d = qr.qp_delta[(size_t)by * qr.qp_bw + bx];
    if (bx < qr.qp_bw / 2) { flat_sum += d; ++flat_n; } else { busy_sum += d; ++busy_n; }
  }
  std::printf("2) adaptive-QP (TextureMotion 6-threshold ladder, 2 frames)\n");
  std::printf("   flat/static region mean QP delta = %+.2f   busy/moving region mean QP delta = %+.2f\n",
              flat_sum / flat_n, busy_sum / busy_n);
  std::printf("   %s (busy+moving blocks get coarser QP to save bits; flat/static kept fine)\n\n",
              (busy_sum / busy_n) > (flat_sum / flat_n) ? "OK" : "UNEXPECTED");

  // ---- 3) RAISR apply path: downscale then upscale; synthetic bank must change pixels vs bilinear ----
  std::vector<uint8_t> small_((size_t)(W / 2) * (H / 2));
  for (int y = 0; y < H / 2; ++y) for (int x = 0; x < W / 2; ++x) small_[(size_t)y * (W / 2) + x] = clean[(size_t)(y * 2) * W + (x * 2)];
  recon::zlt::RaisrConfig rc; rc.scale = 2;
  recon::zlt::PassthroughFilterBank pass(rc.patch); SharpenBank sharp(rc.patch);
  std::vector<uint8_t> up_bilinear, up_sharp; int ow = 0, oh = 0, ow2 = 0, oh2 = 0;
  recon::zlt::RaisrUpscaler(rc, &pass).Upscale(small_.data(), W / 2, H / 2, up_bilinear, ow, oh);
  recon::zlt::RaisrUpscaler(rc, &sharp).Upscale(small_.data(), W / 2, H / 2, up_sharp, ow2, oh2);
  std::printf("3) RAISR super-res apply (classify -> hashed filter -> blend)\n");
  std::printf("   upscaled %dx%d -> %dx%d   passthrough vs synthetic-bank mean|delta| = %.2f\n",
              W / 2, H / 2, ow, oh, mean_abs_err(up_bilinear, up_sharp));
  std::printf("   structure runs; the real learned filter bank is a WEIGHTS boundary (not reproduced)\n\n");

  // ---- optional: real captured frame end-to-end ----
  VideoFrame f;
  if (read_bmp("capture_frame0.bmp", f)) {
    VideoPreprocessConfig full; full.denoise = true; full.adaptive_qp = true; full.raisr = false;
    VideoPreprocessor pp(full); VideoPreprocessResult r; pp.Process(f, r);
    VideoFrame outv; I420ToBgra(r.frame, outv);
    write_bmp("preproc_frame0.bmp", outv);
    std::printf("real frame: capture_frame0.bmp %dx%d -> denoised+QP(mean %+.2f) -> preproc_frame0.bmp\n\n", f.width, f.height, r.qp_mean);
  } else {
    std::printf("(capture_frame0.bmp not found — run capture_demo first to also test a real frame)\n\n");
  }

  std::printf("DONE (video preprocess verified: denoise reduces error, QP differentiates regions, RAISR applies)\n");
  return 0;
}
