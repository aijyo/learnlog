// screen_shared.hpp — Present-hook capture, consumer side (Zoom's backend ③, from CptShare).
// A producer (present_target.exe) hooks its swap chain's Present and copies each backbuffer into a
// keyed-mutex SHARED D3D11 texture (Zoom's CD3d11SharedHandleHelper), publishing the shared handle +
// size via a named file-mapping. This SharedSurfaceSource opens that shared texture from ANOTHER
// process and reads frames under the keyed mutex — the exact Present-hook -> shared-surface data path.
//
// (The cross-process DLL INJECTION that hooks a *foreign* app's Present is the fragile / anti-cheat-
//  sensitive part and is intentionally not automated; the mechanism it feeds is implemented here in
//  full and demonstrated across two processes with a self-hooking target.)
#pragma once
#include "video_source.hpp"
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <wrl/client.h>
#include <cstdint>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

namespace avp {

constexpr wchar_t kSharedMapName[] = L"Local\\AvpPresentHookShare";
struct SharedInfo { uint32_t magic; int width; int height; uint64_t handle; };  // magic 'AVPS'
constexpr uint32_t kSharedMagic = 0x53505641u;  // "AVPS"

// producer: publish the shared-texture handle + size (keep the returned mapping HANDLE open).
inline HANDLE PublishSharedInfo(const SharedInfo& info) {
  HANDLE m = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(SharedInfo), kSharedMapName);
  if (!m) return nullptr;
  void* p = MapViewOfFile(m, FILE_MAP_WRITE, 0, 0, sizeof(SharedInfo));
  if (p) { memcpy(p, &info, sizeof(info)); UnmapViewOfFile(p); }
  return m;
}
// consumer: read it.
inline bool ReadSharedInfo(SharedInfo& out) {
  HANDLE m = OpenFileMappingW(FILE_MAP_READ, FALSE, kSharedMapName);
  if (!m) return false;
  void* p = MapViewOfFile(m, FILE_MAP_READ, 0, 0, sizeof(SharedInfo));
  bool ok = false;
  if (p) { memcpy(&out, p, sizeof(out)); ok = (out.magic == kSharedMagic && out.width > 0); UnmapViewOfFile(p); }
  CloseHandle(m);
  return ok;
}

using Microsoft::WRL::ComPtr;

class SharedSurfaceSource : public IVideoSource {
public:
  bool open(const CaptureConfig&) override {
    UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
    if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags, nullptr, 0,
                                 D3D11_SDK_VERSION, &dev_, nullptr, &ctx_))) return false;
    SharedInfo info{};
    for (int i = 0; i < 50 && !ReadSharedInfo(info); ++i) Sleep(100);   // wait for the producer
    if (info.magic != kSharedMagic) return false;
    w_ = info.width; h_ = info.height;
    if (FAILED(dev_->OpenSharedResource((HANDLE)(uintptr_t)info.handle, IID_PPV_ARGS(&shared_)))) return false;
    if (FAILED(shared_.As(&mutex_))) return false;
    D3D11_TEXTURE2D_DESC d{};
    d.Width = w_; d.Height = h_; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    d.SampleDesc.Count = 1; d.Usage = D3D11_USAGE_STAGING; d.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    return SUCCEEDED(dev_->CreateTexture2D(&d, nullptr, &staging_));
  }
  bool grab(VideoFrame& out) override {
    if (!shared_ || !mutex_ || !staging_) return false;
    if (mutex_->AcquireSync(0, 100) != S_OK) { if (last_.valid()) { out = last_; return true; } return false; }
    ctx_->CopyResource(staging_.Get(), shared_.Get());
    mutex_->ReleaseSync(0);
    D3D11_MAPPED_SUBRESOURCE map{};
    if (FAILED(ctx_->Map(staging_.Get(), 0, D3D11_MAP_READ, 0, &map))) return false;
    out.width = w_; out.height = h_; out.stride = w_ * 4; out.format = PixelFormat::BGRA;
    LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); out.timestamp_us = c.QuadPart * 1000000 / f.QuadPart;
    out.data.resize((size_t)out.stride * h_);
    for (int y = 0; y < h_; ++y) memcpy(&out.data[(size_t)y * out.stride], (const uint8_t*)map.pData + (size_t)y * map.RowPitch, out.stride);
    ctx_->Unmap(staging_.Get(), 0);
    last_ = out;
    return true;
  }
  void close() override { staging_.Reset(); mutex_.Reset(); shared_.Reset(); ctx_.Reset(); dev_.Reset(); }
  const char* backend() const override { return "PresentHook-SharedSurface"; }
  int width() const override { return w_; }
  int height() const override { return h_; }
private:
  ComPtr<ID3D11Device> dev_; ComPtr<ID3D11DeviceContext> ctx_;
  ComPtr<ID3D11Texture2D> shared_, staging_; ComPtr<IDXGIKeyedMutex> mutex_;
  VideoFrame last_; int w_ = 0, h_ = 0;
};

}  // namespace avp
#endif
