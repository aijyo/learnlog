// audio_demo.cpp — exercises the WASAPI audio leg (§1.3): enumerate endpoints, then capture a few
// seconds from the microphone and from system-audio loopback, write each to a .wav, and report the
// measured signal level (peak / RMS in dBFS) so you can tell real audio from silence.
//
//   audio_demo [--seconds N] [--target mic|loopback|both]
#ifndef NOMINMAX
#define NOMINMAX          // keep windows.h's min/max macros from clobbering std::max/std::min
#endif
#include "capture/audio_wasapi.hpp"
#include "capture/audio_tone.hpp"
#include "capture/wav_writer.hpp"
#include <windows.h>
#include <algorithm>
#include <thread>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

using namespace avp;

// peak/RMS over an interleaved buffer, normalized to [-1,1] regardless of sample format.
static void measure(const AudioFormat& f, const std::vector<uint8_t>& pcm, double& peak, double& rms) {
  peak = 0.0; double sumsq = 0.0; size_t count = 0;
  if (f.is_float && f.bits == 32) {
    const float* s = reinterpret_cast<const float*>(pcm.data()); count = pcm.size() / 4;
    for (size_t i = 0; i < count; ++i) { double v = s[i]; peak = std::max(peak, std::fabs(v)); sumsq += v * v; }
  } else if (!f.is_float && f.bits == 16) {
    const int16_t* s = reinterpret_cast<const int16_t*>(pcm.data()); count = pcm.size() / 2;
    for (size_t i = 0; i < count; ++i) { double v = s[i] / 32768.0; peak = std::max(peak, std::fabs(v)); sumsq += v * v; }
  } else if (!f.is_float && f.bits == 32) {
    const int32_t* s = reinterpret_cast<const int32_t*>(pcm.data()); count = pcm.size() / 4;
    for (size_t i = 0; i < count; ++i) { double v = s[i] / 2147483648.0; peak = std::max(peak, std::fabs(v)); sumsq += v * v; }
  }
  rms = count ? std::sqrt(sumsq / count) : 0.0;
}
static double dbfs(double x) { return x > 1e-9 ? 20.0 * std::log10(x) : -120.0; }

// narrow a wide device name for clean console output (avoids %ls console-codepage tangling).
static std::string narrow(const std::wstring& w) {
  if (w.empty()) return "(unnamed)";
  int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
  std::string s(n, '\0');
  WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), s.data(), n, nullptr, nullptr);
  return s;
}

// capture `secs` seconds from one source into a WAV, printing level stats. If `play_tone`, a 440 Hz
// sine is played on the default speaker while capturing (used to self-verify the loopback path).
static bool capture_one(AudioTarget target, double secs, const char* wav_path, bool play_tone = false) {
  WasapiAudioSource src;
  AudioCaptureConfig cfg; cfg.target = target;
  if (!src.open(cfg)) { std::printf("  [%s] open failed (no endpoint?)\n", wav_path); return false; }
  std::thread tone;
  if (play_tone) { std::printf("  (playing a 440 Hz tone on the speaker to exercise loopback)\n");
                   tone = std::thread([secs]{ PlayToneBlocking(secs, 440.0, 0.25); }); }
  AudioFormat f = src.format();
  std::printf("  backend %-18s  %d Hz, %d ch, %d-bit %s\n",
              src.backend(), f.sample_rate, f.channels, f.bits, f.is_float ? "float" : "int");

  std::vector<uint8_t> all;
  const ULONGLONG t0 = GetTickCount64();
  const ULONGLONG stop = t0 + (ULONGLONG)(secs * 1000);
  int64_t total_frames = 0;
  while (GetTickCount64() < stop) {
    AudioFrame fr;
    if (!src.read(fr)) break;
    if (fr.frames > 0) { all.insert(all.end(), fr.data.begin(), fr.data.end()); total_frames += fr.frames; }
    Sleep(5);   // poll the shared-mode endpoint a bit faster than its ~10 ms period
  }
  src.close();
  if (tone.joinable()) tone.join();

  double peak = 0, rms = 0; measure(f, all, peak, rms);
  double dur = f.sample_rate ? double(total_frames) / f.sample_rate : 0.0;
  std::printf("  captured %.2fs (%lld frames, %zu bytes)  peak %.1f dBFS  rms %.1f dBFS  %s\n",
              dur, (long long)total_frames, all.size(), dbfs(peak), dbfs(rms),
              rms > 1e-4 ? "-> real signal" : "-> ~silence (quiet mic / no playback)");
  if (!write_wav(wav_path, f, all)) { std::printf("  WAV write failed\n"); return false; }
  std::printf("  saved %s\n", wav_path);
  return total_frames > 0;
}

int main(int argc, char** argv) {
  double secs = 3.0; std::string target = "both";
  for (int i = 1; i < argc; ++i) {
    if (!std::strcmp(argv[i], "--seconds") && i + 1 < argc) secs = atof(argv[++i]);
    else if (!std::strcmp(argv[i], "--target") && i + 1 < argc) target = argv[++i];
  }

  std::printf("=== AV pipeline / module 1: audio capture (WASAPI) ===\n");
  std::printf("audio endpoints:\n");
  auto devs = EnumerateAudioDevices();
  for (size_t i = 0; i < devs.size(); ++i) {
    const auto& d = devs[i];
    std::printf("  %2zu. %-8s %-9s %s\n", i, d.is_capture ? "capture" : "render",
                d.is_default ? "*default*" : "", narrow(d.name).c_str());
  }
  std::printf("\n");

  bool any = false;
  if (target == "mic" || target == "both") {
    std::printf("microphone (default capture endpoint):\n");
    any |= capture_one(AudioTarget::DefaultMic, secs, "mic_capture.wav");
    std::printf("\n");
  }
  if (target == "loopback" || target == "both") {
    std::printf("system audio (default render endpoint, loopback):\n");
    // self-verify loopback by playing a tone into the render endpoint while we capture it.
    any |= capture_one(AudioTarget::DefaultLoopback, secs, "loopback_capture.wav", /*play_tone=*/true);
    std::printf("\n");
  }
  std::printf(any ? "DONE (captured audio; play the .wav files to verify)\n"
                  : "DONE (endpoints opened; no frames — check that a mic/playback is active)\n");
  return any ? 0 : 1;
}
