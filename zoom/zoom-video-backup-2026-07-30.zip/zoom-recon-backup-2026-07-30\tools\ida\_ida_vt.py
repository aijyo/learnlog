# dump a vtable's slots + decompile them. ARGV[1]=out, ARGV[2]=vtable addr hex
import idc, ida_hexrays, ida_funcs, idautils
out = idc.ARGV[1]; vt = int(idc.ARGV[2], 16)
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
slots = []
ea = vt
for i in range(24):
    p = idc.get_qword(ea)
    if not ida_funcs.get_func(p): break
    slots.append(p); ea += 8
L.append("// vtable 0x%x: %d slots" % (vt, len(slots)))
for i, s in enumerate(slots):
    L.append("//  [%d] 0x%x  %s" % (i, s, idc.get_func_name(s)))
# constructors: who writes this vtable addr
ctors = sorted(set(idc.get_func_attr(x, idc.FUNCATTR_START) for x in idautils.DataRefsTo(vt) if ida_funcs.get_func(x)))
L.append("// ctors/refs: " + ", ".join("0x%x(%s)"%(c, idc.get_func_name(c)) for c in ctors if c != idc.BADADDR))
def decomp(ea, label):
    f = ida_funcs.get_func(ea)
    if not f: return
    try:
        L.append("\n// ===== %s  %s  (0x%x) =====" % (label, idc.get_func_name(f.start_ea), f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e: L.append("// FAIL 0x%x: %s" % (ea, e))
seen = set()
for i, s in enumerate(slots):
    if s in seen: continue
    seen.add(s); decomp(s, "slot%d" % i)
open(out, "w", encoding="utf-8", errors="replace").write("\n".join(L))
idc.qexit(0)
