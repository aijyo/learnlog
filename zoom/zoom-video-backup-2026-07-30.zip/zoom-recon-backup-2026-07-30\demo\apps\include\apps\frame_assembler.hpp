// frame_assembler.hpp — receiver-side reassembly of a frame from out-of-order UDP packets, recovering
// missing ones via MULTI-GROUP FEC (Zoom §4.1). A big frame is protected as several independent K+R
// groups; each group is recovered on its own (RS over its ≤256 shards), then the whole frame's source
// packets are concatenated. Packets are grouped by frame timestamp; old incomplete frames are dropped.
#pragma once
#include "conference/media_channel.hpp"
#include "protect/fec.hpp"
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <vector>

namespace avp {

struct AssembleStat { bool recovered = false; int dropped_pkts = 0; uint32_t ts = 0; };

class FrameAssembler {
public:
  void add(const WirePacket& w) {
    FrameBuf& fb = frames_[w.frame_ts];
    if (!w.is_fec) {
      fb.media[w.pkt.seq] = w.pkt;
      if (w.pkt.marker) { fb.have_marker = true; fb.marker_seq = w.pkt.seq; }
    } else {
      Group& g = fb.groups[w.fec.base_seq];
      g.k = w.fec.k; g.fecs.push_back(w.fec);
    }
  }

  // Deliver frames STRICTLY in timestamp order (a decoder needs them in order — pops out of order
  // break the P-frame reference chain). Only the oldest frame is considered: if it isn't ready we wait,
  // unless too many frames have piled up behind it (it's stuck on unrecoverable loss) — then drop it
  // and move on. Returns the next in-order complete/recovered frame, or false if none ready yet.
  bool try_pop(std::vector<uint8_t>& au, AssembleStat& st) {
    while (!frames_.empty()) {
      auto it = frames_.begin();
      if (have_last_ && it->first <= last_ts_) { frames_.erase(it); continue; }   // stale / already delivered
      FrameBuf& fb = it->second;

      // 1) recover each FEC group in place (fills fb.media)
      int dropped = 0; bool recovered = false;
      for (auto& gp : fb.groups) {
        const uint16_t gbase = gp.first; const int gk = gp.second.k; if (gk <= 0) continue;
        int present = 0;
        for (int i = 0; i < gk; ++i) if (fb.media.count((uint16_t)(gbase + i))) ++present;
        if (present == gk) continue;
        if (present + (int)gp.second.fecs.size() < gk) continue;
        std::vector<std::vector<uint8_t>> pay(gk); std::vector<char> pres(gk, 0);
        for (int i = 0; i < gk; ++i) { auto m = fb.media.find((uint16_t)(gbase + i)); if (m != fb.media.end()) { pay[i] = m->second.payload; pres[i] = 1; } }
        auto rec = FecDecoder::recover(pay, pres, gp.second.fecs);
        if (rec.empty()) continue;
        for (int i = 0; i < gk; ++i) if (!pres[i]) { MediaPacket mp; mp.seq = (uint16_t)(gbase + i); mp.timestamp = it->first; mp.payload = rec[i]; fb.media[mp.seq] = mp; ++dropped; }
        recovered = true;
      }

      // 2) is this (oldest) frame complete?
      bool ready = false; uint16_t base = 0, end = 0;
      if (!fb.media.empty()) {
        base = fb.media.begin()->first;
        if (!fb.groups.empty() && fb.groups.begin()->first < base) base = fb.groups.begin()->first;
        bool have_end = false;
        if (fb.have_marker) { end = fb.marker_seq; have_end = true; }
        else if (!fb.groups.empty()) { auto& last = *fb.groups.rbegin(); end = (uint16_t)(last.first + last.second.k - 1); have_end = true; }
        if (have_end) { ready = true; for (uint16_t s = base;; ++s) { if (!fb.media.count(s)) { ready = false; break; } if (s == end) break; } }
      }

      if (ready) {
        au.clear();
        for (uint16_t s = base;; ++s) { au.insert(au.end(), fb.media[s].payload.begin(), fb.media[s].payload.end()); if (s == end) break; }
        st.recovered = recovered; st.dropped_pkts = dropped; st.ts = it->first;
        last_ts_ = it->first; have_last_ = true;
        frames_.erase(it);
        return true;
      }
      // Oldest not ready. Give up ONLY if it's genuinely STALLED — no new packet has arrived for it
      // across many polls (a truly lost packet) — NOT merely because newer frames queued behind it.
      // A big keyframe arrives over hundreds of packets while the tiny P-frames behind it complete
      // instantly; dropping the still-arriving keyframe here poisons the whole GOP (the screen-share
      // "0 decoded even at 0% loss" bug). Any new media/FEC packet (incl. a FEC-recovered one) is
      // progress and resets patience; only a real stall, or a hard queue cap, evicts the frame.
      size_t cur = fb.media.size(); for (auto& gp : fb.groups) cur += gp.second.fecs.size();
      if (cur != fb.last_pkts) { fb.last_pkts = cur; fb.idle_polls = 0; return false; }   // still arriving → wait
      if (++fb.idle_polls < kStallPolls && frames_.size() < kMaxQueue) return false;      // patient
      bool by_cap = frames_.size() >= kMaxQueue;
      if (std::getenv("AVP_EVICT")) std::fprintf(stderr, "EVICT ts=%u reason=%s media=%zu groups=%zu marker=%d queued=%zu idle=%d\n",
        it->first, by_cap ? "cap" : "stall", fb.media.size(), fb.groups.size(), (int)fb.have_marker, frames_.size(), fb.idle_polls);
      frames_.erase(it); ++evicted_; if (by_cap) ++evicted_cap_; else ++evicted_stall_;   // stalled or hard cap → PICTURE LOST → PLI trigger
    }
    return false;
  }

  // Whole pictures given up as unrecoverable since the last call (a lost picture breaks the P-frame ref
  // chain -> the receiver should request a fresh key: Zoom SetKeyPictureRequest / RTCP PLI).
  int take_evicted() { int e = evicted_; evicted_ = 0; return e; }

  // how many frames are queued (delivered-or-waiting) — a "we've fallen behind" signal for the receiver's
  // catch-up (an overloaded peer skips the stale backlog instead of decoding seconds of it).
  size_t pending() const { return frames_.size(); }

private:
  static constexpr int    kStallPolls = 120;   // ~no-new-packet polls before declaring loss (~100ms+)
  static constexpr size_t kMaxQueue   = 240;    // hard cap on queued frames (~20s @12fps) — memory bound
  int evicted_ = 0;                             // whole pictures given up since take_evicted() (PLI trigger)
public:
  int evicted_stall_ = 0, evicted_cap_ = 0;     // eviction-reason diagnostics (stall vs hard queue cap)
private:
  struct Group { int k = 0; std::vector<FecPacket> fecs; };
  struct FrameBuf {
    std::map<uint16_t, MediaPacket> media;
    std::map<uint16_t, Group> groups;
    bool have_marker = false; uint16_t marker_seq = 0;
    size_t last_pkts = 0; int idle_polls = 0;   // stall detection: packets seen last poll, polls w/o growth
  };
  std::map<uint32_t, FrameBuf> frames_;
  uint32_t last_ts_ = 0; bool have_last_ = false;
};

}  // namespace avp
