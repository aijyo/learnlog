// receive_demo.cpp — modules 6-8 + the WHOLE-PIPELINE loop (AV_PIPELINE_DETAILS.html §6/§7/§8).
// Send side (mod 1-5) -> a reordering, lossy channel -> receive side (mod 6-8):
//   preprocess -> H.264 encode -> packetize -> FEC  ||  shuffle + drop  ||  jitter buffer (reorder,
//   RFC3550 jitter) -> FEC recover -> reassemble AU -> decode (FFmpeg) -> PSNR -> render BMP.
// Audio: AAC encode -> decode -> WAV. Proves the reconstructed pipeline runs end to end on real codecs.
#include "receive/jitter_buffer.hpp"
#include "receive/renderer.hpp"
#include "protect/fec.hpp"
#include "protect/packetizer.hpp"
#include "encode/h264_encoder.hpp"
#include "preprocess/video_preprocess.hpp"
#ifdef AVP_WITH_FFMPEG
#include "encode/h264_decode_verify.hpp"    // H264Decoder, PsnrY
#include "encode/audio_encoder.hpp"         // AacEncoder
#include "receive/audio_decoder.hpp"        // AacDecoder
#include "preprocess/wav_reader.hpp"
#endif
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <vector>

using namespace avp;

static uint32_t rng = 0x9E3779B1;
static int ri(int n) { rng = rng * 1664525u + 1013904223u; return (int)((rng >> 8) % n); }

static I420Image gradient_i420(int w, int h, int t) {
  I420Image im; im.w = w; im.h = h;
  im.y.assign((size_t)w * h, 0); im.u.assign((size_t)im.cw() * im.ch(), 128); im.v.assign((size_t)im.cw() * im.ch(), 128);
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) im.y[(size_t)y * w + x] = (uint8_t)((x + y + t * 4) & 0xFF);
  return im;
}

int main() {
  std::printf("=== AV pipeline / modules 6-8: RECEIVE + full-pipeline loop ===\n\n");
  int fail = 0;
  const int W = 320, H = 240;

  // ---- send side: encode a frame, packetize, protect ----
  VideoEncoderConfig ec; ec.width = W; ec.height = H; ec.fps = 30; ec.bitrate_bps = 1500000;
  H264Encoder enc; enc.open(ec);
  I420Image src = gradient_i420(W, H, 0);
  EncodedFrame frame = enc.encode(src, true);          // IDR
  Packetizer pk(1100); auto pkts = pk.packetize(frame.data, 3000);  // ts=3000, marker on last
  int K = (int)pkts.size(); int level = SelectFecLevel(0.08);
  FecEncoder fenc; auto fecs = fenc.protect(pkts, level);
  std::printf("send: %d B H.264 -> %d media packets + %d FEC (L%d)\n", frame.size(), K, level, level);

  // ---- channel: shuffle arrival order + drop up to `level` source packets ----
  struct Arr { MediaPacket p; bool is_fec; FecPacket f; int64_t recv_us; };
  std::vector<Arr> wire;
  std::vector<char> src_present(K, 1); int drops = level < K ? level : K - 1;
  for (int d = 0; d < drops; ++d) src_present[ri(K)] = 0;                 // lose some source packets
  for (int i = 0; i < K; ++i) if (src_present[i]) wire.push_back({ pkts[i], false, {}, 0 });
  for (auto& f : fecs) { MediaPacket mp; wire.push_back({ mp, true, f, 0 }); }   // FEC packets all arrive
  for (int i = (int)wire.size() - 1; i > 0; --i) std::swap(wire[i], wire[ri(i + 1)]);   // shuffle order
  int64_t clk = 0; for (auto& a : wire) { clk += 2500 + ri(4000); a.recv_us = clk; }    // arrival + jitter

  // ---- receive side: jitter buffer (reorder) + collect FEC ----
  JitterBuffer jb(90000);
  std::vector<FecPacket> got_fec;
  int lost_src = 0; for (int i = 0; i < K; ++i) if (!src_present[i]) ++lost_src;
  for (auto& a : wire) { if (a.is_fec) got_fec.push_back(a.f); else jb.insert(a.p, a.recv_us); }
  std::printf("recv: %d/%d source arrived (%d lost, reordered), jitter=%.1f ms, playout target=%.0f ms\n",
              K - lost_src, K, lost_src, jb.jitter_ms(), jb.target_delay_ms());

  // ---- FEC recover the lost source packets, feed them back into the jitter buffer ----
  std::vector<std::vector<uint8_t>> srcpay(K);
  for (int i = 0; i < K; ++i) srcpay[i] = src_present[i] ? pkts[i].payload : std::vector<uint8_t>{};
  auto rec = FecDecoder::recover(srcpay, src_present, got_fec);
  if (!rec.empty()) for (int i = 0; i < K; ++i) if (!src_present[i]) {
    MediaPacket mp = pkts[i]; mp.payload = rec[i]; jb.insert(mp, clk += 3000);   // recovered -> buffer
  }

  // ---- reassemble the access unit and compare byte-for-byte to the encoded frame ----
  std::vector<uint8_t> au; uint32_t ts = 0;
  bool popped = jb.pop_frame(au, ts);
  bool identical = popped && au == frame.data;
  std::printf("reassemble: popped=%d, ts=%u, AU==encoded frame: %s  %s\n",
              (int)popped, ts, identical ? "yes (byte-identical)" : "no", identical ? "OK" : (++fail, "FAIL"));

  // ---- decode + render ----
#ifdef AVP_WITH_FFMPEG
  if (identical) {
    H264Decoder dec; dec.open(); I420Image out;
    if (dec.decode(au, out) && out.w == W) {
      double psnr = PsnrY(src, out);
      VideoRenderer vr; vr.present(out, "received_frame0.bmp");
      std::printf("decode+render: FFmpeg H.264 -> %dx%d, luma PSNR=%.1f dB vs source -> received_frame0.bmp  %s\n",
                  out.w, out.h, psnr, psnr > 30 ? "OK" : (++fail, "FAIL"));
    } else { std::printf("decode FAILED\n"); ++fail; }
  }
#else
  std::printf("decode+render: (build -DAVP_WITH_FFMPEG=ON to decode the recovered H.264 + PSNR + BMP)\n");
#endif
  std::printf("\n");

  // ---- audio loop: AAC encode -> decode -> WAV ----
#ifdef AVP_WITH_FFMPEG
  {
    std::vector<float> in; int rate = 48000;
    if (!read_wav_mono("mic_preprocessed.wav", in, rate) && !read_wav_mono("mic_capture.wav", in, rate)) {
      in.resize(48000); for (size_t i = 0; i < in.size(); ++i) in[i] = 0.3f * std::sin(2 * 3.14159265f * 440 * i / rate);
      std::printf("audio: (synthetic 440 Hz, no WAV found)\n");
    } else std::printf("audio: mic_preprocessed.wav %d Hz %.2fs\n", rate, (double)in.size() / rate);
    AacEncoder aenc; AacDecoder adec;
    if (aenc.open(rate, 1, 64000)) {
      std::vector<EncodedAudio> pkts_a; aenc.encode(in.data(), (int)in.size(), pkts_a);
      auto tail = aenc.flush(); pkts_a.insert(pkts_a.end(), tail.begin(), tail.end());
      adec.open(aenc.extradata(), aenc.extradata_size(), rate, 1);
      std::vector<float> outpcm; for (auto& p : pkts_a) adec.decode(p.data.data(), p.size(), outpcm);
      AudioRenderer ar; ar.append(outpcm); ar.save_wav("received_audio.wav", rate);
      double ein = 0, eout = 0; for (float v : in) ein += v * v; for (float v : outpcm) eout += v * v;
      double ratio = ein > 0 ? std::sqrt(eout / ein) : 0;
      std::printf("audio loop: %zu AAC pkts -> decoded %zu samples, energy ratio %.2f -> received_audio.wav  %s\n\n",
                  pkts_a.size(), outpcm.size(), ratio, (outpcm.size() > in.size() / 2 && ratio > 0.5 && ratio < 1.6) ? "OK" : (++fail, "FAIL"));
      if (getenv("AVP_PLAY")) PlayPcmBlocking(outpcm, rate);
    }
  }
#endif

  std::printf(fail ? "SOME CHECKS FAILED (%d)\n" : "ALL PASS — full pipeline: capture->...->transport->jitter->FEC->decode->render\n", fail);
  return fail ? 1 : 0;
}
