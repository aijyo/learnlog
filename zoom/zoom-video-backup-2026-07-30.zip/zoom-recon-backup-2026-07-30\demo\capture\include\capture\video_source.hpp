// video_source.hpp — the capture interface every backend implements. Mirrors Zoom's model:
// a source is opened for a target (monitor / window / camera), then frames are pulled (or pushed).
// Zoom probes capability and picks a backend by priority (WGC -> Magnification/Duplication ->
// injection); here the factory (capture_factory.hpp) does the same for the screen backends.
#pragma once
#include "video_frame.hpp"
#include <functional>
#include <string>

namespace avp {

enum class CaptureTarget { PrimaryMonitor, MonitorIndex, Camera };

struct CaptureConfig {
  CaptureTarget target = CaptureTarget::PrimaryMonitor;
  int           monitor_index = 0;      // for MonitorIndex
  int           camera_index = 0;       // for Camera
  int           target_fps = 30;
  bool          capture_cursor = true;  // WGC/duplication include the cursor
  int           want_width = 0;         // camera preferred format (0 = source default)
  int           want_height = 0;
};

// Pull-model source: open() -> grab() repeatedly -> close(). Simple + deterministic to test.
struct IVideoSource {
  virtual ~IVideoSource() = default;
  virtual bool         open(const CaptureConfig& cfg) = 0;
  virtual bool         grab(VideoFrame& out) = 0;   // next frame; false if none this instant / lost
  virtual void         close() = 0;
  virtual const char*  backend() const = 0;         // e.g. "DXGI-DesktopDuplication"
  virtual int          width() const = 0;
  virtual int          height() const = 0;
};

}  // namespace avp
