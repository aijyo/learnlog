// screen_dxgi.hpp — DXGI Desktop Duplication screen capture (Windows 8+). The GPU path: the OS
// composites the desktop and hands us a shared D3D11 texture; we copy it to a CPU-readable staging
// texture and hand out BGRA. This is one of Zoom's fallbacks below WGC; low overhead, but only
// whole-monitor (not per-window) and unavailable in Session 0 / secure desktop.
#pragma once
#include "video_source.hpp"
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <wrl/client.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

namespace avp {

using Microsoft::WRL::ComPtr;

class DxgiScreenSource : public IVideoSource {
public:
  bool open(const CaptureConfig& cfg) override {
    D3D_FEATURE_LEVEL fl;
    UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
    if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags, nullptr, 0,
                                 D3D11_SDK_VERSION, &dev_, &fl, &ctx_))) return false;
    ComPtr<IDXGIDevice> dxgiDev;
    if (FAILED(dev_.As(&dxgiDev))) return false;
    ComPtr<IDXGIAdapter> adapter;
    if (FAILED(dxgiDev->GetAdapter(&adapter))) return false;
    ComPtr<IDXGIOutput> output;
    UINT idx = (cfg.target == CaptureTarget::MonitorIndex) ? (UINT)cfg.monitor_index : 0;
    if (FAILED(adapter->EnumOutputs(idx, &output))) return false;
    DXGI_OUTPUT_DESC od{}; output->GetDesc(&od);
    w_ = od.DesktopCoordinates.right - od.DesktopCoordinates.left;
    h_ = od.DesktopCoordinates.bottom - od.DesktopCoordinates.top;
    ComPtr<IDXGIOutput1> output1;
    if (FAILED(output.As(&output1))) return false;
    if (FAILED(output1->DuplicateOutput(dev_.Get(), &dupl_))) return false;   // needs a desktop session
    return w_ > 0 && h_ > 0;
  }

  bool grab(VideoFrame& out) override {
    if (!dupl_) return false;
    DXGI_OUTDUPL_FRAME_INFO info{};
    ComPtr<IDXGIResource> res;
    HRESULT hr = dupl_->AcquireNextFrame(200, &info, &res);
    if (hr == DXGI_ERROR_WAIT_TIMEOUT) {                             // no screen change -> reuse last frame
      if (last_.valid()) { out = last_; out.timestamp_us = now_us(); return true; }
      return false;
    }
    if (FAILED(hr)) { reset_(); return false; }                     // e.g. ACCESS_LOST -> caller retries/reopens
    bool ok = false;
    ComPtr<ID3D11Texture2D> tex;
    if (SUCCEEDED(res.As(&tex))) {
      ensure_staging_(tex.Get());
      if (staging_) {
        ctx_->CopyResource(staging_.Get(), tex.Get());
        D3D11_MAPPED_SUBRESOURCE map{};
        if (SUCCEEDED(ctx_->Map(staging_.Get(), 0, D3D11_MAP_READ, 0, &map))) {
          out.width = w_; out.height = h_; out.stride = w_ * 4; out.format = PixelFormat::BGRA;
          out.timestamp_us = now_us();
          out.data.resize((size_t)out.stride * h_);
          const uint8_t* src = (const uint8_t*)map.pData;
          for (int y = 0; y < h_; ++y) memcpy(&out.data[(size_t)y * out.stride], src + (size_t)y * map.RowPitch, out.stride);
          ctx_->Unmap(staging_.Get(), 0);
          last_ = out;                    // cache for static-screen (timeout) reuse
          ok = true;
        }
      }
    }
    dupl_->ReleaseFrame();
    return ok;
  }

  void close() override { dupl_.Reset(); staging_.Reset(); ctx_.Reset(); dev_.Reset(); }
  const char* backend() const override { return "DXGI-DesktopDuplication"; }
  int width() const override { return w_; }
  int height() const override { return h_; }

private:
  void ensure_staging_(ID3D11Texture2D* src) {
    if (staging_) return;
    D3D11_TEXTURE2D_DESC d{}; src->GetDesc(&d);
    d.Usage = D3D11_USAGE_STAGING; d.BindFlags = 0; d.MiscFlags = 0;
    d.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    dev_->CreateTexture2D(&d, nullptr, &staging_);
  }
  void reset_() { dupl_.Reset(); staging_.Reset(); }
  static int64_t now_us() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return c.QuadPart * 1000000 / f.QuadPart; }

  ComPtr<ID3D11Device> dev_;
  ComPtr<ID3D11DeviceContext> ctx_;
  ComPtr<IDXGIOutputDuplication> dupl_;
  ComPtr<ID3D11Texture2D> staging_;
  VideoFrame last_;
  int w_ = 0, h_ = 0;
};

}  // namespace avp
#endif
