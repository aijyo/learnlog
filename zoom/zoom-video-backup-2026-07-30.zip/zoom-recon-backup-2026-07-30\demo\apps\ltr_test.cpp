// ltr_test.cpp — LONG-TERM REFERENCE (LTR) loss recovery, the Zoom mechanism (实证): on a loss/corruption
// the receiver asks (KeyPicture request, carries last_received_pic_id) for recovery from a CLEAN LONG-TERM
// REFERENCE instead of a full IDR — the sender encodes the next frame as a P-frame referencing that LTR,
// which the decoder still holds, so it recovers cheaply (no expensive keyframe). RE: zlt bLtrFlag ->
// max_long_term_reference_frames=1; "花屏时不发完整 IDR,而是参考一个干净的长期参考帧发 P 帧". Zoom keeps
// 1 LTR slot; VP9's GOLDEN frame is exactly a long-term reference, so we drive it via libvpx directly
// (avcodec can't manage refs — same reason SVC lives in svc_test). Proves: LTR-recovery frame ≪ a keyframe,
// and it recovers a decoder that missed frames, WITHOUT an IDR.
#include "preprocess/video_convert.hpp"
#include <cstdio>
#include <cstring>
#include <vector>
extern "C" {
#include "vpx/vpx_encoder.h"
#include "vpx/vp8cx.h"
#include "vpx/vpx_decoder.h"
#include "vpx/vp8dx.h"
#include "vpx/vpx_image.h"
}

using namespace avp;
static const int W = 640, H = 360, FRAMES = 40;

// A moving scene so P-frames carry real residual (a static scene would make every frame ~free and hide the point).
static void fill(vpx_image_t* img, int t) {
  for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
    int v = ((x / 6 + y / 6) & 1) ? 210 : 40;                  // fine checker (high-freq detail)
    if (((x + t * 11) % 200) < 100) v = 128 + ((x + t) % 60);  // moving band -> real inter residual
    img->planes[0][(size_t)y * img->stride[0] + x] = (uint8_t)v;
  }
  for (int p = 1; p <= 2; ++p) for (int y = 0; y < H / 2; ++y)
    memset(img->planes[p] + (size_t)y * img->stride[p], 128, W / 2);
}

int main() {
  vpx_codec_ctx_t enc{}; vpx_codec_enc_cfg_t cfg{};
  vpx_codec_enc_config_default(vpx_codec_vp9_cx(), &cfg, 0);
  cfg.g_w = W; cfg.g_h = H; cfg.g_timebase = { 1, 30 }; cfg.rc_target_bitrate = 800;
  cfg.rc_end_usage = VPX_CBR; cfg.g_lag_in_frames = 0; cfg.g_error_resilient = 1;
  cfg.kf_mode = VPX_KF_DISABLED; cfg.kf_max_dist = 99999;      // no auto keyframes — recovery must come from LTR
  if (vpx_codec_enc_init(&enc, vpx_codec_vp9_cx(), &cfg, 0)) { std::printf("enc init failed\n"); return 1; }
  vpx_codec_control(&enc, VP8E_SET_CPUUSED, 7);
  vpx_image_t img; vpx_img_alloc(&img, VPX_IMG_FMT_I420, W, H, 1);

  vpx_codec_ctx_t dec{}; vpx_codec_dec_init(&dec, vpx_codec_vp9_dx(), nullptr, 0);

  const int kLtrPeriod = 8;                 // refresh the long-term reference (golden) every 8 frames
  const int kLostFrom = 20, kLostTo = 23;   // simulate a burst loss: frames 20..23 never reach the decoder
  int last_good_ltr = 0;                    // pic id of the last LTR the DECODER is known to hold
  long ltr_recover_bytes = 0, keyframe_bytes = 0;
  int dec_ok = 0, dec_fail = 0; bool recovered_via_ltr = false;

  std::printf("\n  LTR loss recovery — VP9 golden frame as the long-term reference (Zoom KeyPicture/last_received_pic_id).\n");
  std::printf("  refresh LTR every %d frames; drop frames %d..%d; recover by referencing the LTR (no IDR).\n", kLtrPeriod, kLostFrom, kLostTo);
  std::printf("  ------------------------------------------------------------------------------------------------\n");

  for (int t = 0; t < FRAMES; ++t) {
    fill(&img, t);
    vpx_enc_frame_flags_t flags = 0;
    bool mark_ltr = (t % kLtrPeriod == 0 && t > 0);            // this frame becomes the new golden/LTR
    bool recover  = (t == kLostTo + 1);                        // first frame after the loss = LTR recovery
    if (t == 0) flags |= VPX_EFLAG_FORCE_KF;                   // one initial IDR to seed both sides
    if (mark_ltr) flags |= VP8_EFLAG_FORCE_GF | VP8_EFLAG_NO_UPD_ARF;   // update golden = new LTR
    if (recover) {
      // recover: reference ONLY the golden/LTR (which the decoder still holds), NOT last (the lost frame).
      // This is the "P from a clean LTR" — no full IDR. (VP9 rejects also pinning golden via NO_UPD_GF here.)
      flags |= VP8_EFLAG_NO_REF_LAST | VP8_EFLAG_NO_REF_ARF;
    }
    if (vpx_codec_encode(&enc, &img, t, 1, flags, VPX_DL_REALTIME)) { std::printf("encode %d failed: %s\n", t, vpx_codec_error_detail(&enc)); return 1; }

    vpx_codec_iter_t it = nullptr; const vpx_codec_cx_pkt_t* pkt;
    while ((pkt = vpx_codec_get_cx_data(&enc, &it))) {
      if (pkt->kind != VPX_CODEC_CX_FRAME_PKT) continue;
      const uint8_t* buf = (const uint8_t*)pkt->data.frame.buf; size_t sz = pkt->data.frame.sz;
      bool key = (pkt->data.frame.flags & VPX_FRAME_IS_KEY) != 0;
      if (recover) ltr_recover_bytes = (long)sz;
      // for a size reference, note a normal frame's typical size (a mid P-frame) and the initial keyframe
      if (t == 0) keyframe_bytes = (long)sz;

      bool dropped = (t >= kLostFrom && t <= kLostTo);         // simulate the network dropping this frame
      const char* tag = key ? "IDR" : mark_ltr ? "P+LTR(golden)" : recover ? "P<-LTR recover" : "P";
      if (dropped) { std::printf("  frame %2d %-14s %5zu B   [LOST on the wire]\n", t, tag, sz); continue; }

      if (vpx_codec_decode(&dec, buf, (unsigned)sz, nullptr, 0) == VPX_CODEC_OK) {
        vpx_codec_iter_t di = nullptr; vpx_image_t* out; bool got = false;
        while ((out = vpx_codec_get_frame(&dec, &di))) got = true;
        if (got) { ++dec_ok; if (recover) recovered_via_ltr = true;
                   std::printf("  frame %2d %-14s %5zu B   decoded OK%s\n", t, tag, sz, recover ? "  <== recovered from LTR, no IDR" : ""); }
        else { ++dec_fail; std::printf("  frame %2d %-14s %5zu B   decode: no output (broken refs)\n", t, tag, sz); }
      } else { ++dec_fail; std::printf("  frame %2d %-14s %5zu B   decode FAILED (missing reference)\n", t, tag, sz); }
      if (mark_ltr) last_good_ltr = t;
    }
  }

  std::printf("  ------------------------------------------------------------------------------------------------\n");
  std::printf("  decoded OK=%d fail=%d ; LTR recovery frame = %ld B vs initial IDR = %ld B (%.0f%% of an IDR)\n",
              dec_ok, dec_fail, ltr_recover_bytes, keyframe_bytes, keyframe_bytes ? 100.0 * ltr_recover_bytes / keyframe_bytes : 0);
  std::printf("  => after losing frames %d..%d, the stream recovered %s by referencing the clean LTR (last good = frame %d),\n",
              kLostFrom, kLostTo, recovered_via_ltr ? "SUCCESSFULLY" : "NOT", last_good_ltr);
  std::printf("     spending ~%ld B instead of a full IDR (~%ld B) — Zoom's LTR loss recovery.\n", ltr_recover_bytes, keyframe_bytes);
  vpx_img_free(&img); vpx_codec_destroy(&enc); vpx_codec_destroy(&dec);
  return 0;
}
