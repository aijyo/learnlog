# av-pipeline — a Zoom-style A/V pipeline, built module by module

Real, runnable Windows implementation of the A/V pipeline described in
`zoom-bin-analysis/AV_PIPELINE_DETAILS.html`, built one module at a time.

| # | module | status |
|---|--------|--------|
| **1** | **capture** (screen + camera + audio) | ✅ **done** — [`capture/`](capture/) |
| **2** | **preprocess** (video denoise/QP/RAISR + audio 3A) | ✅ **done** — [`preprocess/`](preprocess/) |
| **3** | **encode** (H.264 SVC + audio codec control) | ✅ **done** — [`encode/`](encode/) |
| **4** | **loss protection** (multi-FEC / NACK / PLC) | ✅ **done** — [`protect/`](protect/) |
| **5** | **transport** (UDP/TCP + congestion control + pacing) | ✅ **done** — [`transport/`](transport/) |
| **6–8** | **receive** (jitter buffer) / **decode** / **render** | ✅ **done** — [`receive/`](receive/) |

**Modules 6–8 — receive / decode / render** ([`receive/README.md`](receive/README.md)): the receive side
(§6/§7/§8). **Jitter buffer** (`jitter_buffer.hpp`) reorders by sequence, estimates RFC 3550 jitter,
holds a self-tuned playout delay, and reassembles access units. **Decode** uses real FFmpeg (H.264 →
I420, AAC → PCM). **Render** writes BMP / WAV (optional WASAPI playout). The demo runs the **entire
pipeline end to end** over a reordering + lossy channel: verified the recovered access unit is
byte-identical to the encoded frame, decodes to **44.6 dB** PSNR, and the audio loop round-trips at
energy ratio 1.00. **All 8 modules complete — a full send→receive pipeline on real codecs.**

## Integrated app — real-time loopback conference

[`conference/`](conference/) wires **all 8 modules into one process** that runs the whole pipeline in
real time. `conference_demo` paces a video stream through capture → preprocess → encode (layered) → FEC
→ channel → jitter buffer → FEC recover → decode → render at a target fps, plus the audio 3A → AAC →
decode path. The media channel is either an in-process loopback or **real UDP sockets** (packets
serialized to an RTP-like wire format and sent over winsock 127.0.0.1), and an optional
**congestion-control loop** adapts the encoder bitrate to the estimated bandwidth. Verified: **15.0 fps
hit**; at **9.2% loss every one of 45 frames still arrives byte-perfect** (FEC + jitter recover the
drops) decoding to **47.0 dB**; over real UDP **75/75 frames byte-intact**; and the CC target converges
to the bottleneck (**~967 kbps on an 800 kbps link, ~1676 on a 1500 kbps link**) — the whole weak-network
story (§4/§6/§9) live.

```powershell
cmake -S . -B build-ff -DAVP_WITH_FFMPEG=ON
cmake --build build-ff --config Release --target conference_demo
.\build-ff\conference\Release\conference_demo.exe --transport udp --loss 0.08          # real UDP + FEC
.\build-ff\conference\Release\conference_demo.exe --transport udp --cc --link-kbps 800  # + congestion control
```

### Two-process app + WPF monitor

[`apps/`](apps/) splits the conference into **two real OS processes** — `sender.exe` and `receiver.exe`
talking over a **real UDP socket** (127.0.0.1:50000) — with a **WPF (C#/.NET) monitor** that launches
them, shows the receiver's **live decoded video**, and mirrors both sides' stats via shared memory.
Verified: 60 frames sent cross-process and all 60 decoded, 6% loss FEC-recovered with 0 frames lost,
`sender.frame_index == receiver.frame_seq` (in sync), and .NET reads the C++ shared memory (live
320×240 BGRA frame + stats) — the same path the WPF `WriteableBitmap` paints from.
```powershell
cmake --build build-ff --config Release --target sender receiver   # C++ processes
dotnet run --project apps\AvpMonitor -c Release                     # WPF monitor (▶ Start)
```

**Module 5 — transport** ([`transport/README.md`](transport/README.md)): the media transport (§5 + §9
loop). **GCC-style congestion control** (`congestion.hpp`) — delay-based over-use detection (backs off
before loss) + loss-based, AIMD to `min(...)`. **Pacer** smooths bursts to the target. **Real winsock
UDP/TCP** (`socket_transport.hpp`) carry packets over loopback. **UDP→TCP fallback** (`transport_select.hpp`)
on a 2 s outage (§3.5). Verified: converges to **112%** of a 2 Mbps link then tracks a drop to 500 kbps,
100 UDP packets byte-intact, UDP→TCP→UDP fallback, 4 KB TCP echo byte-identical. The TLS/QUIC secure
layer is the separately-verified tp slice (real OpenSSL 3 / QUIC).

**Module 4 — loss protection** ([`protect/README.md`](protect/README.md)): the three §4 defenses. **FEC**
(`fec.hpp`) protects K source packets with R parity via the body-verified **RS(GF256, 0x11D)** nydus
engine, R adapting 3/4/5 by loss (mcm tiering). **NACK** (`nack.hpp`) detects gaps + resends from a
history buffer for bursts FEC can't cover. **PLC** (`plc.hpp`) extrapolates audio / freezes video as
last resort (DRED neural PLC = boundary). Verified: 200 groups recovered byte-exact, burst→NACK 5→
resend 5→complete, and a **real H.264 frame with all 4 packets dropped recovered byte-identical** from
parity. Engine + 3/4/5 tiering vendored from the verified `bin2cpp-output` reconstruction.

**Module 3 — encode** ([`encode/README.md`](encode/README.md)): the codec stage (§3). Video: **real H.264**
(minih264) driven by Zoom's reconstructed SVC control surface (`SetKeyPictureRequest`), dyadic ×0.5
temporal layering (30→15→7.5) with a **real droppable layered-reference structure** (LTR slots — a t≤1
sub-stream decodes at 44.8 dB while the same frames dropped from a plain stream collapse to 8.0 dB),
keyframe/LTR/IDR control, rate control, and screen-content detection (§3.4). Audio: the codec-switch
control surface (AI-codec 121 gate / SNAC state machine / SNAC-TCP fallback, §3.5) + real AAC-LC encode.
Verified: temporal ids `0 2 1 2…`, **encode→decode PSNR 37.7 dB** (FFmpeg H.264 decode), AAC 11.8×.
Real codec engines (zlt / AV1 SC core), Opus, and SNAC weights are boundaries; minih264 + FFmpeg AAC are
the real stand-in encoders.

**Module 2 — preprocess** ([`preprocess/README.md`](preprocess/README.md)): the encoder-side "perceptual
enhancement + entropy reduction" stage (§2). Video: BGRA→I420, temporal IIR denoise (α=0.37), adaptive-QP
hint map (TextureMotion 6-threshold), RAISR super-res (structure real, filter bank = ⛔). Audio 3A: NLMS
echo cancel, spectral-subtraction noise suppression, AGC, framing. Verified: denoise 55% noise removed,
QP −6 (flat) vs +4 (busy), AEC 18.5 dB ERLE, ANS 21 dB noise-floor attenuation, AGC → −18 dBFS target.
The three video algorithms are vendored unchanged from the body-verified `bin2cpp-output` reconstruction.

## Module 1 — capture

Mirrors Zoom's capture design (AV_PIPELINE_DETAILS.html §1): **capability-probe + priority fallback**
for the screen, a Media Foundation camera source, and a WASAPI audio leg (mic + system loopback).
Two parallel interfaces (`IVideoSource`, `IAudioSource`), one screen factory.

### Video

| backend | file | Zoom mapping (§1) | notes |
|---|---|---|---|
| **WGC** (Windows.Graphics.Capture) | `screen_wgc.hpp` | ① primary (CptUwpCapture) | GPU frame pool; per-monitor; Win10 2004+; opt-in `AVP_WITH_WGC` (needs cppwinrt) |
| **Magnification — Callback** | `screen_mag.hpp` | ② branch A (CptHost) | `MagSetImageScalingCallback` → real source bitmap; `MagSetWindowFilterList` excludes our own windows |
| **Magnification — DirectRead** | `screen_mag.hpp` | ② branch B (CptHost) | reads the magnifier window's rendered output (the "DX9 direct surface read" branch) |
| **Present-hook + shared surface** | `screen_shared.hpp` | ③ (CptShare) | reads a keyed-mutex `D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX` texture a hooked `Present` publishes; cross-process via named file-mapping + `OpenSharedResource` (`present_target.exe` is the self-hooking producer) |
| **DXGI Desktop Duplication** | `screen_dxgi.hpp` | ④ fallback | GPU; whole-monitor; Win8+ |
| **GDI BitBlt** | `screen_gdi.hpp` | universal last resort | CPU; works on any session (RDP / no-GPU) |
| **Media Foundation camera** | `camera_mf.hpp` | §1.2 (mfAdapter) | `IMFSourceReader`, RGB32, device enumeration |

### Audio (§1.3)

| backend | file | notes |
|---|---|---|
| **WASAPI — Microphone** | `audio_wasapi.hpp` | `IAudioClient` shared mode on the default **capture** endpoint (eCapture/eConsole) + `IAudioCaptureClient` drain loop |
| **WASAPI — Loopback** | `audio_wasapi.hpp` | same client on the default **render** endpoint with `AUDCLNT_STREAMFLAGS_LOOPBACK` = "share computer sound" |
| endpoint enumeration | `audio_wasapi.hpp` | `IMMDeviceEnumerator` over capture + render, friendly names, default markers |
| tone player (test aid) | `audio_tone.hpp` | `IAudioRenderClient` sine generator — plays into the speaker so loopback capture is self-verifying |
| WAV writer | `wav_writer.hpp` | RIFF/WAVE, PCM or IEEE-float |

3A (AEC / ANS / AGC) is deliberately **not** here — it's a *preprocess* concern and belongs to module 2.

Auto priority (factory `capture_factory.hpp`, `CreateBestScreenSource`): **WGC → DXGI → GDI** (probed,
fall back with reason). Any backend can also be selected by name: `--backend auto|wgc|dxgi|gdi|mag-cb|mag-dx`
(the Magnification modes need an interactive desktop session + a message pump, so they're not in the
silent auto-chain). This is the shape of Zoom's `CptHost` backend selection.

### Build & run
```powershell
cmake -S . -B build                 # DXGI + GDI + camera (WGC off)
cmake -S . -B build -DAVP_WITH_WGC=ON   # + WGC primary (needs Windows SDK cppwinrt)
cmake --build build --config Release
.\build\capture\Release\capture_demo.exe [--frames N] [--fps F] [--backend NAME]
```
The demo auto-selects the best screen backend, captures N frames, saves `capture_frame0.bmp`, reports
backend/resolution/FPS, then enumerates cameras and (if present) captures + saves `camera_frame0.bmp`.

**Present-hook ③ (cross-process), two terminals:**
```powershell
.\build\capture\Release\present_target.exe          # renders + hooks its own Present, publishes shared texture
.\build\capture\Release\capture_demo.exe --backend shared   # opens that texture from another process
```
`present_target` demonstrates the mechanism by hooking *its own* swap chain (the real vtable-slot-8
`Present` patch + keyed-mutex shared texture); the consumer reads it cross-process. Injecting the same
hook into a *foreign* app is the fragile / anti-cheat-sensitive part and is intentionally not automated.

**Audio (§1.3):**
```powershell
.\build\capture\Release\audio_demo.exe [--seconds N] [--target mic|loopback|both]
```
Enumerates endpoints, captures the mic and system-audio loopback (playing a 440 Hz tone so loopback is
self-verifying), reports peak/RMS in dBFS, and writes `mic_capture.wav` + `loopback_capture.wav`.

### Verified (this machine)
```
WGC-GraphicsCapture      1920x1080, ~19 fps, mean px 46  -> real desktop  (capture_frame0.bmp 8.1 MB)
Magnification-Callback   1920x1080, mean px 49            -> real source bitmap (via scaling callback)
Magnification-DirectRead 1920x1080, mean px 240           -> frame produced (reads mag-window output)*
PresentHook-SharedSurface 640x360, ~22 fps, mean px 122   -> cross-process capture of present_target.exe
                          producer reports "stopped after 52131 hooked presents" (vtable slot 8)
DXGI-DesktopDuplication  1920x1080 (when WGC off)         -> real frames
camera "Logi C270 HD WebCam" 640x480, 5 frames            -> camera_frame0.bmp (1.2 MB)
WASAPI-Microphone        48000 Hz/2ch/f32, 2.96s          -> real signal (peak -40 dBFS)  mic_capture.wav
WASAPI-Loopback          48000 Hz/2ch/f32, 2.96s          -> real signal (peak -12 dBFS, 440 Hz tone)  loopback_capture.wav
```
*DirectRead honesty: it captures the magnifier window's composited output; on our layered/transparent
host that output isn't the full desktop (hence the bright uniform mean). The **Callback** mode is the
faithful Magnification path here (it receives the actual source bitmap). Both modes are real & running.

### Architecture
```
IVideoSource { open(cfg); grab(VideoFrame&); close(); backend(); width/height }
   ├─ WgcScreenSource      (screen_wgc.hpp,  AVP_WITH_WGC)
   ├─ DxgiScreenSource     (screen_dxgi.hpp)
   ├─ GdiScreenSource      (screen_gdi.hpp)
   ├─ MagnifierScreenSource(screen_mag.hpp,  Callback | DirectRead)
   ├─ SharedSurfaceSource  (screen_shared.hpp, Present-hook ③)
   └─ MfCameraSource       (camera_mf.hpp)
IAudioSource { open(cfg); read(AudioFrame&); close(); backend(); format() }
   └─ WasapiAudioSource    (audio_wasapi.hpp, Microphone | Loopback)
VideoFrame { width, height, stride, format(BGRA/NV12), timestamp_us, data }   (video_frame.hpp)
AudioFrame { format(rate/ch/bits/float), timestamp_us, frames, data }         (audio_frame.hpp)
CreateBestScreenSource(cfg, notes) -> probes WGC→DXGI→GDI                      (capture_factory.hpp)
```
Pull model (`grab`) for deterministic testing; frames are BGRA (encoder-side NV12 conversion belongs to
module 2/3). DXGI/WGC cache the last frame so a static desktop still yields frames.

### Honest scope / not-yet-done
- **Magnification API (Zoom ②)**: ✅ **done** — both branches (Callback + DirectRead), `screen_mag.hpp`,
  incl. `MagSetWindowFilterList` self-exclude. (DirectRead's content fidelity is limited by the layered
  host — see the verified note above.)
- **Present-hook + shared surface (Zoom ③)**: ✅ **done** — `screen_shared.hpp` reads a keyed-mutex
  shared texture published by a hooked `Present`; demonstrated cross-process with `present_target.exe`
  (self-hooking producer). The remaining piece — *injecting* this hook into a **foreign** process — is
  fragile / anti-cheat-sensitive and intentionally left manual (the data path it feeds is complete here).
- **Audio capture (WASAPI + 3A, §1.3)**: ✅ **done** — `audio_capture.hpp` (WASAPI shared-mode mic +
  render-loopback), `audio_demo` writes a WAV. (3A — AEC/ANS/AGC — is a module-2 preprocess concern.)
- **Per-window / per-region WGC target**, **capture-side resolution/FPS adaptation (§1.4)**, and a
  **push/callback delivery model**: the interface is ready; these are incremental additions.
- WGC needs Win10 2004+ and a desktop session; on Session 0 / older OS the factory falls back to DXGI/GDI.

Clean-room, following Zoom's *design* (not its code). For interop / education.
