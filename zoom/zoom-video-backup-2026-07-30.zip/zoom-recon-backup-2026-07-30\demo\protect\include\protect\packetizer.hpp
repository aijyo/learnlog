// packetizer.hpp — module 4 packetization: a coded frame (module 3) becomes a sequence of RTP-like
// media packets, and back. Real, necessary step between the encoder and the network: a large frame is
// split to MTU-sized packets with sequence numbers / timestamps / a marker on the last packet.
#pragma once
#include <cstdint>
#include <vector>

namespace avp {

struct MediaPacket {
  uint16_t seq = 0;
  uint32_t timestamp = 0;    // media clock (e.g. 90 kHz video, sample-rate audio)
  uint8_t  payload_type = 96;
  bool     marker = false;   // last packet of an access unit
  std::vector<uint8_t> payload;
  int size() const { return (int)payload.size(); }
};

class Packetizer {
public:
  explicit Packetizer(int mtu = 1200, uint8_t pt = 96) : mtu_(mtu), pt_(pt) {}

  // split one coded access unit into packets; seq advances across calls.
  std::vector<MediaPacket> packetize(const std::vector<uint8_t>& au, uint32_t timestamp) {
    std::vector<MediaPacket> out;
    size_t off = 0;
    if (au.empty()) return out;
    while (off < au.size()) {
      size_t n = au.size() - off < (size_t)mtu_ ? au.size() - off : (size_t)mtu_;
      MediaPacket p; p.seq = next_seq_++; p.timestamp = timestamp; p.payload_type = pt_;
      p.payload.assign(au.begin() + off, au.begin() + off + n);
      off += n; p.marker = (off >= au.size());
      out.push_back(std::move(p));
    }
    return out;
  }
  uint16_t next_seq() const { return next_seq_; }

private:
  int mtu_; uint8_t pt_; uint16_t next_seq_ = 0;
};

// Reassemble an access unit from its (in-order, complete) packets — used to verify a recovered stream.
inline std::vector<uint8_t> reassemble(const std::vector<MediaPacket>& pkts) {
  std::vector<uint8_t> au;
  for (const auto& p : pkts) au.insert(au.end(), p.payload.begin(), p.payload.end());
  return au;
}

}  // namespace avp
