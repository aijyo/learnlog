// capture_demo.cpp — module 1 (capture) runnable demo.
// Auto-selects the best screen backend (Zoom-style probe/fallback), captures frames from the real
// desktop, saves the first as a BMP, and reports backend / resolution / achieved FPS.
#include "capture/capture_factory.hpp"
#include "capture/camera_mf.hpp"
#include "capture/bmp_writer.hpp"
#include <windows.h>
#include <cstdio>

using namespace avp;

static int64_t now_us() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return c.QuadPart * 1000000 / f.QuadPart; }

int main(int argc, char** argv) {
  CaptureConfig cfg;
  cfg.target = CaptureTarget::PrimaryMonitor;
  cfg.target_fps = 30;
  int N = 30;
  std::string backend = "auto";
  for (int i = 1; i + 1 < argc; ++i) {
    if (!strcmp(argv[i], "--frames"))  N = atoi(argv[i+1]);
    if (!strcmp(argv[i], "--fps"))     cfg.target_fps = atoi(argv[i+1]);
    if (!strcmp(argv[i], "--backend")) backend = argv[i+1];   // auto|wgc|dxgi|gdi|mag-cb|mag-dx
  }

  std::printf("=== AV pipeline / module 1: capture ===\n");
  std::printf("requested backend: %s\n", backend.c_str());
  std::string notes;
  auto src = CreateNamedScreenSource(backend, cfg, notes);
  if (!src) { std::printf("no screen backend available: %s\n", notes.c_str()); return 2; }
  std::printf("selected backend : %s  (%dx%d)\n", src->backend(), src->width(), src->height());
  std::printf("probe/fallback   : %s\n", notes.empty() ? "(primary backend used)" : notes.c_str());

  VideoFrame f, first;
  int got = 0;
  int64_t t0 = now_us();
  int budget = N * 6 + 60;  // allow retries (DXGI may time out on a static screen before the first real frame)
  while (got < N && budget-- > 0) {
    if (src->grab(f)) { if (got == 0) first = f; ++got; }
    Sleep(1000 / (cfg.target_fps > 0 ? cfg.target_fps : 30));
  }
  double secs = (now_us() - t0) / 1e6;
  double fps = secs > 0 ? got / secs : 0;
  std::printf("captured         : %d frames in %.2fs -> %.1f fps\n", got, secs, fps);

  bool saved = false;
  if (first.valid()) {
    saved = write_bmp("capture_frame0.bmp", first);
    std::printf("first frame      : %dx%d %s, %zu bytes ; saved BMP: %s\n",
                first.width, first.height, to_string(first.format), first.data.size(), saved ? "capture_frame0.bmp" : "(write failed)");
    // rough content signal: mean luma (headless/black desktop is fine — we assert structure, not content)
    uint64_t sum = 0; size_t px = first.data.size() / 4;
    for (size_t i = 0; i < px; ++i) sum += first.data[i * 4] + first.data[i * 4 + 1] + first.data[i * 4 + 2];
    std::printf("mean pixel value : %.1f (0=black)\n", px ? (double)sum / (px * 3) : 0.0);
  }

  src->close();

  // ---- camera (Media Foundation) — best-effort: enumerate + capture if a device exists ----
  std::printf("\n--- camera (Media Foundation) ---\n");
  auto cams = EnumerateCameras();
  std::printf("cameras found    : %zu\n", cams.size());
  for (size_t i = 0; i < cams.size(); ++i) std::printf("   [%zu] %s\n", i, cams[i].c_str());
  if (!cams.empty()) {
    CaptureConfig ccfg; ccfg.target = CaptureTarget::Camera; ccfg.camera_index = 0;
    MfCameraSource cam;
    if (cam.open(ccfg)) {
      std::printf("camera backend   : %s  (%dx%d)\n", cam.backend(), cam.width(), cam.height());
      VideoFrame cf; int cgot = 0;
      for (int i = 0; i < 15 && cgot < 5; ++i) { if (cam.grab(cf)) ++cgot; }
      if (cgot > 0 && cf.valid()) { write_bmp("camera_frame0.bmp", cf); std::printf("captured %d camera frames; saved camera_frame0.bmp (%dx%d)\n", cgot, cf.width, cf.height); }
      else std::printf("camera opened but no frames (device busy?)\n");
      cam.close();
    } else std::printf("camera present but could not open (in use / no RGB path)\n");
  } else {
    std::printf("(no camera on this machine — screen capture is the tested path)\n");
  }

  bool ok = got > 0 && first.valid() && first.width > 0 && first.height > 0 && saved;
  std::printf("\n%s\n", ok ? "ALL PASS (captured real frames)" : "FAIL");
  return ok ? 0 : 1;
}
