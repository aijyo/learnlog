// fec.hpp — module 4 packet-level multi-layer FEC (AV_PIPELINE_DETAILS.html §4.1). A group of K source
// packets is protected by R parity packets; any K of the K+R survive => the group is recovered with NO
// retransmission delay. R (the "3rd/4th/5th-level" count) rises with measured loss. The RS(GF256,0x11D)
// engine and the 3/4/5 tiering are the body-verified nydus/mcm reconstruction (vendored, algo/).
//
// Packet-level (not payload-level) FEC: each source packet is one shard, padded to the group's max
// length with a 2-byte length prefix so recovered shards carry their true size. This matches how RTP
// FEC (ULP/FlexFEC) protects a run of media packets, which is what §4.1 describes.
#pragma once
#include "packetizer.hpp"
#include "algo/rs_fec.hpp"
#include "algo/mcm_multifec.hpp"
#include <cstdint>
#include <vector>

namespace avp {

// loss-rate -> protection level {3,4,5} (mcm's exact tiering; thresholds inferred).
inline int SelectFecLevel(double loss_rate) { return recon::mcm::MultiFecPolicy::SelectLevel(loss_rate); }

struct FecPacket {
  uint16_t base_seq = 0;    // seq of the group's first source packet
  uint8_t  k = 0, r = 0;    // K source + R parity in this group
  uint16_t shard_len = 0;
  uint8_t  index = 0;       // parity index 0..r-1
  std::vector<uint8_t> payload;
};

class FecEncoder {
public:
  // Protect K source packets with `level` parity packets. Group is `src` (size K, contiguous seqs).
  // Protect the source packets with `level` parity packets PER GROUP of at most `group_size` source
  // packets (Zoom §4.1 "media packets protected by group"). A big frame becomes several independent
  // RS groups so (a) no group exceeds RS's K+R<=256 limit and (b) losses are shared out, so a modest
  // per-group R recovers a big frame. group_size huge = one group (the original single-group behavior,
  // used by the single-process conference where frames are small).
  std::vector<FecPacket> protect(const std::vector<MediaPacket>& src, int level, int group_size = 1 << 20) const {
    std::vector<FecPacket> out;
    const int N = (int)src.size(); if (N == 0 || level <= 0) return out;
    if (group_size < 1) group_size = 1;
    for (int g = 0; g < N; g += group_size) {
      const int gk = (N - g < group_size) ? (N - g) : group_size;
      uint16_t shard_len = 0;
      for (int i = g; i < g + gk; ++i) if (src[i].payload.size() + 2 > shard_len) shard_len = (uint16_t)(src[i].payload.size() + 2);
      std::vector<std::vector<uint8_t>> data(gk, std::vector<uint8_t>(shard_len, 0));
      for (int i = 0; i < gk; ++i) encode_shard(src[g + i].payload, data[i]);
      recon::algo::RsFec rs(gk, level);
      auto parity = rs.Encode(data);
      for (int j = 0; j < level; ++j)
        out.push_back({ src[g].seq, (uint8_t)gk, (uint8_t)level, shard_len, (uint8_t)j, std::move(parity[j]) });
    }
    return out;
  }
private:
  static void encode_shard(const std::vector<uint8_t>& payload, std::vector<uint8_t>& shard) {
    uint16_t n = (uint16_t)payload.size();
    shard[0] = (uint8_t)(n & 0xFF); shard[1] = (uint8_t)(n >> 8);
    for (size_t i = 0; i < payload.size(); ++i) shard[2 + i] = payload[i];
  }
};

class FecDecoder {
public:
  // Recover the K source payloads from the surviving source packets + FEC packets.
  // `src_present[i]` and `src[i]` describe source shard i (payload only, in group order);
  // `fecs` are the received parity packets (carry k/r/shard_len/index). Returns K payloads or empty.
  static std::vector<std::vector<uint8_t>>
  recover(const std::vector<std::vector<uint8_t>>& src,      // size K; entry may be empty if lost
          const std::vector<char>& src_present,               // size K
          const std::vector<FecPacket>& fecs) {
    if (fecs.empty()) return {};
    const int k = fecs.front().k, r = fecs.front().r; const uint16_t sl = fecs.front().shard_len;
    if ((int)src.size() != k) return {};
    std::vector<std::vector<uint8_t>> raw(k + r, std::vector<uint8_t>(sl, 0));
    std::vector<char> present(k + r, 0);
    for (int i = 0; i < k; ++i) if (src_present[i]) { raw[i] = pad_shard(src[i], sl); present[i] = 1; }
    for (const auto& f : fecs) if (f.index < r) { raw[k + f.index] = f.payload; present[k + f.index] = 1; }
    recon::algo::RsFec rs(k, r);
    if (!rs.Decode(raw, present)) return {};                 // < K survived -> unrecoverable
    std::vector<std::vector<uint8_t>> out(k);
    for (int i = 0; i < k; ++i) out[i] = decode_shard(raw[i]);
    return out;
  }
private:
  static std::vector<uint8_t> pad_shard(const std::vector<uint8_t>& payload, uint16_t sl) {
    std::vector<uint8_t> s(sl, 0); uint16_t n = (uint16_t)payload.size();
    s[0] = (uint8_t)(n & 0xFF); s[1] = (uint8_t)(n >> 8);
    for (size_t i = 0; i < payload.size() && 2 + i < sl; ++i) s[2 + i] = payload[i];
    return s;
  }
  static std::vector<uint8_t> decode_shard(const std::vector<uint8_t>& shard) {
    if (shard.size() < 2) return {};
    uint16_t n = (uint16_t)(shard[0] | (shard[1] << 8));
    if ((size_t)n + 2 > shard.size()) n = (uint16_t)(shard.size() - 2);
    return std::vector<uint8_t>(shard.begin() + 2, shard.begin() + 2 + n);
  }
};

}  // namespace avp
