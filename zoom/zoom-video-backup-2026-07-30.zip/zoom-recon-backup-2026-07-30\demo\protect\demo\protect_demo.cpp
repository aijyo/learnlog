// protect_demo.cpp — module 4 loss protection, verified end to end (AV_PIPELINE_DETAILS.html §4):
//   1) FEC: random loss <= R per group -> RS(GF256) recovers the group BYTE-FOR-BYTE, no retransmit.
//   2) adaptive level: measured loss -> protection level 3/4/5 (mcm's exact tiering).
//   3) burst loss: a burst wipes > R of a group -> FEC fails -> NACK retransmit fills the gap.
//   4) NACK reordering: light reorder does NOT trigger a spurious NACK; a real gap does.
//   5) PLC: unrecoverable frame -> audio extrapolation / video freeze (zero delay, zero bandwidth).
//   6) end to end: a REAL H.264 frame -> packetize -> FEC -> random loss -> recover -> byte-identical.
#include "protect/fec.hpp"
#include "protect/nack.hpp"
#include "protect/plc.hpp"
#include "protect/loss_sim.hpp"
#include "protect/packetizer.hpp"
#include "encode/h264_encoder.hpp"
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <vector>

using namespace avp;

static uint32_t rng = 0xC0FFEE11;
static uint8_t rb() { rng = rng * 1664525u + 1013904223u; return (uint8_t)(rng >> 16); }
static int ri(int n) { rng = rng * 1664525u + 1013904223u; return (int)((rng >> 8) % n); }

static MediaPacket mk_pkt(uint16_t seq, int len) {
  MediaPacket p; p.seq = seq; p.timestamp = 1000; p.payload.resize(len);
  for (auto& b : p.payload) b = rb();
  return p;
}

int main() {
  std::printf("=== AV pipeline / module 4: LOSS PROTECTION ===\n\n");
  int fail = 0;

  // ---- 1) FEC recovers random loss <= R, byte-for-byte, over many groups ----
  std::printf("1) multi-layer FEC (RS(GF256,0x11D), packet groups)\n");
  const int K = 8, LVL = 3;
  FecEncoder fenc; int groups = 200, recovered = 0, exact = 0;
  for (int g = 0; g < groups; ++g) {
    std::vector<MediaPacket> src; for (int i = 0; i < K; ++i) src.push_back(mk_pkt((uint16_t)(g * 16 + i), 200 + ri(800)));
    auto fec = fenc.protect(src, LVL);
    // drop up to LVL random source packets
    std::vector<char> spres(K, 1); int to_drop = ri(LVL + 1);
    for (int d = 0; d < to_drop; ++d) spres[ri(K)] = 0;
    std::vector<std::vector<uint8_t>> sp(K);
    for (int i = 0; i < K; ++i) sp[i] = spres[i] ? src[i].payload : std::vector<uint8_t>{};
    auto out = FecDecoder::recover(sp, spres, fec);   // all FEC packets present
    if (!out.empty()) {
      ++recovered; bool ok = true;
      for (int i = 0; i < K; ++i) if (out[i] != src[i].payload) { ok = false; break; }
      if (ok) ++exact;
    }
  }
  std::printf("   %d groups, drop 0..%d src/group: recovered %d, byte-exact %d  %s\n\n",
              groups, LVL, recovered, exact, exact == groups ? "OK" : (++fail, "FAIL"));

  // ---- 2) adaptive protection level ----
  std::printf("2) adaptive level (loss -> 3/4/5)\n   loss 2%%->%d  7%%->%d  15%%->%d  (expect 3/4/5)\n\n",
              SelectFecLevel(0.02), SelectFecLevel(0.07), SelectFecLevel(0.15));
  if (SelectFecLevel(0.02) != 3 || SelectFecLevel(0.07) != 4 || SelectFecLevel(0.15) != 5) ++fail;

  // ---- 3) burst loss defeats FEC -> NACK retransmit recovers ----
  // A continuous stream seq 496..509; the FEC group is seq 500..507 (K=8). A burst wipes 500..504
  // (5 > R=3) so FEC fails; the receiver — which has stream context (496..499 arrived) — detects the
  // 500..504 gap and NACKs it, and the sender resends from its history buffer.
  std::printf("3) burst loss (> R per group) -> FEC fails -> NACK\n");
  {
    const int BURST = LVL + 2;                          // 5 lost
    std::vector<MediaPacket> stream; for (uint16_t s = 496; s <= 509; ++s) stream.push_back(mk_pkt(s, 400));
    std::vector<MediaPacket> grp(stream.begin() + 4, stream.begin() + 12);   // seq 500..507
    auto fec = fenc.protect(grp, LVL);
    std::vector<char> gpres(K, 1); for (int d = 0; d < BURST; ++d) gpres[d] = 0;    // 500..504 lost
    std::vector<std::vector<uint8_t>> gp(K); for (int i = 0; i < K; ++i) gp[i] = gpres[i] ? grp[i].payload : std::vector<uint8_t>{};
    auto out = FecDecoder::recover(gp, gpres, fec);
    std::printf("   dropped %d/%d src (> R=%d): FEC recover -> %s\n", BURST, K, LVL, out.empty() ? "FAILED (expected)" : "recovered");

    RetransmitBuffer txbuf; for (auto& p : stream) txbuf.add(p);         // sender keeps history
    NackTracker nack;
    for (const auto& p : stream) {                                        // receiver: everything except the burst
      bool lost = (p.seq >= 500 && p.seq <= 500 + BURST - 1);
      if (!lost) nack.observe(p.seq);
    }
    auto nlist = nack.build_nack();
    auto resent = txbuf.resend(nlist);
    for (auto& p : resent) nack.resolve(p.seq);
    std::printf("   receiver detected gap, NACK %zu seqs, sender resent %zu, complete=%d  %s\n\n",
                nlist.size(), resent.size(), (int)nack.complete(),
                (nlist.size() == (size_t)BURST && nack.complete()) ? "OK" : (++fail, "FAIL"));
  }

  // ---- 4) NACK ignores light reordering ----
  std::printf("4) NACK vs reordering (slack=2)\n");
  {
    NackTracker n(2);
    // arrivals: 10,11,13,12,14  (12 was just reordered, not lost)
    uint16_t arr[] = {10, 11, 13, 12, 14};
    for (uint16_t s : arr) n.observe(s);
    auto nl = n.build_nack();
    std::printf("   reordered 12 after 13: NACK size=%zu (expect 0)  %s\n", nl.size(), nl.empty() ? "OK" : (++fail, "FAIL"));
    NackTracker n2(2);
    uint16_t arr2[] = {20, 21, 24, 25, 26};    // 22,23 truly missing, now well behind
    for (uint16_t s : arr2) n2.observe(s);
    auto nl2 = n2.build_nack();
    std::printf("   real gap 22,23: NACK size=%zu (expect 2)  %s\n\n", nl2.size(), nl2.size() == 2 ? "OK" : (++fail, "FAIL"));
  }

  // ---- 5) PLC ----
  std::printf("5) packet-loss concealment (last resort)\n");
  {
    AudioPlc aplc; const int FS = 480;
    std::vector<float> good(FS); for (int i = 0; i < FS; ++i) good[i] = 0.5f * std::sinf(2 * 3.14159265f * 440 * i / 48000);
    aplc.push_good(good);
    auto c1 = aplc.conceal(); auto c2 = aplc.conceal();
    double e_good = 0, e1 = 0, e2 = 0; for (int i = 0; i < FS; ++i) { e_good += good[i]*good[i]; e1 += c1[i]*c1[i]; e2 += c2[i]*c2[i]; }
    std::printf("   audio: conceal1 energy %.0f%% of good, conceal2 %.0f%% (decays, not silent/clipping)  %s\n",
                100*std::sqrt(e1/e_good), 100*std::sqrt(e2/e_good), (e1 > 0 && e1 < e_good && e2 < e1) ? "OK" : (++fail,"FAIL"));
    VideoPlc vplc; I420Image f; f.w = 64; f.h = 64; f.y.assign(64*64, 120); f.u.assign(32*32,128); f.v.assign(32*32,128);
    vplc.push_good(f);
    const I420Image& frozen = vplc.conceal();
    std::printf("   video: freeze -> %dx%d ref reused, frozen=%d  %s\n\n", frozen.w, frozen.h, vplc.frozen(),
                (frozen.w == 64 && frozen.y[0] == 120) ? "OK" : (++fail,"FAIL"));
  }

  // ---- 6) end to end: real H.264 frame protected + recovered byte-identical ----
  std::printf("6) end to end: real H.264 -> packetize -> FEC -> loss -> recover\n");
  {
    VideoEncoderConfig c; c.width = 320; c.height = 240; c.fps = 30; c.bitrate_bps = 1500000;
    H264Encoder enc; enc.open(c);
    I420Image img; img.w = 320; img.h = 240; img.y.assign(320*240, 0); img.u.assign(160*120,128); img.v.assign(160*120,128);
    for (int y = 0; y < 240; ++y) for (int x = 0; x < 320; ++x) img.y[y*320+x] = (uint8_t)((x+y) & 0xFF);
    EncodedFrame ef = enc.encode(img, true);
    Packetizer pk(1200); auto pkts = pk.packetize(ef.data, 3000);
    int kk = (int)pkts.size(); int lvl = SelectFecLevel(0.08);
    auto fec = fenc.protect(pkts, lvl);
    // drop exactly min(lvl, kk) source packets (<= R, so RS can still recover the whole group)
    std::vector<char> spres(kk, 1); int dropped = 0, want = lvl < kk ? lvl : kk;
    RandomLoss chan(0.9, 777);   // high rate so we actually hit `want` drops to demonstrate recovery
    for (int pass = 0; pass < 4 && dropped < want; ++pass)
      for (int i = 0; i < kk && dropped < want; ++i) if (spres[i] && chan.drop()) { spres[i] = 0; ++dropped; }
    std::vector<std::vector<uint8_t>> sp(kk); for (int i = 0; i < kk; ++i) sp[i] = spres[i] ? pkts[i].payload : std::vector<uint8_t>{};
    auto rec = FecDecoder::recover(sp, spres, fec);
    std::vector<MediaPacket> restored = pkts;
    bool ok = !rec.empty();
    if (ok) { for (int i = 0; i < kk; ++i) restored[i].payload = rec[i]; }
    auto reAU = reassemble(restored);
    std::printf("   frame %d B in %d pkts, FEC L%d, dropped %d, recover=%s, reassembled==original: %s  %s\n\n",
                ef.size(), kk, lvl, dropped, ok ? "yes" : "no", reAU == ef.data ? "yes" : "no",
                (ok && reAU == ef.data) ? "OK" : (++fail, "FAIL"));
  }

  std::printf(fail ? "SOME CHECKS FAILED (%d)\n" : "ALL PASS (FEC recovers, NACK fills bursts, PLC conceals)\n", fail);
  return fail ? 1 : 0;
}
