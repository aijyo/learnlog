// ipc_shared.hpp — shared-memory layout the C++ sender/receiver publish and the C# WPF monitor reads.
// POD, fixed size, 4-byte packed so the C# [StructLayout(Sequential, Pack=4)] mirror matches exactly.
// The video frame is a fixed 320x240 BGRA buffer embedded in the receiver block (no dynamic sizing).
#pragma once
#include <cstdint>
#include <cstring>

namespace avp { namespace ipc {

constexpr int      kW = 1920, kH = 1088; // Zoom's screen-share strategy (§1.4): HIGH resolution + LOW frame
                                          // rate. 1920x1088 encodes a 1920x1080 desktop essentially 1:1 (no
                                          // downscale => text keeps its native pixels; that is what makes it
                                          // sharp), 1088 is 16-aligned for the H.264 A/B path. VP9 screen-
                                          // content + low fps keeps it real-time. Must match AvpMonitor W/H.
constexpr uint32_t kMagic = 0x49505641u;               // 'AVPI'
// Named mappings (Local\ = per-session). The C# side opens these exact names.
inline const wchar_t* kSenderMap()   { return L"Local\\AvpSenderStats"; }
inline const wchar_t* kReceiverMap() { return L"Local\\AvpReceiverShare"; }
inline const wchar_t* kControlMap()  { return L"Local\\AvpControl"; }   // WPF writes, the C++ procs poll
inline const wchar_t* kPeerMap(char id) { return id == 'A' ? L"Local\\AvpPeerA" : L"Local\\AvpPeerB"; }
inline const wchar_t* kRaisrMap()    { return L"Local\\AvpRaisr"; }     // RAISR super-res tab (raisr_cam -> WPF)

// RAISR super-resolution demo: low-res input at (in_w,in_h), both images shown at the 2x output size —
// left = plain bilinear x2 (naive), right = RAISR x2 (luma RAISR + bilinear chroma). Output capped at 1280x960
// (input up to 640x480). Both images double-buffered (anti-tearing) and tightly packed at out_w x out_h.
constexpr int kRW = 1280, kRH = 960;

#pragma pack(push, 4)
// Live control the monitor writes and the sender/receiver poll each frame — so the sliders take effect
// without restarting the processes.
struct ControlBlock {
  uint32_t magic;
  int32_t  loss_pct;         // 0..100 (sender injects loss/100)
  int32_t  cc_on;            // 1 = congestion control active
  int32_t  link_kbps;        // simulated bottleneck for CC
  int32_t  stop;             // 1 = please exit
  int32_t  fps;              // @20: live manual frame rate (applied when adaptive is OFF; 0 = ignore)
  int32_t  reserved[7];
};
struct SenderStats {
  uint32_t magic;
  uint32_t frame_index;      // increments per encoded/sent frame
  int32_t  width, height, fps;
  int32_t  encode_kbps;      // instantaneous (this frame * fps)
  int32_t  cc_target_kbps;   // 0 if congestion control off
  int32_t  pkts_sent, fec_sent;
  int64_t  bytes_sent;
  int32_t  loss_pct;         // configured injected loss
  int32_t  running;          // 1 while active, 0 on exit
  int32_t  reserved[6];
};

struct ReceiverShare {
  uint32_t magic;
  uint32_t frame_seq;        // increments per decoded frame — the WPF UI watches this
  int32_t  width, height;
  int32_t  frames_recv, dropped, recovered, intact_frames;
  int32_t  decode_ok;        // 1 if the last frame decoded
  int32_t  psnr_x100;        // luma PSNR * 100 (vs a reference, if available; else 0)
  int32_t  jitter_x100_ms;   // RFC3550 jitter * 100
  int32_t  running;
  int32_t  reserved[5];
  uint8_t  frame[kW * kH * 4];   // BGRA, top-down
};

// One peer in the two-way conference: it sends its own video AND shows the frame it RECEIVES from the
// other peer. `frame` here is the *received* picture (the other peer's video). One PeerShare per peer.
struct PeerShare {
  uint32_t magic;
  uint32_t sent_frames;
  int32_t  encode_kbps, cc_target_kbps, pkts_sent, fec_sent;
  uint32_t recv_frame_seq;   // increments per decoded received frame (UI watches this)
  int32_t  recv_frames, recv_decoded, recv_recovered, recv_dropped;
  int32_t  width, height, running, loss_pct;
  // adaptation telemetry (Zoom §9 loop): the current encode tier this peer chose from the net-score.
  int32_t  adapt_w, adapt_h, adapt_fps;   // live encode resolution + frame rate (the ladder tier)
  int32_t  bw_level;                       // 1..4 bandwidth level
  int32_t  mos_x100;                        // G.107 MOS * 100
  int32_t  audio_tx_mrms;   // @80: this peer's OUTGOING audio RMS level * 1000 (Opus encode input)
  int32_t  audio_rx_mrms;   // @84: RMS * 1000 of the audio DECODED from the other peer (proves Opus loop)
  int32_t  av_sync_ms;      // @88: presented-video vs audio-playout offset (ms). ~0 = lip-synced; big +ve = video leads
  int32_t  net_delay_ms;    // @92: abs_net_delay fed to §9 G.107 = measured RTT/2 + audio jitter-buffer depth
  // Anti-tearing DOUBLE BUFFER (Zoom's DXGI swap-chain analog: SafeCreateSwapChain/SafePresent front/back
  // flip). The writer fills frame[1-front] then flips `frame_front`; the reader reads frame[frame_front].
  // Reader and writer never touch the same buffer, so a mid-write read can't tear (was: single buffer +
  // memcpy racing the WPF ReadArray -> a torn frame, invisible on static text but a white seam on video).
  int32_t  frame_front;     // @96: index (0/1) of the COMPLETE buffer to read
  uint8_t  frame[2][kW * kH * 4];   // @100: front/back BGRA buffers (the other peer's video / composite)
  // Receive-side super-res telemetry (appended AFTER the frame array, so every offset above is unchanged).
  // recv_sr_on = 1 when the last received frame was RAISR-super-resolved (else bilinear); recv_sr_us = its
  // GPU compute time (µs); content_mode = the sender's scene class (0=camera, 1=screen-static, 2=screen-video).
  int32_t  recv_sr_on;      // @ 100 + 2*kW*kH*4
  int32_t  recv_sr_us;
  int32_t  content_mode;
  int32_t  recv_frozen;     // @ +12: 1 = freeze-on-loss active (holding last complete frame, awaiting a clean key)
};

// Super-res share: the engine produces THREE views every frame so each WPF viewer can pick any of them:
// orig (original input, in_w x in_h), bilin (bilinear x2), raisr (RAISR x2) — the latter two at out_w x out_h.
// All double-buffered. reserved[0]=raisr_on, [1]=gpu_us.
struct RaisrShare {
  uint32_t magic;
  int32_t  running;
  uint32_t frame_seq;        // increments per produced frame (WPF watches this)
  int32_t  in_w, in_h;       // ORIGINAL input dims (orig buffer)
  int32_t  out_w, out_h;     // 2x output dims (bilin/raisr buffers); <= kRW x kRH
  int32_t  fps_x10;          // measured throughput * 10
  int32_t  cam_ok;           // 1 = real camera, 0 = synth / image
  int32_t  reserved[4];      // [0]=raisr_on [1]=gpu_us
  int32_t  frame_front;      // 0/1: the COMPLETE buffer to read
  uint8_t  orig[2][kRW * kRH * 4];    // original input BGRA (in_w x in_h)
  uint8_t  bilin[2][kRW * kRH * 4];   // bilinear x2 BGRA (out_w x out_h)
  uint8_t  raisr[2][kRW * kRH * 4];   // RAISR x2 BGRA (out_w x out_h)
};

// Publish the three views with the swap-chain flip (each a different size, so pass each length).
inline void publish_raisr(RaisrShare* s, const uint8_t* orig, size_t on, const uint8_t* bilin, size_t bn, const uint8_t* raisr, size_t rn) {
  int back = 1 - s->frame_front;
  auto cp = [](uint8_t* d, const uint8_t* src, size_t n, size_t cap) { std::memcpy(d, src, n < cap ? n : cap); };
  cp(s->orig[back],  orig,  on, sizeof(s->orig[0]));
  cp(s->bilin[back], bilin, bn, sizeof(s->bilin[0]));
  cp(s->raisr[back], raisr, rn, sizeof(s->raisr[0]));
  s->frame_front = back;
  s->frame_seq++;
}

// Publish one BGRA frame with the swap-chain flip: fill the back buffer, then flip front to it. (x86 TSO:
// the buffer stores are visible before the front-index store, so the reader never sees a half-written buffer.)
inline void publish_frame(PeerShare* s, const uint8_t* data, size_t n) {
  int back = 1 - s->frame_front;
  size_t nb = n < sizeof(s->frame[0]) ? n : sizeof(s->frame[0]);
  std::memcpy(s->frame[back], data, nb);
  s->frame_front = back;
  s->recv_frame_seq++;
}
#pragma pack(pop)

}}  // namespace avp::ipc
