// video_preprocess.hpp — module 2 video preprocess (AV_PIPELINE_DETAILS.html §2), the encoder-side
// "perceptual enhancement + entropy reduction" chain, wired to the verified zlt algorithms:
//
//   capture BGRA ─► BGRA→I420 ─► temporal IIR denoise (Y, α=0.37, zltCIIRDenoise)
//                              ─► adaptive-QP hint map (TextureMotion 6-threshold ladder)
//                              ─► [optional] RAISR super-res (structure real, filter bank = ⛔ boundary)
//                   ─► preprocessed I420 + per-block QP-delta side info for the encoder (module 3)
//
// Denoise runs on the luma plane (chroma noise is far less visible and costs less to leave); the
// QP map is *side information* the encoder consumes — preprocess doesn't quantize, it advises.
#pragma once
#include "capture/video_frame.hpp"
#include "video_convert.hpp"
#include "algo/zlt_denoise.hpp"
#include "algo/mc_denoise.hpp"        // motion-adaptive spatial-temporal denoise (ghost-free)
#include "algo/zlt_adaptive_qp.hpp"
#include "algo/zlt_raisr.hpp"
#include "algo/zlt_vfx.hpp"          // zltCSharpen (unsharp) + zltCCLAHE (local contrast) perceptual enhance
#include <cstdint>
#include <vector>

namespace avp {

struct VideoPreprocessConfig {
  bool  denoise = true;
  float denoise_alpha = recon::zlt::IIRDenoise::kAlpha;   // 0.37 (verified)
  int   denoise_motion_guard = 0;                          // 0 = pure IIR; >0 anti-ghost threshold
  bool  denoise_motion_adaptive = false;                   // true = ghost-free spatial-temporal (mc_denoise)

  bool  adaptive_qp = true;
  recon::zlt::AdaptQuantKind qp_kind = recon::zlt::AdaptQuantKind::TextureMotion;
  int   qp_block = 16;

  bool  raisr = false;         // off by default (needs a learned filter bank for real gain)
  int   raisr_scale = 2;

  // perceptual enhancement (Zoom ns_vpp), before adaptive-QP/encode. Off by default; --vfx turns them on.
  // Order = Zoom's: global exposure/WB (LightAdaption/ColorAdaption) first, then local CLAHE + Sharpen.
  bool  light = false;         float light_strength = 0.5f;   // zltCLightAdaption (auto-brightness, on Y)
  bool  color = false;         float color_strength = 0.5f;   // zltCColorAdaption (auto white-balance, on U/V)
  bool  clahe = false;         float clahe_clip = 3.0f;
  bool  sharpen = false;       float sharpen_amount = 0.6f;
};

// Side information produced per frame for the downstream encoder.
struct VideoPreprocessResult {
  I420Image        frame;        // preprocessed I420 (denoised; NOT super-resolved — see sr_* below)
  std::vector<int> qp_delta;     // per-block QP offset (row-major), −3..+3 per block; empty if disabled
  int              qp_bw = 0, qp_bh = 0;
  float            qp_mean = 0.f;
  bool             denoised = false;
  // optional RAISR output (kept separate: SR changes resolution, an encoder-target decision)
  bool             sr_done = false;
  int              sr_w = 0, sr_h = 0;
  std::vector<uint8_t> sr_y;     // super-resolved luma (sr_w*sr_h) when raisr enabled
};

class VideoPreprocessor {
public:
  explicit VideoPreprocessor(VideoPreprocessConfig cfg = {}) : cfg_(cfg) {
    denoise_cfg_.alpha = cfg_.denoise_alpha;
    denoise_cfg_.motion_guard = cfg_.denoise_motion_guard;
    aq_ = recon::zlt::MakeAdaptQuant(cfg_.qp_kind, cfg_.qp_block);
  }

  // Process one captured BGRA frame. `ref_y` (previous frame's luma) drives the motion metric; the
  // preprocessor keeps its own denoise state across calls, so just feed frames in order.
  void Process(const VideoFrame& bgra, VideoPreprocessResult& out) {
    BgraToI420(bgra, out.frame);
    const int w = out.frame.w, h = out.frame.h;

    // 1) temporal IIR denoise on Y (recursive; state owned by denoiser_)
    if (cfg_.denoise) {
      if ((int)prev_y_.size() != w * h) prev_y_.assign((size_t)w * h, 0);
      std::vector<uint8_t> dy((size_t)w * h);
      if (cfg_.denoise_motion_adaptive)                          // ghost-free: temporal on static, spatial on motion
        mc_denoiser_.Filter(out.frame.y.data(), dy.data(), w, h);
      else                                                        // plain zlt IIR (verified; trails on motion)
        denoiser_.Filter(out.frame.y.data(), dy.data(), (size_t)w * h);
      out.frame.y.swap(dy);
      out.denoised = true;
    }

    // 1b) perceptual enhancement (Zoom ns_vpp), in Zoom's chain order: global exposure (LightAdaption on Y)
    // and white-balance (ColorAdaption on U/V) FIRST, then local CLAHE contrast, then unsharp Sharpen.
    // QP is computed AFTER, so the encoder targets the enhanced picture.
    if (cfg_.light)   recon::vfx::LightAdapt(out.frame.y.data(), w, h, cfg_.light_strength);
    if (cfg_.color)   recon::vfx::ColorAdapt(out.frame.u.data(), out.frame.v.data(), out.frame.cw(), out.frame.ch(), cfg_.color_strength);
    if (cfg_.clahe)   recon::vfx::Clahe(out.frame.y.data(), w, h, 8, 8, cfg_.clahe_clip);
    if (cfg_.sharpen) recon::vfx::Sharpen(out.frame.y.data(), w, h, cfg_.sharpen_amount);

    // 2) adaptive-QP hint map from (enhanced) luma vs the previous luma (motion)
    if (cfg_.adaptive_qp) {
      const uint8_t* ref = have_prev_ ? prev_y_.data() : nullptr;
      out.qp_mean = aq_.Compute(out.frame.y.data(), ref, w, w, h, out.qp_delta);
      out.qp_bw = (w + cfg_.qp_block - 1) / cfg_.qp_block;
      out.qp_bh = (h + cfg_.qp_block - 1) / cfg_.qp_block;
    }

    // remember this frame's luma for the next frame's motion metric
    prev_y_ = out.frame.y; have_prev_ = true;

    // 3) optional RAISR super-res on the (denoised) luma
    if (cfg_.raisr) {
      recon::zlt::RaisrConfig rc; rc.scale = cfg_.raisr_scale;
      recon::zlt::PassthroughFilterBank bank(rc.patch);   // ⛔ real learned bank injected here
      recon::zlt::RaisrUpscaler up(rc, &bank);
      up.Upscale(out.frame.y.data(), w, h, out.sr_y, out.sr_w, out.sr_h);
      out.sr_done = true;
    }
  }

  // Inject a real RAISR filter bank (weights boundary) to get true super-res instead of passthrough.
  void set_raisr_bank(const recon::zlt::IFilterBank* bank) { raisr_bank_ = bank; }

  void reset() { denoiser_.Reset(); mc_denoiser_.Reset(); prev_y_.clear(); have_prev_ = false; }

private:
  VideoPreprocessConfig cfg_;
  recon::zlt::IIRDenoise denoise_cfg_;
  recon::zlt::TemporalDenoiser denoiser_{denoise_cfg_};
  MotionAdaptiveDenoiser mc_denoiser_;
  recon::zlt::TextureMotionAdaptQuant aq_;
  const recon::zlt::IFilterBank* raisr_bank_ = nullptr;
  std::vector<uint8_t> prev_y_;
  bool have_prev_ = false;
};

}  // namespace avp
