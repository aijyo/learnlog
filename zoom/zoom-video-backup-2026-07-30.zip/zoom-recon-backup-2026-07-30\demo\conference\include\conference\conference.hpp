// conference.hpp — the whole pipeline wired into ONE object. process_frame() runs a captured frame
// through every module in order (capture is the caller's; here: preprocess → encode → packetize → FEC
// → loopback channel → jitter buffer → FEC recover → reassemble → decode → render) and returns a
// per-frame stat line. process_audio() does the audio equivalent (3A → AAC → channel → AAC decode).
// This is the send-and-receive path of a real-time loopback "conference", in a single process.
#pragma once
#include "conference/media_channel.hpp"
#include "conference/loopback_channel.hpp"
#include "conference/udp_media_channel.hpp"
#include "preprocess/video_preprocess.hpp"
#include "preprocess/audio_preprocess.hpp"
#include "encode/h264_encoder.hpp"
#include "protect/packetizer.hpp"
#include "protect/fec.hpp"
#include "transport/congestion.hpp"
#include "transport/net_sim.hpp"
#include "receive/jitter_buffer.hpp"
#include "receive/renderer.hpp"
#ifdef AVP_WITH_FFMPEG
#include "encode/h264_decode_verify.hpp"
#include "encode/audio_encoder.hpp"
#include "receive/audio_decoder.hpp"
#endif
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace avp {

struct ConferenceConfig {
  int    width = 320, height = 240, fps = 15, bitrate_bps = 1200000;
  double loss = 0.05;        // per-packet loss the channel injects
  bool   reorder = true;
  bool   layered = true;     // droppable temporal layers
  bool   use_udp = false;    // real UDP sockets instead of the in-process loopback
  bool   cc = false;         // congestion control: adapt the encoder bitrate to estimated bandwidth
  double link_bps = 1000000; // the (simulated) bottleneck the CC estimator learns from
};

struct FrameStat {
  int  enc_bytes = 0, pkts = 0, fec = 0, dropped = 0;
  bool recovered = false;    // FEC/reorder rebuilt the frame
  bool intact = false;       // reassembled AU == encoded frame
  bool decoded = false;
  double psnr = 0;
  double target_bps = 0;     // congestion-control target driving the encoder (0 if cc off)
};

class Conference {
public:
  bool open(const ConferenceConfig& c) {
    cfg_ = c;
    if (c.use_udp) { auto u = std::make_unique<UdpMediaChannel>(); if (!u->open(c.loss)) return false; udp_port_ = u->rx_port(); chan_ = std::move(u); }
    else chan_ = std::make_unique<LoopbackChannel>(c.loss, c.reorder, 0xC0FFEE);
    VideoEncoderConfig ec; ec.width = c.width; ec.height = c.height; ec.fps = c.fps;
    ec.bitrate_bps = c.bitrate_bps; ec.temporal_layers = 3; ec.layered_refs = c.layered; ec.gop = 32;   // periodic IDR
    if (!enc_.open(ec)) return false;
    jb_ = JitterBuffer(90000);
    pktz_ = Packetizer(1100);
    cc_enabled_ = c.cc;
    cc_ = CongestionController(c.bitrate_bps, 100000, 4000000);
    link_ = BottleneckLink(c.link_bps, 40, 80000);
    vclock_us_ = 0;
#ifdef AVP_WITH_FFMPEG
    dec_.open();
#endif
    return true;
  }

  // one video frame end to end. `bgra` is a captured/synthesized BGRA frame.
  FrameStat process_frame(const VideoFrame& bgra) {
    FrameStat st;
    // send: preprocess -> encode -> packetize -> FEC
    VideoPreprocessResult pp; pp_.Process(bgra, pp);
    EncodedFrame ef = enc_.encode(pp.frame);
    if (ef.size() == 0) return st;
    st.enc_bytes = ef.size();
    auto pkts = pktz_.packetize(ef.data, ts_); ts_ += 3000;
    int K = (int)pkts.size(); st.pkts = K;
    int level = SelectFecLevel(cfg_.loss > 0 ? cfg_.loss * 1.5 : 0.03);
    auto fecs = fenc_.protect(pkts, level); st.fec = (int)fecs.size();

    // channel: send media + FEC, deliver (with loss + reorder)
    for (auto& p : pkts) chan_->send({ false, p, {} });
    for (auto& f : fecs) chan_->send({ true, {}, f });
    auto wire = chan_->deliver();

    // receive: jitter buffer (reorder) + collect FEC
    std::vector<char> present(K, 0); std::vector<FecPacket> got_fec;
    uint16_t base = pkts.front().seq;
    for (auto& w : wire) {
      if (w.is_fec) got_fec.push_back(w.fec);
      else { jb_.insert(w.pkt, rx_us_); rx_us_ += 2000; int idx = (uint16_t)(w.pkt.seq - base); if (idx >= 0 && idx < K) present[idx] = 1; }
    }
    for (int i = 0; i < K; ++i) if (!present[i]) ++st.dropped;

    // FEC recover the lost source packets
    if (st.dropped > 0) {
      std::vector<std::vector<uint8_t>> sp(K);
      for (int i = 0; i < K; ++i) sp[i] = present[i] ? pkts[i].payload : std::vector<uint8_t>{};
      auto rec = FecDecoder::recover(sp, present, got_fec);
      if (!rec.empty()) { for (int i = 0; i < K; ++i) if (!present[i]) { MediaPacket mp = pkts[i]; mp.payload = rec[i]; jb_.insert(mp, rx_us_ += 500); } st.recovered = true; }
    }

    // reassemble + decode + render
    std::vector<uint8_t> au; uint32_t ts = 0;
    if (jb_.pop_frame(au, ts)) { st.intact = (au == ef.data);
#ifdef AVP_WITH_FFMPEG
      I420Image out;
      if (st.intact && dec_.decode(au, out) && out.w == cfg_.width) {
        st.decoded = true; st.psnr = PsnrY(pp.frame, out);
        if (snap_++ % snap_every_ == 0) { std::string p = "conf_frame" + std::to_string(rendered_) + ".bmp"; vr_.present(out, p); ++rendered_; }
      }
#else
      st.decoded = st.intact;
#endif
    }

    // congestion-control feedback loop: model this frame's packets crossing the bottleneck link,
    // feed the per-packet delay/loss to the GCC estimator, and adapt the encoder bitrate to its
    // target — so the send rate tracks available bandwidth (§5/§9). (loopback/UDP-127.0.0.1 have no
    // real bottleneck, so the estimator learns from the simulated link.)
    if (cc_enabled_) {
      // Drive the bottleneck at the INTENDED send rate (the CC target). In a real client a pacer emits
      // packets at the target and a rate-controlled encoder tracks it; our stand-in baseline encoder's
      // rate control is loose, so we pace at the target here to test that the GCC estimator converges
      // to the link. `set_bitrate` still feeds the target to the real encoder (it tracks it loosely).
      const int fps = cfg_.fps > 0 ? cfg_.fps : 15;
      const double period_us = 1000000.0 / fps;
      int intended = (int)(cc_.target_bps() / 8.0 / fps);      // bytes this frame at the target rate
      const int pktsz = 1100; int npk = intended / pktsz; if (npk < 2) npk = 2;
      int64_t gap = (int64_t)(period_us / npk);
      std::vector<PacketFeedback> fbs; fbs.reserve(npk);
      for (int i = 0; i < npk; ++i) {
        PacketFeedback f; f.seq = (uint16_t)i; f.size = pktsz; f.send_time_us = vclock_us_;
        int64_t rx = 0; link_.transmit(pktsz, f.send_time_us, rx); f.recv_time_us = rx;
        fbs.push_back(f); vclock_us_ += gap;
      }
      cc_.on_feedback(fbs);
      enc_.set_bitrate((int)cc_.target_bps());
      st.target_bps = cc_.target_bps();
    }
    return st;
  }

#ifdef AVP_WITH_FFMPEG
  // one audio buffer end to end: 3A -> AAC -> channel -> AAC decode. Returns decoded PCM.
  bool process_audio(const std::vector<float>& mic, int rate, std::vector<float>& out) {
    std::vector<float> clean = apre_.Process(mic, {}, rate, nullptr);   // AEC(no ref)+ANS+AGC
    if (!aenc_open_) { if (!aenc_.open(rate, 1, 64000)) return false; adec_.open(aenc_.extradata(), aenc_.extradata_size(), rate, 1); aenc_open_ = true; }
    std::vector<EncodedAudio> apkts; aenc_.encode(clean.data(), (int)clean.size(), apkts);
    auto tail = aenc_.flush(); apkts.insert(apkts.end(), tail.begin(), tail.end());
    for (auto& p : apkts) adec_.decode(p.data.data(), p.size(), out);
    return !out.empty();
  }
#endif

  const IMediaChannel& channel() const { return *chan_; }
  uint16_t udp_port() const { return udp_port_; }
  int rendered() const { return rendered_; }
  CongestionState cc_state() const { return cc_.state(); }

private:
  ConferenceConfig cfg_;
  VideoPreprocessor pp_;
  H264Encoder enc_;
  FecEncoder fenc_;
  std::unique_ptr<IMediaChannel> chan_;
  uint16_t udp_port_ = 0;
  Packetizer pktz_;
  JitterBuffer jb_;
  VideoRenderer vr_;
  CongestionController cc_{1200000};
  BottleneckLink link_{1000000, 40, 80000};
  bool cc_enabled_ = false; int64_t vclock_us_ = 0;
  uint32_t ts_ = 3000; int64_t rx_us_ = 0;
  int snap_ = 0, snap_every_ = 30, rendered_ = 0;
#ifdef AVP_WITH_FFMPEG
  H264Decoder dec_;
  AudioPreprocessor apre_;
  AacEncoder aenc_; AacDecoder adec_; bool aenc_open_ = false;
#endif
#ifndef AVP_WITH_FFMPEG
  AudioPreprocessor apre_;
#endif
};

}  // namespace avp
