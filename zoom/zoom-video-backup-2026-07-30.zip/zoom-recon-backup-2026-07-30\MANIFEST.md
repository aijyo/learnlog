# Zoom 媒体栈逆向 + Clean-room 重构 + Demo —— 备份(2026-07-30)

**代码(完整 recon + 可运行 demo 源码)+ 文档 + 工具**。全部 clean-room 原创实现与原创技术分析(不含任何反编译/专有代码粘贴)。**IP 敏感,仅本地留存。**

## 目录

```
recon/          完整 clean-room 重构头文件(46 个 .hpp,按子系统分组)
demo/           av-pipeline 可运行 demo 源码(已剔除 build 产物/二进制)
docs/           技术文档(Zoom 逆向详版 2 份 + 队友脱敏 wiki 1 份;.md 源 + .html)
tools/ida/      IDA 7.5 headless 逆向脚本
tools/docgen/   Markdown → HTML 转换器
```

## recon/ —— 完整重构(46 .hpp,按子系统)

**视频(本次对话重点)**
- `zlt_scene_change.hpp` 场景切换检测 · `zlt_content_analysis.hpp` **video-in-share 内容分析簇** · `zlt_vfx.hpp` 感知增强(逆光/色彩/CLAHE/锐化)· `zlt_adaptive_qp.hpp` 逐帧自适应 QP · `zlt_rate_control.hpp` 码率控制 · `zlt_dcci.hpp` 边缘定向上采样 · `zlt_chroma.hpp` 导向色度 · `zlt_raisr.hpp`/`zlt_raisr_camera.hpp`/`raisr_gpu.hpp`/`raisr_cam_gpu.hpp` 超分 · `zlt_resample.hpp` 缩放 · `zlt_denoise.hpp` 降噪 · `zlt_h264_backend.hpp`/`zlt_svc_encoder.hpp`/`zlt_encode_config.hpp` 编码控制 · `zbt_av1_codec.hpp`/`zbt_av1_encoder.hpp` AV1 屏幕内容 · `codec/av1_*.hpp`
- `mcm/mcm_channel.hpp` **弱网自适应(G.107 + 服务端中介档位)** · `mcm/mcm_multifec.hpp` 多层 FEC · `algo/rs_fec.hpp` Reed–Solomon · `protect`(demo 侧)

**音频 / 其他子系统(早前会话,一并归档)**
- `snac/*` 音频 codec · `viper_codec_control.hpp`/`viperex_*.hpp` 音频引擎/OpenVINO · `mesh/*` mesh 网络 · `tp/*` 传输(curl/openssl/url)· `ssb/webapp_settings.hpp` · `conti/conti_session.hpp` · `mcm/ffmpeg_codec.hpp`

> 精度分级见各文件头注:**逐位**(实证)/ **机制**(结构确认)/ **残差**(上游算式或服务端阈值,标 [推断])。视频侧核心均已编译 + 行为测试。

## demo/ —— av-pipeline 可运行源码

发送→接收双向会议 demo。源码树:`apps/`(peer + AvpMonitor UI)`capture/ preprocess/ encode/ protect/ transport/ receive/ conference/`,`CMakeLists.txt` / `README.md` / `screen_content.cfg` / `verify.ps1`。

**已剔除(需自行准备/构建)**:`build/ build-ff/ dist/ third_party/`(FFmpeg/libaom/libvpx 预编译,~800M)、`AvpMonitor/bin,obj`、`*.dll/exe/pdb/obj/lib/i64`、帧转储 `*.bmp`。构建:见 `demo/README.md`;peer 目标需 `-DAVP_WITH_FFMPEG=ON`,产物进 `build-ff`。
> `demo/preprocess/include/preprocess/algo/*.hpp` 是 recon 的**同步副本**(供 demo 直接引用);canonical 版在 `recon/`。

## docs/ —— 文档

| 文件 | 定位 |
|---|---|
| `ZOOM_VIDEO_PIPELINE.{md,html}` | Zoom 逆向**详版**(IP 敏感):全环节机制 + 函数/地址/阈值 + [实证]/[推断] |
| `ZOOM_RECON_SUMMARY.{md,html}` | Zoom 逆向**成果总结**(IP 敏感):模块地图 + 状态表 + 残差 |
| `VIDEO_STREAMING_ARCHITECTURE.{md,html}` | **队友脱敏 wiki**「Zoom 视频流技术分析」:零逆向痕迹,暗色 + 目录侧栏 |

## tools/

- `ida/` — `_runida.ps1`(复用 .i64)/`_buildida.ps1`(新建)/`_ida_*.py`(反编译/vtable/xref/names)。
- `docgen/` — `md2html_gen.py`(暗色详版)/`md2wiki.py`(暗色 wiki + 目录)。

## 本次对话完成

T1–T5(码率/mcm 阈值/VFX 精确核/**拥塞=服务端中介非 GCC**/残差复核 + ~230 类覆盖表)· CA1–CA5(内容分析簇逆向 + `zlt_content_analysis.hpp`)· 渲染冻结核查(**无"损坏帧"闸门**,据实更正)· 队友 wiki 建成暗色化 + [实证]/[推断]。

## 边界原则

Clean-room(自写,不粘贴反编译)· fidelity-no-invention([实证]/[推断] 标注)· ⛔W 神经权重(训自有)/ ⛔K 第三方编解码核(标准库)/ ⛔S 编译 shader(RE 算法后自写)/ 服务端阈值(不在客户端二进制)。
