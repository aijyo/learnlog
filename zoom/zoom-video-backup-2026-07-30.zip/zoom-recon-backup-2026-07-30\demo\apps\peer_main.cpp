// peer_main.cpp — one participant in a TWO-WAY conference: a single process that BOTH sends its own
// video and receives + decodes the other peer's, like a real conferencing client. Two peers (A and B)
// point at each other's ports; each publishes a PeerShare (its send stats + the frame it received from
// the other peer) for the WPF monitor's side-by-side view.
//
//   peer --id A|B --local-port L --remote-port R [--fps F] [--loss P] [--source synth|screen]
//        [--cc --link-kbps N] [--seconds N|0]
#include "apps/ipc_shared.hpp"
#include "apps/ipc_writer.hpp"
#include "apps/frame_assembler.hpp"
#include "apps/adaptation.hpp"          // Zoom §9 weak-network loop -> resolution/fps/bitrate ladder
#include "apps/screen_content_config.hpp" // content-mode tunables (Zoom SceneChangeDetect: config-driven + defaults)
#include "apps/resample.hpp"              // Zoom VPP scaler (bicubic Catmull-Rom, anti-aliased) for capture->encode
#include "apps/recv_superres.hpp"         // receive-side GPU RAISR super-res (Zoom zltCScreenRAISR render path)
#include "zlt_dcci.hpp"                    // Zoom zltCDCC = DCCI edge-directed 2x upscaler (render-chain "Upsample")
#include "zlt_scene_change.hpp"            // Zoom zltCSceneChangeDetect (precise: luma-histogram brightness-invariant similarity)
#include "conference/media_channel.hpp"
#include "preprocess/video_preprocess.hpp"
#include "encode/h264_encoder.hpp"
#include "protect/packetizer.hpp"
#include "protect/fec.hpp"
#include "protect/nack.hpp"               // RetransmitBuffer + NackTracker (burst-loss retransmit)
#include "transport/socket_transport.hpp"
#include "transport/congestion.hpp"
#include "transport/net_sim.hpp"
#include "transport/pacer.hpp"           // SendPacer — GCC send pacer (smooth the burst to the BWE target)
#include "capture/capture_factory.hpp"
#include "capture/camera_mf.hpp"          // MfCameraSource for --source camera
#include "capture/audio_wasapi.hpp"       // WasapiAudioSource for --mic
#include "capture/audio_player.hpp"        // StreamingAudioPlayer for --play (live speaker)
#include "preprocess/video_convert.hpp"
#include "preprocess/audio_preprocess.hpp" // 3A (ANS/AGC) on the captured audio
#include "protect/plc.hpp"                 // AudioPlc: conceal a lost audio packet (0.6^n fade)
#ifdef AVP_WITH_FFMPEG
#include "encode/h264_decode_verify.hpp"
#include "encode/vp9_screen.hpp"      // VP9 screen-content backend (+ AV1 SC factory slot)
#include "encode/opus_codec.hpp"      // real Opus audio (libopus) for the conference audio leg
#endif
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <thread>
#include <vector>

using namespace avp;
using clockt = std::chrono::steady_clock;

static uint32_t g_rng = 0x13572468;
static double urand() { g_rng = g_rng * 1664525u + 1013904223u; return (g_rng >> 8) / (double)(1u << 24); }

// A tinted, animated frame so the two peers' streams are visually distinguishable (A warm, B cool).
static VideoFrame synth(int w, int h, int t, char id) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA; f.data.resize((size_t)w * h * 4);
  int cx = (t * 9) % w, cy = (t * 6) % h;
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    int dx = x - cx, dy = y - cy; bool box = (dx * dx + dy * dy) < 1600;
    uint8_t base = (uint8_t)((x + y + t * 8) & 0xFF);   // animate faster so the test pattern reads as MOTION (not static)
    uint8_t* p = &f.data[((size_t)y * w + x) * 4];
    if (id == 'A') { p[0] = (uint8_t)(base / 3); p[1] = (uint8_t)(base / 2); p[2] = box ? 255 : 200; }   // reddish
    else           { p[0] = box ? 255 : 200; p[1] = (uint8_t)(base / 2); p[2] = (uint8_t)(base / 3); }   // bluish
    p[3] = 255;
  }
  return f;
}
// A distinct "shared document / slides" pattern for the DUAL screen-share leg (light page + text-like bars
// + a scrolling highlight) so the composited PIP clearly shows two different contents.
static VideoFrame synth2(int w, int h, int t, char id) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA; f.data.resize((size_t)w * h * 4);
  int scroll = (t * 4) % (h / 2 + 1);
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    uint8_t* p = &f.data[((size_t)y * w + x) * 4];
    bool page = (x > w / 12 && x < w * 11 / 12);                       // white page with margins
    bool textline = page && (x < w * 3 / 4) && ((y % 40) < 22) && (y > h / 8) && (y < h * 7 / 8);  // dark "text" rows
    bool highlight = page && (y > (h / 4 + scroll) && y < (h / 4 + scroll + 34));  // a scrolling highlight bar
    uint8_t v = page ? (textline ? 60 : 240) : 30;                    // text dark on light page, grey outside
    p[0] = highlight ? 90 : v; p[1] = highlight ? 200 : v; p[2] = highlight ? 250 : v; p[3] = 255;   // highlight = amber
  }
  (void)id; return f;
}
// Aspect-preserving (letterbox) scale-to-fit using Zoom's VPP downscaler: fit the captured frame into
// dw x dh without stretching (unused margin stays black), resampling the fitted region with a bicubic
// Catmull-Rom (Keys a=-0.5) polyphase filter whose support widens with the shrink factor to anti-alias —
// exactly the kernel and support law reverse-engineered from zlt.dll ns_vpp::zltCResample /
// zltCGvdownsample (see apps/resample.hpp). This preserves thin text strokes and edges far better than a
// box average, and at scale==1 (e.g. 1920x1080 -> 1920x1088) Catmull-Rom passes through the samples, so
// the desktop's native pixels come through as an exact 1:1 copy.
static VideoFrame downscale(const VideoFrame& big, int dw, int dh) {
  VideoFrame f; f.width = dw; f.height = dh; f.stride = dw * 4; f.format = PixelFormat::BGRA; f.data.assign((size_t)dw * dh * 4, 0);
  if (big.width <= 0 || big.height <= 0) return f;
  int bs = big.stride ? big.stride : big.width * 4;
  double scale = (double)dw / big.width, sy2 = (double)dh / big.height; if (sy2 < scale) scale = sy2;
  int sw = (int)(big.width * scale), shh = (int)(big.height * scale), ox = (dw - sw) / 2, oy = (dh - shh) / 2;
  if (sw < 1) sw = 1; if (shh < 1) shh = 1;
  std::vector<uint8_t> fit((size_t)sw * shh * 4);                       // fitted region, then blit into letterbox
  avp::resample::ResizeBGRA(big.data.data(), big.width, big.height, bs, fit.data(), sw, shh);
  for (int y = 0; y < shh; ++y)
    std::memcpy(&f.data[((size_t)(y + oy) * dw + ox) * 4], &fit[(size_t)y * sw * 4], (size_t)sw * 4);
  return f;
}

// Bilinear resize of a BGRA frame to dw x dh — used to scale a decoded frame (whatever tier resolution
// arrived) up to the fixed shared-memory buffer size so the WPF always reads kW x kH. A low adaptation
// tier therefore shows as a softer (upscaled) picture, which is exactly the visible effect of §9.
static void resize_bgra(const VideoFrame& s, int dw, int dh, VideoFrame& o) {
  o.width = dw; o.height = dh; o.stride = dw * 4; o.format = PixelFormat::BGRA; o.data.assign((size_t)dw * dh * 4, 0);
  if (s.width <= 0 || s.height <= 0) return;
  int ss = s.stride ? s.stride : s.width * 4;
  double fx = (double)s.width / dw, fy = (double)s.height / dh;
  for (int y = 0; y < dh; ++y) {
    double sy = (y + 0.5) * fy - 0.5; int y0 = (int)(sy < 0 ? 0 : sy); double ty = sy - y0; if (y0 >= s.height - 1) { y0 = s.height - 1; ty = 0; }
    int y1 = y0 + 1 < s.height ? y0 + 1 : y0;
    for (int x = 0; x < dw; ++x) {
      double sx = (x + 0.5) * fx - 0.5; int x0 = (int)(sx < 0 ? 0 : sx); double tx = sx - x0; if (x0 >= s.width - 1) { x0 = s.width - 1; tx = 0; }
      int x1 = x0 + 1 < s.width ? x0 + 1 : x0;
      const uint8_t* p00 = &s.data[(size_t)y0 * ss + (size_t)x0 * 4]; const uint8_t* p01 = &s.data[(size_t)y0 * ss + (size_t)x1 * 4];
      const uint8_t* p10 = &s.data[(size_t)y1 * ss + (size_t)x0 * 4]; const uint8_t* p11 = &s.data[(size_t)y1 * ss + (size_t)x1 * 4];
      uint8_t* d = &o.data[((size_t)y * dw + x) * 4];
      for (int c = 0; c < 4; ++c) {
        double top = p00[c] * (1 - tx) + p01[c] * tx, bot = p10[c] * (1 - tx) + p11[c] * tx;
        d[c] = (uint8_t)(top * (1 - ty) + bot * ty + 0.5);
      }
      d[3] = 255;
    }
  }
}

// Cheap PRE-DECODE keyframe check for H.264 Annex-B: scan for a NAL of type 5 (IDR slice) or 7 (SPS, which
// precedes an IDR). Lets an overloaded receiver skip to the recovery keyframe WITHOUT decoding the stale
// P-frame backlog (the catch-up path). Non-H.264 payloads never match -> caller disables catch-up for them.
static bool au_has_idr_h264(const std::vector<uint8_t>& au) {
  const size_t n = au.size();
  for (size_t i = 0; i + 4 < n; ++i) {
    if (au[i] == 0 && au[i + 1] == 0 &&
        (au[i + 2] == 1 || (au[i + 2] == 0 && au[i + 3] == 1))) {
      size_t h = (au[i + 2] == 1) ? i + 3 : i + 4;         // NAL header byte
      if (h < n) { int t = au[h] & 0x1F; if (t == 5 || t == 7) return true; }
    }
  }
  return false;
}

int main(int argc, char** argv) {
  char id = 'A'; int lport = 50001, rport = 50002, fps = 15, gop_frames = 48; double loss = 0.05, seconds = 0, link_kbps = 800;
  int force_w = 0, force_h = 0;   // --enc-res WxH: pin the encode resolution (overrides §9), for forcing the receive-side RAISR path
  bool cc_on = false, adapt_flag = true, audio_on = true, use_mic = false, play_audio = false, nack_on = true, avsync = true, pli_on = true, content_fps = true, dual = false, recv_sr = true, vfx = false; std::string source = "synth", content_cfg = "screen_content.cfg";
  // --vfx module strengths (overridable from AvpMonitor's 「配置」window; defaults = the content-aware tuning).
  // (zltCDCC has no strength — it's a deterministic edge-directed upscaler, DCCI — so no --vfx-dcc.)
  float vfx_light = 0.40f, vfx_color = 0.35f, vfx_sharpen_cam = 0.30f, vfx_sharpen_screen = 0.60f, vfx_clahe = 3.0f;
  // Video codec for this peer's stream. Default vp9 = VP9 screen-content coding (sharp text). `h264`
  // keeps the minih264 baseline path for A/B comparison; `av1` selects the Zoom-exact AV1 SC backend
  // if it's been built in (AVP_WITH_AOM), otherwise it degrades to VP9 (see vp9_screen.hpp factory).
  std::string codec = "vp9";
  for (int i = 1; i < argc; ++i) {
    if (!strcmp(argv[i], "--id") && i + 1 < argc) id = argv[++i][0];
    else if (!strcmp(argv[i], "--local-port") && i + 1 < argc) lport = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--remote-port") && i + 1 < argc) rport = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--fps") && i + 1 < argc) fps = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--loss") && i + 1 < argc) loss = atof(argv[++i]);
    else if (!strcmp(argv[i], "--seconds") && i + 1 < argc) seconds = atof(argv[++i]);
    else if (!strcmp(argv[i], "--source") && i + 1 < argc) source = argv[++i];
    else if ((!strcmp(argv[i], "--codec") || !strcmp(argv[i], "--screen-codec")) && i + 1 < argc) codec = argv[++i];
    else if (!strcmp(argv[i], "--cc")) cc_on = true;
    else if (!strcmp(argv[i], "--link-kbps") && i + 1 < argc) link_kbps = atof(argv[++i]);
    else if (!strcmp(argv[i], "--no-adapt")) adapt_flag = false;
    else if (!strcmp(argv[i], "--no-audio")) audio_on = false;
    else if (!strcmp(argv[i], "--mic")) use_mic = true;
    else if (!strcmp(argv[i], "--play")) play_audio = true;
    else if (!strcmp(argv[i], "--no-nack")) nack_on = false;
    else if (!strcmp(argv[i], "--no-avsync")) avsync = false;   // don't gate video on the audio clock (A/B: still measures offset)
    else if (!strcmp(argv[i], "--no-pli")) pli_on = false;      // don't request keyframes on decode failure (A/B for PLI/FIR)
    else if (!strcmp(argv[i], "--gop") && i + 1 < argc) gop_frames = atoi(argv[++i]);   // periodic keyframe cadence (frames)
    else if (!strcmp(argv[i], "--no-content-fps")) content_fps = false;   // don't drop fps when the screen is static (A/B)
    else if (!strcmp(argv[i], "--content-cfg") && i + 1 < argc) content_cfg = argv[++i];   // screen content-mode config (Zoom SetConfig analog)
    else if (!strcmp(argv[i], "--dual")) dual = true;   // send camera(ch3) + screen-share(ch2) concurrently (Zoom ds+video)
    else if (!strcmp(argv[i], "--no-recv-sr")) recv_sr = false;   // don't super-res the received frame on display (A/B vs bilinear)
    else if (!strcmp(argv[i], "--vfx")) vfx = true;               // Zoom ns_vpp perceptual enhance: LightAdapt+ColorAdapt(camera)+CLAHE+sharpen (send) + DCC (recv)
    else if (!strcmp(argv[i], "--vfx-light") && i + 1 < argc) vfx_light = (float)atof(argv[++i]);            // camera auto-brightness strength
    else if (!strcmp(argv[i], "--vfx-color") && i + 1 < argc) vfx_color = (float)atof(argv[++i]);            // camera auto white-balance strength
    else if (!strcmp(argv[i], "--vfx-sharpen-cam") && i + 1 < argc) vfx_sharpen_cam = (float)atof(argv[++i]);// camera unsharp gain
    else if (!strcmp(argv[i], "--vfx-sharpen-screen") && i + 1 < argc) vfx_sharpen_screen = (float)atof(argv[++i]); // screen unsharp gain
    else if (!strcmp(argv[i], "--vfx-clahe") && i + 1 < argc) vfx_clahe = (float)atof(argv[++i]);            // screen CLAHE clip limit
    else if (!strcmp(argv[i], "--enc-res") && i + 1 < argc) { if (sscanf(argv[++i], "%dx%d", &force_w, &force_h) != 2) { force_w = force_h = 0; } }  // pin encode res (e.g. 640x360) to force recv RAISR
  }
#ifndef AVP_WITH_FFMPEG
  codec = "h264base";   // VP9/AV1/x264 backends need FFmpeg; without it fall back to built-in minih264.
#endif
  // "h264base" = the minih264 baseline stand-in (built-in). vp9/av1/h264/h265 go through the avcodec
  // factory: h264/h265 = the real zlt codec family (libx264/libx265), av1 = zbt SC (libaom).
  const bool use_minih264 = (codec == "h264base");
  std::printf("peer %c: local :%d  remote :%d  fps=%d loss=%.0f%% src=%s codec=%s\n",
              id, lport, rport, fps, loss * 100, source.c_str(), codec.c_str());

  WsaScope wsa;
  UdpSocket rx; if (!rx.open((uint16_t)lport)) { std::printf("bind %d failed\n", lport); return 1; }
  UdpSocket tx; tx.open(0);
  ipc::ShmPublisher<ipc::PeerShare> shm;
  if (!shm.open(ipc::kPeerMap(id))) { std::printf("shm open failed\n"); return 1; }
  shm->magic = ipc::kMagic; shm->width = ipc::kW; shm->height = ipc::kH; shm->running = 1; shm->loss_pct = (int)(loss * 100);
  ipc::ShmReader<ipc::ControlBlock> ctrl; ctrl.open(ipc::kControlMap());

  // Screen content-mode config (Zoom's SceneChangeDetect SetConfig analog): load overrides from a key=value
  // file if present, else defaults. The thresholds are config-driven in Zoom too (IDA: cfg blob, not consts).
  ScreenContentConfig ccfg;
  bool ccfg_loaded = ccfg.load(content_cfg);
  std::printf("peer %c: screen content cfg = %s (analysis %dx%d, video_thresh %.1f, enter %.1fs/exit %.1fs, video_fps %d)\n",
              id, ccfg_loaded ? content_cfg.c_str() : "(defaults)", ccfg.analysis_w, ccfg.analysis_h, ccfg.video_thresh, ccfg.enter_sec, ccfg.exit_sec, ccfg.video_fps);

  // send side: real capture source — screen (DXGI/WGC/...) or camera (MediaFoundation). Falls back to
  // a synthetic frame if the chosen source can't open (e.g. the one webcam already taken by the peer).
  std::unique_ptr<IVideoSource> cap_src; std::string notes;
  if (source == "screen") { CaptureConfig cap; cap_src = CreateBestScreenSource(cap, notes); }
  else if (source == "camera") { CaptureConfig cap; auto cam = std::make_unique<MfCameraSource>(); if (cam->open(cap)) cap_src = std::move(cam); else std::printf("peer %c: camera open failed -> synth\n", id); }
  // Preprocess config. The zlt temporal IIR denoise (out = 0.37*cur + 0.63*prev) is a CAMERA step —
  // it removes sensor noise but, with motion_guard=0, blends the previous frame into moving pixels and
  // leaves a GHOST/trail on anything that scrolls (§2.2 "快速运动边缘拖尾"). Screen content has no sensor
  // noise, so denoise it NOT at all; for camera keep it but turn on the anti-ghost motion guard.
  VideoPreprocessConfig ppc;
  const bool cam0 = (source == "camera");
  // --vfx perceptual enhance is CONTENT-AWARE. CLAHE (local histogram EQ) + DCC (local contrast) sharpen
  // TEXT/screen beautifully but on a low-bitrate compressed FACE they amplify block-artifacts, skin
  // unevenness and noise -> the picture looks WORSE, not better. So they are SCREEN-ONLY. Camera gets the
  // gentle, face-appropriate chain instead: denoise + auto-brightness + white-balance + a light unsharp.
  ppc.clahe   = vfx && !cam0; ppc.clahe_clip = vfx_clahe; // CLAHE: screen/document local-contrast only (harsh on faces)
  ppc.sharpen = vfx;                                      // unsharp is ok on faces...
  ppc.sharpen_amount = cam0 ? vfx_sharpen_cam : vfx_sharpen_screen;  // ...but gentler for camera (don't amplify compression noise)
  ppc.light = vfx && cam0; ppc.light_strength = vfx_light;   // auto-brightness: camera only
  ppc.color = vfx && cam0; ppc.color_strength = vfx_color;   // auto white-balance: camera only (screen colors are intentional)
  ppc.denoise = (source == "camera");        // screen has no sensor noise -> no denoise (no scroll ghost)
  ppc.denoise_motion_adaptive = true;        // camera: ghost-free spatial-temporal (temporal on static,
                                             //         spatial on motion) — a plain IIR trails (§2.2)
  VideoPreprocessor pp(ppc);
  // H.264 path (used when --codec h264): minih264 baseline + real temporal-SVC references.
  VideoEncoderConfig ec; ec.width = ipc::kW; ec.height = ipc::kH; ec.fps = fps; ec.bitrate_bps = cc_on ? 2000000 : 1200000;
  ec.temporal_layers = 3; ec.layered_refs = true; ec.gop = 32;   // periodic IDR so lost keyframes recover
  H264Encoder enc;
  std::unique_ptr<IScreenEncoder> senc;   // VP9/AV1/H264/H265 avcodec path (default)
  const bool camera = (source == "camera");
  const bool adapt  = adapt_flag && !use_minih264 && force_w <= 0;   // §9 ladder off when a res is pinned
  // The current encode TIER (resolution/fps/bitrate). Adaptive: start at the best tier, the §9 loop moves
  // it with the network. Non-adaptive: fixed full-res + the CLI fps. --enc-res WxH pins a low res so the
  // decoded frame is < display -> the receive-side RAISR (and its chroma upsample) path always engages.
  VideoTier tier = (force_w > 0)
                       ? VideoTier{ force_w, force_h, fps, 1500, "forced-lo" }
                       : (adapt ? (camera ? CameraTier(recon::mcm::BwLevel::L4) : ScreenTier(recon::mcm::BwLevel::L4))
                                : VideoTier{ ipc::kW, ipc::kH, fps, 6000, "fixed" });
  int enc_w = tier.w, enc_h = tier.h, cur_fps = tier.fps, cur_kbps = tier.kbps, tier_fps = tier.fps;
  // (re)create the screen encoder at a given tier — called on startup and whenever the tier resolution
  // changes (avcodec contexts are fixed-size, so a resolution switch = a fresh encoder + a keyframe).
  auto open_senc = [&](int w, int h, int f, int kb, bool video_mode = false) -> bool {
    ScreenEncParams sp; sp.width = w; sp.height = h; sp.fps = f; sp.kbps = kb; sp.gop = gop_frames;
    sp.screen_content = !camera;
    // Content-adaptive screen mode (§ video-in-share): SHARP text = AV1 good-mode + low qmax (slow, ~8 fps);
    // SMOOTH video = AV1 realtime + higher qmax (fast, sustains the boosted fps). Zoom picks by content.
    if (ParseScreenCodec(codec) == ScreenCodec::AV1) { sp.realtime = video_mode; sp.cpu_used = 8; sp.qmax = video_mode ? 40 : 14; }
    // camera H.264/H.265: let Zoom's injected TextureMotion QP map drive adaptive QP (codec AQ off, §3.3)
    ScreenCodec pc = ParseScreenCodec(codec);
    if (pc == ScreenCodec::H264 || pc == ScreenCodec::H265) {
      sp.ext_qp_map = true;
      // Content-adaptive rate: the recovered zlt H.264 backend uses a QP range [20,40] (实证,
      // zlt_h264_backend.hpp). qmin=20 is a QUALITY CAP — a simple/static camera scene encodes at QP20
      // and undershoots the bitrate target instead of wasting bits to fill it (was qmin 4 = near-lossless
      // fill). So the bitrate now tracks CONTENT (cheap when simple, up to the tier cap when busy) like Zoom.
      sp.qmin = 20; sp.qmax = 40;
    }
    senc = MakeScreenEncoder(ParseScreenCodec(codec));
    return senc && senc->open(sp);
  };
#ifdef AVP_WITH_FFMPEG
  if (use_minih264) { enc.open(ec); }
  else {
    if (!open_senc(enc_w, enc_h, cur_fps, cur_kbps)) { std::printf("peer %c: screen encoder (%s) open failed\n", id, codec.c_str()); return 1; }
    std::printf("peer %c: encoder = %s  tier=%s  adapt=%d\n", id, senc->name(), tier.label, adapt ? 1 : 0);
  }
#else
  if (use_minih264) enc.open(ec);
#endif
  AdaptationController adaptor(camera);   // the reconstructed mcm brain + video ladder
  Packetizer pk(1100, /*pt = video channel 3*/ 3); FecEncoder fenc;
  CongestionController cc(2000000, 100000, 8000000);   // GCC/BWE, fed by real transport-cc feedback below
  uint32_t ts = 3000; int pkts_sent = 0, fec_sent = 0;
  // ---- BWE / send pacer (full GCC on the real path): media+FEC are ENQUEUED into a SendPacer and released
  // at the BWE target rate (no burst). The receiver reports each packet's arrival (transport-cc, wire type 6);
  // the sender matches them to its send times -> feeds the GCC (`cc`) real inter-packet delay+loss. cc's target
  // drives the pacer rate + the encoder bitrate. --cc caps the target at the simulated link (the bottleneck).
  SendPacer pacer; pacer.set_rate_bps(2000000);
  int last_open_kbps = tier.kbps; auto last_reopen = std::chrono::steady_clock::now();   // BWE re-opens the encoder on a big rate change (avcodec set_bitrate is ~a no-op mid-stream)
  std::unordered_map<uint16_t, std::pair<int64_t, int>> sendlog;   // media seq -> (paced-out time_us, size) for BWE
  std::mutex twcc_mtx; std::vector<std::pair<uint16_t, uint16_t>> twcc_pending;   // rxth -> main: reported {seq, arrival_ms}
  auto us_now = [] { return (int64_t)std::chrono::duration_cast<std::chrono::microseconds>(clockt::now().time_since_epoch()).count(); };
  // recv side — decoder matches the sender's codec (both peers run the same --codec).
#ifdef AVP_WITH_FFMPEG
  H264Decoder dec;
  std::unique_ptr<IScreenDecoder> sdec;
  if (use_minih264) dec.open();
  else { sdec = MakeScreenDecoder(ParseScreenCodec(codec)); sdec->open(); }
  // Receive-side super-res (Zoom's render-path RAISR): when a reduced tier arrives and must be upscaled to
  // the display, refine it with GPU RAISR (matched bank) instead of a bilinear stretch. Enabled for BOTH
  // screen (Zoom zltCScreenRAISR) and camera (Zoom zltCRaisr) — Zoom ships a render-side RAISR for each.
  // Falls back to bilinear if the GPU/bank aren't available. NOTE: the bank is screen-trained, so camera
  // is cross-domain (still a net gain; Zoom uses a separate camera-trained bank). Bank ships next to exe.
  RecvSuperRes rsr;
  bool rsr_init = recv_sr && (rsr.init("raisr_bank.bin", "raisr_cam_bank_x2.bin", "raisr_cam_bank_x3.bin") ||
                              rsr.init("D:/code/work/bin2cpp-output/recon/raisr_bank.bin",
                                       "D:/code/work/bin2cpp-output/recon/raisr_cam_bank_x2.bin",
                                       "D:/code/work/bin2cpp-output/recon/raisr_cam_bank_x3.bin"));
  bool rsr_ok = rsr_init;   // both paths may be ready; the per-frame path follows the REMOTE content type
  // Cross-peer content signal (#5): pick the super-res path from the REMOTE sender's content_mode (camera
  // vs screen), not our own source. A co-located demo peer reads the other peer's PeerShare; real
  // conferencing would carry the content type on the wire. Falls back to our own `camera` flag if absent.
  char remote_id = (id == 'A') ? 'B' : 'A';
  ipc::ShmReader<ipc::PeerShare> remote_share; remote_share.open(ipc::kPeerMap(remote_id));
  if (recv_sr)
    std::printf("peer %c: recv-side super-res: screen=%s  camera=%s  (path follows remote content_mode)\n", id,
                (rsr_ok && rsr.readyFor(false)) ? "GPU" : "off",
                (rsr_ok && rsr.readyFor(true)) ? (rsr.cameraGpu() ? "GPU cam-bank(x2/x3)" : "CPU cam-bank(x2/x3)") : "off");
#endif
  // ---- DUAL STREAM (Zoom: camera video = channel 3, desktop-share = channel 2, concurrent+independent;
  // per-channel bw_level in the type-53 QoS PDU). --dual runs a SECOND video channel = the OTHER content
  // (camera-primary -> screen share; screen-primary -> camera), its own source/encoder/decoder/packetizer
  // + its own FEC, demuxed at the receiver by the wire channel tag and composited as a PIP. The screen-
  // share leg encodes at NATIVE resolution (kW x kH) so shared TEXT stays sharp (encoding it at 720p and
  // upscaling for the composite blurred it) — screen content at low fps keeps that affordable.
  const int kCh2 = 2, enc2_w = ipc::kW, enc2_h = ipc::kH;
  std::unique_ptr<IVideoSource> cap_src2;
  Packetizer pk2(1100, /*pt = ds channel 2*/ kCh2);
#ifdef AVP_WITH_FFMPEG
  std::unique_ptr<IScreenEncoder> senc2; std::unique_ptr<IScreenDecoder> sdec2;
  ScreenCodec sec_codec = camera ? ScreenCodec::VP9 : ScreenCodec::H264;   // secondary is screen(vp9) if primary camera, else camera(h264)
  if (dual) {
    if (camera) { CaptureConfig cap; std::string n2; cap_src2 = CreateBestScreenSource(cap, n2); }   // camera primary -> share the screen
    else { CaptureConfig cap; auto cam = std::make_unique<MfCameraSource>(); if (cam->open(cap)) cap_src2 = std::move(cam); }
    senc2 = MakeScreenEncoder(sec_codec);
    ScreenEncParams sp2; sp2.width = enc2_w; sp2.height = enc2_h; sp2.fps = camera ? 8 : 15; sp2.kbps = camera ? 3500 : 1200; sp2.gop = 48;
    sp2.screen_content = camera; if (sec_codec == ScreenCodec::AV1) { sp2.realtime = false; sp2.cpu_used = 8; sp2.qmax = 20; }
    senc2->open(sp2);
    sdec2 = MakeScreenDecoder(sec_codec); sdec2->open();
    std::printf("peer %c: DUAL — ch3=%s(%s) + ch2=%s(%s)\n", id, camera ? "camera" : "screen", codec.c_str(), camera ? "screen" : "camera", sec_codec == ScreenCodec::VP9 ? "vp9" : "h264");
  }
#endif
  FrameAssembler fa; int recv_frames = 0, recv_dec = 0, recv_rec = 0, recv_drop = 0, raw_recv = 0, ch2_dec = 0, sr_frames = 0, sr_skipped = 0;
  // NACK (§4 burst-loss retransmit): sender keeps a history (main thread), receiver (rxth) asks for
  // missing seqs; the remote's NACK arrives on rx and is queued for the main thread to resend via tx.
  RetransmitBuffer rtx_buf(512);
  std::mutex nack_mtx; std::vector<uint16_t> nack_req; int nacks_sent = 0, retx_sent = 0;
  // PLI/FIR (Zoom zlt SetKeyPictureRequest): the receiver (rxth) requests a fresh key/IDR when its decoder
  // loses sync; the request arrives on the sender's rx and sets force_key_req (2=KeyPicture/PLI, 4=Idr/FIR,
  // IDR supersedes) which the main send loop consumes to force the next frame to be a keyframe.
  std::atomic<int> force_key_req{ 0 };
  std::atomic<int> kf_pending_reqno{ -1 }, kf_served_reqno{ -1 };   // Zoom §Q1 dedup: emit at most ONE key per recovery request-number (coalesce a receiver's 100ms re-requests)
  int kfreq_sent = 0, kfreq_recv = 0, forced_keys = 0;
  // §7a real QoS (mcm cmd 301): the REMOTE receiver measures OUR outgoing stream and reports back;
  // these are what the §9 adaptation reads (real measured loss/jitter, not the locally-injected value).
  std::atomic<int> rep_loss_x10k{ 0 }, rep_jitter_ms{ 0 }, rep_fec_x100{ 0 };
  std::atomic<int> rep_overload{ 0 };   // §9+compute: remote receiver's decode-lag level (wire type 7) — it can't decode our tier fast enough
  std::atomic<long> dbg_gaps{ 0 }, dbg_recv{ 0 };   // raw measurement (this peer's incoming) for diagnostics
  // A/V lip-sync (Zoom: audio is the master clock, video Present is gated by A/V-sync timing —
  // AV_PIPELINE_DETAILS "对齐音视频时间戳", ARCHITECTURE "Present 受 A/V 同步时序控制"). Both our audio and
  // video packets carry a capture timestamp in ONE shared timebase (ms since peer_epoch); the remote
  // receiver holds each decoded video frame until the audio playout clock reaches that frame's stamp.
  const auto peer_epoch = clockt::now();
  auto cap_ms_now = [&] { return (uint32_t)std::chrono::duration_cast<std::chrono::milliseconds>(clockt::now() - peer_epoch).count(); };
  std::atomic<uint32_t> a_play_cap{ 0 };     // capture-stamp of the audio frame currently playing out (remote timebase)
  std::atomic<bool>     a_clock_valid{ false };  // true once audio playout has started (else video presents ungated)
  std::atomic<int>      dbg_avsync{ 0 };     // EWMA of the presented video-vs-audio offset (ms) for the exit report
  // Freeze-on-loss concealment diagnostics (exit report): are lost-reference frames being CONCEALED (frozen)
  // or LEAKING to screen (mosaic)? unfreeze_backstop / unfreeze_dirtykey > 0 = we resumed onto a NOT-clean
  // recovery point = the mosaic leak. evicted = pictures given up; freezes = concealment episodes entered.
  std::atomic<int>      dbg_evicted{ 0 }, dbg_freezes{ 0 }, dbg_unfreeze_key{ 0 }, dbg_unfreeze_dirtykey{ 0 }, dbg_unfreeze_backstop{ 0 }, dbg_frozen_holds{ 0 };
  // Real network delay for the §9 G.107 MOS (was a 40/300 ms stub). abs_net_delay = one-way RTT/2 (probe/echo,
  // type-5 wire) + the audio jitter-buffer playout depth (jb_target×20 ms) — the real mouth-to-ear latency.
  std::atomic<int>      rtt_ms{ -1 };         // measured round-trip (ms); -1 = not yet measured
  std::atomic<int>      a_jb_delay_ms{ 60 };  // audio jitter-buffer playout delay (jb_target×20 ms)

  std::this_thread::sleep_for(std::chrono::milliseconds(400));   // let BOTH peers bind before anyone sends

  // Receive + decode on a dedicated thread: encode (send side, below) and decode (here) run in
  // parallel, so the send loop never blocks on decoding — the key to holding frame rate for HD video.
  // fa/dec/rx are touched only here; enc/tx only on the main thread; shm fields are disjoint (no lock).
  std::atomic<bool> running{ true };
  std::thread rxth([&] {
    UdpSocket ntx; ntx.open(0);                 // receiver -> sender NACK feedback channel
    NackTracker nt(2);                          // reorder slack 2 (don't NACK until 2 newer arrived)
    auto last_nack = clockt::now(); auto last_qos = clockt::now(); auto last_probe = clockt::now();
    auto last_rstat = clockt::now(); int last_cud = 0;   // compute-status (type 7): ~1 s cadence + last catchup_drops sample
    std::vector<std::pair<uint16_t, uint16_t>> twcc_win; auto twcc_base = clockt::now(); auto last_twcc = clockt::now();   // transport-cc: {seq, arrival_ms} window we report back
    // §7a QoS measurement on the INCOMING stream. Loss = RFC3550/RTCP fraction-lost = expected−received
    // over the interval (expected = highest_seq−first_seq+1). This is exactly Zoom's cur_packets_loss_rate
    // method, and unlike per-gap accumulation it is ROBUST TO REORDERING: a NACK-retransmitted packet
    // arrives out of order (old seq) but only bumps `win_recv` — it never lowers the max, so it can't be
    // miscounted as fresh loss. (The old `win_last`-gap counter mis-read ~6% real loss as ~55% once NACK
    // resends started arriving late.) Jitter = RFC3550-style EWMA of per-frame inter-arrival deviation.
    int win_recv = 0; uint16_t win_first = 0; int win_max = 0; bool win_have = false;
    uint32_t jit_ts = 0; bool jit_have = false; double jit_gap = 0, jit = 0; auto jit_arr = clockt::now();
    std::map<uint32_t, VideoFrame> vbuf;   // A/V sync: decoded frames keyed by capture-stamp, released when audio playout reaches them
    auto last_kfreq = clockt::now(); bool ever_decoded = false;   // PLI/FIR: throttle keyframe requests; pick Idr before first decode
    // FREEZE-ON-LOSS concealment (user's call: a brief freeze beats mosaic). A lost picture breaks the
    // H.264 reference chain, so every following P-frame decodes against a wrong reference = garbage. Rather
    // than display that, HOLD the last COMPLETE frame until a clean recovery point (an intra/IDR frame,
    // requested via PLI) arrives. `frozen` persists across polls; a 2 s safety timeout un-freezes anyway.
    bool frozen = false; auto froze_at = clockt::now(); bool pli_want = false; int frozen_holds = 0; int catchup_drops = 0;
    bool prev_frozen = false; uint16_t kf_reqno = 0;   // Zoom §Q1 dedup: one monotonic recovery request-number per freeze EPISODE (not per re-request)
    // CATCH-UP: an overloaded peer (decode slower than arrival) accumulates seconds of backlog -> a/v drifts
    // and freeze-recovery keyframes sit far back. When behind, SKIP decoding stale P-frame AUs and resync at
    // the next keyframe (freeze covers the gap). Only for H.264 (we can spot a keyframe pre-decode).
    const bool can_catchup = (codec == "h264" || codec == "h264base");
    FrameAssembler fa2;                    // DUAL: the ch2 (screen-share) reassembler, demuxed by payload_type=2
    VideoFrame cam_buf, screen_buf; bool have_cam = false, have_screen = false;   // DUAL: latest of each leg, for the PIP composite
    // Composite the two legs into shm: screen-share FULL (background) + camera as a PIP top-right (like Zoom).
    auto do_composite = [&] {
      std::vector<uint8_t> out((size_t)ipc::kW * ipc::kH * 4, 32);
      if (have_screen) { VideoFrame bg; resize_bgra(screen_buf, ipc::kW, ipc::kH, bg); out = std::move(bg.data); }
      if (have_cam) {
        int pw = ipc::kW / 4, ph = ipc::kH / 4; VideoFrame pip; resize_bgra(cam_buf, pw, ph, pip);
        int ox = ipc::kW - pw - 24, oy = 24;
        for (int y = -3; y < ph + 3; ++y) for (int x = -3; x < pw + 3; ++x) {   // 3px white border + PIP
          int gx = ox + x, gy = oy + y; if (gx < 0 || gy < 0 || gx >= ipc::kW || gy >= ipc::kH) continue;
          size_t d = ((size_t)gy * ipc::kW + gx) * 4;
          if (x < 0 || y < 0 || x >= pw || y >= ph) { out[d] = out[d + 1] = out[d + 2] = 255; }
          else { size_t s = ((size_t)y * pw + x) * 4; out[d] = pip.data[s]; out[d + 1] = pip.data[s + 1]; out[d + 2] = pip.data[s + 2]; out[d + 3] = 255; }
        }
      }
      ipc::publish_frame(shm.get(), out.data(), out.size());   // double-buffer flip (anti-tearing) + recv_frame_seq++
    };
    std::vector<uint8_t> rbuf(4096);
    while (running.load(std::memory_order_relaxed)) {
      bool got = false;
      for (;;) {
        int n = rx.recv_nb(rbuf.data(), (int)rbuf.size()); if (n <= 0) break; got = true; ++raw_recv;
        std::vector<uint16_t> nk; int ql, qj, qf;
        if (nack_on && wire::parse_nack(rbuf.data(), n, nk)) {   // remote asked us to resend -> queue for main
          std::lock_guard<std::mutex> lg(nack_mtx); for (uint16_t s : nk) nack_req.push_back(s); continue;
        }
        if (wire::parse_qos(rbuf.data(), n, ql, qj, qf)) {       // remote's QoS about OUR stream -> feed §9
          rep_loss_x10k.store(ql); rep_jitter_ms.store(qj); rep_fec_x100.store(qf); continue;
        }
        uint8_t kreq, kspatial; uint16_t kpic;
        if (wire::parse_kfreq(rbuf.data(), n, kreq, kspatial, kpic)) {   // remote's decoder lost sync -> force a key
          // Zoom's SetKeyPictureRequest dedup (dispatcher sub_180008370 case 4: slot+36 = max(cur, reqno)): a
          // receiver re-requests every 100 ms while still broken, all carrying the SAME episode reqno — emit at
          // most ONE key per reqno. Only accept a request whose reqno we haven't already SERVED (coalesce the rest).
          int reqno = (int)kpic;
          if (reqno != kf_served_reqno.load()) {
            int cur = force_key_req.load();
            if (kreq == wire::KFREQ_IDR || cur != wire::KFREQ_IDR) force_key_req.store(kreq);  // Idr supersedes KeyPicture
            kf_pending_reqno.store(reqno);
          }
          ++kfreq_recv; continue;
        }
        uint32_t pts; uint8_t pecho;
        if (wire::parse_rttprobe(rbuf.data(), n, pts, pecho)) {          // RTT probe/echo
          if (!pecho) { auto e = wire::serialize_rttprobe(pts, 1); ntx.send_to((uint16_t)rport, e.data(), (int)e.size()); }  // bounce it back
          else { int r = (int)(cap_ms_now() - pts); int prev = rtt_ms.load();   // our echo returned -> RTT = now - sent
                 rtt_ms.store(prev < 0 ? r : (int)(0.75 * prev + 0.25 * r)); }  // EWMA
          continue;
        }
        std::vector<std::pair<uint16_t, uint16_t>> tw;
        if (wire::parse_twcc(rbuf.data(), n, tw)) {                      // remote's arrival report about OUR stream -> BWE
          std::lock_guard<std::mutex> lg(twcc_mtx); for (auto& e : tw) twcc_pending.push_back(e); continue;
        }
        int rov;
        if (wire::parse_recvstatus(rbuf.data(), n, rov)) {              // remote can't DECODE our tier in real time -> §9 compute cap
          rep_overload.store(rov); continue;
        }
        WirePacket w;
        if (wire::deserialize(rbuf.data(), n, w)) {
          if (w.channel == kCh2) { fa2.add(w); continue; }        // DUAL: ch2 screen-share leg (media + FEC) -> fa2
          fa.add(w);                                              // ch3 (video) media + FEC -> primary assembler
          if (!w.is_fec) {
            if (nack_on) nt.observe(w.pkt.seq);                  // observe ALL (incl. resends) -> stop NACKing recovered seqs
            uint16_t am = (uint16_t)std::chrono::duration_cast<std::chrono::milliseconds>(clockt::now() - twcc_base).count();  // arrival for transport-cc
            if (twcc_win.size() < 400) twcc_win.push_back({ w.pkt.seq, am });
          }
          if (!w.is_fec && !w.is_retx) {                         // network loss/jitter = ORIGINALS only. Resends are the
            uint16_t s = w.pkt.seq;                              // RTX "stream": they recover decode but must NOT hide the
            if (!win_have) { win_first = s; win_max = 0; win_have = true; }   // network loss the §9 ladder reacts to (Zoom
            else { int d = (int)(int16_t)(s - win_first); if (d > win_max) win_max = d; }  // measures loss on the media SSRC).
            ++win_recv;
            if (!jit_have || w.pkt.timestamp != jit_ts) {        // new frame -> one jitter sample
              auto nowt = clockt::now();
              if (jit_have) { double gap = std::chrono::duration<double, std::milli>(nowt - jit_arr).count(); double d = gap - jit_gap; if (d < 0) d = -d; jit += (d - jit) / 16.0; jit_gap = gap; }
              jit_arr = nowt; jit_ts = w.pkt.timestamp; jit_have = true;
            }
          }
        }
      }
      // ask the sender to resend the seqs we're still missing (throttled ~1 RTT so we don't NACK-storm)
      if (nack_on && std::chrono::duration<double, std::milli>(clockt::now() - last_nack).count() >= 15.0) {
        auto miss = nt.build_nack();
        if (!miss.empty()) { auto b = wire::serialize_nack(miss); ntx.send_to((uint16_t)rport, b.data(), (int)b.size()); ++nacks_sent; last_nack = clockt::now(); }
      }
      // RTT probe ~1 Hz: the remote bounces it straight back (above) and we time the round trip.
      if (std::chrono::duration<double, std::milli>(clockt::now() - last_probe).count() >= 1000.0) {
        auto pb = wire::serialize_rttprobe(cap_ms_now(), 0); ntx.send_to((uint16_t)rport, pb.data(), (int)pb.size()); last_probe = clockt::now();
      }
      // transport-cc: report the arrivals of OUR incoming media ~every 100 ms so the remote's BWE sees the
      // real per-packet delay/loss on this stream. Batched arrivals are relative to twcc_base (reset here).
      if (!twcc_win.empty() && std::chrono::duration<double, std::milli>(clockt::now() - last_twcc).count() >= 100.0) {
        auto b = wire::serialize_twcc(twcc_win); ntx.send_to((uint16_t)rport, b.data(), (int)b.size());
        twcc_win.clear(); twcc_base = clockt::now(); last_twcc = clockt::now();
      }
      // report measured QoS back to the sender every score-report period (mcm cmd 301). The period is the
      // RECOVERED constant kScoreReportPeriodMs = 9800 ms (0x2648) — Zoom's value, not an invented one; the
      // ~10 s interval also accumulates enough packets that "cur_" loss is stable (screen P-frames are
      // sparse), so it's measured over the interval and reset (matching "cur_" = current-interval rate).
      if (std::chrono::duration<double, std::milli>(clockt::now() - last_qos).count() >= (double)recon::mcm::MediaChannel::kScoreReportPeriodMs) {
        int expected = win_have ? win_max + 1 : 0;              // RFC3550: expected = highest−first+1
        int lost = expected - win_recv; if (lost < 0) lost = 0;  // dupes/late resends can make recv>expected
        int loss_x10k = expected > 0 ? (int)((double)lost / expected * 10000) : 0;
        int fec_x100 = recv_frames > 0 ? (int)(100.0 * recv_rec / recv_frames) : 0;
        auto b = wire::serialize_qos(loss_x10k, (int)(jit + 0.5), fec_x100);
        ntx.send_to((uint16_t)rport, b.data(), (int)b.size());
        dbg_gaps.store(lost); dbg_recv.store(win_recv);
        win_recv = 0; win_have = false; last_qos = clockt::now();  // reset per report interval ("cur_" rate)
      }
      // COMPUTE-STATUS (type 7, ~1 s): tell the SENDER how far our video DECODE is behind real time so it can
      // drop RESOLUTION when this box can't decode the current tier — a compute limit invisible to loss-based §9
      // (an overloaded receiver falls seconds behind and the kernel drops real packets even at 0% injected loss).
      // Signal = the A/V Present lag (video-behind-audio, ms) in ~300 ms levels, boosted whenever we're actively
      // dropping stale frames to catch up (that IS "can't keep up", and works even with the audio clock absent).
      if (std::chrono::duration<double, std::milli>(clockt::now() - last_rstat).count() >= 1000.0) {
        int lag = -dbg_avsync.load(); if (lag < 0) lag = 0;      // video behind audio (ms); ahead/synced -> 0
        int ov = lag / 300;                                       // ~one level per 300 ms of decode lag
        int cud = catchup_drops - last_cud; last_cud = catchup_drops;
        if (cud >= 3 && ov < 2) ov = 2;                           // dropping stale frames = can't keep up (audio-independent)
        if (ov > 30) ov = 30;
        auto b = wire::serialize_recvstatus(ov);
        ntx.send_to((uint16_t)rport, b.data(), (int)b.size());
        last_rstat = clockt::now();
      }
      std::vector<uint8_t> au; AssembleStat as;
      while (fa.try_pop(au, as)) {
        ++recv_frames; if (as.recovered) ++recv_rec; recv_drop += as.dropped_pkts;
        { int ev = fa.take_evicted(); if (ev > 0) { dbg_evicted.fetch_add(ev); if (!frozen) { frozen = true; froze_at = clockt::now(); dbg_freezes.fetch_add(1); } pli_want = true; } }  // a picture was lost → ref chain broken → freeze + request a key
        // CATCH-UP: if we've fallen GENUINELY behind (a deep backlog still queued), don't spend decode time on
        // stale P-frames — DROP undecoded AUs until a keyframe, so an overloaded peer resyncs to a RECENT frame
        // instead of drifting seconds behind. Freeze covers the skipped gap; PLI fetches the key. Threshold is
        // deliberately DEEP (kCatchupBacklog ≈ 2 s of frames): a shallow one (>8) fired a freeze+keyframe-wait on
        // transient jitter the pipeline recovers from on its own (visible micro-stutter even at 0% loss). Sustained
        // overload is handled by the compute-aware tier downgrade (adaptation.hpp); this is only the last-resort
        // resync for a truly deep backlog.
        static constexpr int kCatchupBacklog = 24;
        if (can_catchup && (int)fa.pending() > kCatchupBacklog && !au_has_idr_h264(au)) {
          if (!frozen) { frozen = true; froze_at = clockt::now(); dbg_freezes.fetch_add(1); } pli_want = true; ++catchup_drops; continue;
        }
#ifdef AVP_WITH_FFMPEG
        I420Image out;
        bool ok = use_minih264 ? dec.decode(au, out) : sdec->decode(au, out);
        if (ok && out.w > 0) {
          // FREEZE-ON-LOSS: while frozen, this frame decodes against a lost reference (mosaic) — DON'T show
          // it; keep the last complete frame on screen until a clean intra/IDR recovery frame arrives. We
          // un-freeze ONLY on a keyframe (never time out onto a still-corrupt frame — the user's hard rule:
          // freeze beats mosaic). Keep re-requesting the key each held frame so a lost recovery key is
          // retried; a 10 s backstop only guards a truly-stuck stream (should never hit on a live sender).
          bool clean_key = out.keyframe && !out.corrupt;   // a keyframe that decoded WITHOUT concealment = a TRUE recovery point
          // A CORRUPT decode (avcodec concealed a missing/lost reference) breaks the ref chain even when the
          // reassembler saw NO eviction — a whole picture whose packets were ALL lost never enters the buffer, so
          // nothing is "evicted", yet the next P-frame here decodes to mosaic. Trust the decoder's own detection:
          // treat it exactly like a lost picture — freeze, request a key, never show it. (This is the leak that
          // was reaching the screen: decode-error frames with 0 evictions / 0 freezes.)
          if (out.corrupt && !frozen) { frozen = true; froze_at = clockt::now(); dbg_freezes.fetch_add(1); pli_want = true; }
          if (frozen) {
            double held = std::chrono::duration<double, std::milli>(clockt::now() - froze_at).count();
            if (clean_key) { frozen = false; dbg_unfreeze_key.fetch_add(1); }   // resume ONLY on a clean intra/IDR
            else if (held > 10000.0 && !out.corrupt) { frozen = false; dbg_unfreeze_backstop.fetch_add(1); }   // anti-hang backstop, never onto a corrupt frame
            else { pli_want = true; ever_decoded = true; ++frozen_holds; dbg_frozen_holds.fetch_add(1); if (out.corrupt) dbg_unfreeze_dirtykey.fetch_add(1); continue; }  // hold last clean frame + keep requesting the key (dirtykey counter now = corrupt frames held)
          }
          // Receive-side super-res: if the decoded tier is smaller than the display and super-res is on
          // (UI toggle in ctrl->reserved[0]: 2 = force off), RAISR-refine on the GPU instead of a bilinear
          // stretch — Zoom's zltCScreenRAISR render path. Else the plain bilinear upscale (or 1:1 at native).
          int srctl = (ctrl.valid() && ctrl->magic == ipc::kMagic) ? ctrl->reserved[0] : 0;
          // chroma upsample toggle (ctrl->reserved[1]: 1 = Zoom-exact guided filter, else our JBU) — live A/B
          rsr.setChromaGuided(ctrl.valid() && ctrl->magic == ipc::kMagic && ctrl->reserved[1] == 1);
          if (!remote_share.valid()) remote_share.open(ipc::kPeerMap(remote_id));   // remote may come up late
          // #5: the received content type is the REMOTE's content_mode (0=camera,1/2=screen,3=synth); fall
          // back to our own source flag if the remote share isn't up. This picks the RAISR path faithfully
          // even when A sends camera and B sends screen.
          int rcm = (remote_share.valid() && remote_share.get()->magic == ipc::kMagic) ? remote_share.get()->content_mode : (camera ? 0 : 1);
          bool recv_camera = (rcm == 0);
          // Zoom's source-size scale selection (zltCRaisr cmd 3, sub_1801B8EA0): super-res only for a
          // SMALL ENOUGH source — camera (mode 1) only <=480p, screen (mode 3) up to 720p; a >=720p source
          // is NOT super-resolved. 0 => bilinear this frame.
          int sr_mode = recv_camera ? 1 : 3;
          int sr_sel  = recon::zltcam::SelectScale(out.w, out.h, (int)ipc::kW, (int)ipc::kH, sr_mode);
          // #3 (Zoom "skip duplicate/redundant render work"): when we're BEHIND, this poll's `while(try_pop)`
          // decodes EVERY queued frame but the A/V present shows only the NEWEST — so RAISR-super-resing a frame
          // that a later-decoded one will supersede is wasted GPU. Skip super-res while frames remain queued
          // (fa.pending()>0); the frame that actually gets shown (pending==0) still gets the full RAISR path.
          bool superseded = fa.pending() > 0;
          if (superseded) ++sr_skipped;
          bool want_sr = rsr_ok && srctl != 2 && rsr.readyFor(recv_camera) && sr_sel != 0 && !superseded;
          VideoFrame bgra; bool did_sr = false; double sr_ms = 0;
          if (want_sr && rsr.Upscale(out, bgra, ipc::kW, ipc::kH, recv_camera, &sr_ms)) {
            did_sr = true;
          } else {
            // Zoom render-chain "Upsample" = zltCDCC = DCCI (Directional Cubic Convolution Interpolation),
            // an EDGE-DIRECTED 2x upscaler (NOT contrast — corrected mis-ID). For SCREEN content, when the
            // decoded tier is <=1/2 the display, do the faithful edge-directed 2x (sharp text/lines) before
            // the final resize, instead of plain bilinear. --vfx gates it; camera uses the clean bilinear.
            if (vfx && !recv_camera && out.w <= 1280 && out.w < (int)ipc::kW && out.valid()) {
              I420Image up; up.w = out.w * 2; up.h = out.h * 2; int aw, ah;
              recon::dcci::Upscale2x(out.y.data(), out.w, out.h, up.y, aw, ah);
              recon::dcci::Upscale2xBilinear(out.u.data(), out.cw(), out.ch(), up.u, aw, ah);
              recon::dcci::Upscale2xBilinear(out.v.data(), out.cw(), out.ch(), up.v, aw, ah);
              out = std::move(up);
            }
            I420ToBgra(out, bgra);
            if (bgra.width != ipc::kW || bgra.height != ipc::kH) {   // decoded tier != shm size -> scale up
              VideoFrame full; resize_bgra(bgra, ipc::kW, ipc::kH, full); bgra = std::move(full);
            }
          }
          shm->recv_sr_on = did_sr ? 1 : 0; shm->recv_sr_us = (int)(sr_ms * 1000.0); if (did_sr) ++sr_frames;
          vbuf[as.ts] = std::move(bgra); ++recv_dec;              // buffer keyed by capture-stamp for A/V-synced present
          if (vbuf.size() > 30) vbuf.erase(vbuf.begin());         // bound memory (~8 MB/frame)
          ever_decoded = true;
        }
#else
        shm->recv_frame_seq++;
#endif
      }
      // catch evictions that didn't surface a popped frame this poll (freeze covers them too)
      { int ev = fa.take_evicted(); if (ev > 0) { dbg_evicted.fetch_add(ev); if (!frozen) { frozen = true; froze_at = clockt::now(); dbg_freezes.fetch_add(1); } pli_want = true; } }
      // PLI/FIR: if the assembler gave up whole pictures as unrecoverable (P-frame ref chain broken), ask the
      // sender for a fresh key instead of waiting for the periodic GOP (Zoom SetKeyPictureRequest). Idr (FIR)
      // before we've ever decoded (join / no reference), else KeyPicture (PLI) recovery. Throttle ~1/100 ms
      // (the key is ~1 RTT away — don't storm while it's in flight). `pli_want` is also set by the freeze path.
      if (frozen && !prev_frozen) ++kf_reqno;   // rising edge = a NEW loss episode → new recovery request-number (Zoom's iRequestNumber)
      prev_frozen = frozen;
      if (pli_on && pli_want) {
        pli_want = false;
        double since = std::chrono::duration<double, std::milli>(clockt::now() - last_kfreq).count();
        if (since >= 100.0) {
          uint8_t rt = ever_decoded ? wire::KFREQ_KEYPICTURE : wire::KFREQ_IDR;
          auto b = wire::serialize_kfreq(rt, 0, kf_reqno);   // carry the EPISODE reqno so the sender coalesces the 100ms re-requests into ONE key
          ntx.send_to((uint16_t)rport, b.data(), (int)b.size()); ++kfreq_sent; last_kfreq = clockt::now();
        }
      }
#ifdef AVP_WITH_FFMPEG
      // FREEZE watchdog — WALL-CLOCK bounded, and OUTSIDE the decode branch. The un-freeze logic (clean keyframe /
      // backstop) only runs when a frame actually DECODES; if the pipeline stalls while frozen (slow encoder, a
      // static screen sending nothing, or a recovery keyframe that never completes) no frame decodes, so the
      // freeze would last FOREVER and a/v grows without bound — exactly the "0% loss screen-share stuck at −17 s"
      // report. Bound it here (this runs every poll): keep re-requesting the key, and HARD-CLEAR after a cap so the
      // next available frame is shown. A live sender recovers within one keyframe; this only guards a stuck pipe.
      if (frozen) {
        double held = std::chrono::duration<double, std::milli>(clockt::now() - froze_at).count();
        if (held > 700.0) pli_want = true;                     // still stuck → keep asking for a fresh key
        if (held > 2500.0) { frozen = false; ++frozen_holds; dbg_unfreeze_backstop.fetch_add(1); }  // never freeze forever
      }
      // A/V-synced PRESENT (Zoom: video Present gated by the audio master clock). Release the NEWEST buffered
      // frame whose capture-stamp <= the audio playout position; hold newer ones; drop older (stale) ones.
      // No audio clock yet (audio off / not started) -> present the latest immediately (ungated fallback).
      if (!vbuf.empty()) {
        bool clk_ok = a_clock_valid.load(std::memory_order_relaxed);
        uint32_t clk = a_play_cap.load(std::memory_order_relaxed);
        bool gate = avsync && clk_ok;                            // gate video on the audio clock (unless --no-avsync)
        auto pick = vbuf.end();
        if (!gate) pick = std::prev(vbuf.end());                 // ungated -> newest available
        else { auto it = vbuf.upper_bound(clk); if (it != vbuf.begin()) pick = std::prev(it); }  // gated -> newest <= clk
        if (pick != vbuf.end()) {
          VideoFrame& f = pick->second;
          shm->av_sync_ms = clk_ok ? (int)((int64_t)pick->first - (int64_t)clk) : 0;   // measured offset (gated ~0; ungated shows video lead)
          if (clk_ok) dbg_avsync.store((int)(0.9 * dbg_avsync.load() + 0.1 * shm->av_sync_ms));
          if (dual) { cam_buf = f; have_cam = true; }            // DUAL: camera becomes the PIP; composite below
          else ipc::publish_frame(shm.get(), f.data.data(), f.data.size());   // single stream: double-buffer flip (anti-tearing)
          vbuf.erase(vbuf.begin(), std::next(pick));             // presented + older removed
        }
      }
      // DUAL: decode the ch2 screen-share leg -> screen_buf, then composite (screen full + camera PIP) to shm.
      if (dual) {
        std::vector<uint8_t> au2; AssembleStat as2;
        while (fa2.try_pop(au2, as2)) { I420Image o2; if (sdec2 && sdec2->decode(au2, o2) && o2.w > 0) { I420ToBgra(o2, screen_buf); have_screen = true; ++ch2_dec; } }
        if (have_cam || have_screen) do_composite();
      }
#endif
      shm->recv_frames = recv_frames; shm->recv_decoded = recv_dec; shm->recv_recovered = recv_rec; shm->recv_dropped = recv_drop;
      shm->recv_frozen = frozen ? 1 : 0;   // UI: freeze-on-loss active (holding last complete frame vs showing mosaic)
      if (!got) std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
  });

  // ---- AUDIO leg: a steady 20 ms Opus loop on its own thread + socket pair (video ports + 100). A
  // synthetic tone (A=440 Hz, B=660 Hz) stands in for the mic so it's deterministic + feedback-safe on
  // one box; it's captured as float PCM, Opus-encoded, sent, received, Opus-decoded, and its RMS level
  // published to shm (audio_rx_mrms > 0 proves the real Opus round-trip). Playback is intentionally off.
#ifdef AVP_WITH_OPUS
  std::thread ath; int a_lost = 0, a_conceal = 0, a_lbrr = 0;
  int a_frames = 0, a_dtx = 0, a_cng = 0; long a_tx_bytes = 0, a_dtx_saved = 0;   // DTX: frames suppressed, comfort-noise gaps filled, bytes saved
  if (audio_on) ath = std::thread([&] {
    UdpSocket arx, atx;
    if (!arx.open((uint16_t)(lport + 100))) return;
    atx.open(0);
    OpusAudioEnc aenc; OpusAudioDec adec;
    if (!aenc.open(48000, 1, 24000, /*inband_fec*/ true, /*expected_loss*/ 20, /*dtx*/ true) || !adec.open(48000, 1)) { std::printf("peer %c: opus open failed\n", id); return; }
    const int fs = aenc.frame_size();
    AudioPlc plc;
    // source: microphone (--mic) downmixed to mono 48k, else a synthetic tone (A=440, B=660 Hz).
    WasapiAudioSource mic; bool have_mic = false;
    if (use_mic) { AudioCaptureConfig ac; ac.target = AudioTarget::DefaultMic; have_mic = mic.open(ac); if (!have_mic) std::printf("peer %c: mic open failed -> tone\n", id); }
    // 3A: AEC only makes sense with a real echo path (mic capturing the speaker) = mic AND playback on;
    // its far-end reference is the audio we play out (last_rx below). AGC always normalizes level; ANS
    // only for the mic (a steady synthetic tone would be wrongly attenuated by spectral-subtraction ANS).
    const bool aec_on = have_mic && play_audio;
    AudioPreprocessor a3a(AudioPreprocessConfig{ /*aec*/ aec_on, /*ans*/ have_mic, /*agc*/true, 20 });
    // live speaker (off by default; single-box mic+speaker is a real echo/feedback path — headphones!)
    StreamingAudioPlayer player; bool playing = false;
    if (play_audio) { playing = player.start(); if (!playing) std::printf("peer %c: audio playback open failed\n", id); }
    // NetEQ-lite jitter buffer: decoded PCM keyed by seq, played out in order at the 20 ms clock with a
    // small target cushion; a missing seq at playout time is concealed (PLC). last_rx = AEC far-end ref.
    std::map<uint16_t, std::pair<uint32_t, std::vector<uint8_t>>> jb;   // seq -> {capture-stamp, OPUS packet} (for LBRR + A/V sync)
    uint16_t play_seq = 0; bool play_started = false;
    uint32_t cur_play_cap = 0; bool have_play_cap = false;   // capture-stamp of the frame currently playing (A/V master clock)
    // NetEQ (viper, 实证): the buffer depth ADAPTS to measured jitter (not a fixed cushion), and playout
    // accelerates (drop) / decelerates (hold) to track it. jb_target frames ~ 3 + jitter/20ms.
    int jb_target = 3; double a_jit = 0; auto a_last_arr = clockt::now(); bool a_arr = false;
    std::vector<float> last_rx(fs, 0.f); int underrun = 0; double rx_ewma = 0;
    std::vector<float> micbuf;
    const double freq = (id == 'A') ? 440.0 : 660.0;
    uint64_t phase = 0, asamp = 0; uint16_t tx_seq = 0; bool a_prev_dtx = false;   // a suppressed frame preceded the next sent one
    std::vector<uint8_t> rb(8192);
    uint32_t arng = 0x9E3779B9u ^ (uint32_t)id;
    auto au_rand = [&] { arng = arng * 1664525u + 1013904223u; return (arng >> 8) / (double)(1u << 24); };
    auto a0 = clockt::now(); double anext = 0;
    while (running.load(std::memory_order_relaxed)) {
      // 1) grab one fs-sample mono frame
      std::vector<float> frame(fs, 0.f);
      if (have_mic) {
        AudioFrame af;
        while ((int)micbuf.size() < fs && mic.read(af) && af.valid()) {
          const AudioFormat& F = af.format; int chs = F.channels ? F.channels : 1; const uint8_t* d = af.data.data();
          for (int i = 0; i < af.frames; ++i) { double acc = 0;
            for (int c = 0; c < chs; ++c) acc += F.is_float ? ((const float*)d)[i*chs+c] : (F.bits==16 ? ((const int16_t*)d)[i*chs+c] / 32768.0 : 0);
            micbuf.push_back((float)(acc / chs)); }
        }
        if ((int)micbuf.size() >= fs) { frame.assign(micbuf.begin(), micbuf.begin()+fs); micbuf.erase(micbuf.begin(), micbuf.begin()+fs); }
      } else {
        for (int i = 0; i < fs; ++i) { frame[i] = 0.3f * (float)std::sin(2.0 * 3.14159265358979 * freq * (double)phase / 48000.0); ++phase; }
        // speech-like envelope: a continuous tone can never be silent, so Opus DTX would never engage. Real
        // speech is ~40% pauses; gate the tone into ~2.4 s "talk" + ~1.6 s "silence" so DTX has real gaps to
        // suppress (a live mic has these naturally). Phase keeps running for click-free re-entry.
        double tsec = (double)asamp / 48000.0;
        if (std::fmod(tsec, 4.0) >= 2.4) std::fill(frame.begin(), frame.end(), 0.f);   // silence window
      }
      asamp += fs;
      // 2) 3A (AEC far-end ref = last played frame; ANS/AGC), then Opus encode + send (seq + audio loss)
      std::vector<float> proc = a3a.Process(frame, last_rx, 48000);
      proc.resize(fs, 0.f);
      double tx_ss = 0; for (float v : proc) tx_ss += (double)v * v;
      shm->audio_tx_mrms = (int)(std::sqrt(tx_ss / fs) * 1000.0);
      std::vector<uint8_t> pkt;
      if (aenc.encode(proc.data(), pkt) && !pkt.empty()) {
        ++a_frames;
        // DTX: Opus returns a 1-2 byte SID frame during detected silence = "nothing to transmit". Drop it
        // (the standard nbBytes<=2 idiom) — the far decoder covers the gap with PLC/CNG (comfort noise). The
        // seq still advances (below), so the receiver's 20 ms playout clock is intact and it conceals the gap.
        bool is_dtx = pkt.size() <= 2;
        if (is_dtx) { ++a_dtx; a_dtx_saved += 6 + 40; a_prev_dtx = true; }   // vs a ~40 B speech frame + 6 B header we'd have sent
        else {
          std::vector<uint8_t> w; w.reserve(pkt.size() + 6);
          uint32_t acap = cap_ms_now() & 0x7FFFFFFFu;   // A/V sync: audio capture-stamp, same timebase as video
          if (a_prev_dtx) acap |= 0x80000000u;   // talk-onset marker (top bit): the preceding gap was DTX silence, NOT loss
          a_prev_dtx = false;
          w.push_back(tx_seq & 0xFF); w.push_back((tx_seq >> 8) & 0xFF);
          w.push_back(acap & 0xFF); w.push_back((acap >> 8) & 0xFF); w.push_back((acap >> 16) & 0xFF); w.push_back((acap >> 24) & 0xFF);
          w.insert(w.end(), pkt.begin(), pkt.end());
          if (au_rand() >= loss) { atx.send_to((uint16_t)(rport + 100), w.data(), (int)w.size()); a_tx_bytes += (long)w.size(); }   // inject audio loss
        }
      }
      ++tx_seq;
      // 3) receive -> jitter buffer of OPUS PACKETS (reorders out-of-order arrivals by seq)
      for (;;) {
        int n = arx.recv_nb(rb.data(), (int)rb.size()); if (n <= 6) break;   // seq(2)+capture-stamp(4)+opus
        uint16_t seq = (uint16_t)(rb[0] | (rb[1] << 8));
        uint32_t acap = (uint32_t)(rb[2] | (rb[3] << 8) | (rb[4] << 16) | ((uint32_t)rb[5] << 24));
        auto nowt = clockt::now();   // NetEQ: EWMA of audio inter-arrival deviation from the 20 ms pace = jitter
        if (a_arr) { double g = std::chrono::duration<double, std::milli>(nowt - a_last_arr).count(); double d = g - 20.0; if (d < 0) d = -d; a_jit += (d - a_jit) / 16.0; }
        a_last_arr = nowt; a_arr = true;
        jb[seq] = { acap, std::vector<uint8_t>(rb.begin() + 6, rb.begin() + n) };
        if (jb.size() > 64) jb.erase(jb.begin());   // overflow guard
      }
      jb_target = 3 + (int)(a_jit / 20.0 + 0.5); if (jb_target < 3) jb_target = 3; if (jb_target > 25) jb_target = 25;   // adapt depth to jitter
      a_jb_delay_ms.store(jb_target * 20);   // expose the playout depth (ms) as part of the mouth-to-ear delay for §9
      // 4) play out one frame this 20 ms tick. On a genuine LOSS, if the NEXT packet is buffered, recover
      // the lost frame from its in-band FEC (real Opus LBRR); only fall back to PLC when the next is also
      // gone. A mere UNDERRUN (buffer empty, ahead of arrivals) just holds — not counted as loss.
      if (!play_started && (int)jb.size() >= jb_target) { play_started = true; play_seq = jb.begin()->first; }
      if (play_started) {
        std::vector<float> out;
        auto it = jb.find(play_seq);
        if (it != jb.end()) {                                       // in-order frame present -> normal decode
          cur_play_cap = it->second.first & 0x7FFFFFFFu; have_play_cap = true;   // A/V master clock (mask off the DTX marker bit)
          adec.decode(it->second.second.data(), (int)it->second.second.size(), out); jb.erase(jb.begin(), std::next(it)); ++play_seq; underrun = 0;
        } else if (!jb.empty() && (uint16_t)(jb.begin()->first - play_seq) < 0x8000) {   // gap ahead of the playout cursor
          // DTX vs loss: if the next buffered packet carries the talk-onset marker, everything up to it was
          // the sender's DTX silence -> fill with comfort noise (Opus PLC) and DON'T count it as loss. Only a
          // gap ahead of a NON-onset packet (mid-talkspurt) is genuine loss (recover via LBRR, else PLC).
          bool dtx_gap = (jb.begin()->second.first & 0x80000000u) != 0;
          if (dtx_gap) { adec.conceal(out); ++a_cng; }              // comfort noise for the silence gap (not loss)
          else {
            auto nx = jb.find((uint16_t)(play_seq + 1));
            if (nx != jb.end()) { adec.decode_fec(nx->second.second.data(), (int)nx->second.second.size(), out); ++a_lbrr; ++a_lost; }  // LBRR recover
            else { adec.conceal(out); ++a_conceal; ++a_lost; }      // next also gone -> classic PLC
          }
          ++play_seq; underrun = 0; if (have_play_cap) cur_play_cap += 20;   // playout advanced one 20 ms frame
        } else {                                                    // underrun -> brief hold (not a loss)
          out = last_rx;
          if (++underrun > 25 && !jb.empty()) { play_seq = jb.begin()->first; underrun = 0; }
        }
        if (!out.empty()) {
          double rx_ss = 0; for (float v : out) rx_ss += (double)v * v;
          double r = std::sqrt(rx_ss / out.size()) * 1000.0;
          rx_ewma = rx_ewma == 0 ? r : 0.9 * rx_ewma + 0.1 * r;   // smooth (was last-frame -> noisy)
          shm->audio_rx_mrms = (int)rx_ewma;
          if (playing) player.push(out);
          last_rx = out;   // AEC far-end reference for the next captured frame
          if (have_play_cap) { a_play_cap.store(cur_play_cap, std::memory_order_relaxed);   // publish A/V master clock -> video present gate
                               a_clock_valid.store(true, std::memory_order_relaxed); }
        }
      }
      // NetEQ also time-stretches (WSOLA accelerate/decelerate) to hold the adaptive target; we do the
      // adaptive DEPTH (jb_target above) but NOT sample-domain time-stretch — that's WebRTC NetEQ internal
      // DSP, an honest boundary here. Overflow is bounded by the jb.size()>64 guard on the receive side.
      anext += (double)fs / 48000.0;
      std::this_thread::sleep_until(a0 + std::chrono::duration_cast<clockt::duration>(std::chrono::duration<double>(anext)));
    }
    if (playing) player.stop();
    mic.close();
  });
#endif

  auto t0 = clockt::now(); double next = 0;              // dynamic pacing (cur_fps changes at run time)
  auto last_qos = t0; double link_now = link_kbps; int fec_extra = 0;
  // content-type detection (Zoom §1.4: "屏幕静止时降到极低帧率甚至只发关键帧"; camera = frame-rate priority).
  // Screen source only: if the luma barely changed vs the last frame it's STATIC -> skip the send (the
  // receiver holds the last picture), with a ~1 s keyframe refresh so a joiner/loss still recovers.
  auto last_send_t = t0; auto last_static_key = t0; bool ever_sent = false; int static_skips = 0;
  recon::zlt::SceneChangeDetect scd;   // precise zltCSceneChangeDetect: derives analysis res (input/4) + luma-histogram similarity
  // Content-adaptive SCREEN mode: sustained high motion (a video playing in the share) -> SMOOTH (boost fps
  // + AV1 realtime); static/text/scroll -> SHARP (good-mode, low fps). Hysteresis so it doesn't flip-flop.
  bool video_mode = false; int hi_streak = 0, lo_streak = 0; int mode_switches = 0;
  for (int i = 0;; ++i) {
    if (seconds > 0 && std::chrono::duration<double>(clockt::now() - t0).count() >= seconds) break;
    if (ctrl.valid() && ctrl->magic == ipc::kMagic) {
      loss = ctrl->loss_pct / 100.0; cc_on = ctrl->cc_on != 0;
      if (ctrl->link_kbps > 0) link_now = ctrl->link_kbps;   // --cc: this is the BWE's bottleneck cap (kbps)
      if (!adapt && ctrl->fps > 0) { cur_fps = ctrl->fps;   // live manual frame rate (adaptive OFF)
        shm->adapt_w = enc_w; shm->adapt_h = enc_h; shm->adapt_fps = cur_fps; shm->bw_level = 0; shm->mos_x100 = 0; }
      if (ctrl->stop) break; shm->loss_pct = ctrl->loss_pct;
    }

    // ---- NACK: resend the packets the remote reported missing, from our history (not loss-injected —
    // this IS the recovery). Burst losses FEC couldn't fix get filled ~1 RTT later (§4). ----
    if (nack_on) {
      std::vector<uint16_t> req; { std::lock_guard<std::mutex> lg(nack_mtx); req.swap(nack_req); }
      if (!req.empty()) { auto rp = rtx_buf.resend(req);
        for (auto& p : rp) { auto b = wire::serialize(WirePacket{ false, p, {}, p.timestamp, true }); tx.send_to((uint16_t)rport, b.data(), (int)b.size()); ++retx_sent; } }  // is_retx=true: recovers decode, excluded from network-loss
    }

    // ---- Zoom §9 weak-network tick (~1 s): metrics -> MOS -> net-score -> bw-level -> encode tier ----
    if (adapt && std::chrono::duration<double>(clockt::now() - last_qos).count() >= 1.0) {
      last_qos = clockt::now();
      // §7a: use the REMOTE's measured QoS about our stream (real loss/jitter/FEC), not the injected knob.
      double meas_loss = rep_loss_x10k.load() / 10000.0;
      double meas_fec  = rep_fec_x100.load() / 100.0;
      uint32_t meas_jit = (uint32_t)rep_jitter_ms.load();
      // real mouth-to-ear delay for the G.107 MOS (was a 40/300 ms stub): one-way network (RTT/2) + audio
      // jitter-buffer playout depth. On loopback RTT≈0 but the jitter buffer is a real 60–500 ms; under
      // congestion (cc) the link adds delay too. Falls back to 40 ms until the first RTT probe returns.
      int rtt = rtt_ms.load();
      uint32_t delay_ms = (uint32_t)((rtt >= 0 ? rtt / 2 : 20) + a_jb_delay_ms.load() + (cc_on && cur_kbps > (int)link_now ? 200 : 0));
      // §3 BWE↔resolution: pick the rung the available bandwidth can sustain, so a bandwidth shortfall lowers
      // RESOLUTION (Zoom's ladder), not just the bitrate at a now-too-high resolution (1080p @ 300 kbps =
      // blocky). Under --cc the simulated link IS the ground-truth capacity. On the real path the delay-based
      // GCC can only DETECT congestion (overuse/loss), not discover spare capacity — probing up needs active
      // BWE probes (WebRTC ALR), an honest boundary here — so only a genuine congestion signal lowers the
      // rung; a healthy real path leaves resolution net-score-driven (loss/jitter/delay still move it).
      auto cs = cc.state();
      int bwe_kbps_now = 0;
      if (cc_on) bwe_kbps_now = (int)link_now;
      else if (std::strcmp(cs.signal, "overuse") == 0 || cs.loss > 0.02) bwe_kbps_now = (int)(cc.target_bps() / 1000.0);
      auto r = adaptor.Tick(meas_loss, meas_fec, meas_jit, delay_ms, bwe_kbps_now, cc_on, rep_overload.load());   // cc_on = real link cap may drop below the 540p floor; rep_overload = receiver can't decode this tier (compute)
      fec_extra = r.d.fec_level - 3;                        // mcm 3/4/5 -> extra parity over the base
      if (r.tier.w != enc_w || r.tier.h != enc_h) {         // resolution change -> rebuild encoder
        enc_w = r.tier.w; enc_h = r.tier.h; tier_fps = r.tier.fps; cur_fps = video_mode ? ccfg.video_fps : tier_fps; cur_kbps = r.tier.kbps;
#ifdef AVP_WITH_FFMPEG
        if (!use_minih264) { open_senc(enc_w, enc_h, cur_fps, cur_kbps, video_mode); last_open_kbps = cur_kbps; last_reopen = clockt::now(); }   // keep the current sharp/smooth mode
#endif
      } else { tier_fps = r.tier.fps; cur_fps = video_mode ? ccfg.video_fps : tier_fps; if (cur_kbps != r.tier.kbps) { cur_kbps = r.tier.kbps;
#ifdef AVP_WITH_FFMPEG
        if (!use_minih264 && senc) senc->set_bitrate(cur_kbps * 1000);
#endif
      } }
      shm->adapt_w = enc_w; shm->adapt_h = enc_h; shm->adapt_fps = cur_fps;
      shm->bw_level = (int)r.d.bw; shm->mos_x100 = (int)(r.d.mos * 100); shm->net_delay_ms = (int)delay_ms;
    }

    // ---- BWE throttle (every frame): the ENCODER produces at min(tier bitrate, GCC target); --cc caps the
    // GCC at the simulated link (the bottleneck). The pacer only SMOOTHS, so its rate is the encoder rate
    // ×2.5 + headroom (FEC + keyframe bursts) — it must never throttle below the encoder or it would shed. ----
    {
      double bwe_bps = cc.target_bps();
      if (cc_on) bwe_bps = std::min(bwe_bps, (double)link_now * 1000.0);   // --cc: simulated link caps the BWE
      int enc_kbps = (int)(std::min(bwe_bps, (double)cur_kbps * 1000.0) / 1000.0); if (enc_kbps < 50) enc_kbps = 50;
      if (use_minih264) enc.set_bitrate(enc_kbps * 1000);
#ifdef AVP_WITH_FFMPEG
      else if (senc) {
        senc->set_bitrate(enc_kbps * 1000);   // best-effort; avcodec usually pins the rate at open, so:
        double since = std::chrono::duration<double, std::milli>(clockt::now() - last_reopen).count();
        if (std::abs(enc_kbps - last_open_kbps) > last_open_kbps * 0.35 && since > 1500.0) {
          open_senc(enc_w, enc_h, cur_fps, enc_kbps, video_mode);   // re-open at the BWE rate = the real throttle
          last_open_kbps = enc_kbps; last_reopen = clockt::now();
        }
      }
#endif
      // the pacer only SMOOTHS (its burst cap does that); it must drain fast enough that a keyframe still
      // reaches the receiver within the assembler's patience, so pace at the TIER rate (upper bound on encoder
      // output), not the throttled bitrate. The BWE throttles the ENCODER (enc_kbps above), not the pacer.
      pacer.set_rate_bps((double)cur_kbps * 1000.0 * 2.5 + 1000000.0);
    }

    // ---- SEND our own video (at the current tier resolution) to the remote peer ----
    VideoFrame frame;
    bool frame_synth = false;   // true when this frame is the synth test pattern, not real capture
    if (cap_src) { VideoFrame big; if (cap_src->grab(big) && big.width > 0) frame = downscale(big, enc_w, enc_h); else { frame = synth(enc_w, enc_h, i, id); frame_synth = true; } }
    else { frame = synth(enc_w, enc_h, i, id); frame_synth = true; }
    ts = cap_ms_now();   // A/V sync: video frame timestamp = capture wall-clock (ms since peer_epoch, shared with audio)
    VideoPreprocessResult pr; pp.Process(frame, pr);
    // content-type detection — the PRECISE zltCSceneChangeDetect (逐位反编译 sub_18009FE00→FAD0→A0190→A03B0→
    // A0790): it derives the analysis resolution = input/4 internally, then computes a BRIGHTNESS-INVARIANT
    // 128-bin LUMA-histogram similarity (0..64, HIGH = similar/static; aligns by bin-shift + mean ratio so a
    // global brightness change doesn't false-fire). Fed the I420 luma we already computed (+ U/V for the
    // chroma-confirm band). Replaces the old crude downscaled-BGR mean-delta. Zoom's decompiled cascade uses
    // HARD-CODED thresholds: score>48 = no-change, ≤16 = scene-cut, with chroma(22)/⅛-SAD(55) confirm between.
    recon::zlt::SceneChangeResult scr = scd.Process(pr.frame.y.data(), pr.frame.w, pr.frame.h, pr.frame.w,
                                                    pr.frame.u.data(), pr.frame.v.data(),
                                                    pr.frame.cw(), pr.frame.ch(), pr.frame.cw());
    double motion = 64.0 - scr.score;       // 0..64, HIGH = motion (for telemetry + the video-mode dwell)
    bool content_static = scr.score > 48;   // Zoom's decompiled "no-change" threshold (hard-coded 48)
    // content-adaptive SCREEN mode. BEHAVIOR is 实证 (Zoom static-doc vs video mode-switch; RE lists its
    // "PPT 里嵌视频判错模式" failure). Thresholds/timing are CONFIG-DRIVEN in Zoom too (IDA: zltCSceneChange
    // Detect SetConfig 0x70005 loads them from a blob, not compile-time consts), so ours come from Screen
    // ContentConfig — a screen_content.cfg file if present, else the [DEFAULT, not-recovered-Zoom] values.
    ScreenCodec pcodec = ParseScreenCodec(codec);
    if (content_fps && !camera && !use_minih264 && (pcodec == ScreenCodec::AV1 || pcodec == ScreenCodec::VP9)) {
      bool motiony = scr.score < 34 || scr.scene_change;   // sustained change / low similarity = VIDEO content (Zoom's confirm band)
      if (motiony) { ++hi_streak; lo_streak = 0; } else { ++lo_streak; hi_streak = 0; }
      bool want = video_mode ? (lo_streak < (int)(ccfg.exit_sec * tier_fps)) : (hi_streak > (int)(ccfg.enter_sec * tier_fps));
      if (want != video_mode) {
        video_mode = want; ++mode_switches; cur_fps = video_mode ? ccfg.video_fps : tier_fps;
#ifdef AVP_WITH_FFMPEG
        open_senc(enc_w, enc_h, cur_fps, cur_kbps, video_mode); last_open_kbps = cur_kbps; last_reopen = clockt::now();   // re-open sharp<->smooth (AV1 good<->realtime + fps)
#endif
        shm->adapt_fps = cur_fps;
        std::printf("peer %c: screen content -> %s (motion %.1f, fps %d)\n", id, video_mode ? "VIDEO/smooth (realtime)" : "text/sharp (good-mode)", motion, cur_fps);
      }
    }
    // Publish the sender's scene class (Zoom SceneChangeDetect analog) so the far end + UI can see the
    // SceneChangeDetect -> receive-super-res chain. 0 = camera, 1 = screen-static/text, 2 = screen-video,
    // 3 = synth/test — this last one is HONEST about the fallback: no real capture source (e.g. --source
    // synth, or camera/screen open failed, which happens when a SECOND peer on one machine can't grab the
    // single webcam), so the picture is the test pattern, not what --source asked for.
    shm->content_mode = frame_synth ? 3 : (camera ? 0 : (video_mode ? 2 : 1));
    bool refresh_due = std::chrono::duration<double, std::milli>(clockt::now() - last_send_t).count() >= 1000.0;
    // §1.4: static screen -> drop to ~1 fps (skip the send; the receiver holds the last picture), with a
    // periodic keyframe refresh. Camera = frame-rate priority (never skip). --no-content-fps disables it.
    bool skip_static = content_fps && !camera && content_static && ever_sent && !refresh_due;
    int kreq = force_key_req.exchange(0);                      // PLI/FIR: a receiver asked for a fresh key (2=KeyPicture, 4=Idr)
    // A static screen periodically refreshes so a joiner / loss-recovery gets a full picture — but that refresh
    // need NOT be a full keyframe every second. An AV1 SC keyframe (IntraBC/palette intra) is VERY expensive:
    // forcing one on every 1 s refresh made AV1 encode ~0.3 fps (every frame a keyframe) → the share fell seconds
    // behind → freeze. Send a cheap INTER refresh each second (a static screen's inter frame is near-empty) and
    // force a real keyframe only every ~5 s (or immediately on PLI). Joiner/recovery latency ≤5 s at 0% loss.
    bool static_key_due = std::chrono::duration<double, std::milli>(clockt::now() - last_static_key).count() >= 5000.0;
    // Zoom SetKeyPictureRequest split (dispatcher sub_180008370): case 2 (KeyPicture = loss recovery) prefers a
    // cheap LTR-referencing P over a full IDR; case 4 (Idr = join/FIR) forces a keyframe. Only the libvpx-direct
    // VP9 encoder can reference the golden LTR — on avcodec (h264/av1) both cases fall back to a full IDR.
    bool ltr_capable = (!use_minih264 && senc && senc->supports_ltr());
    bool want_ltr = (kreq == wire::KFREQ_KEYPICTURE) && ltr_capable;
    if (want_ltr) senc->request_ltr_recover();   // next encode() = LTR recovery (reference the clean golden), not an IDR
    bool force_key = (kreq == wire::KFREQ_IDR) || (kreq == wire::KFREQ_KEYPICTURE && !want_ltr)
                     || (refresh_due && content_static && !camera && static_key_due);
    std::vector<uint8_t> au; bool key = false;
    if (!skip_static) {
      if (use_minih264) { EncodedFrame ef = enc.encode(pr.frame); au.swap(ef.data); key = ef.keyframe(); }  // minih264: periodic GOP only
#ifdef AVP_WITH_FFMPEG
      else {
        senc->set_qp_map(pr.qp_delta, pr.qp_bw, pr.qp_bh, 16);   // Zoom §3.3 adaptive-QP (zlt h264/h265; no-op for av1/vp9)
        senc->encode(pr.frame, force_key, au, key);             // one coded frame == one access unit; force_key = PLI/FIR response
      }
#endif
    }
    if (force_key && key) ++forced_keys;
    if (kreq != 0 && !au.empty()) kf_served_reqno.store(kf_pending_reqno.load());   // the emitted key OR LTR-recovery frame SERVED the pending reqno → coalesce further re-requests (no IDR storm)
    if (key) last_static_key = clockt::now();   // any keyframe (forced / periodic GOP / reopen) resets the static-refresh keyframe spacing
    if (!au.empty()) {
      auto pkts = pk.packetize(au, ts);
      // FEC level — weak-network HARDENING on top of the RE'd §4.1/§9 policy. For a group of `gsize` source
      // packets at effective loss p, expected losses = gsize*p; set parity to cover mean + 3σ of the binomial
      // tail so P(a group loses more than its parity) << 1% (the old flat R≈3 left ~1.5%/group unrecoverable
      // at 6% -> lost pictures -> H.264 inter-frame error propagation = the "screen garble"). Keyframes get
      // smaller groups + extra parity (a lost key breaks the whole GOP). p=0 -> ~no FEC (no idle overhead).
      const double p = cc_on ? 0.03 : loss;                          // effective loss to protect against
      const int gsize = key ? 8 : 16;                                // keyframes: smaller groups, better protected
      const int reBase = SelectFecLevel(p * 1.5) + (adapt ? fec_extra : 0) + (key ? 4 : 0);   // RE'd policy + kf boost
      const int robust = (int)std::ceil(gsize * p + 3.0 * std::sqrt(gsize * p * (1.0 - p))) + (key ? 2 : 0);  // mean+3σ tail
      int level = reBase > robust ? reBase : robust;
      if (level < 0) level = 0; if (level > gsize) level = gsize;    // cap parity at K (RS limit + diminishing returns)
      auto fecs = fenc.protect(pkts, level, gsize);   // multi-group FEC (Zoom §4.1)
      // ENQUEUE media + FEC into the send pacer (drained at the BWE target below, no burst). Loss is injected
      // at drain time. rtx_buf still keeps every media packet for NACK resends.
      for (auto& p : pkts) { if (nack_on) rtx_buf.add(p); pacer.enqueue(wire::serialize(WirePacket{ false, p, {}, p.timestamp })); }
      for (auto& fp : fecs) { WirePacket w{ true, {}, fp, ts }; pacer.enqueue(wire::serialize(w)); }
      shm->sent_frames++; shm->encode_kbps = (int)(au.size() * 8.0 * cur_fps / 1000);
      shm->cc_target_kbps = (int)(cc.target_bps() / 1000);   // real BWE target (the drain loop refines it from transport-cc)
      shm->pkts_sent = pkts_sent; shm->fec_sent = fec_sent;
      last_send_t = clockt::now(); ever_sent = true;           // content-fps: mark an actual send
    } else if (skip_static) { ++static_skips; shm->encode_kbps = 0; }   // static screen -> sent nothing this tick (receiver holds last frame)
#ifdef AVP_WITH_FFMPEG
    // DUAL: the SECOND channel (ch2 = desktop-share when primary is camera). Its own capture+encode, sent
    // media-only tagged payload_type=2 (pk2). Paced slower (screen = low fps) via a simple frame stride.
    if (dual && senc2 && (i % (camera ? 2 : 1)) == 0) {   // ~half rate for the screen share leg
      VideoFrame f2;
      if (cap_src2) { VideoFrame big; if (cap_src2->grab(big) && big.width > 0) f2 = downscale(big, enc2_w, enc2_h); else f2 = synth2(enc2_w, enc2_h, i, id); }
      else f2 = synth2(enc2_w, enc2_h, i, id);
      I420Image i2; BgraToI420(f2, i2);
      std::vector<uint8_t> au2; bool k2 = false; senc2->encode(i2, false, au2, k2);
      if (!au2.empty()) {   // ch2 = channel 2 (both media AND FEC tagged), demuxed at the receiver by w.channel
        uint32_t ts2 = cap_ms_now();
        auto pk2s = pk2.packetize(au2, ts2);
        auto fec2 = fenc.protect(pk2s, k2 ? 6 : 3, 16);   // FEC on the share leg too (no NACK on ch2 -> FEC carries it)
        for (auto& p : pk2s) { if (urand() < loss) continue; WirePacket w2{ false, p, {}, p.timestamp }; w2.channel = (uint8_t)kCh2; auto b = wire::serialize(w2); tx.send_to((uint16_t)rport, b.data(), (int)b.size()); }
        for (auto& fp : fec2) { if (urand() < loss) continue; WirePacket w2{ true, {}, fp, ts2 }; w2.channel = (uint8_t)kCh2; auto b = wire::serialize(w2); tx.send_to((uint16_t)rport, b.data(), (int)b.size()); }
      }
    }
#endif
    shm->running = 1;
    next += 1.0 / (cur_fps > 0 ? cur_fps : 8);            // pace at the current tier's frame rate
    auto frame_end = t0 + std::chrono::duration_cast<clockt::duration>(std::chrono::duration<double>(next));
    // ---- BWE + PACER: while waiting for the next frame, feed the GCC the real transport-cc arrivals and
    // release the queued packets at the BWE target (smooth output, no burst). ----
    do {
      std::vector<std::pair<uint16_t, uint16_t>> tw;
      { std::lock_guard<std::mutex> lg(twcc_mtx); if (!twcc_pending.empty()) tw.swap(twcc_pending); }
      if (tw.size() >= 2) {                                            // build PacketFeedback from real arrivals -> GCC
        std::vector<PacketFeedback> fb;
        for (auto& e : tw) { auto it = sendlog.find(e.first); if (it == sendlog.end()) continue;
          PacketFeedback f; f.seq = e.first; f.size = it->second.second; f.send_time_us = it->second.first;
          f.recv_time_us = (int64_t)e.second * 1000 + 1; fb.push_back(f); }
        if (fb.size() >= 2) cc.on_feedback(fb);                        // update the GCC target (applied to encoder+pacer next frame)
      }
      int64_t nu = us_now();
      pacer.drain(nu, [&](const std::vector<uint8_t>& b) {             // release paced packets (inject loss here)
        if (b.size() >= 3 && (b[0] & 0x0F) == 0) {                     // media -> log send time for the BWE
          uint16_t sq = (uint16_t)(b[1] | (b[2] << 8)); sendlog[sq] = { nu, (int)b.size() };
          if (sendlog.size() > 2000) sendlog.erase(sendlog.begin());
        }
        if (urand() >= loss) { tx.send_to((uint16_t)rport, b.data(), (int)b.size()); if ((b[0] & 0x0F) == 0) ++pkts_sent; else ++fec_sent; }
      });
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
      // BACKPRESSURE: keep draining until the frame is actually SENT, not just until the frame-rate deadline.
      // The pacer's burst budget is capped at ~6 ms of data PER drain call, which silently assumes drain runs
      // ~every ms. But drain only runs here in the send loop, and a SLOW encoder (e.g. 1080p AV1 screen, seconds
      // per frame) makes iterations seconds apart → each drain then dumps only ~2 packets and a big keyframe
      // trickles out over many seconds → the receiver's stall-eviction kills the still-arriving picture → freeze
      // (the "0% loss screen share stalls at 2 decoded" bug). Draining until the queue empties paces the frame
      // out steadily AND applies natural backpressure (a sender must not produce faster than it can send). The
      // 4 s guard bounds the block so a pathologically low rate can't hang the loop (Stop / NACK still respond).
    } while (clockt::now() < frame_end ||
             (pacer.queued() > 0 && std::chrono::duration<double>(clockt::now() - frame_end).count() < 4.0));
  }
  running.store(false); rxth.join();
#ifdef AVP_WITH_OPUS
  if (ath.joinable()) ath.join();
#endif
  shm->running = 0;
  std::printf("peer %c: stopped, sent %d+%d pkts, %d raw pkts recv, %d frames (%d decoded, %d recv-super-res)  final tier=%dx%d@%d bw=L%d mos=%.2f  audio tx/rx rms=%d/%d\n",
              id, pkts_sent, fec_sent, raw_recv, recv_frames, recv_dec, sr_frames, enc_w, enc_h, cur_fps, shm->bw_level, shm->mos_x100 / 100.0, shm->audio_tx_mrms, shm->audio_rx_mrms);
#ifdef AVP_WITH_OPUS
  if (audio_on) std::printf("peer %c: audio — %d lost: %d LBRR-recovered + %d PLC-concealed (Opus in-band FEC)\n", id, a_lost, a_lbrr, a_conceal);
  if (audio_on) std::printf("peer %c: DTX — %d/%d frames (%.0f%%) suppressed as silence, ~%ld B saved vs %ld B sent; far end filled %d gaps with comfort noise (viper VAD + Opus DTX)\n",
                            id, a_dtx, a_frames, a_frames ? 100.0 * a_dtx / a_frames : 0.0, a_dtx_saved, a_tx_bytes, a_cng);
  if (audio_on) std::printf("peer %c: a/v-sync — video-vs-audio offset ~%d ms (%s; |offset| small = lip-synced)\n", id, dbg_avsync.load(), avsync ? "gated on audio clock" : "UNGATED --no-avsync");
#endif
  if (nack_on) std::printf("peer %c: nack — sent %d requests, resent %d pkts\n", id, nacks_sent, retx_sent);
  if (pli_on) std::printf("peer %c: pli/fir — sent %d keyframe requests, received %d, forced %d keys (SetKeyPictureRequest)\n", id, kfreq_sent, kfreq_recv, forced_keys);
  std::printf("peer %c: conceal — %d pictures evicted, %d freeze episodes; un-froze %d on clean-keyframe + %d on 10s backstop; %d frames held (%d were CORRUPT decodes caught before display = the mosaic that used to leak)\n",
              id, dbg_evicted.load(), dbg_freezes.load(), dbg_unfreeze_key.load(), dbg_unfreeze_backstop.load(), dbg_frozen_holds.load(), dbg_unfreeze_dirtykey.load());
  { int rtt = rtt_ms.load(); std::printf("peer %c: rtt/delay — measured RTT %s ms; abs_net_delay ~%d ms (RTT/2 + jitter-buffer %d ms) -> §9 G.107 delay term\n",
      id, rtt < 0 ? "(none)" : std::to_string(rtt).c_str(), (rtt >= 0 ? rtt / 2 : 20) + a_jb_delay_ms.load(), a_jb_delay_ms.load()); }
  if (content_fps) std::printf("peer %c: content-fps — %d static-frame skips (screen sitting still -> ~1 fps refresh; camera never skips)\n", id, static_skips);
  std::printf("peer %c: bwe/pacer — GCC target %.0f kbps (%s), pacer shed %d pkts%s\n", id, cc.target_bps() / 1000.0,
              cc.state().signal, pacer.dropped(), cc_on ? " [--cc: capped at the simulated link]" : "");
  if (dual) std::printf("peer %c: dual — ch3 video %d decoded + ch2 screen-share %d decoded (composited: screen full + camera PIP)\n", id, recv_dec, ch2_dec);
  { long g = dbg_gaps.load(), rv = dbg_recv.load(); double ml = (g + rv) > 0 ? 100.0 * g / (g + rv) : 0;
    std::printf("peer %c: qos — measured incoming loss=%.1f%% (lost %ld / expected %ld) [RFC3550]; remote reports OUR stream loss=%.1f%% (drives §9)\n",
                id, ml, g, g + rv, rep_loss_x10k.load() / 100.0); }
  return 0;
}
