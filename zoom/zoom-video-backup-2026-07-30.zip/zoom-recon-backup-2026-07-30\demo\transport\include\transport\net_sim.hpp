// net_sim.hpp — a bottleneck-link model to drive/verify congestion control offline. A single FIFO
// queue drained at `capacity_bps`: packets serialize at the link rate, wait behind the backlog, and
// are DROPPED when the queue exceeds its byte limit. So sending above capacity grows the queue ->
// rising delay (what the delay-based estimator must catch) -> eventual loss. Deterministic.
#pragma once
#include "transport_types.hpp"
#include <cstdint>

namespace avp {

class BottleneckLink {
public:
  BottleneckLink(double capacity_bps, double base_delay_ms, int queue_limit_bytes)
      : cap_(capacity_bps), base_ms_(base_delay_ms), qlimit_(queue_limit_bytes) {}

  void set_capacity(double bps) { cap_ = bps > 1 ? bps : 1; }

  // Offer a packet sent at `send_us`. Fills recv_us (0 => dropped). Returns false if dropped.
  bool transmit(int size, int64_t send_us, int64_t& recv_us) {
    // drain the queue up to now
    if (send_us > busy_until_us_) { queue_bytes_ = 0; busy_until_us_ = send_us; }
    else queue_bytes_ = (int)((busy_until_us_ - send_us) * cap_ / 8.0 / 1e6);
    if (queue_bytes_ + size > qlimit_) { recv_us = 0; return false; }   // queue full -> drop
    double serialize_us = size * 8.0 / cap_ * 1e6;
    int64_t start = send_us > busy_until_us_ ? send_us : busy_until_us_;
    busy_until_us_ = start + (int64_t)serialize_us;
    recv_us = busy_until_us_ + (int64_t)(base_ms_ * 1000);
    return true;
  }
  int queue_bytes() const { return queue_bytes_; }

private:
  double cap_, base_ms_; int qlimit_;
  int64_t busy_until_us_ = 0; int queue_bytes_ = 0;
};

}  // namespace avp
