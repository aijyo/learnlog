// screen_content_config.hpp — the SCREEN content-mode (static / text / video) detector's tunables, modelled
// on Zoom's ns_codec::zltCSceneChangeDetect. IDA (zlt.dll) showed that class's thresholds are CONFIG-DRIVEN:
// SetConfig (feature id 0x70005, sub_18009FCF0) copies a ~160-byte config blob into the object; the actual
// scene-change thresholds live at cfg offsets, NOT as compile-time constants — so Zoom's real values are in
// server/encoder config we can't read. We mirror that exactly: load overrides from a key=value file if one is
// present, else use these DEFAULTS. The one 实证 piece is the ANALYSIS RESOLUTION — Zoom's detector downscales
// the frame to ~640x360 before measuring (sub_18009FAD0). Everything else here is [DEFAULT, not recovered Zoom].
#pragma once
#include <string>
#include <fstream>
#include <cstdlib>

namespace avp {

struct ScreenContentConfig {
  int    analysis_w    = 640;  // Zoom SceneChangeDetect analysis resolution (实证 ~640x360, sub_18009FAD0)
  int    analysis_h    = 360;
  double static_thresh = 1.5;  // mean B/G/R delta < this        => STATIC (skip to ~1 fps)  [default, config-overridable]
  double video_thresh  = 8.0;  // mean B/G/R delta > this SUSTAINED => VIDEO (smooth mode)   [default, config-overridable]
  double enter_sec     = 1.0;  // sustained high-motion seconds before entering smooth mode  [default, config-overridable]
  double exit_sec      = 2.0;  // low-motion seconds before leaving smooth mode              [default, config-overridable]
  int    video_fps     = 20;   // smooth-mode (video) frame rate                             [default, config-overridable]

  // Zoom's config-blob analog: load key=value overrides from `path`. Missing file/keys keep the defaults.
  // Returns true if the file existed. Lines are `key=value`; `#` starts a comment.
  bool load(const std::string& path) {
    std::ifstream f(path);
    if (!f) return false;
    std::string line;
    while (std::getline(f, line)) {
      if (line.empty() || line[0] == '#') continue;
      auto eq = line.find('=');
      if (eq == std::string::npos) continue;
      std::string k = line.substr(0, eq), v = line.substr(eq + 1);
      if      (k == "analysis_w")    analysis_w    = std::atoi(v.c_str());
      else if (k == "analysis_h")    analysis_h    = std::atoi(v.c_str());
      else if (k == "static_thresh") static_thresh = std::atof(v.c_str());
      else if (k == "video_thresh")  video_thresh  = std::atof(v.c_str());
      else if (k == "enter_sec")     enter_sec     = std::atof(v.c_str());
      else if (k == "exit_sec")      exit_sec      = std::atof(v.c_str());
      else if (k == "video_fps")     video_fps     = std::atoi(v.c_str());
    }
    return true;
  }
};

}  // namespace avp
