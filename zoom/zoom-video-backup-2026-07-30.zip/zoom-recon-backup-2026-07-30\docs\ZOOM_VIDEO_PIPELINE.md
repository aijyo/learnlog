# Zoom 视频流技术详解 — 各环节原理、实现方式与逆向重构关键代码

> 逆向(IDA Pro 7.5 + Hex-Rays)所得的 Zoom 视频管线技术细节。聚焦 **Zoom 本身**的原理与实现;每个技术附**逆向重构的关键代码**(clean-room,复现 Zoom 的算法核)。
> 标注:**[实证]** = 反汇编 body/shader 确认;**[推断]** = 由行为/常量推断;**⛔W/K/S** = 权重/编解码核/GPU shader 边界(不抄,重建算法)。IP 敏感,仅本地。

---

## 1. 模块地图(逆向定位的真实模块)

| 模块 | 职责 | 关键类/符号 [实证] |
|---|---|---|
| `zlt.dll` | 相机编解码(H.264/265)+ VPP + RAISR + 丢包恢复 | `ns_avc`/`ns_codec`/`ns_vpp`/`ns_gct`;`zltCDecoderWrapper`;`SetKeyPictureRequest` = `sub_180008370` |
| `zbt.dll` | 屏幕 AV1 SC 编解码 | `ns_av1`;`(mode&0xF)==2 → zbtCScEncoderCore`(libaom) |
| `nydus.dll` | RTP/FEC 接收 + 视频渲染/混流 + 末帧重复 | `CCRCVideoFrameAdapter`、`CVideoMixer`、`CVideoRepeater`、RS `sub_180005C44/F34` |
| `mcm.dll` | 弱网自适应脑(QoS→MOS→档位) | `sub_1801642D0`(G.107)、`sub_18009CC20`(NW_WARNING)、阶梯表 `0x1802BF000` |
| `viper/viperex.dll` | **音频**引擎 + 音频神经模型(非视频) | `webrtc::` audio、AEC-NN、CAM++ |

完整链路:**采集(MF/DXGI)→ VPP(缩放/降噪/QP/VFX)→ 编码(zlt/zbt)→ 打包/FEC/pacer/NACK → §9 mcm 自适应 → RTP 重组/抖动缓冲 → 解码 → 渲染(时钟驱动 + DCCI/chroma/RAISR)**。

---

## 2. 采集 Capture

- **相机**:MediaFoundation。**屏幕**:DXGI Desktop Duplication / WGC(采集宿主 CptHost)。
- **拥塞跳帧**:编码侧 `SetFrameSkipRequest`(分发器 case 24,`slot+48=1`)在拥塞时丢弃该空域层的下一帧,防止采集帧堆积落后于实时。[实证]

---

## 3. 预处理 VPP(ns_vpp)

### 3.1 缩放 / 下采样 — 多相可分离双三次(scale-adaptive)
**原理**:把 native/4K 采集帧缩到编码档位(≤1080p)。**多相 + 可分离 + 尺度自适应**的双三次重采样:非盒式平均、非普通双线性。缩小时**支撑随比例加宽**(抗锯齿),避免屏幕文字高频混叠。
**Zoom [实证 zlt.dll]**:`ns_vpp::zltCResample`(vtable `0x180504F98`,Transform `sub_1801E2BF0`)/ `zltCGvdownsample`(`0x1805054A8`,硬编码双三次)/ `zltCNearest`(整数因子快路)。
- 系数构建 `sub_1801BC400`:`ratio=dst/src`;`fscale=max(1, src/dst)`(缩小加宽);`support=base_radius·fscale`(bicubic base_radius=2);`taps=ceil(2·support)`(缩得越多抽头越多)。
- 权重生成 `sub_1801BCF00`:每输出像素 `center=(o+phase)/ratio`,`w[j]=kernel((j−center)/fscale)`,**归一到 Q14 定点 16384**;末抽头吸收舍入。
- 核可配 `sub_1801BC6F0`:case1/3 = **双三次 Keys a=−0.5(Catmull-Rom)** 默认;case2 = **Lanczos-4**(窗 sinc)。scalar/SSE/AVX2 三 SIMD 变体按 CPU 分派。

**逆向重构关键代码**(`recon/zlt_resample.hpp`):
```cpp
// Catmull-Rom (Keys a=-0.5):|x|<1: 1.5|x|³−2.5|x|²+1 ; 1≤|x|<2: −0.5|x|³+2.5|x|²−4|x|+2
double CatmullRom(double x){ double a=fabs(x);
  if(a<1) return (1.5*a-2.5)*a*a+1.0;
  if(a<2) return ((-0.5*a+2.5)*a-4.0)*a+2.0; return 0.0; }
// 每输出像素的抽头(支撑律 + 归一化)
double ratio=(double)dst/src, fscale=ratio<1?1.0/ratio:1.0;   // 缩小时加宽支撑(抗锯齿)
double support=radius*fscale, center=(o+0.5)/ratio-0.5;
for(int s=ceil(center-support); s<=floor(center+support); ++s)
    w.push_back(kernel((s-center)/fscale));                   // 归一后 X/Y 两遍可分离
```

### 3.2 场景检测 SceneChangeDetect(逐位反编译,已精确还原)
**已反编译 `ns_codec::zltCSceneChangeDetect`(vftable `0x180501638`)全链路** [实证 body]:`Process sub_18009FE00` → `setup sub_18009FAD0`(分析分辨率)→ `stats sub_1800A0190`(每帧直方图)→ `decision sub_1800A03B0`(阈值级联)→ `score sub_1800A0790`(相似度)+ `chroma sub_1800A0CB0`。**纠正了之前两处误判:**
- **分析分辨率 = 输入 ÷ 4**(≤1440p 固定因子 4:1080p→**480×270**、720p→**320×180**),仅 >1440p/4K 才降到 ~640×360;**不是固定 640×360**(之前推断错)。
- **度量是 LUMA 直方图相似度,不是像素均值差**;而且**亮度不变**(先按小 bin 位移 + 均值比缩放对齐两帧直方图再比,全局变亮不会误判)。
- **阈值是硬编码常量**(16/48/38 亮度分、22 色度、55/52 的 1/8-SAD),**不是配置 blob**(之前也判错;只有上层视频模式的进/出 dwell 才是配置)。

**算法(实证)**:
1. **每帧统计**(`sub_1800A0190`):128-bin 亮度直方图(bin=luma>>1)+ 均值 + 主 bin(众数)+ 主 bin 占比×64;双缓冲(本帧存给下帧比)。
2. **相似度分**(`sub_1800A0790`,0..64,**高=相似/无变化**):逐 bin `min·64/max` 加权求和归一;并取"直方图小位移 ±2 + 按均值比 `32·mean_cur/mean_prev` 缩放对齐"后的**最大**相似度(亮度不变)。
3. **级联判决**(`sub_1800A03B0`):`分≤16`→场景切换;`分>48`→无变化;`分∈(38,48]`→用**色度直方图相似度**(U、V,`sub_1800A0CB0`,阈值 22)确认;`分∈(16,38]`→用 **1/8 分辨率亮度 SAD**(阈值 `55·(w/8)(h/8)/64`,强变化 `52·…`)确认。

**逆向重构关键代码**(`recon/zlt_scene_change.hpp`,编译+运行验证:1080p→480×270):
```cpp
// 分析分辨率:≤1440p 固定 /4,否则拟合 ~640×360
int factor = (int64_t)w*h <= 3686400 ? 4 : max(ceil(w/640.0), ceil(h/360.0));
aw = (w/factor + 1) & ~1;  ah = (h/factor + 1) & ~1;             // 偶数
// 亮度直方图相似度(逐 bin min·64/max),归一到 0..64
for (int i=0;i<128;++i){ int mx=max(ha,hb),mn=min(ha,hb); if(mx) acc += ha*((mn<<6)/mx); tot+=ha; }
int score = acc/tot;                                             // 高=相似
// 级联:16/48/38 硬编码
if(score<=16) change=true; else if(score>48) change=false;
else if(score>38) change = chroma_similarity(U,V) < 22;          // 色度确认
else              change = mean_sad_1_8(cur,prev) >= 55*(aw>>3)*(ah>>3)>>6;  // 1/8-SAD 确认
```
> 我们 demo 里 peer_main 用的"降采样后 BGR 绝对差均值 + 单阈值"是**粗略类比**;此文件是逐位对齐的精确版本(1/8-SAD 路径的 SSE 核用标量均值差复现)。

### 3.3 自适应 QP — TextureMotion(ns_avc)
**原理**:繁忙/高运动块(量化误差被感知掩盖)给**更粗** QP(正偏移)省比特;平坦/静态/ROI(人脸、文字)块给**更细** QP(负偏移)保清晰。每块偏移 ∈ [−3,+3]。
**Zoom [实证,逐位深挖 `sub_1800E7A00`/`E7680`/`E7610`/`E7C90`]**:`sub_1800E7A00`(vtable `0x180502738`)= TextureMotion。**它不给块打离散标签,而是对两个度量做「逐帧自适应阶梯」**:
- **两个每块度量**:纹理(空间复杂度,数组 obj+104)、运动(时域,来自 ME,数组 obj+112)。(**更正**:earlier 记的 obj+136/+120 是**built 阈值的存储位**,不是度量;`+136..146`=纹理6阈值、`+120..130`=运动6阈值。)
- **阈值逐帧自适应,不是固定常数**(`sub_1800E7610` 逐位):`thr[i] = (int)(度量总和 / 块数 × mult[i]) + 1 = 帧均值 × mult[i] + 1`。固定的是 **6 个 double 乘数**(纹理表 `qword_1803FBDB0`、运动表 `qword_1803FBDE0`,按分析模式索引)。所以「繁忙」是**相对本帧平均块**判定。
- **阶梯**(`sub_1800E7680` 逐位):`level = −3 + count(度量 ≥ thr[i])` ∈ [−3,+3]。
- **合并**:每块 `delta = texLevel + motLevel`,按模式 `obj+72`(纹理-only / 运动-only / 两者)门控。
- ROI/人脸/文字的**细-QP 偏置是另一条策略**(`zltCRoiAdaptQuant` 吃 ROI 图),与 `zltCBackgroundAdaptQuant`/`zltCScStaticAdaptQuant`/`zltCComAdaptQuant` 一起在 `zltCBuQpCalc`/`zltCFrameQpCalc` 下游合并 —— **不在 TextureMotion 里**。阈值/乘数是**可调配置**(非学习权重)。

**sibling 策略族(深挖 b)**:
- **全族共用同一个阶梯原语**,只是喂的度量不同。铁证:纯纹理变体 `sub_1800E78C0` 与 `sub_1800E7A00` **逐字节相同、只少运动轴**(同套 6 阈值 @obj+136)。策略经 `0x180527960` 的**打包 32-bit RVA 表**派发(非薄 RTTI vtable)。
- **Static/Background 用另一套** `sub_1800E8C90`:不是简单 staircase,而是**邻域空间扫描** + 活动度阈值 `clamp(2.5 × frame_param[obj+396], 11468, 16384)` —— 静止/平坦区靠局部空间分析判定。
- **Roi** `sub_1800EBD70`(0x80B)= **ROI 图驱动**:ctor 存外部掩码指针(obj+16/+24),对掩码内块给负偏移;掩码**来源**(人脸/文字检测)是 ⛔W/检测边界 → 喂自有 ROI 图。三者偏移图在 `zltCBuQpCalc` 叠加。
> **诚实边界 [推断]**:① 两个度量的**最内层算式**(纹理=方差?梯度和?SATD?运动=MV 幅度?SAD?)由编码分析虚调用(`obj+32→slot+8/+16`)产出,在反编译层再上一层——现定性为「每块空间活动度 / 时域差」,`BlockVariance`/`BlockMotionSAD` 是**合理替身**;② Static/Background 的**邻域扫描体**只到结构级(阈值 `[11468,16384]` 已拿)。其外的分类(逐帧阶梯+staircase+合并)是**逐位**。

**逆向重构关键代码**(`recon/zlt_adaptive_qp.hpp`):
```cpp
// 阶梯(逐位 sub_1800E7680):level = -3 + count(val >= thr[i])
struct QpLadder { std::array<int,6> thr;
  int level(int val) const {
    int lvl = (val >= thr[0]) - 3 + 1;
    if (val < thr[1]) lvl = (val >= thr[0]) - 3;
    if (val >= thr[2]) ++lvl; if (val >= thr[3]) ++lvl;
    if (val >= thr[4]) ++lvl; if (val >= thr[5]) ++lvl;
    return lvl; } };
// 逐帧自适应阈值(逐位 sub_1800E7610):thr[i] = 帧均值 × mult[i] + 1
QpLadder BuildLadder(double sum, int nblk, const std::array<double,6>& mult){
  QpLadder L; for(int i=0;i<6;++i){ int t=(int)(sum*mult[i]/nblk)+1;
    L.thr[i]=(unsigned)t<=0xFFFF?t:0xFFFF; } return L; }
// 每帧:先量测所有块的纹理/运动 + 累加总和 → BuildLadder(总和,块数,乘数) → 每块 staircase
int delta = texL.level(tex[b]) + motL.level(mot[b]);       // → 注入编码器 ROI/量化偏移(mode 门控)
```

### 3.4 VFX 感知增强(ns_vpp,GPU shader ⛔S → RE 算法重写)
**发送侧链序 [实证]**:`LightAdapt → ColorAdapt → CLAHE → Sharpen`。
- **CLAHE**(`zltCCLAHE` vft `0x180504F28`,核 `sub_1801E0820` [实证结构]):**8×8=64 tile**,每 tile **256-bin 直方图**,**对比度限幅**(`climit=clip·cnt/256`,clip≈3~4)后把超出的质量**均摊回全直方图**,CDF → 映射 LUT;tile 间**双线性混合**避免块边界。[实证:v78[256] 直方图 / v79[64] tile / v80[256] CDF,luma 钳 254/255]
- **LightAdaption**(`zltCLightAdaption` vft `0x180504CA8`,2025-07 **完整逆向** [实证]):**不是**通用 "把均值拉到 128" 的 gamma,而是一套 **逆光检测 + 暗部提亮**。apply `sub_1801BF500` → 分辨率档(`min(w,h)`:≥720→子采样 shift 3,≥360→2,≥180→1,else 0)→ 注意力集成 `sub_1801C11D0`(把归一化人脸/主体框 clamp[0,1] → 像素,拒绝 <1/64 面积,做 1/4 与 1/8 内缩,自适应子采样使 ROI 直方图 ≤200 采样)→ 决策核 `sub_1801C1350`:
  - **几何均值亮度**(Reinhard 对数平均 key,`sub_1801C1100`):`exp( Σ h[i]·log(i) / (N−h[0]) )`(255 项 log 系数表 `qword_180416AF0`,排除纯黑 bin)。
  - **Shannon 熵**:`−Σ p·log2 p`。
  - **触发级联** [实证]:`ROI 几何均值 ≤ 100`(暗主体)**且** `整帧高光占比 ≥ 10%`(bins 240..255)**且** `整帧几何均值 ≤ 170` → 置 "逆光→提亮" 标志。像素色调映射由 SIMD 派发(`a1+56` 或 `*(a1+160)+216`,两变体)→ 曲线抽头在 ⛔S 核内([推断] 用保护高光的暗部提升曲线复现)。
- **ColorAdaption**(`zltCColorAdaption` vft `0x180504D18`):apply `sub_1801CB090` 从常量种子表 `qword_1804174C0` 构建 **4×4×192B 颜色校正 LUT**(灰阶对角初始化 `(v,v,v)`)后 SIMD 应用;核 `sub_1801CBD10/CBFC0` 对 U/V 做定点邻域加权重映射拉向中性 127/128 = **gray-world 白平衡**。
- **Sharpen**(`zltCSharpen` vft `0x1805049B8`,核 [实证]):3×3 高斯/16 得低频,`unsharp = orig + amount·(orig−low)`,阈值化(/128)避免放大噪点。apply `sub_1801ABA20` 确认外壳:**边界复制**上/下行 → **2-pass 可分离派发**(水平核 fn-ptr `a1+24`,半径 = 分析参数−2;再合并核 fn-ptr `a1+32`,携带强度字 `a1+16`)。
- **新发现(2025-07)**:
  - **`zltCAttentionLight`**(vft `0x180505040`):给 LightAdapt 喂人脸/主体 ROI 框的**注意力/显著性前端**(slot3 配置门 `a3[3]==16`/`a3[5]==3328`;slot2 telemetry 包裹的检测器派发)= 学习式显著性/人脸定位 → **边界 ⛔W**:把 ROI 当**输入**(用我们自己的人脸框),不搬 Zoom 权重。
  - **`zltCColorSpaceCvt`**(vft `0x180505518`):像素格式/色彩空间转换器(补上审计的 "颜色转换" 缺口)。slot2 `sub_18023D890` → 格式对派发 `sub_18023DEC0/sub_18023E100` → SIMD 转换核(YUV↔RGB / 打包↔平面)。标准可复现 CSC(✅ CPU SIMD)。

**逆向重构关键代码**(LightAdaption 逆光级联,`recon/zlt_vfx.hpp`):
```cpp
// 几何均值亮度(sub_1801C1100):exp( Σ h[i]·log(i) / (N-h[0]) )
double GeoMeanLuma(const long h[256], long N){ long d=N-h[0]; if(d<=0) return 0;
  double s=0; for(int i=1;i<256;++i) if(h[i]) s+=h[i]*std::log((double)i); return std::exp(s/d); }
double roi_geo   = GeoMeanLuma(roi_hist,  rc);      // 主体(ROI)几何均值
double frame_geo = GeoMeanLuma(frame_hist,fc);      // 整帧几何均值
long hi=0; for(int i=240;i<256;++i) hi+=frame_hist[i];   // 高光(240..255)计数
double hl = (double)hi/fc;                                // 高光占比
bool backlit = roi_geo<=100.0 && hl>=0.10 && frame_geo<=170.0;   // [实证] 触发级联
if(backlit){ /* [推断] 暗部提亮曲线,>=200 滚向 identity 保护高光 */ }
```

**逆向重构关键代码**(CLAHE,`recon/zlt_vfx.hpp`):
```cpp
long climit = (long)(clip * cnt / 256);                        // 对比度限幅阈值
long excess=0; for(int i=0;i<256;++i) if(hist[i]>climit){ excess+=hist[i]-climit; hist[i]=climit; }
double addF = (double)excess / 256;                            // 超出质量均摊回全直方图
double acc=0; for(int i=0;i<256;++i){ acc+=hist[i]+addF; map[t][i]=acc*scale; }  // CDF → LUT
// 输出:4 个最近 tile 中心的映射做双线性混合
out = bilerp(map[tl][v], map[tr][v], map[bl][v], map[br][v], fx, fy);
```

### 3.5 时域降噪(IIR / EWMA)
**原理**:递归时域滤波,用少量运动拖尾换强随机噪声抑制;运动处需补偿/复位防鬼影。
**Zoom [实证 sub_1802A5260 `zltCIIRDenoise`]**:`out = 0.37·in + 0.63·prev`(**α=0.37**,配置命令 `0x70004`);另有 `zltCTemporalDenoise`/`zltCDenoiseASM`(SSE/AVX 变体)。神经 EDNet(`CVideoEDNetDenoise_AOM`)是 ⛔W 权重边界。
```cpp
// out = 0.37*in + 0.63*prev;运动门(|in-prev|>guard 时取输入,防鬼影);输出反馈为下帧 state
if (motion_guard && abs(cur-prev) > motion_guard) v = cur;
else v = int(0.37f*cur + 0.63f*prev + 0.5f);
state[i] = v;   // 递归
```

---

## 4. 编码 Encode(⛔K 编码核用标准库,✅ Zoom 控制层)

### 4.1 两套编解码族
- **zlt(相机)** = H.264/H.265 **High profile + CABAC**,自适应 QP(§3.3 注入)、时域参考、LTR。核 = libx264/libx265。
- **zbt(屏幕)** = **AV1 屏幕内容编码**:`tune=screen` + **palette**(调色板,重复色块)+ **IntraBC**(块内拷贝,对重复文字/UI 极高效)+ error-resilient。核 = libaom(⛔K)。

**zbt 编解码控制层 [实证 zbt.dll]**(SC 工具在 libaom 核内;wrapper 是控制/装配层):
- **Create ABI**:`Av1EncInterfaceCreate 0x18009C920` / `Av1DecInterfaceCreate 0x18009C680`,`(mode&0xF)==2` 选 SC 核 `ns_av1::zbtCScEncoderCore`/`zbtCScDecoderCore`(否则普通核);enc 对象 ~0x488F0 字节。
- **SpecialFeature**(整数 id,非位掩码):enc base `0x850001`(+2 → `zbtCObuHdrWriter` 打包器);dec base `0x880001`(+1 → `zbtCObuHdrParser` 解包器)。
- **HW/DXVA 解码**:`Av1CreateWinHwDecSpecificCodec 0x18009CD10` → `zltCWinHwDecSpecificCodecAV1`(D3D 设备后绑)。
- **SW OBU 解析**:`sub_1801CFA10`(序列/元数据)+ `sub_1801D0AA0`(帧头):完整 AV1 OBU 解析(temporal-delimiter/seq/frame/tile-group/metadata,含 **ITU-T T.35 + HDR CLL/mastering-display**);`set_frame_refs` 在 **8 个参考槽**做 ref-sign-bias 选择;**多线程 tile 解码**(SRW + 条件变量)。诊断串:"Error parsing sequence/frame header"、"Overrun in OBU bit buffer"。

### 4.2 内容自适应模式(§ video-in-share)
- **静态/文字** → libaom `good` 模式 + 低 qmax(慢但锐;IntraBC/palette 全开)。
- **共享里放视频**(持续高运动)→ `realtime` 模式 + 高 qmax(快,冲帧率)。[实证意图,迟滞切换]

**内容分析簇(ns_codec)—— video-in-share 是空间区域检测,不是整帧开关 [逐位深挖]**。一整套协作检测器把「共享画面里正在放视频的那块」框出来:
- **`zltCContentDetect`**:异步编排器——把分析放到**后台工作线程**(互斥量+条件变量,1000ms 超时轮询),不占编码关键路径;委托给 `+176` 的子检测器。
- **`zltCTextVideoPartition`**:容器/编排。分析在 **320×180 + 160×90** 两个低分辨率尺度上做,最小区域 **256px**,**30 帧**时间窗,双缓冲(帧间比较)。内嵌运动场引擎(box 与列/行直方图与 GlobalMotionDetect 同一对象布局)。
- **`zltCGlobalMotionDetect`**:核心。① 每 **16×16 块**打**运动标签**(label 7 = 动;标签源=上游块分析,见边界);② **投影求框**:把 label-7 块投到列/行直方图,扫**持续运动带**(列 ≥5、行 ≥10 个动块;间隙容忍 <8;起码 ~5 连续)→ box = 带 ×16px;③ **全局运动门**:整帧都在动(相机 pan)→ 拒绝;④ **区域确认**:box 需 >256×256 且不贴边(距边 ≥64),框内动块 **`12·动 ≥ 总` 且 `动 ≥ 30`** → 判定视频区。
- **`zltCStaticDetection`**:每 16×16 块活动度和,自适应归一 vs **`3072 × 块列数`** 参考;≤15 块直接判活跃。
- **`zltCMotionMaskDetect`**:降采样(下采样位移,对齐 32/16,配置命令 `0x70005`)+ 委托生成运动掩码(格式码 3328)。
- **`zltCFlashDetection`**(ns_vpp):全局亮度突变(闪光/切场)检测。

**逆向重构**:`recon/zlt_content_analysis.hpp`(`recon::zlt::DetectVideoRegion` / `StaticDetection`)—— 投影求框 + 全局运动门 + 区域确认全是**逐位**(阈值 col≥5/row≥10/gap<8、box>256、`12·动≥总`&`动≥30`、static 参考 `3072×cols`);行为测试 PASS(静态帧中嵌入的运动区被框出、纯静态不触发、整帧运动被门挡)。
> **诚实边界 [推断]**:每 16×16 块的**运动标签算式**(标签 7 怎么来:块 SAD?MV?)在上游编码块分析里(⛔K-adjacent,同自适应-QP 的度量残差);`BlockMotionLabel` 是帧差替身。全局运动门的轴计数精确数学(count_A/count_B)与 MotionMask/Flash 完整体到结构级。

### 4.3 关键帧策略(三来源)
1. 周期 GOP(random-access)。 2. 按需 PLI/FIR(`SetKeyPictureRequest`)。 3. 静态屏幕周期刷新(供加入者/恢复)。

### 4.4 LTR 长期参考 —— 丢包廉价恢复
**原理**:保留 1 个"长期参考"帧(干净的更早图)。丢包打断参考链时,**不发昂贵的完整 IDR**,而是发一个**只引用 LTR** 的 P 帧;解码器仍持有该 LTR → 立即恢复,码率 ≪ IDR。
**Zoom [实证]**:`bLtrFlag → max_long_term_reference_frames=1`;恢复请求携带 `nLastReceivedPicId`(见 §8 case 2)。
**逆向重构关键代码**(VP9 golden 帧即 LTR,`vp9_ltr.hpp` / `ltr_test.cpp` 验证恢复帧 ≈ IDR 的一小部分字节):
```cpp
// 周期把 golden 刷成新的 LTR 检查点
if ((frame_no_ % ltr_period_)==0 && frame_no_>0)
    flags |= VP8_EFLAG_FORCE_GF | VP8_EFLAG_NO_UPD_ARF;   // 更新 golden = 新 LTR
// 收到 case-2 恢复请求:下一帧只引用 golden(不碰可能损坏的 last)
if (ltr_recover) flags |= VP8_EFLAG_NO_REF_LAST | VP8_EFLAG_NO_REF_ARF;  // 廉价 P 恢复,非 IDR
```
> avcodec 的 H.264/AV1 路径不暴露逐帧参考控制,故只能用 libvpx 直连做 LTR;Zoom 的 zlt 有自己的参考管理。

### 4.5 SVC 时域/空域 + 码率控制
**原理**:一路码流内含多层——时域(分层帧率,丢高层不影响低层)+ 空域(多分辨率)。
**Zoom [实证 sub_180062730]**:
- **二叉时域层帧率**:自顶向下,每低层 = 上层**一半 fps**(T0 最低,顶层满帧率),`fr[N-1]=R, fr[N-2]=R/2, …`(`v70=v66*0.5` 级联)。校验:顶层时域率 == 该空域层配置帧率。
- **码率因子** `dBitrateFactor` = **Q10 定点**(`raw·2⁻¹⁰ = raw/1024`),作用于目标码率。
```cpp
std::vector<float> TemporalFrameRates(float top, int n){    // 二叉时域:顶=满帧率,每低层减半
    std::vector<float> fr(n); float r=top;
    for(int i=n-1;i>=0;--i){ fr[i]=r; r*=0.5f; } return fr; }
float BitrateFactor = raw / 1024.0f;   // Q10:0.0009765625
```

**zlt 自带的每帧码率控制器 `zltCVideoRateCtrl`(ns_avc,vtable `0x180502F20`)[实证,逐位反编译]** —— 纠正之前"RC 全在编解码核里(⛔K)"的判断:zlt 在 libx264/libaom **之上**跑自己的复杂度自适应 QP + 漏桶 VBV,再把基准 QP 交给编解码核。
- Init `sub_1801187B0`:码率因子 = target×1024(Q10);载入 qp_min/qp_max、桶状态。Update `sub_1801193B0`:每帧更新。
- **复杂度→QP 缩放 = `clamp(pow(complexity/refComplexity, 0.3), 0.2, 5.0)`(Q10)**。**指数 0.3** 是特征常量(libx264 的 qcompress 默认 0.6 → Zoom 的 0.3 曲线更平 = 更接近恒定质量);钳位 0.2/5.0 精确。
- 帧 QP = 各单元缩放的**复杂度加权平均**;**无复杂度数据时默认 28**;钳到 **[qp_min(+82), qp_max(+83)]**(与 H.264 [20,40] 一致)。
- **漏桶 VBV**:每帧 `bucket += 1024000000 / bitrate`(定点时间填充)。
- 基准 QP 交给编解码核;**逐块感知偏移是 TextureMotion**(§3.3)。逆向重构:`recon/zlt_rate_control.hpp` `VideoRateCtrl`。
> ⛔K 边界仅剩:libx264/libaom 内部的熵/变换级 QP→比特实际映射。zlt 侧的 RC 决策(上面这些)**不是**边界,已还原。

```cpp
int QpScaleQ10(double C, double ref){ double s = ref>0 ? pow(C/ref, 0.3) : 1.0;   // 指数 0.3
  return (int)(clamp(s, 0.2, 5.0) * 1024); }                                        // Q10
// 帧QP = 复杂度加权平均(默认28)→ clamp[qmin,qmax];VBV: bucket += 1024000000/bitrate
```

### 4.6 zlt 编码控制 ABI(`ISvcEncoderBackend`)+ H.264 backend
**原理**:Zoom 的 zlt 把编码核封在一个控制 ABI 后面,§8 的 `SetKeyPictureRequest` 各 case 就是通过它下发到编码器。
**Zoom [实证]**:控制方法 ↔ 分发器 case:`ForceIdr`↔case 4(IDR)、`RequestKeyPicture`↔case 2(恢复)、`DuplicatePFrame`↔case 5(冗余P)、`SkipNextFrame`↔case 24(跳帧)、`SetBitrateTarget`。zlt H.264 backend **QP 范围 [20,40]**(`qp_min=20/qp_max=40`),`gop=ra_period`,LTR 来自 `bLtrFlag→max_long_term_reference_frames=1`,目标帧字节 `= bitrate/8/fps`。
```cpp
// 控制 ABI(复现 zlt ISvcEncoderBackend):每个方法对应一个 SetKeyPictureRequest case
void ForceIdr(...)          { force_key_ = true; }   // case 4
void RequestKeyPicture(...) { force_key_ = true; }   // case 2(baseline 退化为关键帧;真 LTR 见 §4.4)
void SkipNextFrame(...)     { skip_next_ = true; }    // case 24
// 编码参数:zlt H.264 的 QP 区间 [20,40](质量下限);码率→每帧目标字节
rp.qp_min = 20; rp.qp_max = 40;
rp.desired_frame_bytes = bitrate / 8.0 / fps;
```

---

## 5. 传输 Transport(nydus)

### 5.1 多组 FEC —— Reed–Solomon over GF(2⁸)
**原理**:一组 K 个源包配 R 个校验包;**任意 K 个(共 K+R)存活即可恢复整组,零重传延迟**。大帧拆成多个独立 RS 组(每组 K+R≤256),丢包摊开 → 适度的每组 R 就能救回大帧。
**Zoom [实证]**:RS over **GF(2⁸),生成多项式 0x11D**;nydus `sub_180005C44`(建表)+ `sub_180005F34`(消元)。**恢复或拒绝**:存活 < K 则整组放弃(不产生垃圾恢复)。
**逆向重构关键代码**(`protect/fec.hpp` 多组 + `recon::algo::RsFec` GF256 核):
```cpp
// 每 group_size 个源包一组,独立 RS(gk, level)
for (int g = 0; g < N; g += group_size) {
    int gk = min(group_size, N - g);
    std::vector<std::vector<uint8_t>> data(gk, std::vector<uint8_t>(shard_len, 0));
    for (int i=0;i<gk;++i) encode_shard(src[g+i].payload, data[i]);  // 2字节长度前缀 + 载荷
    recon::algo::RsFec rs(gk, level);
    auto parity = rs.Encode(data);           // GF(2⁸)/0x11D Cauchy 矩阵编码
}
// 解码:凑齐 ≥K 个(源+校验)才解,否则 unrecoverable(恢复或拒绝)
recon::algo::RsFec rs(k, r);
if (!rs.Decode(raw, present)) return {};     // <K 存活 → 放弃该组
```

### 5.2 多层 FEC 档 3/4/5
**Zoom [实证 telemetry]**:`total_decoded_3rd_4th_5th_fec_packets`、`cur_fec_packets_ratio` → 分 **3/4/5** 三档(每组 R 个校验包);Opus 构建串 `multifec-dred`(音频另有 in-band LBRR + 上层 multi-FEC)。档名 3/4/5 精确,**丢包阈值 [推断]**:
```cpp
int SelectLevel(double loss){ return loss<0.05 ? 3 : loss<0.10 ? 4 : 5; }  // 丢得越多 R 越大
```
与音频 QoS(§6)联动:mcm 每 tick 同时算出 bw-level(降分辨率)与 fec_level(加校验)。

### 5.3 Pacer + NACK(发送整形)
- **Pacer(令牌桶)**:把一帧的突发按**当前 bw-level 目标速率**平滑输出,压低瓶颈队列(从而压低 loss+delay)。目标速率来自服务端下发的 bw-level(见 §6.1),**不是**客户端 BWE 算出来的。
- **NACK/RTX**:接收端报缺失 seq,发送端从历史重传(~1 RTT 补 FEC 补不了的突发丢)。
> **T4 更正**:早期本节写过 "transport-wide-cc → 发送端 GCC 看到达梯度 → BWE",这是 WebRTC 的思路,**Zoom 客户端并不这么做**。穷举扫描 mcm.dll / nydus.dll **没有** trendline 估计器、overuse 检测器、AIMD 速率控制器(GCC 三件套的符号与算法都不存在)。Zoom 的视频码率决策是**服务端中介**的离散档方案,详见 §6.1。

---

## 6. §9 弱网自适应(mcm 编排脑)

### 6.1 反馈环 —— 服务端中介的离散档拥塞控制 [T4 实证架构]
```
客户端(接收侧)量测 QoS(loss/fec/plc/jitter/abs_net_delay,cmd 301,~9800ms 上报)
        │  ── 原始指标上报 ──▶  Zoom 服务端(MMR)决策
        ▼                                   │
   G.107 音频 MOS(本地遥测/NW_WARNING)      │  metric → net_score{0..5} / bw_level{1..4}(+max_loss_rate)
                                            ▼
发送端  ◀── app_uplink_net_score_t(ssb PDU id 85)──  net_score + 属性 "mc_up_bw_level"∈{1,2,3,4}
   │
   └▶ bw_level → 目标码率 → zltCVideoRateCtrl(§4.5,complexity→QP) ;  loss → MultiFecPolicy FEC 3/4/5
```
> **核心结论(T4)**:视频拥塞控制**不是**客户端 Google GCC。mcm 里 net_score/bw_level 只是**被路由的不透明值**——三个完全相同的搬运节点 `sub_180057A10`/`sub_1800D8310`/`sub_1801D09A0`(按 `值>>10` 的红黑树定位流,槽 `[10..13]`={net_score,bw_level} 双向)存转发,**没有任何客户端函数计算它**。指标→档位的映射在**服务端/配置**(`Configrate*` 配置钩子),是一条真实的**逆向边界**,不是遗漏。
- **PDU 85 线格式 [实证]**:构造 `sub_18000D600`(`*(pdu+8)=85`,net_score dword @ +24,标志字节 @ +28,属性 `mc_up_bw_level`∈{1,2,3,4});解析 `sub_180041360`(net_score 0..5 的 switch)。这**逐位确认**了 `recon/mcm/mcm_channel.hpp` 的 `NetScore(0..5)`/`BwLevel(1..4)` 枚举与 PDU 编号。

### 6.2 G.107 E-model MOS(`sub_1801642D0`)—— 延迟损伤逐位还原(修正)
**原理**:传输评分 R = R0 − 延迟损伤 Id;R→MOS 用 G.107 多项式。mcm 的 MOS 本质是**音频质量分**,作为网络质量代理去驱动音频+视频自适应。
**Zoom [实证,逐位反编译 sub_1801642D0]**:
- **延迟损伤 Id 是 log 型分段,不是线性插值**(之前用线性是近似,现修正)。折点 100/500/1000/2000/3500 ms(0x64/1F4/3E8/7D0/0xDAC);头两段带 log2 项:
  - `d≤100`: 0;`100<d≤500`: `log2(d/100)+(d−100)/55`;`500<d≤1000`: `2·log2((d−400)/100)+0.01(d−500)+9.6`;`1000<d≤2000`: `0.008(d−1000)+19.8`;`2000<d≤3500`: `0.006(d−2000)+27.8`;`>3500`: `min(60, 0.008(d−3500)+36.8)`。
- **R 钳 [0, 93.2]**;上报周期 **9800ms(0x2648)**。
```cpp
double DelayImpairment(double d){
  if(d<=100)  return 0;
  if(d<=500)  return log2(d/100) + (d-100)/55.0;               // 头两段有 log2 项
  if(d<=1000) return 2*log2((d-400)/100) + 0.01*(d-500) + 9.6;
  if(d<=2000) return 0.008*(d-1000)+19.8;
  if(d<=3500) return 0.006*(d-2000)+27.8;
  return min(60.0, 0.008*(d-3500)+36.8); }
double RtoMos(double R){ return R<=0?1.0 : R>=100?4.5 : 1.0+0.035*R + R*(R-60)*(100-R)*7e-6; }  // G.107
```
> **诚实边界(T2 结论)**:① MOS→net-score 的分档阈值(4.2/3.9/… [推断])在这个**音频 MOS 函数**内部、且被大量 telemetry(cur_mos_score/audioscore 的 JSON/文本流)包裹,没干净提取到确切数值;② `NW_WARNING`(`sub_18009CC20` 是**遥测发射器**,决策在 QoS 上报摄入 `sub_1800A9510`,cmd 201/PDU 80,8000-tick 节流)——on/off 数值同样纠缠在音频 MOS 里;③ **多层 FEC 3/4/5 是音频(Opus,`sub_18015F820` 带 samplerate/codecType)**,不是视频——视频 FEC = nydus 的 RS(§5.1 已实证)。**视频真正吃的输出 = bw-level → 分辨率阶梯,已实证(§6.4)。**

### 6.3 net-score→bw-level + 双阈值迟滞
**线格式 [实证 PDU 85]**:net_score 0..5、bw_level 1..4(见 §6.1)。`MCM_NW_WARNING` 双阈值防抖(mos<on 触发、mos>off 才清除)。
> **注意**:下面的 `ScoreFromMos`/`BwFromScore` 具体分档是**我们给本地 demo 的替身**(demo 没有 Zoom MMR,需要一个能自适应的策略)——**不是** Zoom 的真实阈值(那在服务端/配置,见 §6.1 边界)。`NW_WARNING` 的 3.0/3.4 同样是 [推断] 占位。
```cpp
BwLevel BwFromScore(s){ S5|S4→L4; S3→L3; S2→L2; else→L1; }   // [推断/替身] 非 Zoom 映射
// NW_WARNING 迟滞:on_thr=3.0 触发,off_thr=3.4 才解除  // [推断/占位]
bool Update(double mos){ if(!active_&&mos<3.0)active_=true; else if(active_&&mos>3.4)active_=false; return ...; }
```

### 6.4 分辨率阶梯 [实证 mcm 表 0x1802BF000,选择器 sub_1801E1DD0 最近像素数]
- 阶梯 = **{320×180, 640×360, 1280×720, 1920×1080}**;fps 上限 30(默认)/60(720p/1080p 运动表)。
- **相机**=帧率优先(先降分辨率);**屏幕**=分辨率优先(先降帧率/码率保文字)。
- **BWE↔分辨率统一**:带宽不足即使没丢包也要降**分辨率**(否则守全分辨率饿码率→宏块化);取 net-score 档与 BWE 档的更受限者。
- **迟滞**:降档立即,升档一次一级 + 停留(防质量"呼吸")。

---

## 7. 接收 / 抖动缓冲(nydus)

- **RTP 重组**:按 SSRC 分组、**重排**、逐组 FEC 恢复,拼回整帧。App-share 初始化 `sub_180035C8C`:90kHz 时钟、缓冲参 `+4084=51200`/`+4068=30000` [实证]。
- **完整性 = 恢复或拒绝**(RS,K−1 拒绝)+ 重排;**渲染侧从不空等**(见 §10)。
- 接收端**重请关键帧间隔** + **抖动缓冲 stall 超时** 在 conf/media 层(拥有 `IRequestRecovering`),不在这三 DLL → 静态逆向拿不到确切数值(诚实边界)。

---

## 8. 丢包恢复 —— `SetKeyPictureRequest` 分发器 `sub_180008370` [实证]

按请求类型开关(`a2`),写入**逐空域层、双缓冲的请求槽**:`slot = cfg+41644 + 52·(spatial + 5·bank)`,编码循环下一帧消费。

| case | 语义 | 响应 [实证] |
|---|---|---|
| **2 KeyPicture**(丢包恢复,*首选*) | **不是完整关键帧** | 让下一 P 帧引用**已知好的更早图**(LTR 式),存 `nLastReceivedPicId`;仅当该层在激活/订阅集才升级 IDR |
| **4 Idr**(FIR/加入) | 完整关键帧 | `slot+28=1` 置 IDR-pending;**`slot+36 = max(cur, iRequestNumber)`** = **单调请求号去重**,发出 ≥该号的 IDR 即标记已服务 → 同号重复请求**最多一个** IDR |
| **5 PDuplicate** | 冗余 P(不推进参考链) | 一个丢包不打断解码(仅当无关键帧在路上) |
| **20/3** | 冗余P/订阅变化 | IDR-pending 时**合并**进 IDR(不额外发关键帧) |
| **24 FrameSkip** | 拥塞跳帧 | `slot+48=1`,丢该层下一帧(模式 4/5) |

**要点**:分发器内**无基于时间的限流**;靠**请求号去重 + IDR 合并**,即使接收端定时狂请求也**最多每个新请求号一个 IDR**(防 IDR 风暴)。恢复优先级 = **LTR(case 2)> IDR(case 4)**。

---

## 9. 解码 Decode

- **zlt**:H.264/H.265 解码器(`zltCDecoderWrapper`/`zltCDecodeSession`)。**zbt**:AV1(libaom/dav1d)。
- **花屏/隐藏错误**:解码器对缺失参考做错误隐藏(concealment)会产出马赛克帧;是否损坏可由解码器自身标志判定(libvpx `VP8D_GET_FRAME_CORRUPTED`;H.264 avcodec 的 concealment 走日志/`decode_error_flags`)。

---

## 10. 渲染 Render(nydus)⭐ 最关键的架构

### 10.1 时钟驱动(pull),**永不阻塞** [实证]
`CCRCVideoFrameAdapter::WaitForFrameAndExitAndTimeout`(`sub_180074B74`)+ `CVideoMixer::WaitForExitAndTimeoutAndTrigger`(`sub_18005EA64`):
- 每帧周期(`this+136` = `1000.0/fps`)用 `Nydus::CClock` 排一个"剩余预算"调度,等一个条件变量,**要么新帧到达、要么调度截止**触发 → **受帧周期约束,永不无限等**。
- **有新帧** → 交付为新帧;**预算耗尽无新帧** → **重发保留的上一帧**并置"**duplicate**"标记(`qword_1801F6E00`),继续按节拍走。
- **A/V 同步**:音频为主时钟;每拍出**最新可用帧**,没有更新就重复上一帧(标 duplicate),打新时间戳(`qword_1801F7AE0`)→ 视频永不落后几秒。呈现 `Nydus::SafePresent`(`sub_180164E84`,DXGI device-lost `0x887A0005/7` 重建)。

### 10.2 末帧重复 & 黑屏
`CVideoRepeater`/`CASRepeater`(`sub_1800568F0`)缓存上一帧(`this+248`);重复标记输入 → 重发缓存,新输入 → 更新缓存。**媒体引擎里冻结无硬超时**——末帧无限重复(非阻塞),直到解出新帧,或上层**显式** `CMemoryWallRenderer::Post_ClearVideo` / 换 `CStillImageSource`(占位,含内嵌 `error_blacklist.*.rgba.raw`)才黑屏。
> **[实证] 无"损坏帧"闸门(逆 `sub_1800568F0` + 帧适配器 `sub_180074B74`=`CCRCVideoFrameAdapter::WaitForFrameAndExitAndTimeout`)**:两者的判决只看 **帧类型**(kind∈{1,2,5,6})+ **duplicate 标志**(`qword_1801F6E00`)/ **帧是否可用**,**不读任何 corrupt/concealment/valid 标志**。即冻结是**"无新可解帧"驱动**,不是"检测到花帧→丢弃"。所以 §11 的"宁可停不可脏"是**结果**(靠上游 FEC/NACK/关键帧/LTR 让解码器有可解数据 + 解码器可能自弃无法隐藏的帧),**不是渲染侧的显式拒绝花帧**。解码器暴露的损坏标志(`VP8D_GET_FRAME_CORRUPTED` 等)是**能力**,渲染路径未据此丢弃 [实证 negative]。

### 10.3 DCC = DCCI 边缘定向 2× 上采样(渲染链 "Upsample",喂给 RAISR)
**原理**:方向自适应的三次卷积插值(DCCI)。对每个 2× 空洞,比较两条对角线的梯度,**沿边(平滑方向)插值**,避免跨边缘糊化——屏幕文字/线条尤其锐利。
**Zoom [实证]**:`zltCDCC` 标量核 `sub_1801E1C10`(**非**对比度,曾误判);判决 = **梯度比 1.15**(整数 `100·Ga ≤ 115·Gb`);方向插值 = **cubic `(9(n1+n2)−f1−f2)>>4`** 即 `[-1,9,9,-1]/16`;各向同性回退 = 4 邻域平均;轴向(H/V)第二遍阈值 575/800、920/500(+8/+5 正则)。梯度核 `sub_1801E19B0` 每 2×2 算 |TL−BR|(\)、|BL−TR|(/) 等。
**逆向重构关键代码**(`recon/zlt_dcci.hpp`):
```cpp
int cubic(int n1,int n2,int f1,int f2){ return (9*(n1+n2)-f1-f2)>>4; }   // [-1,9,9,-1]/16
// 对角空洞 (2x+1,2y+1):算 135°(\) 与 45°(/) 梯度,沿平滑方向插值
if (100*G1 <= 115*G2) {                      // G1 ≤ 1.15·G2
    if (100*G2 <= 115*G1) v = (a+b+e+f+2)>>2; // 相近 → 各向同性 4 平均
    else                  v = cubic(a,b,c,d); // 边在 / 方向,沿 \ 插值
} else                    v = cubic(e,f,g,hh); // 边在 \ 方向,沿 / 插值
```

### 10.4 CChromaUpsample —— 亮度引导的色度上采样(导向滤波)
**原理**:色度(U/V)分辨率是亮度的一半;用**亮度 Y 作引导**做**导向滤波**(He 2010),让色度边界贴合亮度边界,消除色度锯齿/溢色。窗口内拟合 `U ≈ a·Y + b`,输出 `U_hr = a·Y_hr + b`。
**Zoom [实证]**:compute shader `sh_804dec70`(754 指令);3×3 窗 N=9;`a = (9·ΣYU − ΣY·ΣU)/(9·ΣYY − ΣY² + EPS)`,**EPS=105.3405**;`b = (ΣU − a·ΣY)/9`;**Q9 定点** `(a·512·Y + b·512 + 256)>>9`;边缘门 `(minU<96 || maxU>160) && (range>4)`;低方差(<5625)回退双线性。
**逆向重构关键代码**(`recon/zlt_chroma.hpp`):
```cpp
const double EPS = 105.3405;
int varN2 = 9*Syy - Sy*Sy;                          // N²·var(Y)
double aU = (9.0*Syu - (double)Sy*Su) / (varN2 + EPS);
double bU = (Su - aU*Sy) / 9.0;
int aUq = lround(aU*512), bUq = lround(bU*512);     // Q9 定点(同 shader)
if (varN2 >= 5625) uOut = (aUq*Yhr + bUq + 256) >> 9;   // 引导输出
else               uOut = /* 双线性回退(引导不可靠) */;
```

### 10.5 RAISR 超分(接收端放大细化)
**原理**:Intel RAISR。先廉价放大(bilinear base),再对每个输出像素:用局部**梯度结构张量**分类到一个**桶**(角度×强度×一致性×子像素相位),套该桶**预学习的线性滤波**卷积 LR patch → HR 子像素。锐化边缘、抑制振铃。
**Zoom [实证 zlt.dll DXBC 反汇编]**:**GPU-only**(`ns_gct::CGPUScreenRaisr sub_1802B4B80` / `CGPURaisr sub_1802B5C70`,D3D11 compute,vtable+24 = Apply);LUMA-only(色度另走 §10.4);`filterBuckets` = 学习滤波库(**⛔W 权重边界**,GPU 纹理);scale 1x/2x/3x(`RaisrX1/2/3`);**tile 16×16 输出 ← 20×20 源(2px apron)**;先跑 17×17 min/max 预处理。

**两套桶方案(实证)**:
- **屏幕 RAISR = 49 桶**:12 角 × 2 强 × 2 一致 = **48 + 1 平坦**;patch 11×11 = **121 taps**;4 相位(x2 的 2×2)。`bucket = coh·24 + str·12 + angle`。
- **相机 RAISR = 22 桶**(更轻):11 角 × 2 强,**无一致维**;梯度用 `[1,5,1]/7`;taps 25(x1,5×5)/13(x2/x3,菱形);相位 = scale²。`bucket = angle + 11·str`。
- **源尺寸选择(cmd 3,`sub_1801B8EA0`)**:**≥720p 源不超分**;断点 180p/480p/720p + 1.18×。**变化检测早退**:与上帧相同的 tile 跳过。

**性能看门狗 [实证 sub_1801B9200]**:每帧 GPU 预算 **15ms**(32 帧窗累计比 32×15);320 帧周期内 ≥2 窗超预算 → **自禁用**(telemetry `timeout=1`);60s 重置、120s 重试冷却。**超分只在机器扛得住时开,保帧率优先。**

**逆向重构关键代码 — 屏幕 RAISR 分类(HLSL,`recon/raisr_gpu.hpp`,GPU 逐指令还原)**:
```hlsl
// 结构张量(高斯加权 patch):gxx=Σw·gx², gyy=Σw·gy², gxy=Σw·gx·gy
float tr=gxx+gyy, d=sqrt((gxx-gyy)*(gxx-gyy)+4*gxy*gxy);
float l1=(tr+d)*0.5, l2=(tr-d)*0.5;                       // 特征值
float s1=sqrt(max(0,l1)), s2=sqrt(max(0,l2));
float strength=s1, coh=(s1+s2>1e-9)?(s1-s2)/(s1+s2):0;   // 强度、一致性
if(strength<flatT) bucket=NBUCK-1;                        // 平坦 → 第 49 桶
else { float ang=0.5*atan2(2*gxy,gxx-gyy); if(ang<0) ang+=PI;
       int ab=round(ang*11.0/PI); int sb=strength>=strT; int cb=coh>=0.5;
       bucket = cb*24 + sb*12 + ab; }                     // 12角×2强×2一致
int phase=(y%2)*2+(x%2);                                  // x2 的 4 相位
acc = Σ gBank[(phase*NBUCK+bucket)*TAPS + k] · LDS[patch_k];  // 桶滤波卷积
```
**相机 RAISR 分类(`recon/zlt_raisr_camera.hpp`)**:
```cpp
float gx = ([1,5,1]/7 横向差), gy = ([1,5,1]/7 纵向差);   // 3×3 结构张量 a,b,c
double lam1 = 0.5*tr + sqrt(0.25*tr*tr-(a*c-b*b)), strength=sqrt(lam1);
double theta = 0.5*atan2(2*b, a-c); if(theta<0) theta+=PI;
int abin = round(theta*10/PI);            // 11 角 [0,10]
int sbin = strength > 0.5 ? 1 : 0;        // 强度 split 0.5
bucket = abin + 11*sbin;                  // 22 桶(无一致维)
```

---

## 11. 场景应对(Zoom 策略)

| 场景 | Zoom 策略 [实证/推断] |
|---|---|
| 相机 vs 屏幕 | 相机=zlt/H.264 **帧率优先**(先降分辨率);屏幕=zbt/AV1 SC **分辨率优先**(先降帧率保文字);超分门槛不同(相机源≤480p、屏幕≤720p 才 RAISR) |
| 静态屏幕 | 降到极低帧率(甚至只发关键帧),接收端保持上一帧;周期关键帧供加入/恢复 |
| 屏幕放视频 | 切 `realtime` + 高 qmax,冲帧率(平滑 > 锐利) |
| 轻度丢包 | 多组 FEC 逐组恢复(K−1 拒绝);NACK 补突发 |
| 中度丢包(断参考链) | **case 2 LTR 优先**:引用干净 LTR 发廉价 P,不发完整 IDR |
| 全帧丢失/重度 | 解码器错误隐藏 → 渲染重复末帧;冗余 P(case 5)预防单包丢断链 |
| 带宽下降 | BWE↔分辨率统一:降**分辨率**(非只饿码率) |
| 抖动/延迟 | 抖动缓冲深度自适应;delay 进 G.107 MOS 压档 |
| 加入/订阅变化 | case 4 IDR 请求 + 周期关键帧;订阅变化合并进 IDR |
| 拥塞/算力 | `SetFrameSkipRequest`(case 24)跳帧;渲染时钟驱动不落后 |
| 网络恢复 | 升档一次一级 + 停留(防呼吸) |

---

## 12. 逆向覆盖对齐总表(zlt ~230 个 zltC 类,T5 清点)

把 zlt.dll 全部 `zltC*` 算法类按**对齐状态**分四档。目的:一眼看清"哪些已逐位对齐、哪些是刻意不碰的边界、哪些是已识别的有界残差"。

**✅ 已重构(本项目 clean-room,可复现)**
- 感知增强 VPP:`zltCSharpen` `zltCLightAdaption` `zltCColorAdaption` `zltCCLAHE` `zltCDCC`(→DCCI 上采样)`zltCGuidedFilter` `zltCColorSpaceCvt`
- 超分:`zltCRaisr` `zltCScreenRAISR`(Intel RAISR,⛔W 权重训练自有,算法/调度已复现)
- 降噪:`zltCIIRDenoise`(α=0.37)`zltCTemporalDenoise` `zltCDenoiseASM`
- 缩放:`zltCResample`(bicubic Catmull-Rom)`zltCBilinear` `zltCChromaUpsample` `zltCNearest` `zltCAlignedBilinearUpsample` `zltCUpSampleBilinear` `zltCUpsample`
- 场景/码控:`zltCSceneChangeDetect`(逐位)`zltCVideoRateCtrl`(pow-0.3 复杂度→QP)
- 内容分析簇(video-in-share):`zltCContentDetect`/`zltCTextVideoPartition`/`zltCGlobalMotionDetect`/`zltCStaticDetection`/`zltCMotionMaskDetect`/`zltCFlashDetection` —— 空间区域检测**已重构**(投影求框+全局运动门+确认逐位,见 §4.2),残差=每块运动标签算式(上游,⛔K-adjacent)

**⛔W 神经权重边界(训练/替换自有模型,绝不搬权重)**
- 虚拟背景/分割:`zltCBackgroundDetect` `zltCBackgroundExtraction` `zltCMatting` `zltCMaskRefinement` `zltCSkinSegmentation` → **xseg 子项目**
- 人脸/跟踪/注意力/自动构图:`zltCFaceDetect` `zltCTrack` `zltCAttentionLight`(喂 LightAdapt ROI)`zltCAutoFraming`
- 美颜/趣味:`zltCFaceBeautification` → **beauty 子项目**;`zltCDeepFake` `zltCDynamicEmoji`

**⛔K 编解码核(用 libx264/libx265/libaom,不逆向)**
- 熵编码:`zltCCabac*` `zltCCavlc*` `zltCResidual{Cabac,Cavlc}{Parser,Writer}`
- 变换量化/重建/环内:`zltCEncTransQuant` `zltCReconstruction*` `zltCDeblock` `zltCIntraPred` `zltCMbEncoder/Decoder` `zltCModeDecision` `zltCMotionEstimate` `zltCInterPixelSearch` `zltCInterPolate` `zltCWeightedPredict`
- 参考/DPB/码流:`zltCEncReflist`/`zltCDecReflist` `zltCDpbMgr` `zltCSps*`/`zltCPps*`/`zltCNal*`/`zltCSlice*` `zltC*InfoExt*`(SEI/元数据扩展)
- 屏幕内容全族 `zltCSc*`、硬件编解码 `zltCHw*`/`zltCWinHw*`

**◻ 已识别、未逐位重构的经典 CV(可选小项,不臆造)**
- **感知 QP 族**:`zltCRoiAdaptQuant` `zltCBackgroundAdaptQuant` `zltCTextureMotionAdaptQuant` `zltCComAdaptQuant` `zltCStaticAdaptQuant` `zltCScStaticAdaptQuant` `zltCGopFrameAdaptQuant` `zltCLtrFrameAdaptQuant` —— 策略族(相邻 vtable 0x180502718…748),经 `zltCBuQpCalc`/`zltCFrameQpCalc`/`zltCParamEstMethods` 汇入每-CU QP。**TextureMotion 轴已升到逐位**(逐帧自适应阶梯,见 §3.3);**残差收窄**为:① 两个度量的最内层算式([推断] 空间活动度/时域差,在编码分析虚调用里),② Roi/Background/Static 各自的判定阈值(结构级)。
- 去闪/去隔行:`zltCComDeflicker` `zltCEncDeflicker` `zltCDeflickerHelper` `zltCFlashDetection` `zltCDeinterlace`
- 滤波/运动:`zltCRecursiveBF`(递归双边)`zltCFrameBlur` `zltCSmoothFilter` `zltCGeneralFilter` `zltCGlobalMotionDetect` `zltCMotionMaskDetect`
- 几何:`zltCRotate` `zltCMirror` `zltCDistortion`

> **结论**:用户可见的核心画质链(增强/超分/降噪/缩放/场景/码控)已逐位对齐;未覆盖项要么是**刻意的 ⛔W/⛔K 边界**(神经权重、标准编解码核),要么是**已定位的有界经典-CV 残差**(感知 QP 各区偏移、去闪、递归双边)。没有"未知的黑盒"。

---

## 附录:关键函数 / 地址 / 常量速查(实证)

| 技术 | 符号/地址 | 常量 |
|---|---|---|
| 丢包恢复分发器 | zlt `sub_180008370` | case 2/4/5/20/24;`slot=cfg+41644+52·(spatial+5·bank)`;`slot+36=max(cur,reqno)` |
| DCCI 上采样 | zlt `sub_1801E1C10`(标量)/`sub_1801E19B0`(梯度) | 梯度比 1.15(100/115);cubic `[-1,9,9,-1]/16`;轴向 575/800、920/500+8/5 |
| 色度导向滤波 | shader `sh_804dec70`(754 指令) | EPS=105.3405;N=9;Q9 `>>9`;边缘门 minU<96/maxU>160/range>4;var<5625 回退 |
| RAISR 屏幕 | `ns_gct::CGPUScreenRaisr sub_1802B4B80`;看门狗 `sub_1801B9200`;源选择 `sub_1801B8EA0` | **49 桶**(12角×2强×2一致+平坦),121 taps,4 相位;tile16×16←20×20;预算 15ms;2 strikes/320f 自禁用;≥720p 源关 |
| RAISR 相机 | `ns_gct::CGPURaisr sub_1802B5C70`;`zltCRaisr` | **22 桶**(11角×2强,无一致);梯度 [1,5,1]/7;taps 25(x1)/13(x2/3);相位 scale²;强度 split 0.5 |
| zlt 控制 ABI | `ISvcEncoderBackend`(ForceIdr/RequestKeyPicture/DuplicatePFrame/SkipNextFrame) | ↔ SetKeyPictureRequest case 4/2/5/24;H.264 QP [20,40];帧字节=bitrate/8/fps |
| 自适应 QP | zlt `sub_1800E7A00`(vt 0x180502738);阶梯 `sub_1800E7680`;阈值构建 `sub_1800E7610`;乘数表 `qword_1803FBDB0`(纹理)/`qword_1803FBDE0`(运动) | 度量 obj+104(纹理)/+112(运动);**阈值逐帧自适应 `thr[i]=帧均值×mult[i]+1`**;`level=−3+count(度量≥thr[i])`∈[−3,+3];delta=tex+mot(mode 门控) |
| LightAdapt 逆光 | zlt `zltCLightAdaption`(0x180504CA8);curve `sub_1801C1350`;geomean `sub_1801C1100`;attention `sub_1801C11D0` | 几何均值 `exp(Σh[i]·log i/(N−h[0]))`;触发 ROI≤100 & 高光(240..255)≥10% & 帧≤170;ROI 采样≤200;档 720/360/180→shift 3/2/1 |
| CLAHE | zlt `zltCCLAHE`(0x180504F28);apply `sub_1801E10F0`;核 `sub_1801E0820` | 8×8 tile/256-bin;luma 钳 [16,235]或[0,255](range-flag);clip=cfg 0x70004;双线性混合 |
| 多组 FEC RS | nydus `sub_180005C44`(建表)/`sub_180005F34`(消元) | GF(2⁸) 生成多项式 0x11D;恢复或拒绝(K−1) |
| G.107 MOS | mcm `sub_1801642D0` | 延迟折点 100/500/1000/2000/3500ms;R 钳 93.2 |
| NW_WARNING | mcm `sub_18009CC20` | 双阈值迟滞 on 3.0/off 3.4 |
| 上行网络分 | mcm `app_uplink_net_score_t` PDU **85**;构造 `sub_18000D600`;解析 `sub_180041360`;路由 `sub_180057A10`/`sub_1800D8310`/`sub_1801D09A0` | net_score 0..5(dword@+24);属性 `mc_up_bw_level`∈{1,2,3,4};**服务端中介,客户端不算分** |
| QoS 上报 | mcm cmd 301 | 周期 9800ms(0x2648) |
| 分辨率阶梯 | mcm 表 `0x1802BF000`;选择器 `sub_1801E1DD0` | {320×180,640×360,1280×720,1920×1080};fps 30/60 |
| 时钟渲染 | nydus `sub_180074B74`(FrameAdapter)/`sub_18005EA64`(Mixer) | `1000/fps` 节拍;duplicate 标 `qword_1801F6E00`;`SafePresent sub_180164E84` |
| 末帧重复/黑屏 | nydus `sub_1800568F0`(Repeater)/`Post_ClearVideo` | 缓存 `this+248`;无硬超时,显式黑屏 |
| AV1 SC 编码核 | zbt `(mode&0xF)==2 → zbtCScEncoderCore` | libaom tune=screen/palette/IntraBC |
| AV1 wrapper | zbt `Av1EncInterfaceCreate 0x18009C920`;OBU 解析 `sub_1801CFA10`/`sub_1801D0AA0`;HW `0x18009CD10` | SpecialFeature enc 0x850001/dec 0x880001;8 参考槽;T.35+HDR;多线程 tile |
| 缩放核 | zlt `zltCResample`(vtable 0x180504F98);系数 `sub_1801BC400`;权重 `sub_1801BCF00`;核 `sub_1801BCCA0` | Catmull-Rom a=−0.5(default)/Lanczos-4;Q14 归一 16384;fscale=max(1,src/dst) |
| IIR 降噪 | zlt `sub_1802A5260 zltCIIRDenoise` | α=0.37(out=0.37in+0.63prev);cmd 0x70004 |
| SVC/码率 | zlt `sub_180062730` | 二叉时域半帧率级联;码率因子 Q10(raw/1024) |
| 多层 FEC 档 | mcm `MultiFecPolicy` | 3/4/5(loss<5%/<10%/else);telemetry `..3rd_4th_5th_fec..` |

*(逆向重构源:`bin2cpp-output/recon/{zlt_dcci,zlt_chroma,zlt_adaptive_qp,zlt_raisr,zlt_vfx,zlt_scene_change,zlt_content_analysis}.hpp`、`recon/mcm/mcm_channel.hpp`、`protect/fec.hpp`、`encode/vp9_ltr.hpp`。IDA 环境:D:\solft 便携 IDA 7.5;库 `scratchpad/zlt/{zlt,nydus,zbt,mcm}.dll.i64`。)*
