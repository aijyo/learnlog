// av1_screen.hpp — the AV1 SCREEN-CONTENT backend: the Zoom-exact path, wired through the RECONSTRUCTED
// zbt control layer. Zoom's `zbt` module encodes screen share with its AV1 Screen-Content core
// ((mode&0xF)==2 -> zbtCScEncoderCore = libaom with the SC tools). Here the reconstructed control class
// `recon::zbt::Av1EncoderControl` (config mapping / core selection / keyframe + bitrate driving — the part
// that is code, from the decompiled bodies) drives a REAL libaom kernel injected as `recon::zbt::IAv1Encoder`
// (the coding kernel is the ⛔K boundary; the RE stub `NullAv1Encoder` is replaced by `LibaomAv1Encoder`).
// So the demo runs the reconstructed zbt control path with libaom as the kernel, exactly as the header says
// ("real impl wraps libaom, injected via IAv1Encoder"). The SC tools (tune=screen + palette + IntraBC) are
// the fix for sharp scrolling text (§3.4). Decode = FFmpeg AV1 (libdav1d). Built only under AVP_WITH_AOM.
#pragma once
#include "encode/screen_codec.hpp"
#if defined(AVP_WITH_FFMPEG) && defined(AVP_WITH_AOM)
#include "encode/algo/zbt_av1_encoder.hpp"   // recon::zbt::Av1EncoderControl / IAv1Encoder / Av1EncParams
#include <cstdio>
#include <cstring>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/opt.h>
#include <libavutil/imgutils.h>
}

namespace avp {

// The real AV1 coding kernel, implementing the reconstructed zbt IAv1Encoder over libaom (avcodec).
// This is what `NullAv1Encoder` stands in for in the reconstruction — here it's the actual libaom.
// The recon Av1EncParams carries {w,h,frame_rate,bitrate,qp,layers,screen_content,hardware}; the finer
// libaom knobs (usage/cpu-used/qmax — NOT in the decompiled control surface, they live inside the ⛔K
// kernel) are our own choices, supplied via `tune`.
class LibaomAv1Encoder : public recon::zbt::IAv1Encoder {
public:
  ScreenEncParams tune;   // set by Av1ScreenEncoder before Configure (usage/cpu-used/qmin/qmax)

  int Configure(const recon::zbt::Av1EncParams& p) override {
    const AVCodec* enc = avcodec_find_encoder_by_name("libaom-av1");
    if (!enc) return -1;
    c_ = avcodec_alloc_context3(enc);
    if (!c_) return -1;
    const int fps = p.frame_rate > 0 ? (int)(p.frame_rate + 0.5f) : 12;
    c_->width = p.width; c_->height = p.height;
    c_->time_base = AVRational{1, fps}; c_->framerate = AVRational{fps, 1};
    c_->pix_fmt = AV_PIX_FMT_YUV420P;
    c_->bit_rate = (int64_t)(p.bitrate > 0 ? p.bitrate : tune.kbps * 1000);
    c_->qmin = tune.qmin; c_->qmax = tune.qmax;
    c_->gop_size = tune.gop; c_->max_b_frames = 0;
    c_->flags |= AV_CODEC_FLAG_LOW_DELAY;
    av_opt_set(c_->priv_data, "usage", tune.realtime ? "realtime" : "good", 0);
    av_opt_set_int(c_->priv_data, "cpu-used", tune.cpu_used, 0);
    av_opt_set_int(c_->priv_data, "lag-in-frames", 0, 0);
    av_opt_set_int(c_->priv_data, "row-mt", 1, 0);
    av_opt_set(c_->priv_data, "tiles", "2x2", 0);
    if (p.screen_content)   // (mode&0xF)==2 -> the SC core: tune=screen + palette + IntraBC
      av_opt_set(c_->priv_data, "aom-params", "tune-content=screen:enable-palette=1:enable-intrabc=1:error-resilient=1", 0);
    else
      av_opt_set(c_->priv_data, "aom-params", "error-resilient=1", 0);
    if (avcodec_open2(c_, enc, nullptr) != 0) return -1;
    f_ = av_frame_alloc(); f_->format = AV_PIX_FMT_YUV420P; f_->width = p.width; f_->height = p.height;
    return av_frame_get_buffer(f_, 32) == 0 ? 0 : -1;
  }
  // buf = contiguous I420 (Y then U then V); obu/cap = output; outLen set on success. last_key updated.
  int Encode(const uint8_t* buf, size_t n, uint8_t* obu, size_t cap, size_t& outLen) override {
    outLen = 0; last_key = false;
    if (!c_ || !f_ || av_frame_make_writable(f_) != 0) return -1;
    const int w = c_->width, h = c_->height, cw = w / 2, chh = h / 2;
    const uint8_t* Y = buf; const uint8_t* U = Y + (size_t)w * h; const uint8_t* V = U + (size_t)cw * chh;
    (void)n;
    for (int j = 0; j < h; ++j) memcpy(f_->data[0] + (size_t)j * f_->linesize[0], Y + (size_t)j * w, w);
    for (int j = 0; j < chh; ++j) {
      memcpy(f_->data[1] + (size_t)j * f_->linesize[1], U + (size_t)j * cw, cw);
      memcpy(f_->data[2] + (size_t)j * f_->linesize[2], V + (size_t)j * cw, cw);
    }
    f_->pts = pts_++;
    f_->pict_type = force_next_key_ ? AV_PICTURE_TYPE_I : AV_PICTURE_TYPE_NONE; force_next_key_ = false;
    if (avcodec_send_frame(c_, f_) != 0) return -1;
    AVPacket* pkt = av_packet_alloc(); int rc = -1;
    while (avcodec_receive_packet(c_, pkt) == 0) {
      if (outLen + pkt->size <= cap) { memcpy(obu + outLen, pkt->data, pkt->size); outLen += pkt->size; rc = 0; }
      if (pkt->flags & AV_PKT_FLAG_KEY) last_key = true;
      av_packet_unref(pkt);
    }
    av_packet_free(&pkt);
    return rc;
  }
  int ForceKeyframe() override { force_next_key_ = true; return 0; }
  int SetBitrate(int bps) override { if (c_ && bps > 0) { c_->bit_rate = bps; av_opt_set_int(c_->priv_data, "b", bps, 0); } return 0; }
  bool last_key = false;
  ~LibaomAv1Encoder() { if (f_) av_frame_free(&f_); if (c_) avcodec_free_context(&c_); }
private:
  AVCodecContext* c_ = nullptr; AVFrame* f_ = nullptr; int64_t pts_ = 0; bool force_next_key_ = false;
};

// Screen-content encoder driving libaom THROUGH the reconstructed zbt control layer.
class Av1ScreenEncoder : public IScreenEncoder {
public:
  bool open(const ScreenEncParams& p) override {
    p_ = p;
    backend_.tune = p;                                  // libaom knobs (⛔K-internal, our choices)
    recon::zbt::Av1EncParams ap;                        // the reconstructed control surface
    ap.width = p.width; ap.height = p.height; ap.frame_rate = (float)p.fps;
    ap.bitrate = p.kbps * 1000; ap.screen_content = p.screen_content;   // -> (mode&0xF)==2 SC core
    ctrl_.reset(new recon::zbt::Av1EncoderControl(&backend_));
    return ctrl_->Open(ap) == 0;
  }
  bool encode(const I420Image& in, bool force_key, std::vector<uint8_t>& out, bool& key) override {
    out.clear(); key = false;
    if (!ctrl_) return false;
    pack_i420(in);
    if (force_key) ctrl_->RequestKeyframe();            // reconstructed keyframe control
    int rc = ctrl_->EncodeFrame(buf_.data(), buf_.size(), out);   // reconstructed encode path -> libaom
    key = backend_.last_key;
    return rc == 0 && !out.empty();
  }
  void set_bitrate(int bps) override { if (ctrl_) ctrl_->SetBitrate(bps); }
  const char* name() const override { return "AV1 screen-content (recon zbt control + libaom, tune=screen/IntraBC)"; }

private:
  void pack_i420(const I420Image& img) {
    const int w = p_.width, h = p_.height, cw = w / 2, chh = h / 2;
    buf_.resize((size_t)w * h + 2 * (size_t)cw * chh);
    uint8_t* Y = buf_.data(); uint8_t* U = Y + (size_t)w * h; uint8_t* V = U + (size_t)cw * chh;
    for (int j = 0; j < h; ++j) { int sj = j < img.h ? j : img.h - 1;
      for (int i = 0; i < w; ++i) { int si = i < img.w ? i : img.w - 1; Y[(size_t)j * w + i] = img.y[(size_t)sj * img.w + si]; } }
    for (int j = 0; j < chh; ++j) { int sj = j < img.ch() ? j : img.ch() - 1;
      for (int i = 0; i < cw; ++i) { int si = i < img.cw() ? i : img.cw() - 1;
        U[(size_t)j * cw + i] = img.u[(size_t)sj * img.cw() + si];
        V[(size_t)j * cw + i] = img.v[(size_t)sj * img.cw() + si]; } }
  }
  ScreenEncParams p_;
  LibaomAv1Encoder backend_;
  std::unique_ptr<recon::zbt::Av1EncoderControl> ctrl_;
  std::vector<uint8_t> buf_;
};

class Av1ScreenDecoder : public IScreenDecoder {
public:
  bool open() override {
    const AVCodec* dec = avcodec_find_decoder(AV_CODEC_ID_AV1);   // libdav1d in the BtbN build
    if (!dec) return false;
    c_ = avcodec_alloc_context3(dec);
    if (!c_) return false;
    c_->thread_count = 0; c_->flags |= AV_CODEC_FLAG_LOW_DELAY;
    return avcodec_open2(c_, dec, nullptr) == 0;
  }
  bool decode(const std::vector<uint8_t>& au, I420Image& out) override {
    if (!c_) return false;
    std::vector<uint8_t> padded(au); padded.resize(au.size() + AV_INPUT_BUFFER_PADDING_SIZE, 0);
    AVPacket* pkt = av_packet_alloc(); pkt->data = padded.data(); pkt->size = (int)au.size();
    AVFrame* f = av_frame_alloc();
    bool got = false;
    if (avcodec_send_packet(c_, pkt) == 0) {
      while (avcodec_receive_frame(c_, f) == 0) {
        out.w = f->width; out.h = f->height;
        out.y.assign((size_t)out.w * out.h, 0);
        out.u.assign((size_t)out.cw() * out.ch(), 128);
        out.v.assign((size_t)out.cw() * out.ch(), 128);
        for (int j = 0; j < out.h; ++j) memcpy(&out.y[(size_t)j * out.w], f->data[0] + (size_t)j * f->linesize[0], out.w);
        for (int j = 0; j < out.ch(); ++j) {
          memcpy(&out.u[(size_t)j * out.cw()], f->data[1] + (size_t)j * f->linesize[1], out.cw());
          memcpy(&out.v[(size_t)j * out.cw()], f->data[2] + (size_t)j * f->linesize[2], out.cw());
        }
        got = true;
      }
    }
    av_frame_free(&f); av_packet_free(&pkt);
    return got;
  }
  const char* name() const override { return "AV1 (FFmpeg libdav1d decoder)"; }
  ~Av1ScreenDecoder() override { if (c_) avcodec_free_context(&c_); }
private:
  AVCodecContext* c_ = nullptr;
};

}  // namespace avp
#endif  // AVP_WITH_FFMPEG && AVP_WITH_AOM
