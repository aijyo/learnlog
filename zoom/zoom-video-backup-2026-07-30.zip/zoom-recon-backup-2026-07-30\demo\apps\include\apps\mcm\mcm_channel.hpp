// mcm_channel.hpp — the mcm media-channel ORCHESTRATOR: ties together the four facets
// the mcm function-map describes into one decision loop:
//   通道编排 (MediaChannel)  +  QoS/MOS (G.107)  +  多层FEC策略 (MultiFecPolicy)  +  带宽分配
// so a single QoS tick drives: metrics -> MOS -> net-score -> bw-level + FEC level.
//
// Body-verified anchors (mcm.dll):
//   sub_1801642D0     per-user audio MOS (ITU-T G.107 E-model): R->MOS polynomial +
//                     delay-impairment curve (breakpoints 100/500/1000/2000/3500 ms)
//   sub_18009CC20     MCM_NW_WARNING network-warning trigger (double-threshold hysteresis)
//   app_uplink_net_score_t (PDU 85)  net_score 0..5 / bw_level 1..4
//   QoS report (cmd 301): cur_packets_loss_rate / cur_fec_packets_ratio / cur_plc_packets_ratio /
//                         cur_jitter_ms / abs_net_delay_ms
//   score-report throttle ~9800 ms (0x2648)
//
// [实证]=recovered from bodies; [推断]=inferred shape (the R-from-loss mapping and the
// MOS->net-score thresholds are mcm-internal constants not fully recovered).
#pragma once
#include "protect/algo/mcm_multifec.hpp"   // MultiFecPolicy (reuse protect's vendored copy; avoids dup)
#include <cstdint>
#include <string>
#include <vector>
#include <utility>

namespace recon { namespace mcm {

// ---- QoS metrics carried by the mcm QoS report (cmd 301) [实证 keys] ----
struct AudioQosMetrics {
  double   loss_rate        = 0.0;   // cur_packets_loss_rate (0..1)
  double   fec_ratio        = 0.0;   // cur_fec_packets_ratio (fraction recovered by FEC)
  double   plc_ratio        = 0.0;   // cur_plc_packets_ratio (fraction concealed)
  uint32_t jitter_ms        = 0;     // cur_jitter_ms
  uint32_t abs_net_delay_ms = 0;     // abs_net_delay_ms
};

// ---- ITU-T G.107 E-model (sub_1801642D0) [实证 polynomial + breakpoints] ----
inline double DelayImpairment(uint32_t d_ms) {
  struct P { double d, id; };
  static const P k[] = {{100,0},{500,9.6},{1000,19.8},{2000,27.8},{3500,36.8},{12000,60}};
  if (d_ms <= k[0].d) return 0.0;
  for (size_t i = 1; i < sizeof(k)/sizeof(k[0]); ++i)
    if (d_ms <= k[i].d) {
      double t = (double(d_ms) - k[i-1].d) / (k[i].d - k[i-1].d);
      return k[i-1].id + t * (k[i].id - k[i-1].id);
    }
  return 60.0;
}
inline double RtoMos(double R) {                       // published G.107 formula
  if (R <= 0)   return 1.0;
  if (R >= 100) return 4.5;
  return 1.0 + 0.035*R + R*(R - 60.0)*(100.0 - R)*7.0e-6;
}
inline double EstimateMos(double R_base, uint32_t delay_ms, int* R_x10 = nullptr) {
  double R = R_base - DelayImpairment(delay_ms);
  if (R < 0) R = 0; else if (R > 93.2) R = 93.2;       // recovered clamp
  if (R_x10) *R_x10 = int(R * 10.0);
  return RtoMos(R);
}
// Base transmission rating R0 from loss/FEC/PLC. [推断 shape]: residual loss after FEC
// impairs R; PLC softens but does not fully hide it.
inline double BaseRfactor(const AudioQosMetrics& m) {
  double residual = m.loss_rate * (1.0 - m.fec_ratio);        // FEC recovers a fraction
  double R = 93.2 - residual*100.0*2.5 - m.plc_ratio*100.0*0.8;
  return R < 0 ? 0 : R;
}

// ---- uplink net-score 0..5 / bw-level 1..4 (PDU 85) ----
enum class NetScore : uint8_t { S0=0,S1,S2,S3,S4,S5 };
enum class BwLevel  : uint8_t { L1=1,L2,L3,L4 };
inline NetScore ScoreFromMos(double mos) {             // cut points refined by IDA re-analysis 2026-07
  // 4.2 / 3.5 / 3.0 / 2.5 are 实证 (present as real doubles in mcm .rdata with code xrefs); the old
  // recon S4 cut of 3.9 is NOT in the image — 3.64 and 3.75 are, so S4 uses 3.75. (See
  // bin2cpp-output/recon/ida_recovered_ladders.md §5.) Exact compare site not fully pinned.
  if (mos >= 4.2) return NetScore::S5;
  if (mos >= 3.75) return NetScore::S4;
  if (mos >= 3.5) return NetScore::S3;
  if (mos >= 3.0) return NetScore::S2;
  if (mos >= 2.5) return NetScore::S1;
  return NetScore::S0;
}
inline BwLevel BwFromScore(NetScore s) {
  switch (s) {
    case NetScore::S5: case NetScore::S4: return BwLevel::L4;
    case NetScore::S3:                    return BwLevel::L3;
    case NetScore::S2:                    return BwLevel::L2;
    default:                              return BwLevel::L1;
  }
}

// ---- MCM_NW_WARNING (sub_18009CC20) double-threshold hysteresis ----
class NetWarning {
public:
  // warn on when mos < on_thr; only clear when mos recovers above off_thr (>on_thr).
  bool Update(double mos, double on_thr = 3.0, double off_thr = 3.4) {
    bool prev = active_;
    if (!active_ && mos < on_thr)  active_ = true;
    else if (active_ && mos > off_thr) active_ = false;
    return active_ != prev;   // true == state changed (emit telemetry)
  }
  bool active() const { return active_; }
private:
  bool active_ = false;
};

// ---- bandwidth distribution by bw_level weight (bandwidth_distribute_info) ----
struct StreamBudget { uint32_t id; BwLevel level; uint32_t assigned_bps; };
inline std::vector<StreamBudget>
DistributeBandwidth(uint32_t total_bps, const std::vector<std::pair<uint32_t,BwLevel>>& streams) {
  uint32_t wsum = 0; for (auto& s : streams) wsum += uint32_t(s.second);
  std::vector<StreamBudget> out;
  for (auto& s : streams) {
    uint32_t w = uint32_t(s.second);
    out.push_back({ s.first, s.second, wsum ? uint32_t(uint64_t(total_bps)*w/wsum) : 0 });
  }
  return out;
}

// ---- the orchestrator: one QoS tick -> the whole adaptation decision ----
struct ChannelDecision {
  double   mos = 0;
  int      r_x10 = 0;
  NetScore score = NetScore::S5;
  BwLevel  bw = BwLevel::L4;
  int      fec_level = 3;       // 3/4/5 — from MultiFecPolicy, applied by mcm_multifec
  bool     warning = false;     // MCM_NW_WARNING active
  bool     warning_changed = false;
};

class MediaChannel {
public:
  static constexpr uint32_t kScoreReportPeriodMs = 9800;  // recovered throttle (~0x2648)
  static constexpr int      kQosCmd = 301;

  // ties: QoS metrics -> MOS -> net-score -> bw-level  +  loss -> FEC level.
  ChannelDecision OnQosTick(const AudioQosMetrics& m) {
    ChannelDecision d;
    d.mos       = EstimateMos(BaseRfactor(m), m.abs_net_delay_ms, &d.r_x10);
    d.score     = ScoreFromMos(d.mos);
    d.bw        = BwFromScore(d.score);
    d.fec_level = MultiFecPolicy::SelectLevel(m.loss_rate);     // <- the 3/4/5 FEC decision
    d.warning_changed = warn_.Update(d.mos);
    d.warning   = warn_.active();
    last_ = d;
    return d;
  }
  const ChannelDecision& last() const { return last_; }

  void AddStream(uint32_t id, BwLevel lvl) { streams_.push_back({id, lvl}); }
  std::vector<StreamBudget> Distribute(uint32_t total_bps) const {
    return DistributeBandwidth(total_bps, streams_);
  }

private:
  NetWarning warn_;
  ChannelDecision last_;
  std::vector<std::pair<uint32_t,BwLevel>> streams_;
};

}} // namespace recon::mcm
