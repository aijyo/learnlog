using System.Windows;

namespace AvpMonitor
{
    // The tunable VFX-module strengths, passed to peer.exe as --vfx-* flags on Start. Defaults = the
    // content-aware tuning baked into peer_main (camera face chain gentle; screen chain fuller).
    public class VfxConfig
    {
        public double Light = 0.40, Color = 0.35, SharpenCam = 0.30, SharpenScreen = 0.60, Clahe = 3.0;
        public VfxConfig Clone() => (VfxConfig)MemberwiseClone();
    }

    public partial class ConfigWindow : Window
    {
        public VfxConfig Result { get; private set; }

        public ConfigWindow(VfxConfig cur)
        {
            InitializeComponent();
            Load(cur ?? new VfxConfig());
        }

        void Load(VfxConfig c)
        {
            LightSlider.Value = c.Light; ColorSlider.Value = c.Color;
            SharpenCamSlider.Value = c.SharpenCam; SharpenScreenSlider.Value = c.SharpenScreen;
            ClaheSlider.Value = c.Clahe;
        }

        void Ok_Click(object s, RoutedEventArgs e)
        {
            Result = new VfxConfig
            {
                Light = LightSlider.Value,
                Color = ColorSlider.Value,
                SharpenCam = SharpenCamSlider.Value,
                SharpenScreen = SharpenScreenSlider.Value,
                Clahe = ClaheSlider.Value
            };
            DialogResult = true;
        }

        void Cancel_Click(object s, RoutedEventArgs e) => DialogResult = false;

        void Defaults_Click(object s, RoutedEventArgs e) => Load(new VfxConfig());
    }
}
