// nack.hpp — module 4 NACK retransmission (AV_PIPELINE_DETAILS.html §4). When FEC can't recover a
// gap (e.g. a burst wiped a whole group), the receiver asks for the missing packets by sequence
// number and the sender resends them from a short history buffer. Costs >=1 RTT (the FEC/NACK
// trade-off in §4), so it's used for small-RTT / bursty loss where standing FEC would be wasteful.
#pragma once
#include "packetizer.hpp"
#include <algorithm>
#include <cstdint>
#include <deque>
#include <set>
#include <unordered_map>
#include <vector>

namespace avp {

// Sender side: keep the last `capacity` sent packets so they can be resent on NACK.
class RetransmitBuffer {
public:
  explicit RetransmitBuffer(size_t capacity = 512) : cap_(capacity) {}
  void add(const MediaPacket& p) {
    store_[p.seq] = p; order_.push_back(p.seq);
    while (order_.size() > cap_) { store_.erase(order_.front()); order_.pop_front(); }
  }
  // resolve a NACK list to the packets we still hold (missing-from-history are dropped).
  std::vector<MediaPacket> resend(const std::vector<uint16_t>& seqs) const {
    std::vector<MediaPacket> out;
    for (uint16_t s : seqs) { auto it = store_.find(s); if (it != store_.end()) out.push_back(it->second); }
    return out;
  }
  bool has(uint16_t seq) const { return store_.count(seq) != 0; }
private:
  size_t cap_;
  std::unordered_map<uint16_t, MediaPacket> store_;
  std::deque<uint16_t> order_;
};

// Receiver side: track arrivals, detect gaps, emit a NACK list. `reorder_slack` packets past a gap
// must arrive before we NACK it, so light reordering doesn't trigger spurious retransmits.
class NackTracker {
public:
  explicit NackTracker(int reorder_slack = 2) : slack_(reorder_slack) {}

  void observe(uint16_t seq) {
    received_.insert(seq);
    missing_.erase(seq);
    if (!have_highest_) { highest_ = seq; have_highest_ = true; return; }
    if (seq16_gt(seq, highest_)) {
      for (uint16_t s = (uint16_t)(highest_ + 1); s != seq; ++s)
        if (!received_.count(s)) missing_.insert(s);
      highest_ = seq;
    }
  }

  // seqs missing and now `slack` behind the newest arrival (so reordering had a chance to fill them).
  std::vector<uint16_t> build_nack() const {
    std::vector<uint16_t> out;
    for (uint16_t s : missing_)
      if (seq16_gt((uint16_t)(highest_ - slack_), s) || (uint16_t)(highest_ - slack_) == s) out.push_back(s);
    std::sort(out.begin(), out.end());
    return out;
  }
  void resolve(uint16_t seq) { observe(seq); }   // a resent packet arrived
  bool complete() const { return missing_.empty(); }
  size_t outstanding() const { return missing_.size(); }

private:
  // a > b in uint16 sequence space (RFC1982-style, window < 32768).
  static bool seq16_gt(uint16_t a, uint16_t b) { return (uint16_t)(a - b) != 0 && (uint16_t)(a - b) < 0x8000; }
  int slack_;
  uint16_t highest_ = 0; bool have_highest_ = false;
  std::set<uint16_t> received_, missing_;
};

}  // namespace avp
