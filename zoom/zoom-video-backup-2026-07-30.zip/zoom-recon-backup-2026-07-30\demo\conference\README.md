# conference — all 8 modules in one real-time loopback process

The integrated app the module-by-module build adds up to. One process runs the **entire pipeline in
real time**, pacing a video stream through every module under injected packet loss, plus the audio
path. This is where capture → preprocess → encode → FEC → transport → jitter → decode → render become a
single running system.

```
每 frame @ target fps:
  synth/screen ─► preprocess ─► H.264 encode (layered) ─► packetize ─► FEC
        ─► loopback channel (drop % + reorder) ─► jitter buffer ─► FEC recover ─► reassemble
        ─► decode (FFmpeg) ─► render (BMP)                                 → per-frame stats
audio: mic ─► 3A (AEC/ANS/AGC) ─► AAC encode ─► loopback ─► AAC decode ─► WAV
```

## Pieces
- **`conference.hpp`** — `Conference`: owns one instance of every module; `process_frame(bgra)` runs a
  frame end to end and returns a `FrameStat`; `process_audio(pcm)` runs the audio path. Optionally runs
  a **congestion-control loop**: each frame's packets are modeled crossing a bottleneck link, the GCC
  estimator (module 5) updates its target from the delay/loss, and `set_bitrate()` adapts the encoder.
- **`media_channel.hpp`** — `IMediaChannel` abstraction + a real **RTP-like wire format** (serialize a
  media/FEC packet to bytes and parse it back — the real work a transport does to cross a socket).
- **`loopback_channel.hpp`** — in-process `IMediaChannel` (loss + reorder), zero sockets.
- **`udp_media_channel.hpp`** — a **real UDP** `IMediaChannel`: every packet goes through an actual
  winsock socket (127.0.0.1) — kernel network path, not a queue. Loss is injected at the receiver
  (loopback itself is lossless) so FEC/jitter recovery is still exercised.

## Build & run
```powershell
cmake -S . -B build -DAVP_WITH_WGC=ON
cmake --build build --config Release --target conference_demo
.\build\conference\Release\conference_demo.exe [--seconds N] [--fps F] [--loss P] \
    [--source synth|screen] [--transport loopback|udp] [--cc --link-kbps N] [--no-layered]
# full loop with real decode + PSNR + BMP/WAV:
cmake -S . -B build-ff -DAVP_WITH_FFMPEG=ON
cmake --build build-ff --config Release --target conference_demo
.\build-ff\conference\Release\conference_demo.exe --transport udp --loss 0.08
.\build-ff\conference\Release\conference_demo.exe --transport udp --cc --link-kbps 800   # congestion control
```

## Verified (this machine)
```
in-process loopback, 8% loss:
  real-time    45 frames in 3.00 s = 15.0 fps (hit the target)
  channel      359 sent, 33 dropped = 9.2%; 11 frames rebuilt by FEC/reorder
  reassemble   45/45 access units BYTE-INTACT ; decode 45/45, avg PSNR 47.0 dB ; ~1.5 ms/frame
  audio        3A -> AAC -> loopback -> AAC decode, 142080 -> 143360 samples -> conf_audio.wav

real UDP sockets (winsock 127.0.0.1), 6% loss:
  media channel  "real UDP (winsock 127.0.0.1)", packets serialized to the wire format + sent/recv'd
  reassemble     75/75 access units BYTE-INTACT ; decode 75/75 (real UDP path + FEC recovery)

congestion control (--cc), 800 kbps bottleneck:
  CC target      started 2000 kbps -> converged to ~967 kbps (delay-based, tracks the link)
  a 1500 kbps link -> target converges to ~1676 kbps instead (follows the bottleneck)
```

At ~9% loss every frame still arrives byte-perfect because FEC + the jitter buffer recover the drops —
the whole weak-network story (§4/§6/§9) live. Over **real UDP** the packets truly cross the kernel
network stack (serialize → sendto → recvfrom → parse). The **CC loop** converges the send target to the
link by delay (before loss). Honest note: the GCC *target* tracks the link (that's the estimator's job);
the stand-in **minih264 has loose rate control** so its actual output only loosely follows the target —
a strict-CBR encoder would sit on it. Real codecs, real DSP, real FEC, real sockets. Clean-room,
following Zoom's *design* (not its code). For interop / education.
