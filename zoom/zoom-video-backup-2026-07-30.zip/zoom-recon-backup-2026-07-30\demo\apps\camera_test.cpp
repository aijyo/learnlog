// camera_test.cpp — the zlt camera-codec A/B: a natural-ish CAMERA frame (smooth gradients + a soft
// subject blob + textured background — what a webcam produces) encoded+decoded three ways at the same
// bitrate, reporting luma PSNR and coded size:
//   1) H.264 baseline (minih264)   — the old stand-in (no CABAC, 4x4 transforms only)
//   2) H.264 High     (libx264)    — the real zlt codec family (CABAC + 8x8 + adaptive QP)
//   3) H.265/HEVC     (libx265)    — zlt's other codec, newer tools
// Higher PSNR / smaller size = the real codec is better. This is the evidence that swapping minih264
// baseline for libx264/libx265 (what zlt actually wraps) is a real upgrade, not cosmetic.
#include "encode/vp9_screen.hpp"          // screen_codec factory (H264/H265 -> zlt libx264/libx265)
#include "encode/h264_encoder.hpp"        // minih264 baseline
#include "encode/h264_decode_verify.hpp"  // H264Decoder + PsnrY
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <cmath>
#include <cstdio>
#include <vector>

using namespace avp;

// a webcam-like frame: vignette-lit background gradient, a soft elliptical "subject", and fine texture.
static VideoFrame make_camera(int w, int h) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA; f.data.resize((size_t)w * h * 4);
  double cx = w * 0.5, cy = h * 0.45, rx = w * 0.22, ry = h * 0.34;
  uint32_t r = 0x777;
  auto rnd = [&]{ r = r * 1664525u + 1013904223u; return (int)((r >> 16) & 0x1F) - 15; };
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    double bg = 60 + 40 * (1.0 - std::hypot((x - w * 0.5) / (w * 0.7), (y - h * 0.5) / (h * 0.7)));  // vignette
    double dx = (x - cx) / rx, dy = (y - cy) / ry, d = dx * dx + dy * dy;
    double v = bg;
    if (d < 1.0) { double s = 1.0 - d; v = 150 + 60 * s + rnd(); }   // subject with skin-ish tone + texture
    else v += rnd() * 0.5;
    uint8_t g = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v);
    uint8_t* p = &f.data[((size_t)y * w + x) * 4];
    p[0] = (uint8_t)(g * 0.8); p[1] = g; p[2] = (uint8_t)(g < 235 ? g + 20 : 255); p[3] = 255;   // warm
  }
  return f;
}

static const int W = 1280, H = 720, FPS = 15, KBPS = 1500, FRAMES = 8;

static void run_screen(ScreenCodec codec, const char* label, const I420Image& src) {
  auto enc = MakeScreenEncoder(codec); auto dec = MakeScreenDecoder(codec);
  ScreenEncParams sp; sp.width = W; sp.height = H; sp.fps = FPS; sp.kbps = KBPS; sp.gop = 1000; sp.screen_content = false;
  if (!enc || !enc->open(sp) || !dec->open()) { std::printf("  %-32s (unavailable)\n", label); return; }
  double psnr = 0; int bytes = 0;
  for (int i = 0; i < FRAMES; ++i) {
    std::vector<uint8_t> au; bool key = false; enc->encode(src, i == 0, au, key);
    I420Image out; bool ok = !au.empty() && dec->decode(au, out);
    psnr = ok ? PsnrY(src, out) : 0; if ((int)au.size()) bytes = (int)au.size();
  }
  std::printf("  %-32s  %6.2f dB   %7.1f KB\n", label, psnr, bytes / 1024.0);
}

int main() {
  VideoFrame cam = make_camera(W, H);
  I420Image src; BgraToI420(cam, src);
  std::printf("\n  CAMERA-content codec A/B  (%dx%d, %d kbps, steady-state frame)\n", W, H, KBPS);
  std::printf("  codec                             luma PSNR    coded size\n");
  std::printf("  ----------------------------------------------------------\n");
  // minih264 baseline
  {
    VideoEncoderConfig ec; ec.width = W; ec.height = H; ec.fps = FPS; ec.bitrate_bps = KBPS * 1000;
    ec.temporal_layers = 1; ec.layered_refs = false; ec.gop = 1000;
    H264Encoder enc; enc.open(ec); H264Decoder dec; dec.open();
    double psnr = 0; int bytes = 0;
    for (int i = 0; i < FRAMES; ++i) { EncodedFrame ef = enc.encode(src, i == 0); I420Image out; bool ok = dec.decode(ef.data, out); psnr = ok ? PsnrY(src, out) : 0; if (ef.size()) bytes = ef.size(); }
    std::printf("  %-32s  %6.2f dB   %7.1f KB\n", "H.264 baseline (minih264)", psnr, bytes / 1024.0);
  }
  run_screen(ScreenCodec::H264, "H.264 High (libx264 — zlt)", src);
  run_screen(ScreenCodec::H265, "H.265/HEVC (libx265 — zlt)", src);
  std::printf("  ----------------------------------------------------------\n\n");
  return 0;
}
