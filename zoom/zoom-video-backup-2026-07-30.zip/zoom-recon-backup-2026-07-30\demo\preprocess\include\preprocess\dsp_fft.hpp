// dsp_fft.hpp — compact iterative radix-2 Cooley–Tukey FFT (standard algorithm) used by the
// noise-suppression stage. Real-only helper; no external DSP library. Size must be a power of two.
#pragma once
#include <cmath>
#include <cstddef>
#include <vector>

namespace avp::dsp {

struct Complex { float re = 0, im = 0; };

// in-place FFT (sign=-1) / IFFT (sign=+1, unnormalized). x.size() must be a power of two.
inline void fft(std::vector<Complex>& x, int sign) {
  const size_t n = x.size();
  if (n < 2) return;
  // bit-reversal permutation
  for (size_t i = 1, j = 0; i < n; ++i) {
    size_t bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) { Complex t = x[i]; x[i] = x[j]; x[j] = t; }
  }
  const double PI = 3.14159265358979323846;
  for (size_t len = 2; len <= n; len <<= 1) {
    double ang = sign * 2.0 * PI / (double)len;
    Complex wl{ (float)std::cos(ang), (float)std::sin(ang) };
    for (size_t i = 0; i < n; i += len) {
      Complex w{ 1.0f, 0.0f };
      for (size_t k = 0; k < len / 2; ++k) {
        Complex a = x[i + k];
        Complex b = x[i + k + len / 2];
        Complex bw{ b.re * w.re - b.im * w.im, b.re * w.im + b.im * w.re };
        x[i + k]           = { a.re + bw.re, a.im + bw.im };
        x[i + k + len / 2] = { a.re - bw.re, a.im - bw.im };
        Complex nw{ w.re * wl.re - w.im * wl.im, w.re * wl.im + w.im * wl.re };
        w = nw;
      }
    }
  }
}

inline size_t next_pow2(size_t v) { size_t p = 1; while (p < v) p <<= 1; return p; }

}  // namespace avp::dsp
