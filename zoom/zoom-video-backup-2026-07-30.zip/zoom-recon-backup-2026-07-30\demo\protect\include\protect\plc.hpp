// plc.hpp — module 4 packet-loss concealment (AV_PIPELINE_DETAILS.html §4): the last-resort when
// neither FEC nor NACK recovered a frame. Zero delay, zero bandwidth — the receiver *fabricates* a
// plausible substitute. Classic (non-neural) concealment is implemented here; DRED (neural PLC in the
// Opus build) is a trained-weight boundary (⛔W) exposed as an injection hook.
#pragma once
#include "preprocess/video_convert.hpp"   // avp::I420Image
#include <cstdint>
#include <vector>

namespace avp {

// Audio PLC: on a lost frame, extrapolate from the last good frame — repeat with attenuation that
// deepens over consecutive losses (avoids a hard cut / buzzy sustain). Real, classic concealment.
class AudioPlc {
public:
  void push_good(const std::vector<float>& frame) { last_ = frame; consecutive_ = 0; }
  std::vector<float> conceal() {
    ++consecutive_;
    std::vector<float> out(last_.size(), 0.f);
    float g = 1.0f; for (int i = 0; i < consecutive_; ++i) g *= 0.6f;   // 0.6^n fade
    for (size_t i = 0; i < last_.size(); ++i) out[i] = last_[i] * g;
    // gentle fade across the frame too, so repeated conceals decay smoothly
    for (size_t i = 0; i < out.size(); ++i) out[i] *= 1.0f - 0.3f * (float)i / (out.size() ? out.size() : 1);
    return out;
  }
  int consecutive() const { return consecutive_; }
private:
  std::vector<float> last_; int consecutive_ = 0;
};

// Neural PLC (Opus DRED) = ⛔W boundary. Inject a real model to replace the classic extrapolation.
struct INeuralPlc {
  virtual ~INeuralPlc() = default;
  virtual std::vector<float> conceal(const std::vector<std::vector<float>>& recent, int sample_rate) = 0;
};

// Video PLC: freeze — reuse the last decoded frame until a fresh (key or recovered) frame arrives.
class VideoPlc {
public:
  void push_good(const I420Image& f) { last_ = f; frozen_ = 0; }
  const I420Image& conceal() { ++frozen_; return last_; }   // display the last good frame again
  int frozen() const { return frozen_; }
  bool has_reference() const { return last_.valid(); }
private:
  I420Image last_; int frozen_ = 0;
};

}  // namespace avp
