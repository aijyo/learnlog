// raisr_train_matched.cpp — RAISR trainer whose DEGRADATION MODEL MATCHES the demo's real receive path.
//
// The receiver's super-res must undo exactly what the send->wire->decode chain did to the picture:
//     HR --(bicubic Catmull-Rom 2x downscale = zlt.dll ns_vpp kernel, apps/resample.hpp)--> LR_clean
//         --(VP9 screen-content encode -> decode, one keyframe)-------------------------->  LR
// so THIS trainer builds its low-res training inputs the same way, and RAISR learns to invert BOTH the
// downscale blur AND the codec's compression artifacts (block/ringing). raisr_train.cpp instead used a
// 2x2 BOX downscale and NO codec — a degradation the receiver never actually sees, so its bank inverts
// the wrong thing. To prove the point this run trains BOTH banks (box vs matched) and scores them on the
// SAME real (matched) degradation; matched should win.
//
// structure/classify/apply = recon/zlt_raisr.hpp ; bicubic = recon/zlt_resample.hpp ; codec = the demo's
// IScreenEncoder/Decoder (encode/screen_codec.hpp, VP9 screen tune). Weights are OURS (⛔W), x8 aug.
#include "zlt_raisr.hpp"
#include "zlt_resample.hpp"
#include "encode/screen_codec.hpp"
#include "encode/vp9_screen.hpp"
#include "preprocess/video_convert.hpp"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
#include <functional>
using std::vector;
using namespace recon::zlt;

static RaisrConfig CFG;   // scale=2, patch=11 (recovered structure)

// ------------------------------------------------------------------ synth / io ---------------------------
// Clean SHARP training image (rects + thin oriented strokes + circles on a smooth bg, NO noise): teaches
// the filters to SHARPEN the edge a cheap upscale blurs, instead of learning to smooth sensor noise.
static void makeSynthHR(vector<float>& Y, int W, int H, uint32_t seed) {
    Y.assign((size_t)W*H, 0.f);
    for (int y=0;y<H;++y) for (int x=0;x<W;++x) Y[(size_t)y*W+x] = 55.f + 90.f*x/W + 45.f*y/H;
    uint32_t s = seed*2654435761u + 12345u;
    auto rnd = [&](float a,float b){ s=s*1664525u+1013904223u; return a+(b-a)*((s>>8)*(1.0f/16777216.0f)); };
    auto put = [&](int x,int y,float v){ if(x>=0&&x<W&&y>=0&&y<H) Y[(size_t)y*W+x]=v; };
    for (int k=0;k<600;++k) {
        int type=(int)rnd(0,3); float val=rnd(8,247);
        if (type==0) { int rx=(int)rnd(0,W),ry=(int)rnd(0,H),rw=(int)rnd(3,55),rh=(int)rnd(3,55);
            for(int y=ry;y<ry+rh;++y) for(int x=rx;x<rx+rw;++x) put(x,y,val); }
        else if (type==1) { float ang=rnd(0,3.14159f),len=rnd(15,110),cx=rnd(0,W),cy=rnd(0,H),th=rnd(0.6f,2.2f);
            float dx=std::cos(ang),dy=std::sin(ang);
            for(float t=-len/2;t<len/2;t+=0.5f) for(float w=-th;w<=th;w+=0.5f) put((int)(cx+t*dx-w*dy),(int)(cy+t*dy+w*dx),val); }
        else { float cx=rnd(0,W),cy=rnd(0,H),rr=rnd(3,28);
            for(int y=(int)(cy-rr);y<=cy+rr;++y) for(int x=(int)(cx-rr);x<=cx+rr;++x)
                if ((x-cx)*(x-cx)+(y-cy)*(y-cy)<=rr*rr) put(x,y,val); }
    }
    for (auto& v:Y) v = v<0?0:(v>255?255:v);
}
static bool loadBMPLuma(const char* path, vector<float>& Y, int& W, int& H) {
    FILE* f=fopen(path,"rb"); if(!f) return false; uint8_t h[54];
    if (fread(h,1,54,f)!=54||h[0]!='B'||h[1]!='M'){fclose(f);return false;}
    int w=*(int*)(h+18),hh=*(int*)(h+22); uint16_t bpp=*(uint16_t*)(h+28); uint32_t off=*(uint32_t*)(h+10);
    if (bpp!=32){fclose(f);return false;} bool up=hh>0; int ah=hh>0?hh:-hh; fseek(f,off,SEEK_SET);
    vector<uint8_t> row((size_t)w*4); Y.assign((size_t)w*ah,0.f); W=w; H=ah;
    for (int r=0;r<ah;++r){ if(fread(row.data(),1,row.size(),f)!=row.size()){fclose(f);return false;}
        int y=up?(ah-1-r):r; for(int x=0;x<w;++x) Y[(size_t)y*w+x]=0.299f*row[x*4+2]+0.587f*row[x*4+1]+0.114f*row[x*4+0]; }
    fclose(f); return true;
}
static void transformHR(const vector<float>& S,int W,int H,int t,vector<float>& D,int& dW,int& dH){
    bool tr=t&1,fx=(t>>1)&1,fy=(t>>2)&1; dW=tr?H:W; dH=tr?W:H; D.assign((size_t)dW*dH,0.f);
    for(int y=0;y<dH;++y) for(int x=0;x<dW;++x){ int sx=tr?y:x,sy=tr?x:y; if(fx)sx=W-1-sx; if(fy)sy=H-1-sy; D[(size_t)y*dW+x]=S[(size_t)sy*W+sx]; }
}
static double psnr(const vector<float>& a,const vector<float>& b,int W,int H){
    const int r=CFG.patch/2; double se=0; long n=0;
    for(int y=r;y<H-r;++y) for(int x=r;x<W-r;++x){ double d=a[(size_t)y*W+x]-b[(size_t)y*W+x]; se+=d*d; ++n; }
    double mse=se/std::max(1L,n); return mse<1e-9?99.0:10.0*log10(255.0*255.0/mse);
}

// ------------------------------------------------------------------ degradation models -------------------
// LR = 2x2 BOX average (raisr_train.cpp's model — the WRONG one; kept only for the A/B).
static void degrade_box(const vector<float>& HR,int W,int H,vector<float>& LR,int& lw,int& lh){
    lw=W/2; lh=H/2; LR.assign((size_t)lw*lh,0.f);
    for(int y=0;y<lh;++y) for(int x=0;x<lw;++x)
        LR[(size_t)y*lw+x]=0.25f*(HR[(size_t)(2*y)*W+2*x]+HR[(size_t)(2*y)*W+2*x+1]+HR[(size_t)(2*y+1)*W+2*x]+HR[(size_t)(2*y+1)*W+2*x+1]);
}
// codec round-trip on a luma plane: build I420 (Y=luma, UV neutral), VP9-screen encode ONE keyframe, decode,
// return the decoded luma — i.e. the frame WITH real compression artifacts, exactly as the receiver sees it.
static avp::ScreenCodec g_codec = avp::ScreenCodec::VP9; static int g_kbps = 2500, g_qmax = 40;
static bool codecRoundtrip(const vector<float>& in,int w,int h,vector<float>& out){
    avp::I420Image img; img.w=w; img.h=h; img.y.resize((size_t)w*h);
    for(size_t i=0;i<img.y.size();++i){ float v=in[i]; img.y[i]=(uint8_t)(v<0?0:(v>255?255:v+0.5f)); }
    int cw=(w+1)/2,ch=(h+1)/2; img.u.assign((size_t)cw*ch,128); img.v.assign((size_t)cw*ch,128);
    auto enc=avp::MakeScreenEncoder(g_codec); if(!enc) return false;
    avp::ScreenEncParams p; p.width=w; p.height=h; p.fps=8; p.kbps=g_kbps; p.gop=1; p.screen_content=true; p.qmax=g_qmax;
    if(!enc->open(p)) return false;
    std::vector<uint8_t> au; bool key=false;
    if(!enc->encode(img,true,au,key)||au.empty()) return false;
    auto dec=avp::MakeScreenDecoder(g_codec); if(!dec||!dec->open()) return false;
    avp::I420Image o; if(!dec->decode(au,o)||!o.valid()) return false;
    out.assign((size_t)w*h,0.f);
    for(int y=0;y<h&&y<o.h;++y) for(int x=0;x<w&&x<o.w;++x) out[(size_t)y*w+x]=(float)o.y[(size_t)y*o.w+x];
    return true;
}
// LR = bicubic Catmull-Rom 2x downscale (the real sender kernel) + codec round-trip (the real wire).
static bool degrade_matched(const vector<float>& HR,int W,int H,vector<float>& LR,int& lw,int& lh){
    lw=W/2; lh=H/2; vector<float> clean((size_t)lw*lh,0.f);
    zlt::resample::ResizePlane(HR.data(),W,H,W, clean.data(),lw,lh,lw);   // bicubic 2x down
    return codecRoundtrip(clean,lw,lh,LR);                                // + VP9 encode/decode
}

// ------------------------------------------------------------------ training core ------------------------
using Degrader = std::function<bool(const vector<float>&,int,int,vector<float>&,int&,int&)>;
struct Base { vector<float> HR,B,LR; int W,H,lW,lH; bool ok; };
static Base makeBase(const vector<float>& src,int sW,int sH,const Degrader& deg){
    Base r; r.W=sW&~1; r.H=sH&~1; r.ok=false;
    r.HR.assign((size_t)r.W*r.H,0.f);
    for(int y=0;y<r.H;++y) for(int x=0;x<r.W;++x) r.HR[(size_t)y*r.W+x]=src[(size_t)y*sW+x];
    if(!deg(r.HR,r.W,r.H,r.LR,r.lW,r.lH)) return r;
    RaisrUpscaler(CFG,nullptr).UpscaleF(r.LR.data(),r.lW,r.lH,r.B,r.W,r.H);   // bilinear base (== apply path)
    r.ok=true; return r;
}
static bool solveSPD(vector<double>& A,vector<double>& b,int n){
    for(int i=0;i<n;++i) for(int j=0;j<=i;++j){ double s=A[(size_t)i*n+j]; for(int k=0;k<j;++k) s-=A[(size_t)i*n+k]*A[(size_t)j*n+k];
        if(i==j){ if(s<=0) return false; A[(size_t)i*n+i]=sqrt(s);} else A[(size_t)i*n+j]=s/A[(size_t)j*n+j]; }
    for(int i=0;i<n;++i){ double s=b[i]; for(int k=0;k<i;++k) s-=A[(size_t)i*n+k]*b[k]; b[i]=s/A[(size_t)i*n+i]; }
    for(int i=n-1;i>=0;--i){ double s=b[i]; for(int k=i+1;k<n;++k) s-=A[(size_t)k*n+i]*b[k]; b[i]=s/A[(size_t)i*n+i]; }
    return true;
}
struct Accum { vector<double> ATA,ATb; vector<long> pop; };
static void accumInto(Accum& ac,const Base& im){
    const int W=im.W,H=im.H,r=CFG.patch/2,TAPS=CFG.Taps(),NB=CFG.Buckets(); vector<float> patch(TAPS);
    for(int y=r;y<H-r;++y) for(int x=r;x<W-r;++x){
        int b=Classify(im.B.data(),W,H,x,y,CFG); int p=PhaseOf(x,y,CFG.scale);
        int k=0; for(int j=-r;j<=r;++j) for(int i=-r;i<=r;++i) patch[k++]=im.B[(size_t)(y+j)*W+(x+i)];
        double t=im.HR[(size_t)y*W+x]; size_t base=((size_t)p*NB+b);
        double* A=&ac.ATA[base*TAPS*TAPS]; double* Bv=&ac.ATb[base*TAPS];
        for(int rr=0;rr<TAPS;++rr){ double pr=patch[rr]; Bv[rr]+=pr*t; double* Ar=A+(size_t)rr*TAPS; for(int c=rr;c<TAPS;++c) Ar[c]+=pr*patch[c]; }
        ac.pop[base]++;
    }
}
static void solveBank(Accum& ac,vector<float>& bank){
    const int TAPS=CFG.Taps(),NB=CFG.Buckets(),NP=CFG.Phases();
    bank.assign((size_t)NP*NB*TAPS,0.f); vector<double> A((size_t)TAPS*TAPS),bb(TAPS); int solved=0,fell=0;
    for(int p=0;p<NP;++p) for(int b=0;b<NB;++b){ size_t base=((size_t)p*NB+b); float* out=&bank[base*TAPS];
        if(ac.pop[base]<TAPS+30){ out[TAPS/2]=1.f; ++fell; continue; }
        double* srcA=&ac.ATA[base*TAPS*TAPS]; double* srcb=&ac.ATb[base*TAPS];
        double diag=0; for(int i=0;i<TAPS;++i) diag+=srcA[(size_t)i*TAPS+i]; diag/=TAPS; double lam=1e-3*diag+1e-6;
        for(int rr=0;rr<TAPS;++rr){ bb[rr]=srcb[rr]; for(int c=0;c<TAPS;++c) A[(size_t)rr*TAPS+c]=(c>=rr?srcA[(size_t)rr*TAPS+c]:srcA[(size_t)c*TAPS+rr]); A[(size_t)rr*TAPS+rr]+=lam; }
        if(solveSPD(A,bb,TAPS)){ double s=0; for(int i=0;i<TAPS;++i) s+=bb[i]; if(s>0.5) for(int i=0;i<TAPS;++i) bb[i]/=s;
            for(int i=0;i<TAPS;++i) out[i]=(float)bb[i]; ++solved; } else { out[TAPS/2]=1.f; ++fell; }
    }
    std::printf("    trained %d/%d filters (%d passthrough)\n",solved,NP*NB,fell);
}
static vector<float> trainBank(const vector<float>& hrSrc,int W,int H,const Degrader& deg,const char* tag){
    const int TAPS=CFG.Taps(),NB=CFG.Buckets(),NP=CFG.Phases();
    Accum ac; ac.ATA.assign((size_t)NP*NB*TAPS*TAPS,0.0); ac.ATb.assign((size_t)NP*NB*TAPS,0.0); ac.pop.assign((size_t)NP*NB,0);
    std::printf("  [%s] accumulating 8-fold augmented normal equations...\n",tag);
    for(int t=0;t<8;++t){ vector<float> hr; int tW,tH; transformHR(hrSrc,W,H,t,hr,tW,tH); Base im=makeBase(hr,tW,tH,deg); if(im.ok) accumInto(ac,im); }
    vector<float> bank; solveBank(ac,bank); return bank;
}

int main(int argc,char** argv){
    CFG.scale=2; CFG.patch=11;
    for(int i=1;i<argc;++i){ if(!strcmp(argv[i],"--codec")&&i+1<argc) g_codec=avp::ParseScreenCodec(argv[++i]);
        else if(!strcmp(argv[i],"--kbps")&&i+1<argc) g_kbps=atoi(argv[++i]);
        else if(!strcmp(argv[i],"--qmax")&&i+1<argc) g_qmax=atoi(argv[++i]); }
    const int TAPS=CFG.Taps(),NB=CFG.Buckets(),NP=CFG.Phases();
    std::printf("\n  RAISR MATCHED-degradation trainer (2x, %d buckets x %d phases, %d taps)\n",NB,NP,TAPS);
    std::printf("  degradation = bicubic-2x-down + %s encode/decode (kbps=%d qmax=%d)  vs  box-2x (A/B)\n",
                avp::ScreenCodecName(g_codec),g_kbps,g_qmax);

    const int SW=768,SH=768;
    vector<float> leftHR,rightHR; makeSynthHR(leftHR,SW,SH,1); makeSynthHR(rightHR,SW,SH,2);
    Degrader dBox=[&](const vector<float>& hr,int W,int H,vector<float>& lr,int& lw,int& lh){ degrade_box(hr,W,H,lr,lw,lh); return true; };
    Degrader dMatch=[&](const vector<float>& hr,int W,int H,vector<float>& lr,int& lw,int& lh){ return degrade_matched(hr,W,H,lr,lw,lh); };

    // Classify thresholds from the MATCHED-degraded train base (same bucketing for both banks -> fair A/B).
    Base tr0=makeBase(leftHR,SW,SH,dMatch);
    if(!tr0.ok){ std::printf("  ERROR: codec round-trip failed (is the VP9/FFmpeg backend built?)\n"); return 2; }
    { vector<float> strg; strg.reserve(300000);
      for(int y=CFG.patch/2;y<tr0.H-CFG.patch/2;y+=2) for(int x=CFG.patch/2;x<tr0.W-CFG.patch/2;x+=2){ double s; Classify(tr0.B.data(),tr0.W,tr0.H,x,y,CFG,&s); strg.push_back((float)s); }
      std::sort(strg.begin(),strg.end()); CFG.flat_thresh=strg[(size_t)(strg.size()*0.12)]; CFG.str_thresh=strg[(size_t)(strg.size()*0.55)]; }
    std::printf("  data-driven thresholds (from matched base): flat<%.2f, strength-split=%.2f\n",CFG.flat_thresh,CFG.str_thresh);

    vector<float> boxBank   = trainBank(leftHR,SW,SH,dBox,  "box   ");
    vector<float> matchBank = trainBank(leftHR,SW,SH,dMatch,"matched");

    // save the MATCHED bank as the canonical bank (the receive-side super-res in point 3 loads this).
    const char* bankPath="D:/code/work/bin2cpp-output/recon/raisr_bank.bin";
    if(FILE* bf=fopen(bankPath,"wb")){ int hdr[4]={NP,NB,TAPS,CFG.patch}; float th[2]={CFG.flat_thresh,CFG.str_thresh};
        fwrite(hdr,sizeof(int),4,bf); fwrite(th,sizeof(float),2,bf); fwrite(matchBank.data(),sizeof(float),matchBank.size(),bf); fclose(bf);
        std::printf("  saved MATCHED bank -> recon/raisr_bank.bin\n"); }

    // ---- A/B: score bilinear / box-RAISR / matched-RAISR ALL on the real (matched) degradation ----
    auto bankToFB=[&](const vector<float>& bank){ TrainedFilterBank fb; fb.fromMemory(NP,NB,TAPS,CFG.patch,CFG.flat_thresh,CFG.str_thresh,bank); return fb; };
    TrainedFilterBank fbBox=bankToFB(boxBank), fbMatch=bankToFB(matchBank);
    auto evalOn=[&](const Base& im,const char* tag){
        RaisrConfig c1=CFG; fbBox.fill(c1);   RaisrUpscaler upBox(c1,&fbBox);
        RaisrConfig c2=CFG; fbMatch.fill(c2); RaisrUpscaler upMatch(c2,&fbMatch);
        vector<float> oB,oM; int ow,oh; upBox.UpscaleF(im.LR.data(),im.lW,im.lH,oB,ow,oh); upMatch.UpscaleF(im.LR.data(),im.lW,im.lH,oM,ow,oh);
        double pBil=psnr(im.B,im.HR,im.W,im.H), pBox=psnr(oB,im.HR,im.W,im.H), pM=psnr(oM,im.HR,im.W,im.H);
        std::printf("  %-24s bilinear=%.3f  box-RAISR=%.3f (%+.3f)  MATCHED-RAISR=%.3f (%+.3f)\n",
                    tag,pBil,pBox,pBox-pBil,pM,pM-pBil);
        return pM-pBox;
    };
    std::printf("  ----------------------------------------------------------------------------------------\n");
    std::printf("  A/B on the REAL (matched) degradation — bicubic-down + %s round-trip:\n",avp::ScreenCodecName(g_codec));
    Base te=makeBase(rightHR,SW,SH,dMatch);
    double adv=evalOn(te,"HELD-OUT synth:");
    evalOn(tr0,"(train synth:");
    { vector<float> cam; int cW,cH; if(loadBMPLuma("D:/code/work/av-pipeline/camera_frame0.bmp",cam,cW,cH)){ Base cb=makeBase(cam,cW,cH,dMatch); if(cb.ok) evalOn(cb,"(real camera x-domain:"); } }
    std::printf("  => matched-degradation training is %+.3f dB vs box-degradation training on the real chain%s\n",
                adv, adv>0?" (WINS)":"");
    return adv>0?0:1;
}
