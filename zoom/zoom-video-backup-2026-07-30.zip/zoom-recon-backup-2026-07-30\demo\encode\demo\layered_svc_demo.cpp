// layered_svc_demo.cpp — proves the temporal layers are REALLY droppable, not just annotated (§3.2).
// Encodes a GOP with the layered-reference structure (t2 frames reference lower layers and are marked
// droppable / non-reference), then decodes SUB-STREAMS with the high layers removed:
//   * full stream (all frames)         -> baseline
//   * t<=1 sub-stream (drop every t2)   -> 15 fps, MUST still decode (references intact)
//   * t<=0 sub-stream (drop t1 and t2)  -> 7.5 fps, MUST still decode
// and contrasts with a plain (annotated, non-layered) stream where dropping the same frames breaks
// decoding (dangling references / frame_num gaps). Needs AVP_WITH_FFMPEG for the real decoder.
#include "encode/h264_encoder.hpp"
#include "encode/svc_layers.hpp"
#ifdef AVP_WITH_FFMPEG
#include "encode/h264_decode_verify.hpp"
#endif
#include <cstdint>
#include <cstdio>
#include <vector>

using namespace avp;

static I420Image grad(int w, int h, int t) {
  I420Image im; im.w = w; im.h = h;
  im.y.assign((size_t)w * h, 0); im.u.assign((size_t)im.cw() * im.ch(), 128); im.v.assign((size_t)im.cw() * im.ch(), 128);
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) im.y[(size_t)y * w + x] = (uint8_t)((x + y + t * 6) & 0xFF);
  return im;
}

static std::vector<EncodedFrame> encode_seq(bool layered, const std::vector<I420Image>& srcs, int W, int H) {
  VideoEncoderConfig c; c.width = W; c.height = H; c.fps = 30; c.bitrate_bps = 1200000; c.gop = 300;
  c.temporal_layers = 3; c.layered_refs = layered;
  H264Encoder enc; enc.open(c);
  std::vector<EncodedFrame> out;
  for (auto& s : srcs) out.push_back(enc.encode(s));
  return out;
}

#ifdef AVP_WITH_FFMPEG
struct DecRes { int out = 0; double psnr = 0; };
static DecRes decode_subset(const std::vector<EncodedFrame>& fr, const std::vector<int>& idx, const std::vector<I420Image>& srcs) {
  H264Decoder d; if (!d.open()) return {};
  DecRes r; double psum = 0; int pn = 0;
  for (int i : idx) {
    I420Image o;
    if (d.decode(fr[i].data, o) && o.w > 0) { ++r.out; double p = PsnrY(srcs[i], o); if (p > 0) { psum += p; ++pn; } }
  }
  r.psnr = pn ? psum / pn : 0;
  return r;
}
#endif

int main() {
  std::printf("=== layered-reference temporal SVC: really-droppable layers ===\n\n");
  const int W = 320, H = 240, N = 24;
  std::vector<I420Image> srcs; for (int i = 0; i < N; ++i) srcs.push_back(grad(W, H, i));

  // reference plan (what each frame points at)
  LayeredRefScheduler sched(3); TemporalLayering tl{3};
  std::printf("reference plan (LTR slot 1 = t0 anchor, slot 2 = t1 anchor):\n");
  for (int i = 0; i < 8; ++i) {
    RefPlan p = sched.next(i);
    std::printf("   f%-2d t%d  use=%-2d update=%-2d %s\n", i, p.temporal_id, p.ltr_use, p.ltr_update,
                p.droppable ? "DROPPABLE" : (i == 0 ? "IDR" : "reference"));
  }
  std::printf("\n");

  auto layered = encode_seq(true, srcs, W, H);
  std::vector<int> all, le1, le0;
  for (int i = 0; i < N; ++i) { all.push_back(i); if (tl.temporal_id(i) <= 1) le1.push_back(i); if (tl.temporal_id(i) == 0) le0.push_back(i); }
  std::printf("encoded %d frames (layered). sub-streams: full=%zu, t<=1=%zu (15fps), t<=0=%zu (7.5fps)\n\n",
              N, all.size(), le1.size(), le0.size());

#ifdef AVP_WITH_FFMPEG
  int fail = 0;
  DecRes f_all = decode_subset(layered, all, srcs);
  DecRes f_le1 = decode_subset(layered, le1, srcs);
  DecRes f_le0 = decode_subset(layered, le0, srcs);
  std::printf("LAYERED decode:\n");
  std::printf("   full  : %2d/%zu frames, PSNR %.1f dB\n", f_all.out, all.size(), f_all.psnr);
  std::printf("   t<=1  : %2d/%zu frames, PSNR %.1f dB  %s\n", f_le1.out, le1.size(), f_le1.psnr,
              (f_le1.out == (int)le1.size() && f_le1.psnr > 28) ? "OK (droppable layer really dropped)" : (++fail, "FAIL"));
  std::printf("   t<=0  : %2d/%zu frames, PSNR %.1f dB  %s\n\n", f_le0.out, le0.size(), f_le0.psnr,
              (f_le0.out == (int)le0.size() && f_le0.psnr > 28) ? "OK" : (++fail, "FAIL"));

  // contrast: annotated (non-layered) stream, drop the same t2 frames
  auto plain = encode_seq(false, srcs, W, H);
  DecRes p_le1 = decode_subset(plain, le1, srcs);
  std::printf("NON-LAYERED (annotated) decode, same t<=1 subset:\n");
  std::printf("   t<=1  : %2d/%zu frames, PSNR %.1f dB  %s\n\n", p_le1.out, le1.size(), p_le1.psnr,
              (p_le1.out < (int)le1.size() || p_le1.psnr < f_le1.psnr - 5) ? "as expected: dropping frames breaks it" : "(decoder concealed it)");

  std::printf("conclusion: layered refs make t2 truly droppable (%s); annotation alone does %s\n",
              f_le1.psnr > 28 ? "sub-stream decodes clean" : "?",
              (p_le1.out < (int)le1.size() || p_le1.psnr < f_le1.psnr - 5) ? "NOT (breaks on drop)" : "concealed");
  std::printf(fail ? "\nSOME CHECKS FAILED (%d)\n" : "\nALL PASS (real droppable temporal layers)\n", fail);
  return fail ? 1 : 0;
#else
  std::printf("(build -DAVP_WITH_FFMPEG=ON to decode the sub-streams and prove droppability)\n");
  return 0;
#endif
}
