# find functions that xref given addresses, decompile them. ARGV[1]=out, ARGV[2..]=hex target addrs
import idc, ida_hexrays, ida_funcs, idautils
out = idc.ARGV[1]; targets = [int(a, 16) for a in idc.ARGV[2:]]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []; funcs = []
for t in targets:
    refs = [x.frm for x in idautils.XrefsTo(t, 0)]
    L.append("// xrefs to 0x%x: %s" % (t, ", ".join("0x%x(%s)" % (r, idc.get_func_name(r)) for r in refs)))
    for r in refs:
        f = idc.get_func_attr(r, idc.FUNCATTR_START)
        if f != idc.BADADDR and f not in funcs: funcs.append(f)
def decomp(ea):
    try:
        L.append("\n// ===== %s (0x%x) =====" % (idc.get_func_name(ea), ea))
        L.append(str(ida_hexrays.decompile(ea)))
    except Exception as e: L.append("// FAIL 0x%x: %s" % (ea, e))
for f in funcs[:6]: decomp(f)
open(out, "w", encoding="utf-8", errors="replace").write("\n".join(L))
idc.qexit(0)
