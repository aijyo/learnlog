# Reusable headless IDA runner against the pre-built zlt.dll.i64 (reuse mode, ~1-6s).
# Usage: powershell -f _runida.ps1 <script.py> <out.txt> [extra args...]
param([string]$Script, [string]$Out, [string]$Idb = "", [Parameter(ValueFromRemainingArguments=$true)]$Rest)
$ida = "D:\solft\IDA Pro 7.5.20.1028 SP3 Portable + All decompilers (Windows)\IDA Pro 7.5.20.1028 SP3 Portable\idat64.exe"
$idb = if ($Idb) { $Idb } else { "C:\Users\NCCTEC~1\AppData\Local\Temp\claude\D--code-work-planet-kit-windows-6-0-2\03fbbd4c-fd81-4fe9-b671-c2fa940fa32d\scratchpad\zlt\zlt.dll.i64" }
$py  = "C:\Users\CT10266\AppData\Local\Programs\Python\Python39"
$log = "$env:TEMP\_ida_run.log"
$env:PYTHONHOME = $py
$env:PATH = "$py;$py\DLLs;" + $env:PATH
$env:_NT_SYMBOL_PATH = $env:TEMP
$sarg = ($Script + " " + $Out + " " + ($Rest -join " ")).Trim()
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $ida
$psi.Arguments = '-A -S"' + $sarg + '" -L"' + $log + '" "' + $idb + '"'
$psi.UseShellExecute = $false
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
Write-Host "ARGS: $($psi.Arguments)"
$p = [System.Diagnostics.Process]::Start($psi)
$p.WaitForExit()
Write-Host "exit=$($p.ExitCode)"
if (Test-Path $Out) { Write-Host "OK -> $Out ($((Get-Item $Out).Length) bytes)" } else { Write-Host "NO OUTPUT"; Get-Content $log -Tail 15 }
