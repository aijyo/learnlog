// denoise_ghost_test.cpp — proves the camera denoise removes noise WITHOUT ghosting. A synthetic
// sequence (gray background + a bright block sweeping across + fresh per-frame noise) is denoised two
// ways and compared to the clean (noise-free) truth:
//   A) plain zlt IIR (out = 0.37*in + 0.63*prev)  — the verified Zoom classic path
//   B) motion-adaptive spatial-temporal (mc_denoise) — temporal on static, spatial on motion
// Two metrics (luma, mean |denoised − clean|):
//   * noise error on a STATIC background patch  -> both should be LOW (both denoise static well)
//   * ghost error on the VACATED strip the block just left -> IIR HIGH (trail), motion-adaptive LOW.
#include "preprocess/video_preprocess.hpp"
#include "capture/video_frame.hpp"
#include <cstdio>
#include <cmath>
#include <vector>

using namespace avp;

static const int W = 640, H = 360, N = 24, STEP = 22, BW = 90, BH = 120, BG = 128, FG = 225, NOISE = 16;
static const int BY = (H - BH) / 2;

// frame t: gray bg + white block at x=t*STEP; `noisy`=with per-pixel noise, `clean`=without.
static void make(int t, VideoFrame& noisy, VideoFrame& clean, uint32_t& rng) {
  noisy.width = clean.width = W; noisy.height = clean.height = H;
  noisy.stride = clean.stride = W * 4; noisy.format = clean.format = PixelFormat::BGRA;
  noisy.data.resize((size_t)W * H * 4); clean.data.resize((size_t)W * H * 4);
  int bx = t * STEP;
  for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
    int base = (x >= bx && x < bx + BW && y >= BY && y < BY + BH) ? FG : BG;
    rng = rng * 1664525u + 1013904223u; int nz = (int)((rng >> 16) % (2 * NOISE + 1)) - NOISE;
    int nv = base + nz; if (nv < 0) nv = 0; if (nv > 255) nv = 255;
    size_t o = ((size_t)y * W + x) * 4;
    clean.data[o] = clean.data[o+1] = clean.data[o+2] = (uint8_t)base; clean.data[o+3] = 255;
    noisy.data[o] = noisy.data[o+1] = noisy.data[o+2] = (uint8_t)nv; noisy.data[o+3] = 255;
  }
}

// mean |denoised_Y − clean_Y| over a rectangle
static double err(const I420Image& den, const VideoFrame& clean, int x0, int y0, int x1, int y1) {
  I420Image c; BgraToI420(clean, c);
  double s = 0; int n = 0;
  for (int y = y0; y < y1; ++y) for (int x = x0; x < x1; ++x) { s += std::abs((int)den.y[(size_t)y*W+x] - (int)c.y[(size_t)y*W+x]); ++n; }
  return n ? s / n : 0;
}

static void run(bool motion_adaptive, const char* label) {
  VideoPreprocessConfig cfg; cfg.denoise = true; cfg.adaptive_qp = false; cfg.raisr = false;
  cfg.denoise_motion_adaptive = motion_adaptive;
  VideoPreprocessor pp(cfg);
  uint32_t rng = 0x1234;
  double noise_e = 0, ghost_e = 0; int cnt = 0;
  for (int t = 0; t < N; ++t) {
    VideoFrame noisy, clean; make(t, noisy, clean, rng);
    VideoPreprocessResult r; pp.Process(noisy, r);
    if (t >= 3) {
      // static bg patch (top-left corner, block never reaches here early)
      noise_e += err(r.frame, clean, 8, 8, 88, 88);
      // ghost strip = the columns the block just VACATED this frame: [ (t-1)*STEP , t*STEP ) at block rows
      int gx0 = (t - 1) * STEP, gx1 = t * STEP;
      ghost_e += err(r.frame, clean, gx0, BY, gx1, BY + BH);
      ++cnt;
    }
  }
  std::printf("  %-38s  static-noise err %5.2f   |   MOVING-EDGE ghost err %6.2f\n",
              label, noise_e / cnt, ghost_e / cnt);
}

int main() {
  std::printf("\n  Denoise ghosting A/B  (%dx%d, block sweeps %d px/frame, noise ±%d; lower = better)\n", W, H, STEP, NOISE);
  std::printf("  --------------------------------------------------------------------------------------\n");
  run(false, "A) plain zlt IIR (0.37/0.63)");
  run(true,  "B) motion-adaptive spatial-temporal");
  std::printf("  --------------------------------------------------------------------------------------\n");
  std::printf("  (both should kill static noise; the ghost column is where IIR trails and B should not)\n\n");
  return 0;
}
