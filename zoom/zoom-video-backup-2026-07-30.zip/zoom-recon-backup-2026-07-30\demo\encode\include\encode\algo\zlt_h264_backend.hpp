// [vendored into av-pipeline module 3 from bin2cpp-output/recon — body-verified clean-room
//  reconstruction of Zoom control surfaces, unchanged except the minih264 include path.]
// zlt_h264_backend.hpp -- OPTION A: drive the reconstructed zlt control layer with a
// REAL H.264 encoder, closing an actual encode loop (pixels -> H.264 Annex-B), the way
// zbt decodes through dav1d. Backend = minih264 (single-header, public-domain/Unlicense
// H.264 baseline encoder) -- no external lib/nasm, MSVC-clean.
//
// This is NOT "zlt's encoder source": the ~96% codec engine is a ⛔K boundary. This maps
// the reconstructed CONTROL calls (ISvcEncoderBackend: config, keyframe/reference requests,
// bitrate) onto a real encoder, and adds the EncodeFrame data path the control ABI lacks.
// Gated behind RECON_WITH_H264.
#pragma once
#if defined(RECON_WITH_H264)
#include "zlt_svc_encoder.hpp"
#include "minih264/minih264e.h"   // declarations; impl in one TU (minih264_impl.cpp)
#include <vector>
#include <cstdint>

namespace recon::zlt {

class H264Backend : public ISvcEncoderBackend {
public:
    // --- reconstructed zlt control ABI (maps config/requests onto the real encoder) ---
    int ApplyConfig(const EncodeConfig& cfg) override {
        if (cfg.spatial.empty()) return -1;
        const SpatialLayer& L = cfg.spatial.back();          // top (highest-res) layer
        w_ = L.width  & ~15; h_ = L.height & ~15;             // H.264 needs multiple of 16
        if (w_ < 16 || h_ < 16) { w_ = 320; h_ = 240; }
        H264E_create_param_t p{};
        p.width = w_; p.height = h_;
        p.gop = (L.ra_period > 0) ? L.ra_period : 30;         // keyframe period (ra_period)
        p.const_input_flag = 1;                               // don't clobber the input frame
        // LTR slots: enough for a real temporal-SVC reference structure (one anchor slot per lower
        // layer). av-pipeline extension — the layered encoder uses these via EncodeFrameCustom().
        p.max_long_term_reference_frames = L.temporal_layer_num > 1 ? (L.temporal_layer_num - 1)
                                                                    : (L.ltr ? 1 : 0);
        int sp = 0, ss = 0;
        if (H264E_sizeof(&p, &sp, &ss)) return -2;
        persist_.assign(sp, 0); scratch_.assign(ss, 0);
        enc_ = reinterpret_cast<H264E_persist_t*>(persist_.data());
        scr_ = reinterpret_cast<H264E_scratch_t*>(scratch_.data());
        if (H264E_init(enc_, &p)) { enc_ = nullptr; return -3; }
        float fps = (L.frame_rate > 0) ? L.frame_rate : 30.f;
        codec_type_ = L.codec_mode;
        if (L.bitrate > 0) desired_frame_bytes_ = int(L.bitrate / 8.0 / fps);
        return 0;
    }
    void ForceIdr(int, int) override            { force_key_ = true; }
    void RequestKeyPicture(int, int) override   { force_key_ = true; }   // recovery -> keyframe
    void DuplicatePFrame(int) override          { /* baseline: no-op (redundant-P is SVC-side) */ }
    void SkipNextFrame(int) override            { skip_next_ = true; }
    void SetBitrateTarget(uint32_t bps, int) override {
        if (bps && last_fps_ > 0) desired_frame_bytes_ = int(bps / 8.0 / last_fps_);
    }
    int codec_type() const override             { return codec_type_; }

    // --- the data path the control ABI lacks: encode one I420 frame -> H.264 Annex-B ---
    // Returns coded byte count (>0), 0 if skipped, <0 on error.
    int EncodeFrame(const uint8_t* i420, int w, int h, std::vector<uint8_t>& out) {
        out.clear();
        if (!enc_) return -1;
        if (skip_next_) { skip_next_ = false; return 0; }
        H264E_io_yuv_t io{};
        io.yuv[0] = const_cast<uint8_t*>(i420);                              io.stride[0] = w;
        io.yuv[1] = const_cast<uint8_t*>(i420) + (size_t)w * h;              io.stride[1] = w / 2;
        io.yuv[2] = io.yuv[1] + (size_t)(w / 2) * (h / 2);                   io.stride[2] = w / 2;
        H264E_run_param_t rp{};
        rp.encode_speed = 10;   // fastest preset — screen-content keyframes are heavy on intra search
        rp.frame_type = force_key_ ? H264E_FRAME_TYPE_KEY : H264E_FRAME_TYPE_DEFAULT;
        rp.qp_min = 20; rp.qp_max = 40;
        rp.desired_frame_bytes = desired_frame_bytes_;
        force_key_ = false;
        unsigned char* coded = nullptr; int sz = 0;
        int err = H264E_encode(enc_, scr_, &rp, &io, &coded, &sz);
        if (err) return -100 - err;
        if (coded && sz > 0) out.assign(coded, coded + sz);
        return sz;
    }
    // av-pipeline extension: encode with EXPLICIT reference control (H264E_FRAME_TYPE_CUSTOM) to build
    // a real temporal-SVC layered-reference structure. ltr_use / ltr_update follow minih264 semantics:
    //   ltr_use    : [1..N] reference that long-term slot; 0 = previous short-term; -1 = IDR (clear LTR)
    //   ltr_update : [1..N] store this frame into that slot; 0 = short-term; -1 = don't save (droppable)
    // A high temporal layer uses ltr_update=-1 so dropping it never breaks a lower layer's references.
    int EncodeFrameCustom(const uint8_t* i420, int w, int h, int ltr_use, int ltr_update,
                          std::vector<uint8_t>& out) {
        out.clear();
        if (!enc_) return -1;
        H264E_io_yuv_t io{};
        io.yuv[0] = const_cast<uint8_t*>(i420);                              io.stride[0] = w;
        io.yuv[1] = const_cast<uint8_t*>(i420) + (size_t)w * h;              io.stride[1] = w / 2;
        io.yuv[2] = io.yuv[1] + (size_t)(w / 2) * (h / 2);                   io.stride[2] = w / 2;
        H264E_run_param_t rp{};
        rp.encode_speed = 10;   // fastest preset — screen-content keyframes are heavy on intra search
        rp.frame_type = H264E_FRAME_TYPE_CUSTOM;
        rp.long_term_idx_use = ltr_use;
        rp.long_term_idx_update = ltr_update;
        rp.qp_min = 20; rp.qp_max = 40;
        rp.desired_frame_bytes = desired_frame_bytes_;
        unsigned char* coded = nullptr; int sz = 0;
        int err = H264E_encode(enc_, scr_, &rp, &io, &coded, &sz);
        if (err) return -100 - err;
        if (coded && sz > 0) out.assign(coded, coded + sz);
        return sz;
    }

    int width() const { return w_; } int height() const { return h_; }

private:
    std::vector<uint8_t> persist_, scratch_;
    H264E_persist_t* enc_ = nullptr;
    H264E_scratch_t* scr_ = nullptr;
    int  w_ = 0, h_ = 0, codec_type_ = 0, desired_frame_bytes_ = 0;
    float last_fps_ = 30.f;
    bool force_key_ = false, skip_next_ = false;
};

} // namespace recon::zlt
#endif // RECON_WITH_H264
