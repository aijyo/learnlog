// screen_codec.hpp — a codec-agnostic SCREEN-CONTENT video codec surface for the conference's
// screen-share path. Zoom encodes screen share with its AV1 Screen-Content core (the reverse-
// engineered `zbt` module: (mode & 0xF) == 2 -> zbtCScEncoderCore, i.e. libaom with the
// screen-content tools) — NOT the H.264 camera codec (`zlt`). See AV_PIPELINE_DETAILS.html §1.4/§3.4.
//
// libaom is unavailable in this environment (its source hosts are blocked and the AV1 SC coding
// kernel is a ⛔K third-party boundary we don't reimplement). So the working backend here is VP9 with
// `VP9E_CONTENT_SCREEN` — Google's screen-content coding, the same *class* of tool, available through
// the already-linked libvpx/avcodec. This interface is deliberately shaped like the zbt IAv1Encoder /
// IAv1Decoder (Configure / Encode nv12->obu / ForceKeyframe / SetBitrate ; Decode obu->nv12) so an
// AV1 SC backend drops in behind the SAME `--codec av1` switch once an AV1 encoder is present — no
// call-site changes. See vp9_screen.hpp for the VP9 backend and the AVP_WITH_AOM factory slot.
#pragma once
#include "preprocess/video_convert.hpp"   // avp::I420Image
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace avp {

// Which codec backend the factory builds. AV1 = zbt screen-content core (libaom); VP9 = libvpx screen
// tune; H264/H265 = the zlt camera-codec family (real libx264/libx265 with adaptive-QP + temporal refs).
enum class ScreenCodec { VP9, AV1, H264, H265 };

inline ScreenCodec ParseScreenCodec(const std::string& s) {
  if (s == "av1"  || s == "AV1")  return ScreenCodec::AV1;
  if (s == "h264" || s == "H264" || s == "avc")  return ScreenCodec::H264;
  if (s == "h265" || s == "H265" || s == "hevc") return ScreenCodec::H265;
  return ScreenCodec::VP9;
}
inline const char* ScreenCodecName(ScreenCodec c) {
  switch (c) { case ScreenCodec::AV1: return "av1"; case ScreenCodec::H264: return "h264";
               case ScreenCodec::H265: return "h265"; default: return "vp9"; }
}

struct ScreenEncParams {
  int  width = 0, height = 0;
  int  fps = 12;
  int  kbps = 2500;         // screen text stays crisp with a healthy bitrate; VP9 handles it efficiently
  int  gop = 48;            // periodic keyframe (random-access) period — bounds loss-recovery latency
  bool screen_content = true;   // -> VP9E_CONTENT_SCREEN / AV1E_SET_TUNE_CONTENT=SCREEN (zbt (mode&0xF)==2)
  // QUALITY-FIRST rate control (Zoom §1.4: desktop share spends bits on spatial sharpness, sacrifices
  // frame rate). qmax caps the WORST-case quantizer so a busy/scrolling frame can never be crushed into
  // blur to hit the bitrate — the encoder overshoots rate (or the fps sags) instead. qmin keeps static
  // content near-lossless. VP9 quantizer range is 0..63; lower qmax = sharper floor, more bits on motion.
  int  qmin = 4, qmax = 40;
  // AV1-only knobs. cpu_used = speed/quality (lower = slower + better screen-content tool search).
  // realtime=false selects libaom's `good` usage, whose full IntraBC/palette path keeps anti-aliased
  // scrolling text sharp (the RT path skips it); on a many-core box `good` still runs live at low fps.
  int  cpu_used = 8;
  bool realtime = true;
  // true = an external per-block QP map (Zoom's zlt TextureMotion, via set_qp_map) drives adaptive QP,
  // so the H.264/H.265 backend turns OFF its own generic AQ and lets the injected map rule (§3.3).
  bool ext_qp_map = false;
};

// A screen-content video ENCODER. Emits one self-contained access unit per frame (a whole coded
// picture), which the existing packetizer / multi-FEC / FrameAssembler carry byte-for-byte exactly like
// the H.264 access unit — so no transport change is needed to swap codecs.
struct IScreenEncoder {
  virtual ~IScreenEncoder() = default;
  virtual bool open(const ScreenEncParams& p) = 0;
  // Encode one I420 frame. `out_au` = the coded frame's bytes; `keyframe` = it's a key/intra frame.
  virtual bool encode(const I420Image& in, bool force_key,
                      std::vector<uint8_t>& out_au, bool& keyframe) = 0;
  virtual void set_bitrate(int bps) = 0;      // congestion-control retarget (zbt SetBitrate)
  // Inject Zoom's reconstructed per-block adaptive-QP map (zlt TextureMotion, §3.3): delta[by*bw+bx]
  // in -3..+3 (flat/smooth -> negative = spend bits/sharper; busy -> positive = save bits). Applied to
  // the next encode() as an encoder ROI/quant-offset map. Default no-op (backends without a QP map API).
  virtual void set_qp_map(const std::vector<int>& /*delta*/, int /*bw*/, int /*bh*/, int /*block*/) {}
  // LONG-TERM-REFERENCE loss recovery (Zoom SetKeyPictureRequest case 2): does this backend support recovering
  // from a clean earlier reference (cheap P) instead of a full IDR? Only the libvpx-direct VP9 encoder does
  // (avcodec can't manage refs); others return false so the receiver's loss request still escalates to an IDR.
  virtual bool supports_ltr() const { return false; }
  // Ask that the NEXT encode() be an LTR-recovery frame (reference the known-good golden, not a full keyframe).
  virtual void request_ltr_recover() {}
  virtual const char* name() const = 0;
};

// The matching DECODER: one coded access unit -> one I420 frame.
struct IScreenDecoder {
  virtual ~IScreenDecoder() = default;
  virtual bool open() = 0;
  virtual bool decode(const std::vector<uint8_t>& au, I420Image& out) = 0;
  virtual const char* name() const = 0;
};

// Factories (defined inline in vp9_screen.hpp). Return nullptr if the requested backend isn't built.
std::unique_ptr<IScreenEncoder> MakeScreenEncoder(ScreenCodec c);
std::unique_ptr<IScreenDecoder> MakeScreenDecoder(ScreenCodec c);

}  // namespace avp
