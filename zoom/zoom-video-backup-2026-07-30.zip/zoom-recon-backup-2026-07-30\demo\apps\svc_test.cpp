// svc_test.cpp — TRUE spatial SVC in ONE stream via libvpx VP9 (the Zoom §3.2 spatial-layer scheme:
// one encode, multiple resolutions, an SFU/receiver keeps only the layers it needs). Uses the low-level
// libvpx SVC API directly (VP9E_SET_SVC + SET_SVC_PARAMETERS + SET_SVC_LAYER_ID) — avcodec can't do this.
// Configures 2 spatial layers (base 640x360, enhancement 1280x720) and prints the per-superframe packet
// structure, then decodes the FULL superframe (720p) vs only the BASE sub-frame (360p) from the SAME
// bytes — proving the stream is prunable.
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <cstdio>
#include <cstring>
#include <vector>
extern "C" {
#include "vpx/vpx_encoder.h"
#include "vpx/vp8cx.h"
#include "vpx/vpx_decoder.h"
#include "vpx/vp8dx.h"
#include "vpx/vpx_image.h"
}

using namespace avp;
static const int FW = 1280, FH = 720, SS = 2, FRAMES = 10;   // 2 spatial layers; base = 1/2 => 640x360

// a text-ish image so downscaled base vs full is visually meaningful
static void fill_i420(vpx_image_t* img, int t) {
  for (int y = 0; y < FH; ++y) for (int x = 0; x < FW; ++x) {
    int v = ((x / 8 + y / 8 + t) & 1) ? 210 : 40;            // checker (high freq)
    if (((x + t * 4) % 120) < 60) v = 128 + (x % 64);        // moving gradient bands
    img->planes[0][y * img->stride[0] + x] = (uint8_t)v;
  }
  for (int y = 0; y < FH / 2; ++y) for (int x = 0; x < FW / 2; ++x) {
    img->planes[1][y * img->stride[1] + x] = 128; img->planes[2][y * img->stride[2] + x] = 128;
  }
}

// parse a VP9 superframe index -> sizes of each contained frame (base first). Returns false if not a superframe.
static bool split_superframe(const uint8_t* d, size_t n, std::vector<size_t>& sizes) {
  sizes.clear();
  if (n < 2) return false;
  uint8_t marker = d[n - 1];
  if ((marker & 0xe0) != 0xc0) return false;                 // not a superframe index
  int bytes_per = ((marker >> 3) & 3) + 1, frames = (marker & 7) + 1;
  size_t index_sz = 2 + (size_t)frames * bytes_per;
  if (n < index_sz || d[n - index_sz] != marker) return false;
  const uint8_t* p = d + n - index_sz + 1;
  for (int i = 0; i < frames; ++i) { size_t s = 0; for (int b = 0; b < bytes_per; ++b) s |= (size_t)p[b] << (8 * b); p += bytes_per; sizes.push_back(s); }
  return true;
}

// feed one access unit to a persistent decoder; update last-decoded dims.
static void dec_feed(vpx_codec_ctx_t* dec, const uint8_t* d, size_t n, int& w, int& h) {
  if (vpx_codec_decode(dec, d, (unsigned)n, nullptr, 0) == VPX_CODEC_OK) {
    vpx_codec_iter_t it = nullptr; vpx_image_t* im;
    while ((im = vpx_codec_get_frame(dec, &it))) { w = im->d_w; h = im->d_h; }
  }
}

int main() {
  vpx_codec_enc_cfg_t cfg; vpx_codec_enc_config_default(vpx_codec_vp9_cx(), &cfg, 0);
  cfg.g_w = FW; cfg.g_h = FH; cfg.g_timebase.num = 1; cfg.g_timebase.den = 30;
  cfg.rc_target_bitrate = 2000; cfg.rc_end_usage = VPX_CBR; cfg.g_lag_in_frames = 0;
  cfg.ss_number_layers = SS; cfg.ts_number_layers = 1;
  cfg.layer_target_bitrate[0] = 700; cfg.layer_target_bitrate[1] = 2000;   // base, base+enh cumulative
  cfg.ts_rate_decimator[0] = 1;

  vpx_codec_ctx_t enc;
  if (vpx_codec_enc_init(&enc, vpx_codec_vp9_cx(), &cfg, 0)) { std::printf("enc init failed: %s\n", vpx_codec_error(&enc)); return 1; }
  vpx_codec_control(&enc, VP9E_SET_SVC, 1);
  vpx_svc_extra_cfg_t svc{};
  svc.scaling_factor_num[0] = 1; svc.scaling_factor_den[0] = 2;   // base = 1/2 -> 640x360
  svc.scaling_factor_num[1] = 1; svc.scaling_factor_den[1] = 1;   // enhancement = full 1280x720
  for (int i = 0; i < SS; ++i) { svc.max_quantizers[i] = 56; svc.min_quantizers[i] = 4; }
  vpx_codec_control(&enc, VP9E_SET_SVC_PARAMETERS, &svc);
  vpx_codec_control(&enc, VP8E_SET_CPUUSED, 7);

  vpx_image_t img; vpx_img_alloc(&img, VPX_IMG_FMT_I420, FW, FH, 1);

  std::printf("\n  VP9 spatial SVC — 1 stream, 2 layers (base 640x360 + enh 1280x720)\n");
  std::printf("  ------------------------------------------------------------------\n");
  std::vector<std::vector<uint8_t>> stream;   // each entry = one superframe (both spatial layers)
  long full_bytes = 0, base_bytes = 0;
  for (int t = 0; t < FRAMES; ++t) {
    fill_i420(&img, t);
    if (vpx_codec_encode(&enc, &img, t, 1, 0, VPX_DL_REALTIME)) { std::printf("encode err: %s\n", vpx_codec_error(&enc)); break; }
    vpx_codec_iter_t it = nullptr; const vpx_codec_cx_pkt_t* pkt;
    std::vector<uint8_t> full;
    while ((pkt = vpx_codec_get_cx_data(&enc, &it)))
      if (pkt->kind == VPX_CODEC_CX_FRAME_PKT) { const uint8_t* b = (const uint8_t*)pkt->data.frame.buf; full.insert(full.end(), b, b + pkt->data.frame.sz); }
    if (full.empty()) continue;
    std::vector<size_t> sizes; bool sf = split_superframe(full.data(), full.size(), sizes);
    full_bytes += (long)full.size(); base_bytes += (long)(sf && !sizes.empty() ? sizes[0] : full.size());
    if (t <= 1) { std::printf("  frame %d: superframe=%d", t, sf ? 1 : 0);
      if (sf) { std::printf(", sub-frames:"); for (size_t s : sizes) std::printf(" %zuB", s); }
      std::printf(", total %zuB\n", full.size()); }
    stream.push_back(std::move(full));
  }
  // decode the WHOLE sequence two ways from the SAME encoded stream:
  //   FULL  = feed each superframe (both layers)   -> highest resolution
  //   BASE  = feed only each superframe's 1st sub-frame (spatial layer 0) -> base resolution
  vpx_codec_ctx_t decF, decB;
  vpx_codec_dec_init(&decF, vpx_codec_vp9_dx(), nullptr, 0);
  vpx_codec_dec_init(&decB, vpx_codec_vp9_dx(), nullptr, 0);
  int fw = 0, fh = 0, bw = 0, bh = 0;
  for (auto& s : stream) {
    dec_feed(&decF, s.data(), s.size(), fw, fh);
    std::vector<size_t> sz; size_t bn = (split_superframe(s.data(), s.size(), sz) && !sz.empty()) ? sz[0] : s.size();
    dec_feed(&decB, s.data(), bn, bw, bh);
  }
  vpx_codec_destroy(&decF); vpx_codec_destroy(&decB);
  std::printf("  ------------------------------------------------------------------\n");
  std::printf("  decode FULL stream -> %dx%d   (%ld B total)\n", fw, fh, full_bytes);
  std::printf("  decode BASE only   -> %dx%d   (%ld B total, enhancement pruned = %.0f%% smaller)\n",
              bw, bh, base_bytes, full_bytes ? 100.0 * (full_bytes - base_bytes) / full_bytes : 0.0);
  std::printf("  ------------------------------------------------------------------\n");
  std::printf("  => ONE encode, ONE stream; an SFU/receiver forwarding only the base sub-frame gets\n");
  std::printf("     %dx%d at %ld B instead of %dx%d at %ld B — Zoom's spatial-layer pruning (§3.2).\n\n",
              bw, bh, base_bytes, fw, fh, full_bytes);
  vpx_img_free(&img); vpx_codec_destroy(&enc);
  return 0;
}
