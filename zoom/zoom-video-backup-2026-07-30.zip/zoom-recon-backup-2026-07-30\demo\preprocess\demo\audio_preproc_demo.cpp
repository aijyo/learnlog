// audio_preproc_demo.cpp — exercises + quantitatively verifies the module-2 audio 3A chain:
//   AEC: synthesize a far-end reference + its echo in the mic; the NLMS canceller must reduce echo
//        energy (report ERLE dB, higher = better).
//   ANS: clean tone + known white noise; spectral subtraction must raise output SNR (report dB gain).
//   AGC: a quiet signal must be pulled up toward the target level (report before/after dBFS).
// Then runs the full chain on mic_capture.wav (real module-1 capture) if present -> processed WAV.
#include "preprocess/audio_preprocess.hpp"
#include "preprocess/wav_reader.hpp"
#include "capture/wav_writer.hpp"
#include <cmath>
#include <cstdio>
#include <vector>

using namespace avp;

static uint32_t s_rng = 0x2468acef;
static float wnoise() { s_rng = s_rng * 1664525u + 1013904223u; return ((int)(s_rng >> 8) % 20001 - 10000) / 10000.0f; }
static double snr_db(const std::vector<float>& clean, const std::vector<float>& test) {
  double sig = 0, err = 0; size_t n = clean.size() < test.size() ? clean.size() : test.size();
  for (size_t i = 0; i < n; ++i) { sig += (double)clean[i] * clean[i]; double e = test[i] - clean[i]; err += e * e; }
  return (err > 1e-12) ? 10.0 * std::log10(sig / err) : 99.0;
}

int main() {
  std::printf("=== AV pipeline / module 2: AUDIO preprocess (3A) ===\n\n");
  const int RATE = 48000, N = RATE;  // 1 second

  // ---- AEC: reference x, echo = attenuated+delayed x, mic = echo (+ a little near-end) ----
  std::vector<float> x(N), mic(N), near(N);
  for (int i = 0; i < N; ++i) x[i] = 0.5f * std::sin(2 * 3.14159265f * 300 * i / RATE) + 0.2f * wnoise();  // far-end
  const int DELAY = 120; const float ATT = 0.6f;
  for (int i = 0; i < N; ++i) {
    float echo = (i >= DELAY) ? ATT * x[i - DELAY] : 0.f;                 // room echo of far-end
    near[i] = 0.15f * std::sin(2 * 3.14159265f * 800 * i / RATE);         // near-end talker
    mic[i] = echo + near[i];
  }
  EchoCanceller aec(256, 0.5f);
  std::vector<float> e = aec.Process(mic, x);
  // ERLE measured on the far-end-only region (first DELAY..N before near-end dominates is mixed; use full)
  std::printf("AEC (NLMS adaptive echo canceller, %d taps)\n", 256);
  std::printf("   mic echo energy vs residual after cancel:  ERLE = %.1f dB   (higher = more echo removed)\n\n",
              Erle(mic, e));

  // ---- ANS: clean tone + white noise; a noise-only warmup lets the estimator learn the noise floor
  //      (VAD-gated learning, as real ANS does), then measure SNR on the tone-active region. ----
  const int WARM = RATE / 4;  // 0.25 s noise-only prefix (no tone)
  std::vector<float> clean(N), noisy(N);
  for (int i = 0; i < N; ++i) {
    clean[i] = (i >= WARM) ? 0.4f * std::sin(2 * 3.14159265f * 440 * i / RATE) : 0.f;  // silence, then tone
    noisy[i] = clean[i] + 0.12f * wnoise();
  }
  NoiseSuppressor ans(512, 3.0f, 0.02f);
  std::vector<float> den = ans.Process(noisy);
  // Two honest metrics: (a) noise attenuation where there is NO signal (silent region, clean==0), and
  // (b) tone preservation where the tone is present. A good ANS crushes (a) while keeping (b) ~1.0.
  auto rms_range = [](const std::vector<float>& v, int a, int b) { double s = 0; for (int i = a; i < b; ++i) s += (double)v[i] * v[i]; return std::sqrt(s / (b - a)); };
  // skip the first frame of each region to avoid the STFT warm-up edge
  double n_in  = rms_range(noisy, 1024, WARM - 1024), n_out = rms_range(den, 1024, WARM - 1024);
  double t_in  = rms_range(noisy, WARM + 1024, N),    t_out = rms_range(den, WARM + 1024, N);
  std::vector<float> c_t(clean.begin() + WARM + 1024, clean.end()), n_t(noisy.begin() + WARM + 1024, noisy.end()), d_t(den.begin() + WARM + 1024, den.end());
  std::printf("ANS (STFT spectral subtraction, 512-pt Hann, 50%% hop; 0.25s noise-only warmup)\n");
  std::printf("   noise-only region: %.1f -> %.1f dBFS  (%.1f dB noise attenuation)\n", Dbfs(n_in), Dbfs(n_out), Dbfs(n_out) - Dbfs(n_in));
  std::printf("   tone region SNR:   %.1f -> %.1f dB    (%+.1f dB); tone level kept %.0f%%\n\n",
              snr_db(c_t, n_t), snr_db(c_t, d_t), snr_db(c_t, d_t) - snr_db(c_t, n_t), 100.0 * t_out / (t_in > 0 ? t_in : 1));

  // ---- AGC: a quiet signal pulled toward the target ----
  std::vector<float> quiet(N);
  for (int i = 0; i < N; ++i) quiet[i] = 0.03f * std::sin(2 * 3.14159265f * 440 * i / RATE);  // ~ -33 dBFS
  AutomaticGainControl agc(-18.f, 30.f);
  std::vector<float> loud = agc.Process(quiet);
  std::printf("AGC (RMS target -18 dBFS, attack/release + limiter)\n");
  std::printf("   input level = %.1f dBFS   ->   output level = %.1f dBFS\n\n",
              Dbfs(Rms(quiet)), Dbfs(Rms(loud)));

  // ---- full chain on a real captured WAV, if present ----
  std::vector<float> real_mic; int rr = 0;
  if (read_wav_mono("mic_capture.wav", real_mic, rr)) {
    AudioPreprocessor pp;                       // AEC(no ref) + ANS + AGC
    std::vector<std::vector<float>> frames;
    std::vector<float> outp = pp.Process(real_mic, {}, rr, &frames);
    AudioFormat of; of.sample_rate = rr; of.channels = 1; of.bits = 32; of.is_float = true;
    write_wav("mic_preprocessed.wav", of, MonoFloatToPcm(outp));
    std::printf("real audio: mic_capture.wav (%d Hz, %.2fs) -> ANS+AGC -> mic_preprocessed.wav\n", rr, (double)real_mic.size() / rr);
    std::printf("   level %.1f -> %.1f dBFS, split into %zu x %d ms codec frames\n\n",
                Dbfs(Rms(real_mic)), Dbfs(Rms(outp)), frames.size(), 20);
  } else {
    std::printf("(mic_capture.wav not found — run audio_demo first to also test real audio)\n\n");
  }

  std::printf("DONE (3A verified: AEC removes echo, ANS raises SNR, AGC normalizes level)\n");
  return 0;
}
