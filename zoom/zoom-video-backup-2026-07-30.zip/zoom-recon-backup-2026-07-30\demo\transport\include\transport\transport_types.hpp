// transport_types.hpp — module 5 shared types (AV_PIPELINE_DETAILS.html §5).
// The media transport carries the protected packets from module 4 over UDP (primary), QUIC, or TCP
// (reliable fallback), under congestion control. These are the small value types the pieces share.
#pragma once
#include <cstdint>

namespace avp {

enum class TransportKind { UDP, QUIC, TCP };
inline const char* to_string(TransportKind k) {
  switch (k) { case TransportKind::UDP: return "UDP"; case TransportKind::QUIC: return "QUIC"; default: return "TCP"; }
}

// Per-packet feedback the receiver reports back (the input to congestion control).
struct PacketFeedback {
  uint16_t seq = 0;
  int64_t  send_time_us = 0;      // when the sender paced it out
  int64_t  recv_time_us = 0;      // when the receiver got it (0 = lost)
  int      size = 0;
  bool     lost() const { return recv_time_us == 0; }
};

// A snapshot of the controller's state.
struct CongestionState {
  double   target_bps = 0;        // current send-rate target
  double   throughput_bps = 0;    // measured received throughput
  double   rtt_ms = 0;
  double   loss = 0;              // recent loss fraction [0,1]
  const char* signal = "normal";  // "normal" | "overuse" | "underuse"
};

}  // namespace avp
