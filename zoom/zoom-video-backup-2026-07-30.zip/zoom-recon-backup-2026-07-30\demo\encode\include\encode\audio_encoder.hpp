// audio_encoder.hpp — module 3 audio encode (AV_PIPELINE_DETAILS.html §3.1/§3.5).
//
// Zoom's audio codecs are Opus (custom) and SNAC (neural). Neither is reproducible here: SNAC is a
// trained-weight boundary (⛔W) and this environment has no libopus, so the *real audio encoder* used
// to demonstrate the encode data path is FFmpeg's native AAC encoder (AVP_WITH_FFMPEG). The codec-
// SWITCHING control surface — the AI-codec 121 gate, the 0x4 control-word bit, the SNAC decode state
// machine, and the SNAC-TCP→Opus fallback thresholds (§3.5) — is Zoom's own logic, reconstructed and
// body-verified, and is available regardless of FFmpeg via algo/viper_codec_control.hpp.
#pragma once
#include "algo/viper_codec_control.hpp"   // recon::viper codec-control surface (always available)
#include <cstdint>
#include <vector>

namespace avp {

struct EncodedAudio {
  std::vector<uint8_t> data;
  int64_t pts_us = 0;
  int     frames = 0;      // sample-frames represented by this packet
  int     size() const { return (int)data.size(); }
};

struct IAudioEncoder {
  virtual ~IAudioEncoder() = default;
  virtual bool open(int sample_rate, int channels, int bitrate_bps) = 0;
  virtual bool encode(const float* pcm, int nframes, std::vector<EncodedAudio>& out) = 0;   // mono float in
  virtual std::vector<EncodedAudio> flush() = 0;
  virtual const char* codec() const = 0;
  virtual int  frame_size() const = 0;   // encoder's native frame size (samples)
};

}  // namespace avp

#ifdef AVP_WITH_FFMPEG
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/channel_layout.h>
#include <libavutil/samplefmt.h>
}
#include <cstring>

namespace avp {

// Real AAC-LC encoder (FFmpeg native). Buffers mono float input into the encoder's frame_size chunks.
class AacEncoder : public IAudioEncoder {
public:
  ~AacEncoder() override { if (c_) avcodec_free_context(&c_); }

  bool open(int sample_rate, int channels, int bitrate_bps) override {
    const AVCodec* enc = avcodec_find_encoder(AV_CODEC_ID_AAC);
    if (!enc) return false;
    c_ = avcodec_alloc_context3(enc);
    c_->sample_rate = sample_rate;
    c_->sample_fmt  = AV_SAMPLE_FMT_FLTP;             // AAC wants planar float
    c_->bit_rate    = bitrate_bps;
    av_channel_layout_default(&c_->ch_layout, channels);
    if (avcodec_open2(c_, enc, nullptr) != 0) { avcodec_free_context(&c_); return false; }
    frame_size_ = c_->frame_size > 0 ? c_->frame_size : 1024;
    rate_ = sample_rate; ch_ = channels;
    return true;
  }

  bool encode(const float* pcm, int nframes, std::vector<EncodedAudio>& out) override {
    if (!c_) return false;
    buf_.insert(buf_.end(), pcm, pcm + nframes);
    size_t pos = 0;
    while (buf_.size() - pos >= (size_t)frame_size_) {
      if (!encode_one(&buf_[pos], frame_size_, out)) return false;
      pos += frame_size_;
    }
    buf_.erase(buf_.begin(), buf_.begin() + pos);
    return true;
  }

  std::vector<EncodedAudio> flush() override {
    std::vector<EncodedAudio> out;
    if (!c_) return out;
    if (!buf_.empty()) {                              // pad the tail to a full frame
      buf_.resize(((buf_.size() + frame_size_ - 1) / frame_size_) * frame_size_, 0.f);
      for (size_t pos = 0; pos < buf_.size(); pos += frame_size_) encode_one(&buf_[pos], frame_size_, out);
      buf_.clear();
    }
    drain(out, nullptr);                              // flush the encoder
    return out;
  }

  const char* codec() const override { return "AAC-LC (FFmpeg native)"; }
  int frame_size() const override { return frame_size_; }
  // AudioSpecificConfig the decoder needs (closes the audio loop in module 7).
  const uint8_t* extradata() const { return c_ ? c_->extradata : nullptr; }
  int extradata_size() const { return c_ ? c_->extradata_size : 0; }

private:
  bool encode_one(const float* mono, int n, std::vector<EncodedAudio>& out) {
    AVFrame* f = av_frame_alloc();
    f->nb_samples = n; f->format = AV_SAMPLE_FMT_FLTP; f->sample_rate = rate_;
    av_channel_layout_copy(&f->ch_layout, &c_->ch_layout);
    if (av_frame_get_buffer(f, 0) != 0) { av_frame_free(&f); return false; }
    for (int ch = 0; ch < ch_; ++ch) memcpy(f->data[ch], mono, (size_t)n * sizeof(float));  // same mono into each plane
    f->pts = pts_samples_; pts_samples_ += n;
    bool ok = drain(out, f);
    av_frame_free(&f);
    return ok;
  }
  bool drain(std::vector<EncodedAudio>& out, AVFrame* f) {
    if (avcodec_send_frame(c_, f) != 0) return false;
    AVPacket* pkt = av_packet_alloc();
    while (avcodec_receive_packet(c_, pkt) == 0) {
      EncodedAudio ea; ea.data.assign(pkt->data, pkt->data + pkt->size);
      ea.frames = frame_size_; ea.pts_us = rate_ ? pkt->pts * 1000000 / rate_ : 0;
      out.push_back(std::move(ea));
      av_packet_unref(pkt);
    }
    av_packet_free(&pkt);
    return true;
  }

  AVCodecContext* c_ = nullptr;
  std::vector<float> buf_;
  int frame_size_ = 1024, rate_ = 48000, ch_ = 1;
  int64_t pts_samples_ = 0;
};

}  // namespace avp
#endif  // AVP_WITH_FFMPEG
