# Modules 6-8 — receive / decode / render (and the whole-pipeline loop)

The receive side (`AV_PIPELINE_DETAILS.html §6/§7/§8`) — the mirror of the send side — plus the demo
that runs **the entire pipeline end to end** over a reordering, lossy channel.

```
[send: capture→preprocess→encode→packetize→FEC]  →  shuffle + drop  →
   jitter buffer (reorder, RFC3550 jitter) → FEC recover → reassemble AU → decode → PSNR → render
```

## Pieces

- **§6 `jitter_buffer.hpp`** — reorders packets by sequence number, estimates interarrival **jitter
  (RFC 3550)**, holds a self-tuned playout delay (`20 + 4·jitter`), reassembles complete access units
  (same RTP timestamp, ending on the marker), and reports missing seqs for FEC/NACK.
- **§7 decode** — `receive/audio_decoder.hpp` (FFmpeg **AAC** → PCM, using the encoder's extradata) and
  the module-3 `H264Decoder` (FFmpeg **H.264** → I420). Real codecs (`AVP_WITH_FFMPEG`).
- **§8 `renderer.hpp`** — `VideoRenderer` (I420 → BGRA → BMP, a headless present) and `AudioRenderer`
  (PCM → WAV, with optional real WASAPI playout via `PlayPcmBlocking`, gated by the `AVP_PLAY` env var).

## Build & run
```powershell
cmake -S . -B build -DAVP_WITH_WGC=ON          # jitter buffer + FEC reassembly (no external libs)
cmake --build build --config Release --target receive_demo
.\build\receive\Release\receive_demo.exe
# full loop with real decode + PSNR + BMP/WAV:
cmake -S . -B build-ff -DAVP_WITH_FFMPEG=ON
cmake --build build-ff --config Release --target receive_demo
.\build-ff\receive\Release\receive_demo.exe    # (put mic_preprocessed.wav alongside for the audio loop)
```

## Verified (this machine)
```
send            3862 B H.264 -> 4 media packets + 4 FEC (L4)
channel         2 of 4 source packets dropped, arrival order shuffled, +jitter
receive         jitter buffer reorders; RFC3550 jitter 0.2 ms, playout target 21 ms
FEC recover     2 lost source packets rebuilt from parity
reassemble      access unit == encoded frame, BYTE-IDENTICAL
decode+render   FFmpeg H.264 -> 320x240, luma PSNR 44.6 dB vs source -> received_frame0.bmp
audio loop      mic_preprocessed.wav -> 140 AAC pkts -> decode 143360 samples, energy 1.00 -> received_audio.wav
```

Jitter buffer + FEC reassembly are real; decode uses real FFmpeg (H.264/AAC). Zoom's own receive path
uses dav1d (AV1) / libopus / SNAC — decoders that are available (dav1d) or boundaries (SNAC weights);
FFmpeg stands in for a runnable loop. Clean-room, following Zoom's *design*. For interop / education.
