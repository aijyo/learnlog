// raisr_train_camera.cpp — train a CLEAN-ROOM camera RAISR bank to Zoom's recovered zltCRaisr structure
// (recon/zlt_raisr_camera.hpp): 22 gradient buckets (11 angle × 2 strength), phases = scale² (4 for x2),
// 13-tap direct LR-patch -> HR-sub-pixel filters. The METHOD is RAISR's canonical per-(phase,bucket)
// least squares (which is how a RAISR bank is defined); the WEIGHTS are OURS. Degradation MATCHES the
// receiver's camera path: HR --bicubic ÷2--> LR_clean --VP9 encode/decode--> LR (the real chain).
//
// Also prints our trained-bank statistics next to Zoom's EXTRACTED x2 bank stats (|mean|≈0.149,
// min/max −0.403/1.370, per-filter sum≈1.70) — an empirical check that least-squares to this shape lands
// in the same regime as Zoom's coefficients (structure + method match; exact recipe is offline/unknown).
#include "zlt_raisr_camera.hpp"          // recon::zltcam  (structure + direct upscaler + bank)
#include "zlt_resample.hpp"              // bicubic downscale (Zoom VPP kernel)
#include "encode/screen_codec.hpp"
#include "encode/vp9_screen.hpp"
#include "preprocess/video_convert.hpp"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
using std::vector;
using namespace recon::zltcam;

static CamRaisrConfig CFG;   // scale=2 default

// ---- images ----
static void makeSynthHR(vector<float>& Y,int W,int H,uint32_t seed){
  Y.assign((size_t)W*H,0.f);
  for(int y=0;y<H;++y)for(int x=0;x<W;++x)Y[(size_t)y*W+x]=55.f+90.f*x/W+45.f*y/H;
  uint32_t s=seed*2654435761u+12345u;
  auto rnd=[&](float a,float b){s=s*1664525u+1013904223u;return a+(b-a)*((s>>8)*(1.0f/16777216.0f));};
  auto put=[&](int x,int y,float v){if(x>=0&&x<W&&y>=0&&y<H)Y[(size_t)y*W+x]=v;};
  for(int k=0;k<600;++k){int t=(int)rnd(0,3);float v=rnd(8,247);
    if(t==0){int rx=(int)rnd(0,W),ry=(int)rnd(0,H),rw=(int)rnd(3,55),rh=(int)rnd(3,55);
      for(int y=ry;y<ry+rh;++y)for(int x=rx;x<rx+rw;++x)put(x,y,v);}
    else if(t==1){float ang=rnd(0,3.14159f),len=rnd(15,110),cx=rnd(0,W),cy=rnd(0,H),th=rnd(0.6f,2.2f),dx=std::cos(ang),dy=std::sin(ang);
      for(float p=-len/2;p<len/2;p+=0.5f)for(float q=-th;q<=th;q+=0.5f)put((int)(cx+p*dx-q*dy),(int)(cy+p*dy+q*dx),v);}
    else{float cx=rnd(0,W),cy=rnd(0,H),rr=rnd(3,28);
      for(int y=(int)(cy-rr);y<=cy+rr;++y)for(int x=(int)(cx-rr);x<=cx+rr;++x)if((x-cx)*(x-cx)+(y-cy)*(y-cy)<=rr*rr)put(x,y,v);}}
  for(auto&v:Y)v=v<0?0:(v>255?255:v);
}
static bool loadBMPLuma(const char* path,vector<float>& Y,int& W,int& H){
  FILE* f=fopen(path,"rb"); if(!f) return false; uint8_t h[54];
  if(fread(h,1,54,f)!=54||h[0]!='B'||h[1]!='M'){fclose(f);return false;}
  int w=*(int*)(h+18),hh=*(int*)(h+22);uint16_t bpp=*(uint16_t*)(h+28);uint32_t off=*(uint32_t*)(h+10);
  if(bpp!=32){fclose(f);return false;} bool up=hh>0;int ah=hh>0?hh:-hh;fseek(f,off,SEEK_SET);
  vector<uint8_t> row((size_t)w*4);Y.assign((size_t)w*ah,0.f);W=w;H=ah;
  for(int r=0;r<ah;++r){if(fread(row.data(),1,row.size(),f)!=row.size()){fclose(f);return false;}
    int y=up?(ah-1-r):r;for(int x=0;x<w;++x)Y[(size_t)y*w+x]=0.299f*row[x*4+2]+0.587f*row[x*4+1]+0.114f*row[x*4+0];}
  fclose(f);return true;
}
// receiver degradation: HR --bicubic ÷scale--> LR_clean --VP9 screen encode/decode--> LR
static int g_kbps=800,g_qmax=44;
static bool codecRT(const vector<float>& in,int w,int h,vector<float>& out){
  avp::I420Image img; img.w=w; img.h=h; img.y.resize((size_t)w*h);
  for(size_t i=0;i<img.y.size();++i){float v=in[i];img.y[i]=(uint8_t)(v<0?0:(v>255?255:v+0.5f));}
  int cw=(w+1)/2,ch=(h+1)/2; img.u.assign((size_t)cw*ch,128); img.v.assign((size_t)cw*ch,128);
  auto e=avp::MakeScreenEncoder(avp::ScreenCodec::VP9); if(!e) return false;
  avp::ScreenEncParams p; p.width=w;p.height=h;p.fps=15;p.kbps=g_kbps;p.gop=1;p.screen_content=false;p.qmax=g_qmax;
  if(!e->open(p)) return false; std::vector<uint8_t> au; bool key=false;
  if(!e->encode(img,true,au,key)||au.empty()) return false;
  auto d=avp::MakeScreenDecoder(avp::ScreenCodec::VP9); if(!d||!d->open()) return false;
  avp::I420Image o; if(!d->decode(au,o)||!o.valid()) return false;
  out.assign((size_t)w*h,0.f);
  for(int y=0;y<h&&y<o.h;++y)for(int x=0;x<w&&x<o.w;++x)out[(size_t)y*w+x]=(float)o.y[(size_t)y*o.w+x];
  return true;
}
static bool degrade(const vector<float>& HR,int W,int H,vector<float>& LR,int& lw,int& lh){
  int s=CFG.scale; lw=W/s; lh=H/s; vector<float> clean((size_t)lw*lh,0.f);
  zlt::resample::ResizePlane(HR.data(),W,H,W, clean.data(),lw,lh,lw);
  return codecRT(clean,lw,lh,LR);
}
static double psnr(const vector<float>& a,const vector<float>& b,int W,int H,int guard){
  double se=0;long n=0;
  for(int y=guard;y<H-guard;++y)for(int x=guard;x<W-guard;++x){double d=a[(size_t)y*W+x]-b[(size_t)y*W+x];se+=d*d;++n;}
  double mse=se/std::max(1L,n);return mse<1e-9?99.0:10.0*log10(255.0*255.0/mse);
}
static bool solveSPD(vector<double>& A,vector<double>& b,int n){
  for(int i=0;i<n;++i)for(int j=0;j<=i;++j){double s=A[(size_t)i*n+j];for(int k=0;k<j;++k)s-=A[(size_t)i*n+k]*A[(size_t)j*n+k];
    if(i==j){if(s<=0)return false;A[(size_t)i*n+i]=sqrt(s);}else A[(size_t)i*n+j]=s/A[(size_t)j*n+j];}
  for(int i=0;i<n;++i){double s=b[i];for(int k=0;k<i;++k)s-=A[(size_t)i*n+k]*b[k];b[i]=s/A[(size_t)i*n+i];}
  for(int i=n-1;i>=0;--i){double s=b[i];for(int k=i+1;k<n;++k)s-=A[(size_t)k*n+i]*b[k];b[i]=s/A[(size_t)i*n+i];}
  return true;
}

// direct-convention normal equations: LR patch (13-tap diamond) -> HR sub-pixel, per (phase,bucket)
static vector<double> g_ATA,g_ATb; static vector<long> g_pop;
static void accumulate(const vector<float>& HR,int W,int H){
  int s=CFG.scale; int lw=W/s,lh=H/s; vector<float> LR; int a,b; if(!degrade(HR,W,H,LR,a,b))return;
  const int NB=CFG.Buckets(),NP=CFG.Phases(),T=CFG.TapsPerPhase(); const auto& off=PatchOffsets(T);
  vector<float> patch(T);
  for(int ly=2;ly<lh-2;++ly)for(int lx=2;lx<lw-2;++lx){
    int bk=ClassifyCam(LR.data(),lw,lh,lx,ly,CFG);
    for(int k=0;k<T;++k){int sx=lx+off[k].first,sy=ly+off[k].second;patch[k]=LR[(size_t)sy*lw+sx];}
    for(int py=0;py<s;++py)for(int px=0;px<s;++px){
      int ph=py*s+px; double tgt=HR[(size_t)(ly*s+py)*W+(lx*s+px)];
      size_t base=((size_t)ph*NB+bk); double* A=&g_ATA[base*T*T]; double* B=&g_ATb[base*T];
      for(int r=0;r<T;++r){double pr=patch[r];B[r]+=pr*tgt;double* Ar=A+(size_t)r*T;for(int c=r;c<T;++c)Ar[c]+=pr*patch[c];}
      g_pop[base]++;
    }
  }
}
static void solveBank(vector<float>& bank){
  const int NB=CFG.Buckets(),NP=CFG.Phases(),T=CFG.TapsPerPhase();
  bank.assign((size_t)NP*NB*T,0.f); vector<double> A((size_t)T*T),bb(T); int solved=0,fell=0;
  for(int p=0;p<NP;++p)for(int b=0;b<NB;++b){size_t base=((size_t)p*NB+b);float* out=&bank[base*T];
    if(g_pop[base]<T+20){out[T/2]=1.f;++fell;continue;}
    double* sA=&g_ATA[base*T*T];double* sb=&g_ATb[base*T];double diag=0;for(int i=0;i<T;++i)diag+=sA[(size_t)i*T+i];diag/=T;double lam=1e-3*diag+1e-6;
    for(int r=0;r<T;++r){bb[r]=sb[r];for(int c=0;c<T;++c)A[(size_t)r*T+c]=(c>=r?sA[(size_t)r*T+c]:sA[(size_t)c*T+r]);A[(size_t)r*T+r]+=lam;}
    if(solveSPD(A,bb,T)){for(int i=0;i<T;++i)out[i]=(float)bb[i];++solved;}else{out[T/2]=1.f;++fell;}
  }
  std::printf("  trained %d/%d (phase,bucket) filters (%d fallback)\n",solved,NP*NB,fell);
}
static void bankStats(const vector<float>& bank,const char* tag){
  const int NB=CFG.Buckets(),NP=CFG.Phases(),T=CFG.TapsPerPhase();
  double amean=0,mn=1e9,mx=-1e9,srmean=0;long n=0;int rows=NP*NB;
  for(int r=0;r<rows;++r){double s=0;for(int i=0;i<T;++i){float v=bank[(size_t)r*T+i];amean+=std::fabs(v);mn=std::min(mn,(double)v);mx=std::max(mx,(double)v);s+=v;++n;}srmean+=s;}
  std::printf("  %-10s |mean|=%.3f  min/max=%.3f/%.3f  per-filter-sum mean=%.3f\n",tag,amean/n,mn,mx,srmean/rows);
}

int main(int argc,char** argv){
  const char* camPath="D:/code/work/av-pipeline/camera_frame0.bmp";
  for(int i=1;i<argc;++i){if(!strcmp(argv[i],"--kbps")&&i+1<argc)g_kbps=atoi(argv[++i]);
    else if(!strcmp(argv[i],"--qmax")&&i+1<argc)g_qmax=atoi(argv[++i]);
    else if(!strcmp(argv[i],"--cam")&&i+1<argc)camPath=argv[++i];}

  // training data (loaded once): real camera frame (primary) + a sharp synthetic for robustness
  vector<float> cam; int cW=0,cH=0; bool haveCam=loadBMPLuma(camPath,cam,cW,cH);
  vector<float> synA,synB; makeSynthHR(synA,768,768,1); makeSynthHR(synB,768,768,2);
  std::printf("\n  CAMERA RAISR trainer (zltCRaisr structure, DIRECT) -- degradation = bicubic ÷scale + VP9 (kbps=%d qmax=%d)\n",g_kbps,g_qmax);
  std::printf("  train: %s + synth 768²\n", haveCam?"real camera":"(no camera bmp)");

  // Zoom ships 3 scale banks (Raisrx1/x2/x3); we train the two upscaling ones (x2/x3 — x1 is a same-size
  // sharpener, not used on the receive path where the tier is always < display). recv_superres picks by ratio.
  for(int scale : {2,3}){
    CFG.scale = scale;
    const int NB=CFG.Buckets(),NP=CFG.Phases(),T=CFG.TapsPerPhase();
    std::printf("\n  === x%d : %d buckets × %d phases × %d taps ===\n",scale,NB,NP,T);
    g_ATA.assign((size_t)NP*NB*T*T,0.0); g_ATb.assign((size_t)NP*NB*T,0.0); g_pop.assign((size_t)NP*NB,0);
    if(haveCam){ int w=cW&~1,h=cH&~1; vector<float> c((size_t)w*h); for(int y=0;y<h;++y)for(int x=0;x<w;++x)c[(size_t)y*w+x]=cam[(size_t)y*cW+x]; accumulate(c,w,h); }
    accumulate(synA,768,768);
    vector<float> bank; solveBank(bank);
    TrainedCamBank tb; tb.fromMemory(NP,NB,T,scale,bank);
    char path[256]; std::snprintf(path,sizeof path,"D:/code/work/bin2cpp-output/recon/raisr_cam_bank_x%d.bin",scale);
    tb.save(path);
    if(scale==2) tb.save("D:/code/work/bin2cpp-output/recon/raisr_cam_bank.bin");   // compat default
    std::printf("  saved -> recon/raisr_cam_bank_x%d.bin  (%zu floats)\n",scale,bank.size());

    auto evalOn=[&](const vector<float>& HR,int W,int H,const char* tag){
      vector<float> LR;int lw,lh; if(!degrade(HR,W,H,LR,lw,lh))return;
      PassthroughCam pb; CamRaisrUpscaler bil(CFG,&pb); CamRaisrUpscaler ra(CFG,&tb);
      vector<float> ob,orr;int ow,oh; bil.Upscale(LR.data(),lw,lh,ob,ow,oh); ra.Upscale(LR.data(),lw,lh,orr,ow,oh);
      vector<float> ref((size_t)ow*oh); for(int y=0;y<oh;++y)for(int x=0;x<ow;++x)ref[(size_t)y*ow+x]=HR[(size_t)y*W+x];
      std::printf("  %-20s bilinear=%.3f  camRAISR=%.3f  gain=%+.3f dB\n",tag,psnr(ob,ref,ow,oh,3),psnr(orr,ref,ow,oh,3),psnr(orr,ref,ow,oh,3)-psnr(ob,ref,ow,oh,3));
    };
    evalOn(synB,768,768,"HELD-OUT synth:");
    if(haveCam){ int w=cW&~1,h=cH&~1; vector<float> c((size_t)w*h); for(int y=0;y<h;++y)for(int x=0;x<w;++x)c[(size_t)y*w+x]=cam[(size_t)y*cW+x]; evalOn(c,w,h,"(train camera:"); }
    bankStats(bank,"OUR bank:");
  }
  std::printf("\n  ZOOM ref x2_A: |mean|=0.149  per-filter-sum=1.70  (our x2 lands in the same regime)\n");
  return 0;
}
