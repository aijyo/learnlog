# apps — two-process conference (sender.exe ⇄ real UDP ⇄ receiver.exe) + WPF monitor

The single-process conference (`conference/`) split into **two real OS processes** that talk over a
**real UDP socket**, with a **WPF (C#/.NET) monitor** that launches them, shows the receiver's live
decoded video, and mirrors both sides' stats — for debugging / watching the pipeline behave.

```
┌───────────── sender.exe (C++) ─────────────┐        ┌──────────── receiver.exe (C++) ───────────┐
│ synth/capture → preprocess → H.264 encode  │  UDP   │ recvfrom → frame assembler (by timestamp) │
│  → packetize → FEC → sendto 127.0.0.1:P    │ ─────► │  → FEC recover → H.264 decode → BGRA       │
│ writes SenderStats shared-mem              │  :50000│ writes ReceiverShare (frame+stats) shm    │
└───────────────────┬────────────────────────┘        └───────────────────┬───────────────────────┘
                    │  shared memory (named mappings, apps/include/apps/ipc_shared.hpp)             │
                    └──────────────────────►  AvpMonitor (WPF, C#)  ◄───────────────────────────────┘
                             reads both, draws the frame in a WriteableBitmap + stat panels
```

## Pieces
- **`ipc_shared.hpp`** — the POD shared-memory layout (Pack=4) both C++ and the C# monitor use.
- **`ipc_writer.hpp`** — C++ helper to publish a struct into a named mapping.
- **`frame_assembler.hpp`** — receiver-side reassembly: group UDP packets by frame timestamp, FEC-recover
  the missing source packets, emit the complete access unit.
- **`sender_main.cpp` / `receiver_main.cpp`** — one-way headless processes (reuse every pipeline module).
- **`peer_main.cpp`** — a **two-way** participant: one process that BOTH sends its own video AND
  receives+decodes the other peer's, like a real conferencing client. Two peers (A↔B) point at each
  other's ports; each publishes a `PeerShare` (send stats + the received frame).
- **`AvpMonitor/`** — the WPF app (`.csproj`, `App.xaml`, `MainWindow.xaml[.cs]`) — **two-way**: it
  launches two peers and shows each one's received video side by side.

## Build
```powershell
# C++ processes (need FFmpeg for the decoders):
cmake -S . -B build-ff -DAVP_WITH_FFMPEG=ON
cmake --build build-ff --config Release --target sender receiver peer
# WPF monitor (.NET 8):
dotnet build apps\AvpMonitor -c Release
```

## Run
**With the UI (recommended, two-way):** launch the monitor, press **▶ Start** — it spawns **two peers**
(A:50001 ⇄ B:50002 over real UDP) and shows each peer's received video **side by side** (left = what A
received from B, right = what B received from A, tinted blue/red so the two streams are distinguishable),
with per-peer stats below each.
The **loss slider, congestion-control checkbox, and link slider take effect LIVE** (no restart): the
monitor writes them into a control shared-memory block (`AvpControl`) that both processes poll each
frame, so you can drag the loss slider and watch FEC recovery / the decoded picture react in real time.
Tick **screen capture** to send your real desktop (DXGI/GDI, downscaled) instead of a synthetic frame.
A **live strip chart** at the bottom plots encode kbps / cc target / loss % over time (watch CC converge).
**■ Stop** writes a stop flag so the processes exit gracefully.
```powershell
dotnet run --project apps\AvpMonitor -c Release
# (the monitor launches the exes from build-ff\apps\Release — edit ExeDir in MainWindow.xaml.cs if elsewhere)
```
**Headless (no UI):**
```powershell
.\build-ff\apps\Release\receiver.exe --port 50000            # bind first
.\build-ff\apps\Release\sender.exe   --port 50000 --fps 15 --loss 0.06 --seconds 8 \
    [--source synth|screen] [--cc --link-kbps 800]          # --source screen sends the real desktop
```
**Two-way, headless (two peers):**
```powershell
.\build-ff\apps\Release\peer.exe --id A --local-port 50001 --remote-port 50002 --fps 15 [--source screen] [--cc]
.\build-ff\apps\Release\peer.exe --id B --local-port 50002 --remote-port 50001 --fps 15 [--source screen] [--cc]
```

## Verified (this machine)
```
cross-process UDP   sender -> 127.0.0.1:50000 -> receiver, 60 frames sent & all 60 decoded (4 s @15 fps)
FEC recovery        6% packet loss -> receiver rebuilt the dropped packets, 0 frames lost
shared memory       .NET reads the C++ mappings: SenderStats (frames/encode kbps/packets) and
                    ReceiverShare (frame_seq, frames/decoded/recovered, + a live 320x240 BGRA frame,
                    pixel-sum non-zero = real content). sender frame_index == receiver frame_seq (in sync).
WPF                 AvpMonitor builds (0 warnings) and reads those mappings via MemoryMappedFile —
                    the same path that paints the WriteableBitmap.
live control        control block written -> sender applied loss 10% then 25% WITHOUT restart
                    (cmdline said 5%); stop flag -> both processes exited gracefully.
screen capture      sender --source screen -> DXGI-DesktopDuplication, downscaled 320x240, sent cross-
                    process; receiver decoded real desktop (75 distinct pixel values = varied content).
WPF chart           strip chart (encode/cc/loss polylines) builds + renders; window launches (no crash).
two-way peers       peer A(:50001) ⇄ peer B(:50002) real UDP: each sent 43 frames, each decoded ~43;
                    routing correct — A received B's blue video (B=203,R=43), B received A's red (R=203,B=42).
                    Fix: SIO_UDP_CONNRESET disabled + 400 ms start delay so the first sender doesn't get
                    poisoned by an ICMP port-unreachable before the other peer binds. WPF two-way builds/launches.
```

## IPC layout (`ipc_shared.hpp`)
Three named mappings (`Local\Avp*`), POD, Pack=4: **SenderStats** (frame_index / encode kbps / packets /
bytes / cc target), **ReceiverShare** (frame_seq + counters + a 320×240 BGRA frame at offset 68), and
**ControlBlock** (loss_pct / cc_on / link_kbps / stop) — the monitor owns the control block and the two
C++ processes poll it every frame.

Two real processes, a real UDP socket between them, FEC recovering real loss, real H.264 decode, and a
live UI. Clean-room, following Zoom's *design*. For interop / education.
