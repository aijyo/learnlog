// screen_content.hpp — screen-content detection (AV_PIPELINE_DETAILS.html §3.4). Natural camera video
// and screen/UI content have opposite statistics, and the encoder should switch tools accordingly
// (Zoom routes screen share to AV1's SC core: palette / IntraBC / near-lossless, `(mode&0xF)==2`).
//
// Three cheap luma statistics separate them:
//   * flat_ratio       — fraction of blocks with near-zero variance (screen has big solid regions)
//   * sharp_edge_ratio — fraction of pixels on a hard step edge (screen has crisp text/UI edges)
//   * palette_ratio    — distinct luma levels / 256 (screen uses few, repeated levels; natural is smooth)
// minih264 (H.264 baseline) has no SC tools, so this emits an ADVISORY: which codec/mode to prefer.
#pragma once
#include "preprocess/video_convert.hpp"
#include <array>
#include <cstdint>

namespace avp {

struct ScreenContentStats {
  double flat_ratio = 0, sharp_edge_ratio = 0, palette_ratio = 0;
  double score = 0;           // 0 = natural, 1 = screen content
  bool   is_screen = false;
  const char* advice() const { return is_screen ? "screen-content -> prefer AV1 SC core (palette/IntraBC)"
                                                 : "natural video -> H.264/AV1 normal tools"; }
};

inline ScreenContentStats DetectScreenContent(const I420Image& img, int block = 16) {
  ScreenContentStats s;
  const int w = img.w, h = img.h; if (w < block || h < block) return s;
  const uint8_t* y = img.y.data();

  // flat blocks
  long flat = 0, nblk = 0;
  for (int by = 0; by + block <= h; by += block)
    for (int bx = 0; bx + block <= w; bx += block, ++nblk) {
      long sum = 0, sum2 = 0;
      for (int j = 0; j < block; ++j) for (int i = 0; i < block; ++i) {
        int p = y[(size_t)(by + j) * w + (bx + i)]; sum += p; sum2 += (long)p * p;
      }
      long n = (long)block * block, mean = sum / n;
      if ((sum2 / n - mean * mean) < 8) ++flat;      // variance < 8 ~ solid
    }
  s.flat_ratio = nblk ? double(flat) / nblk : 0;

  // sharp step edges (large horizontal gradient) + palette (distinct luma levels)
  std::array<int, 256> hist{}; long sharp = 0, npx = 0;
  for (int j = 0; j < h; ++j)
    for (int i = 0; i < w; ++i) {
      int p = y[(size_t)j * w + i]; ++hist[p]; ++npx;
      if (i > 0) { int d = p - y[(size_t)j * w + i - 1]; if (d < 0) d = -d; if (d > 48) ++sharp; }
    }
  s.sharp_edge_ratio = npx ? double(sharp) / npx : 0;
  int distinct = 0; for (int v : hist) if (v) ++distinct;
  s.palette_ratio = distinct / 256.0;

  // combine: screen = flat + sharp edges + small palette. Weights tuned for the two regimes.
  s.score = 0.45 * s.flat_ratio + 0.40 * (s.sharp_edge_ratio > 0.02 ? 1.0 : s.sharp_edge_ratio / 0.02)
          + 0.15 * (1.0 - s.palette_ratio);
  s.is_screen = s.score > 0.5;
  return s;
}

}  // namespace avp
