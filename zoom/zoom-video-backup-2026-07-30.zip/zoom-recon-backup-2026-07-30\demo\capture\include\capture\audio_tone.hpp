// audio_tone.hpp — a tiny WASAPI *render* helper that plays a sine tone on the default speaker.
// Used only to make the loopback capture path self-verifying: play a tone here while capturing the
// render endpoint in loopback, and the captured signal proves the loopback leg end-to-end. This is
// the render mirror of audio_wasapi.hpp (IAudioClient shared mode + IAudioRenderClient fill loop).
#pragma once
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <cmath>
#include <cstdint>
#pragma comment(lib, "ole32.lib")

namespace avp {

// Play a `freq`-Hz sine for `secs` seconds on the default render endpoint (blocking).
// Returns false if the endpoint couldn't be opened. Handles float32 and 16-bit PCM mix formats.
inline bool PlayToneBlocking(double secs, double freq = 440.0, double amplitude = 0.25) {
  bool co = SUCCEEDED(CoInitializeEx(nullptr, COINIT_MULTITHREADED));
  bool ok = false;
  IMMDeviceEnumerator* en = nullptr; IMMDevice* dev = nullptr;
  IAudioClient* client = nullptr; IAudioRenderClient* render = nullptr; WAVEFORMATEX* mix = nullptr;
  do {
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
                                __uuidof(IMMDeviceEnumerator), (void**)&en))) break;
    if (FAILED(en->GetDefaultAudioEndpoint(eRender, eConsole, &dev)) || !dev) break;
    if (FAILED(dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&client))) break;
    if (FAILED(client->GetMixFormat(&mix)) || !mix) break;

    const REFERENCE_TIME buf = 2000000;  // 200 ms engine buffer (100-ns units)
    if (FAILED(client->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, buf, 0, mix, nullptr))) break;
    if (FAILED(client->GetService(__uuidof(IAudioRenderClient), (void**)&render))) break;

    UINT32 total = 0; if (FAILED(client->GetBufferSize(&total))) break;
    const int    ch    = mix->nChannels;
    const int    sr    = (int)mix->nSamplesPerSec;
    bool is_float = (mix->wFormatTag == WAVE_FORMAT_IEEE_FLOAT);
    if (mix->wFormatTag == WAVE_FORMAT_EXTENSIBLE && mix->cbSize >= 22)
      is_float = (reinterpret_cast<WAVEFORMATEXTENSIBLE*>(mix)->SubFormat == KSDATAFORMAT_SUBTYPE_IEEE_FLOAT);

    uint64_t phase = 0;  // integer sample index -> stable phase across buffer fills
    auto fill = [&](BYTE* p, UINT32 frames) {
      for (UINT32 i = 0; i < frames; ++i) {
        double s = amplitude * std::sin(2.0 * 3.14159265358979 * freq * double(phase) / sr);
        ++phase;
        for (int c = 0; c < ch; ++c) {
          if (is_float) { *reinterpret_cast<float*>(p) = (float)s; p += 4; }
          else          { *reinterpret_cast<int16_t*>(p) = (int16_t)(s * 32767); p += 2; }
        }
      }
    };

    BYTE* p = nullptr;
    if (FAILED(render->GetBuffer(total, &p))) break;
    fill(p, total); render->ReleaseBuffer(total, 0);
    if (FAILED(client->Start())) break;

    const ULONGLONG stop = GetTickCount64() + (ULONGLONG)(secs * 1000);
    while (GetTickCount64() < stop) {
      Sleep(10);
      UINT32 pad = 0; if (FAILED(client->GetCurrentPadding(&pad))) break;
      UINT32 avail = total - pad;
      if (avail && SUCCEEDED(render->GetBuffer(avail, &p))) { fill(p, avail); render->ReleaseBuffer(avail, 0); }
    }
    client->Stop();
    ok = true;
  } while (false);

  if (mix) CoTaskMemFree(mix);
  if (render) render->Release();
  if (client) client->Release();
  if (dev) dev->Release();
  if (en) en->Release();
  if (co) CoUninitialize();
  return ok;
}

}  // namespace avp
#endif  // _WIN32
