# Zoom 音视频栈 逆向 + Clean-room 复现 — Session 成果总结

> 目标:参考 Zoom 的媒体处理管线,在 `av-pipeline` 里做一个**可运行、逐模块对齐 Zoom RE'd 值**的双向会议 demo。
> RE 依据:IDA(`zlt.dll`/`zlt.i64`)+ RenderDoc + D3DReflect/D3DDisassemble。demo 代码:`D:\code\work\av-pipeline`;RE 重建:`D:\code\work\bin2cpp-output\recon`。

---

## 0. 标准与约束(全程遵守)

| 约束 | 含义 |
|---|---|
| **Clean-room** | 绝不粘贴 Zoom 反编译/专有代码。理解算法后**自己写**;恢复精确数值参数(权重/阈值)是允许的——它们是事实。 |
| **fidelity-no-invention** | 每个选择都跟随 Zoom RE'd 值,不臆造参数。标注 **实证**(反编译直接可见)/ **推断**(结构推理)。 |
| **边界** | ✅ 可参考重写 = 算法/结构/常量 + **CPU SIMD 核(Zoom 自家 x86)**;⛔W = 神经网络权重(自己训);⛔K = 第三方编解码/DSP 核(用 libvpx/libaom/libx264/Opus);⛔S = 编译后的 GPU shader(RE 算法后自己写 HLSL)。 |

---

## 1. 全景:管线模块地图

发送侧:`采集 BGRA → BGRA→I420 → 降噪 → VFX 感知增强 → 自适应QP → 编码 → RTP/UDP`
接收侧:`解包/FEC/NACK → 解码 → DCC → Chroma上采样 → 接收端超分(RAISR) → 显示(双缓冲)`

| 模块 | Zoom 组件 | 我们的实现 | 状态 |
|---|---|---|---|
| 缩放/下采样 | zlt ns_vpp polyphase scaler | `recon/zlt_resample.hpp` + `apps/resample.hpp` | ✅ 精确核 |
| 降噪 | zltCIIRDenoise | `algo/zlt_denoise.hpp` + `mc_denoise.hpp` | ✅ |
| 自适应 QP | TextureMotion 逐帧自适应阶梯 | `algo/zlt_adaptive_qp.hpp` | ✅ **逐位** |
| Sharpen | zltCSharpen | `recon/zlt_vfx.hpp` | ✅ **精确核** |
| CLAHE | zltCCLAHE | `recon/zlt_vfx.hpp` | ✅ 结构精确(钳位 [16,235]/[0,255]、clip 配置) |
| DCC(=DCCI 上采样) | zltCDCC | `recon/zlt_dcci.hpp` | ✅ 算法+常数(边缘定向 2× 上采样,非对比) |
| Light 自动亮度/逆光 | zltCLightAdaption | `recon/zlt_vfx.hpp` | ✅ **精确(逆光检测级联)** |
| Color 自动白平衡 | zltCColorAdaption | `recon/zlt_vfx.hpp` | ✅ 结构(4×4 LUT + gray-world) |
| 编码 | zlt 编码族(libx264/265)/ zbt AV1 SC | avcodec 工厂 | ✅(用标准库,⛔K) |
| §9 自适应 | mcm 码率/梯度大脑 | `recon/mcm` + `AdaptationController` | ✅ |
| 传输 | RTP + NACK + FEC + PLI/FIR | `transport/` 真 UDP | ✅ |
| Chroma 上采样 | CChromaUpsample(导向滤波) | JBU + `recon/zlt_chroma.hpp` | ✅ JBU + Zoom-exact 导向滤波 |
| 屏幕超分 | zltCScreenRAISR(48桶,2×) | `recon/raisr_gpu.hpp` | ✅ GPU |
| 相机超分 | zltCRaisr(22桶,x1/x2/x3) | `recon/raisr_cam_gpu.hpp` + `zlt_raisr_camera.hpp` | ✅ GPU |
| A/B 双 bank | RAISR 4 shader / A≠B | — | ❌ 静态不可解 |
| 注意力光(ROI 前端) | zltCAttentionLight | 用自有人脸框当 ROI | ⛔W 边界(已定性,喂 LightAdapt) |
| 颜色空间转换 | zltCColorSpaceCvt | 标准 CSC | ✅ 新发现(可复现) |
| 边缘保持平滑 | GuidedFilter(已用于 chroma)/ RecursiveBF | `recon/zlt_chroma.hpp` | ◻ RecursiveBF 未接 |
| 虚拟背景/分割 | Zoom segmentation | (独立子项目 xseg) | ❌ 本 session 未接 |
| 音频 | Opus + 3A(ANS/AGC) | `audio_preprocess.hpp` + Opus | ✅(基础) |

---

## 2. 发送侧:编码前处理(ns_vpp)

### 2.1 缩放 / 下采样 — ✅ 精确核

**Zoom 做法(实证)**:polyphase 可分离重采样器。
- 默认核 = **bicubic Keys a=−0.5(即 Catmull-Rom)**,`sub_1801BCCA0`。
- 备选 = **Lanczos-4**,`sub_1801BCE40`。
- **尺度自适应抗锯齿**:下采样时把核支撑宽度按 `2·max(1, src/dst)` 展宽,`sub_1801BC400`。
- **Q14 定点**(÷16384)int16 归一化,`sub_1801BCF00`;SIMD 分发。

**我们的实现**:`recon/zlt_resample.hpp`(3 核含 Lanczos-4)→ 移植到 `apps/resample.hpp` 的 `ResizeBGRA`(Catmull-Rom + BuildAxis 支撑展宽 + 可分离)。15/15 单测过。demo `downscale()` 用它(保 letterbox)。

**优劣**:✅ Catmull-Rom 比 bilinear 锐利、比 Lanczos 便宜、无振铃;抗锯齿展宽避免下采样摩尔纹。⚠️ 比纯 Lanczos-4 在极端下采样时细节略少(Zoom 也默认 Catmull-Rom,权衡一致)。

**对比 works_on_rs(Agora)**:对方用 avir CLancIR(Lanczos 类),质量相近但**没有多档 downscale 逻辑**;我们对齐了 Zoom 的多档 + 抗锯齿。

### 2.2 降噪 — ✅

**Zoom**:`zltCIIRDenoise`,时域递归 IIR,α≈0.37(实证)。
**我们**:`zlt_denoise.hpp`(纯 IIR)+ `mc_denoise.hpp`(**运动自适应**:静止区时域、运动区空域 → 无拖影)。屏幕源不降噪(无传感器噪声,避免滚动拖影);相机源开运动自适应。

**优劣**:✅ 运动自适应消除了纯 IIR 的运动拖影;❌ 比学习式降噪弱(但那需 ⛔W 权重)。

### 2.3 自适应 QP — ✅

**Zoom(逐位深挖 `sub_1800E7A00/E7680/E7610`)**:TextureMotion **不给块打离散标签**,而是对两个每块度量(纹理 obj+104 / 运动 obj+112)做**逐帧自适应阶梯**:
- 阈值逐帧算:`thr[i] = 帧均值 × mult[i] + 1`(固定的是 6 个 double 乘数,表 `qword_1803FBDB0`/`FBDE0`,按模式索引)——「繁忙」相对本帧平均块;
- 阶梯:`level = −3 + count(度量 ≥ thr[i])` ∈ [−3,+3];每块 `delta = texLevel + motLevel`(mode 门控);
- 人脸/文字的细-QP 偏置是**另一条策略** `zltCRoiAdaptQuant`(吃 ROI 图),在 `zltCBuQpCalc` 下游合并 —— 不在 TextureMotion 里。

**我们**:`zlt_adaptive_qp.hpp` 已从「固定 6 档」升级为**逐帧自适应**(`BuildLadder` 逐位复现 `sub_1800E7610`,行为测试 PASS:busy→+3、flat→−6、`帧均值100→thr{26,76,101,151,251,401}`),已同步 demo 副本;相机 H.264/265 用 `ext_qp_map` 驱动(编码器自带 AQ 关,QP [20,40] 实证)。

**sibling 策略族(深挖 b)**:
- 全族**共用同一阶梯原语**,只是喂的度量不同——纯纹理变体 `sub_1800E78C0` 与 `sub_1800E7A00` 逐字节相同、只少运动轴;策略经 `0x180527960` 的打包 32-bit RVA 表派发。
- **Static/Background** `sub_1800E8C90` 是另一套:**邻域空间扫描** + 活动度阈值 `clamp(2.5×frame_param[obj+396], 11468, 16384)`,非简单 staircase。
- **Roi** `sub_1800EBD70`(0x80B)= **ROI 图驱动**(存外部掩码指针 obj+16/+24;掩码来源 = ⛔W 检测边界,喂自有 ROI 图);三者偏移图在 `zltCBuQpCalc` 叠加。

**残差**:① 两个度量的最内层算式([推断] 空间活动度/时域差,编码分析虚调用 `obj+32→slot+8/+16`,⛔K-adjacent);② Static/Background 的邻域扫描体(结构级,阈值 `[11468,16384]` 已拿)。

### 2.4 VFX 感知增强(本 session 重点)

顺序(Zoom 链序):**全局 Light → Color → 局部 CLAHE → Sharpen**(发送侧);接收侧 **DCC**。全部在 `recon/zlt_vfx.hpp`(clean-room)。

#### 2.4.1 Sharpen(zltCSharpen)— ✅ **精确核**

**Zoom(实证,`sharpen_re2.py`)**:6 个核(scalar+SSE+AVX2 × blur+unsharp),`sub_1801ABCA0/ABB90`(标量)+ `sub_180391440/391760`(SIMD)。算法:
1. **3×3 高斯/二项式模糊** `[1 2 1; 2 4 2; 1 2 1]/16`(**不是 box**);
2. **带阈值的 unsharp**:`out = Y + (gain·detail)>>7`,仅当 `|detail = Y−blur| > threshold`;`gain/threshold` 打包在对象 +16 的 hi16/lo16(config-driven,定点 /128 格式精确)。

**我们**:逐位复现该核(高斯 /16 + 阈值 unsharp /128)。gain 默认相机 0.30 / 屏幕 0.60,threshold 4。

**优劣**:✅ 高斯基比 box 基振铃更少;阈值门控避免放大平坦区噪声;定点与 Zoom 一致。⚠️ 强度过高仍会在压缩视频上放大块效应(→ 见 2.4.6 内容分流)。

#### 2.4.2 CLAHE(zltCCLAHE)— ✅ 结构精确

**Zoom(实证,`clahe_dcc_re.py`,核 `sub_1801E0820`)**:栈变量直接暴露结构 —— `int v78[256]` 直方图、`__int128 v79[64]` = **8×8 = 64 个 tile**、`int v80[256]` CDF/映射;luma 钳位 254/255;clip 参数 ≈4;单/多线程在 235520 像素处分流。
**我们**:8×8 网格 / 256-bin / clip-limited 直方图均衡 + tile 间双线性混合。**结构与 Zoom 完全一致**。修过一个 bug:整数 `add=excess/256` 在窄输入下截断为 0 → 变暗;改用浮点重分配。

**优劣**:✅ 局部对比、暗部/背光提升,对文字/文档极好;❌ 对人脸会放大皮肤不均(→ 内容分流)。

#### 2.4.3 DCC(zltCDCC)— ✅ 算法+常数(重大纠正:不是对比,是上采样器)

> DCC 被**误判了两次**(先"动态对比"、后"局部对比",都错)。读通 **scalar 核 `sub_1801E1C10`**(可读 C)后确认:**zltCDCC = Directional Cubic Convolution Interpolation(DCCI),边缘定向 2× 上采样器**——渲染链的 "Upsample",喂给 RAISR(解码 LR → DCC 2× → RAISR 精修)。详见 §5.4。

**Zoom(实证)**:Transform `sub_1801E16A0` 分配 4 个梯度平面,调 3 组核:梯度(obj+0x10)、**luma 上采样(obj+0x18 = scalar `sub_1801E1C10`)**、chroma(obj+0x20,U/V 各一次)。scalar 明文:LR 放进偶/偶网格,再对每个空洞:
```c
if(100*G1<=115*G2){ if(100*G2<=115*G1) v=(a+b+c+d+2)>>2; else v=(9*(a+b)-c-d)>>4; }
else v=(9*(e+f)-g-h)>>4;   // 9,-1 权重 = [-1,9,9,-1]/16 半像素三次
```
精确常数:**比率 1.15**(100/115)、三次核 **[-1,9,9,-1]/16**、轴向遍阈值 575/800 与 920/500 + 8/5。Transform 里的 {15,47,6,100,128,32} 是**对齐/校验/看门狗**常数(16 对齐掩码、malloc pad、最小高度、100 帧看门狗、32 对齐),**不是曲线参数**。

**我们**:`recon/zlt_dcci.hpp`(`recon::dcci::Upscale2x`),Zoom 精确决策常数 + 三次核;chroma 用 `Upscale2xBilinear`。删除了错误的 `recon::vfx::Dcc`。验证:2× 对角边缘比 bilinear 明显更锐、少锯齿(dump 图)。

**优劣 / 精确度**:✅ 文字/线条边缘锐利无振铃,强于 bilinear。**逐-cell 梯度公式(|TL−BR| \ / |BL−TR| /)、决策比率 1.15、三次核 [-1,9,9,-1]/16 全是 Zoom 精确值**。唯一残差:Zoom apply 用 9-tap 窗口求和(偏移在混淆指针算术里),我们用经典 DCCI 7-tap,功能等价(仅边界像素级差异)。

#### 2.4.4 LightAdapt(zltCLightAdaption)— ✅ **精确(逆光检测,2025-07 深挖修正)**

> **修正**:之前记为「多分辨率 luma 直方图 + Shannon 熵 → 拉向 128 的 gamma」是**错的**。逐位深挖(`_ida_t3.py`/`_ida_t3b.py`)后确认它是一套**逆光检测 + 暗部提亮**,度量是**几何均值**而非算术均值。

**Zoom(实证,Transform `sub_1801BF500`,决策核 `sub_1801C1350`/`sub_1801C1100`/`sub_1801C11D0`)**:
- **分辨率档**:`min(w,h)` ≥720→子采样 shift 3、≥360→2、≥180→1、else 0;
- **注意力集成** `sub_1801C11D0`:归一化人脸/ROI 框 clamp[0,1]→像素,拒绝 <1/64 面积,¼/⅛ 内缩,自适应子采样使 ROI 直方图 ≤200 采样;
- **决策核** `sub_1801C1350`:算**几何均值亮度**(Reinhard 对数平均,`sub_1801C1100` = `exp(Σ h[i]·log i /(N−h[0]))`,255 项 log 系数表)+ **Shannon 熵** `−Σ p·log2 p`;
- **触发级联 [实证]**:`ROI 几何均值 ≤ 100`(暗主体)**且** `整帧高光占比(bins 240..255)≥ 10%` **且** `整帧几何均值 ≤ 170` → 置「逆光→提亮」标志。像素色调映射由 SIMD 派发(`a1+56` 或 `*(a1+160)+216`,2 变体),曲线抽头在 ⛔S 核内。

**我们**:`recon/zlt_vfx.hpp` 重写为 `LightAdaptROI(...)` + 几何均值/熵原语 + 整帧 `LightAdapt` overload(向后兼容,已同步到 demo 副本;非逆光时**不动** = 忠实)。**行为测试 PASS**:逆光样张(暗主体+亮背景)主体提亮 185.5→191.4,普通均匀帧与「暗但无高光」帧均保持不变。

**优劣**:✅ 精准命中逆光、不误伤正常帧(比旧的「拉到 128」忠实得多);曲线形状 [推断](SIMD 派发核,触发级联是 [实证])。

#### 2.4.5 ColorAdapt(zltCColorAdaption)— ✅ 结构

**Zoom(实证,Transform `sub_1801CB090`,核 `sub_1801CBD10/CBFC0`)**:U/V 在 **4:2:0 半分辨率**上做定点邻域加权 chroma 重映射 `((25·a + 128·b + 13·c + 64)>>7) − bias` 拉向中性 127/128 —— 本质是 **gray-world 白平衡**。
**我们**:chroma 均值按 strength 拉向 128。验证:U 113→124,V 146→133。

**优劣**:✅ 消色偏、白平衡;⚠️ 纯 gray-world 对大面积单色场景会误纠(strength 0.35 已限幅;屏幕内容不做——见下)。

#### 2.4.6 内容分流(本 session 关键工程修正)— ✅

**问题**(用户实测发现):把 CLAHE + DCC + Sharpen0.6 无差别套到**低码率压缩人脸**上,放大的是压缩块效应+皮肤不均+噪点 —— **越增强越糟**。
**量化**:高频伪影粗糙度(块缝+噪点)旧链 1.90→**15.52(×8.17)**;新链 1.90→2.20(×1.15)。

**修复**(`peer_main.cpp`):
| 内容 | 链 |
|---|---|
| 相机(人脸) | 降噪 + LightAdapt(0.40) + ColorAdapt(0.35) + **轻 Sharpen(0.30)**,**不做 CLAHE/DCC** |
| 屏幕/文字 | CLAHE(clip 3) + Sharpen(0.60)(发送);收侧另有 DCC=DCCI 边缘定向上采样 |

**为什么**:CLAHE/DCC/强锐化是文档/文字的局部对比+细节工具,Zoom 也不拿 CLAHE 怼人脸。**教训:感知"增强"必须按内容分型;放大压缩伪影的增强不如不加。**

#### 2.4.7 新发现 + 修正(T3/T5,2025-07)

- **`zltCColorSpaceCvt`(vft 0x180505518)— ✅ 补上颜色转换缺口**:像素格式/色彩空间转换器。slot2 `sub_18023D890` → 格式对派发 `sub_18023DEC0/E100` → SIMD 转换核(YUV↔RGB / 打包↔平面)。标准可复现 CSC。
- **`zltCAttentionLight`(vft 0x180505040)— ⛔W 边界**:给 LightAdapt 喂人脸/主体 ROI 框的**注意力/显著性前端**(= `ssb_media_client_extension_face_detector`;slot3 配置门 a3[3]==16/a3[5]==3328)。学习式定位 → **不搬权重,用我们自己的人脸框当 ROI 输入**。
- **CLAHE 钳位修正**:apply `sub_1801E10F0` 的 luma 钳位是 **range-flag 驱动**——`[16,235]`(TV/限定)或 `[0,255]`(全域),由帧色彩范围字段 `*(hdr+124)` 选,**不是**之前记的「254/255」;**clip 是配置项**(SetConfig cmd `0x70004`→obj+312),非硬编码。
- **ColorAdapt 补充**:apply `sub_1801CB090` 从常量种子表 `qword_1804174C0`(灰阶对角初始化)构建 **4×4×192B 颜色校正 LUT** 再 SIMD 应用(gray-world 意图不变)。
- **感知 QP 族(T5 定位 → TextureMotion 轴已升逐位)**:`zltCRoiAdaptQuant`/`BackgroundAdaptQuant`/`TextureMotionAdaptQuant`/`ComAdaptQuant`/… 是相邻 vtable 的策略族,经 `zltCBuQpCalc`/`zltCParamEstMethods` 汇入每-CU QP。**TextureMotion 已逐位**(逐帧自适应阶梯 `thr[i]=帧均值×mult[i]+1`,`level=−3+count(≥thr)`,见 §2.3)。**残差收窄**:① 两个度量的最内层算式([推断]),② Roi/Background/Static 的判定阈值(结构级)。

---

## 2.5 内容分析簇 —— video-in-share 空间检测(深挖 b,2025-07)

**问题**:§4.2 的 video-in-share 之前只有「模式切换 [实证意图]」,demo 用整帧 SceneChange 分数当代理。深挖后确认 Zoom 是**空间区域检测**——框出共享画面里"正在放视频"的那块。RE'd 一整个 `ns_codec` 协作检测簇:

| 类 | 角色 | 关键 [逐位] |
|---|---|---|
| `zltCContentDetect` | 异步编排器 | 后台工作线程(mutex/condvar,1000ms 超时),委托 `+176` 子检测器;不占编码关键路径 |
| `zltCTextVideoPartition` | 容器/编排 | 分析 320×180 + 160×90;最小区域 256px;30 帧窗;双缓冲;内嵌运动场引擎 |
| `zltCGlobalMotionDetect` | 核心 | 16×16 块运动标签(7=动)→ 列/行投影求框(列≥5/行≥10/gap<8)→ 全局运动门 → 确认 `12·动≥总` & `动≥30` |
| `zltCStaticDetection` | 静态判定 | 每块活动度 vs `3072×块列` 参考;≤15 块判活跃 |
| `zltCMotionMaskDetect` | 掩码 | 降采样(位移对齐 32/16,cmd 0x70005)+ 委托生成运动掩码(格式码 3328) |
| `zltCFlashDetection`(ns_vpp) | 闪光 | 全局亮度突变/切场检测 |

**我们**:clean-room 重构 `recon/zlt_content_analysis.hpp`(`DetectVideoRegion`/`StaticDetection`)—— 投影求框 + 全局运动门 + 区域确认全逐位;**行为测试 PASS**(静态帧内嵌 288×288 运动区 → 框出 272×272;纯静态不触发;整帧运动被门挡;static 判定正确)。
**残差 [推断]**:每块运动标签算式(标签 7 的来源,上游块分析,⛔K-adjacent,同自适应-QP 度量残差);count_A/count_B 全局运动门精确数学 + MotionMask/Flash 完整体到结构级。

---

## 3. 编码(codec)— ✅(标准库,⛔K 边界)

**Zoom**:zlt 编码族 = libx264/libx265(相机);zbt = **libaom AV1 屏幕内容编码**(IntraBC);libvpx VP9。
**我们**:avcodec 工厂选 av1/vp9/h264/h265。⛔K 边界 —— 编解码核用标准库,不自己写。内容自适应:AV1 sharp text = good-mode + qmax 14(慢,~8fps);smooth video = realtime + qmax 40(快)。H.264 QP [20,40](实证,qmin=20 是质量帽,简单场景欠码率而非填满 = 跟内容走,像 Zoom)。

---

## 4. 传输 + §9 自适应 — ✅

**§9 自适应**:`recon/mcm` 大脑 + `AdaptationController`,梯度 L1–L4;上报周期 **kScoreReportPeriodMs=9800ms**(实证,0x2648);G.107 MOS 评分。弱网时**分辨率+帧率+码率一起降**(如降到 270p@10),牺牲清晰保流畅。

**拥塞控制架构(T4,2025-07 实证,推翻错误前提)**:Zoom 视频码率**不是**客户端 Google GCC。穷举扫描 mcm.dll/nydus.dll **没有** trendline 估计器 / overuse 检测器 / AIMD——GCC 三件套在客户端不存在。真相是**服务端中介的离散档**:
- 客户端(接收侧)只上报**原始 QoS**(cmd 301:loss/fec/plc/jitter/abs_net_delay);
- `net_score{0..5}`/`bw_level{1..4}` 决策在**服务端/配置**(`Configrate*` 钩子),**没有客户端函数计算它**——mcm 只是**路由**这个值(3 个相同搬运节点 `sub_180057A10`/`sub_1800D8310`/`sub_1801D09A0`,按 `值>>10` 红黑树定位流);
- 反馈 = `app_uplink_net_score_t` = **ssb PDU id 85** [实证:构造 `sub_18000D600` `*(pdu+8)=85`,net_score dword@+24,属性 `mc_up_bw_level`∈{1,2,3,4};解析 `sub_180041360`];
- 发送端 bw_level → 目标码率 → `zltCVideoRateCtrl`(T1) → QP+FEC。
- **结论**:指标→档位阈值是真实的**逆向边界**(服务端,不在客户端二进制),不臆造;`recon/mcm/mcm_channel.hpp` 的 `NetScore(0..5)`/`BwLevel(1..4)`/PDU 85 已**逐位确认**,`ScoreFromMos`/`BwFromScore` 明标为 demo 替身(非 Zoom 真值)。
**传输**:真 UDP;NACK 重传;FEC;PLI/FIR(Zoom SetKeyPictureRequest,解码失败/join 请关键帧);抗撕裂**双缓冲**(DXGI swap-chain SafePresent front/back 类比)。

**弱网加固(2026-07,针对"相机 6% 丢包屏幕乱码")** — 乱码根因是**丢包超 FEC → 丢帧 → H.264 帧间错误传播**(synth 小帧扛得住、camera 大帧中招)。两项修复:
- **① 稳健 FEC(编解码无关)**:每组校验数从旧的定值 R≈3 改成随丢包+组大小算的 **mean + 3σ 尾部余量**(`peer_main.cpp`),关键帧更小组+额外校验。6% 下每组不可恢复概率从 ~1.5% 降到 ~0.03%(50×)。实测 camera 6% 解码错 **多个→0**、画面由乱码→干净;15% 极限下也仅 1 错、画面完好。
- **② intra-refresh / GDR(libx264 路径)**:`zlt_codec.hpp` 给 libx264 开 `intra-refresh=1`,用移动帧内刷新波取代大 IDR → 错误传播**限制在 ≤1 刷新周期**、包更均匀不易丢(avcodec 不暴露逐帧 LTR,GDR 是这条路径可行的 LTR 等价物,也是 WebRTC/Zoom 的弱网手段)。

---

## 5. 接收侧:解码 → 显示

### 5.1 Chroma 上采样 — ✅(JBU + Zoom-exact 导向滤波,两个都有)

**Zoom(实证,反汇编 `sh_804dec70` 754 指令 compute)**:`CChromaUpsample` = **luma-guided 的 GUIDED FILTER(He 2010 导向滤波)**。逐位恢复:
- 引导 I = Y(2×2 平均下采样到 chroma 做统计,全分辨率做输出),输入 p = U/V,窗口 **3×3(N=9)**;
- `a = (9·ΣYU − ΣY·ΣU)/(9·ΣYY − ΣY² + ε)`,**ε=105.3405**;`b = (ΣU − a·ΣY)/9`;输出 `U_hr = a·Y_hr + b`(**Q9 定点** `(a·512·Y + b·512 + 256)>>9`);
- **边缘/稳定门控**:仅当 tile 有**饱和色边缘**(`(minU<96 || maxU>160) && (maxU−minU>4)`)才导向,方差过低(阈值 5625/11250)时逐像素回退 bilinear——平坦引导下 a 不可靠。

**我们**:① 保留原有 **JBU 联合双边**(`recv_superres.hpp`,512-entry range LUT,sigma 16);② 新增 **Zoom-exact 导向滤波** `recon::chroma::GuidedUpsample`(`recon/zlt_chroma.hpp`),ε/N/Q9/门控全按上面精确值。验证:luma 边缘处 chroma 边缘**精确吸附**(过渡宽度 0,锐度 80 vs bilinear 40),零色渗,与 Zoom 行为一致。

**优劣**:JBU = 我们的增强(range LUT 更平滑);导向滤波 = **Zoom 精确复现**(边缘吸附最干净)。已接成**运行时切换**:AvpMonitor 「导向 chroma」复选框(控制块 reserved[1])实时切 JBU↔导向,可 A/B(屏幕 RAISR 路径生效;低方差 cell 回退 JBU)。

### 5.2 接收端超分 RAISR

RAISR = 结构张量梯度 hash → 分桶的学习式线性滤波。**⛔S 边界**:编译后的 GPU shader 不复制,RE 算法后自己写 HLSL;**⛔W 边界**:学习权重自己训。

#### 屏幕 RAISR(zltCScreenRAISR)— ✅ GPU
- **48 桶**(12 角度 × 2 强度 × 2 相干性),单 **2×**(ScreenRaisrx2),运行时纹理 bank。
- 我们:`recon/raisr_gpu.hpp`(D3D11 compute)+ `raisr_bank.bin`。

#### 相机 RAISR(zltCRaisr → CGPURaisr)— ✅ GPU
- **22 桶**(11 角度 × 2 强度,**无相干性**),**3 尺度 x1/x2/x3**,phases=scale²,taps **13**(x2/x3)/ **25**(x1),**DIRECT 约定**(LR-patch→HR-subpixel),**时域** `g_refLuma` 变化检测。
- 我们:`recon/raisr_cam_gpu.hpp`(2 passes:A=LR→scale× RAISR luma,B=resize+JBU chroma+YUV→BGRA)+ `zlt_raisr_camera.hpp`(CPU 参考)。GPU/CPU 逐像素校验 mean|diff|=1.6。x2/x3 bank 都训了。
- **DX/DY 13-diamond 顺序**必须与 CPU PatchOffsets 一致(踩过坑:顺序错 → mean|diff|=36,修正后 1.6)。

#### SelectScale 门控(zltCRaisr cmd3,`sub_1801B8EA0`)— ✅
- 源 ≥720p → 不超分;断点 180p/480p/720p 像素数 + 1.18× 比率;**相机 mode1 ≤480p,屏幕 mode3 ≤720p**。
- 意义:**弱网降到低分辨率时超分才介入**(把降档丢的清晰度找回);网络好时源本清晰,RAISR 不介入。这是完整闭环。

#### RAISR 性能看门狗 — ✅(实证)
- **15ms/帧预算**,32 帧窗口,320 帧周期,**2 次超支自禁用**,60s 重置。

**优劣**:✅ 弱网下显著恢复清晰度(GPU ~7ms);学习式滤波比 bilinear 锐利且无振铃。⚠️ bank 是屏幕训的,相机需自己的 bank(已训 x2/x3);A/B 双 bank 未解(见下)。

#### A/B 双 bank — ❌ 静态不可解
- 4 个唯一 RAISR shader(各 1 filterBuckets),x3 时 A==B,descriptor 延迟绑定 → **静态分析不可解**;需 RenderDoc 对**运行中开启相机 RAISR 的 Zoom** 动态抓帧。工具已备(`renderdoccmd convert -c xml` headless),**gated 在用户抓一帧实时 Zoom**。

### 5.4 DCC = DCCI 边缘定向 2× 上采样(见 2.4.3)— ✅

Zoom 渲染链的 "Upsample" 就是 zltCDCC = DCCI(不是对比)。已接入 demo 收侧:**屏幕内容 + RAISR 关闭 + 解码 ≤1280** 时,用 `recon::dcci::Upscale2x`(Y,边缘定向)+ `Upscale2xBilinear`(U/V)做 2× 后再 resize 到显示分辨率,替代纯 bilinear。相机走干净 bilinear(人脸不需要边缘锐化)。RAISR 开启时由 RAISR 负责上采样,DCCI 不介入。实测:屏幕文字上采样后清晰可读、不崩、非黑。

---

## 6. 音频 — ✅(基础,本 session 非重点)

**Zoom**:Opus 编解码 + 3A(ANS 降噪 / AGC 增益 / AEC 回声)。
**我们**:`audio_preprocess.hpp`(ANS/AGC)+ Opus;真麦(--mic)、外放(--play)、A/V 同步(av_sync_ms)。**未做**:AEC 回声消除、Zoom 音频 RE 深挖(本 session 聚焦视频)。

---

## 7. Demo 基础设施(本 session)

| 事项 | 说明 |
|---|---|
| **内容分流 VFX** | 相机/屏幕不同增强链(见 2.4.6) |
| **⚙ 配置窗口** | `ConfigWindow.xaml(.cs)`:6 个 VFX 强度滑块(light/color/相机sharpen/屏幕sharpen/clahe/dcc),`VfxConfig` 类,默认/取消/确定;Start 时拼成 `--vfx-*` flag 传给 peer.exe(InvariantCulture 避免 `0,30`) |
| **Start/Stop 切换按钮** | 合并成单个 `RunBtn`(绿 ▶Start ↔ 红 ■Stop),状态+颜色切换 |
| **配色** | 深色调色板 + 圆角按钮 + 悬停/按下反馈 + 统一文字/复选框色 |
| **peer.exe --vfx-* flag** | `peer_main.cpp` 加 6 个覆盖内部默认的 flag,运行时可调 |

---

## 8. 没做的 + 为什么

| 未做 | 为什么 |
|---|---|
| **A/B 双 bank 分解** | descriptor 延迟绑定 → 静态不可解;需用户对实时 Zoom 抓 RenderDoc 帧(已 gated) |
| **DCC 曲线常数 {15,47,6} 逐位** | 埋在大 SIMD 核 `sub_1803A3540`;局部对比结构已对,逐位收益低,留可选 |
| **AttentionLight / GuidedFilter / RecursiveBF** | 已 RE 结构,未实现;边缘保持平滑/注意力光,下一批可做 |
| **虚拟背景 / 人像分割** | 体量大;有独立子项目 `xseg`(clean-room U-Net,⛔W 自训),本 session 未接入 demo |
| **音频 AEC + Opus 深挖** | 本 session 聚焦视频;音频基础(Opus+3A)已可用 |
| **分辨率上限/码率 配置项** | 要动 §9 自适应循环(档位在 `peer_main.cpp:752` 更新,需两处夹取+偶数尺寸),风险较高,留作配置窗口下一步 |

---

## 9. 边界原则速查

| 标记 | 含义 | 处理 |
|---|---|---|
| ✅ | 算法/结构/常量/**CPU SIMD 核**(Zoom 自家 x86) | RE + clean-room 重写(可恢复精确参数) |
| ⛔W | 神经网络**权重** | 自己训(matched-degradation) |
| ⛔K | 第三方**编解码/DSP 核** | 用 libvpx/libaom/libx264/libx265/Opus |
| ⛔S | 编译后 **GPU shader** | RE 算法 + 自己写 HLSL |

---

## 10. 关键工程教训

1. **感知增强必须按内容分型** —— 放大压缩伪影的"增强"(CLAHE/DCC 怼人脸,×8 伪影)不如不加。
2. **CPU SIMD 核是可参考的**(Zoom 自家 x86,非第三方),所以能做**精确核复现**(Sharpen 逐位),而非只做标准算法近似 —— 这是本 session 的边界修正。
3. **构建目录陷阱**:AvpMonitor 曾硬编码 `ExeDir=build-ff`,peer 编到 `build` 无效;AvpMonitor 用户跑 `bin\Release` 而我编到 `dist`。**务必编到实际运行的目录**(peer→`build-ff`;AvpMonitor→`bin\Release`),已改 AvpMonitor 优先用自身目录旁的 peer.exe(可移植)。
4. **黑屏排查方法论**:直接读共享内存 + dump 帧成图,逐路径(synth/camera/低档/屏幕RAISR/相机GPU RAISR/同时启动)验证,证明 peer.exe 全路径产出有效非黑帧 → 定位到显示/进程侧(僵尸进程占 UDP 端口 → bind 失败 → 双黑,已加 Start 前清理)。
5. **优先反编译 scalar 变体识别算法性质** —— SIMD 反汇编极易误判。DCC 的 4 方向梯度 + `vpavgb` 一度让人以为是"局部对比",直到读了 scalar 核 `sub_1801E1C10`(可读 C)才发现是**边缘定向插值(DCCI 上采样)**。每个 zlt 核都有 scalar/SSE/AVX2 三个变体(CPU 分发装在 obj 的 fn-ptr 里);**先从 ctor 找到 scalar 那个地址、反编译它认清算法,再回头对 SIMD 变体逐位**,能避免"结构对了但性质错了"的返工。

---

## 附录:关键函数地址 + 参数速查(实证)

| 模块 | 地址 | 关键参数 |
|---|---|---|
| Scaler bicubic | `sub_1801BCCA0` | Keys a=−0.5;抗锯齿 2·max(1,src/dst);Q14 ÷16384 |
| Scaler Lanczos-4 | `sub_1801BCE40` | a=4 |
| Sharpen 核 | `sub_1801ABCA0/ABB90`,`sub_180391440/391760` | 高斯[1,2,1;2,4,2;1,2,1]/16;unsharp (gain·detail)>>7,阈值门控 |
| CLAHE 核 | `sub_1801E0820`;apply `sub_1801E10F0` | 8×8=64 tile;256 bin;**钳位 [16,235]/[0,255](range-flag `*(hdr+124)`)**;**clip=cfg 0x70004**;多线程 235520px |
| DCC=DCCI Transform | `sub_1801E16A0` | 分配 4 梯度平面 + 调 3 核;imm 是对齐/看门狗非曲线 |
| DCC 梯度核 | `sub_1801E19B0`(scalar)/`A4160`/`A3420` | 4 方向 max−min 饱和 |
| DCC 上采样核 | `sub_1801E1C10`(scalar)/`A42C0`/`A3540` | 边缘定向 2×;比率 1.15;三次 [-1,9,9,-1]/16;轴向 575/800·920/500 |
| LightAdapt(逆光) | Transform `sub_1801BF500`;决策 `sub_1801C1350`;几何均值 `sub_1801C1100`;注意力 `sub_1801C11D0` | **几何均值亮度** `exp(Σh[i]·log i/(N−h[0]))`;触发:ROI≤100 **且** 高光(240..255)≥10% **且** 帧≤170;ROI 采样≤200;档 720/360/180→shift 3/2/1 |
| ColorAdapt | Transform `sub_1801CB090`,核 `sub_1801CBD10/CBFC0` | 4×4×192B LUT(种子 `qword_1804174C0`);(25a+128b+13c+64)>>7−bias;gray-world→127/128 |
| 颜色空间转换 | `zltCColorSpaceCvt` 0x180505518;`sub_18023D890`→`sub_18023DEC0/E100` | 格式对派发→SIMD 转换核(YUV↔RGB / 打包↔平面);标准 CSC ✅ |
| 注意力光(ROI) | `zltCAttentionLight` 0x180505040 | 人脸/显著性前端喂 LightAdapt;⛔W 边界(用自有人脸框) |
| 上行网络分 | `app_uplink_net_score_t` PDU **85**;构造 `sub_18000D600`;解析 `sub_180041360`;路由 `sub_180057A10/D8310/1D09A0` | net_score 0..5(dword@+24);属性 `mc_up_bw_level`∈{1,2,3,4};**服务端中介** |
| 相机 RAISR | zltCRaisr→CGPURaisr;SelectScale `sub_1801B8EA0` | 22桶;x1/x2/x3;taps 13/25;DIRECT;时域;≤480p |
| 屏幕 RAISR | zltCScreenRAISR | 48桶;2×;≤720p |
| Chroma(导向滤波) | `sh_804dec70`(754 指令 compute) | guided filter;3×3;ε=105.34;Q9 `(a·512·Y+b·512+256)>>9`;边缘门控(→ JBU + `zlt_chroma.hpp` 精确复现) |
| RAISR 看门狗 | — | 15ms;32帧窗;320帧周期;2 strike;60s |
| §9 上报 | — | kScoreReportPeriodMs=9800ms(0x2648) |

> 细节 RE 文档:`bin2cpp-output/recon/ida_recovered_ladders.md`(§8 scaler + RAISR)、`recon/zlt_raisr_camera.md`(相机 RAISR + A/B + RenderDoc 计划)。
