// [vendored into av-pipeline module 3 from bin2cpp-output/recon — body-verified clean-room
//  reconstruction of Zoom control surfaces, unchanged except the minih264 include path.]
// viper_codec_control.hpp -- clean-room reconstruction of viper.dll's audio codec-
// control decision/state logic (the ~24% reconstructable "control surface"). All four
// pieces are body-verified; the Opus/SNAC/DRED DSP itself is a ⛔K/⛔W boundary.
#pragma once
#include <cstdint>
#include <cstddef>

namespace recon::viper {

// ---- 1. AI-codec (121) enable gate -- sub_1800CE540 --------------------------
// AI-codec 121 overlays a parallel ACM+RtpRtcp on the main send path, allowed only
// when the main send codec is 113 or 116. Each failure step has a fixed error code.
struct AiCodecGate {
    enum Err { Ok = 0, NoMainCodec = -301, MainNotAllowed = -302, EnumFail = -303,
               NoCodec121 = -304, AcmCreate = -305, AcmInit = -306, RtpCreate = -307, RtpInit = -308 };
    static bool MainCodecAllowed(int codec) { return codec == 113 || codec == 116; }
    // rate/channel key used to create the ACM / RtpRtcp modules.
    static uint32_t CodecKey(int rate, int channels) {
        return (uint32_t(rate) << 16) | uint32_t(channels == -1 ? 99 : channels);
    }
    // returns the first failing step's error (Ok if all preconditions pass).
    static Err PreflightEnable(int main_codec, bool found_121) {
        if (main_codec == 0)             return NoMainCodec;
        if (!MainCodecAllowed(main_codec)) return MainNotAllowed;
        if (!found_121)                  return NoCodec121;
        return Ok;
    }
};

// ---- 2. Control word (bit 0x4 = kCtrlEnc) -- sub_1800594C0 -------------------
// 10-bit field; bit 0x4 toggles the extra AI/SNAC encode. A value change fires
// event 44 to the dispatcher; telemetry logs [ExtraAiCodecEvent_kCtrlEnc].
struct ControlWord {
    static constexpr uint32_t kMask = 0x3FF;   // 10-bit
    static constexpr uint32_t kBitExtraEnc = 0x4;
    uint32_t value = 0;

    // apply a new control word (low 10 bits), preserving high bits of `store`.
    struct Result { bool extra_enc; bool changed; bool fire_event44; };
    Result Apply(uint32_t& store, uint32_t incoming) {
        uint32_t old = store & kMask;
        uint32_t nw  = incoming & kMask;
        store = nw | (store & ~kMask);
        value = nw;
        bool extra = (incoming & kBitExtraEnc) != 0;   // bit 0x4
        bool changed = old != nw;
        return { extra, changed, changed /* -> event 44 */ };
    }
};

// ---- 3. SNAC decode state machine -- sub_1800C39E0 (EnableExtraSnacDecoding) -
// Atomic state: 0=kDisable, 1=kReady (2 also treated as active). Register/deregister
// via sub_1800CF050(payloadType); the same control-word bit 0x4 drives the receive side.
class SnacDecodeControl {
public:
    enum State { kDisable = 0, kReady = 1 };
    // Returns the transition taken; toggles registered_ accordingly.
    // (register/deregister of the actual codec is the caller's sub_1800CF050 hook.)
    struct Transition { State from, to; bool did_register, did_deregister; };
    Transition EnableExtraSnacDecoding(bool enable, uint32_t ctrlword, int /*payloadType*/) {
        State from = state_;
        Transition t{ from, from, false, false };
        if (!enable) {
            if (state_ == kReady || (int)state_ == 2) { t.did_deregister = true; state_ = kDisable; } // -> kDisable
            // else: already disabled, just store control word (below)
        } else {
            if (state_ == kDisable) { t.did_register = true; state_ = kReady; } // kDisable -> kReady
            // else: already enabled
        }
        t.to = state_;
        ctrlword_ = ctrlword;
        // same bit 0x4 as the send side also enables the receive-module extra decode:
        recv_extra_decode_ = (ctrlword & ControlWord::kBitExtraEnc) != 0;
        return t;
    }
    State state() const { return state_; }
    bool  recv_extra_decode() const { return recv_extra_decode_; }
private:
    State    state_ = kDisable;
    uint32_t ctrlword_ = 0;
    bool     recv_extra_decode_ = false;
};

// ---- 4. SNAC-TCP -> Opus reliable fallback -- sub_1800D1BE0 / sub_1800D2A60 --
// When UDP stalls, reassemble Opus from the reliable TCP channel. Verified thresholds.
struct SnacTcpFallback {
    enum Tier { TierII, TierIII };
    static constexpr int   kMinUdpOutageMs = 2000;   // need >=2s UDP stall before engaging
    static constexpr int   kMinTsRange     = 2500;   // enough valid data in the window
    static constexpr float kLossTierII     = 0.5f;   // tier II accepts loss <= 0.5
    static constexpr float kLossTierIII    = 0.2f;   // tier III accepts loss <= 0.2

    // ts_range = (max_ts - min_ts)/48 + 20   (48 = 48 kHz/ms, +20 = one frame)
    static int TsRange(uint32_t max_ts, uint32_t min_ts) { return int((max_ts - min_ts) / 48) + 20; }
    // loss = (expected - actual) / expected   (expected = seq span, actual = pkts received)
    static float LossRate(int expected, int actual) {
        return expected > 0 ? float(expected - actual) / float(expected) : 1.f;
    }
    // Decide whether to reassemble from TCP.
    static bool ShouldEngage(int ms_since_last_udp, int ts_range, float loss, Tier tier) {
        if (ms_since_last_udp < kMinUdpOutageMs) return false;         // recv_no_snac_tcp_pack
        if (ts_range < kMinTsRange)              return false;         // not enough valid data
        float cap = (tier == TierII) ? kLossTierII : kLossTierIII;     // lookback 2s = ts-96000
        return loss <= cap;
    }
};

} // namespace recon::viper
