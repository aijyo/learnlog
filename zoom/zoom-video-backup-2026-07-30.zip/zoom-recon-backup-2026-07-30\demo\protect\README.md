# Module 4 — loss protection

The three loss defenses from `AV_PIPELINE_DETAILS.html §4`, each with its own delay/bandwidth trade-off;
Zoom uses all three and combines them per condition.

| tool | file | principle | delay | bandwidth |
|---|---|---|---|---|
| **FEC** (multi-layer) | `fec.hpp` + `algo/rs_fec.hpp` | send parity ahead of time; recover in place (§4.1) | low (no wait) | high (standing redundancy) |
| **NACK** retransmit | `nack.hpp` | detect a gap, ask again | ≥1 RTT | low (only the lost) |
| **PLC** concealment | `plc.hpp` | extrapolate / freeze when nothing recovers | zero | zero |

```
encoded frame (mod 3) ─► packetize ─► [K src + R parity]  ─►  lossy channel  ─►  recover:
                                                              FEC (≤R lost) → NACK (burst) → PLC (last resort)
```

## Pieces

- **`packetizer.hpp`** — a coded access unit → MTU-sized `MediaPacket`s (seq / timestamp / marker), and back.
- **`fec.hpp`** — packet-level multi-layer FEC. A group of **K source packets** gets **R parity packets**;
  any K of K+R recover the group with no retransmit. R (the "3rd/4th/5th-level" count) rises with loss
  via `SelectFecLevel` (mcm's exact 3/4/5 tiering). Engine = the body-verified **RS(GF256, poly 0x11D)**
  from nydus (`algo/rs_fec.hpp` + `algo/mcm_multifec.hpp`, **vendored unchanged**).
- **`nack.hpp`** — sender `RetransmitBuffer` (recent-packet history) + receiver `NackTracker`
  (gap detection with reorder slack, RFC1982 seq compare).
- **`plc.hpp`** — `AudioPlc` (attenuating waveform extrapolation), `VideoPlc` (freeze the last frame).
  Neural PLC (Opus **DRED**) is a trained-weight boundary (⛔W) exposed as `INeuralPlc`.
- **`loss_sim.hpp`** — `RandomLoss` (Bernoulli) + `BurstLoss` (Gilbert-Elliott) deterministic channels.

## Build & run
```powershell
cmake -S . -B build -DAVP_WITH_WGC=ON
cmake --build build --config Release --target protect_demo
.\build\protect\Release\protect_demo.exe
```
No external libraries. The demo also encodes a real H.264 frame (module 3) and protects/recovers it.

## Verified (this machine)
```
1) FEC            200 groups, drop 0..R random/group -> recovered 200, BYTE-EXACT 200
2) adaptive       loss 2% -> L3, 7% -> L4, 15% -> L5
3) burst > R      FEC fails (expected) -> receiver detects gap -> NACK 5 seqs -> sender resends 5 -> complete
4) NACK/reorder   reordered packet: NACK 0 (no spurious) ; real 2-packet gap: NACK 2
5) PLC            audio conceal 51% then 31% energy (decays, not silent) ; video freeze reuses last frame
6) end to end     real H.264 frame, 4 pkts, all 4 dropped -> 4 parity recover -> reassembled == original (byte-identical)
```

The RS engine, the 3/4/5 tiering, and the packet-group model are the body-verified nydus/mcm
reconstruction; FEC/NACK/PLC control logic is standard RTC design. DRED neural PLC is a boundary.
Clean-room, following Zoom's *design* (not its code). For interop / education.
