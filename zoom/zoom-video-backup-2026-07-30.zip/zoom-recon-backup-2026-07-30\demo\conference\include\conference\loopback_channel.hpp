// loopback_channel.hpp — in-process IMediaChannel: media/FEC packets go in, a configurable fraction is
// dropped and the rest optionally reordered before delivery — the lossy/reordering conditions the
// receive side (jitter buffer + FEC) is built to survive. Deterministic given a seed. For a channel
// that actually crosses a socket, see udp_media_channel.hpp.
#pragma once
#include "conference/media_channel.hpp"
#include <cstdint>
#include <vector>

namespace avp {

class LoopbackChannel : public IMediaChannel {
public:
  LoopbackChannel(double loss = 0.0, bool reorder = false, uint32_t seed = 0x1234)
      : loss_(loss), reorder_(reorder), s_(seed ? seed : 1) {}

  void send(const WirePacket& w) override {
    ++sent_;
    if (next() < loss_) { ++dropped_; return; }
    pending_.push_back(w);
  }
  std::vector<WirePacket> deliver() override {
    if (reorder_) for (int i = (int)pending_.size() - 1; i > 0; --i) { int j = (int)(next() * (i + 1)); std::swap(pending_[i], pending_[j]); }
    std::vector<WirePacket> out; out.swap(pending_);
    return out;
  }
  long sent() const override { return sent_; }
  long dropped() const override { return dropped_; }
  const char* name() const override { return "loopback (in-process)"; }
  void set_loss(double l) { loss_ = l; }

private:
  double next() { s_ = s_ * 1664525u + 1013904223u; return (s_ >> 8) / (double)(1u << 24); }
  double loss_; bool reorder_; uint32_t s_;
  std::vector<WirePacket> pending_;
  long sent_ = 0, dropped_ = 0;
};

}  // namespace avp
