// wav_reader.hpp — minimal RIFF/WAVE reader (PCM16 or IEEE-float), enough to load the WAVs that
// module 1's audio_demo writes and feed them into the 3A chain. Returns interleaved samples as
// mono float (averaging channels) plus the sample rate.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace avp {

inline bool read_wav_mono(const std::string& path, std::vector<float>& mono, int& sample_rate) {
  FILE* f = nullptr;
#ifdef _WIN32
  fopen_s(&f, path.c_str(), "rb");
#else
  f = fopen(path.c_str(), "rb");
#endif
  if (!f) return false;
  fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
  std::vector<uint8_t> b((size_t)sz);
  bool okr = sz > 44 && fread(b.data(), 1, (size_t)sz, f) == (size_t)sz;
  fclose(f);
  if (!okr) return false;
  auto u16 = [&](size_t o) { return (uint16_t)(b[o] | (b[o + 1] << 8)); };
  auto u32 = [&](size_t o) { return (uint32_t)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | ((uint32_t)b[o + 3] << 24)); };
  if (std::memcmp(b.data(), "RIFF", 4) || std::memcmp(b.data() + 8, "WAVE", 4)) return false;

  uint16_t fmt = 1, ch = 1, bits = 16; uint32_t rate = 48000; size_t data_off = 0, data_len = 0;
  size_t p = 12;
  while (p + 8 <= b.size()) {
    uint32_t id_off = (uint32_t)p; uint32_t clen = u32(p + 4);
    if (!std::memcmp(&b[id_off], "fmt ", 4)) { fmt = u16(p + 8); ch = u16(p + 10); rate = u32(p + 12); bits = u16(p + 22); }
    else if (!std::memcmp(&b[id_off], "data", 4)) { data_off = p + 8; data_len = clen; }
    p += 8 + clen + (clen & 1);
  }
  if (!data_off || !data_len || ch == 0) return false;
  if (data_off + data_len > b.size()) data_len = b.size() - data_off;
  sample_rate = (int)rate;

  const uint8_t* d = b.data() + data_off;
  if (fmt == 3 && bits == 32) {
    size_t n = data_len / 4; const float* s = reinterpret_cast<const float*>(d);
    for (size_t i = 0; i + ch <= n; i += ch) { float a = 0; for (int c = 0; c < ch; ++c) a += s[i + c]; mono.push_back(a / ch); }
  } else if (fmt == 1 && bits == 16) {
    size_t n = data_len / 2; const int16_t* s = reinterpret_cast<const int16_t*>(d);
    for (size_t i = 0; i + ch <= n; i += ch) { int a = 0; for (int c = 0; c < ch; ++c) a += s[i + c]; mono.push_back((a / ch) / 32768.0f); }
  } else return false;
  return !mono.empty();
}

}  // namespace avp
