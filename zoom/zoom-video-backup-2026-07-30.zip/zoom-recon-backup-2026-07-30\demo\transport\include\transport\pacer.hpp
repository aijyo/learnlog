// pacer.hpp — smooth the send rate (AV_PIPELINE_DETAILS.html §5). The encoder emits a whole frame at
// once (a burst of packets); sending them back-to-back spikes the queue and confuses the bandwidth
// estimator. A token-bucket pacer releases packets at the congestion target, so the link sees a
// steady stream. Burst budget is capped (~250 ms) so a brief idle can't release a huge burst later.
#pragma once
#include <cstdint>
#include <deque>
#include <utility>
#include <vector>

namespace avp {

class Pacer {
public:
  explicit Pacer(double rate_bps = 300000) : rate_(rate_bps) {}
  void set_rate(double bps) { rate_ = bps > 1 ? bps : 1; }
  void enqueue(uint16_t seq, int size) { q_.push_back({ seq, size }); }
  size_t backlog() const { return q_.size(); }

  // release whatever the budget allows at `now_us`; returns the seqs sent this tick.
  std::vector<uint16_t> tick(int64_t now_us) {
    if (last_us_ == 0) last_us_ = now_us;
    double dt = (now_us - last_us_) / 1e6; if (dt < 0) dt = 0;
    last_us_ = now_us;
    budget_ += rate_ * dt / 8.0;                       // bytes we may send now
    double cap = rate_ * 0.25 / 8.0;                   // <=250 ms of burst budget
    if (budget_ > cap) budget_ = cap;
    std::vector<uint16_t> out;
    while (!q_.empty() && budget_ >= q_.front().second) {
      budget_ -= q_.front().second; out.push_back(q_.front().first); q_.pop_front();
    }
    return out;
  }
private:
  double rate_, budget_ = 0; int64_t last_us_ = 0;
  std::deque<std::pair<uint16_t, int>> q_;
};

// SendPacer — a token bucket that holds the ACTUAL serialized packet bytes (so the live peer can drain it
// straight to the socket), the missing GCC/Zoom send-pacer: a frame's packet burst is released at the BWE
// target rate instead of blasting, which keeps the bottleneck queue (and thus loss + delay) low.
class SendPacer {
public:
  void set_rate_bps(double bps) { rate_ = bps > 8000 ? bps : 8000; }
  double rate_bps() const { return rate_; }
  void enqueue(std::vector<uint8_t> pkt) { bytes_ += (long)pkt.size(); q_.push_back(std::move(pkt)); }
  size_t queued() const { return q_.size(); }

  // Release whatever the budget allows at now_us; `send(const std::vector<uint8_t>&)` sends each packet.
  template <class Send>
  void drain(int64_t now_us, Send&& send) {
    if (last_us_ == 0) last_us_ = now_us;
    double dt = (now_us - last_us_) / 1e6; if (dt < 0) dt = 0;
    last_us_ = now_us;
    budget_ += rate_ / 8.0 * dt;
    double cap = rate_ / 8.0 * kBurstMs / 1000.0 + 1500.0;   // ~kBurstMs of burst, min 1 MTU
    if (budget_ > cap) budget_ = cap;
    while (!q_.empty() && budget_ >= (double)q_.front().size()) {
      budget_ -= (double)q_.front().size(); bytes_ -= (long)q_.front().size();
      send(q_.front()); q_.pop_front();
    }
    while (q_.size() > kMaxQueue) { bytes_ -= (long)q_.front().size(); q_.pop_front(); ++dropped_; }   // shed a runaway backlog
  }
  int dropped() const { return dropped_; }

private:
  static constexpr double kBurstMs = 6.0;
  static constexpr size_t kMaxQueue = 1200;
  std::deque<std::vector<uint8_t>> q_;
  double rate_ = 2000000, budget_ = 0; int64_t last_us_ = 0; long bytes_ = 0; int dropped_ = 0;
};

}  // namespace avp
