// jitter_buffer.hpp — module 6 receive / jitter buffer (AV_PIPELINE_DETAILS.html §6). The network
// delivers packets out of order and with variable delay; this buffer reorders by sequence number,
// estimates the interarrival jitter (RFC 3550), holds a self-tuned playout delay to absorb it, and
// reassembles complete access units (same RTP timestamp, ending on the marker packet) for the decoder.
// Missing packets are reported so FEC/NACK (module 4) or PLC can fill them.
#pragma once
#include "protect/packetizer.hpp"     // avp::MediaPacket
#include <cstdint>
#include <map>
#include <vector>

namespace avp {

class JitterBuffer {
public:
  explicit JitterBuffer(uint32_t clock_hz = 90000) : clock_hz_(clock_hz) {}

  // Insert a received packet with its arrival time (us). Updates the RFC 3550 jitter estimate.
  void insert(const MediaPacket& p, int64_t recv_us) {
    // interarrival jitter: D = (recv_j - recv_i) - (ts_j - ts_i), J += (|D| - J)/16
    if (have_prev_) {
      double recv_delta_ts = (recv_us - prev_recv_us_) * 1e-6 * clock_hz_;   // arrival delta in ts units
      double send_delta_ts = (double)(int32_t)(p.timestamp - prev_ts_);
      double d = recv_delta_ts - send_delta_ts;
      if (d < 0) d = -d;
      jitter_ += (d - jitter_) / 16.0;
    }
    prev_recv_us_ = recv_us; prev_ts_ = p.timestamp; have_prev_ = true;
    if (!pkts_.count(p.seq)) pkts_[p.seq] = p;
  }

  double jitter_ms() const { return clock_hz_ ? jitter_ * 1000.0 / clock_hz_ : 0; }
  // playout delay ~ base + 4*jitter (RTP rule of thumb), clamped.
  double target_delay_ms() const { double d = 20.0 + 4.0 * jitter_ms(); return d < 20 ? 20 : (d > 500 ? 500 : d); }

  // Pop the next complete access unit in sequence order (all packets present, ending on a marker).
  // Returns false if the head AU isn't complete yet. On success, `au` is the reassembled bytes.
  bool pop_frame(std::vector<uint8_t>& au, uint32_t& ts) {
    if (pkts_.empty()) return false;
    uint16_t start = have_next_ ? next_seq_ : pkts_.begin()->first;
    // walk contiguous seqs from `start` until a marker; require every seq present.
    std::vector<const MediaPacket*> run;
    uint16_t s = start;
    for (;;) {
      auto it = pkts_.find(s);
      if (it == pkts_.end()) return false;         // gap -> AU not complete (yet)
      run.push_back(&it->second);
      bool marker = it->second.marker;
      ++s;
      if (marker) break;
      if (run.size() > 4096) return false;          // safety
    }
    au.clear(); ts = run.front()->timestamp;
    for (auto* p : run) au.insert(au.end(), p->payload.begin(), p->payload.end());
    for (uint16_t k = start; k != s; ++k) pkts_.erase(k);   // consume
    next_seq_ = s; have_next_ = true;
    return true;
  }

  // Sequence numbers missing between the head and the newest packet (for NACK / FEC decisions).
  std::vector<uint16_t> missing() const {
    std::vector<uint16_t> out;
    if (pkts_.size() < 2) return out;
    uint16_t lo = have_next_ ? next_seq_ : pkts_.begin()->first, hi = pkts_.rbegin()->first;
    for (uint16_t k = lo; k != hi; ++k) if (!pkts_.count(k)) out.push_back(k);
    return out;
  }
  size_t buffered() const { return pkts_.size(); }

private:
  uint32_t clock_hz_;
  std::map<uint16_t, MediaPacket> pkts_;
  double jitter_ = 0; int64_t prev_recv_us_ = 0; uint32_t prev_ts_ = 0; bool have_prev_ = false;
  uint16_t next_seq_ = 0; bool have_next_ = false;
};

}  // namespace avp
