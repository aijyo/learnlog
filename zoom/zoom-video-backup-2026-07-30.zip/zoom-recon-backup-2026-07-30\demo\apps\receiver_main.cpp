// receiver_main.cpp — the RECEIVE half. Binds a REAL UDP socket, reassembles frames from the out-of-
// order/lossy packet stream (FEC-recovering drops), decodes H.264 (FFmpeg), converts to BGRA, and
// publishes the frame + stats into shared memory for the WPF monitor.
//
//   receiver [--port P] [--seconds N|0]
#include "apps/ipc_shared.hpp"
#include "apps/ipc_writer.hpp"
#include "apps/frame_assembler.hpp"
#include "conference/media_channel.hpp"
#include "transport/socket_transport.hpp"
#include "preprocess/video_convert.hpp"
#ifdef AVP_WITH_FFMPEG
#include "encode/h264_decode_verify.hpp"
#endif
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>

using namespace avp;
using clockt = std::chrono::steady_clock;

int main(int argc, char** argv) {
  int port = 50000; double seconds = 0;
  for (int i = 1; i < argc; ++i) {
    if (!strcmp(argv[i], "--port") && i + 1 < argc) port = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--seconds") && i + 1 < argc) seconds = atof(argv[++i]);
  }
  std::printf("receiver: binding 127.0.0.1:%d\n", port);

  WsaScope wsa; UdpSocket rx; if (!rx.open((uint16_t)port)) { std::printf("bind %d failed\n", port); return 1; }
  ipc::ShmPublisher<ipc::ReceiverShare> shm;
  if (!shm.open(ipc::kReceiverMap())) { std::printf("shm open failed\n"); return 1; }
  shm->magic = ipc::kMagic; shm->width = ipc::kW; shm->height = ipc::kH; shm->running = 1;
  ipc::ShmReader<ipc::ControlBlock> ctrl; ctrl.open(ipc::kControlMap());

#ifdef AVP_WITH_FFMPEG
  H264Decoder dec; dec.open();
#endif
  FrameAssembler fa;
  int frames_recv = 0, decoded = 0, recovered = 0, dropped = 0;
  auto t0 = clockt::now(); auto last_pkt = t0;
  std::vector<uint8_t> buf(4096);
  for (;;) {
    if (seconds > 0 && std::chrono::duration<double>(clockt::now() - t0).count() >= seconds) break;
    if (ctrl.valid() && ctrl->magic == ipc::kMagic && ctrl->stop) break;   // monitor requested stop
    // drain the socket
    int got = 0;
    for (;;) { int n = rx.recv_nb(buf.data(), (int)buf.size()); if (n <= 0) break; WirePacket w; if (wire::deserialize(buf.data(), n, w)) { fa.add(w); ++got; } }
    if (got) last_pkt = clockt::now();

    // pop complete/recoverable frames and decode
    std::vector<uint8_t> au; AssembleStat as;
    while (fa.try_pop(au, as)) {
      ++frames_recv; if (as.recovered) ++recovered; dropped += as.dropped_pkts;
#ifdef AVP_WITH_FFMPEG
      I420Image out;
      if (dec.decode(au, out) && out.w > 0) {
        VideoFrame bgra; I420ToBgra(out, bgra);
        size_t n = std::min(sizeof(shm->frame), bgra.data.size());
        std::memcpy(shm->frame, bgra.data.data(), n);
        shm->width = out.w; shm->height = out.h; shm->decode_ok = 1; ++decoded;
        shm->frame_seq++;
      } else shm->decode_ok = 0;
#else
      shm->frame_seq++;   // no decoder: still count reassembled frames
#endif
    }
    shm->frames_recv = frames_recv; shm->dropped = dropped; shm->recovered = recovered; shm->intact_frames = decoded; shm->running = 1;

    // exit if the sender has been silent for a while (after having received something)
    if (frames_recv > 0 && std::chrono::duration<double>(clockt::now() - last_pkt).count() > 2.0) break;
    std::this_thread::sleep_for(std::chrono::milliseconds(2));
  }
  shm->running = 0;
  std::printf("receiver: stopped, %d frames (%d decoded, %d recovered, %d pkts dropped)\n", frames_recv, decoded, recovered, dropped);
  return 0;
}
