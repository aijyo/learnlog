// audio_wasapi.hpp — real WASAPI shared-mode capture (Zoom's audio ingest, §1.3).
//
// Two endpoints, one code path:
//   * microphone  — activate an IAudioClient on the default *capture* endpoint (eCapture/eConsole).
//   * system audio — activate on the default *render* endpoint with AUDCLNT_STREAMFLAGS_LOOPBACK,
//                    which delivers exactly what the speakers are playing ("share computer sound").
//
// Shared mode negotiates the endpoint's mix format (typically 48 kHz / stereo / 32-bit float), so the
// same client works for both. read() drains every packet WASAPI currently has via IAudioCaptureClient
// (GetNextPacketSize -> GetBuffer -> ReleaseBuffer), the standard event/poll capture loop.
#pragma once
#include "audio_source.hpp"
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <functiondiscoverykeys_devpkey.h>
#include <cstring>
#include <vector>
#pragma comment(lib, "ole32.lib")

namespace avp {

// RAII for CoInitialize so the demo/host doesn't have to remember to pair it.
struct ComScope {
  bool owned = false;
  ComScope() { HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED); owned = SUCCEEDED(hr) && hr != RPC_E_CHANGED_MODE; }
  ~ComScope() { if (owned) CoUninitialize(); }
};

class WasapiAudioSource : public IAudioSource {
public:
  ~WasapiAudioSource() override { close(); }

  bool open(const AudioCaptureConfig& cfg) override {
    close();
    if (FAILED(CoInitializeEx(nullptr, COINIT_MULTITHREADED)) ) { /* may already be inited on this thread */ }
    co_inited_ = true;
    loopback_ = (cfg.target == AudioTarget::DefaultLoopback);

    IMMDeviceEnumerator* en = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
                                __uuidof(IMMDeviceEnumerator), (void**)&en)))
      return false;

    HRESULT hr;
    if (cfg.target == AudioTarget::DeviceId && !cfg.device_id.empty()) {
      hr = en->GetDevice(cfg.device_id.c_str(), &dev_);
    } else {
      // loopback captures the RENDER endpoint; mic captures the CAPTURE endpoint.
      const EDataFlow flow = loopback_ ? eRender : eCapture;
      hr = en->GetDefaultAudioEndpoint(flow, eConsole, &dev_);
    }
    en->Release();
    if (FAILED(hr) || !dev_) return false;

    if (FAILED(dev_->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&client_))) return false;

    WAVEFORMATEX* mix = nullptr;
    if (FAILED(client_->GetMixFormat(&mix)) || !mix) return false;
    fmt_ = from_wfx(mix);

    REFERENCE_TIME dur = cfg.buffer_ms > 0 ? (REFERENCE_TIME)cfg.buffer_ms * 10000 : 0;  // 100-ns units
    DWORD stream_flags = loopback_ ? AUDCLNT_STREAMFLAGS_LOOPBACK : 0;
    hr = client_->Initialize(AUDCLNT_SHAREMODE_SHARED, stream_flags, dur, 0, mix, nullptr);
    CoTaskMemFree(mix);
    if (FAILED(hr)) return false;

    if (FAILED(client_->GetService(__uuidof(IAudioCaptureClient), (void**)&capture_))) return false;
    if (FAILED(client_->Start())) return false;
    started_ = true;
    QueryPerformanceFrequency(&qpc_freq_);
    return true;
  }

  bool read(AudioFrame& out) override {
    if (!capture_) return false;
    out.format = fmt_;
    out.data.clear();
    out.frames = 0;

    UINT32 packet = 0;
    if (FAILED(capture_->GetNextPacketSize(&packet))) return false;
    bool stamped = false;
    while (packet > 0) {
      BYTE* pdata = nullptr; UINT32 nframes = 0; DWORD flags = 0; UINT64 qpc = 0;
      if (FAILED(capture_->GetBuffer(&pdata, &nframes, &flags, nullptr, &qpc))) break;
      const size_t bytes = (size_t)nframes * fmt_.frame_bytes();
      if (!stamped) {
        // GetBuffer's device QPC position is in 100-ns units -> microseconds.
        out.timestamp_us = (int64_t)(qpc / 10);
        stamped = true;
      }
      if (flags & AUDCLNT_BUFFERFLAGS_SILENT) {
        out.data.insert(out.data.end(), bytes, 0);   // silent packet: WASAPI says "treat as zeros"
      } else if (pdata && bytes) {
        out.data.insert(out.data.end(), pdata, pdata + bytes);
      }
      out.frames += (int)nframes;
      capture_->ReleaseBuffer(nframes);
      if (FAILED(capture_->GetNextPacketSize(&packet))) break;
    }
    return true;   // 0 frames is normal (no full period yet); only hard errors return false
  }

  void close() override {
    if (client_ && started_) { client_->Stop(); started_ = false; }
    if (capture_) { capture_->Release(); capture_ = nullptr; }
    if (client_)  { client_->Release();  client_  = nullptr; }
    if (dev_)     { dev_->Release();      dev_     = nullptr; }
    if (co_inited_) { CoUninitialize(); co_inited_ = false; }
  }

  const char* backend() const override { return loopback_ ? "WASAPI-Loopback" : "WASAPI-Microphone"; }
  AudioFormat format() const override { return fmt_; }

private:
  static AudioFormat from_wfx(const WAVEFORMATEX* w) {
    AudioFormat f;
    f.sample_rate = (int)w->nSamplesPerSec;
    f.channels    = (int)w->nChannels;
    f.bits        = (int)w->wBitsPerSample;
    f.is_float    = (w->wFormatTag == WAVE_FORMAT_IEEE_FLOAT);
    if (w->wFormatTag == WAVE_FORMAT_EXTENSIBLE && w->cbSize >= 22) {
      const WAVEFORMATEXTENSIBLE* ext = reinterpret_cast<const WAVEFORMATEXTENSIBLE*>(w);
      f.is_float = (ext->SubFormat == KSDATAFORMAT_SUBTYPE_IEEE_FLOAT);
    }
    return f;
  }

  IMMDevice*           dev_     = nullptr;
  IAudioClient*        client_  = nullptr;
  IAudioCaptureClient* capture_ = nullptr;
  AudioFormat          fmt_;
  LARGE_INTEGER        qpc_freq_{};
  bool loopback_ = false, started_ = false, co_inited_ = false;
};

// Enumerate audio endpoints (both capture and render). Render endpoints are loopback-capable.
inline std::vector<AudioDeviceInfo> EnumerateAudioDevices() {
  std::vector<AudioDeviceInfo> list;
  ComScope com;
  IMMDeviceEnumerator* en = nullptr;
  if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
                              __uuidof(IMMDeviceEnumerator), (void**)&en)))
    return list;

  const EDataFlow flows[2] = { eCapture, eRender };
  for (EDataFlow flow : flows) {
    IMMDevice* def = nullptr; std::wstring def_id;
    if (SUCCEEDED(en->GetDefaultAudioEndpoint(flow, eConsole, &def)) && def) {
      LPWSTR id = nullptr; if (SUCCEEDED(def->GetId(&id)) && id) { def_id = id; CoTaskMemFree(id); }
      def->Release();
    }
    IMMDeviceCollection* col = nullptr;
    if (FAILED(en->EnumAudioEndpoints(flow, DEVICE_STATE_ACTIVE, &col)) || !col) continue;
    UINT n = 0; col->GetCount(&n);
    for (UINT i = 0; i < n; ++i) {
      IMMDevice* d = nullptr; if (FAILED(col->Item(i, &d)) || !d) continue;
      AudioDeviceInfo info; info.is_capture = (flow == eCapture);
      LPWSTR id = nullptr; if (SUCCEEDED(d->GetId(&id)) && id) { info.id = id; CoTaskMemFree(id); }
      IPropertyStore* props = nullptr;
      if (SUCCEEDED(d->OpenPropertyStore(STGM_READ, &props)) && props) {
        PROPVARIANT v; PropVariantInit(&v);
        if (SUCCEEDED(props->GetValue(PKEY_Device_FriendlyName, &v)) && v.vt == VT_LPWSTR && v.pwszVal)
          info.name = v.pwszVal;
        PropVariantClear(&v);
        props->Release();
      }
      info.is_default = (!def_id.empty() && info.id == def_id);
      list.push_back(std::move(info));
      d->Release();
    }
    col->Release();
  }
  en->Release();
  return list;
}

}  // namespace avp
#endif  // _WIN32
