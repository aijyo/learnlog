#pragma once
// recv_superres.hpp — RECEIVE-SIDE super-resolution for the conference: reconstruct detail on a decoded
// low-tier frame before display, the way Zoom applies its render-path RAISR. Two paths, matching Zoom's
// two GPU objects:
//   * SCREEN content  -> GPU RAISR (recon/raisr_gpu.hpp, screen structure, bank = raisr_bank.bin), like
//                        ns_gct::CGPUScreenRaisr — bilinear base at display size + GPU refine.
//   * CAMERA content  -> CPU camera RAISR (recon/zlt_raisr_camera.hpp, 22-bucket/13-tap DIRECT structure,
//                        bank = raisr_cam_bank.bin), like ns_gct::CGPURaisr — direct LR-patch->HR-subpixel
//                        2x, then fit to the display.
// Banks are OURS (trained by apps/raisr_train_matched.cpp / raisr_train_camera.cpp on the receiver's real
// degradation). If a path's bank/GPU is unavailable, readyFor() is false and the caller falls back to a
// bilinear resize.
//
// Self-contained: reads the bank files itself, drives GpuRaisr (standalone D3D11) + the header-only
// CamRaisrUpscaler. Deliberately does NOT include zlt_raisr.hpp (avoids clashing with the preprocess
// module's own copy pulled in via video_preprocess.hpp); zlt_raisr_camera.hpp is a separate namespace.
#include "preprocess/video_convert.hpp"       // avp::I420Image
#include "capture/video_frame.hpp"            // avp::VideoFrame
#include "raisr_gpu.hpp"                      // recon::zlt::GpuRaisr (standalone D3D11 compute, screen)
#include "zlt_raisr_camera.hpp"               // recon::zltcam (camera RAISR structure + CPU upscaler)
#include "raisr_cam_gpu.hpp"                  // recon::zltcam::GpuCamRaisr (camera GPU, full path)
#include <vector>
#include <cstdint>
#include <cstdio>
#include <cmath>
#include <chrono>
#include <string>

namespace avp {

class RecvSuperRes {
public:
  // Load the screen bank (+GPU RAISR) and the camera banks (x2 + x3, either optional). ready() = OR.
  bool init(const std::string& screenBankPath, const std::string& camX2Path = "",
            const std::string& camX3Path = "") {
    gpuReady_ = initGpuScreen(screenBankPath);
    bool x2 = !camX2Path.empty() && camBankX2_.load(camX2Path.c_str());
    bool x3 = !camX3Path.empty() && camBankX3_.load(camX3Path.c_str());
    camReady_ = x2 || x3;
    // camera RAISR on the GPU (full path: RAISR luma + luma-guided chroma + combine). Falls back to the
    // CPU CamRaisrUpscaler if the GPU/shader isn't available.
    if (camReady_) gpuCamReady_ = gpuCam_.init(camBankX2_.nbuck ? camBankX2_.nbuck : camBankX3_.nbuck, 11, 0.5f,
                                               camBankX2_.data, camBankX3_.data);
    return gpuReady_ || camReady_;
  }
  bool ready() const { return gpuReady_ || camReady_; }
  bool readyFor(bool camera) const { return camera ? camReady_ : gpuReady_; }
  bool cameraGpu() const { return gpuCamReady_; }          // camera path runs on GPU (else CPU fallback)
  const std::string& adapter() const { return gpuCamReady_ ? gpuCam_.adapter() : gpu_.adapter(); }
  void setChromaGuided(bool g) { chromaGuided_ = g; }      // chroma upsample: false=our JBU, true=Zoom-exact guided filter

  // Upscale a decoded I420 frame to (outW x outH) BGRA. `camera` picks the CPU camera RAISR path; else
  // the GPU screen path. computeMs (optional) = GPU time (screen) / 0 (camera CPU). Returns false if the
  // selected path isn't ready (caller should bilinear-fall-back).
  bool Upscale(const I420Image& in, VideoFrame& out, int outW, int outH, bool camera = false,
               double* computeMs = nullptr) {
    if (in.w <= 0 || in.h <= 0 || outW <= 0 || outH <= 0) return false;
    if (camera) return camReady_ && upscaleCamera(in, out, outW, outH, computeMs);
    return gpuReady_ && upscaleScreenGpu(in, out, outW, outH, computeMs);
  }

private:
  static uint8_t clamp8(int v) { return (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v)); }

  bool initGpuScreen(const std::string& bankPath) {
    std::FILE* f = std::fopen(bankPath.c_str(), "rb"); if (!f) return false;
    int hdr[4]; float th[2]; std::vector<float> bank;
    bool ok = std::fread(hdr, sizeof(int), 4, f) == 4 && std::fread(th, sizeof(float), 2, f) == 2;
    if (ok) {
      int np = hdr[0], nb = hdr[1], nt = hdr[2], patch = hdr[3];
      bank.assign((size_t)np * nb * nt, 0.f);
      ok = np > 0 && nb > 0 && nt > 0 && std::fread(bank.data(), sizeof(float), bank.size(), f) == bank.size();
      if (ok) { std::fclose(f); return gpu_.init(patch, nb, np, th[0], th[1], bank); }
    }
    std::fclose(f); return false;
  }

  // SCREEN: luma bilinear base at display size -> GPU RAISR refine; chroma bilinear.
  bool upscaleScreenGpu(const I420Image& in, VideoFrame& out, int outW, int outH, double* ms) {
    std::vector<float> yin((size_t)in.w * in.h);
    for (size_t i = 0; i < yin.size(); ++i) yin[i] = in.y[i];
    bilinearPlane(yin.data(), in.w, in.h, baseY_, outW, outH);
    if (!gpu_.upscale(baseY_.data(), outW, outH, rY_, ms)) return false;
    chromaAndCombine(in, out, outW, outH);
    return true;
  }

  // CAMERA: direct LR-patch->HR-subpixel at the scale bank matching the needed ratio (Zoom Raisrx2/x3
  // selection), then fit to display; chroma bilinear. x3 bank for big (>=2.5x) upscales, else x2.
  bool upscaleCamera(const I420Image& in, VideoFrame& out, int outW, int outH, double* ms) {
    auto t0 = std::chrono::steady_clock::now();
    if (gpuCamReady_) {                                           // FULL GPU camera path (Zoom CGPURaisr-style)
      out.width = outW; out.height = outH; out.stride = outW * 4; out.format = PixelFormat::BGRA;
      if (gpuCam_.Upscale(in.y.data(), in.u.data(), in.v.data(), in.w, in.h, in.cw(), in.ch(), out.data, outW, outH)) {
        if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        return true;
      }
    }
    double ratio = std::max((double)outW / in.w, (double)outH / in.h);
    recon::zltcam::TrainedCamBank* bank = (ratio >= 2.5 && camBankX3_.ntaps > 0) ? &camBankX3_ : &camBankX2_;
    if (bank->ntaps == 0) bank = (camBankX2_.ntaps > 0 ? &camBankX2_ : &camBankX3_);   // whichever exists
    recon::zltcam::CamRaisrConfig cfg; cfg.scale = bank->scale > 0 ? bank->scale : 2;
    std::vector<float> yin((size_t)in.w * in.h);
    for (size_t i = 0; i < yin.size(); ++i) yin[i] = in.y[i];
    recon::zltcam::CamRaisrUpscaler up(cfg, bank);
    std::vector<float> yhr; int hw = 0, hh = 0;
    up.Upscale(yin.data(), in.w, in.h, yhr, hw, hh);              // scale× direct camera RAISR (CPU fallback)
    bilinearPlane(yhr.data(), hw, hh, rY_, outW, outH);           // fit to the display
    chromaAndCombine(in, out, outW, outH);
    if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    return true;
  }

  // LUMA-GUIDED chroma upsample + YUV(BT.601)->BGRA. Mirrors Zoom's ChromaUpsample shader (recovered:
  // tex_Y + tex_U/tex_V -> out_tex_U/out_tex_V — it samples LUMA to weight the chroma). We do a joint
  // bilateral upsample: each output chroma is a bilinear 2x2 of the LR chroma, but each tap is re-weighted
  // by how close the RECONSTRUCTED HR luma (rY_) is to that tap's LR luma — so chroma edges snap to luma
  // edges (kills the color bleed a plain bilinear leaves). A 512-entry range LUT keeps it cheap.
  // [aligned approach — luma-guided like Zoom; NOT a bit-exact match of Zoom's 754-instr shader.]
  void chromaAndCombine(const I420Image& in, VideoFrame& out, int outW, int outH) {
    const int cw = in.cw(), ch = in.ch();
    static float rangeLUT[512]; static bool lutInit = false;
    if (!lutInit) { const float s = 16.f; for (int d = -256; d < 256; ++d) rangeLUT[d + 256] = std::exp(-(float)d * d / (2.f * s * s)); lutInit = true; }
    // LR luma at chroma resolution (box-2x of the decoded luma) = the low-res guide reference
    std::vector<float> lumaLo((size_t)cw * ch, 0.f);
    for (int cy = 0; cy < ch; ++cy) for (int cx = 0; cx < cw; ++cx) {
      int x0 = cx * 2, y0 = cy * 2, x1 = x0 + 1 < in.w ? x0 + 1 : x0, y1 = y0 + 1 < in.h ? y0 + 1 : y0;
      lumaLo[(size_t)cy * cw + cx] = 0.25f * (in.y[(size_t)y0 * in.w + x0] + in.y[(size_t)y0 * in.w + x1] +
                                              in.y[(size_t)y1 * in.w + x0] + in.y[(size_t)y1 * in.w + x1]);
    }
    // Zoom CChromaUpsample = luma-guided GUIDED FILTER (sh_804dec70). When chromaGuided_ is on, precompute
    // per-chroma-pixel (a,b) over a 3x3 window (N=9, EPS=105.3405), applied block-constant per chroma cell;
    // low guide-variance cells fall back to JBU (Zoom's stability gate). Off = our JBU (range-LUT bilateral).
    std::vector<float> aU, bU, aV, bV; std::vector<uint8_t> gok;
    if (chromaGuided_) {
      aU.assign((size_t)cw * ch, 0); bU = aU; aV = aU; bV = aU; gok.assign((size_t)cw * ch, 0);
      auto L = [&](int x, int y){ x = x<0?0:(x>=cw?cw-1:x); y = y<0?0:(y>=ch?ch-1:y); return lumaLo[(size_t)y*cw+x]; };
      auto CU = [&](int x, int y){ x = x<0?0:(x>=cw?cw-1:x); y = y<0?0:(y>=ch?ch-1:y); return (float)in.u[(size_t)y*cw+x]; };
      auto CV = [&](int x, int y){ x = x<0?0:(x>=cw?cw-1:x); y = y<0?0:(y>=ch?ch-1:y); return (float)in.v[(size_t)y*cw+x]; };
      const float EPS = 105.3405f;
      for (int cy = 0; cy < ch; ++cy) for (int cx = 0; cx < cw; ++cx) {
        float Sy=0, Syy=0, Su=0, Syu=0, Sv=0, Syv=0;
        for (int j=-1;j<=1;++j) for (int i=-1;i<=1;++i) { float y=L(cx+i,cy+j), u=CU(cx+i,cy+j), v=CV(cx+i,cy+j);
          Sy+=y; Syy+=y*y; Su+=u; Syu+=y*u; Sv+=v; Syv+=y*v; }
        float varN2 = 9*Syy - Sy*Sy;                              // = N^2 * var(Y guide)
        size_t idx = (size_t)cy*cw+cx;
        aU[idx] = (9*Syu - Sy*Su)/(varN2+EPS); bU[idx] = (Su - aU[idx]*Sy)/9.f;
        aV[idx] = (9*Syv - Sy*Sv)/(varN2+EPS); bV[idx] = (Sv - aV[idx]*Sy)/9.f;
        gok[idx] = (varN2 >= 5625.f) ? 1 : 0;                     // Zoom's low-variance gate
      }
    }
    out.width = outW; out.height = outH; out.stride = outW * 4; out.format = PixelFormat::BGRA;
    out.data.assign((size_t)outW * outH * 4, 0);
    const double fx = (double)cw / outW, fy = (double)ch / outH;
    for (int oy = 0; oy < outH; ++oy) {
      double scy = (oy + 0.5) * fy - 0.5; int cy0 = (int)std::floor(scy); float ty = (float)(scy - cy0);
      for (int ox = 0; ox < outW; ++ox) {
        double scx = (ox + 0.5) * fx - 0.5; int cx0 = (int)std::floor(scx); float tx = (float)(scx - cx0);
        float gh = rY_[(size_t)oy * outW + ox];                      // HR luma guide
        float U, V;
        int gcx = cx0 + (tx >= 0.5f ? 1 : 0), gcy = cy0 + (ty >= 0.5f ? 1 : 0);   // nearest chroma cell
        gcx = gcx<0?0:(gcx>=cw?cw-1:gcx); gcy = gcy<0?0:(gcy>=ch?ch-1:gcy);
        if (chromaGuided_ && gok[(size_t)gcy*cw+gcx]) {              // Zoom guided filter: U = a*Y_hr + b
          size_t gi = (size_t)gcy*cw+gcx;
          U = (aU[gi]*gh + bU[gi]) - 128.f; V = (aV[gi]*gh + bV[gi]) - 128.f;
        } else {                                                     // our JBU (or guided low-var fallback)
          float su = 0, sv = 0, sw = 0;
          for (int j = 0; j < 2; ++j) for (int i = 0; i < 2; ++i) {
            int cx = cx0 + i, cy = cy0 + j; cx = cx < 0 ? 0 : (cx >= cw ? cw - 1 : cx); cy = cy < 0 ? 0 : (cy >= ch ? ch - 1 : cy);
            float wsp = (i ? tx : 1 - tx) * (j ? ty : 1 - ty);
            int dl = (int)(gh - lumaLo[(size_t)cy * cw + cx]); dl = dl < -256 ? -256 : (dl > 255 ? 255 : dl);
            float w = wsp * rangeLUT[dl + 256];
            su += in.u[(size_t)cy * cw + cx] * w; sv += in.v[(size_t)cy * cw + cx] * w; sw += w;
          }
          U = (sw > 1e-6f ? su / sw : 128.f) - 128.f; V = (sw > 1e-6f ? sv / sw : 128.f) - 128.f;
        }
        uint8_t* d = &out.data[((size_t)oy * outW + ox) * 4];
        d[0] = clamp8((int)(gh + 1.772f * U + 0.5f));
        d[1] = clamp8((int)(gh - 0.344136f * U - 0.714136f * V + 0.5f));
        d[2] = clamp8((int)(gh + 1.402f * V + 0.5f));
        d[3] = 255;
      }
    }
  }

  static void bilinearPlane(const float* s, int w, int h, std::vector<float>& d, int dw, int dh) {
    d.assign((size_t)dw * dh, 0.f);
    if (w <= 0 || h <= 0) return;
    const double fx = (double)w / dw, fy = (double)h / dh;
    for (int y = 0; y < dh; ++y) {
      double sy = (y + 0.5) * fy - 0.5; int y0 = (int)(sy < 0 ? 0 : sy); double ty = sy - y0;
      if (y0 >= h - 1) { y0 = h - 1; ty = 0; } int y1 = y0 + 1 < h ? y0 + 1 : y0;
      for (int x = 0; x < dw; ++x) {
        double sx = (x + 0.5) * fx - 0.5; int x0 = (int)(sx < 0 ? 0 : sx); double tx = sx - x0;
        if (x0 >= w - 1) { x0 = w - 1; tx = 0; } int x1 = x0 + 1 < w ? x0 + 1 : x0;
        float a = s[(size_t)y0 * w + x0], b = s[(size_t)y0 * w + x1];
        float c = s[(size_t)y1 * w + x0], e = s[(size_t)y1 * w + x1];
        float top = a * (1 - (float)tx) + b * (float)tx, bot = c * (1 - (float)tx) + e * (float)tx;
        d[(size_t)y * dw + x] = top * (1 - (float)ty) + bot * (float)ty;
      }
    }
  }

  bool chromaGuided_ = false;                            // false=JBU (our enhanced), true=Zoom-exact guided filter
  recon::zlt::GpuRaisr gpu_;                              // screen path (GPU)
  recon::zltcam::GpuCamRaisr gpuCam_;                     // camera path (GPU, full)
  recon::zltcam::TrainedCamBank camBankX2_, camBankX3_;   // camera path CPU fallback (Raisrx2 / Raisrx3)
  std::vector<float> baseY_, rY_;                         // bilinear base (GPU) / RAISR-refined HR luma
  bool gpuReady_ = false, camReady_ = false, gpuCamReady_ = false;
};

}  // namespace avp
