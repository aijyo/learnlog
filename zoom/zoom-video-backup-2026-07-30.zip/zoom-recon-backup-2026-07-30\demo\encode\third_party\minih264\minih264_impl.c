/* minih264 implementation TU -- compiled as C (the library is C89; C++ rejects its
   implicit void* conversions). C compilation gives plain C linkage, matching the
   header's extern "C" declarations the C++ callers use. */
#define MINIH264_IMPLEMENTATION
#include "minih264e.h"
