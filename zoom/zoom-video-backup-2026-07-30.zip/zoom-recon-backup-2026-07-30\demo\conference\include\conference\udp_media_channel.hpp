// udp_media_channel.hpp — a REAL UDP IMediaChannel. Every packet is serialized to the wire format and
// sent through an actual winsock UDP socket (127.0.0.1), then received + parsed back — the real
// kernel network path, not an in-process queue. By default it loops back to its own receive port
// (single process); pass a dest port to send to a *separate* receiver process. Loss is injected at the
// receiver (loopback itself is lossless) so FEC/jitter recovery is still exercised.
#pragma once
#include "conference/media_channel.hpp"
#include "transport/socket_transport.hpp"
#include <cstdint>
#include <vector>

namespace avp {

class UdpMediaChannel : public IMediaChannel {
public:
  // dest_port 0 => loop back to our own receive socket (single process, real UDP).
  bool open(double loss = 0.0, uint16_t dest_port = 0, uint32_t seed = 0x51ED) {
    if (!rx_.open(0)) return false;
    if (!tx_.open(0)) return false;
    rx_port_ = rx_.local_port();
    dest_port_ = dest_port ? dest_port : rx_port_;
    loss_ = loss; s_ = seed ? seed : 1;
    return rx_port_ != 0;
  }

  void send(const WirePacket& w) override {
    ++sent_;
    auto b = wire::serialize(w);
    tx_.send_to(dest_port_, b.data(), (int)b.size());   // real sendto over 127.0.0.1
  }

  std::vector<WirePacket> deliver() override {
    std::vector<WirePacket> out; uint8_t buf[4096];
    for (;;) {
      int n = rx_.recv_nb(buf, sizeof(buf));            // real non-blocking recvfrom
      if (n <= 0) break;
      WirePacket w;
      if (!wire::deserialize(buf, n, w)) continue;
      if (next() < loss_) { ++dropped_; continue; }     // channel loss model (loopback is lossless)
      out.push_back(std::move(w));
    }
    return out;
  }

  long sent() const override { return sent_; }
  long dropped() const override { return dropped_; }
  const char* name() const override { return "real UDP (winsock 127.0.0.1)"; }
  uint16_t rx_port() const { return rx_port_; }
  void set_loss(double l) { loss_ = l; }

private:
  double next() { s_ = s_ * 1664525u + 1013904223u; return (s_ >> 8) / (double)(1u << 24); }
  WsaScope wsa_;
  UdpSocket tx_, rx_;
  uint16_t rx_port_ = 0, dest_port_ = 0;
  double loss_ = 0; uint32_t s_ = 1;
  long sent_ = 0, dropped_ = 0;
};

}  // namespace avp
