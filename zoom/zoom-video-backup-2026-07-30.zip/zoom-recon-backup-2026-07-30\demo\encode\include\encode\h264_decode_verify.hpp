// h264_decode_verify.hpp — close the encode loop with a REAL decoder (AVP_WITH_FFMPEG). Decodes the
// H.264 Annex-B that minih264 produced through FFmpeg avcodec back to I420 and computes PSNR against
// the source frame — the same "real encoder -> real decoder, compare pixels" check the mcm/zbt slices
// use. Without FFMPEG the encoder still runs and is validated by NAL-structure parsing (self-contained).
#pragma once
#ifdef AVP_WITH_FFMPEG
#include "preprocess/video_convert.hpp"
#include <cmath>
#include <cstdint>
#include <vector>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/imgutils.h>
}

namespace avp {

// A stateful H.264 decoder (frames may depend on earlier ones). Feed Annex-B frames in order.
class H264Decoder {
public:
  bool open() {
    const AVCodec* dec = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!dec) return false;
    c_ = avcodec_alloc_context3(dec);
    if (!c_) return false;
    c_->thread_count = 1;                    // no frame-threading -> no multi-frame output delay
    c_->flags |= AV_CODEC_FLAG_LOW_DELAY;    // emit each frame as soon as it's decoded
    return avcodec_open2(c_, dec, nullptr) == 0;
  }
  // decode one Annex-B access unit into I420 (out). Returns true if a frame came out.
  bool decode(const std::vector<uint8_t>& annexb, I420Image& out) {
    if (!c_) return false;
    std::vector<uint8_t> padded(annexb);
    padded.resize(annexb.size() + AV_INPUT_BUFFER_PADDING_SIZE, 0);
    AVPacket* pkt = av_packet_alloc(); pkt->data = padded.data(); pkt->size = (int)annexb.size();
    AVFrame* f = av_frame_alloc();
    bool got = false;
    if (avcodec_send_packet(c_, pkt) == 0) {
      while (avcodec_receive_frame(c_, f) == 0) {           // drain every frame this packet produced
        out.w = f->width; out.h = f->height;
        out.y.assign((size_t)out.w * out.h, 0);
        out.u.assign((size_t)out.cw() * out.ch(), 128);
        out.v.assign((size_t)out.cw() * out.ch(), 128);
        for (int j = 0; j < out.h; ++j) memcpy(&out.y[(size_t)j * out.w], f->data[0] + (size_t)j * f->linesize[0], out.w);
        for (int j = 0; j < out.ch(); ++j) {
          memcpy(&out.u[(size_t)j * out.cw()], f->data[1] + (size_t)j * f->linesize[1], out.cw());
          memcpy(&out.v[(size_t)j * out.cw()], f->data[2] + (size_t)j * f->linesize[2], out.cw());
        }
        got = true;
      }
    }
    av_frame_free(&f); av_packet_free(&pkt);
    return got;
  }
  ~H264Decoder() { if (c_) avcodec_free_context(&c_); }
private:
  AVCodecContext* c_ = nullptr;
};

// luma PSNR between two same-size I420 frames (dB; INFINITY if identical).
inline double PsnrY(const I420Image& a, const I420Image& b) {
  int w = a.w < b.w ? a.w : b.w, h = a.h < b.h ? a.h : b.h;
  double mse = 0; long n = 0;
  for (int j = 0; j < h; ++j) for (int i = 0; i < w; ++i) {
    double d = (double)a.y[(size_t)j * a.w + i] - b.y[(size_t)j * b.w + i]; mse += d * d; ++n;
  }
  if (n == 0) return 0; mse /= n;
  return mse < 1e-9 ? 99.0 : 10.0 * std::log10(255.0 * 255.0 / mse);
}

}  // namespace avp
#endif  // AVP_WITH_FFMPEG
