# -*- coding: utf-8 -*-
# Build a wiki-style HTML (sticky TOC sidebar + committed dark theme matching ZOOM_VIDEO_PIPELINE)
# from markdown. Usage: python md2wiki.py <src.md> <out.html>
import re, sys
SRC_MD, OUT = sys.argv[1], sys.argv[2]

def esc_code(s):
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
_LINKY = re.compile(r"(https?://|ftp://|mailto:|www\.|/|#)")
def inline(text):
    stash=[]
    def sc(m):
        stash.append("<code>"+esc_code(m.group(1))+"</code>"); return "\x00%d\x00"%(len(stash)-1)
    text=re.sub(r"`([^`]*)`",sc,text)
    text=text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
    text=re.sub(r"\*\*(.+?)\*\*",r"<strong>\1</strong>",text)
    def lr(m):
        t,u=m.group(1),m.group(2); return ("<a href='%s'>%s</a>"%(u,t)) if _LINKY.match(u) else m.group(0)
    text=re.sub(r"\[([^\]]*)\]\(([^)]*)\)",lr,text)
    text=re.sub("\x00(\\d+)\x00",lambda m:stash[int(m.group(1))],text)
    return text
def is_sep(l):
    s=l.strip(); return bool(s) and set(s)<=set("|-: ") and "-" in s
def split_row(r):
    r=r.strip()
    if r.startswith("|"): r=r[1:]
    if r.endswith("|"): r=r[:-1]
    return [c.strip() for c in r.split("|")]
def table(header,rows):
    ths="".join("<th>"+inline(c)+"</th>" for c in split_row(header))
    trs="".join("<tr>"+"".join("<td>"+inline(c)+"</td>" for c in split_row(r))+"</tr>" for r in rows)
    return "<div class='tw'><table><thead><tr>"+ths+"</tr></thead><tbody>"+trs+"</tbody></table></div>"

md=open(SRC_MD,encoding="utf-8-sig").read().split("\n")
blocks=[]; toc=[]; i=0; n=len(md); sid=0
ORD=re.compile(r"\s*(\d+)\.\s"); ORDC=re.compile(r"\s*\d+\.\s+(.*)$")
title="文档"
while i<n:
    line=md[i]; s=line.strip()
    if s.startswith("```"):
        i+=1; code=[]
        while i<n and not md[i].strip().startswith("```"): code.append(md[i]); i+=1
        i+=1; blocks.append("<pre class='code'><code>"+esc_code("\n".join(code))+"</code></pre>"); continue
    if s=="": i+=1; continue
    if s=="---": blocks.append("<hr>"); i+=1; continue
    m=re.match(r"(#{1,4})\s+(.*)$",line)
    if m:
        lvl=len(m.group(1)); txt=inline(m.group(2).rstrip())
        if lvl==1:
            title=re.sub("<[^>]+>","",txt); blocks.append("<h1>"+txt+"</h1>"); i+=1; continue
        sid+=1; anc="s%d"%sid
        if lvl in (2,3): toc.append((lvl,anc,txt))
        blocks.append("<h%d id='%s'>%s<a class='ah' href='#%s'>#</a></h%d>"%(lvl,anc,txt,anc,lvl)); i+=1; continue
    if s.startswith("|") and i+1<n and is_sep(md[i+1]):
        header=md[i]; i+=2; rows=[]
        while i<n and md[i].strip().startswith("|"): rows.append(md[i]); i+=1
        blocks.append(table(header,rows)); continue
    if line.startswith(">"):
        bq=[]
        while i<n and md[i].startswith(">"):
            c=md[i][1:];  c=c[1:] if c.startswith(" ") else c
            bq.append(inline(c.rstrip())); i+=1
        blocks.append("<blockquote>"+"<br>".join(bq)+"</blockquote>"); continue
    if line.lstrip().startswith("- "):
        it=[]
        while i<n and md[i].lstrip().startswith("- "): it.append("<li>"+inline(md[i].lstrip()[2:].rstrip())+"</li>"); i+=1
        blocks.append("<ul>"+"".join(it)+"</ul>"); continue
    if ORD.match(line):
        it=[]
        while i<n and ORD.match(md[i]): it.append("<li>"+inline(ORDC.match(md[i]).group(1).rstrip())+"</li>"); i+=1
        blocks.append("<ol>"+"".join(it)+"</ol>"); continue
    blocks.append("<p>"+inline(s)+"</p>"); i+=1

tl=["<div class='toc-h'>目录</div><ul class='toc-l'>"]
for lvl,anc,txt in toc:
    t=re.sub("<[^>]+>","",txt)
    tl.append("<li class='t%d'><a href='#%s'>%s</a></li>"%(lvl,anc,t))
tl.append("</ul>")
toc_html="".join(tl)

# Committed dark theme, palette identical to ZOOM_VIDEO_PIPELINE.html.
CSS="""
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:#0f1216;color:#d7dde5;font:16px/1.7 -apple-system,Segoe UI,Roboto,'Microsoft YaHei',sans-serif}
.wiki{display:flex;align-items:flex-start;max-width:1240px;margin:0 auto;gap:32px;padding:0 24px}
.toc{position:sticky;top:0;align-self:flex-start;width:266px;flex:none;max-height:100vh;overflow-y:auto;padding:26px 8px 40px 0;border-right:1px solid #232a33}
.toc-h{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#8b96a5;margin:0 0 10px 12px}
.toc-l{list-style:none;margin:0;padding:0}
.toc-l li a{display:block;padding:4px 12px;color:#8b96a5;text-decoration:none;font-size:13.5px;border-left:2px solid transparent;line-height:1.45}
.toc-l li a:hover{color:#5aa9e6;border-left-color:#5aa9e6}
.toc-l li.t3 a{padding-left:26px;font-size:12.5px}
.toc-l li.t2 a{font-weight:600;color:#d7dde5}
.doc{flex:1;min-width:0;padding:26px 0 96px;max-width:900px}
h1{font-size:28px;line-height:1.25;margin:.2em 0 .5em;font-weight:800;border-bottom:2px solid #5aa9e6;padding-bottom:12px}
h2{font-size:21px;margin:2em 0 .6em;padding-bottom:6px;border-bottom:1px solid #232a33;color:#5aa9e6;scroll-margin-top:20px;font-weight:700}
h3{font-size:17px;margin:1.6em 0 .4em;color:#7bd88f;scroll-margin-top:20px;font-weight:700}
h4{font-size:15px;margin:1.2em 0 .3em;color:#e6b45a}
h2 .ah,h3 .ah{opacity:0;margin-left:.4em;font-size:.7em;color:#8b96a5;text-decoration:none}
h2:hover .ah,h3:hover .ah{opacity:.6}
p{margin:.65em 0}a{color:#5aa9e6}
strong{color:#fff;font-weight:700}
ul,ol{margin:.6em 0;padding-left:1.5em}li{margin:.35em 0}
blockquote{border-left:3px solid #5aa9e6;background:#12161c;margin:1.1em 0;padding:.7em 1.1em;color:#9aa4b2;border-radius:0 6px 6px 0}
blockquote strong{color:#fff}
code{background:#161b22;border:1px solid #232a33;border-radius:4px;padding:1px 5px;font:13.5px/1.5 'Cascadia Code',Consolas,monospace;color:#e6c07b}
pre.code{background:#161b22;border:1px solid #232a33;border-radius:8px;padding:14px 16px;overflow-x:auto;margin:1em 0}
pre.code code{background:none;border:none;padding:0;color:#d7dde5;white-space:pre;font-size:13px}
.tw{overflow-x:auto;margin:1.1em 0}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{border:1px solid #232a33;padding:7px 10px;text-align:left;vertical-align:top}
th{background:#1a2029;font-weight:600;white-space:nowrap}
tbody tr:nth-child(even) td{background:#12161c}
hr{border:none;border-top:1px solid #232a33;margin:2em 0}
@media (max-width:980px){.wiki{flex-direction:column;gap:0;padding:0 18px}.toc{position:static;width:auto;max-height:none;border-right:none;border-bottom:1px solid #232a33;padding:18px 0}.doc{padding-top:18px}}
"""

html=("<!doctype html><html lang='zh'><head><meta charset='utf-8'>"
      "<meta name='viewport' content='width=device-width,initial-scale=1'>"
      "<title>"+title+"</title><style>"+CSS+"</style></head><body>"
      "<div class='wiki'><nav class='toc'>"+toc_html+"</nav>"
      "<main class='doc'>"+"\n".join(blocks)+"</main></div></body></html>")
open(OUT,"w",encoding="utf-8",newline="").write(html)

import re as _re
leaked=_re.findall(r"<p>[^<]*\|[^<]*\|[^<]*</p>",html)
print("OUT bytes=%d  toc=%d  tables=%d  pre=%d  head_ok=%s tail_ok=%s fences=%s pipeLeak=%d"%(
    len(html.encode("utf-8")),len(toc),html.count("<table>"),html.count("<pre class='code'>"),
    html.startswith("<!doctype html>"),html.endswith("</body></html>"),("```" in html),len(leaked)))
