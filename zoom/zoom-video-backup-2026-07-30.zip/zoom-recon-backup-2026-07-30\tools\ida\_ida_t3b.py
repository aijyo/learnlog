import idc, ida_hexrays, ida_funcs
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
def decomp(ea, label):
    f = ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x (%s)" % (ea, label)); return
    try:
        L.append("\n// ===== %s  %s  (0x%x) =====" % (label, idc.get_func_name(f.start_ea), f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e:
        L.append("// FAILED 0x%x: %s" % (ea, e))
decomp(0x1801C1100, "Light.brightness_stat")     # the value compared vs 100 / 170
decomp(0x18023DEC0, "CSC.kernelA")               # color-space-cvt dispatched kernel A
decomp(0x18023E100, "CSC.kernelB")               # color-space-cvt dispatched kernel B
open(out, "w", encoding="utf-8", errors="replace").write("\n".join(L))
idc.qexit(0)
