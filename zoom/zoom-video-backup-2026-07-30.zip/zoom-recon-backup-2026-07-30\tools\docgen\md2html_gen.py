# -*- coding: utf-8 -*-
# Generalized mechanical MD -> HTML transform. Reuses the EXISTING html's PREAMBLE
# (head/style/body/<div class='wrap'>) verbatim so each doc keeps its own theme.
# Usage: python md2html_gen.py <src.md> <inout.html>
import re, sys

if len(sys.argv) != 3:
    sys.stderr.write("usage: md2html_gen.py <src.md> <inout.html>\n"); sys.exit(2)
SRC_MD, IO_HTML = sys.argv[1], sys.argv[2]
SUFFIX = "</div></body></html>"

with open(IO_HTML, "r", encoding="utf-8-sig") as f:
    html = f.read()
# accept either quote style for the wrap div
idx, MARKER = -1, None
for cand in ("<div class='wrap'>", '<div class="wrap">'):
    j = html.find(cand)
    if j != -1:
        idx, MARKER = j, cand; break
if idx == -1:
    sys.stderr.write("FATAL: wrap-div marker not found in %s\n" % IO_HTML); sys.exit(1)
PREAMBLE = html[:idx + len(MARKER)]

def esc_code(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

_LINKY = re.compile(r"(https?://|ftp://|mailto:|www\.|/|#)")

def inline(text):
    stash = []
    def stash_code(m):
        stash.append("<code>" + esc_code(m.group(1)) + "</code>")
        return "\x00%d\x00" % (len(stash) - 1)
    text = re.sub(r"`([^`]*)`", stash_code, text)
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    def link_repl(m):
        txt, url = m.group(1), m.group(2)
        return ("<a href='%s'>%s</a>" % (url, txt)) if _LINKY.match(url) else m.group(0)
    text = re.sub(r"\[([^\]]*)\]\(([^)]*)\)", link_repl, text)
    text = re.sub("\x00(\\d+)\x00", lambda m: stash[int(m.group(1))], text)
    return text

def is_separator(line):
    s = line.strip()
    return bool(s) and set(s) <= set("|-: ") and "-" in s

def split_row(row):
    row = row.strip()
    if row.startswith("|"): row = row[1:]
    if row.endswith("|"): row = row[:-1]
    return [c.strip() for c in row.split("|")]

def build_table(header, rows):
    ths = "".join("<th>" + inline(c) + "</th>" for c in split_row(header))
    trs = ""
    for r in rows:
        trs += "<tr>" + "".join("<td>" + inline(c) + "</td>" for c in split_row(r)) + "</tr>"
    return "<table><thead><tr>" + ths + "</tr></thead><tbody>" + trs + "</tbody></table>"

with open(SRC_MD, "r", encoding="utf-8-sig") as f:
    md = f.read()
lines = md.split("\n")
blocks = []
i, n = 0, len(lines)
ORD = re.compile(r"\s*(\d+)\.\s")
ORDC = re.compile(r"\s*\d+\.\s+(.*)$")

while i < n:
    line = lines[i]; s = line.strip()
    if s.startswith("```"):
        i += 1; code = []
        while i < n and not lines[i].strip().startswith("```"):
            code.append(lines[i]); i += 1
        i += 1
        blocks.append("<pre class=\"code\"><code>" + esc_code("\n".join(code)) + "</code></pre>")
        continue
    if s == "": i += 1; continue
    if s == "---": blocks.append("<hr>"); i += 1; continue
    m = re.match(r"(#{1,4})\s+(.*)$", line)
    if m:
        lvl = len(m.group(1))
        blocks.append("<h%d>%s</h%d>" % (lvl, inline(m.group(2).rstrip()), lvl)); i += 1; continue
    if s.startswith("|") and i + 1 < n and is_separator(lines[i + 1]):
        header = lines[i]; i += 2; rows = []
        while i < n and lines[i].strip().startswith("|"): rows.append(lines[i]); i += 1
        blocks.append(build_table(header, rows)); continue
    if line.startswith(">"):
        bq = []
        while i < n and lines[i].startswith(">"):
            c = lines[i][1:]
            if c.startswith(" "): c = c[1:]
            bq.append(inline(c.rstrip())); i += 1
        blocks.append("<blockquote>" + "<br>".join(bq) + "</blockquote>"); continue
    if line.lstrip().startswith("- "):
        items = []
        while i < n and lines[i].lstrip().startswith("- "):
            items.append("<li>" + inline(lines[i].lstrip()[2:].rstrip()) + "</li>"); i += 1
        blocks.append("<ul>" + "".join(items) + "</ul>"); continue
    if ORD.match(line):
        items = []
        while i < n and ORD.match(lines[i]):
            items.append("<li>" + inline(ORDC.match(lines[i]).group(1).rstrip()) + "</li>"); i += 1
        blocks.append("<ol>" + "".join(items) + "</ol>"); continue
    blocks.append("<p>" + inline(s) + "</p>"); i += 1

out = PREAMBLE + "\n".join(blocks) + SUFFIX
with open(IO_HTML, "w", encoding="utf-8", newline="") as f:
    f.write(out)

# generic verification
data = out
leaked = re.findall(r"<p>[^<]*\|[^<]*\|[^<]*</p>", data)
print("%-46s bytes=%6d  h2=%2d table=%2d pre=%2d  ok_head=%s ok_tail=%s fences=%s pipeLeak=%d" % (
    IO_HTML.split("/")[-1], len(data.encode("utf-8")),
    data.count("<h2>"), data.count("<table>"), data.count("<pre class=\"code\">"),
    data.startswith("<!doctype html>"), data.endswith("</body></html>"),
    ("```" in data), len(leaked)))
if leaked:
    for L in leaked[:5]: print("   PIPE-LEAK:", L[:140])
