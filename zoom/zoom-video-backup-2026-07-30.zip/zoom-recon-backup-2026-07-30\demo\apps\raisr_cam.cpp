// raisr_cam.cpp -- RAISR super-resolution live engine for the AvpMonitor "超分" tab.
// Opens the selected camera at a chosen low input resolution R, then produces two 2R images:
//   left  = plain bilinear x2 (naive)          right = RAISR x2 (luma RAISR + bilinear chroma)
// Both share identical chroma, so the visible left/right difference is exactly RAISR's luma super-res.
// Uses the clean-room recon library (zlt_raisr.hpp) + our trained bank (raisr_bank.bin). Writes the pair
// to the RaisrShare shared memory the WPF tab reads. `--synth` runs a moving detail pattern (no camera).
#include "capture/camera_mf.hpp"
#include "capture/video_source.hpp"
#include "apps/ipc_shared.hpp"
#include "apps/ipc_writer.hpp"
#include "zlt_raisr.hpp"
#include "raisr_gpu.hpp"
#include <cstdio>
#include <cstring>
#include <cmath>
#include <chrono>
#include <thread>
#include <vector>
#include <string>
using std::vector;
using namespace avp;
using recon::zlt::RaisrConfig; using recon::zlt::RaisrUpscaler; using recon::zlt::TrainedFilterBank;
using recon::zlt::GpuRaisr; using recon::zlt::RaisrWatchdog;

// ---- color + resample ----
static void bgraToYUV(const uint8_t* p, int w, int h, vector<float>& Y, vector<float>& U, vector<float>& V) {
    Y.assign((size_t)w*h, 0); U.assign((size_t)w*h, 0); V.assign((size_t)w*h, 0);
    for (int i = 0; i < w*h; ++i) {
        float B = p[i*4+0], G = p[i*4+1], R = p[i*4+2];
        Y[i] = 0.299f*R + 0.587f*G + 0.114f*B;
        U[i] = -0.169f*R - 0.331f*G + 0.5f*B + 128.f;
        V[i] = 0.5f*R - 0.419f*G - 0.081f*B + 128.f;
    }
}
static void yuvToBGRA(const float* Y, const float* U, const float* V, int w, int h, vector<uint8_t>& out) {
    out.assign((size_t)w*h*4, 255);
    auto cl = [](float v) { return (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v + 0.5f)); };
    for (int i = 0; i < w*h; ++i) {
        float y = Y[i], u = U[i]-128.f, v = V[i]-128.f;
        out[i*4+0] = cl(y + 1.772f*u);              // B
        out[i*4+1] = cl(y - 0.344f*u - 0.714f*v);   // G
        out[i*4+2] = cl(y + 1.402f*v);              // R
    }
}
// generic bilinear resample of a BGRA image (used to bring the camera's native frame to the chosen R)
static void resampleBGRA(const uint8_t* s, int sw, int sh, vector<uint8_t>& d, int dw, int dh) {
    d.assign((size_t)dw*dh*4, 255);
    for (int y = 0; y < dh; ++y) { float fy = (y+0.5f)*sh/dh - 0.5f; int y0 = (int)std::floor(fy); float wy = fy-y0;
        int y0c = y0<0?0:(y0>=sh?sh-1:y0), y1c = (y0+1)<0?0:((y0+1)>=sh?sh-1:y0+1);
        for (int x = 0; x < dw; ++x) { float fx = (x+0.5f)*sw/dw - 0.5f; int x0 = (int)std::floor(fx); float wx = fx-x0;
            int x0c = x0<0?0:(x0>=sw?sw-1:x0), x1c = (x0+1)<0?0:((x0+1)>=sw?sw-1:x0+1);
            for (int c = 0; c < 3; ++c) {   // BGR only; alpha stays 255 (camera RGB32 alpha is often 0 -> would show black)
                float a = s[((size_t)y0c*sw+x0c)*4+c]*(1-wx) + s[((size_t)y0c*sw+x1c)*4+c]*wx;
                float b = s[((size_t)y1c*sw+x0c)*4+c]*(1-wx) + s[((size_t)y1c*sw+x1c)*4+c]*wx;
                d[((size_t)y*dw+x)*4+c] = (uint8_t)(a*(1-wy)+b*wy + 0.5f);
            }
        }
    }
}
// moving high-detail synthetic scene (fine checker + oriented stripes + color) at R for headless demo
static void synthFrame(vector<uint8_t>& bgra, int w, int h, int t) {
    bgra.assign((size_t)w*h*4, 255);
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
        float v = ((x/2 + y/2) & 1) ? 205.f : 55.f;                       // fine checker (high freq)
        if (((x + t*2) / 9) & 1) v = 0.5f*v + 90.f;                       // moving diagonal stripes
        v += 26.f * std::sin(0.13f*(x*0.8f + y) + t*0.25f);              // moving oriented ripple
        float r = v*1.05f + 18*std::sin(0.06f*x), g = v, b = v*0.9f + 14*std::cos(0.05f*y);
        size_t i = ((size_t)y*w+x)*4;
        auto cl=[](float z){return (uint8_t)(z<0?0:(z>255?255:z));};
        bgra[i+0]=cl(b); bgra[i+1]=cl(g); bgra[i+2]=cl(r); bgra[i+3]=255;
    }
}

// load a raw BGRA image the WPF wrote for --image input: header {int32 w, int32 h} then w*h*4 BGRA (top-down).
// (WPF decodes any format — PNG/JPG/BMP — to BGRA and dumps this, so the engine needs no image decoder.)
static bool loadRawBGRA(const char* path, vector<uint8_t>& img, int& w, int& h) {
    FILE* f = fopen(path, "rb"); if (!f) return false;
    int hdr[2]; if (fread(hdr, 4, 2, f) != 2) { fclose(f); return false; }
    w = hdr[0]; h = hdr[1];
    if (w <= 0 || h <= 0 || w > 8192 || h > 8192) { fclose(f); return false; }
    img.assign((size_t)w * h * 4, 0);
    size_t got = fread(img.data(), 1, img.size(), f); fclose(f);
    return got == img.size();
}

// write a 32-bit BGRA BMP (top-down via negative height) — for the --dump side-by-side proof image.
static void writeBMP(const char* path, const uint8_t* bgra, int w, int h) {
    uint32_t data = (uint32_t)w*h*4, off = 54, fsz = off + data;
    uint8_t H[54]; std::memset(H, 0, 54);
    H[0]='B'; H[1]='M'; std::memcpy(H+2,&fsz,4); std::memcpy(H+10,&off,4);
    uint32_t ih=40; std::memcpy(H+14,&ih,4); std::memcpy(H+18,&w,4); int nh=-h; std::memcpy(H+22,&nh,4);
    uint16_t pl=1, bpp=32; std::memcpy(H+26,&pl,2); std::memcpy(H+28,&bpp,2); std::memcpy(H+34,&data,4);
    FILE* f = std::fopen(path,"wb"); if (!f) return; std::fwrite(H,1,54,f); std::fwrite(bgra,1,data,f); std::fclose(f);
}

int main(int argc, char** argv) {
    int camIdx = 0, inW = 480, inH = 360; bool synth = false, list = false, gpuTest = false, forceGpu = false, forceCpu = false;
    std::string bankPath = "D:/code/work/bin2cpp-output/recon/raisr_bank.bin", dumpPath, imagePath;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--list") list = true;
        else if (a == "--gpu-test") gpuTest = true;
        else if (a == "--force-gpu") forceGpu = true;
        else if (a == "--force-cpu") forceCpu = true;
        else if (a == "--image" && i+1 < argc) imagePath = argv[++i];   // static raw-BGRA image as input
        else if (a == "--synth") synth = true;
        else if (a == "--camera" && i+1 < argc) camIdx = std::atoi(argv[++i]);
        else if (a == "--in-w" && i+1 < argc) inW = std::atoi(argv[++i]);
        else if (a == "--in-h" && i+1 < argc) inH = std::atoi(argv[++i]);
        else if (a == "--bank" && i+1 < argc) bankPath = argv[++i];
        else if (a == "--dump" && i+1 < argc) dumpPath = argv[++i];
    }
    if (list) { for (auto& n : EnumerateCameras()) std::printf("%s\n", n.c_str()); return 0; }
    if (inW > 640) inW = 640; if (inH > 480) inH = 480;              // cap so 2x <= kRW x kRH
    const int outW = inW*2, outH = inH*2;

    RaisrConfig cfg; cfg.scale = 2;
    TrainedFilterBank bank; bool haveBank = bank.load(bankPath.c_str());
    if (haveBank) bank.fill(cfg); else std::printf("raisr_cam: bank not found (%s) -> RAISR falls back to bilinear\n", bankPath.c_str());
    RaisrUpscaler bilin(cfg, nullptr), sr(cfg, haveBank ? &bank : nullptr);
    // GPU RAISR (clean-room HLSL of the recovered algorithm + our bank) with the recovered self-disable watchdog.
    GpuRaisr gpu; bool gpuOk = false;
    if (haveBank) gpuOk = gpu.init(cfg.patch, cfg.Buckets(), cfg.Phases(), cfg.flat_thresh, cfg.str_thresh, bank.data);
    bool useGpu = false;   // decided by the startup calibration below
    RaisrWatchdog wd;   // 15 ms/frame budget, 2 strikes / 320 frames -> self-disable (实证 sub_1801B9200)

    // source: static image (--image) > camera > synth
    vector<uint8_t> srcImg; int imgW = 0, imgH = 0; bool haveImage = false;
    if (!imagePath.empty()) { haveImage = loadRawBGRA(imagePath.c_str(), srcImg, imgW, imgH);
                              std::printf("raisr_cam: image %s (%dx%d)\n", haveImage ? "loaded" : "load FAILED", imgW, imgH); }
    CaptureConfig cc; cc.target = CaptureTarget::Camera; cc.camera_index = camIdx;
    MfCameraSource cam; bool camOk = false;
    if (!synth && !haveImage) { camOk = cam.open(cc); if (!camOk) std::printf("raisr_cam: camera %d open failed -> synth\n", camIdx); }

    // --dump: one warmed-up frame -> a side-by-side BMP (left bilinear | right RAISR), then exit.
    if (!dumpPath.empty()) {
        vector<float> Y, U, V, Yb, Ub, Vb, Yr; int ow, oh; vector<uint8_t> low, left, right; VideoFrame vf;
        for (int k = 0; k < 10; ++k) { if (camOk && cam.grab(vf) && vf.width > 0) resampleBGRA(vf.data.data(), vf.width, vf.height, low, inW, inH); else synthFrame(low, inW, inH, k*4); std::this_thread::sleep_for(std::chrono::milliseconds(60)); }
        bgraToYUV(low.data(), inW, inH, Y, U, V);
        bilin.UpscaleF(Y.data(), inW, inH, Yb, ow, oh); sr.UpscaleF(Y.data(), inW, inH, Yr, ow, oh);
        bilin.UpscaleF(U.data(), inW, inH, Ub, ow, oh); bilin.UpscaleF(V.data(), inW, inH, Vb, ow, oh);
        yuvToBGRA(Yb.data(), Ub.data(), Vb.data(), outW, outH, left);
        yuvToBGRA(Yr.data(), Ub.data(), Vb.data(), outW, outH, right);
        int cw = outW * 2; vector<uint8_t> combo((size_t)cw*outH*4, 0);
        for (int y = 0; y < outH; ++y) {
            std::memcpy(&combo[((size_t)y*cw)*4], &left[(size_t)y*outW*4], (size_t)outW*4);
            std::memcpy(&combo[((size_t)y*cw+outW)*4], &right[(size_t)y*outW*4], (size_t)outW*4);
        }
        writeBMP(dumpPath.c_str(), combo.data(), cw, outH);
        std::printf("raisr_cam: dumped %s (left Bilinear x2 | right RAISR x2, %dx%d, %s)\n", dumpPath.c_str(), cw, outH, camOk ? "camera" : "synth");
        return 0;
    }

    // --gpu-test: verify the GPU HLSL is a faithful port of the CPU reference (mean|CPU-GPU| ~ 0).
    if (gpuTest) {
        vector<float> Y, U, V, Yb, Ycpu, Ygpu; int ow, oh; vector<uint8_t> low;
        synthFrame(low, inW, inH, 5);
        bgraToYUV(low.data(), inW, inH, Y, U, V);
        bilin.UpscaleF(Y.data(), inW, inH, Yb, ow, oh);
        sr.UpscaleF(Y.data(), inW, inH, Ycpu, ow, oh);
        if (gpuOk) {
            gpu.upscale(Yb.data(), outW, outH, Ygpu);   // warm up (first dispatch/alloc is slow)
            double computeMs = 0;
            auto w0 = std::chrono::steady_clock::now();
            gpu.upscale(Yb.data(), outW, outH, Ygpu, &computeMs);
            double wallMs = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - w0).count();
            double d = 0, mx = 0; long nz = 0;
            for (size_t i = 0; i < Ycpu.size(); ++i) { double e = std::fabs(Ycpu[i] - Ygpu[i]); d += e; if (e > mx) mx = e; if (e > 0.5) ++nz; }
            std::printf("gpu-test: adapter='%s'\n", gpu.adapter().c_str());
            std::printf("gpu-test: GPU compute=%.2f ms  wall(incl upload+readback)=%.2f ms  on %dx%d\n", computeMs, wallMs, outW, outH);
            std::printf("gpu-test: mean|CPU-GPU|=%.3f max=%.1f (%.2f%% >0.5) -> HLSL %s the CPU reference\n",
                        d / Ycpu.size(), mx, 100.0 * nz / Ycpu.size(), d / Ycpu.size() < 1.0 ? "MATCHES" : "DIVERGES from");
        } else std::printf("gpu-test: GPU unavailable\n");
        return 0;
    }

    // path selection: --force-gpu / --force-cpu override; otherwise calibrate (below).
    if (forceCpu) { useGpu = false; std::printf("raisr_cam: --force-cpu\n"); }
    else if (forceGpu) { useGpu = gpuOk; std::printf("raisr_cam: --force-gpu -> %s (watchdog auto-disable bypassed)\n", gpuOk ? "GPU" : "GPU unavailable -> CPU"); }
    // calibrate: use the GPU only if it's actually faster than our multi-thread CPU on THIS machine (a real
    // GPU wins by 10x+; a virtual/remote-desktop D3D adapter can be slower due to the readback). The recovered
    // watchdog then handles any ongoing drift. Warm up once (shader/thread/texture init), then time.
    else if (gpuOk) {
        vector<float> Y, U, V, Yb, Ytmp; int ow, oh; vector<uint8_t> low;
        synthFrame(low, inW, inH, 1); bgraToYUV(low.data(), inW, inH, Y, U, V);
        bilin.UpscaleF(Y.data(), inW, inH, Yb, ow, oh);
        gpu.upscale(Yb.data(), outW, outH, Ytmp); sr.UpscaleF(Y.data(), inW, inH, Ytmp, ow, oh);   // warm up
        auto g0 = std::chrono::steady_clock::now(); gpu.upscale(Yb.data(), outW, outH, Ytmp);
        double gms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - g0).count();
        auto c0 = std::chrono::steady_clock::now(); sr.UpscaleF(Y.data(), inW, inH, Ytmp, ow, oh);
        double cms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - c0).count();
        useGpu = gms < cms;
        std::printf("raisr_cam: calibrate GPU %.1f ms vs CPU %.1f ms -> use %s\n", gms, cms, useGpu ? "GPU" : "CPU");
    }
    std::printf("raisr_cam: RAISR path = %s\n", useGpu ? "GPU D3D11 (hardware compute shader)" : gpuOk ? "CPU multi-thread (GPU slower on this machine)" : "CPU multi-thread");
    std::fflush(stdout);

    ipc::ShmPublisher<ipc::RaisrShare> shm;
    if (!shm.open(ipc::kRaisrMap())) { std::printf("raisr_cam: shm open failed\n"); return 1; }
    shm->magic = ipc::kMagic; shm->running = 1; shm->in_w = inW; shm->in_h = inH; shm->out_w = outW; shm->out_h = outH; shm->cam_ok = camOk ? 1 : 0;
    std::printf("raisr_cam: %s  in %dx%d -> out %dx%d  bank=%s\n", haveImage ? "image" : camOk ? "camera" : "synth", inW, inH, outW, outH, haveBank ? "loaded" : "none");

    vector<float> Yr, Ur, Vr, Ybil, Ubil, Vbil, Yraisr; int ow, oh;
    vector<uint8_t> low, bilImg, raisrImg; VideoFrame vf;
    auto t0 = std::chrono::steady_clock::now(); long frames = 0; int tt = 0;
    while (true) {
        auto fstart = std::chrono::steady_clock::now();
        // 1) get a low-res BGRA input at (inW,inH): static image > camera > synth
        if (haveImage) resampleBGRA(srcImg.data(), imgW, imgH, low, inW, inH);
        else if (camOk && cam.grab(vf) && vf.width > 0) resampleBGRA(vf.data.data(), vf.width, vf.height, low, inW, inH);
        else synthFrame(low, inW, inH, tt);
        // 2) produce all THREE views so each viewer can pick any: orig(=low), bilinear x2, RAISR x2 (shared chroma)
        bgraToYUV(low.data(), inW, inH, Yr, Ur, Vr);
        bilin.UpscaleF(Yr.data(), inW, inH, Ybil, ow, oh);   // bilinear luma (also the RAISR base)
        bilin.UpscaleF(Ur.data(), inW, inH, Ubil, ow, oh);
        bilin.UpscaleF(Vr.data(), inW, inH, Vbil, ow, oh);
        double gpuMs = 0; bool raisrOn = true;
        if (useGpu) {
            auto g0 = std::chrono::steady_clock::now();
            gpu.upscale(Ybil.data(), outW, outH, Yraisr);
            gpuMs = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - g0).count();
            raisrOn = forceGpu ? true : wd.tick(gpuMs);
            if (!raisrOn) Yraisr = Ybil;
        } else sr.UpscaleF(Yr.data(), inW, inH, Yraisr, ow, oh);
        // 3) compose bilinear + RAISR (out_w x out_h, shared chroma); publish orig + both
        yuvToBGRA(Ybil.data(),   Ubil.data(), Vbil.data(), outW, outH, bilImg);
        yuvToBGRA(Yraisr.data(), Ubil.data(), Vbil.data(), outW, outH, raisrImg);
        ipc::publish_raisr(shm.get(), low.data(), (size_t)inW*inH*4, bilImg.data(), (size_t)outW*outH*4, raisrImg.data(), (size_t)outW*outH*4);
        shm->reserved[0] = raisrOn ? 1 : 0; shm->reserved[1] = (int)(gpuMs * 1000 + 0.5);
        // 4) fps meter + pace to at most ~30 fps (when the RAISR compute is faster than the frame budget)
        ++frames; ++tt;
        auto now = std::chrono::steady_clock::now();
        double el = std::chrono::duration<double>(now - t0).count();
        if (el >= 1.0) { shm->fps_x10 = (int)(frames / el * 10 + 0.5); frames = 0; t0 = now; }
        auto frameMs = std::chrono::duration_cast<std::chrono::milliseconds>(now - fstart);
        auto budget = std::chrono::milliseconds(33);
        if (frameMs < budget) std::this_thread::sleep_for(budget - frameMs);
    }
    return 0;
}
