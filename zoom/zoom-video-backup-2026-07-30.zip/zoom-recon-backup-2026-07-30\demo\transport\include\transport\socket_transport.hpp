// socket_transport.hpp — REAL Windows sockets (winsock2). UDP is the media primary; TCP is the
// reliable fallback (§3.5 / §5). These carry actual bytes over the loopback in the demo — real
// send()/recv(), not a simulation. (The TLS/QUIC secure layer is the separately-verified tp slice:
// bin2cpp-output tp_transport.hpp over real OpenSSL 3 / libcurl — referenced, not duplicated here.)
#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#pragma comment(lib, "ws2_32.lib")

// Stop a UDP socket from being poisoned by an ICMP "port unreachable": on Windows, sending to a port
// nobody is listening on yet flips the sender into WSAECONNRESET so later sends silently fail. Disabling
// SIO_UDP_CONNRESET keeps two peers that start at slightly different times from breaking one direction.
#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif

namespace avp {

struct WsaScope {
  bool ok = false;
  WsaScope() { WSADATA d; ok = WSAStartup(MAKEWORD(2, 2), &d) == 0; }
  ~WsaScope() { if (ok) WSACleanup(); }
};

class UdpSocket {
public:
  ~UdpSocket() { close(); }
  bool open(uint16_t bind_port = 0) {
    s_ = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s_ == INVALID_SOCKET) return false;
    BOOL disable = FALSE; DWORD ret = 0;
    WSAIoctl(s_, SIO_UDP_CONNRESET, &disable, sizeof(disable), nullptr, 0, &ret, nullptr, nullptr);  // don't die on ICMP unreachable
    // Big socket buffers: a video keyframe is a burst of ~90+ packets (~100 KB+); the default ~64 KB
    // SO_RCVBUF overflows and the kernel silently drops part of the keyframe, poisoning the whole GOP
    // (screen-share "0 decoded even at 0% loss"). 8 MB absorbs the burst until the receiver drains it.
    int buf = 8 * 1024 * 1024;
    setsockopt(s_, SOL_SOCKET, SO_RCVBUF, (const char*)&buf, sizeof(buf));
    setsockopt(s_, SOL_SOCKET, SO_SNDBUF, (const char*)&buf, sizeof(buf));
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = htons(bind_port);
    if (bind(s_, (sockaddr*)&a, sizeof(a)) != 0) { close(); return false; }
    return true;
  }
  uint16_t local_port() const {
    sockaddr_in a{}; int n = sizeof(a);
    if (getsockname(s_, (sockaddr*)&a, &n) == 0) return ntohs(a.sin_port);
    return 0;
  }
  bool send_to(uint16_t port, const uint8_t* data, int len) {
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = htons(port);
    return sendto(s_, (const char*)data, len, 0, (sockaddr*)&a, sizeof(a)) == len;
  }
  int recv(uint8_t* buf, int cap, int timeout_ms) {
    DWORD t = (DWORD)timeout_ms; setsockopt(s_, SOL_SOCKET, SO_RCVTIMEO, (const char*)&t, sizeof(t));
    int n = ::recv(s_, (char*)buf, cap, 0);
    return n;   // <=0 on timeout/close
  }
  // non-blocking recvfrom: returns bytes, 0 if nothing waiting, <0 on error. Lets a receiver drain the
  // socket without blocking the real-time loop.
  int recv_nb(uint8_t* buf, int cap) {
    u_long nb = 1; ioctlsocket(s_, FIONBIO, &nb);
    int n = ::recv(s_, (char*)buf, cap, 0);
    if (n < 0 && WSAGetLastError() == WSAEWOULDBLOCK) return 0;
    return n;
  }
  void close() { if (s_ != INVALID_SOCKET) { closesocket(s_); s_ = INVALID_SOCKET; } }
private:
  SOCKET s_ = INVALID_SOCKET;
};

// minimal TCP endpoints for the reliable-fallback demonstration.
class TcpListener {
public:
  ~TcpListener() { if (s_ != INVALID_SOCKET) closesocket(s_); }
  bool listen(uint16_t port) {
    s_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s_ == INVALID_SOCKET) return false;
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = htons(port);
    return bind(s_, (sockaddr*)&a, sizeof(a)) == 0 && ::listen(s_, 4) == 0;
  }
  uint16_t local_port() const { sockaddr_in a{}; int n = sizeof(a); return getsockname(s_, (sockaddr*)&a, &n) == 0 ? ntohs(a.sin_port) : 0; }
  SOCKET accept_one() { return ::accept(s_, nullptr, nullptr); }
private:
  SOCKET s_ = INVALID_SOCKET;
};

class TcpConn {
public:
  TcpConn() = default;
  explicit TcpConn(SOCKET s) : s_(s) {}
  ~TcpConn() { close(); }
  bool connect(uint16_t port) {
    s_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s_ == INVALID_SOCKET) return false;
    int one = 1; setsockopt(s_, IPPROTO_TCP, TCP_NODELAY, (const char*)&one, sizeof(one));  // low latency
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = htons(port);
    return ::connect(s_, (sockaddr*)&a, sizeof(a)) == 0;
  }
  bool send_all(const uint8_t* data, int len) {
    int off = 0; while (off < len) { int n = ::send(s_, (const char*)data + off, len - off, 0); if (n <= 0) return false; off += n; }
    return true;
  }
  int recv(uint8_t* buf, int cap) { return ::recv(s_, (char*)buf, cap, 0); }
  void close() { if (s_ != INVALID_SOCKET) { closesocket(s_); s_ = INVALID_SOCKET; } }
  SOCKET handle() const { return s_; }
private:
  SOCKET s_ = INVALID_SOCKET;
};

}  // namespace avp
