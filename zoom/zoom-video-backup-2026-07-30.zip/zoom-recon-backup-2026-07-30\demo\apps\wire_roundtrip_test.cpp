// wire_roundtrip_test.cpp — reproduce the peer's screen-decode failure offline. Encode a sequence of
// CHANGING frames with the real VP9 screen-content encoder, push each coded AU through the exact peer
// path (packetize -> wire -> assemble, 0% loss), then decode. Prints per frame: how many avcodec
// packets the encoder emitted (>1 == the bug: two VP9 frames concatenated into one AU) and whether it
// decoded. Synth-simple content stays 1 pkt/frame (decodes); this changing content triggers the bug.
#include "encode/vp9_screen.hpp"
#include "protect/packetizer.hpp"
#include "protect/fec.hpp"
#include "conference/media_channel.hpp"
#include "apps/frame_assembler.hpp"
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <cstdio>
#include <cstdint>
#include <vector>

using namespace avp;

// a changing "screen-like" frame: scrolling text bars on white so each frame differs (forces P-frames
// and exercises whatever makes libvpx emit extra packets).
static VideoFrame frame_at(int w, int h, int t) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA;
  f.data.assign((size_t)w * h * 4, 235);
  for (size_t i = 3; i < f.data.size(); i += 4) f.data[i] = 255;
  for (int line = 0; line < 40; ++line) {
    int y = 20 + line * 16; if (y >= h - 10) break;
    int x0 = 20 + ((line * 37 + t * 11) % 200);
    for (int gy = 0; gy < 9; ++gy) for (int x = x0; x < w - 20; x += 2)
      { uint8_t* p = &f.data[((size_t)(y + gy) * w + x) * 4]; p[0] = p[1] = p[2] = 30; }
  }
  return f;
}

int main() {
  const int W = 1280, H = 720, FPS = 12, N = 30;
  Vp9ScreenEncoder enc; ScreenEncParams sp; sp.width = W; sp.height = H; sp.fps = FPS; sp.kbps = 2500; sp.gop = 48; sp.screen_content = true;
  enc.open(sp);
  Vp9ScreenDecoder dec; dec.open();

  Packetizer pk(1100); FecEncoder fenc; FrameAssembler fa;
  uint32_t ts = 3000;
  int sent = 0, decoded = 0, multi = 0;

  for (int i = 0; i < N; ++i) {
    VideoFrame bgra = frame_at(W, H, i); I420Image src; BgraToI420(bgra, src);
    std::vector<uint8_t> au; bool key = false;
    enc.encode(src, false, au, key);
    if (au.empty()) { std::printf("  frame %2d: encoder pkts=%d  (no output)\n", i, enc.last_pkt_count); continue; }
    if (enc.last_pkt_count > 1) ++multi;
    ++sent;
    // peer path: packetize -> wire roundtrip -> assemble (0% loss)
    auto pkts = pk.packetize(au, ts); auto fecs = fenc.protect(pkts, 8, key ? 8 : 16);
    for (auto& p : pkts)  { auto b = wire::serialize(WirePacket{ false, p, {}, p.timestamp }); WirePacket w; wire::deserialize(b.data(), (int)b.size(), w); fa.add(w); }
    for (auto& fp : fecs) { auto b = wire::serialize(WirePacket{ true, {}, fp, ts });          WirePacket w; wire::deserialize(b.data(), (int)b.size(), w); fa.add(w); }
    ts += 3000;
    std::vector<uint8_t> rau; AssembleStat st;
    while (fa.try_pop(rau, st)) {
      I420Image out; bool ok = dec.decode(rau, out) && out.w > 0;
      if (ok) ++decoded;
      if (i < 6 || enc.last_pkt_count > 1)
        std::printf("  frame %2d: encoder pkts=%d  key=%d  AU=%zu B  %2zu wirepkts  decode=%s\n",
                    i, enc.last_pkt_count, (int)key, au.size(), pkts.size(), ok ? "OK" : "FAIL");
    }
  }
  std::printf("  ----\n  sent %d frames, %d decoded, %d frames had >1 encoder packet\n\n", sent, decoded, multi);
  return 0;
}
