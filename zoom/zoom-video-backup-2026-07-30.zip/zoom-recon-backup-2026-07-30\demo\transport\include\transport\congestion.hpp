// congestion.hpp — Google-Congestion-Control-style bandwidth estimation (AV_PIPELINE_DETAILS.html §5,
// §9 weak-network loop). Two estimators combined, exactly the WebRTC GCC shape (public algorithm,
// clean-room):
//   * delay-based: a trendline over inter-group delay variation + an adaptive threshold detects queue
//     build-up (over-use) BEFORE loss happens -> multiplicative back-off to the measured throughput.
//   * loss-based: high loss -> back off; low loss -> creep up. The send target is min(delay, loss).
// AIMD: over-use -> rate = beta*throughput (beta=0.85); normal -> increase (multiplicative, capped at
// ~1.5x measured throughput so it can't run away). This is what makes Zoom hold latency low on a
// congested link instead of just filling the queue until it drops packets.
#pragma once
#include "transport_types.hpp"
#include <algorithm>
#include <cmath>
#include <vector>

namespace avp {

// Delay-based over-use detector. Per received packet pair, the inter-group delay variation
//   dv = recv_delta - send_delta
// is >0 while the bottleneck queue is growing (sending above capacity), ~0 when stable, <0 while the
// queue drains. An EWMA of dv is the trend; compared against an adaptive threshold gamma, sustained
// trend > gamma => over-use (back off before loss). This is the WebRTC trendline signal, stable form.
class DelayDetector {
public:
  // feed adjacent received packets: send-time delta and recv-time delta (ms). Returns signal.
  //   +1 overuse, 0 normal, -1 underuse
  int update(double send_delta_ms, double recv_delta_ms, double now_ms) {
    double dv = recv_delta_ms - send_delta_ms;
    if (!init_) { trend_ = dv; init_ = true; } else trend_ = 0.85 * trend_ + 0.15 * dv;   // EWMA

    int signal = 0;
    if (trend_ > gamma_) {
      if (last_ms_ > 0) overuse_ms_ += now_ms - last_ms_;
      if (overuse_ms_ > kOveruseTimeMs && trend_ >= prev_) signal = 1;    // sustained + not shrinking
    } else if (trend_ < -gamma_) {
      overuse_ms_ = 0; signal = -1;
    } else {
      overuse_ms_ = 0; signal = 0;
    }
    // adapt gamma toward |trend| (slow up, faster down) so it tracks the link's jitter floor.
    double k = (std::fabs(trend_) < gamma_) ? 0.039 : 0.0087;
    double dt = last_ms_ > 0 ? std::min(now_ms - last_ms_, 100.0) : 0;
    gamma_ += k * (std::fabs(trend_) - gamma_) * dt;
    gamma_ = std::min(std::max(gamma_, 3.0), 200.0);
    prev_ = trend_; last_ms_ = now_ms;
    return signal;
  }
private:
  static constexpr double kOveruseTimeMs = 10.0;
  double trend_ = 0, gamma_ = 6.0, overuse_ms_ = 0, prev_ = 0, last_ms_ = 0; bool init_ = false;
};

class CongestionController {
public:
  CongestionController(double start_bps = 300000, double min_bps = 50000, double max_bps = 8000000)
      : target_(start_bps), min_(min_bps), max_(max_bps) {}

  // Process one batch of per-packet feedback (roughly one RTT / one report interval).
  void on_feedback(const std::vector<PacketFeedback>& fb) {
    if (fb.empty()) return;
    // ---- throughput + loss over the batch ----
    long recv_bytes = 0; int lost = 0; int64_t rmin = 0, rmax = 0; double rtt_sum = 0; int rtt_n = 0;
    std::vector<const PacketFeedback*> got;
    for (auto& p : fb) {
      if (p.lost()) { ++lost; continue; }
      recv_bytes += p.size; got.push_back(&p);
      if (rmin == 0 || p.recv_time_us < rmin) rmin = p.recv_time_us;
      if (p.recv_time_us > rmax) rmax = p.recv_time_us;
      double rtt = (p.recv_time_us - p.send_time_us) / 1000.0; if (rtt > 0) { rtt_sum += rtt; ++rtt_n; }
    }
    double loss = fb.size() ? double(lost) / fb.size() : 0;
    double span_s = (rmax > rmin) ? (rmax - rmin) / 1e6 : 0;
    double throughput = span_s > 0 ? recv_bytes * 8.0 / span_s : throughput_;
    if (throughput > 0) throughput_ = 0.5 * throughput_ + 0.5 * throughput;
    rtt_ms_ = rtt_n ? rtt_sum / rtt_n : rtt_ms_;

    // ---- delay-based signal over adjacent received packets ----
    int sig = 0;
    for (size_t i = 1; i < got.size(); ++i) {
      double sd = (got[i]->send_time_us - got[i-1]->send_time_us) / 1000.0;
      double rd = (got[i]->recv_time_us - got[i-1]->recv_time_us) / 1000.0;
      int s = delay_.update(sd, rd, got[i]->recv_time_us / 1000.0);
      if (s > sig) sig = s; if (s < 0 && sig <= 0) sig = s;
    }
    signal_ = sig > 0 ? "overuse" : (sig < 0 ? "underuse" : "normal");

    // ---- delay-based AIMD ----
    double delay_rate;
    if (sig > 0) {                                   // over-use: back off to measured throughput
      delay_rate = 0.85 * throughput_;
      increasing_ = false;
    } else if (sig < 0) {                            // under-use: hold (queue draining)
      delay_rate = target_;
    } else {                                         // normal: increase, capped near measured
      double mult = increasing_ ? 1.08 : 1.03;       // faster once we've been stable a while
      delay_rate = target_ * mult;
      delay_rate = std::min(delay_rate, 1.5 * throughput_ + 10000);
      increasing_ = true;
    }

    // ---- loss-based ----
    double loss_rate = target_;
    if (loss > 0.10)      loss_rate = target_ * (1.0 - 0.5 * loss);
    else if (loss < 0.02) loss_rate = target_ * 1.05;

    target_ = std::max(min_, std::min({ max_, delay_rate, loss_rate }));
    loss_ = loss;
  }

  double target_bps() const { return target_; }
  CongestionState state() const { return { target_, throughput_, rtt_ms_, loss_, signal_ }; }

private:
  DelayDetector delay_;
  double target_, min_, max_, throughput_ = 0, rtt_ms_ = 0, loss_ = 0;
  bool increasing_ = false;
  const char* signal_ = "normal";
};

}  // namespace avp
