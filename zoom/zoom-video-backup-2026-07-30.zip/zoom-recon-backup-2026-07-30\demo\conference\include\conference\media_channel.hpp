// media_channel.hpp — the media-transport abstraction for the conference app, plus a real RTP-like
// WIRE FORMAT. A media/FEC packet is an in-memory struct on the send side; to cross a socket it must be
// serialized to bytes and parsed back — the real work a transport does. IMediaChannel lets the same
// Conference run over an in-process loopback (LoopbackChannel) or real UDP sockets (UdpMediaChannel).
#pragma once
#include "protect/packetizer.hpp"   // MediaPacket
#include "protect/fec.hpp"          // FecPacket
#include <cstdint>
#include <vector>

namespace avp {

struct WirePacket { bool is_fec = false; MediaPacket pkt; FecPacket fec; uint32_t frame_ts = 0; bool is_retx = false; uint8_t channel = 3; };

// ---- wire format ------------------------------------------------------------------------------
//   byte 0 = type (0 media, 1 fec)
//   media: u16 seq, u32 ts, u8 pt, u8 flags(bit0=marker, bit1=retransmit), u16 len, <len> payload
//   fec:   u16 base_seq, u8 k, u8 r, u16 shard_len, u8 index, u32 frame_ts, u16 len, <len> payload
// frame_ts lets a cross-process receiver group a frame's media + FEC packets by timestamp (a bare
// FecPacket has no timestamp of its own).
namespace wire {
inline void p16(std::vector<uint8_t>& b, uint16_t v) { b.push_back(v & 0xFF); b.push_back(v >> 8); }
inline void p32(std::vector<uint8_t>& b, uint32_t v) { for (int i = 0; i < 4; ++i) b.push_back((v >> (8 * i)) & 0xFF); }
inline uint16_t g16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }
inline uint32_t g32(const uint8_t* p) { return (uint32_t)(p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t)p[3] << 24)); }

inline std::vector<uint8_t> serialize(const WirePacket& w) {
  std::vector<uint8_t> b;
  // byte 0 low nibble = type (0 media, 1 fec), high nibble = channel (3 video, 2 desktop-share). Distinct
  // from the feedback packet types 2/3/4/5 (those are exact small values; media/fec are 0x2X/0x3X).
  if (!w.is_fec) {
    b.push_back(0 | (w.channel << 4));
    p16(b, w.pkt.seq); p32(b, w.pkt.timestamp); b.push_back(w.pkt.payload_type); b.push_back((w.pkt.marker ? 1 : 0) | (w.is_retx ? 2 : 0));
    p16(b, (uint16_t)w.pkt.payload.size()); b.insert(b.end(), w.pkt.payload.begin(), w.pkt.payload.end());
  } else {
    b.push_back(1 | (w.channel << 4));
    p16(b, w.fec.base_seq); b.push_back(w.fec.k); b.push_back(w.fec.r); p16(b, w.fec.shard_len); b.push_back(w.fec.index);
    p32(b, w.frame_ts);
    p16(b, (uint16_t)w.fec.payload.size()); b.insert(b.end(), w.fec.payload.begin(), w.fec.payload.end());
  }
  return b;
}
inline bool deserialize(const uint8_t* d, int n, WirePacket& w) {
  if (n < 1) return false;
  int type = d[0] & 0x0F; w.channel = (uint8_t)(d[0] >> 4);
  if (type == 0) {
    if (n < 11) return false;
    w.is_fec = false; w.pkt.seq = g16(d + 1); w.pkt.timestamp = g32(d + 3); w.pkt.payload_type = d[7];
    w.pkt.marker = (d[8] & 1) != 0; w.is_retx = (d[8] & 2) != 0;
    int len = g16(d + 9); if (11 + len > n) return false;
    w.pkt.payload.assign(d + 11, d + 11 + len); w.frame_ts = w.pkt.timestamp; return true;
  } else if (type == 1) {
    if (n < 14) return false;
    w.is_fec = true; w.fec.base_seq = g16(d + 1); w.fec.k = d[3]; w.fec.r = d[4]; w.fec.shard_len = g16(d + 5); w.fec.index = d[7];
    w.frame_ts = g32(d + 8);
    int len = g16(d + 12); if (14 + len > n) return false;
    w.fec.payload.assign(d + 14, d + 14 + len); return true;
  }
  return false;
}
// NACK feedback packet (type 2): the receiver lists the media seqs it's missing so the sender resends
// them from its retransmit history (§4 — the burst-loss fallback when FEC couldn't recover a group).
inline std::vector<uint8_t> serialize_nack(const std::vector<uint16_t>& seqs) {
  std::vector<uint8_t> b; b.push_back(2); p16(b, (uint16_t)seqs.size());
  for (uint16_t s : seqs) p16(b, s);
  return b;
}
inline bool parse_nack(const uint8_t* d, int n, std::vector<uint16_t>& seqs) {
  if (n < 3 || d[0] != 2) return false;
  int cnt = g16(d + 1); seqs.clear();
  for (int i = 0; i < cnt && 3 + i * 2 + 1 < n; ++i) seqs.push_back(g16(d + 3 + i * 2));
  return true;
}
// QoS report (type 3) — the mcm cmd-301 feedback: the RECEIVER measures its incoming stream and reports
// loss / FEC-recovery / jitter back to the SENDER, which feeds the §9 net-score loop (real, not injected).
inline std::vector<uint8_t> serialize_qos(int loss_x10000, int jitter_ms, int fec_x100) {
  std::vector<uint8_t> b; b.push_back(3);
  p16(b, (uint16_t)(loss_x10000 < 0 ? 0 : loss_x10000 > 10000 ? 10000 : loss_x10000));
  p16(b, (uint16_t)(jitter_ms < 0 ? 0 : jitter_ms > 65535 ? 65535 : jitter_ms));
  b.push_back((uint8_t)(fec_x100 < 0 ? 0 : fec_x100 > 100 ? 100 : fec_x100));
  return b;
}
inline bool parse_qos(const uint8_t* d, int n, int& loss_x10000, int& jitter_ms, int& fec_x100) {
  if (n < 6 || d[0] != 3) return false;
  loss_x10000 = g16(d + 1); jitter_ms = g16(d + 3); fec_x100 = d[5]; return true;
}
// Keyframe request (type 4) — Zoom's zlt SetKeyPictureRequest feedback (sub_180008370): a receiver whose
// decoder has lost sync (missing/undecodable reference) asks the sender to emit a fresh key/IDR instead of
// waiting for the periodic GOP. `req_type` mirrors the recovered RequestType enum: 2 = KeyPicture (recovery
// ref, ≈ RTCP PLI), 4 = Idr (forced IDR, ≈ RTCP FIR). `spatial` = dependencyId; `pic_id` = last_received_
// pic_id (KeyPicture) or request_number (Idr). At the sender an Idr supersedes a KeyPicture.
enum : uint8_t { KFREQ_KEYPICTURE = 2, KFREQ_IDR = 4 };
inline std::vector<uint8_t> serialize_kfreq(uint8_t req_type, uint8_t spatial, uint16_t pic_id) {
  std::vector<uint8_t> b; b.push_back(4); b.push_back(req_type); b.push_back(spatial); p16(b, pic_id); return b;
}
inline bool parse_kfreq(const uint8_t* d, int n, uint8_t& req_type, uint8_t& spatial, uint16_t& pic_id) {
  if (n < 5 || d[0] != 4) return false;
  req_type = d[1]; spatial = d[2]; pic_id = g16(d + 3); return true;
}
// RTT probe (type 5) — a lightweight round-trip measurement (Zoom's RTP layer runs GCC/BWE which needs
// RTT + the QoS report's abs_net_delay_ms). `is_echo`=0 is a probe carrying the originator's local send
// time (opaque to the echoer); the peer bounces it back with is_echo=1 and the SAME ts; the originator
// then computes RTT = now − ts. Fed (with the jitter-buffer delay) as abs_net_delay into the §9 G.107 MOS.
inline std::vector<uint8_t> serialize_rttprobe(uint32_t ts, uint8_t is_echo) {
  std::vector<uint8_t> b; b.push_back(5); b.push_back(is_echo); p32(b, ts); return b;
}
inline bool parse_rttprobe(const uint8_t* d, int n, uint32_t& ts, uint8_t& is_echo) {
  if (n < 6 || d[0] != 5) return false;
  is_echo = d[1]; ts = g32(d + 2); return true;
}
// Transport-cc feedback (type 6) — the receiver reports the ARRIVAL time of each media packet it got in the
// last window (WebRTC transport-wide-cc), so the sender's GCC/BWE sees the real inter-packet delay gradient
// on the actual stream (not a simulation). Payload = u16 count, then count × {u16 seq, u16 arrival_delta_ms}
// where arrival_delta is relative to the FIRST reported packet's arrival (receiver clock; only deltas matter).
inline std::vector<uint8_t> serialize_twcc(const std::vector<std::pair<uint16_t, uint16_t>>& arr) {
  std::vector<uint8_t> b; b.push_back(6); p16(b, (uint16_t)arr.size());
  for (auto& e : arr) { p16(b, e.first); p16(b, e.second); }
  return b;
}
inline bool parse_twcc(const uint8_t* d, int n, std::vector<std::pair<uint16_t, uint16_t>>& arr) {
  if (n < 3 || d[0] != 6) return false;
  int cnt = g16(d + 1); arr.clear();
  for (int i = 0; i < cnt && 3 + i * 4 + 3 < n; ++i) arr.push_back({ g16(d + 3 + i * 4), g16(d + 3 + i * 4 + 2) });
  return true;
}
// Receiver compute-status (type 7) — a fast (~1 s) feedback the RECEIVER emits when it cannot DECODE the
// current tier in real time (its video Present is falling behind the audio master clock, or it's actively
// dropping stale frames to catch up). This is a *compute* limit, not a network one: on an overloaded box the
// decoder can't drain packets fast enough (kernel then drops real packets even at 0% injected loss) and the
// picture falls seconds behind. Distinct from the QoS report (type 3, ~10 s, loss/jitter) so the sender can
// react to a decode-throughput limit within a second — dropping RESOLUTION cuts the receiver's decode cost.
// Payload = one byte overload level: 0 = keeping up; higher = further behind (≈ decode lag / 300 ms).
inline std::vector<uint8_t> serialize_recvstatus(int overload_lvl) {
  std::vector<uint8_t> b; b.push_back(7);
  b.push_back((uint8_t)(overload_lvl < 0 ? 0 : overload_lvl > 255 ? 255 : overload_lvl));
  return b;
}
inline bool parse_recvstatus(const uint8_t* d, int n, int& overload_lvl) {
  if (n < 2 || d[0] != 7) return false;
  overload_lvl = d[1]; return true;
}
}  // namespace wire

// The transport the conference sends/receives media over.
struct IMediaChannel {
  virtual ~IMediaChannel() = default;
  virtual void send(const WirePacket& w) = 0;
  virtual std::vector<WirePacket> deliver() = 0;   // packets that arrived this round
  virtual long sent() const = 0;
  virtual long dropped() const = 0;
  virtual const char* name() const = 0;
};

}  // namespace avp
