# Module 5 — transport

The media transport from `AV_PIPELINE_DETAILS.html §5` (+ the §9 weak-network loop): carry the
protected packets (module 4) over UDP / QUIC / TCP under congestion control, paced to the estimated
bandwidth, with a reliable fallback.

```
protected packets ─► pacer (smooth to target) ─► UDP socket ─► [receiver feedback]
                          ▲                                          │
              congestion controller  ◄──────────────────────────────┘   (target bps)
   UDP silent >2 s ─► transport selector ─► TCP (reliable fallback) ─► ... ─► UDP on recovery
```

## Pieces

- **`congestion.hpp`** — Google-Congestion-Control-style estimator (public algorithm, clean-room):
  - *delay-based* (`DelayDetector`): EWMA of inter-group delay variation vs an adaptive threshold —
    catches queue build-up **before** loss and backs off (`rate = 0.85·throughput`).
  - *loss-based*: high loss → multiplicative decrease; low loss → creep up.
  - AIMD, send target = `min(delay-based, loss-based)`, capped near measured throughput so it can't run away.
- **`pacer.hpp`** — token-bucket pacer; releases a burst at the congestion target (≤250 ms burst budget).
- **`socket_transport.hpp`** — REAL winsock UDP + TCP endpoints (`send()`/`recv()` over loopback).
- **`transport_select.hpp`** — UDP→(QUIC)→TCP fallback after a UDP outage (Zoom's verified 2000 ms SNAC
  threshold, §3.5), switching back to UDP on recovery.
- **`net_sim.hpp`** — deterministic bottleneck-link model (FIFO queue, drop-on-full) to drive/verify CC.

The TLS/QUIC **secure** layer is the separately-verified **tp slice** (`bin2cpp-output/recon/tp/`,
real OpenSSL 3 + libcurl, `demo_tp_slice` 15/15 + live TLS 1.3) — referenced here, not duplicated.

## Build & run
```powershell
cmake -S . -B build -DAVP_WITH_WGC=ON
cmake --build build --config Release --target transport_demo
.\build\transport\Release\transport_demo.exe
```
No external libraries (winsock only). UDP/TCP checks use real sockets on 127.0.0.1.

## Verified (this machine)
```
1) GCC converge     300 kbps -> probe/overshoot 3.2 Mbps -> back off -> ~2.25 Mbps on a 2 Mbps link (112%)
2) bandwidth drop   2 Mbps -> 500 kbps: target follows to ~626 kbps
3) pacer            40-pkt burst drained over ~365 ms @1 Mbps, max 1 pkt/tick (no burst)
4) real UDP         100 media packets sent+received byte-intact over winsock loopback
5) fallback         UDP -> (2 s outage) -> TCP -> (recovery) -> UDP, 2 switches
6) real TCP         4000-byte echo byte-identical over winsock loopback (the reliable path)
```

Congestion control converges by delay (backing off before loss), the exact behavior §5/§9 describe.
GCC is the public WebRTC algorithm reproduced clean-room; Zoom's own estimator constants aren't
reproducible (that transport/congestion core wasn't feasible to reconstruct). Clean-room, following
Zoom's *design* (not its code). For interop / education.
