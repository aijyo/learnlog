import idc, ida_hexrays, ida_funcs, idautils
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
def decomp(ea, label):
    f = ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x (%s)"%(ea,label)); return
    try:
        L.append("\n// ===== %s  %s  (0x%x) ====="%(label, idc.get_func_name(f.start_ea), f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e:
        L.append("// FAIL 0x%x: %s"%(ea,e))
def dumpvt(vt, label, nd=6):
    slots=[]; ea=vt
    for i in range(14):
        p=idc.get_qword(ea)
        if not ida_funcs.get_func(p): break
        slots.append(p); ea+=8
    L.append("\n// ==== VTABLE %s 0x%x: %d slots ===="%(label,vt,len(slots)))
    for i,s in enumerate(slots): L.append("//  [%d] 0x%x %s"%(i,s,idc.get_func_name(s)))
    seen=set()
    for i,s in enumerate(slots[:nd]):
        if s in seen: continue
        seen.add(s); decomp(s,"%s.slot%d"%(label,i))
# TextureMotion classifier (from T1)
decomp(0x1800E7A00, "TextureMotion.classify_A")
decomp(0x1800E7680, "TextureMotion.classify_B")
# Where per-block texture/motion is MEASURED + how offsets combine
dumpvt(0x180503018, "zltCParamEstMethods", 8)
dumpvt(0x180502738, "zltCTextureMotionAdaptQuant", 4)
dumpvt(0x180502e18, "zltCBuQpCalc", 4)
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
