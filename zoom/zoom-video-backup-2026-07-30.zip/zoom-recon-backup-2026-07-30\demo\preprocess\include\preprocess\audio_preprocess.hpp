// audio_preprocess.hpp — module 2 audio preprocess = classic "3A" (AV_PIPELINE_DETAILS.html §2 audio).
//
// The RTC audio front-end every client runs before the codec, in order:
//   AEC  echo cancellation  — NLMS adaptive filter driven by the far-end (loopback) reference
//   ANS  noise suppression  — STFT spectral subtraction (classic, non-neural)
//   AGC  gain control       — RMS-targeting gain with attack/release + limiter
//   framing                 — split into fixed 10/20 ms frames for the encoder (module 3)
//
// Zoom's §2 audio note also lists DRED (neural PLC inside the Opus build) and AI background
// denoise — those are TRAINED-WEIGHT boundaries (⛔W), not reproducible; the neural denoiser is
// exposed as an injection hook (INeuralDenoiser). The classic 3A here is real, runnable DSP.
#pragma once
#include "capture/audio_frame.hpp"
#include "dsp_fft.hpp"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <deque>
#include <vector>

namespace avp {

// ---- format helpers: AudioFrame (interleaved, float32 or int16) <-> mono float ---------------
inline std::vector<float> ToMonoFloat(const AudioFrame& f) {
  std::vector<float> m;
  const int ch = f.format.channels > 0 ? f.format.channels : 1;
  if (f.format.is_float && f.format.bits == 32) {
    const float* s = reinterpret_cast<const float*>(f.data.data());
    size_t n = f.data.size() / 4;
    m.reserve(n / ch);
    for (size_t i = 0; i + ch <= n; i += ch) { float a = 0; for (int c = 0; c < ch; ++c) a += s[i + c]; m.push_back(a / ch); }
  } else if (!f.format.is_float && f.format.bits == 16) {
    const int16_t* s = reinterpret_cast<const int16_t*>(f.data.data());
    size_t n = f.data.size() / 2;
    m.reserve(n / ch);
    for (size_t i = 0; i + ch <= n; i += ch) { int a = 0; for (int c = 0; c < ch; ++c) a += s[i + c]; m.push_back((a / ch) / 32768.0f); }
  }
  return m;
}
inline std::vector<uint8_t> MonoFloatToPcm(const std::vector<float>& m, bool as_float = true) {
  std::vector<uint8_t> out;
  if (as_float) { out.resize(m.size() * 4); std::memcpy(out.data(), m.data(), out.size()); }
  else {
    out.resize(m.size() * 2); int16_t* d = reinterpret_cast<int16_t*>(out.data());
    for (size_t i = 0; i < m.size(); ++i) { float v = m[i] < -1 ? -1 : (m[i] > 1 ? 1 : m[i]); d[i] = (int16_t)(v * 32767); }
  }
  return out;
}
inline double Rms(const std::vector<float>& m) { double s = 0; for (float v : m) s += (double)v * v; return m.empty() ? 0 : std::sqrt(s / m.size()); }
inline double Dbfs(double x) { return x > 1e-9 ? 20.0 * std::log10(x) : -120.0; }

// ---- AEC: NLMS adaptive echo canceller -------------------------------------------------------
// Estimates the echo of the far-end reference present in the near-end mic and subtracts it.
// e[n] = d[n] - w·x[n..n-L+1] ;  w += mu * e * x / (||x||^2 + eps).  Cancels *linear* echo paths.
class EchoCanceller {
public:
  explicit EchoCanceller(int taps = 512, float mu = 0.5f) : w_(taps, 0.f), xbuf_(taps, 0.f), mu_(mu) {}
  // near-end `d` and far-end reference `x` (same length, same rate). Returns echo-reduced signal.
  std::vector<float> Process(const std::vector<float>& d, const std::vector<float>& x) {
    const int L = (int)w_.size();
    std::vector<float> e(d.size());
    for (size_t n = 0; n < d.size(); ++n) {
      // shift new reference sample into the delay line (xbuf_[0] = newest)
      for (int k = L - 1; k > 0; --k) xbuf_[k] = xbuf_[k - 1];
      xbuf_[0] = (n < x.size()) ? x[n] : 0.f;
      float yhat = 0, energy = 1e-6f;
      for (int k = 0; k < L; ++k) { yhat += w_[k] * xbuf_[k]; energy += xbuf_[k] * xbuf_[k]; }
      float en = d[n] - yhat;
      float g = mu_ * en / energy;
      for (int k = 0; k < L; ++k) w_[k] += g * xbuf_[k];
      e[n] = en;
    }
    return e;
  }
  void reset() { std::fill(w_.begin(), w_.end(), 0.f); std::fill(xbuf_.begin(), xbuf_.end(), 0.f); }
private:
  std::vector<float> w_, xbuf_; float mu_;
};

// ---- ANS: STFT spectral-subtraction noise suppressor -----------------------------------------
// Overlap-add STFT (Hann, 50% hop). Estimates the noise magnitude spectrum from low-energy frames
// (recursive averaging when a frame looks noise-dominated), subtracts it with over-subtraction and
// a spectral floor. Classic, non-neural — the AI denoiser is a separate boundary (below).
class NoiseSuppressor {
public:
  NoiseSuppressor(int frame = 512, float over = 1.5f, float floor = 0.05f)
      : N_(frame), hop_(frame / 2), over_(over), floor_(floor), win_(frame), noise_(frame / 2 + 1, 0.f) {
    for (int i = 0; i < N_; ++i) win_[i] = 0.5f - 0.5f * std::cos(2.0 * 3.14159265358979 * i / (N_ - 1));
  }
  std::vector<float> Process(const std::vector<float>& in) {
    std::vector<float> out(in.size(), 0.f), norm(in.size(), 0.f);
    std::vector<dsp::Complex> spec(N_);
    for (size_t start = 0; start + N_ <= in.size(); start += hop_) {
      for (int i = 0; i < N_; ++i) spec[i] = { in[start + i] * win_[i], 0.f };
      dsp::fft(spec, -1);
      const int H = N_ / 2 + 1;
      std::vector<float> mag(H);
      for (int k = 0; k < H; ++k) mag[k] = std::sqrt(spec[k].re * spec[k].re + spec[k].im * spec[k].im);
      // PER-BIN noise estimate: bootstrap on the first frame, then adapt a bin ONLY when it isn't
      // signal-dominated (mag < kSignalRatio * noise). A steady tone bin (mag >> noise) is held, so
      // it never poisons its own noise floor — the failure mode a frame-level VAD can't avoid.
      const float kSignalRatio = 3.0f, a = 0.9f;
      for (int k = 0; k < H; ++k) {
        if (!have_noise_)                       noise_[k] = mag[k];                     // bootstrap (warmup is noise-only)
        else if (mag[k] < kSignalRatio * noise_[k]) noise_[k] = a * noise_[k] + (1 - a) * mag[k];
      }
      have_noise_ = true;
      // spectral subtraction with over-subtraction + floor, mirror to negative freqs
      for (int k = 0; k < H; ++k) {
        float m = mag[k] - over_ * noise_[k];
        float fl = floor_ * mag[k];
        if (m < fl) m = fl;
        float scale = mag[k] > 1e-9f ? m / mag[k] : 0.f;
        spec[k].re *= scale; spec[k].im *= scale;
        if (k > 0 && k < N_ - k) { spec[N_ - k].re = spec[k].re; spec[N_ - k].im = -spec[k].im; }
      }
      dsp::fft(spec, +1);
      for (int i = 0; i < N_; ++i) { out[start + i] += spec[i].re / N_ * win_[i]; norm[start + i] += win_[i] * win_[i]; }
    }
    for (size_t i = 0; i < out.size(); ++i) if (norm[i] > 1e-6f) out[i] /= norm[i];
    return out;
  }
  void reset() { std::fill(noise_.begin(), noise_.end(), 0.f); have_noise_ = false; noise_avg_ = 0; }
private:
  int N_, hop_; float over_, floor_;
  std::vector<float> win_, noise_;
  bool have_noise_ = false; double noise_avg_ = 0;
};

// AI background denoise = trained-weight boundary (⛔W). Inject a real model to replace the classic ANS.
struct INeuralDenoiser {
  virtual ~INeuralDenoiser() = default;
  virtual std::vector<float> Denoise(const std::vector<float>& in, int sample_rate) = 0;
};

// ---- AGC: RMS-targeting gain with attack/release + limiter -----------------------------------
class AutomaticGainControl {
public:
  explicit AutomaticGainControl(float target_dbfs = -18.f, float max_gain_db = 30.f)
      : target_(std::pow(10.f, target_dbfs / 20.f)), max_gain_(std::pow(10.f, max_gain_db / 20.f)) {}
  std::vector<float> Process(const std::vector<float>& in) {
    std::vector<float> out(in.size());
    for (size_t i = 0; i < in.size(); ++i) {
      float a = std::fabs(in[i]);
      env_ = a > env_ ? (att_ * env_ + (1 - att_) * a) : (rel_ * env_ + (1 - rel_) * a);
      float desired = env_ > 1e-6f ? target_ / env_ : max_gain_;
      if (desired > max_gain_) desired = max_gain_;
      gain_ = 0.9f * gain_ + 0.1f * desired;                 // smooth gain changes
      float v = in[i] * gain_;
      out[i] = v < -1 ? -1 : (v > 1 ? 1 : v);                // hard limiter
    }
    return out;
  }
  void reset() { env_ = 0; gain_ = 1; }
private:
  float target_, max_gain_, env_ = 0, gain_ = 1, att_ = 0.2f, rel_ = 0.98f;
};

// ---- the chained front-end -------------------------------------------------------------------
struct AudioPreprocessConfig { bool aec = true, ans = true, agc = true; int frame_ms = 20; };

class AudioPreprocessor {
public:
  explicit AudioPreprocessor(AudioPreprocessConfig cfg = {}) : cfg_(cfg) {}

  // near-end mic (mono float) + optional far-end reference (loopback) at `rate`.
  // Returns the fully processed mono signal; also fills `frames` with fixed-size codec frames.
  std::vector<float> Process(const std::vector<float>& mic, const std::vector<float>& ref,
                             int rate, std::vector<std::vector<float>>* frames = nullptr) {
    std::vector<float> s = mic;
    if (cfg_.aec && !ref.empty()) s = aec_.Process(s, ref);
    if (cfg_.ans) s = neural_ ? neural_->Denoise(s, rate) : ans_.Process(s);
    if (cfg_.agc) s = agc_.Process(s);
    if (frames) {
      int fs = rate * cfg_.frame_ms / 1000;
      frames->clear();
      for (size_t i = 0; i + fs <= s.size(); i += fs) frames->emplace_back(s.begin() + i, s.begin() + i + fs);
    }
    return s;
  }
  void set_neural_denoiser(INeuralDenoiser* d) { neural_ = d; }   // ⛔W AI denoise injection
  EchoCanceller& aec() { return aec_; }
private:
  AudioPreprocessConfig cfg_;
  EchoCanceller aec_;
  NoiseSuppressor ans_;
  AutomaticGainControl agc_;
  INeuralDenoiser* neural_ = nullptr;
};

// echo-return-loss-enhancement (dB): how much echo energy the AEC removed. Higher = better.
inline double Erle(const std::vector<float>& before, const std::vector<float>& after) {
  double eb = 0, ea = 0; size_t n = before.size() < after.size() ? before.size() : after.size();
  for (size_t i = 0; i < n; ++i) { eb += (double)before[i] * before[i]; ea += (double)after[i] * after[i]; }
  return (ea > 1e-12 && eb > 1e-12) ? 10.0 * std::log10(eb / ea) : 0.0;
}

}  // namespace avp
