// transport_select.hpp — media transport selection + fallback (AV_PIPELINE_DETAILS.html §5, §3.5).
// UDP is primary (lowest latency). If UDP goes silent for >= outage_ms (Zoom's verified 2000 ms SNAC
// threshold), fall back to the reliable path (TCP; QUIC is the UDP-based reliable option in between).
// When UDP traffic resumes, switch back — media wants UDP whenever it works.
#pragma once
#include "transport_types.hpp"
#include <cstdint>

namespace avp {

class TransportSelector {
public:
  // outage_ms default = viper SnacTcpFallback::kMinUdpOutageMs (2000). quic_available inserts QUIC
  // as the reliable-but-UDP option before dropping all the way to TCP.
  explicit TransportSelector(int outage_ms = 2000, bool quic_available = false)
      : outage_us_((int64_t)outage_ms * 1000), quic_(quic_available) {}

  void on_udp_activity(int64_t now_us) {
    last_udp_us_ = now_us; have_last_ = true;
    if (current_ != TransportKind::UDP) { current_ = TransportKind::UDP; ++switches_; }   // recovered
  }

  // periodic check; returns the (possibly changed) transport.
  TransportKind on_tick(int64_t now_us) {
    if (!have_last_) { last_udp_us_ = now_us; have_last_ = true; }   // establish a baseline on first tick
    if (current_ == TransportKind::UDP && now_us - last_udp_us_ >= outage_us_) {
      current_ = quic_ ? TransportKind::QUIC : TransportKind::TCP;                          // fall back
      ++switches_;
    } else if (current_ == TransportKind::QUIC && now_us - last_udp_us_ >= 2 * outage_us_) {
      current_ = TransportKind::TCP;                                                        // escalate
      ++switches_;
    }
    return current_;
  }

  TransportKind current() const { return current_; }
  int switches() const { return switches_; }

private:
  int64_t outage_us_, last_udp_us_ = 0; bool quic_; bool have_last_ = false;
  TransportKind current_ = TransportKind::UDP; int switches_ = 0;
};

}  // namespace avp
