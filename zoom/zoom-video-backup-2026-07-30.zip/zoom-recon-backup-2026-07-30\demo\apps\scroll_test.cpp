// scroll_test.cpp — realistic scroll-blur sweep. A tall text page is scrolled past a 1080p window at a
// FRACTIONAL rate with bilinear vertical sampling, so each frame is NOT a pixel-exact copy of the last
// (mimics anti-aliased sub-pixel scrolling of real text) — the case pure-translation misses. Reports,
// per encoder config, the average luma PSNR of the MOVING frames, avg coded size, and avg encode time
// (so we know what stays real-time: 12 fps => ~83 ms/frame budget per encoder). This is how we pick the
// AV1 usage/cpu-used/qmax that keeps scrolling text sharp while remaining live.
#include "encode/vp9_screen.hpp"          // screen_codec factory (VP9 + AV1 under AVP_WITH_AOM)
#include "encode/h264_encoder.hpp"
#include "encode/h264_decode_verify.hpp"  // PsnrY
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <chrono>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace avp;

static std::vector<uint8_t> make_doc(int w, int hdoc) {
  std::vector<uint8_t> d((size_t)w * hdoc * 4, 235);
  for (size_t i = 3; i < d.size(); i += 4) d[i] = 255;
  uint32_t r = 0x51ED;
  auto rnd = [&]{ r = r * 1664525u + 1013904223u; return (r >> 9) & 0xFFFF; };
  for (int line = 0; line * 17 < hdoc - 17; ++line) {
    int y = 6 + line * 17;
    if (line % 7 == 6) { for (int x = 20; x < w - 20; ++x) { uint8_t* p = &d[((size_t)(y + 5) * w + x) * 4]; p[0]=p[1]=p[2]=180; } continue; }
    int x = 24;
    while (x < w - 24) {
      int wl = 7 + rnd() % 46;
      for (int gy = 0; gy < 10; ++gy) for (int gx = 0; gx < wl; ++gx)
        if (((gx + gy) & 1) || gy == 0 || gy == 9) { uint8_t* p = &d[((size_t)(y + gy) * w + (x + gx)) * 4]; p[0]=p[1]=p[2]=30; }
      x += wl + 6 + rnd() % 7;
    }
  }
  return d;
}
// sub-pixel vertical window: sample row (oy + y) with bilinear interpolation between adjacent doc rows.
static void window_i420(const std::vector<uint8_t>& doc, int w, int hdoc, double oy, int h, I420Image& out) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA; f.data.resize((size_t)w * h * 4);
  for (int y = 0; y < h; ++y) {
    double sy = oy + y; int y0 = (int)sy; double t = sy - y0; int y1 = y0 + 1;
    if (y0 < 0) y0 = 0; if (y1 >= hdoc) y1 = hdoc - 1; if (y0 >= hdoc) y0 = hdoc - 1;
    const uint8_t* r0 = &doc[(size_t)y0 * w * 4]; const uint8_t* r1 = &doc[(size_t)y1 * w * 4];
    uint8_t* d = &f.data[(size_t)y * w * 4];
    for (int i = 0; i < w * 4; ++i) d[i] = (uint8_t)(r0[i] * (1 - t) + r1[i] * t + 0.5);
  }
  BgraToI420(f, out);
}

static const int W = 1920, H = 1088, FPS = 12, DOC = 4000, N = 20, KBPS = 6000;
static const double SCROLL = 12.5;   // fractional -> sub-pixel each frame

struct Cfg { const char* name; ScreenCodec codec; int cpu; bool rt; int qmax; };

static void run(const Cfg& c, const std::vector<uint8_t>& doc) {
  auto enc = MakeScreenEncoder(c.codec); auto dec = MakeScreenDecoder(c.codec);
  ScreenEncParams sp; sp.width = W; sp.height = H; sp.fps = FPS; sp.kbps = KBPS; sp.gop = 1000;
  sp.screen_content = true; sp.qmin = 4; sp.qmax = c.qmax; sp.cpu_used = c.cpu; sp.realtime = c.rt;
  if (!enc || !enc->open(sp) || !dec->open()) { std::printf("  %-34s (unavailable)\n", c.name); return; }
  double sum = 0, ms = 0; long bytes = 0; int cnt = 0;
  for (int i = 0; i < N; ++i) {
    I420Image src; window_i420(doc, W, DOC, i * SCROLL, H, src);
    std::vector<uint8_t> au; bool key = false;
    auto t0 = std::chrono::steady_clock::now();
    enc->encode(src, i == 0, au, key);
    auto t1 = std::chrono::steady_clock::now();
    I420Image out; bool ok = !au.empty() && dec->decode(au, out);
    double p = ok ? PsnrY(src, out) : 0;
    if (i >= 2) { sum += p; bytes += (long)au.size(); ms += std::chrono::duration<double, std::milli>(t1 - t0).count(); ++cnt; }
  }
  std::printf("  %-34s  %6.2f dB   %7.1f KB   %6.1f ms/frame  %s\n",
              c.name, sum / cnt, bytes / (double)cnt / 1024.0, ms / cnt,
              ms / cnt <= 83 ? "(live 12fps OK)" : "(too slow)");
}

int main() {
  auto doc = make_doc(W, DOC);
  std::printf("\n  SUB-PIXEL scrolling text  (%dx%d, %.1f px/frame, %d kbps, motion frames)\n", W, H, SCROLL, KBPS);
  std::printf("  config                              motion PSNR   avg size     encode time\n");
  std::printf("  --------------------------------------------------------------------------------\n");
  Cfg cfgs[] = {
    { "AV1  good cpu8 q28 (cur.)",  ScreenCodec::AV1, 8, false, 28 },
    { "AV1  good cpu8 q20",         ScreenCodec::AV1, 8, false, 20 },
    { "AV1  good cpu8 q14",         ScreenCodec::AV1, 8, false, 14 },
    { "AV1  good cpu6 q16",         ScreenCodec::AV1, 6, false, 16 },
    { "AV1  good cpu6 q10",         ScreenCodec::AV1, 6, false, 10 },
    { "AV1  good cpu4 q8",          ScreenCodec::AV1, 4, false,  8 },
  };
  for (auto& c : cfgs) run(c, doc);
  std::printf("  --------------------------------------------------------------------------------\n\n");
  return 0;
}
