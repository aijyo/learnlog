// sfu_test.cpp — a mini SFU (Selective Forwarding Unit): ONE sender encodes ONE spatial-SVC VP9 stream;
// the SFU forwards to N receivers, and for EACH receiver prunes the stream to the spatial layers that
// receiver's network can take — WITHOUT re-encoding (Zoom §3.2 + §9). Each receiver's layer count is
// decided by the reconstructed mcm brain: its loss -> G.107 MOS -> net-score -> bw-level -> #layers.
// Proves: strong receivers get 720p, weak ones get 360p, the sender encodes exactly once.
#include "encode/vp9_svc.hpp"
#include "apps/mcm/mcm_channel.hpp"
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <cstdio>
#include <string>
#include <vector>
extern "C" {
#include "vpx/vpx_decoder.h"
#include "vpx/vp8dx.h"
#include "vpx/vpx_image.h"
}

using namespace avp;
static const int FW = 1280, FH = 720, FRAMES = 20;

static I420Image make_i420(int t) {
  I420Image im; im.w = FW; im.h = FH; im.y.resize((size_t)FW * FH); im.u.assign((size_t)im.cw() * im.ch(), 128); im.v.assign((size_t)im.cw() * im.ch(), 128);
  for (int y = 0; y < FH; ++y) for (int x = 0; x < FW; ++x) {
    int v = ((x / 8 + y / 8) & 1) ? 205 : 45;                 // fine checker (high freq: base vs full differ)
    if (((x + t * 6) % 160) < 80) v = 128 + (x % 60);         // moving bands
    im.y[(size_t)y * FW + x] = (uint8_t)v;
  }
  return im;
}

struct Receiver {
  std::string name; double loss;                 // simulated uplink loss for this receiver's path
  vpx_codec_ctx_t dec{}; int keep = 2, w = 0, h = 0; long bytes = 0;
};

int main() {
  // one SVC encode (2 spatial layers)
  Vp9SvcEncoder enc;
  if (!enc.open(FW, FH, 2, /*base*/700, /*full*/2000)) { std::printf("svc enc open failed\n"); return 1; }
  std::vector<std::vector<uint8_t>> stream; long sender_bytes = 0;
  for (int t = 0; t < FRAMES; ++t) { I420Image im = make_i420(t); std::vector<uint8_t> sf;
    if (enc.encode(im, t, sf)) { sender_bytes += (long)sf.size(); stream.push_back(std::move(sf)); } }

  // 3 receivers on different networks -> mcm net-score -> bw-level -> #spatial layers to forward
  std::vector<Receiver> rx = { {"R0 strong", 0.00}, {"R1 medium", 0.06}, {"R2 weak", 0.28} };
  std::printf("\n  mini-SFU: 1 SVC encode (%ld B) -> per-receiver layer pruning (no re-encode)\n", sender_bytes);
  std::printf("  ---------------------------------------------------------------------------\n");
  for (auto& r : rx) {
    recon::mcm::AudioQosMetrics m; m.loss_rate = r.loss; m.abs_net_delay_ms = 40;
    double mos = recon::mcm::EstimateMos(recon::mcm::BaseRfactor(m), m.abs_net_delay_ms);
    auto bw = recon::mcm::BwFromScore(recon::mcm::ScoreFromMos(mos));
    r.keep = (int)bw >= (int)recon::mcm::BwLevel::L3 ? 2 : 1;   // L3/L4 -> full(2), L1/L2 -> base(1)
    vpx_codec_dec_init(&r.dec, vpx_codec_vp9_dx(), nullptr, 0);
    std::printf("  %-9s loss %4.0f%%  MOS %.2f  bw L%d  -> forward %d layer(s)\n",
                r.name.c_str(), r.loss * 100, mos, (int)bw, r.keep);
  }
  // SFU forwards each superframe, pruned per receiver; each receiver decodes what it got.
  for (auto& sf : stream) for (auto& r : rx) {
    std::vector<uint8_t> fwd = vp9_prune(sf, r.keep); r.bytes += (long)fwd.size();
    if (vpx_codec_decode(&r.dec, fwd.data(), (unsigned)fwd.size(), nullptr, 0) == VPX_CODEC_OK) {
      vpx_codec_iter_t it = nullptr; vpx_image_t* im;
      while ((im = vpx_codec_get_frame(&r.dec, &it))) { r.w = im->d_w; r.h = im->d_h; }
    }
  }
  std::printf("  ---------------------------------------------------------------------------\n");
  for (auto& r : rx) { std::printf("  %-9s decoded %dx%d   received %ld B (%.0f%% of full)\n",
      r.name.c_str(), r.w, r.h, r.bytes, sender_bytes ? 100.0 * r.bytes / sender_bytes : 0); vpx_codec_destroy(&r.dec); }
  std::printf("  ---------------------------------------------------------------------------\n");
  std::printf("  => sender encoded ONCE; the SFU forwarded 720p to strong receivers and 360p to weak\n");
  std::printf("     ones by dropping the enhancement sub-frame — Zoom's SVC + SFU (§3.2 / §9).\n\n");
  return 0;
}
