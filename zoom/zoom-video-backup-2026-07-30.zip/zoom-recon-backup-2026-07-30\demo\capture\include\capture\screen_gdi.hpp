// screen_gdi.hpp — GDI BitBlt screen capture. The universal last-resort backend (works on any
// session, including RDP / no-GPU), matching Zoom's fallback chain. CPU path, so it is the slowest
// and cannot see hardware-overlay / protected content — but it always produces a frame.
#pragma once
#include "video_source.hpp"
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

namespace avp {

class GdiScreenSource : public IVideoSource {
public:
  bool open(const CaptureConfig& cfg) override {
    // virtual-screen origin + size (covers all monitors); for a single monitor we clip to primary
    left_ = GetSystemMetrics(SM_XVIRTUALSCREEN);
    top_  = GetSystemMetrics(SM_YVIRTUALSCREEN);
    if (cfg.target == CaptureTarget::PrimaryMonitor) {
      left_ = 0; top_ = 0; w_ = GetSystemMetrics(SM_CXSCREEN); h_ = GetSystemMetrics(SM_CYSCREEN);
    } else { w_ = GetSystemMetrics(SM_CXVIRTUALSCREEN); h_ = GetSystemMetrics(SM_CYVIRTUALSCREEN); }
    return w_ > 0 && h_ > 0;
  }
  bool grab(VideoFrame& out) override {
    HDC screen = GetDC(nullptr);
    if (!screen) return false;
    HDC mem = CreateCompatibleDC(screen);
    BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w_; bi.bmiHeader.biHeight = -h_;   // top-down
    bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    HBITMAP dib = CreateDIBSection(screen, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    bool ok = false;
    if (dib && bits) {
      HGDIOBJ old = SelectObject(mem, dib);
      if (BitBlt(mem, 0, 0, w_, h_, screen, left_, top_, SRCCOPY | CAPTUREBLT)) {
        out.width = w_; out.height = h_; out.stride = w_ * 4; out.format = PixelFormat::BGRA;
        out.timestamp_us = now_us();
        out.data.assign((uint8_t*)bits, (uint8_t*)bits + (size_t)out.stride * h_);
        ok = true;
      }
      SelectObject(mem, old);
    }
    if (dib) DeleteObject(dib);
    DeleteDC(mem); ReleaseDC(nullptr, screen);
    return ok;
  }
  void close() override {}
  const char* backend() const override { return "GDI-BitBlt"; }
  int width() const override { return w_; }
  int height() const override { return h_; }
private:
  static int64_t now_us() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return c.QuadPart * 1000000 / f.QuadPart; }
  int left_ = 0, top_ = 0, w_ = 0, h_ = 0;
};

}  // namespace avp
#endif
