// vp9_text_test.cpp — quantitative A/B on SCREEN-CONTENT (text/UI) sharpness: the same synthetic
// "screen page" (dense black text-like strokes + thin 1px rules on white, a colored title bar)
// encoded+decoded two ways, at the SAME target bitrate, reporting coded size and luma PSNR:
//   1) H.264 baseline (minih264)      — the old screen path (the one whose text looked blurry)
//   2) VP9 screen-content (libvpx, tune=screen) — the new path (Zoom's SC class of coding)
// Higher PSNR = sharper text. This is the evidence that swapping the codec (not tuning FEC) is what
// fixes the blur. Reports both the keyframe and the steady-state (static-refined) frame.
#include "encode/h264_encoder.hpp"
#include "encode/h264_decode_verify.hpp"
#include "encode/vp9_screen.hpp"
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <cstdio>
#include <vector>

using namespace avp;

// Draw a realistic-ish screen page: white bg, a blue title bar, and many short black bars laid out in
// lines to mimic text, plus thin 1px horizontal rules — exactly the high-frequency content DCT smears.
static VideoFrame make_text_page(int w, int h) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA;
  f.data.assign((size_t)w * h * 4, 235);                          // near-white background
  for (size_t i = 3; i < f.data.size(); i += 4) f.data[i] = 255;  // alpha
  auto px = [&](int x, int y, uint8_t B, uint8_t G, uint8_t R) {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    uint8_t* p = &f.data[((size_t)y * w + x) * 4]; p[0] = B; p[1] = G; p[2] = R; p[3] = 255;
  };
  for (int y = 0; y < 40; ++y) for (int x = 0; x < w; ++x) px(x, y, 200, 120, 40);   // blue title bar
  uint32_t r = 0x2545F1;
  auto rnd = [&]{ r = r * 1664525u + 1013904223u; return (r >> 8) & 0xFFFF; };
  for (int line = 0; line < 46; ++line) {                          // ~46 lines of "text"
    int y = 56 + line * 14; if (y > h - 14) break;
    if (line % 6 == 5) { for (int x = 20; x < w - 20; ++x) px(x, y + 6, 180, 180, 180); continue; } // 1px rule
    int x = 24;
    while (x < w - 24) {
      int wlen = 6 + (rnd() % 40);                                 // "word" width
      for (int gy = 0; gy < 9; ++gy)                               // 9px tall glyph strokes
        for (int gx = 0; gx < wlen; ++gx)
          if (((gx + gy) & 1) || gy == 0 || gy == 8) px(x + gx, y + gy, 30, 30, 30); // black-ish, textured
      x += wlen + 6 + (rnd() % 6);                                 // space
    }
  }
  return f;
}

struct Result { int key_bytes = 0; double key_psnr = 0; int ss_bytes = 0; double ss_psnr = 0; };

int main() {
  const int W = 1280, H = 720, FPS = 12, KBPS = 2500, FRAMES = 8;
  VideoFrame page = make_text_page(W, H);
  I420Image src; BgraToI420(page, src);

  // ---- H.264 baseline (minih264) ----
  Result h264;
  {
    VideoEncoderConfig ec; ec.width = W; ec.height = H; ec.fps = FPS; ec.bitrate_bps = KBPS * 1000;
    ec.temporal_layers = 1; ec.layered_refs = false; ec.gop = 1000;   // plain IDR then P frames
    H264Encoder enc; enc.open(ec);
    H264Decoder dec; dec.open();
    for (int i = 0; i < FRAMES; ++i) {
      EncodedFrame ef = enc.encode(src, i == 0);
      I420Image out; bool ok = dec.decode(ef.data, out);
      double psnr = ok ? PsnrY(src, out) : 0;
      if (i == 0) { h264.key_bytes = ef.size(); h264.key_psnr = psnr; }
      h264.ss_bytes = ef.size(); h264.ss_psnr = psnr;
    }
  }

  // ---- VP9 screen-content (libvpx tune=screen) ----
  Result vp9;
  {
    ScreenEncParams sp; sp.width = W; sp.height = H; sp.fps = FPS; sp.kbps = KBPS; sp.gop = 1000; sp.screen_content = true;
    auto enc = MakeScreenEncoder(ScreenCodec::VP9);
    auto dec = MakeScreenDecoder(ScreenCodec::VP9);
    enc->open(sp); dec->open();
    for (int i = 0; i < FRAMES; ++i) {
      std::vector<uint8_t> au; bool key = false;
      enc->encode(src, i == 0, au, key);
      I420Image out; bool ok = !au.empty() && dec->decode(au, out);
      double psnr = ok ? PsnrY(src, out) : 0;
      if (i == 0) { vp9.key_bytes = (int)au.size(); vp9.key_psnr = psnr; }
      vp9.ss_bytes = (int)au.size(); vp9.ss_psnr = psnr;
    }
  }

  std::printf("\n  Screen-content (text/UI) sharpness A/B  @ %dx%d, %d kbps, %d fps\n", W, H, KBPS, FPS);
  std::printf("  ------------------------------------------------------------------\n");
  std::printf("  %-34s  keyframe            steady-state (static)\n", "");
  std::printf("  %-34s  %6d B  %6.2f dB   %6d B  %6.2f dB\n",
              "H.264 baseline (minih264)", h264.key_bytes, h264.key_psnr, h264.ss_bytes, h264.ss_psnr);
  std::printf("  %-34s  %6d B  %6.2f dB   %6d B  %6.2f dB\n",
              "VP9 screen-content (tune=screen)", vp9.key_bytes, vp9.key_psnr, vp9.ss_bytes, vp9.ss_psnr);
  std::printf("  ------------------------------------------------------------------\n");
  std::printf("  keyframe luma PSNR gain: %+.2f dB   steady-state gain: %+.2f dB\n\n",
              vp9.key_psnr - h264.key_psnr, vp9.ss_psnr - h264.ss_psnr);
  return 0;
}
