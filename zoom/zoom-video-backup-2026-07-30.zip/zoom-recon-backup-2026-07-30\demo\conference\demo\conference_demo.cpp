// conference_demo.cpp — all 8 modules wired into ONE real-time loopback conference process. Paces a
// synthesized (or screen-captured) video stream through capture→preprocess→encode→FEC→loopback→jitter
// →FEC-recover→decode→render at a target fps under injected loss, and runs the audio 3A→AAC→decode
// path. Reports end-to-end stats. This is the integrated app the module-by-module build adds up to.
//
//   conference_demo [--seconds N] [--fps F] [--loss P] [--source synth|screen] [--no-layered]
#include "conference/conference.hpp"
#include "capture/capture_factory.hpp"
#include "capture/bmp_writer.hpp"
#ifdef AVP_WITH_FFMPEG
#include "preprocess/wav_reader.hpp"
#include "capture/wav_writer.hpp"
#endif
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>
#include <vector>

using namespace avp;

// a moving synthetic BGRA frame (deterministic content that flows through the whole pipeline).
static VideoFrame synth(int w, int h, int t) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA;
  f.data.resize((size_t)w * h * 4);
  int cx = (t * 7) % w, cy = (t * 5) % h;
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    uint8_t* p = &f.data[((size_t)y * w + x) * 4];
    int dx = x - cx, dy = y - cy; bool box = (dx * dx + dy * dy) < 1200;
    p[0] = (uint8_t)((x + t * 3) & 0xFF); p[1] = (uint8_t)((y + t * 2) & 0xFF);
    p[2] = box ? 240 : (uint8_t)((x + y) & 0xFF); p[3] = 255;
  }
  return f;
}

// high-entropy variant: moving content + per-pixel noise, so the encoder's rate control has real room
// to hit (or overshoot) the bitrate target — needed to exercise congestion control (simple content
// compresses far below the target, so the link would never congest and CC couldn't converge).
static VideoFrame synth_hi(int w, int h, int t) {
  VideoFrame f = synth(w, h, t);
  uint32_t r = 0x2545F491u * (uint32_t)(t + 1);
  for (int i = 0; i < w * h; ++i) {
    r = r * 1664525u + 1013904223u; int nz = (int)((r >> 8) % 160) - 80;
    uint8_t* p = &f.data[(size_t)i * 4];
    for (int c = 0; c < 3; ++c) { int v = p[c] + nz; p[c] = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v); }
  }
  return f;
}

int main(int argc, char** argv) {
  double seconds = 3.0, loss = 0.05, link_kbps = 800; int fps = 15;
  std::string source = "synth", transport = "loopback"; bool layered = true, cc_on = false;
  for (int i = 1; i < argc; ++i) {
    if (!strcmp(argv[i], "--seconds") && i + 1 < argc) seconds = atof(argv[++i]);
    else if (!strcmp(argv[i], "--fps") && i + 1 < argc) fps = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--loss") && i + 1 < argc) loss = atof(argv[++i]);
    else if (!strcmp(argv[i], "--source") && i + 1 < argc) source = argv[++i];
    else if (!strcmp(argv[i], "--transport") && i + 1 < argc) transport = argv[++i];
    else if (!strcmp(argv[i], "--cc")) cc_on = true;
    else if (!strcmp(argv[i], "--link-kbps") && i + 1 < argc) link_kbps = atof(argv[++i]);
    else if (!strcmp(argv[i], "--no-layered")) layered = false;
  }

  std::printf("=== AV pipeline — real-time loopback conference (all 8 modules) ===\n");
  std::printf("source=%s  transport=%s  fps=%d  loss=%.0f%%  layered=%d  cc=%d%s  duration=%.1fs\n\n",
              source.c_str(), transport.c_str(), fps, loss * 100, (int)layered, (int)cc_on,
              cc_on ? ("(link " + std::to_string((int)link_kbps) + " kbps)").c_str() : "", seconds);

  ConferenceConfig cc; cc.width = 320; cc.height = 240; cc.fps = fps; cc.loss = loss; cc.layered = layered;
  cc.use_udp = (transport == "udp"); cc.cc = cc_on; cc.link_bps = link_kbps * 1000;
  if (cc_on) cc.bitrate_bps = 2000000;   // start high so CC has to converge down to the link

  // optional real screen source (crop to WxH)
  std::unique_ptr<IVideoSource> screen; std::string notes;
  if (source == "screen") {
    CaptureConfig cap; screen = CreateBestScreenSource(cap, notes);
    if (screen) std::printf("screen backend: %s (%dx%d) -> cropped to %dx%d\n\n", screen->backend(), screen->width(), screen->height(), cc.width, cc.height);
    else { std::printf("screen capture unavailable (%s); using synth\n\n", notes.c_str()); source = "synth"; }
  }

  Conference conf;
  if (!conf.open(cc)) { std::printf("conference open failed\n"); return 1; }
  std::printf("media channel: %s", conf.channel().name());
  if (cc.use_udp) std::printf(" (rx port %u)", conf.udp_port());
  std::printf("\n\n");

  auto crop_from = [&](const VideoFrame& big) {
    VideoFrame f; f.width = cc.width; f.height = cc.height; f.stride = cc.width * 4; f.format = PixelFormat::BGRA;
    f.data.resize((size_t)cc.width * cc.height * 4);
    int bs = big.stride ? big.stride : big.width * 4;
    for (int y = 0; y < cc.height; ++y) for (int x = 0; x < cc.width; ++x) {
      const uint8_t* s = (y < big.height && x < big.width) ? &big.data[(size_t)y * bs + (size_t)x * 4] : nullptr;
      uint8_t* d = &f.data[((size_t)y * cc.width + x) * 4];
      if (s) { d[0] = s[0]; d[1] = s[1]; d[2] = s[2]; d[3] = 255; } else { d[0] = d[1] = d[2] = 0; d[3] = 255; }
    }
    return f;
  };

  using clock = std::chrono::steady_clock;
  auto t0 = clock::now(); const double period = 1.0 / fps;
  int n = 0, decoded = 0, intact = 0, recovered = 0; long bytes = 0, late_bytes = 0; int late_n = 0;
  double psnr_sum = 0, proc_ms = 0, late_target = 0;
  if (cc_on) std::printf("congestion control (encoder bitrate adapts to the %.0f kbps link):\n", link_kbps);
  for (int i = 0;; ++i) {
    if (std::chrono::duration<double>(clock::now() - t0).count() >= seconds) break;
    VideoFrame frame;
    if (source == "screen" && screen) { VideoFrame big; if (screen->grab(big)) frame = crop_from(big); else frame = synth(cc.width, cc.height, i); }
    else frame = cc_on ? synth_hi(cc.width, cc.height, i) : synth(cc.width, cc.height, i);

    auto p0 = clock::now();
    FrameStat st = conf.process_frame(frame);
    proc_ms += std::chrono::duration<double, std::milli>(clock::now() - p0).count();
    ++n; bytes += st.enc_bytes; if (st.intact) ++intact; if (st.recovered) ++recovered;
    if (st.decoded) { ++decoded; psnr_sum += st.psnr; }
    if (cc_on) {
      double el = std::chrono::duration<double>(clock::now() - t0).count();
      if (el > seconds * 0.5) { late_bytes += st.enc_bytes; late_target += st.target_bps; ++late_n; }
      if (i % fps == 0) std::printf("   t=%4.1fs  cc target %5.0f kbps  encode %5.0f kbps  %s\n",
                                    el, st.target_bps / 1000, st.enc_bytes * 8.0 * fps / 1000, conf.cc_state().signal);
    }

    auto target = t0 + std::chrono::duration_cast<clock::duration>(std::chrono::duration<double>((i + 1) * period));
    std::this_thread::sleep_until(target);
  }
  double elapsed = std::chrono::duration<double>(clock::now() - t0).count();

  std::printf("VIDEO — %d frames in %.2fs = %.1f fps (target %d)\n", n, elapsed, n / elapsed, fps);
  std::printf("  encode        avg %ld B/frame -> %.0f kbps\n", n ? bytes / n : 0, elapsed > 0 ? bytes * 8 / elapsed / 1000 : 0);
  std::printf("  channel       %ld sent, %ld dropped (%.1f%%)\n", conf.channel().sent(), conf.channel().dropped(),
              conf.channel().sent() ? 100.0 * conf.channel().dropped() / conf.channel().sent() : 0);
  std::printf("  recover       %d frames needed FEC/reorder recovery\n", recovered);
  std::printf("  reassemble    %d/%d access units byte-intact\n", intact, n);
#ifdef AVP_WITH_FFMPEG
  std::printf("  decode+render %d frames decoded, avg PSNR %.1f dB, %d BMP snapshots\n", decoded, decoded ? psnr_sum / decoded : 0, conf.rendered());
#else
  std::printf("  decode        (build -DAVP_WITH_FFMPEG=ON for real decode + PSNR + BMP)\n");
#endif
  std::printf("  latency       %.2f ms avg end-to-end processing per frame\n\n", n ? proc_ms / n : 0);

  if (cc_on) {
    double avg_target = late_n ? late_target / late_n / 1000 : 0;         // CC target, 2nd half (kbps)
    double settled_enc = late_n ? late_bytes * 8.0 * fps / 1000.0 / late_n : 0;
    bool ok = avg_target > link_kbps * 0.6 && avg_target < link_kbps * 1.5;
    std::printf("CONGESTION CONTROL — %.0f kbps link\n", link_kbps);
    std::printf("  CC target: started 2000 kbps -> converged to ~%.0f kbps (delay-based, tracks the link)  %s\n",
                avg_target, ok ? "OK" : "(check)");
    std::printf("  set_bitrate() feeds that target to the real encoder each frame (actual ~%.0f kbps —\n"
                "    the baseline minih264 rate control is loose; a strict-CBR encoder would sit on target)\n\n", settled_enc);
  }

#ifdef AVP_WITH_FFMPEG
  {
    std::vector<float> mic; int rate = 48000;
    if (!read_wav_mono("mic_preprocessed.wav", mic, rate) && !read_wav_mono("mic_capture.wav", mic, rate)) {
      mic.resize(48000); for (size_t i = 0; i < mic.size(); ++i) mic[i] = 0.25f * sinf(2 * 3.14159265f * 440 * i / rate);
    }
    std::vector<float> out;
    if (conf.process_audio(mic, rate, out)) {
      AudioFormat af; af.sample_rate = rate; af.channels = 1; af.bits = 32; af.is_float = true;
      write_wav("conf_audio.wav", af, MonoFloatToPcm(out));
      std::printf("AUDIO — 3A -> AAC -> loopback -> AAC decode: %zu -> %zu samples -> conf_audio.wav\n\n", mic.size(), out.size());
    }
  }
#endif

  std::printf("DONE — one process ran capture->preprocess->encode->FEC->transport->jitter->decode->render in real time.\n");
  return 0;
}
