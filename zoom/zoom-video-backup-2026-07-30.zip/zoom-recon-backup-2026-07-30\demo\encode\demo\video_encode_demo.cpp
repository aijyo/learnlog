// video_encode_demo.cpp — module 3 video encode, verified end to end:
//   * real H.264: minih264 emits Annex-B (SPS/PPS/IDR on key frames, P otherwise)
//   * SVC temporal layering (§3.2): dyadic ×0.5 ids (0 2 1 2 …); SFU pruning by subscription
//   * keyframe request model (§3.3): request_idr() mid-stream forces an IDR
//   * rate control: a lower bitrate target yields a smaller stream
//   * screen-content detection (§3.4): natural vs screen frames classified differently
//   * (AVP_WITH_FFMPEG) closes the loop: FFmpeg decodes the H.264 back and reports PSNR
#include "encode/h264_encoder.hpp"
#include "encode/svc_layers.hpp"
#include "encode/screen_content.hpp"
#include "preprocess/video_preprocess.hpp"
#include "capture/bmp_writer.hpp"
#ifdef AVP_WITH_FFMPEG
#include "encode/h264_decode_verify.hpp"
#endif
#include <cstdint>
#include <cstdio>
#include <vector>

using namespace avp;

static uint32_t rng = 0x51ed270b;
static int noise(int a) { rng = rng * 1664525u + 1013904223u; return (int)((rng >> 9) % (2 * a + 1)) - a; }

// synthetic natural-ish I420 (smooth gradient + a little noise, moving with t)
static I420Image natural_i420(int w, int h, int t) {
  I420Image im; im.w = w; im.h = h;
  im.y.assign((size_t)w * h, 0); im.u.assign((size_t)im.cw() * im.ch(), 128); im.v.assign((size_t)im.cw() * im.ch(), 128);
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    int v = (x + y) / 2 + t * 3 + noise(6); im.y[(size_t)y * w + x] = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v);
  }
  return im;
}
// synthetic screen-content I420 (solid background + sharp rectangles/"text" bars)
static I420Image screen_i420(int w, int h) {
  I420Image im; im.w = w; im.h = h;
  im.y.assign((size_t)w * h, 235); im.u.assign((size_t)im.cw() * im.ch(), 128); im.v.assign((size_t)im.cw() * im.ch(), 128);
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    bool bar = ((y % 20) < 3) && (x % 7 < 5) && x > 20 && x < w - 20;   // crisp "text" rows
    bool box = (x > w / 2 && y > h / 2);                                 // a solid UI panel
    if (bar) im.y[(size_t)y * w + x] = 16; else if (box) im.y[(size_t)y * w + x] = 180;
  }
  return im;
}
static void scan_nals(const std::vector<uint8_t>& bs, int& n, bool& idr, bool& sps, bool& pps) {
  n = 0; idr = sps = pps = false;
  for (size_t i = 0; i + 3 < bs.size(); ++i) {
    size_t hd = (!bs[i] && !bs[i+1] && !bs[i+2] && bs[i+3] == 1) ? 4 : ((!bs[i] && !bs[i+1] && bs[i+2] == 1) ? 3 : 0);
    if (!hd) continue; int t = bs[i + hd] & 0x1F; ++n;
    if (t == 5) idr = true; if (t == 7) sps = true; if (t == 8) pps = true; i += hd;
  }
}

int main() {
  std::printf("=== AV pipeline / module 3: VIDEO encode ===\n\n");
  const int W = 320, H = 240, FPS = 30, NFR = 16;

  // ---- 1) SVC temporal layering: dyadic id pattern + per-subscription fps ----
  TemporalLayering tl; tl.layers = 3;
  std::printf("1) SVC temporal layering (dyadic x0.5, %d layers)\n   tid[0..7] =", tl.layers);
  for (int i = 0; i < 8; ++i) std::printf(" %d", tl.temporal_id(i));
  std::printf("   (expect 0 2 1 2 0 2 1 2)\n   fps @ sub L0/L1/L2 = %.1f / %.1f / %.1f\n\n",
              tl.fps_at(0, FPS), tl.fps_at(1, FPS), tl.fps_at(2, FPS));

  // ---- 2) encode a real sequence; IDR first, request another IDR at frame 8 ----
  VideoEncoderConfig cfg; cfg.width = W; cfg.height = H; cfg.fps = FPS; cfg.bitrate_bps = 1200000; cfg.gop = 60; cfg.temporal_layers = 3;
  H264Encoder enc; if (!enc.open(cfg)) { std::printf("encoder open failed\n"); return 1; }
  std::printf("2) H.264 encode (%s) %dx%d\n", enc.codec(), enc.width(), enc.height());
  std::vector<int> sizes(NFR); std::vector<int> tids(NFR);
  long total = 0; int idr_count = 0;
#ifdef AVP_WITH_FFMPEG
  H264Decoder dec; dec.open(); double psnr_sum = 0; int psnr_n = 0; std::vector<I420Image> srcs(NFR);
#endif
  for (int t = 0; t < NFR; ++t) {
    I420Image src = natural_i420(W, H, t);
    bool force = (t == 8);
    EncodedFrame ef = enc.encode(src, force);
    int nnal; bool idr, sps, pps; scan_nals(ef.data, nnal, idr, sps, pps);
    sizes[t] = ef.size(); tids[t] = ef.temporal_id; total += ef.size(); if (ef.keyframe()) ++idr_count;
    if (t < 3 || force)
      std::printf("   f%-2d %-4s tid=%d %5d B  [%s%s%s%s]%s\n", t, to_string(ef.type), ef.temporal_id, ef.size(),
                  sps?"SPS ":"", pps?"PPS ":"", idr?"IDR":"", (!idr&&ef.size()>0)?"P":"", force?"  <- request_idr()":"");
#ifdef AVP_WITH_FFMPEG
    srcs[t] = src; I420Image outf;
    if (dec.decode(ef.data, outf) && outf.w == W) { psnr_sum += PsnrY(src, outf); ++psnr_n; }
#endif
  }
  std::printf("   %d frames, %ld bytes total, %d IDR (frame0 + requested frame8)\n\n", NFR, total, idr_count);

  // ---- 3) SFU pruning: bytes/fps kept at each subscription layer ----
  std::printf("3) SFU temporal pruning (one encode, pruned per receiver)\n");
  for (int L = 0; L <= tl.max_tid(); ++L) {
    long kept = 0; int kn = 0;
    for (int t = 0; t < NFR; ++t) if (tids[t] <= L) { kept += sizes[t]; ++kn; }
    std::printf("   sub L%d: keep %2d/%d frames, %6ld B (%.0f%%), ~%.1f fps\n",
                L, kn, NFR, kept, 100.0 * kept / total, tl.fps_at(L, FPS));
  }
  std::printf("\n");

  // ---- 4) rate control: lower target -> smaller stream ----
  auto stream_bytes = [&](int bps) {
    VideoEncoderConfig c = cfg; c.bitrate_bps = bps; H264Encoder e; e.open(c);
    long b = 0; for (int t = 0; t < NFR; ++t) b += e.encode(natural_i420(W, H, t)).size(); return b;
  };
  long hi = stream_bytes(3000000), lo = stream_bytes(300000);
  std::printf("4) rate control: 3.0 Mbps -> %ld B   vs   0.3 Mbps -> %ld B   (%s)\n\n",
              hi, lo, lo < hi ? "OK, target honored" : "UNEXPECTED");

  // ---- 5) screen-content detection ----
  ScreenContentStats sn = DetectScreenContent(natural_i420(W, H, 0));
  ScreenContentStats ss = DetectScreenContent(screen_i420(W, H));
  std::printf("5) screen-content detection (§3.4)\n");
  std::printf("   natural: flat=%.2f sharp=%.3f palette=%.2f score=%.2f -> %s\n", sn.flat_ratio, sn.sharp_edge_ratio, sn.palette_ratio, sn.score, sn.advice());
  std::printf("   screen : flat=%.2f sharp=%.3f palette=%.2f score=%.2f -> %s\n\n", ss.flat_ratio, ss.sharp_edge_ratio, ss.palette_ratio, ss.score, ss.advice());

#ifdef AVP_WITH_FFMPEG
  std::printf("6) encode->decode loop (FFmpeg H.264 decode): mean luma PSNR = %.1f dB over %d frames\n\n",
              psnr_n ? psnr_sum / psnr_n : 0.0, psnr_n);
#else
  std::printf("6) (build with -DAVP_WITH_FFMPEG=ON to also decode the H.264 back and report PSNR)\n\n");
#endif

  // ---- end to end: real captured frame -> preprocess -> encode ----
  VideoFrame bmp;
  if (read_bmp("capture_frame0.bmp", bmp)) {
    VideoPreprocessor pp; VideoPreprocessResult pr; pp.Process(bmp, pr);
    VideoEncoderConfig c; c.width = pr.frame.w; c.height = pr.frame.h; c.fps = 30; c.bitrate_bps = 2000000;
    H264Encoder e; e.open(c);
    EncodedFrame ef = e.encode(pr.frame, true);
    std::printf("real frame: capture_frame0.bmp -> preprocess -> encode: %s %d bytes (%dx%d)\n",
                to_string(ef.type), ef.size(), e.width(), e.height());
  }

  std::printf("\nDONE (video encode verified: real H.264, SVC layering, keyframe control, rate control, SC detect)\n");
  return 0;
}
