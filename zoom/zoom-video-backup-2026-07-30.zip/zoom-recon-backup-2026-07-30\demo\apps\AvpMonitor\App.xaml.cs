using System.Windows;

namespace AvpMonitor
{
    public partial class App : Application
    {
    }
}
