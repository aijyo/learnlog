// vp9_ltr.hpp — VP9 screen-content encoder driven through libvpx DIRECTLY (not avcodec), so it can manage
// references — specifically a LONG-TERM REFERENCE (the VP9 "golden" frame) for Zoom-style loss recovery.
//
// Why not avcodec: avcodec's libvpx wrapper does not expose per-frame reference control (no way to say "this
// frame refreshes golden" or "recover by referencing ONLY golden"). Zoom's zlt does LTR recovery (RE:
// SetKeyPictureRequest case 2 = point the next P at a known-good earlier picture, NOT a full IDR). libvpx's
// golden frame IS a long-term reference, so we drive it via libvpx directly — the mechanism proven in
// apps/ltr_test.cpp, here wired into the live IScreenEncoder. The decoder stays FFmpeg/avcodec VP9 (a
// standard VP9 bitstream; golden refs are ordinary VP9 — no decoder change).
//
// Compiled ONLY where libvpx is linked (peer, via AVP_WITH_VPX). Every other target keeps the avcodec VP9
// encoder (vp9_screen.hpp) unchanged — this header is never included without the vpx headers/lib present.
#pragma once
#ifdef AVP_WITH_VPX
#include "encode/screen_codec.hpp"
#include <cstring>
#include <vector>
extern "C" {
#include "vpx/vpx_encoder.h"
#include "vpx/vp8cx.h"
#include "vpx/vpx_decoder.h"
#include "vpx/vp8dx.h"
#include "vpx/vpx_image.h"
}

namespace avp {

class Vp9LtrEncoder : public IScreenEncoder {
public:
  bool open(const ScreenEncParams& p) override {
    p_ = p;
    if (vpx_codec_enc_config_default(vpx_codec_vp9_cx(), &cfg_, 0)) return false;
    cfg_.g_w = p.width; cfg_.g_h = p.height;
    cfg_.g_timebase = { 1, p.fps <= 0 ? 12 : p.fps };
    cfg_.rc_target_bitrate = (unsigned)(p.kbps <= 0 ? 1500 : p.kbps);
    cfg_.rc_end_usage = VPX_CBR;
    cfg_.g_lag_in_frames = 0;                 // no lookahead -> low delay
    cfg_.g_error_resilient = 1;               // each frame more self-contained on a lossy link
    cfg_.rc_min_quantizer = p.qmin < 0 ? 4 : p.qmin;
    cfg_.rc_max_quantizer = p.qmax <= 0 ? 40 : p.qmax;
    cfg_.kf_mode = VPX_KF_AUTO;               // KEEP periodic keyframes (joins / ultimate loss fallback) ...
    cfg_.kf_max_dist = (unsigned)(p.gop <= 0 ? 48 : p.gop);   // ... every gop frames; LTR recovery is the CHEAP path in between
    cfg_.g_threads = 4;
    if (vpx_codec_enc_init(&enc_, vpx_codec_vp9_cx(), &cfg_, 0)) return false;
    vpx_codec_control(&enc_, VP8E_SET_CPUUSED, 8);           // fastest real-time preset
    if (p.screen_content) vpx_codec_control(&enc_, VP9E_SET_TUNE_CONTENT, VP9E_CONTENT_SCREEN);   // <<< screen-content coding
    vpx_codec_control(&enc_, VP9E_SET_AQ_MODE, 0);
    if (!vpx_img_alloc(&img_, VPX_IMG_FMT_I420, p.width, p.height, 32)) { vpx_codec_destroy(&enc_); return false; }
    open_ = true; return true;
  }

  bool encode(const I420Image& in, bool force_key, std::vector<uint8_t>& out, bool& key) override {
    out.clear(); key = false;
    if (!open_) return false;
    copy_i420(in);
    vpx_enc_frame_flags_t flags = 0;
    bool recover = ltr_recover_ && !force_key && have_golden_;   // LTR recovery only once a golden is established
    if (force_key) {
      flags |= VPX_EFLAG_FORCE_KF;                              // full IDR (join / FIR / periodic GOP)
    } else if (recover) {
      // Zoom case 2: recover by referencing ONLY the golden LTR (which the decoder still holds), no full IDR.
      flags |= VP8_EFLAG_NO_REF_LAST | VP8_EFLAG_NO_REF_ARF;    // ref golden only (NOT the possibly-broken last)
    } else if ((frame_no_ % ltr_period_) == 0 && frame_no_ > 0) {
      flags |= VP8_EFLAG_FORCE_GF | VP8_EFLAG_NO_UPD_ARF;       // periodically refresh golden = new LTR checkpoint
    }
    ltr_recover_ = false;
    if (vpx_codec_encode(&enc_, &img_, frame_no_, 1, flags, VPX_DL_REALTIME)) return false;
    ++frame_no_;
    vpx_codec_iter_t it = nullptr; const vpx_codec_cx_pkt_t* pkt; bool got = false;
    while ((pkt = vpx_codec_get_cx_data(&enc_, &it))) {
      if (pkt->kind != VPX_CODEC_CX_FRAME_PKT) continue;
      const uint8_t* b = (const uint8_t*)pkt->data.frame.buf;
      out.insert(out.end(), b, b + pkt->data.frame.sz);
      if (pkt->data.frame.flags & VPX_FRAME_IS_KEY) key = true;
      got = true;
    }
    if (key || (flags & VP8_EFLAG_FORCE_GF)) have_golden_ = true;   // a key re-seeds golden; a GF-refresh establishes it
    return got;
  }

  void set_bitrate(int bps) override {
    if (!open_ || bps <= 0) return;
    cfg_.rc_target_bitrate = (unsigned)(bps / 1000);   // congestion-control retarget (whole cfg re-applied)
    vpx_codec_enc_config_set(&enc_, &cfg_);
  }
  bool supports_ltr() const override { return true; }
  void request_ltr_recover() override { ltr_recover_ = true; }
  const char* name() const override { return "VP9 screen-content (libvpx direct, LTR loss-recovery)"; }
  ~Vp9LtrEncoder() override { if (open_) { vpx_img_free(&img_); vpx_codec_destroy(&enc_); } }

private:
  void copy_i420(const I420Image& in) {
    const int w = p_.width, h = p_.height, cw = w / 2, chh = h / 2;
    for (int j = 0; j < h; ++j) {
      int sj = j < in.h ? j : in.h - 1; uint8_t* d = img_.planes[0] + (size_t)j * img_.stride[0];
      for (int i = 0; i < w; ++i) { int si = i < in.w ? i : in.w - 1; d[i] = in.y[(size_t)sj * in.w + si]; }
    }
    for (int j = 0; j < chh; ++j) {
      int sj = j < in.ch() ? j : in.ch() - 1;
      uint8_t* du = img_.planes[1] + (size_t)j * img_.stride[1];
      uint8_t* dv = img_.planes[2] + (size_t)j * img_.stride[2];
      for (int i = 0; i < cw; ++i) { int si = i < in.cw() ? i : in.cw() - 1;
        du[i] = in.u[(size_t)sj * in.cw() + si]; dv[i] = in.v[(size_t)sj * in.cw() + si]; }
    }
  }
  ScreenEncParams p_{};
  vpx_codec_ctx_t enc_{};
  vpx_codec_enc_cfg_t cfg_{};
  vpx_image_t img_{};
  bool open_ = false, ltr_recover_ = false, have_golden_ = false;
  int64_t frame_no_ = 0;
  static constexpr int ltr_period_ = 12;   // refresh the golden LTR every 12 frames (a rolling clean checkpoint)
};

// Matching libvpx-DIRECT VP9 decoder. The avcodec VP9 decoder rejected our libvpx encoder's bitstream
// (golden-LTR ref structure) — decode with libvpx too (the enc↔dec pair proven in apps/ltr_test.cpp).
class Vp9LtrDecoder : public IScreenDecoder {
public:
  bool open() override {
    if (vpx_codec_dec_init(&dec_, vpx_codec_vp9_dx(), nullptr, 0)) return false;
    open_ = true; return true;
  }
  bool decode(const std::vector<uint8_t>& au, I420Image& out) override {
    if (!open_ || au.empty()) return false;
    vpx_codec_stream_info_t si{}; si.sz = sizeof(si);   // is this AU an intra/keyframe? (freeze-on-loss un-freeze point)
    bool is_kf = (vpx_codec_peek_stream_info(vpx_codec_vp9_dx(), au.data(), (unsigned)au.size(), &si) == VPX_CODEC_OK) && si.is_kf;
    if (vpx_codec_decode(&dec_, au.data(), (unsigned)au.size(), nullptr, 0) != VPX_CODEC_OK) return false;
    vpx_codec_iter_t it = nullptr; vpx_image_t* img; bool got = false;
    while ((img = vpx_codec_get_frame(&dec_, &it))) {
      out.keyframe = is_kf;
      int corrupted = 0;   // libvpx reports concealment directly (better than the h264 log-scrape): a lost/missing ref -> mosaic
      if (vpx_codec_control(&dec_, VP8D_GET_FRAME_CORRUPTED, &corrupted) == VPX_CODEC_OK) out.corrupt = (corrupted != 0);
      out.w = img->d_w; out.h = img->d_h;
      out.y.assign((size_t)out.w * out.h, 0);
      out.u.assign((size_t)out.cw() * out.ch(), 128);
      out.v.assign((size_t)out.cw() * out.ch(), 128);
      for (int j = 0; j < out.h; ++j) memcpy(&out.y[(size_t)j * out.w], img->planes[0] + (size_t)j * img->stride[0], out.w);
      for (int j = 0; j < out.ch(); ++j) {
        memcpy(&out.u[(size_t)j * out.cw()], img->planes[1] + (size_t)j * img->stride[1], out.cw());
        memcpy(&out.v[(size_t)j * out.cw()], img->planes[2] + (size_t)j * img->stride[2], out.cw());
      }
      got = true;
    }
    return got;
  }
  const char* name() const override { return "VP9 (libvpx direct decoder — matches the LTR encoder)"; }
  ~Vp9LtrDecoder() override { if (open_) vpx_codec_destroy(&dec_); }
private:
  vpx_codec_ctx_t dec_{}; bool open_ = false;
};

}  // namespace avp
#endif  // AVP_WITH_VPX
