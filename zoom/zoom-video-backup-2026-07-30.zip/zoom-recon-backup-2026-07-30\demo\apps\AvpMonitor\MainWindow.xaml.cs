using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace AvpMonitor
{
    // Two-way conference monitor: launches peer.exe twice (A:50001↔B:50002, real cross-process UDP) and
    // shows each peer's RECEIVED video side by side (left = what A got from B, right = what B got from A),
    // plus per-peer stats, a live chart, and live loss/cc/link control. Reads the C++ PeerShare mappings
    // by byte offset to match apps/include/apps/ipc_shared.hpp (Pack=4).
    public partial class MainWindow : Window
    {
        const int W = 1920, H = 1088;   // matches ipc_shared.hpp kW/kH (native-1080p screen share)
        // Launch peer.exe from THIS app's own folder when it's packaged there (portable/delivered demo);
        // otherwise fall back to the dev build dir. Before this, ExeDir was hardcoded to build-ff, so a
        // packaged dist/ ran the dev build's peer.exe (or none) instead of the peer.exe shipped beside it.
        static readonly string ExeDir = ResolveExeDir();
        static string ResolveExeDir()
        {
            try
            {
                string local = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                if (!string.IsNullOrEmpty(local) && File.Exists(System.IO.Path.Combine(local, "peer.exe"))) return local;
            }
            catch { }
            return @"D:\code\work\av-pipeline\build-ff\apps\Release";   // dev fallback
        }
        const string PeerAMap = @"Local\AvpPeerA", PeerBMap = @"Local\AvpPeerB", ControlMap = @"Local\AvpControl";
        const int PeerFrameOffset = 100;  // ipc_shared.hpp PeerShare.frame[0] (after audio + av_sync_ms + net_delay_ms + frame_front@96)

        Process _peerA, _peerB;
        VfxConfig _vfx = new VfxConfig();   // advanced VFX-module strengths, edited via the ⚙ 配置 window
        bool _running;                       // drives the single Start/Stop toggle button
        MemoryMappedFile _control; MemoryMappedViewAccessor _ctrlAcc;
        readonly DispatcherTimer _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(33) };
        readonly WriteableBitmap _wbA = new WriteableBitmap(W, H, 96, 96, PixelFormats.Bgra32, null);
        readonly WriteableBitmap _wbB = new WriteableBitmap(W, H, 96, 96, PixelFormats.Bgra32, null);
        readonly byte[] _frameA = new byte[W * H * 4], _frameB = new byte[W * H * 4];
        uint _lastSeqA = uint.MaxValue, _lastSeqB = uint.MaxValue;
        int _cmA = -1, _cmB = -1;   // each peer's OWN sent content class; a panel shows the REMOTE peer's

        const int MaxPts = 180;
        Polyline _encLine, _ccLine, _lossLine;
        readonly List<double> _encH = new List<double>(), _ccH = new List<double>(), _lossH = new List<double>();
        double _curEnc, _curCc, _curLoss;

        // ---- RAISR super-resolution tab ----
        const string RaisrMap = @"Local\AvpRaisr";
        const int kRW = 1280, kRH = 960;                               // matches ipc_shared.hpp RaisrShare
        static readonly long SrBuf = (long)kRW * kRH * 4;
        static readonly long OrigOff = 56, BilinOff = 56 + 2 * SrBuf, RaisrOff = 56 + 4 * SrBuf;  // orig/bilin/raisr[0] offsets (Pack=4)
        string _srSrcName = "";   // "摄像头 …" / "合成图" / "图片"
        Process _raisrCam;
        readonly DispatcherTimer _srTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(40) };
        WriteableBitmap _wbSrL, _wbSrR;
        byte[] _srBuf;
        uint _srLastSeq = uint.MaxValue;
        int _srInW, _srInH, _srOw, _srOh;   // left = original (in), right = processed (out=2x)

        public MainWindow()
        {
            InitializeComponent();
            VideoA.Source = _wbA; VideoB.Source = _wbB;
            _encLine = MakeLine(Color.FromRgb(0xD0, 0xD0, 0xD0));
            _ccLine = MakeLine(Color.FromRgb(0x4E, 0xC9, 0xB0));
            _lossLine = MakeLine(Color.FromRgb(0xE0, 0x55, 0x61));
            LossSlider.ValueChanged += (s, e) => { LossLabel.Text = ((int)LossSlider.Value) + "%"; WriteControl(); };
            LinkSlider.ValueChanged += (s, e) => { LinkLabel.Text = ((int)LinkSlider.Value) + "k"; WriteControl(); };
            FpsSlider.ValueChanged += (s, e) => { if (FpsLabel != null) FpsLabel.Text = ((int)FpsSlider.Value).ToString(); WriteControl(); };
            CcCheck.Checked += (s, e) => WriteControl();
            CcCheck.Unchecked += (s, e) => WriteControl();
            RecvSrCheck.Checked += (s, e) => WriteControl();      // live toggle of receive-side super-res
            RecvSrCheck.Unchecked += (s, e) => WriteControl();
            ChromaGuidedCheck.Checked += (s, e) => WriteControl();   // live JBU <-> Zoom guided-filter chroma A/B
            ChromaGuidedCheck.Unchecked += (s, e) => WriteControl();
            _timer.Tick += Timer_Tick;
            _srTimer.Tick += SrTimer_Tick;
            Closing += (s, e) => { StopControl(); KillProcs(); KillRaisr(); };
            Loaded += (s, e) => RefreshCameras();
        }

        void WriteControl()
        {
            if (_ctrlAcc == null) return;
            try { _ctrlAcc.Write(4, (int)LossSlider.Value); _ctrlAcc.Write(8, CcCheck.IsChecked == true ? 1 : 0); _ctrlAcc.Write(12, (int)LinkSlider.Value); _ctrlAcc.Write(20, (int)FpsSlider.Value);
                  _ctrlAcc.Write(24, RecvSrCheck.IsChecked == true ? 1 : 2);                 // reserved[0]: 1=recv-super-res on, 2=off
                  _ctrlAcc.Write(28, ChromaGuidedCheck.IsChecked == true ? 1 : 0); } catch { } // reserved[1]: 1=Zoom guided chroma, 0=our JBU
        }
        void StopControl()
        {
            try { _ctrlAcc?.Write(16, 1); } catch { }
            try { _ctrlAcc?.Dispose(); _control?.Dispose(); } catch { }
            _ctrlAcc = null; _control = null;
        }

        // single toggle button: Start when idle, Stop when running
        void Run_Click(object s, RoutedEventArgs e) { if (_running) StopRun(); else StartRun(); }

        void SetRunBtn()
        {
            RunBtn.Content = _running ? "■  Stop" : "▶  Start";
            RunBtn.Background = (System.Windows.Media.Brush)FindResource(_running ? "StopBrush" : "OkBrush");
        }

        void StartRun()
        {
            KillProcs();
            string peer = System.IO.Path.Combine(ExeDir, "peer.exe");
            if (!File.Exists(peer)) { Status.Text = "peer.exe not found in " + ExeDir + " (build target 'peer')"; return; }
            _control = MemoryMappedFile.CreateOrOpen(ControlMap, 64);
            _ctrlAcc = _control.CreateViewAccessor(0, 64);
            _ctrlAcc.Write(0, 0x49505641u); _ctrlAcc.Write(16, 0);
            WriteControl();
            // codec dropdown: 0=av1 (Zoom SC, default), 1=vp9, 2=h264 (zlt libx264), 3=h265 (zlt libx265)
            string codec = CodecCombo.SelectedIndex == 1 ? "vp9" : CodecCombo.SelectedIndex == 2 ? "h264" : CodecCombo.SelectedIndex == 3 ? "h265" : "av1";
            // AV1 screen-content runs libaom `good` (full IntraBC) -> heavier -> Zoom's low frame rate (8 fps);
            // VP9/H.264 stay at 12 fps. Screen share trades fps for sharp text (§1.4).
            int fps = (int)FpsSlider.Value;   // manual frame rate (live via control block when adaptive is off)
            string source = SourceCombo.SelectedIndex == 1 ? "camera" : "screen";
            string common = $"--fps {fps} --loss {(LossSlider.Value / 100.0):0.###} --codec {codec} --source {source}";
            if (AdaptCheck.IsChecked != true) common += " --no-adapt";   // §9 ladder on by default
            if (NackCheck.IsChecked != true) common += " --no-nack";      // NACK retransmit on by default
            if (MicCheck.IsChecked == true) common += " --mic";          // capture the real microphone
            if (PlayCheck.IsChecked == true) common += " --play";        // live speaker (use headphones!)
            if (DualCheck.IsChecked == true) common += " --dual";        // camera(ch3) + screen-share(ch2) at once -> PIP composite
            if (VfxCheck.IsChecked == true)                              // Zoom ns_vpp perceptual enhance + the ⚙ 配置 module strengths
            {
                var ic = System.Globalization.CultureInfo.InvariantCulture;   // atof wants '0.30' not locale '0,30'
                common += " --vfx"
                    + $" --vfx-light {_vfx.Light.ToString("0.##", ic)} --vfx-color {_vfx.Color.ToString("0.##", ic)}"
                    + $" --vfx-sharpen-cam {_vfx.SharpenCam.ToString("0.##", ic)} --vfx-sharpen-screen {_vfx.SharpenScreen.ToString("0.##", ic)}"
                    + $" --vfx-clahe {_vfx.Clahe.ToString("0.##", ic)}";
            }
            if (CcCheck.IsChecked == true) common += $" --cc --link-kbps {(int)LinkSlider.Value}";
            if (ForceLoResCheck.IsChecked == true) common += " --enc-res 640x360";   // pin low res -> force recv RAISR + chroma path
            _peerA = Launch(peer, $"--id A --local-port 50001 --remote-port 50002 {common}");
            _peerB = Launch(peer, $"--id B --local-port 50002 --remote-port 50001 {common}");
            _lastSeqA = _lastSeqB = uint.MaxValue;
            _running = true; SetRunBtn();
            NoSignalA.Text = NoSignalB.Text = "waiting for frames…";
            NoSignalA.Visibility = NoSignalB.Visibility = Visibility.Visible;   // show until a real frame arrives
            _wbA.WritePixels(new Int32Rect(0, 0, W, H), new byte[W * H * 4], W * 4, 0);   // clear stale frames
            _wbB.WritePixels(new Int32Rect(0, 0, W, H), new byte[W * H * 4], W * 4, 0);
            Status.Text = "running:  peer A(:50001) ⇄ peer B(:50002)   real UDP, " + common;
            _timer.Start();
        }

        void StopRun()
        {
            StopControl();
            System.Threading.Thread.Sleep(150);
            _timer.Stop(); KillProcs();
            _encH.Clear(); _ccH.Clear(); _lossH.Clear(); Redraw();
            _running = false; SetRunBtn();
            Status.Text = "stopped"; NoSignalA.Text = NoSignalB.Text = "no signal — press Start";
            NoSignalA.Visibility = Visibility.Visible; NoSignalB.Visibility = Visibility.Visible;
        }

        void Config_Click(object s, RoutedEventArgs e)
        {
            var w = new ConfigWindow(_vfx.Clone()) { Owner = this };
            if (w.ShowDialog() == true) _vfx = w.Result;   // applied on the next Start (peer.exe reads it via --vfx-* flags)
        }

        static Process Launch(string exe, string args) =>
            Process.Start(new ProcessStartInfo { FileName = exe, Arguments = args, WorkingDirectory = ExeDir, UseShellExecute = false, CreateNoWindow = true });

        void KillProcs()
        {
            try { if (_peerA != null && !_peerA.HasExited) _peerA.Kill(); } catch { }
            try { if (_peerB != null && !_peerB.HasExited) _peerB.Kill(); } catch { }
            KillStrayPeers();   // also clear zombies from a previous run holding UDP 50001/50002 (else bind fails -> black panels)
        }

        // Kill any leftover peer.exe from OUR ExeDir (a crashed/detached run whose Process handle we no longer
        // hold). Without this, a zombie holding local-port 50001/50002 makes the new peer's bind() fail and it
        // exits immediately -> that side never sends/receives -> both viewers stay black.
        static void KillStrayPeers()
        {
            foreach (var p in System.Diagnostics.Process.GetProcessesByName("peer"))
            {
                try { if (string.Equals(System.IO.Path.GetDirectoryName(p.MainModule.FileName), ExeDir, System.StringComparison.OrdinalIgnoreCase)) { p.Kill(); p.WaitForExit(1500); } }
                catch { /* access denied / already gone / different peer.exe — leave it */ }
            }
        }

        void Timer_Tick(object s, EventArgs e)
        {
            // each panel shows the OTHER peer's video, so label it with the REMOTE peer's content class
            _cmA = ReadContentMode(PeerAMap); _cmB = ReadContentMode(PeerBMap);
            ReadPeer(PeerAMap, _wbA, _frameA, StatsA, NoSignalA, ref _lastSeqA, true);
            ReadPeer(PeerBMap, _wbB, _frameB, StatsB, NoSignalB, ref _lastSeqB, false);
            SampleChart();
        }

        // Read just a peer's published content class (PeerShare.content_mode, appended after the frame array).
        static int ReadContentMode(string map)
        {
            try
            {
                using var mmf = MemoryMappedFile.OpenExisting(map, MemoryMappedFileRights.Read);
                using var a = mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read);
                if (a.ReadUInt32(0) == 0) return -1;
                return a.ReadInt32(PeerFrameOffset + 2L * W * H * 4 + 8);
            }
            catch { return -1; }
        }

        void ReadPeer(string map, WriteableBitmap wb, byte[] frame, System.Windows.Controls.TextBlock stats,
                      System.Windows.Controls.TextBlock noSig, ref uint lastSeq, bool isA)
        {
            try
            {
                using var mmf = MemoryMappedFile.OpenExisting(map, MemoryMappedFileRights.Read);
                using var a = mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read);
                if (a.ReadUInt32(0) == 0) return;
                uint sent = a.ReadUInt32(4); int enc = a.ReadInt32(8), cct = a.ReadInt32(12);
                uint rseq = a.ReadUInt32(24); int rdec = a.ReadInt32(32), rrec = a.ReadInt32(36), rdrop = a.ReadInt32(40), run = a.ReadInt32(52);
                int aw = a.ReadInt32(60), ah = a.ReadInt32(64), afps = a.ReadInt32(68), bw = a.ReadInt32(72); double mos = a.ReadInt32(76) / 100.0;
                int atx = a.ReadInt32(80), arx = a.ReadInt32(84);   // Opus audio RMS*1000 (tx / decoded rx)
                int avs = a.ReadInt32(88);   // @88: presented-video vs audio-playout offset (ms); ~0 = lip-synced
                int nd = a.ReadInt32(92);    // @92: abs_net_delay fed to §9 G.107 (RTT/2 + jitter-buffer depth)
                string tier = aw <= 0 ? "tier —" : bw > 0 ? $"tier {ah}p@{afps} · bw L{bw} · MOS {mos:0.0} · delay {nd}ms" : $"tier {ah}p@{afps} · manual fps";
                string audio = $"🔊 opus tx {Bar(atx)} · rx {Bar(arx)}   ⏱ a/v {(avs >= 0 ? "+" : "")}{avs}ms";
                // receive-side super-res telemetry, appended after the frame array (see ipc_shared.hpp PeerShare)
                long srOff = PeerFrameOffset + 2L * W * H * 4;
                int srOn = a.ReadInt32(srOff), srUs = a.ReadInt32(srOff + 4);   // this peer's RECEIVE super-res (describes the displayed frame)
                int frozen = a.ReadInt32(srOff + 12);   // freeze-on-loss active (holding last complete frame vs mosaic)
                int cmode = isA ? _cmB : _cmA;   // the SENDER's content class = what this panel actually shows
                string cm = cmode == 1 ? "screen·text" : cmode == 2 ? "screen·video" : cmode == 3 ? "synth/test(无摄像头?)" : cmode == 0 ? "camera" : "—";
                string sr = srOn == 1 ? $"接收端超分 ● RAISR(GPU) {srUs / 1000.0:0.0}ms" : "接收端超分 ○ bilinear";
                string frz = frozen == 1 ? "   ⏸ 冻结恢复中(抗花屏)" : "";
                stats.Text = $"{(run == 1 ? "● live" : "○ idle")}   sent {sent} frames, {enc} kbps{(cct > 0 ? " · cc " + cct + "k" : "")}\n" +
                             $"received {rdec} decoded · {rrec} FEC-recovered · {rdrop} pkts lost\n" +
                             $"⟳ {tier}    {audio}\n" +
                             $"🔍 {sr}  ·  内容 {cm}{frz}";
                if (isA) { _curEnc = enc; _curCc = cct > 0 ? cct : 0; _curLoss = a.ReadInt32(56); }
                if (rseq != lastSeq && rdec > 0)
                {
                    lastSeq = rseq;
                    // SEQLOCK anti-tearing: the front/back flip only protects ONE publish; with 2 buffers a slow
                    // 8 MB read (WPF, under load) can be overwritten if the writer wraps back — publishes ≥2
                    // frames — DURING our copy, giving a torn frame (the "割裂锯齿" seam on animated content).
                    // Re-read recv_frame_seq(@24) before+after the copy; if it advanced by ≥2, our buffer may be
                    // torn → retry. ≤1 publish means the writer only touched the OTHER buffer → clean.
                    for (int attempt = 0; attempt < 4; ++attempt)
                    {
                        uint s0 = a.ReadUInt32(24);
                        int front = a.ReadInt32(96);                   // frame_front: which double-buffer is complete
                        long fbase = PeerFrameOffset + (long)(front & 1) * ((long)W * H * 4);
                        a.ReadArray(fbase, frame, 0, frame.Length);
                        uint s1 = a.ReadUInt32(24);
                        if (s1 - s0 < 2) break;                        // writer touched only the other buffer → not torn
                    }
                    wb.WritePixels(new Int32Rect(0, 0, W, H), frame, W * 4, 0);
                    noSig.Visibility = Visibility.Collapsed;
                }
            }
            catch { stats.Text = "(peer not up)"; if (isA) { _curEnc = _curCc = _curLoss = 0; } }
        }

        // tiny text VU meter: N filled blocks where N = level (0..8) — the LENGTH shows loudness, no
        // empty track. Uses █ (Block-Elements, present in Consolas; the old ▮/▯ were missing → tofu).
        static string Bar(int mrms) { int n = mrms <= 0 ? 0 : Math.Min(8, mrms / 40); return new string('█', n); }

        Polyline MakeLine(Color c) { var p = new Polyline { Stroke = new SolidColorBrush(c), StrokeThickness = 1.5 }; Chart.Children.Add(p); return p; }
        void Chart_SizeChanged(object s, SizeChangedEventArgs e) => Redraw();
        static void Push(List<double> l, double v) { l.Add(v); if (l.Count > MaxPts) l.RemoveAt(0); }
        void SampleChart() { Push(_encH, _curEnc); Push(_ccH, _curCc); Push(_lossH, _curLoss); Redraw(); }
        void Redraw()
        {
            double w = Chart.ActualWidth, h = Chart.ActualHeight; if (w <= 1 || h <= 1) return;
            double maxK = 500; foreach (var v in _encH) if (v > maxK) maxK = v; foreach (var v in _ccH) if (v > maxK) maxK = v; maxK *= 1.15;
            ChartScale.Text = $"(0–{(int)maxK} kbps · 0–30% loss)";
            SetPts(_encLine, _encH, w, h, maxK);
            SetPts(_ccLine, _ccH, w, h, maxK);
            SetPts(_lossLine, _lossH, w, h, 30);
        }
        void SetPts(Polyline pl, List<double> hist, double w, double h, double maxV)
        {
            var pts = new PointCollection(); int n = hist.Count;
            for (int i = 0; i < n; i++) { double x = MaxPts <= 1 ? 0 : (double)i / (MaxPts - 1) * w; double y = h - 4 - Math.Min(1.0, hist[i] / maxV) * (h - 8); pts.Add(new Point(x, y)); }
            pl.Points = pts;
        }

        // Picking a source suggests the codec that fits it: screen -> AV1 (screen-content, sharp text),
        // camera -> H.264 (smooth motion at higher fps). The user can still override the codec after.
        void SourceCombo_Changed(object s, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (CodecCombo == null) return;   // SelectionChanged also fires during XAML init
            CodecCombo.SelectedIndex = SourceCombo.SelectedIndex == 1 ? 2 : 0;   // camera -> h264, screen -> av1
        }

        // Double-click a video panel to open it at NATIVE 1:1. The panels show a 1280-wide frame in
        // ~488 px, so their softness is mostly DISPLAY downscaling; this window shows the decoded frame
        // pixel-for-pixel (NearestNeighbor, no smoothing) so you can tell codec blur from scaling blur.
        // It shares the live WriteableBitmap, so it keeps updating as frames arrive. Wheel = zoom.
        void ZoomA(object s, System.Windows.Input.MouseButtonEventArgs e) { if (e.ClickCount == 2) ShowZoom(_wbA, "Peer A  ◀ Peer B's video"); }
        void ZoomB(object s, System.Windows.Input.MouseButtonEventArgs e) { if (e.ClickCount == 2) ShowZoom(_wbB, "Peer B  ◀ Peer A's video"); }

        void ShowZoom(WriteableBitmap wb, string who)
        {
            var img = new System.Windows.Controls.Image { Source = wb, Stretch = Stretch.None, SnapsToDevicePixels = true };
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.Fant);   // high-quality smoothing (clean when zoomed / DPI-scaled)
            var scale = new ScaleTransform(1, 1);
            img.LayoutTransform = scale;
            var sv = new System.Windows.Controls.ScrollViewer
            {
                HorizontalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Auto,
                VerticalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Auto,
                Background = Brushes.Black,
                Content = img
            };
            sv.PreviewMouseWheel += (o, ev) =>
            {
                double f = ev.Delta > 0 ? 1.25 : 0.8;
                scale.ScaleX = scale.ScaleY = Math.Max(0.25, Math.Min(8.0, scale.ScaleX * f));
                ev.Handled = true;
            };
            int pw = wb.PixelWidth, ph = wb.PixelHeight;
            new Window
            {
                Title = who + "   —   " + pw + "×" + ph + "   ·   1:1 (mouse wheel = zoom)",
                Width = Math.Min(pw + 40, 1500),
                Height = Math.Min(ph + 60, 950),
                Background = Brushes.Black,
                Content = sv,
                Owner = this
            }.Show();
        }

        // ===================== RAISR super-resolution tab =====================
        // Enumerate cameras by running `raisr_cam --list` (MediaFoundation lives in the C++ engine); always
        // append a synth option so the tab works without a camera.
        void RefreshCameras()
        {
            SrCamCombo.Items.Clear();
            try
            {
                string exe = System.IO.Path.Combine(ExeDir, "raisr_cam.exe");
                if (File.Exists(exe))
                {
                    var psi = new ProcessStartInfo { FileName = exe, Arguments = "--list", WorkingDirectory = ExeDir, UseShellExecute = false, RedirectStandardOutput = true, CreateNoWindow = true };
                    var p = Process.Start(psi);
                    string outp = p.StandardOutput.ReadToEnd(); p.WaitForExit(2500);
                    foreach (var line in outp.Split('\n')) { var t = line.Trim(); if (t.Length > 0) SrCamCombo.Items.Add(t); }
                }
            }
            catch { }
            SrCamCombo.Items.Add("(合成测试图 · 无需摄像头)");
            SrCamCombo.Items.Add("📁 图片文件…");
            if (SrCamCombo.SelectedIndex < 0) SrCamCombo.SelectedIndex = 0;
        }
        void SrRefresh_Click(object s, RoutedEventArgs e) => RefreshCameras();

        void SrStart_Click(object s, RoutedEventArgs e)
        {
            KillRaisr();
            string exe = System.IO.Path.Combine(ExeDir, "raisr_cam.exe");
            if (!File.Exists(exe)) { SrStatus.Text = "raisr_cam.exe 未找到 (" + ExeDir + ") — 请先构建 raisr_cam 目标"; return; }
            int resIdx = SrResCombo.SelectedIndex;
            int inW = resIdx == 0 ? 320 : resIdx == 2 ? 640 : 480, inH = resIdx == 0 ? 240 : resIdx == 2 ? 480 : 360;
            _srInW = inW; _srInH = inH; _srOw = inW * 2; _srOh = inH * 2;

            int camN = SrCamCombo.SelectedIndex, n = SrCamCombo.Items.Count;
            bool isImage = camN == n - 1, isSynth = camN == n - 2;
            string srcArg;
            if (isImage)   // pick an image; WPF decodes it (any format) and dumps raw BGRA for the engine
            {
                var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "图片 (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp|所有文件|*.*" };
                if (dlg.ShowDialog() != true) return;
                string raw; try { raw = SaveInputRaw(dlg.FileName); } catch (Exception ex) { SrStatus.Text = "图片加载失败:" + ex.Message; return; }
                srcArg = $"--image \"{raw}\""; _srSrcName = "图片 " + System.IO.Path.GetFileName(dlg.FileName);
            }
            else if (isSynth) { srcArg = "--synth"; _srSrcName = "合成图"; }
            else { srcArg = $"--camera {camN}"; _srSrcName = "摄像头 " + SrCamCombo.SelectedItem; }

            string args = $"{srcArg} --in-w {inW} --in-h {inH}";
            if (SrForceGpu.IsChecked == true) args += " --force-gpu";
            _raisrCam = Launch(exe, args);
            _wbSrL = _wbSrR = null;   // UpdateViewer (re)creates each at the size its selection needs
            SrLeft.Source = null; SrRight.Source = null;
            _srBuf = new byte[_srOw * _srOh * 4];   // sized for the largest (2x) view; reused for every read
            _srLastSeq = uint.MaxValue;
            SrNoLeft.Text = SrNoRight.Text = "等待帧…"; SrNoLeft.Visibility = SrNoRight.Visibility = Visibility.Visible;
            SrStartBtn.IsEnabled = false; SrStopBtn.IsEnabled = true;
            SrStatus.Text = $"运行中:{_srSrcName}   输入 {inW}×{inH} → 处理 {_srOw}×{_srOh}(每个窗口可独立选 原图 / Bilinear / RAISR;双击放大看细节)";
            _srTimer.Start();
        }

        void SrStop_Click(object s, RoutedEventArgs e)
        {
            _srTimer.Stop(); KillRaisr();
            SrStartBtn.IsEnabled = true; SrStopBtn.IsEnabled = false;
            SrStatus.Text = "已停止"; SrInfo.Text = "";
            SrNoLeft.Text = SrNoRight.Text = "未启动"; SrNoLeft.Visibility = SrNoRight.Visibility = Visibility.Visible;
        }
        void KillRaisr() { try { if (_raisrCam != null && !_raisrCam.HasExited) _raisrCam.Kill(); } catch { } }

        void SrTimer_Tick(object s, EventArgs e)
        {
            try
            {
                using var mmf = MemoryMappedFile.OpenExisting(RaisrMap, MemoryMappedFileRights.Read);
                using var a = mmf.CreateViewAccessor(0, 0, MemoryMappedFileAccess.Read);
                if (a.ReadUInt32(0) == 0) return;
                uint seq = a.ReadUInt32(8);
                int iw = a.ReadInt32(12), ih = a.ReadInt32(16), ow = a.ReadInt32(20), oh = a.ReadInt32(24), front = a.ReadInt32(52), fps10 = a.ReadInt32(28);
                int raisrOn = a.ReadInt32(36), gpuUs = a.ReadInt32(40);   // reserved[0]/[1]
                if (iw <= 0 || ow <= 0 || ow > kRW || oh > kRH || iw != _srInW || ih != _srInH || ow != _srOw || oh != _srOh) return;   // wait until dims match
                string path = gpuUs > 0 ? $"GPU {gpuUs / 1000.0:0.0}ms" : "CPU";
                string off = raisrOn == 0 ? "  ·  ⚠ RAISR 看门狗已关闭" : "";
                SrInfo.Text = $"{_srSrcName}  ·  {fps10 / 10.0:0.0} fps  ·  原图 {iw}×{ih} → {ow}×{oh}  ·  RAISR {path}{off}";
                if (seq == _srLastSeq) return;
                _srLastSeq = seq;
                UpdateViewer(SrViewLeft.SelectedIndex,  ref _wbSrL, SrLeft,  a, front, iw, ih, ow, oh);
                UpdateViewer(SrViewRight.SelectedIndex, ref _wbSrR, SrRight, a, front, iw, ih, ow, oh);
                SrNoLeft.Visibility = SrNoRight.Visibility = Visibility.Collapsed;
            }
            catch { SrInfo.Text = "(引擎未就绪)"; }
        }

        // a viewer shows one of the 3 buffers (0=orig @in-dims, 1=bilin @out, 2=raisr @out); (re)size its bitmap to match.
        void UpdateViewer(int sel, ref WriteableBitmap wb, System.Windows.Controls.Image img, MemoryMappedViewAccessor a, int front, int iw, int ih, int ow, int oh)
        {
            if (sel < 0) sel = 0;
            int w = sel == 0 ? iw : ow, h = sel == 0 ? ih : oh;
            long baseOff = sel == 0 ? OrigOff : sel == 1 ? BilinOff : RaisrOff;
            long off = baseOff + (long)(front & 1) * SrBuf;
            if (wb == null || wb.PixelWidth != w || wb.PixelHeight != h) { wb = new WriteableBitmap(w, h, 96, 96, PixelFormats.Bgra32, null); img.Source = wb; }
            a.ReadArray(off, _srBuf, 0, w * h * 4);
            wb.WritePixels(new Int32Rect(0, 0, w, h), _srBuf, w * 4, 0);
        }
        void SrView_Changed(object s, System.Windows.Controls.SelectionChangedEventArgs e) { _srLastSeq = uint.MaxValue; }   // force a redraw next tick

        // decode any image (PNG/JPG/BMP) to BGRA and write a raw {int32 w, int32 h, BGRA...} the engine reads via --image.
        string SaveInputRaw(string imagePath)
        {
            var bmp = new BitmapImage();
            bmp.BeginInit(); bmp.CacheOption = BitmapCacheOption.OnLoad; bmp.UriSource = new Uri(imagePath); bmp.EndInit();
            var conv = new FormatConvertedBitmap(bmp, PixelFormats.Bgra32, null, 0);
            int w = conv.PixelWidth, h = conv.PixelHeight;
            var px = new byte[w * h * 4]; conv.CopyPixels(px, w * 4, 0);
            string raw = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "avp_raisr_input.raw");
            using (var bw = new BinaryWriter(new FileStream(raw, FileMode.Create))) { bw.Write(w); bw.Write(h); bw.Write(px); }
            return raw;
        }

        void SrZoomLeft(object s, System.Windows.Input.MouseButtonEventArgs e) { if (e.ClickCount == 2 && _wbSrL != null) ShowZoom(_wbSrL, "输入 · Bilinear ×2"); }
        void SrZoomRight(object s, System.Windows.Input.MouseButtonEventArgs e) { if (e.ClickCount == 2 && _wbSrR != null) ShowZoom(_wbSrR, "RAISR 超分 ×2"); }
    }
}
