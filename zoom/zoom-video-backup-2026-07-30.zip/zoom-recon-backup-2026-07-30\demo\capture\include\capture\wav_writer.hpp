// wav_writer.hpp — minimal RIFF/WAVE writer so captured audio is audible/inspectable.
// Handles both PCM (integer) and IEEE-float sample formats via the format tag.
#pragma once
#include "audio_frame.hpp"
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace avp {

inline void wav_put32(std::vector<uint8_t>& b, uint32_t v) { for (int i = 0; i < 4; ++i) b.push_back((v >> (8 * i)) & 0xFF); }
inline void wav_put16(std::vector<uint8_t>& b, uint16_t v) { b.push_back(v & 0xFF); b.push_back((v >> 8) & 0xFF); }
inline void wav_puts(std::vector<uint8_t>& b, const char* s) { for (int i = 0; i < 4; ++i) b.push_back((uint8_t)s[i]); }

// Write interleaved `pcm` (already in `fmt`) to a .wav file. Returns false on I/O failure.
inline bool write_wav(const std::string& path, const AudioFormat& fmt, const std::vector<uint8_t>& pcm) {
  const uint16_t tag = fmt.is_float ? 3 /*WAVE_FORMAT_IEEE_FLOAT*/ : 1 /*WAVE_FORMAT_PCM*/;
  const uint16_t block_align = (uint16_t)(fmt.channels * (fmt.bits / 8));
  const uint32_t byte_rate = (uint32_t)fmt.sample_rate * block_align;
  std::vector<uint8_t> h;
  wav_puts(h, "RIFF"); wav_put32(h, 36 + (uint32_t)pcm.size()); wav_puts(h, "WAVE");
  wav_puts(h, "fmt "); wav_put32(h, 16); wav_put16(h, tag); wav_put16(h, (uint16_t)fmt.channels);
  wav_put32(h, (uint32_t)fmt.sample_rate); wav_put32(h, byte_rate); wav_put16(h, block_align); wav_put16(h, (uint16_t)fmt.bits);
  wav_puts(h, "data"); wav_put32(h, (uint32_t)pcm.size());

  FILE* f = nullptr;
#ifdef _WIN32
  fopen_s(&f, path.c_str(), "wb");
#else
  f = fopen(path.c_str(), "wb");
#endif
  if (!f) return false;
  bool ok = fwrite(h.data(), 1, h.size(), f) == h.size() &&
            (pcm.empty() || fwrite(pcm.data(), 1, pcm.size(), f) == pcm.size());
  fclose(f);
  return ok;
}

}  // namespace avp
