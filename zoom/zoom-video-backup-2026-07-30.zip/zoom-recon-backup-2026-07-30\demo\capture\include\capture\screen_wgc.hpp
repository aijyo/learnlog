// screen_wgc.hpp — Windows.Graphics.Capture (WGC) screen capture, Zoom's PRIMARY backend on
// Windows 10 2004+. The OS composites the target and delivers GPU frames via a
// Direct3D11CaptureFramePool; we copy to a staging texture and hand out BGRA. Opt-in (needs
// cppwinrt) via AVP_WITH_WGC; the factory prefers it when built.
#pragma once
#include "video_source.hpp"
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <wrl/client.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <winrt/base.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Graphics.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <winrt/Windows.Graphics.DirectX.h>
#include <winrt/Windows.Graphics.DirectX.Direct3D11.h>
#include <thread>
#include <chrono>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "windowsapp.lib")

namespace avp {
namespace wgc  = winrt::Windows::Graphics::Capture;
namespace wgdx = winrt::Windows::Graphics::DirectX;

class WgcScreenSource : public IVideoSource {
public:
  bool open(const CaptureConfig& cfg) override {
    try {
      if (!wgc::GraphicsCaptureSession::IsSupported()) return false;
      try { winrt::init_apartment(winrt::apartment_type::multi_threaded); } catch (...) {}

      UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
      if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags, nullptr, 0,
                                   D3D11_SDK_VERSION, dev_.GetAddressOf(), nullptr, ctx_.GetAddressOf()))) return false;
      Microsoft::WRL::ComPtr<IDXGIDevice> dxgi;
      if (FAILED(dev_.As(&dxgi))) return false;
      winrt::com_ptr<::IInspectable> insp;
      if (FAILED(CreateDirect3D11DeviceFromDXGIDevice(dxgi.Get(), insp.put()))) return false;
      rtDevice_ = insp.as<wgdx::Direct3D11::IDirect3DDevice>();

      HMONITOR mon = MonitorFromPoint(POINT{0, 0}, MONITOR_DEFAULTTOPRIMARY);
      auto interop = winrt::get_activation_factory<wgc::GraphicsCaptureItem, ::IGraphicsCaptureItemInterop>();
      winrt::check_hresult(interop->CreateForMonitor(mon, winrt::guid_of<wgc::GraphicsCaptureItem>(), winrt::put_abi(item_)));

      auto size = item_.Size();
      w_ = size.Width; h_ = size.Height;
      pool_ = wgc::Direct3D11CaptureFramePool::Create(rtDevice_, wgdx::DirectXPixelFormat::B8G8R8A8UIntNormalized, 2, size);
      session_ = pool_.CreateCaptureSession(item_);
      try { session_.IsCursorCaptureEnabled(cfg.capture_cursor); } catch (...) {}
      session_.StartCapture();
      return w_ > 0 && h_ > 0;
    } catch (...) { return false; }
  }

  bool grab(VideoFrame& out) override {
    if (!pool_) return false;
    wgc::Direct3D11CaptureFrame frame{nullptr};
    for (int i = 0; i < 200 && !frame; ++i) {
      frame = pool_.TryGetNextFrame();
      if (!frame) std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    if (!frame) { if (last_.valid()) { out = last_; return true; } return false; }
    auto access = frame.Surface().as<::Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();
    Microsoft::WRL::ComPtr<ID3D11Texture2D> tex;
    if (FAILED(access->GetInterface(IID_PPV_ARGS(tex.GetAddressOf())))) return false;
    ensure_staging_(tex.Get());
    bool ok = false;
    if (staging_) {
      ctx_->CopyResource(staging_.Get(), tex.Get());
      D3D11_MAPPED_SUBRESOURCE map{};
      if (SUCCEEDED(ctx_->Map(staging_.Get(), 0, D3D11_MAP_READ, 0, &map))) {
        out.width = w_; out.height = h_; out.stride = w_ * 4; out.format = PixelFormat::BGRA; out.timestamp_us = now_us();
        out.data.resize((size_t)out.stride * h_);
        for (int y = 0; y < h_; ++y) memcpy(&out.data[(size_t)y * out.stride], (const uint8_t*)map.pData + (size_t)y * map.RowPitch, out.stride);
        ctx_->Unmap(staging_.Get(), 0);
        last_ = out; ok = true;
      }
    }
    return ok;
  }
  void close() override {
    if (session_) { session_.Close(); session_ = nullptr; }
    if (pool_) { pool_.Close(); pool_ = nullptr; }
    item_ = nullptr; staging_.Reset(); ctx_.Reset(); dev_.Reset();
  }
  const char* backend() const override { return "WGC-GraphicsCapture"; }
  int width() const override { return w_; }
  int height() const override { return h_; }
private:
  void ensure_staging_(ID3D11Texture2D* src) {
    if (staging_) return;
    D3D11_TEXTURE2D_DESC d{}; src->GetDesc(&d);
    d.Usage = D3D11_USAGE_STAGING; d.BindFlags = 0; d.MiscFlags = 0; d.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    dev_->CreateTexture2D(&d, nullptr, staging_.GetAddressOf());
  }
  static int64_t now_us() { LARGE_INTEGER f, c; QueryPerformanceFrequency(&f); QueryPerformanceCounter(&c); return c.QuadPart * 1000000 / f.QuadPart; }

  Microsoft::WRL::ComPtr<ID3D11Device> dev_;
  Microsoft::WRL::ComPtr<ID3D11DeviceContext> ctx_;
  Microsoft::WRL::ComPtr<ID3D11Texture2D> staging_;
  wgdx::Direct3D11::IDirect3DDevice rtDevice_{nullptr};
  wgc::GraphicsCaptureItem item_{nullptr};
  wgc::Direct3D11CaptureFramePool pool_{nullptr};
  wgc::GraphicsCaptureSession session_{nullptr};
  VideoFrame last_;
  int w_ = 0, h_ = 0;
};

}  // namespace avp
#endif
