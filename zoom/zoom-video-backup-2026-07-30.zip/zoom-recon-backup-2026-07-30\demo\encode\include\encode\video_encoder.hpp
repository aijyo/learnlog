// video_encoder.hpp — module 3 video-encode interface (AV_PIPELINE_DETAILS.html §3).
// Takes the preprocessed I420 frame + QP side-info from module 2 and produces a coded bitstream,
// under SVC layer control and the keyframe/reference request model (§3.2/§3.3). One interface;
// the real backend (h264_encoder.hpp) drives minih264.
#pragma once
#include "preprocess/video_convert.hpp"   // avp::I420Image
#include <cstdint>
#include <string>
#include <vector>

namespace avp {

enum class FrameType { IDR, I, P, Skipped };
inline const char* to_string(FrameType t) {
  switch (t) { case FrameType::IDR: return "IDR"; case FrameType::I: return "I";
               case FrameType::P: return "P"; default: return "skip"; }
}

struct EncodedFrame {
  std::vector<uint8_t> data;      // coded bitstream (H.264 Annex-B here)
  FrameType type = FrameType::P;
  int       temporal_id = 0;      // SVC temporal layer (0 = base)
  int       spatial_id = 0;       // SVC spatial layer
  int64_t   pts_us = 0;
  bool      droppable = false;    // top layer with no dependents — an SFU can drop it safely
  int       size() const { return (int)data.size(); }
  bool      keyframe() const { return type == FrameType::IDR || type == FrameType::I; }
};

struct VideoEncoderConfig {
  int   width = 0, height = 0;    // 0 = take from the first frame
  int   fps = 30;
  int   bitrate_bps = 1500000;
  int   gop = 60;                 // keyframe (random-access) period
  int   temporal_layers = 3;      // SVC temporal layers (dyadic ×0.5 cascade)
  bool  ltr = true;               // long-term reference (loss-resilient)
  bool  layered_refs = false;     // real droppable layered-reference structure (needs temporal_layers>=2)
};

struct IVideoEncoder {
  virtual ~IVideoEncoder() = default;
  virtual bool         open(const VideoEncoderConfig& cfg) = 0;
  virtual EncodedFrame encode(const I420Image& frame, bool force_key = false) = 0;
  virtual void         request_idr() = 0;                 // §3.3 forced IDR
  virtual void         request_key_recovery(int spatial) = 0;   // §3.3 LTR/key-picture recovery
  virtual void         set_bitrate(int bps) = 0;
  virtual const char*  codec() const = 0;
};

}  // namespace avp
