// video_convert.hpp — BGRA <-> I420/NV12 color conversion.
//
// Capture hands us packed BGRA (screen + camera). Every video encoder wants planar YUV
// (I420 = Y plane + half-res U,V; NV12 = Y + interleaved UV). This is a *real, necessary*
// preprocess step — and it is also what gives the denoise / adaptive-QP / RAISR stages a
// clean 8-bit luma (Y) plane to operate on. BT.601 limited-range coefficients (the RTC
// default for SD/HD camera video); swap to BT.709 for >=720p if you match the decoder.
#pragma once
#include "capture/video_frame.hpp"
#include <cstdint>
#include <vector>

namespace avp {

// Planar I420 image: Y (w*h) + U,V ((w/2)*(h/2) each). Chroma dims are ceil-half.
struct I420Image {
  int w = 0, h = 0;
  std::vector<uint8_t> y, u, v;
  bool keyframe = false;   // decoder sets: this frame is an intra/IDR = a clean recovery point (no prior-frame dep)
  bool corrupt  = false;   // decoder sets: it concealed errors (missing/lost reference) — output is mosaic, not to be shown
  int cw() const { return (w + 1) / 2; }
  int ch() const { return (h + 1) / 2; }
  bool valid() const { return w > 0 && h > 0 && y.size() == (size_t)w * h; }
};

namespace detail {
inline uint8_t clamp8(int v) { return (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v)); }
}

// BGRA -> I420 (BT.601 limited range). BGRA byte order is B,G,R,A (little-endian 0xAARRGGBB).
inline void BgraToI420(const VideoFrame& in, I420Image& out) {
  const int w = in.width, h = in.height, stride = in.stride ? in.stride : in.width * 4;
  out.w = w; out.h = h;
  out.y.assign((size_t)w * h, 0);
  const int cw = out.cw(), chh = out.ch();
  out.u.assign((size_t)cw * chh, 128);
  out.v.assign((size_t)cw * chh, 128);
  const uint8_t* src = in.data.data();

  // luma for every pixel
  for (int j = 0; j < h; ++j) {
    const uint8_t* row = src + (size_t)j * stride;
    for (int i = 0; i < w; ++i) {
      int B = row[i * 4 + 0], G = row[i * 4 + 1], R = row[i * 4 + 2];
      out.y[(size_t)j * w + i] = detail::clamp8((66 * R + 129 * G + 25 * B + 128 >> 8) + 16);
    }
  }
  // chroma: average each 2x2 block, then convert (subsampled)
  for (int j = 0; j < h; j += 2) {
    for (int i = 0; i < w; i += 2) {
      int sr = 0, sg = 0, sb = 0, n = 0;
      for (int dj = 0; dj < 2 && j + dj < h; ++dj)
        for (int di = 0; di < 2 && i + di < w; ++di) {
          const uint8_t* p = src + (size_t)(j + dj) * stride + (size_t)(i + di) * 4;
          sb += p[0]; sg += p[1]; sr += p[2]; ++n;
        }
      int R = sr / n, G = sg / n, B = sb / n;
      int u = (-38 * R - 74 * G + 112 * B + 128 >> 8) + 128;
      int v = (112 * R - 94 * G - 18 * B + 128 >> 8) + 128;
      size_t co = (size_t)(j / 2) * cw + (i / 2);
      out.u[co] = detail::clamp8(u);
      out.v[co] = detail::clamp8(v);
    }
  }
}

// I420 -> BGRA (BT.601 limited range) — for visualizing a preprocessed frame as a BMP.
inline void I420ToBgra(const I420Image& in, VideoFrame& out) {
  const int w = in.w, h = in.h, cw = in.cw();
  out.width = w; out.height = h; out.stride = w * 4; out.format = PixelFormat::BGRA;
  out.data.assign((size_t)w * h * 4, 0);
  for (int j = 0; j < h; ++j)
    for (int i = 0; i < w; ++i) {
      int Y = in.y[(size_t)j * w + i] - 16;
      int U = in.u[(size_t)(j / 2) * cw + (i / 2)] - 128;
      int V = in.v[(size_t)(j / 2) * cw + (i / 2)] - 128;
      int c = 298 * Y;
      uint8_t* p = &out.data[((size_t)j * w + i) * 4];
      p[0] = detail::clamp8(c + 516 * U + 128 >> 8);            // B
      p[1] = detail::clamp8(c - 100 * U - 208 * V + 128 >> 8);  // G
      p[2] = detail::clamp8(c + 409 * V + 128 >> 8);            // R
      p[3] = 255;
    }
}

}  // namespace avp
