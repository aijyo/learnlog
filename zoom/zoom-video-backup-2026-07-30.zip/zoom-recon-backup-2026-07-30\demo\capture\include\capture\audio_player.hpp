// audio_player.hpp — a streaming WASAPI render sink for LIVE playout (the receive side's speaker).
// Unlike audio_tone.hpp's blocking one-shot, this owns a fill thread that pulls mono float frames from a
// queue and writes them into the shared-mode render buffer continuously, emitting silence on underrun.
// Used by the conference's audio leg when --play is on (headphones recommended: on one box, speaker→mic
// is a real echo path — that's what the AEC far-end reference is for). Mono source is duplicated to the
// device's channel count; assumes the device runs at 48 kHz (the Opus/mix rate) — no resampling.
#pragma once
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <atomic>
#include <deque>
#include <mutex>
#include <thread>
#include <vector>
#pragma comment(lib, "ole32.lib")

namespace avp {

class StreamingAudioPlayer {
public:
  bool start() {
    co_ = SUCCEEDED(CoInitializeEx(nullptr, COINIT_MULTITHREADED));
    IMMDeviceEnumerator* en = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&en))) return false;
    HRESULT hr = en->GetDefaultAudioEndpoint(eRender, eConsole, &dev_); en->Release();
    if (FAILED(hr) || !dev_) return false;
    if (FAILED(dev_->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&client_))) return false;
    if (FAILED(client_->GetMixFormat(&mix_)) || !mix_) return false;
    ch_ = mix_->nChannels; sr_ = (int)mix_->nSamplesPerSec;
    is_float_ = (mix_->wFormatTag == WAVE_FORMAT_IEEE_FLOAT);
    if (mix_->wFormatTag == WAVE_FORMAT_EXTENSIBLE && mix_->cbSize >= 22)
      is_float_ = (reinterpret_cast<WAVEFORMATEXTENSIBLE*>(mix_)->SubFormat == KSDATAFORMAT_SUBTYPE_IEEE_FLOAT);
    if (FAILED(client_->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, 2000000, 0, mix_, nullptr))) return false;
    if (FAILED(client_->GetService(__uuidof(IAudioRenderClient), (void**)&render_))) return false;
    client_->GetBufferSize(&total_);
    client_->Start();
    run_ = true; th_ = std::thread([this] { fill_loop(); });
    return true;
  }
  // enqueue one mono frame (any length) at the device rate (48 kHz assumed)
  void push(const std::vector<float>& mono) {
    std::lock_guard<std::mutex> lk(m_);
    for (float v : mono) q_.push_back(v);
    if (q_.size() > (size_t)sr_) q_.erase(q_.begin(), q_.begin() + (q_.size() - sr_ / 2));  // cap ~1s, drop oldest
  }
  void stop() {
    run_ = false; if (th_.joinable()) th_.join();
    if (client_) client_->Stop();
    if (render_) render_->Release(); if (client_) client_->Release(); if (dev_) dev_->Release();
    if (mix_) CoTaskMemFree(mix_);
    render_ = nullptr; client_ = nullptr; dev_ = nullptr; mix_ = nullptr;
  }
  ~StreamingAudioPlayer() { stop(); if (co_) CoUninitialize(); }
  int rate() const { return sr_; }

private:
  float pop() { if (q_.empty()) return 0.f; float v = q_.front(); q_.pop_front(); return v; }
  void fill_loop() {
    while (run_) {
      UINT32 pad = 0; if (FAILED(client_->GetCurrentPadding(&pad))) break;
      UINT32 avail = total_ > pad ? total_ - pad : 0;
      if (avail == 0) { Sleep(3); continue; }
      BYTE* p = nullptr;
      if (FAILED(render_->GetBuffer(avail, &p))) { Sleep(3); continue; }
      { std::lock_guard<std::mutex> lk(m_);
        for (UINT32 i = 0; i < avail; ++i) { float s = pop();
          for (int c = 0; c < ch_; ++c) { if (is_float_) { *reinterpret_cast<float*>(p) = s; p += 4; } else { *reinterpret_cast<int16_t*>(p) = (int16_t)(s * 32767); p += 2; } } } }
      render_->ReleaseBuffer(avail, 0);
      Sleep(3);
    }
  }
  bool co_ = false; std::atomic<bool> run_{false}; std::thread th_;
  IMMDevice* dev_ = nullptr; IAudioClient* client_ = nullptr; IAudioRenderClient* render_ = nullptr; WAVEFORMATEX* mix_ = nullptr;
  UINT32 total_ = 0; int ch_ = 2, sr_ = 48000; bool is_float_ = true;
  std::mutex m_; std::deque<float> q_;
};

}  // namespace avp
#endif  // _WIN32
