import idc, ida_hexrays, ida_funcs
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
# dump qwords around the apply-interface vtable region to find sibling classifiers
lo, hi = 0x180527960, 0x180527A80
L.append("// vtable region 0x%x..0x%x:"%(lo,hi))
funcs=[]
ea=lo
while ea < hi:
    p = idc.get_qword(ea)
    nm = idc.get_func_name(p) if ida_funcs.get_func(p) else ""
    L.append("//  [0x%x] -> 0x%x %s"%(ea, p, nm))
    if ida_funcs.get_func(p) and p not in funcs: funcs.append(p)
    ea += 8
def decomp(ea):
    try:
        L.append("\n// ===== %s (0x%x) ====="%(idc.get_func_name(ea), ea))
        L.append(str(ida_hexrays.decompile(ea)))
    except Exception as e: L.append("// FAIL 0x%x: %s"%(ea,e))
# decompile the distinct classifiers found (skip the known TextureMotion sub_1800E7A00)
for f in funcs:
    if f != 0x1800E7A00:
        decomp(f)
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
