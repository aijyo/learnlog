// h264_encoder.hpp — the real H.264 backend for module 3. Drives minih264 (single-header, public-
// domain baseline encoder) through Zoom's reconstructed SVC control surface (zlt_svc_encoder.hpp +
// zlt_h264_backend.hpp), taking the preprocessed I420 frame from module 2 and emitting Annex-B.
//
// What is REAL here: the pixels->H.264 encode (minih264), the SetKeyPictureRequest control model
// (IDR / key-recovery / bitrate), and the dyadic temporal-id assignment used for SFU pruning.
// Honest boundary: H.264 *baseline* has no layered-reference structure, so temporal_id is a correct
// standard ANNOTATION on an IPPP stream (SFU pruning is demonstrated); making high layers truly
// droppable needs zlt's SVC reference structure, which the baseline encoder doesn't implement.
#pragma once
#define RECON_WITH_H264 1
#include "video_encoder.hpp"
#include "svc_layers.hpp"
#include "algo/zlt_svc_encoder.hpp"
#include "algo/zlt_h264_backend.hpp"
#include <cstdint>
#include <memory>
#include <vector>

namespace avp {

// Plans each frame's references for a real dyadic temporal-SVC structure (3 layers). LTR slot 1 holds
// the latest t0 anchor, slot 2 the latest t1 anchor; a t2 frame references the most recent t<=1 frame
// and is NOT saved (droppable), so dropping every t2 frame leaves the t0/t1 reference chains intact.
//   frame:  0(IDR)  1(t2)  2(t1)  3(t2)  4(t0)  5(t2)  6(t1)  7(t2) ...
struct RefPlan { int temporal_id; int ltr_use; int ltr_update; bool droppable; };

class LayeredRefScheduler {
public:
  // key_period: emit a fresh IDR (SPS+PPS+intra) every key_period frames, so a lost keyframe recovers
  // periodically instead of poisoning the whole stream (critical over lossy links with big keyframes).
  explicit LayeredRefScheduler(int layers = 3, int key_period = 1 << 30)
      : tl_{layers}, key_period_(key_period < 1 ? 1 : key_period) {}
  RefPlan next(uint64_t i) {
    int t = tl_.temporal_id(i), maxt = tl_.max_tid();
    RefPlan p{ t, 0, 0, false };
    if (i % (uint64_t)key_period_ == 0) { p.temporal_id = 0; p.ltr_use = -1; p.ltr_update = 1; last_le_lower_ = 1; }  // (periodic) IDR
    else if (t == 0)     { p.ltr_use = 1;  p.ltr_update = 1; last_le_lower_ = 1; }    // t0 anchor
    else if (t < maxt)   { p.ltr_use = last_le_lower_; p.ltr_update = t + 1; last_le_lower_ = t + 1; }  // mid layer
    else                 { p.ltr_use = last_le_lower_; p.ltr_update = -1; p.droppable = true; }         // top: droppable
    return p;
  }
private:
  TemporalLayering tl_;
  int last_le_lower_ = 1;   // LTR slot of the most recent frame at a layer <= the next top-layer frame's dependency
  int key_period_;
};

class H264Encoder : public IVideoEncoder {
public:
  bool open(const VideoEncoderConfig& cfg) override {
    cfg_ = cfg;
    layering_.layers = cfg.temporal_layers < 1 ? 1 : cfg.temporal_layers;

    recon::zlt::EncodeConfig ec; ec.spatial.resize(1);
    auto& L = ec.spatial[0];
    L.width = cfg.width; L.height = cfg.height; L.frame_rate = (float)cfg.fps;
    L.bitrate = cfg.bitrate_bps; L.ra_period = cfg.gop; L.ltr = cfg.ltr;
    L.temporal_layer_num = layering_.layers;
    control_.reset(new recon::zlt::SvcEncoderControl(&backend_));
    control_->SetMaxLayers(/*codec_type*/0, /*max_spatial*/4, /*max_temporal*/4);
    if (control_->SetEncodeConfig(ec) != 0) return false;
    layered_ = cfg.layered_refs && layering_.layers >= 2;
    // periodic IDR aligned to a t0 frame (multiple of 2^max_tid) so keyframes don't disturb the
    // dyadic structure; caps the "no keyframe yet" window on a lossy link.
    int kp = cfg.gop > 0 ? cfg.gop : 60; int step = 1 << layering_.max_tid(); kp = (kp / step) * step; if (kp < step) kp = step;
    sched_ = LayeredRefScheduler(layering_.layers, kp);
    if (!layered_) control_->Request(recon::zlt::RequestType::Idr, mk_args(0, 1));   // start on an IDR
    w_ = backend_.width(); h_ = backend_.height();
    index_ = 0;
    return w_ > 0 && h_ > 0;
  }

  EncodedFrame encode(const I420Image& img, bool force_key = false) override {
    EncodedFrame ef;
    ef.spatial_id = 0;
    ef.temporal_id = layering_.temporal_id(index_);
    ef.pts_us = cfg_.fps > 0 ? (int64_t)(index_ * 1000000 / cfg_.fps) : 0;

    std::vector<uint8_t> packed; pack_i420(img, packed);        // crop/pack to the encoder's w_ x h_
    std::vector<uint8_t> bs; int n;
    if (layered_) {                                             // real layered-reference structure
      RefPlan plan = sched_.next(index_);
      ef.temporal_id = plan.temporal_id; ef.droppable = plan.droppable;
      n = backend_.EncodeFrameCustom(packed.data(), w_, h_, plan.ltr_use, plan.ltr_update, bs);
    } else {
      if (force_key) control_->Request(recon::zlt::RequestType::Idr, mk_args(0, ++idr_num_));
      n = backend_.EncodeFrame(packed.data(), w_, h_, bs);
    }
    if (n <= 0) { ef.type = FrameType::Skipped; ++index_; return ef; }

    ef.data.swap(bs);
    ef.type = first_nal_is_idr(ef.data) ? FrameType::IDR : FrameType::P;
    ++index_;
    return ef;
  }

  void request_idr() override { if (control_) control_->Request(recon::zlt::RequestType::Idr, mk_args(0, ++idr_num_)); }
  void request_key_recovery(int spatial) override {
    if (control_) control_->Request(recon::zlt::RequestType::KeyPicture, mk_args(spatial, 0));
  }
  void set_bitrate(int bps) override { backend_.SetBitrateTarget((uint32_t)bps, 0); cfg_.bitrate_bps = bps; }
  const char* codec() const override { return "H.264/AVC (minih264, baseline)"; }

  int width() const { return w_; }
  int height() const { return h_; }
  const TemporalLayering& layering() const { return layering_; }

private:
  static recon::zlt::RequestArgs mk_args(int spatial, int num) {
    recon::zlt::RequestArgs a; a.spatial_index = spatial; a.request_number = num; return a;
  }
  static bool first_nal_is_idr(const std::vector<uint8_t>& bs) {
    for (size_t i = 0; i + 3 < bs.size(); ++i) {
      size_t hdr = 0;
      if (!bs[i] && !bs[i+1] && !bs[i+2] && bs[i+3] == 1) hdr = 4;
      else if (!bs[i] && !bs[i+1] && bs[i+2] == 1) hdr = 3;
      if (!hdr) continue;
      int t = bs[i + hdr] & 0x1F;
      if (t == 5) return true;          // IDR slice
      if (t == 1) return false;         // non-IDR slice
      i += hdr;                          // SPS/PPS/SEI -> keep scanning
    }
    return false;
  }
  // pack an avp::I420Image into a contiguous 16-aligned I420 buffer minih264 expects.
  void pack_i420(const I420Image& img, std::vector<uint8_t>& out) const {
    const int cw = w_ / 2, chh = h_ / 2;
    out.resize((size_t)w_ * h_ + 2 * (size_t)cw * chh);
    uint8_t* Y = out.data(); uint8_t* U = Y + (size_t)w_ * h_; uint8_t* V = U + (size_t)cw * chh;
    const int sy = img.w, scw = img.cw();
    for (int j = 0; j < h_; ++j) {
      int sj = j < img.h ? j : img.h - 1;
      for (int i = 0; i < w_; ++i) { int si = i < img.w ? i : img.w - 1; Y[(size_t)j * w_ + i] = img.y[(size_t)sj * sy + si]; }
    }
    for (int j = 0; j < chh; ++j) {
      int sj = j < img.ch() ? j : img.ch() - 1;
      for (int i = 0; i < cw; ++i) {
        int si = i < img.cw() ? i : img.cw() - 1;
        U[(size_t)j * cw + i] = img.u[(size_t)sj * scw + si];
        V[(size_t)j * cw + i] = img.v[(size_t)sj * scw + si];
      }
    }
  }

  VideoEncoderConfig cfg_;
  recon::zlt::H264Backend backend_;
  std::unique_ptr<recon::zlt::SvcEncoderControl> control_;
  TemporalLayering layering_;
  LayeredRefScheduler sched_{3};
  bool layered_ = false;
  uint64_t index_ = 0; int w_ = 0, h_ = 0, idr_num_ = 1;
};

}  // namespace avp
