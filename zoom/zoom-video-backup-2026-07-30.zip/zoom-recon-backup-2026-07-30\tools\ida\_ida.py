# generic decompiler: idc.ARGV[1]=out file, idc.ARGV[2..]=hex addresses to decompile (+callees for the first)
import idc, ida_hexrays, ida_funcs, idautils, ida_xref
out = idc.ARGV[1]
addrs = [int(a, 16) for a in idc.ARGV[2:]]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L = []
def decomp(ea, label):
    f = ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x (%s)" % (ea, label)); return None
    try:
        L.append("\n// ===== %s  %s  (0x%x) =====" % (label, idc.get_func_name(f.start_ea), f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e:
        L.append("// FAILED 0x%x: %s" % (ea, e))
    return f
for a in addrs:
    decomp(a, "target")
open(out, "w", encoding="utf-8", errors="replace").write("\n".join(L))
idc.qexit(0)
