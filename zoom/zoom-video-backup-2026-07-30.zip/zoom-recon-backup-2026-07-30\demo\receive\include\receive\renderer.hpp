// renderer.hpp — module 8 render / playout (AV_PIPELINE_DETAILS.html §8). Video: convert decoded
// I420 -> BGRA and write a BMP (a headless stand-in for a swap-chain present). Audio: accumulate PCM
// and write a WAV, with an optional real WASAPI render (play out the speakers) gated by AVP_PLAY.
#pragma once
#include "preprocess/video_convert.hpp"    // I420ToBgra
#include "capture/bmp_writer.hpp"          // write_bmp
#include "capture/wav_writer.hpp"          // write_wav
#include <cstdint>
#include <string>
#include <vector>

namespace avp {

class VideoRenderer {
public:
  bool present(const I420Image& f, const std::string& bmp_path) {
    VideoFrame bgra; I420ToBgra(f, bgra);
    ++count_;
    return write_bmp(bmp_path.c_str(), bgra);
  }
  int count() const { return count_; }
private:
  int count_ = 0;
};

class AudioRenderer {
public:
  void append(const std::vector<float>& mono) { pcm_.insert(pcm_.end(), mono.begin(), mono.end()); }
  size_t samples() const { return pcm_.size(); }
  bool save_wav(const std::string& path, int rate) {
    AudioFormat f; f.sample_rate = rate; f.channels = 1; f.bits = 32; f.is_float = true;
    return write_wav(path, f, to_bytes());
  }
  const std::vector<float>& pcm() const { return pcm_; }
private:
  std::vector<uint8_t> to_bytes() const {
    std::vector<uint8_t> b(pcm_.size() * 4); if (!pcm_.empty()) memcpy(b.data(), pcm_.data(), b.size()); return b;
  }
  std::vector<float> pcm_;
};

}  // namespace avp

// Optional real WASAPI playout (gated; the demo calls it only if AVP_PLAY is set, so automated runs
// stay silent). Mirrors capture/audio_tone.hpp's render loop, fed from a PCM buffer.
#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#pragma comment(lib, "ole32.lib")

namespace avp {
inline bool PlayPcmBlocking(const std::vector<float>& mono, int rate) {
  bool co = SUCCEEDED(CoInitializeEx(nullptr, COINIT_MULTITHREADED));
  bool ok = false;
  IMMDeviceEnumerator* en = nullptr; IMMDevice* dev = nullptr; IAudioClient* cl = nullptr;
  IAudioRenderClient* rc = nullptr; WAVEFORMATEX* mix = nullptr;
  do {
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&en))) break;
    if (FAILED(en->GetDefaultAudioEndpoint(eRender, eConsole, &dev)) || !dev) break;
    if (FAILED(dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&cl))) break;
    if (FAILED(cl->GetMixFormat(&mix)) || !mix) break;
    if (FAILED(cl->Initialize(AUDCLNT_SHAREMODE_SHARED, 0, 2000000, 0, mix, nullptr))) break;
    if (FAILED(cl->GetService(__uuidof(IAudioRenderClient), (void**)&rc))) break;
    UINT32 total = 0; cl->GetBufferSize(&total);
    int ch = mix->nChannels, sr = (int)mix->nSamplesPerSec; bool isflt = mix->wFormatTag == WAVE_FORMAT_IEEE_FLOAT
      || (mix->wFormatTag == WAVE_FORMAT_EXTENSIBLE && mix->cbSize >= 22 && ((WAVEFORMATEXTENSIBLE*)mix)->SubFormat == KSDATAFORMAT_SUBTYPE_IEEE_FLOAT);
    size_t pos = 0;
    auto fill = [&](BYTE* p, UINT32 frames) {
      for (UINT32 i = 0; i < frames; ++i) { float s = pos < mono.size() ? mono[pos++] : 0.f;
        for (int c = 0; c < ch; ++c) { if (isflt) { *(float*)p = s; p += 4; } else { *(int16_t*)p = (int16_t)(s * 32767); p += 2; } } }
    };
    BYTE* p; if (FAILED(rc->GetBuffer(total, &p))) break; fill(p, total); rc->ReleaseBuffer(total, 0);
    cl->Start();
    (void)sr;
    while (pos < mono.size()) { Sleep(10); UINT32 pad = 0; cl->GetCurrentPadding(&pad); UINT32 av = total - pad;
      if (av && SUCCEEDED(rc->GetBuffer(av, &p))) { fill(p, av); rc->ReleaseBuffer(av, 0); } }
    Sleep(200); cl->Stop(); ok = true;
  } while (false);
  if (mix) CoTaskMemFree(mix); if (rc) rc->Release(); if (cl) cl->Release();
  if (dev) dev->Release(); if (en) en->Release(); if (co) CoUninitialize();
  return ok;
}
}  // namespace avp
#endif  // _WIN32
