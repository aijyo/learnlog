// audio_encode_demo.cpp — module 3 audio encode. Two parts:
//   1) Zoom's codec-switching CONTROL surface (§3.5), body-verified, always available:
//      AI-codec 121 enable gate, the 0x4 control-word bit, the SNAC decode state machine, and the
//      SNAC-TCP→Opus reliable-fallback thresholds.
//   2) a REAL audio encoder (AVP_WITH_FFMPEG): FFmpeg's native AAC-LC encoding the preprocessed
//      audio from module 2 (mic_preprocessed.wav) — Opus/SNAC themselves are ⛔ boundaries (no libopus;
//      SNAC is neural weights), so AAC stands in to exercise the encode data path.
#include "encode/audio_encoder.hpp"
#include "preprocess/wav_reader.hpp"
#include <cmath>
#include <cstdio>
#include <vector>

using namespace avp;
using namespace recon::viper;

int main() {
  std::printf("=== AV pipeline / module 3: AUDIO encode ===\n\n");

  // ---- 1) codec-switching control surface (§3.5) ----
  std::printf("1) audio codec-switching control (viper, body-verified)\n");
  std::printf("   AI-codec 121 gate: main=113 ->%d(Ok)  main=100 ->%d(MainNotAllowed)  main=0 ->%d(NoMainCodec)  no-121 ->%d(NoCodec121)\n",
              AiCodecGate::PreflightEnable(113, true), AiCodecGate::PreflightEnable(100, true),
              AiCodecGate::PreflightEnable(0, true),   AiCodecGate::PreflightEnable(113, false));

  ControlWord cw; uint32_t store = 0;
  auto r1 = cw.Apply(store, 0x4);      // set bit 0x4 (extra AI/SNAC enc)
  auto r2 = cw.Apply(store, 0x4);      // no change
  auto r3 = cw.Apply(store, 0x0);      // clear
  std::printf("   control-word 0x4: extra_enc=%d changed=%d event44=%d | resend same: changed=%d | clear: extra_enc=%d changed=%d\n",
              r1.extra_enc, r1.changed, r1.fire_event44, r2.changed, r3.extra_enc, r3.changed);

  SnacDecodeControl sd;
  auto t1 = sd.EnableExtraSnacDecoding(true, 0x4, 0x71);   // kDisable -> kReady
  auto t2 = sd.EnableExtraSnacDecoding(false, 0x0, 0x71);  // kReady   -> kDisable
  std::printf("   SNAC decode SM: enable %d->%d (reg=%d) | disable %d->%d (dereg=%d)\n",
              t1.from, t1.to, t1.did_register, t2.from, t2.to, t2.did_deregister);

  int tsr = SnacTcpFallback::TsRange(48000 * 3, 0);        // 3 s window
  float loss = SnacTcpFallback::LossRate(100, 55);         // 45% loss
  std::printf("   SNAC-TCP fallback: udp_out=2500ms ts_range=%d loss=%.2f -> tierII engage=%d ; udp_out=1000ms -> engage=%d\n\n",
              tsr, loss,
              SnacTcpFallback::ShouldEngage(2500, tsr, loss, SnacTcpFallback::TierII),
              SnacTcpFallback::ShouldEngage(1000, tsr, loss, SnacTcpFallback::TierII));

  // ---- 2) real AAC encode of the preprocessed audio ----
#ifdef AVP_WITH_FFMPEG
  std::vector<float> mono; int rate = 48000;
  if (!read_wav_mono("mic_preprocessed.wav", mono, rate) && !read_wav_mono("mic_capture.wav", mono, rate)) {
    mono.resize(48000); for (size_t i = 0; i < mono.size(); ++i) mono[i] = 0.3f * std::sin(2 * 3.14159265f * 440 * i / rate);
    rate = 48000; std::printf("2) real AAC encode (no WAV found -> synthetic 440 Hz tone)\n");
  } else {
    std::printf("2) real AAC encode of module-2 output (%d Hz, %.2fs)\n", rate, (double)mono.size() / rate);
  }
  AacEncoder aac;
  if (aac.open(rate, 1, 64000)) {
    std::vector<EncodedAudio> pkts;
    aac.encode(mono.data(), (int)mono.size(), pkts);
    auto tail = aac.flush(); pkts.insert(pkts.end(), tail.begin(), tail.end());
    long coded = 0; for (auto& p : pkts) coded += p.size();
    long pcm_bytes = (long)mono.size() * 2;   // vs 16-bit PCM
    std::printf("   codec=%s frame=%d samples\n", aac.codec(), aac.frame_size());
    std::printf("   %zu packets, %ld bytes coded  vs  %ld bytes PCM16  ->  %.1fx compression\n\n",
                pkts.size(), coded, pcm_bytes, pcm_bytes / (double)(coded > 0 ? coded : 1));
  } else std::printf("   AAC encoder open failed\n\n");
#else
  std::printf("2) (build with -DAVP_WITH_FFMPEG=ON to also run the real AAC encoder on module-2 audio)\n\n");
#endif

  std::printf("DONE (audio: codec-switch control verified; AAC data path exercised where FFmpeg present)\n");
  return 0;
}
