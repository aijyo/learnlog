# Force full autoanalysis on a (re-opened) partial DB and save it. ARGV[1]=marker out.
import idc
idc.auto_wait()
idc.save_database(idc.get_idb_path(), 0)
open(idc.ARGV[1], "w").write("analyzed+saved: %s\n" % idc.get_idb_path())
idc.qexit(0)
