// [vendored into av-pipeline module 2 from bin2cpp-output/recon — verified
//  clean-room reconstruction, unchanged. Operates on raw 8-bit luma planes; the
//  module wrapper extracts the Y plane from an avp::VideoFrame and calls it.]
// zlt_raisr.hpp -- clean-room reconstruction of the RAISR super-resolution APPLY
// pipeline used by zlt.dll (ns_vpp/ns_glt/ns_gct: zltCScreenRAISR / zltCRaisr /
// gltD3D11ScreenRaisr / CGPUScreenRaisr ...) and nydus (CDrawFunc_D3d11_Raisr).
//
// RAISR (Intel, published) = "Rapid and Accurate Image Super-Resolution": cheaply
// upscale, then for each output pixel classify the local gradient into a bucket
// (angle x strength x coherence x pixel-type) and apply that bucket's PRE-LEARNED
// linear filter over a patch. The STRUCTURE (classify -> hashed filter -> blend) is
// code and is reconstructed here; the FILTER-BANK COEFFICIENTS are trained data
// (a WEIGHTS boundary) -- injected via IFilterBank, defaulting to a passthrough so
// the pipeline runs without the learned bank.
#pragma once
#include <cstdint>
#include <vector>
#include <cmath>
#include <cstddef>

namespace recon::zlt {

struct RaisrConfig {
    int scale        = 2;    // 2x
    int patch        = 11;   // odd patch side used for classification + filtering
    int angle_bins   = 24;
    int strength_bins= 3;
    int coherence_bins = 3;
    int Buckets() const { return angle_bins * strength_bins * coherence_bins; }
};

// Learned filter bank: bucket -> (patch*patch) linear filter. Boundary (weights).
struct IFilterBank {
    virtual ~IFilterBank() = default;
    // Returns patch*patch coefficients for `bucket`, or nullptr to use passthrough.
    virtual const float* filter(int bucket) const = 0;
    virtual int patch() const = 0;
};

// Default bank: no learned coefficients -> returns nullptr -> passthrough (bilinear).
struct PassthroughFilterBank : IFilterBank {
    int p; explicit PassthroughFilterBank(int patch = 11) : p(patch) {}
    const float* filter(int) const override { return nullptr; }
    int patch() const override { return p; }
};

class RaisrUpscaler {
public:
    RaisrUpscaler(RaisrConfig cfg, const IFilterBank* bank)
        : cfg_(cfg), bank_(bank) {}

    // in: w*h 8-bit luma; out: (w*scale)*(h*scale). Returns out dims via ow/oh.
    void Upscale(const uint8_t* in, int w, int h,
                 std::vector<uint8_t>& out, int& ow, int& oh) const {
        const int s = cfg_.scale;
        ow = w * s; oh = h * s;
        out.assign((size_t)ow * oh, 0);
        // 1) cheap base upscale (bilinear) -- RAISR refines on top of this
        for (int oy = 0; oy < oh; ++oy) {
            float fy = (oy + 0.5f) / s - 0.5f; int y0 = (int)std::floor(fy); float wy = fy - y0;
            for (int ox = 0; ox < ow; ++ox) {
                float fx = (ox + 0.5f) / s - 0.5f; int x0 = (int)std::floor(fx); float wx = fx - x0;
                out[(size_t)oy * ow + ox] = uint8_t(bilerp(in, w, h, x0, y0, wx, wy) + 0.5f);
            }
        }
        // 2) per-pixel gradient bucket -> learned filter (if any)
        if (!bank_) return;
        const int p = bank_->patch(), r = p / 2;
        std::vector<uint8_t> base = out;   // classify+filter over the base upscale
        for (int oy = r; oy < oh - r; ++oy)
            for (int ox = r; ox < ow - r; ++ox) {
                int bucket = Classify(base.data(), ow, oh, ox, oy);
                const float* f = bank_->filter(bucket);
                if (!f) continue;                    // no learned filter -> keep bilinear
                float acc = 0;
                for (int j = -r, k = 0; j <= r; ++j)
                    for (int i = -r; i <= r; ++i, ++k)
                        acc += f[k] * base[(size_t)(oy + j) * ow + (ox + i)];
                int v = int(acc + 0.5f); v = v < 0 ? 0 : (v > 255 ? 255 : v);
                out[(size_t)oy * ow + ox] = uint8_t(v);
            }
    }

    // Gradient hash: angle (structure tensor) x strength x coherence -> bucket.
    int Classify(const uint8_t* img, int w, int h, int cx, int cy) const {
        const int r = cfg_.patch / 2;
        double gxx = 0, gyy = 0, gxy = 0;
        for (int j = -r; j <= r; ++j)
            for (int i = -r; i <= r; ++i) {
                int x = cx + i, y = cy + j;
                if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
                double gx = double(img[(size_t)y * w + (x + 1)]) - img[(size_t)y * w + (x - 1)];
                double gy = double(img[(size_t)(y + 1) * w + x]) - img[(size_t)(y - 1) * w + x];
                gxx += gx * gx; gyy += gy * gy; gxy += gx * gy;
            }
        double t = gxx + gyy;
        double d = std::sqrt((gxx - gyy) * (gxx - gyy) + 4 * gxy * gxy);
        double l1 = (t + d) / 2, l2 = (t - d) / 2;
        double angle = 0.5 * std::atan2(2 * gxy, gxx - gyy);      // dominant orientation
        if (angle < 0) angle += 3.14159265358979;
        double strength = std::sqrt(l1);
        double coherence = (l1 + l2 > 1e-9) ? (std::sqrt(l1) - std::sqrt(l2)) / (std::sqrt(l1) + std::sqrt(l2)) : 0;

        int a = int(angle / 3.14159265358979 * cfg_.angle_bins); if (a >= cfg_.angle_bins) a = cfg_.angle_bins - 1;
        int st = strength  < 20 ? 0 : (strength  < 60 ? 1 : 2); if (st >= cfg_.strength_bins) st = cfg_.strength_bins - 1;
        int co = coherence < 0.25 ? 0 : (coherence < 0.5 ? 1 : 2); if (co >= cfg_.coherence_bins) co = cfg_.coherence_bins - 1;
        return (a * cfg_.strength_bins + st) * cfg_.coherence_bins + co;
    }

private:
    static float bilerp(const uint8_t* in, int w, int h, int x0, int y0, float wx, float wy) {
        auto at = [&](int x, int y) -> float {
            x = x < 0 ? 0 : (x >= w ? w - 1 : x); y = y < 0 ? 0 : (y >= h ? h - 1 : y);
            return in[(size_t)y * w + x];
        };
        float a = at(x0, y0) * (1 - wx) + at(x0 + 1, y0) * wx;
        float b = at(x0, y0 + 1) * (1 - wx) + at(x0 + 1, y0 + 1) * wx;
        return a * (1 - wy) + b * wy;
    }
    RaisrConfig cfg_;
    const IFilterBank* bank_;
};

} // namespace recon::zlt
