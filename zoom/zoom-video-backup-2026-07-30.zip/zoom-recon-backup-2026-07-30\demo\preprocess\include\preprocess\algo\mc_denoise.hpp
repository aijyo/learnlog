// mc_denoise.hpp — motion-ADAPTIVE spatial-temporal luma denoise (ghost-free), the classic-DSP answer to
// the trailing that a plain temporal IIR leaves. Grounded in the zlt findings: the body-verified
// zltCIIRDenoise (sub_1802A5260) is a pure EWMA out = 0.37*in + 0.63*prev with NO motion compensation —
// so it trails on motion (Zoom §2.2 admits "快速运动边缘拖尾"); Zoom's ghost-free denoise is the neural
// EDNet (⛔ weights boundary). This is the standard non-neural way to get temporal denoising WITHOUT
// ghosting: detect motion per block (SAD vs the previous *input* frame), then
//   static block  -> temporal IIR (α=0.37) : strong noise kill, no ghost (nothing is moving there)
//   moving block   -> spatial 3x3 average    : still denoises, but pulls in NO history -> no trail
// with a soft blend across the transition, and the recursive state refreshed to the output so a moving
// region never leaves a lingering ghost into later frames. Keeps the verified 0.37 for the static path.
#pragma once
#include <cstdint>
#include <vector>
#include <cstdlib>

namespace avp {

class MotionAdaptiveDenoiser {
public:
  struct Config {
    float alpha       = 0.37f;   // temporal EWMA weight on the current frame (verified zlt value)
    int   block       = 16;      // motion-detection block size
    int   static_sad  = 3;       // per-pixel mean |Δ| below this = static (full temporal)
    int   motion_sad  = 12;      // above this = full motion (full spatial); linear blend between
  };

  explicit MotionAdaptiveDenoiser(Config c = {}) : c_(c) {}
  void Reset() { first_ = true; }

  // Denoise one luma plane in place-ish: reads `in` (w*h), writes `out` (w*h).
  void Filter(const uint8_t* in, uint8_t* out, int w, int h) {
    const size_t n = (size_t)w * h;
    if (state_.size() != n) { state_.assign(n, 0); prev_in_.assign(n, 0); first_ = true; }
    if (first_) {
      for (size_t i = 0; i < n; ++i) { out[i] = in[i]; state_[i] = in[i]; prev_in_[i] = in[i]; }
      first_ = false; return;
    }
    const int bs = c_.block, bw = (w + bs - 1) / bs, bh = (h + bs - 1) / bs;
    motion_.assign((size_t)bw * bh, 0.f);
    // 1) per-block motion = mean |current - previous INPUT| (true scene motion, not filtered history)
    for (int by = 0; by < bh; ++by) for (int bx = 0; bx < bw; ++bx) {
      long sad = 0; int cnt = 0;
      int y1 = (by + 1) * bs < h ? (by + 1) * bs : h, x1 = (bx + 1) * bs < w ? (bx + 1) * bs : w;
      for (int y = by * bs; y < y1; ++y) { const uint8_t* r = in + (size_t)y * w; const uint8_t* p = prev_in_.data() + (size_t)y * w;
        for (int x = bx * bs; x < x1; ++x) { sad += std::abs((int)r[x] - (int)p[x]); ++cnt; } }
      motion_[(size_t)by * bw + bx] = cnt ? (float)sad / cnt : 0.f;
    }
    // 2) per-pixel: blend temporal (static) and spatial (moving) by the block's motion weight.
    const float a = c_.alpha, b = 1.0f - c_.alpha;
    for (int y = 0; y < h; ++y) {
      for (int x = 0; x < w; ++x) {
        size_t i = (size_t)y * w + x;
        float m = motion_[(size_t)(y / bs) * bw + (x / bs)];
        // temporal weight w_t: 1 when static, 0 when fully moving, linear between the thresholds
        float wt = m <= c_.static_sad ? 1.f : m >= c_.motion_sad ? 0.f
                 : 1.f - (m - c_.static_sad) / float(c_.motion_sad - c_.static_sad);
        int cur = in[i];
        int temporal = int(a * cur + b * state_[i] + 0.5f);   // ghost-free ONLY where static
        int spatial;
        if (wt >= 0.999f) spatial = cur;                       // pure static -> skip spatial work
        else {                                                  // 3x3 box average (denoise w/o history)
          int s = 0, cnt = 0;
          for (int dy = -1; dy <= 1; ++dy) { int yy = y + dy; if (yy < 0 || yy >= h) continue;
            const uint8_t* r = in + (size_t)yy * w;
            for (int dx = -1; dx <= 1; ++dx) { int xx = x + dx; if (xx < 0 || xx >= w) continue; s += r[xx]; ++cnt; } }
          spatial = cnt ? (s + cnt / 2) / cnt : cur;
        }
        int v = int(wt * temporal + (1.f - wt) * spatial + 0.5f);
        if (v < 0) v = 0; else if (v > 255) v = 255;
        out[i] = (uint8_t)v;
        state_[i] = (uint8_t)v;    // recursive state = output; moving regions refresh to ~current (no lingering ghost)
      }
    }
    // 3) remember this frame's INPUT for next frame's motion detection
    for (size_t i = 0; i < n; ++i) prev_in_[i] = in[i];
  }

private:
  Config c_;
  std::vector<uint8_t> state_, prev_in_;
  std::vector<float> motion_;
  bool first_ = true;
};

}  // namespace avp
