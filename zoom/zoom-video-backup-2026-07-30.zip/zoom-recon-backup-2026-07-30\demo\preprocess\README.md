# Module 2 — preprocess

The encoder-side stage from `AV_PIPELINE_DETAILS.html §2`: **perceptual enhancement + entropy reduction**
before the codec. Video and audio each get their own chain, wired to the verified algorithms.

```
capture BGRA ─► BGRA→I420 ─► IIR denoise (Y, α=0.37) ─► adaptive-QP hint ─► [RAISR] ─► I420 + QP map ─► encoder
mic + loopback ─► AEC (NLMS) ─► ANS (spectral subtraction) ─► AGC ─► 20 ms frames ─► encoder
```

## Video (`video_preprocess.hpp`)

| stage | file | Zoom mapping (§2) | boundary |
|---|---|---|---|
| BGRA → I420 / NV12 | `video_convert.hpp` | necessary color step (capture is BGRA, codecs want planar YUV) | real |
| temporal IIR denoise | `algo/zlt_denoise.hpp` | `zltCIIRDenoise`, α=0.37 (`out=0.37·in+0.63·prev`) | real, verified |
| adaptive-QP hint map | `algo/zlt_adaptive_qp.hpp` | `zltCTextureMotionAdaptQuant`, 6-threshold ladder, ±3 | real, verified |
| RAISR super-res | `algo/zlt_raisr.hpp` | `zltCScreenRAISR` (classify → hashed filter → blend) | structure real; **filter bank = ⛔ weights** |

The three `algo/*.hpp` are **vendored unchanged** from the `bin2cpp-output` clean-room reconstruction
(body-verified against `zlt.dll`); `video_preprocess.hpp` adapts them to `avp::VideoFrame` and produces
a per-block **QP-delta map** as *side information* for the encoder (module 3) — preprocess advises, it
doesn't quantize. The QP map is the reason screen-share switches to "screen content mode" (§3.4): text
is high-texture but must stay sharp, so it must not be treated as a "compressible" busy region.

## Audio — classic "3A" (`audio_preprocess.hpp`)

| stage | technique | boundary |
|---|---|---|
| **AEC** echo cancel | NLMS adaptive filter driven by the far-end (loopback) reference | real |
| **ANS** noise suppress | STFT spectral subtraction (Hann, 50 % hop, per-bin VAD noise floor) | real |
| **AGC** gain control | RMS-target with attack/release + limiter | real |
| framing | fixed 10 / 20 ms frames for the codec | real |
| AI background denoise / DRED | neural (Opus DRED, AI denoise) | **⛔ weights** — `INeuralDenoiser` injection hook |

Zoom's §2 audio note lists **DRED** (neural PLC inside the Opus build) and **AI background denoise** —
those are trained-weight boundaries. The classic 3A here is real, runnable DSP; inject a real model via
`INeuralDenoiser` to replace the spectral-subtraction ANS.

## Build & run
```powershell
cmake -S . -B build -DAVP_WITH_WGC=ON
cmake --build build --config Release
.\build\preprocess\Release\video_preproc_demo.exe   # denoise / adaptive-QP / RAISR
.\build\preprocess\Release\audio_preproc_demo.exe   # AEC / ANS / AGC
```
Both demos run controlled synthetic tests with known ground truth (so the numbers are verifiable), and
also process the real artifacts module 1 produced (`capture_frame0.bmp`, `mic_capture.wav`) if present.

## Verified (this machine)
```
VIDEO
  temporal IIR denoise (α=0.37)   luma error 10.15 -> 4.55        55% noise removed
  adaptive-QP (TextureMotion)     flat/static -6.00  vs  busy/moving +4.00   (coarser QP on busy)
  RAISR apply                     128x128 -> 256x256, synthetic bank changes pixels (structure runs)
  real frame                      capture_frame0.bmp 640x360 -> preproc_frame0.bmp
AUDIO (3A)
  AEC  (NLMS, 256 taps)           ERLE = 18.5 dB echo reduction
  ANS  (spectral subtraction)     noise floor -23.2 -> -44.2 dBFS (21 dB), tone kept 94%
  AGC  (target -18 dBFS)          -33.5 -> -19.8 dBFS
  real audio                      mic_capture.wav -> ANS+AGC -> mic_preprocessed.wav, 148 x 20 ms frames
```
Honesty note: ANS raises the *noise-floor* by 21 dB but the tone-region SNR is nearly flat — magnitude
subtraction can't remove broadband noise sitting inside the tone's own FFT bins without damaging the
tone, so the floor-attenuation number is the meaningful one. RAISR uses a passthrough (and a synthetic
sharpening) bank; the real perceptual gain needs Zoom's trained filter bank, which is a weights boundary.

## Architecture
```
avp::VideoPreprocessor(cfg)  -> Process(VideoFrame bgra, VideoPreprocessResult&)
   { I420 frame, qp_delta[], qp_mean, sr_y[] }          (video_preprocess.hpp)
avp::AudioPreprocessor(cfg)  -> Process(mic, ref, rate, &frames) -> processed mono
   EchoCanceller / NoiseSuppressor / AutomaticGainControl   (audio_preprocess.hpp)
```
Clean-room, following Zoom's *design* (not its code). Neural weights and trained banks are boundaries.
For interop / education.
