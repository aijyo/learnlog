// audio_decoder.hpp — module 7 audio decode (AV_PIPELINE_DETAILS.html §7). Decodes the AAC packets
// module 3 produced back to PCM via FFmpeg (AVP_WITH_FFMPEG). Needs the encoder's extradata
// (AudioSpecificConfig) to know the stream config — the demo passes it across, closing the audio loop.
// (Zoom's real audio codec is Opus/SNAC; AAC stands in here — no libopus, SNAC = neural weights.)
#pragma once
#ifdef AVP_WITH_FFMPEG
#include <cstdint>
#include <vector>
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/channel_layout.h>
#include <libavutil/samplefmt.h>
}

namespace avp {

class AacDecoder {
public:
  ~AacDecoder() { if (c_) avcodec_free_context(&c_); }
  bool open(const uint8_t* extradata, int ex_len, int sample_rate, int channels) {
    const AVCodec* dec = avcodec_find_decoder(AV_CODEC_ID_AAC);
    if (!dec) return false;
    c_ = avcodec_alloc_context3(dec);
    c_->sample_rate = sample_rate;
    av_channel_layout_default(&c_->ch_layout, channels);
    if (extradata && ex_len > 0) {
      c_->extradata = (uint8_t*)av_mallocz(ex_len + AV_INPUT_BUFFER_PADDING_SIZE);
      memcpy(c_->extradata, extradata, ex_len); c_->extradata_size = ex_len;
    }
    return avcodec_open2(c_, dec, nullptr) == 0;
  }
  // decode one AAC packet, appending mono float samples to `mono`.
  bool decode(const uint8_t* data, int len, std::vector<float>& mono) {
    std::vector<uint8_t> padded(data, data + len); padded.resize(len + AV_INPUT_BUFFER_PADDING_SIZE, 0);
    AVPacket* pkt = av_packet_alloc(); pkt->data = padded.data(); pkt->size = len;
    AVFrame* f = av_frame_alloc();
    bool any = false;
    if (avcodec_send_packet(c_, pkt) == 0) {
      while (avcodec_receive_frame(c_, f) == 0) {
        int ch = f->ch_layout.nb_channels, n = f->nb_samples; any = true;
        bool planar = av_sample_fmt_is_planar((AVSampleFormat)f->format);
        for (int i = 0; i < n; ++i) {
          float acc = 0;
          for (int c = 0; c < ch; ++c) acc += sample_at(f, c, i, planar);
          mono.push_back(acc / (ch ? ch : 1));
        }
      }
    }
    av_frame_free(&f); av_packet_free(&pkt);
    return any;
  }
  int sample_rate() const { return c_ ? c_->sample_rate : 0; }
private:
  static float sample_at(AVFrame* f, int ch, int i, bool planar) {
    AVSampleFormat fmt = (AVSampleFormat)f->format;
    const uint8_t* base = planar ? f->data[ch] : f->data[0];
    int idx = planar ? i : i * f->ch_layout.nb_channels + ch;
    switch (fmt) {
      case AV_SAMPLE_FMT_FLTP: case AV_SAMPLE_FMT_FLT: return ((const float*)base)[idx];
      case AV_SAMPLE_FMT_S16P: case AV_SAMPLE_FMT_S16: return ((const int16_t*)base)[idx] / 32768.0f;
      case AV_SAMPLE_FMT_S32P: case AV_SAMPLE_FMT_S32: return ((const int32_t*)base)[idx] / 2147483648.0f;
      default: return 0.f;
    }
  }
  AVCodecContext* c_ = nullptr;
};

}  // namespace avp
#endif  // AVP_WITH_FFMPEG
