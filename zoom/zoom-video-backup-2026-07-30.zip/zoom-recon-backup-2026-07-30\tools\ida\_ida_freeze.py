import idc, ida_hexrays, ida_funcs
out=idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L=[]
def d(ea,label):
    f=ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x %s"%(ea,label)); return
    try:
        L.append("\n// ===== %s %s (0x%x) ====="%(label,idc.get_func_name(f.start_ea),f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e: L.append("// FAIL 0x%x: %s"%(ea,e))
d(0x1800568F0,"CVideoRepeater")       # cache/repeat last frame
d(0x180074B74,"FrameAdapter")         # clock-driven frame pull/present
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
