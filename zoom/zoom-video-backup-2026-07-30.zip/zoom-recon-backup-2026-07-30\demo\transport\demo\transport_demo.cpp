// transport_demo.cpp — module 5 transport, verified (AV_PIPELINE_DETAILS.html §5):
//   1) congestion control converges to the bottleneck bandwidth (delay-based, before loss)
//   2) responds to a mid-stream bandwidth drop (2 Mbps -> 500 kbps)
//   3) pacer smooths a burst to the target rate
//   4) REAL UDP loopback: media packets sent/received over an actual winsock socket, bytes intact
//   5) transport selection falls back UDP -> TCP after a 2 s UDP outage, and recovers
//   6) REAL TCP loopback: reliable send/recv over an actual socket (the fallback path)
#include "transport/congestion.hpp"
#include "transport/pacer.hpp"
#include "transport/net_sim.hpp"
#include "transport/socket_transport.hpp"
#include "transport/transport_select.hpp"
#include <cstdio>
#include <cstdint>
#include <thread>
#include <vector>

using namespace avp;

// Run the congestion controller against a bottleneck link for `seconds`, optionally changing capacity
// at the midpoint. Returns the average target over the last second (bps).
static double run_cc(CongestionController& cc, BottleneckLink& link, double seconds,
                     double cap2 = -1, bool verbose = false) {
  const int64_t period_us = 50000;    // 50 ms report interval
  const int pkt = 1100;
  int64_t clk = 1'000'000; uint16_t seq = 0;
  int steps = (int)(seconds * 1e6 / period_us);
  double last_sec_sum = 0; int last_sec_n = 0;
  for (int s = 0; s < steps; ++s) {
    if (cap2 > 0 && s == steps / 2) link.set_capacity(cap2);
    double bytes = cc.target_bps() * period_us / 1e6 / 8.0;
    int n = (int)(bytes / pkt); if (n < 2) n = 2;
    int64_t gap = period_us / n;
    std::vector<PacketFeedback> fb;
    for (int i = 0; i < n; ++i) {
      PacketFeedback f; f.seq = seq++; f.size = pkt; f.send_time_us = clk + i * gap;
      int64_t rx; link.transmit(pkt, f.send_time_us, rx); f.recv_time_us = rx; fb.push_back(f);
    }
    clk += period_us;
    cc.on_feedback(fb);
    if (s >= steps - 20) { last_sec_sum += cc.target_bps(); ++last_sec_n; }
    if (verbose && s % 10 == 0) {
      auto st = cc.state();
      std::printf("     t=%4.1fs  target=%6.0f kbps  thr=%6.0f kbps  %s\n",
                  s * period_us / 1e6, cc.target_bps() / 1000, st.throughput_bps / 1000, st.signal);
    }
  }
  return last_sec_n ? last_sec_sum / last_sec_n : 0;
}

int main() {
  WsaScope wsa;
  std::printf("=== AV pipeline / module 5: TRANSPORT ===\n\n");
  int fail = 0;

  // ---- 1) congestion control converges to a 2 Mbps bottleneck ----
  std::printf("1) GCC congestion control converges to bottleneck (2 Mbps, 100 ms RTT)\n");
  { BottleneckLink link(2'000'000, 50, 60000); CongestionController cc(300000);
    double conv = run_cc(cc, link, 8.0, -1, true);
    double ratio = conv / 2'000'000;
    std::printf("   converged target = %.0f kbps (%.0f%% of link)  %s\n\n",
                conv / 1000, 100 * ratio, (ratio > 0.7 && ratio < 1.3) ? "OK" : (++fail, "FAIL")); }

  // ---- 2) respond to a bandwidth drop mid-stream ----
  std::printf("2) bandwidth drop 2 Mbps -> 500 kbps at midpoint\n");
  { BottleneckLink link(2'000'000, 50, 40000); CongestionController cc(300000);
    double conv = run_cc(cc, link, 12.0, 500'000, false);
    double ratio = conv / 500'000;
    std::printf("   target after drop = %.0f kbps (%.0f%% of new link)  %s\n\n",
                conv / 1000, 100 * ratio, (ratio > 0.6 && ratio < 1.6) ? "OK" : (++fail, "FAIL")); }

  // ---- 3) pacer smooths a burst ----
  std::printf("3) pacer smooths a 40-packet burst at 1 Mbps\n");
  { Pacer pacer(1'000'000); for (int i = 0; i < 40; ++i) pacer.enqueue((uint16_t)i, 1100);
    int64_t t = 0; int sent = 0, ticks_with_send = 0, max_per_tick = 0;
    while (pacer.backlog() > 0 && t < 2'000'000) {
      auto out = pacer.tick(t); if (!out.empty()) { ++ticks_with_send; if ((int)out.size() > max_per_tick) max_per_tick = (int)out.size(); }
      sent += (int)out.size(); t += 5000;   // 5 ms ticks
    }
    // 40*1100*8 = 352 kbit @ 1 Mbps -> ~352 ms
    std::printf("   drained %d pkts over %.0f ms, max %d pkts/tick (no big burst)  %s\n\n",
                sent, t / 1000.0, max_per_tick, (sent == 40 && t / 1000.0 > 250 && max_per_tick <= 3) ? "OK" : (++fail, "FAIL")); }

  // ---- 4) REAL UDP loopback: send 100 media packets, receive them intact ----
  std::printf("4) real UDP loopback (winsock)\n");
  { UdpSocket rx; UdpSocket tx; bool ok = rx.open(0) && tx.open(0);
    uint16_t port = rx.local_port();
    int got = 0; bool intact = true;
    for (int i = 0; i < 100 && ok; ++i) {
      uint8_t buf[256]; for (int b = 0; b < 200; ++b) buf[b] = (uint8_t)((i * 7 + b) & 0xFF);
      buf[0] = (uint8_t)i;
      if (!tx.send_to(port, buf, 200)) { intact = false; break; }
      uint8_t rbuf[256]; int n = rx.recv(rbuf, sizeof(rbuf), 200);
      if (n == 200 && rbuf[0] == (uint8_t)i && rbuf[199] == (uint8_t)((i * 7 + 199) & 0xFF)) ++got; else intact = false;
    }
    std::printf("   sent 100, received %d intact over 127.0.0.1:%u  %s\n\n",
                got, port, (ok && got == 100 && intact) ? "OK" : (++fail, "FAIL")); }

  // ---- 5) transport selection: UDP -> TCP fallback after 2 s outage, then recover ----
  std::printf("5) transport selection UDP->TCP (2 s outage) + recover\n");
  { TransportSelector sel(2000, /*quic*/false);
    int64_t t = 0; sel.on_udp_activity(t);
    TransportKind k_before = sel.on_tick(t + 1'000'000);         // 1 s: still UDP
    TransportKind k_out    = sel.on_tick(t + 2'500'000);         // 2.5 s silence: -> TCP
    sel.on_udp_activity(t + 3'000'000);                          // UDP resumes -> UDP
    TransportKind k_rec    = sel.current();
    std::printf("   1s:%s  2.5s-outage:%s  after-recover:%s  (switches=%d)  %s\n\n",
                to_string(k_before), to_string(k_out), to_string(k_rec), sel.switches(),
                (k_before == TransportKind::UDP && k_out == TransportKind::TCP && k_rec == TransportKind::UDP) ? "OK" : (++fail, "FAIL")); }

  // ---- 6) REAL TCP loopback: reliable send/recv (the fallback path) ----
  std::printf("6) real TCP loopback (winsock, reliable fallback path)\n");
  { TcpListener lis; bool ok = lis.listen(0); uint16_t port = lis.local_port();
    std::vector<uint8_t> payload(4000); for (size_t i = 0; i < payload.size(); ++i) payload[i] = (uint8_t)(i & 0xFF);
    std::thread server([&]{ SOCKET c = lis.accept_one(); if (c == INVALID_SOCKET) return;
      TcpConn conn(c); std::vector<uint8_t> buf(8192); int total = 0;
      while (total < (int)payload.size()) { int n = conn.recv(buf.data(), (int)buf.size()); if (n <= 0) break; conn.send_all(buf.data(), n); total += n; } });
    TcpConn cli; bool cok = cli.connect(port);
    bool match = false;
    if (cok) {
      cli.send_all(payload.data(), (int)payload.size());
      std::vector<uint8_t> back(payload.size()); int total = 0;
      while (total < (int)payload.size()) { int n = cli.recv(back.data() + total, (int)payload.size() - total); if (n <= 0) break; total += n; }
      match = (total == (int)payload.size() && back == payload);
      cli.close();
    }
    server.join();
    std::printf("   TCP echo of %zu bytes on 127.0.0.1:%u: %s  %s\n\n",
                payload.size(), port, match ? "byte-identical" : "mismatch", (ok && cok && match) ? "OK" : (++fail, "FAIL")); }

  std::printf(fail ? "SOME CHECKS FAILED (%d)\n" : "ALL PASS (CC converges, pacer smooths, real UDP/TCP, fallback works)\n", fail);
  return fail ? 1 : 0;
}
