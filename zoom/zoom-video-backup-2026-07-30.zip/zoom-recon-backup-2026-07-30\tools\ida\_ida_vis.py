import idc, ida_hexrays, ida_funcs, idautils
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L=[]
def decomp(ea,label):
    f=ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x %s"%(ea,label)); return
    try:
        L.append("\n// ===== %s %s (0x%x) ====="%(label,idc.get_func_name(f.start_ea),f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e: L.append("// FAIL 0x%x: %s"%(ea,e))
def vt(addr,label,nd=5):
    slots=[]; ea=addr
    for i in range(14):
        p=idc.get_qword(ea)
        if not ida_funcs.get_func(p): break
        slots.append(p); ea+=8
    L.append("\n// ==== %s vtable 0x%x: %d slots ===="%(label,addr,len(slots)))
    for i,s in enumerate(slots): L.append("//  [%d] 0x%x %s"%(i,s,idc.get_func_name(s)))
    # ctors
    refs=sorted(set(idc.get_func_attr(x,idc.FUNCATTR_START) for x in idautils.DataRefsTo(addr)))
    L.append("//  ctors/refs: "+", ".join("0x%x"%c for c in refs if c!=idc.BADADDR and (not slots or c!=slots[0])))
    seen=set()
    for i,s in enumerate(slots[:nd]):
        if s in seen: continue
        seen.add(s); decomp(s,"%s.slot%d"%(label,i))
vt(0x180501510,"TextVideoPartition",6)
vt(0x180501558,"ContentDetect",5)
vt(0x1805014d8,"GlobalMotionDetect",5)
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
