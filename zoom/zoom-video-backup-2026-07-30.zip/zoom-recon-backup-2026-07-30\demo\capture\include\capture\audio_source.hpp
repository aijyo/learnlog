// audio_source.hpp — the audio capture interface, mirroring IVideoSource. Zoom's audio ingest (§1.3)
// opens a WASAPI client on either the default capture endpoint (microphone) or the default render
// endpoint in loopback mode (system/"share" audio), then pulls packets. Same open/read/close shape.
#pragma once
#include "audio_frame.hpp"
#include <string>

namespace avp {

enum class AudioTarget {
  DefaultMic,       // default capture endpoint (eCapture / eConsole) — the microphone
  DefaultLoopback,  // default render endpoint captured in loopback — system/"share" audio
  DeviceId          // a specific endpoint by id (device_id below)
};

struct AudioCaptureConfig {
  AudioTarget target = AudioTarget::DefaultMic;
  std::wstring device_id;     // for AudioTarget::DeviceId (endpoint id from EnumerateAudioDevices)
  int          buffer_ms = 0; // requested engine buffer; 0 = WASAPI default (typically ~10 ms period)
};

// Pull-model like IVideoSource: open() -> read() repeatedly -> close(). read() returns whatever the
// endpoint has buffered right now (0 frames is normal when the client hasn't accumulated a period yet).
struct IAudioSource {
  virtual ~IAudioSource() = default;
  virtual bool         open(const AudioCaptureConfig& cfg) = 0;
  virtual bool         read(AudioFrame& out) = 0;   // drains currently-available packets; false only on error
  virtual void         close() = 0;
  virtual const char*  backend() const = 0;         // e.g. "WASAPI-Loopback"
  virtual AudioFormat  format() const = 0;          // negotiated capture format
};

// One audio endpoint discovered on the system.
struct AudioDeviceInfo {
  std::wstring id;        // endpoint id (pass to AudioCaptureConfig::device_id)
  std::wstring name;      // friendly name
  bool         is_capture = true;   // true = capture (mic), false = render (speaker; loopback-capable)
  bool         is_default = false;
};

}  // namespace avp
