// mmr_test.cpp — a mini MMR (Zoom "Multimedia Router") multi-party / GALLERY demo, built strictly to the
// reverse-engineered Zoom model:
//   * N participants each send ONE spatial-SVC VP9 stream (base 360p + enh 720p), encoded once.
//   * The MMR forwards to the viewer PER-SOURCE BY ROLE (§8.3 + §3.2, "服务端决策、客户端执行"): the
//     ACTIVE SPEAKER's stream at the FULL layer (720p, enlarged), everyone else at the BASE layer (360p
//     thumbnail) — NO re-encode (just superframe pruning, vp9_prune).
//   * ACTIVE SPEAKER = audio energy sustained > 5.0 s (Zoom's "活跃 >5.0s 判定"; the CAM++ neural speaker
//     embedding is the ⛔W version — here it's plain energy + the 5 s rule with hysteresis).
//   * Per-stream BANDWIDTH WEIGHTING (§ "按流加权": speaker video > thumbnail) via mcm DistributeBandwidth.
//   * The client composites a video WALL (nydus CWallRenderer analog): speaker large + a thumbnail strip,
//     written to the PeerA shm map so the AvpMonitor shows the live multi-party gallery.
#include "encode/vp9_svc.hpp"
#include "apps/mcm/mcm_channel.hpp"
#include "apps/ipc_shared.hpp"
#include "apps/ipc_writer.hpp"
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <cmath>
#include <thread>
#include <chrono>
extern "C" {
#include "vpx/vpx_decoder.h"
#include "vpx/vp8dx.h"
#include "vpx/vpx_image.h"
}

using namespace avp;
static const int N = 4, FW = 1280, FH = 720;   // 4 participants, each encodes 720p SVC
using clockt = std::chrono::steady_clock;

// A distinct, recognisable synthetic feed per participant p: a solid hue + a moving bar + (p+1) corner
// dots so each tile is identifiable in the gallery.
static I420Image participant_frame(int p, int t, bool talking) {
  I420Image im; im.w = FW; im.h = FH; im.y.resize((size_t)FW * FH);
  im.u.assign((size_t)im.cw() * im.ch(), 128); im.v.assign((size_t)im.cw() * im.ch(), 128);
  int bar = (t * (6 + p * 3)) % FW;                        // per-participant moving bar speed
  int luma = talking ? 150 : 90;                           // brighter while talking
  for (int y = 0; y < FH; ++y) for (int x = 0; x < FW; ++x) {
    int v = luma + ((x + y) % 48 < 24 ? 12 : -12);
    if (std::abs(x - bar) < 40) v = 230;                   // moving highlight bar
    im.y[(size_t)y * FW + x] = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v);
  }
  // distinct chroma per participant (red/green/blue/amber-ish) so tiles are colour-coded
  static const int U[N] = { 90, 100, 200, 110 }, V[N] = { 200, 90, 120, 150 };
  for (auto& u : im.u) u = (uint8_t)U[p]; for (auto& vv : im.v) vv = (uint8_t)V[p];
  // (p+1) white dots, top-left, to identify the participant
  for (int d = 0; d <= p; ++d) for (int yy = 30; yy < 70; ++yy) for (int xx = 30 + d * 55; xx < 70 + d * 55; ++xx)
    im.y[(size_t)yy * FW + xx] = 255;
  return im;
}

// decode one pruned superframe with `dec`, convert the newest frame to BGRA (native size). returns false if none.
static bool decode_bgra(vpx_codec_ctx_t& dec, const std::vector<uint8_t>& data, VideoFrame& out) {
  if (vpx_codec_decode(&dec, data.data(), (unsigned)data.size(), nullptr, 0) != VPX_CODEC_OK) return false;
  vpx_codec_iter_t it = nullptr; vpx_image_t* im; bool got = false;
  while ((im = vpx_codec_get_frame(&dec, &it))) {
    I420Image q; q.w = im->d_w; q.h = im->d_h; q.y.resize((size_t)q.w * q.h);
    q.u.resize((size_t)q.cw() * q.ch()); q.v.resize((size_t)q.cw() * q.ch());
    for (int y = 0; y < q.h; ++y) std::memcpy(&q.y[(size_t)y * q.w], im->planes[0] + (size_t)y * im->stride[0], q.w);
    for (int y = 0; y < q.ch(); ++y) { std::memcpy(&q.u[(size_t)y * q.cw()], im->planes[1] + (size_t)y * im->stride[1], q.cw());
                                       std::memcpy(&q.v[(size_t)y * q.cw()], im->planes[2] + (size_t)y * im->stride[2], q.cw()); }
    I420ToBgra(q, out); got = true;
  }
  return got;
}

// nearest-neighbour blit of a BGRA source into rect (dx,dy,dw,dh) of the dst canvas (canvasW x canvasH).
static void blit(std::vector<uint8_t>& dst, int cw, int ch, const VideoFrame& s, int dx, int dy, int dw, int dh) {
  if (s.width <= 0 || s.height <= 0) return;
  for (int y = 0; y < dh; ++y) { int gy = dy + y; if (gy < 0 || gy >= ch) continue;
    int sy = y * s.height / dh;
    for (int x = 0; x < dw; ++x) { int gx = dx + x; if (gx < 0 || gx >= cw) continue;
      int sx = x * s.width / dw; size_t sp = ((size_t)sy * s.width + sx) * 4, dp = ((size_t)gy * cw + gx) * 4;
      dst[dp] = s.data[sp]; dst[dp + 1] = s.data[sp + 1]; dst[dp + 2] = s.data[sp + 2]; dst[dp + 3] = 255; } }
}
static void border(std::vector<uint8_t>& dst, int cw, int ch, int x, int y, int w, int h, int thick, uint8_t B, uint8_t G, uint8_t R) {
  for (int t = 0; t < thick; ++t) for (int i = -t; i < w + t; ++i) {
    for (int e = 0; e < 2; ++e) { int yy = e ? y + h + t - 1 : y - t, xx = x + i;
      if (xx >= 0 && xx < cw && yy >= 0 && yy < ch) { size_t d = ((size_t)yy * cw + xx) * 4; dst[d] = B; dst[d + 1] = G; dst[d + 2] = R; }
      int xv = e ? x + w + t - 1 : x - t, yv = y + i;
      if (xv >= 0 && xv < cw && yv >= 0 && yv < ch) { size_t d = ((size_t)yv * cw + xv) * 4; dst[d] = B; dst[d + 1] = G; dst[d + 2] = R; } } }
}

int main(int argc, char** argv) {
  int seconds = 30, fps = 10; for (int i = 1; i < argc; ++i) if (!strcmp(argv[i], "--seconds") && i + 1 < argc) seconds = atoi(argv[++i]);
  const int CW = ipc::kW, CH = ipc::kH;

  // N participants: one SVC encoder + one decoder each (the viewer's per-source decoder).
  std::vector<Vp9SvcEncoder> enc(N);
  std::vector<vpx_codec_ctx_t> dec(N);
  for (int p = 0; p < N; ++p) {
    if (!enc[p].open(FW, FH, 2, /*base*/500, /*full*/1600)) { std::printf("enc %d open failed\n", p); return 1; }
    vpx_codec_dec_init(&dec[p], vpx_codec_vp9_dx(), nullptr, 0);
  }
  ipc::ShmPublisher<ipc::PeerShare> shm;
  bool have_shm = shm.open(ipc::kPeerMap('A'));
  if (have_shm) { shm->magic = ipc::kMagic; shm->width = CW; shm->height = CH; shm->running = 1; }

  std::printf("\n  mini-MMR: %d participants, each 1 SVC encode; MMR forwards speaker=FULL(720p) others=BASE(360p)\n", N);
  std::printf("  active speaker = audio energy sustained > 5.0 s (Zoom §8.3). Gallery -> PeerA shm (open AvpMonitor).\n");
  std::printf("  --------------------------------------------------------------------------------------------------\n");

  std::vector<double> talk_time(N, 0.0);
  int speaker = 0, last_speaker = -1;
  long full_bytes = 0, sent_bytes = 0;
  const double dt = 1.0 / fps;
  auto t0 = clockt::now();
  int total = seconds * fps;
  for (int t = 0; t < total; ++t) {
    double now_s = t * dt;
    // ---- audio energy: participants take ~7 s turns talking (rotating); energy drives the 5 s rule ----
    int turn = ((int)(now_s / 7.0)) % N;
    std::vector<double> energy(N);
    for (int p = 0; p < N; ++p) energy[p] = (p == turn) ? 0.85 : 0.05;
    // ---- active-speaker detection: sustained-talk time + 5 s threshold, with hysteresis ----
    for (int p = 0; p < N; ++p) talk_time[p] = energy[p] > 0.30 ? talk_time[p] + dt : 0.0;
    int cand = 0; for (int p = 1; p < N; ++p) if (talk_time[p] > talk_time[cand]) cand = p;
    if (talk_time[cand] > 5.0 && cand != speaker) speaker = cand;   // only promote after >5 s sustained
    if (speaker != last_speaker) {
      std::printf("  [%5.1fs] active speaker -> P%d  (talked %.1fs; MMR now forwards P%d at FULL 720p, others BASE 360p)\n",
                  now_s, speaker, talk_time[speaker], speaker);
      last_speaker = speaker;
    }

    // ---- each participant encodes once (SVC superframe) ----
    std::vector<std::vector<uint8_t>> sf(N);
    for (int p = 0; p < N; ++p) { I420Image im = participant_frame(p, t, energy[p] > 0.30); enc[p].encode(im, t, sf[p]); full_bytes += (long)sf[p].size(); }

    // ---- MMR: forward per source by ROLE (speaker=full, others=base), then the viewer decodes each ----
    std::vector<VideoFrame> tile(N);
    for (int p = 0; p < N; ++p) {
      int keep = (p == speaker) ? 2 : 1;                       // Zoom subscription: speaker=enh layer, thumbnail=base
      std::vector<uint8_t> fwd = vp9_prune(sf[p], keep); sent_bytes += (long)fwd.size();
      decode_bgra(dec[p], fwd, tile[p]);
    }

    // ---- composite the video WALL (CWallRenderer analog): speaker large on top + thumbnail strip below ----
    std::vector<uint8_t> canvas((size_t)CW * CH * 4, 20);
    int stripH = CH / 4, bigH = CH - stripH;                   // top 3/4 = speaker, bottom 1/4 = thumbnails
    blit(canvas, CW, CH, tile[speaker], 0, 0, CW, bigH);       // speaker enlarged (from its FULL 720p layer)
    border(canvas, CW, CH, 4, 4, CW - 8, bigH - 8, 4, 90, 220, 90);   // green frame on the speaker
    int tw = CW / N, th = stripH;
    for (int p = 0; p < N; ++p) {
      int x = p * tw;
      blit(canvas, CW, CH, tile[p], x + 4, bigH + 4, tw - 8, th - 8);
      bool talking = energy[p] > 0.30;
      if (p == speaker) border(canvas, CW, CH, x + 4, bigH + 4, tw - 8, th - 8, 3, 90, 220, 90);   // speaker: green
      else if (talking) border(canvas, CW, CH, x + 4, bigH + 4, tw - 8, th - 8, 3, 80, 200, 250);  // talking: amber
    }
    if (have_shm) { ipc::publish_frame(shm.get(), canvas.data(), canvas.size());   // double-buffer flip (anti-tearing) + recv_frame_seq++
                    shm->recv_decoded = t; shm->adapt_w = CW; shm->adapt_h = bigH; shm->adapt_fps = fps; }

    std::this_thread::sleep_until(t0 + std::chrono::duration_cast<clockt::duration>(std::chrono::duration<double>((t + 1) * dt)));
  }

  std::printf("  --------------------------------------------------------------------------------------------------\n");
  std::printf("  => %d participants, each encoded ONCE. MMR forwarded %ld / %ld B = %.0f%% (speaker FULL + %d thumbnails BASE),\n",
              N, sent_bytes, full_bytes, full_bytes ? 100.0 * sent_bytes / full_bytes : 0, N - 1);
  std::printf("     no re-encode; active speaker switched by the >5 s energy rule; gallery composited (CWallRenderer).\n\n");
  for (int p = 0; p < N; ++p) vpx_codec_destroy(&dec[p]);
  return 0;
}
