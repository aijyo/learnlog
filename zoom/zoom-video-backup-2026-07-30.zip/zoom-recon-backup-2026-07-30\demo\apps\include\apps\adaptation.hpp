// adaptation.hpp — Zoom's end-to-end weak-network feedback loop (§9), driving the video ladder (§1.4).
// It runs the RECONSTRUCTED mcm "brain" (apps/mcm/mcm_channel.hpp, body-anchored to mcm.dll):
//   QoS metrics (loss/jitter/delay) -> G.107 MOS -> net-score 0..5 -> bw-level 1..4 (+ MCM_NW_WARNING
//   double-threshold hysteresis + the 3/4/5 multi-FEC level).
// On top of that brain this maps bw-level -> a {resolution, frame-rate, bitrate} tier, with the two
// profiles §1.4 calls out: SCREEN share = "high resolution + low frame rate" (drop fps/bitrate first,
// keep pixels for text), CAMERA = "frame-rate priority" (drop resolution first, keep motion smooth).
// Tier moves have their own hysteresis: downgrade immediately (react to congestion), upgrade one step at
// a time after a dwell (avoid the "breathing" quality oscillation §9 warns about).
#pragma once
#include "apps/mcm/mcm_channel.hpp"
#include <cstdint>

namespace avp {

struct VideoTier { int w, h, fps, kbps; const char* label; };

// The resolution rungs below are the RECOVERED Zoom ladder (IDA re-analysis 2026-07,
// bin2cpp-output/recon/ida_recovered_ladders.md):
//   mcm.dll table 0x1802BF000 / 0x1802BEFC0, selector sub_1801E1DD0 (nearest-pixel-count):
//     {320x180, 640x360, 1280x720, 1920x1080}, rung = {u32 w, u32 h, f32 fps, u32 rsvd}.
//   fps CAP is 实证: 30 for the screen/default table, 60 for 720p/1080p in the motion table.
//   Ladder height is 1080 (not 1088 — 1088 is only the encoder's 16-align).
// Tagging: [实证] recovered rung/fps-cap ; [derived] fps below the cap is content/network-throttled
// (not a tabled constant) ; [formula] kbps from sub_1801E1970 (pixels/921600 shaped) + the
// sub_18001A890 Mbit budget — approximated to the nearest rung target here.

// SCREEN ladder — §1.4 "high resolution + LOW frame rate": hold pixels for text, shed fps/bitrate
// first. The recovered fps CAP is 30 (table 0x1802BF000) but screen OPERATES far below it on
// quasi-static content — and software AV1 good-mode (IntraBC = the sharp path) only sustains ~8 fps
// at 1080p, so the operating fps must stay low (raising it starves bits/frame → blur). Resolution
// dims are the recovered rungs {1280x720, 1920x1080, height 1080 not 1088}; fps/bitrate are the
// verified low-fps operating points (NOT the 30 cap).
inline VideoTier ScreenTier(recon::mcm::BwLevel l) {
  switch (l) {
    case recon::mcm::BwLevel::L4: return { 1920, 1080, 8, 6000, "1080p@8" };  // rung dims + §1.4 low-fps op-point
    case recon::mcm::BwLevel::L3: return { 1920, 1080, 6, 4000, "1080p@6" };
    case recon::mcm::BwLevel::L2: return { 1280,  720, 5, 2500, "720p@5"  };
    default:                      return { 1280,  720, 4, 1500, "720p@4"  };
  }
}
// CAMERA ladder — §1.4 "frame-rate priority": keep fps up, shed resolution first. Dims are the
// recovered 16:9 rungs (zlt ladder 0x1803F8520: 1280x720 / 960x540 / 640x360 / 480x270); fps 15
// is the verified-smooth operating point (recovered caps go to 24/60, kept moderate here). Bitrates
// anchor 720p@15 at real HD-call rate (~1.5 Mbps; not 2500 — that was too high for a camera) and scale
// by the RECOVERED bitrate-vs-resolution shape (sub_1801E1970: bitrate ∝ pow(px/921600, ...) ≈
// 720:540:360:270 = 1 : 0.63 : 0.35 : 0.25). The absolute coefficient is config-driven (not in the image).
inline VideoTier CameraTier(recon::mcm::BwLevel l) {
  switch (l) {
    case recon::mcm::BwLevel::L4: return { 1280, 720, 15, 1500, "720p@15" };  // real 720p HD-call rate (was 2500)
    case recon::mcm::BwLevel::L3: return {  960, 540, 15,  950, "540p@15" };  // 1500 x 0.63
    case recon::mcm::BwLevel::L2: return {  640, 360, 12,  520, "360p@12" };  // 1500 x 0.35
    default:                      return {  480, 270, 10,  350, "270p@10" };  // 1500 x 0.25 (+ floor)
  }
}

// §3 BWE↔resolution unification: map a BWE bandwidth estimate (kbps) to the highest ladder rung whose
// bitrate it can sustain. A pure bandwidth shortfall (BWE low but no loss yet, so the G.107 net-score is
// still high) must still drop RESOLUTION — otherwise the encoder holds full res and just starves the
// bitrate (1080p @ 300 kbps = blocky macroblocking, exactly what a fixed-res throttle produces). Zoom's
// ladder selector (mcm sub_1801E1DD0) picks the rung for the target rate; we walk L4→L1 and take the first
// rung whose bitrate fits, leaving ~10% for the audio + FEC + retransmits that share the same link. Returns
// L1 (floor) if even that rung doesn't fit.
inline recon::mcm::BwLevel BweLevel(int bwe_kbps, bool camera) {
  using Lv = recon::mcm::BwLevel;
  for (Lv l : { Lv::L4, Lv::L3, Lv::L2 }) {
    VideoTier t = camera ? CameraTier(l) : ScreenTier(l);
    if (bwe_kbps >= t.kbps + t.kbps / 10) return l;   // BWE covers this rung's bitrate + ~10% link overhead
  }
  return Lv::L1;
}

class AdaptationController {
public:
  explicit AdaptationController(bool camera, int up_dwell_ticks = 3)
      : camera_(camera), up_dwell_(up_dwell_ticks) {}

  struct Result {
    recon::mcm::ChannelDecision d;   // mos / net-score / bw-level / fec-level / warning
    VideoTier tier;
    bool tier_changed;
  };

  // One QoS tick. loss_rate/fec_ratio in [0,1]; jitter/delay in ms. bwe_kbps>0 folds the GCC/BWE bandwidth
  // estimate into the rung choice (§3). recv_overload>0 = the REMOTE receiver reports it can't DECODE our
  // current tier in real time (a compute limit — see media_channel.hpp type 7). Returns the coordinated decision.
  // hard_cap = true ONLY when congestion control is genuinely on (a real link-rate limit). When it's off,
  // loss/delay signals (and single-machine compute inflating them) must NOT crater the camera resolution.
  Result Tick(double loss_rate, double fec_ratio, uint32_t jitter_ms, uint32_t delay_ms, int bwe_kbps = 0, bool hard_cap = false, int recv_overload = 0) {
    recon::mcm::AudioQosMetrics m;
    m.loss_rate = loss_rate; m.fec_ratio = fec_ratio; m.jitter_ms = jitter_ms; m.abs_net_delay_ms = delay_ms;
    recon::mcm::ChannelDecision d = ch_.OnQosTick(m);

    // §3 unify: the resolution rung is the MORE constrained of the loss-driven net-score (d.bw) and the
    // bandwidth-driven BWE level. FEC keeps following d.bw (a loss signal); only the tier follows the min.
    int want = (int)d.bw;
    if (bwe_kbps > 0) { int bl = (int)BweLevel(bwe_kbps, camera_); if (bl < want) want = bl; }   // bandwidth cap

    // COMPUTE-AWARE cap (CAMERA ONLY): §9 only sees the network; but the RECEIVER can be unable to DECODE a
    // camera tier in real time (weak CPU / an overloaded box) even at 0% loss — its picture falls seconds behind.
    // `recv_overload` is that receiver-reported decode lag (≈ lag/300 ms). For CAMERA, lowering RESOLUTION is a
    // real fix (decode cost ∝ pixels). But SCREEN share is ENCODE-bound (software AV1/VP9 SC is the cost, not
    // decode) and its whole point is sharp text — dropping its resolution loses legibility AND doesn't relieve
    // the encoder, and reopening the encoder to change res just adds a keyframe stall. So compute-adapt is
    // camera-only; a slow screen encoder is handled by frame-rate/keyframe pacing, not resolution. Drop the cap
    // FAST on overload, RELAX one rung after a hold (no "breathing"). A compute drop BYPASSES the 540p floor.
    int cap = (int)compute_cap_;
    if (camera_) {
      if (recv_overload >= 2) {                                 // sustained decode lag at the receiver
        int target = (int)cur_ - (recv_overload >= 5 ? 2 : 1);  // deeper lag → drop two rungs at once
        if (target < (int)recon::mcm::BwLevel::L1) target = (int)recon::mcm::BwLevel::L1;
        if (target < cap) cap = target;                         // tighten (never loosen on overload)
        compute_hold_ = kComputeHold;
      } else if (compute_hold_ > 0) { --compute_hold_; }        // settle at the lower tier before any climb-back
      else if (cap < (int)recon::mcm::BwLevel::L4) { ++cap; compute_hold_ = kComputeHold; }   // relax one rung, slowly
      compute_cap_ = (recon::mcm::BwLevel)cap;
      if (cap < want) want = cap;
    }

    // Weak-net hardening (applied LAST, so it overrides the loss/delay-driven drop): robust FEC + freeze-on-
    // loss recovery (peer_main) now absorb 6–15% loss cleanly, so loss/delay should NOT crater the CAMERA to
    // 360p/270p (where detail macroblocks). Hold ≥540p (L3) UNLESS congestion control is genuinely on
    // (`hard_cap` = a real link limit) OR the receiver genuinely can't decode 540p (compute cap forced it
    // lower — then keeping 540p would just keep it frozen). This also resists single-machine compute inflating
    // delay/BWE via the loss/delay path (the compute cap above is the *explicit*, decode-driven signal).
    bool compute_ok_at_floor = (cap >= (int)recon::mcm::BwLevel::L3);
    if (camera_ && !hard_cap && compute_ok_at_floor && want < (int)recon::mcm::BwLevel::L3) want = (int)recon::mcm::BwLevel::L3;
    int cur = (int)cur_;
    bool changed = false;
    if (want < cur) { cur_ = (recon::mcm::BwLevel)want; dwell_ = 0; changed = true; }   // downgrade at once
    else if (want > cur) { if (++dwell_ >= up_dwell_) { cur_ = (recon::mcm::BwLevel)(cur + 1); dwell_ = 0; changed = true; } }
    else dwell_ = 0;

    VideoTier t = camera_ ? CameraTier(cur_) : ScreenTier(cur_);
    return { d, t, changed };
  }

  recon::mcm::BwLevel level() const { return cur_; }

  recon::mcm::BwLevel compute_cap() const { return compute_cap_; }

private:
  static constexpr int kComputeHold = 20;   // ticks (~20 s) to hold a compute-forced tier before relaxing 1 rung
  recon::mcm::MediaChannel ch_;
  bool camera_;
  int  up_dwell_;
  int  dwell_ = 0;
  recon::mcm::BwLevel cur_ = recon::mcm::BwLevel::L4;   // start at best; congestion steps it down
  recon::mcm::BwLevel compute_cap_ = recon::mcm::BwLevel::L4;   // receiver-decode ceiling (compute-aware); L4 = no cap
  int  compute_hold_ = 0;                              // hysteresis: hold a compute drop before climbing back
};

}  // namespace avp
