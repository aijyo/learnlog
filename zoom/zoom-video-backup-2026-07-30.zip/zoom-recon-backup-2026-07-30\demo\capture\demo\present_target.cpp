// present_target.exe — a companion D3D11 app that demonstrates Zoom's Present-hook capture (③).
// It renders an animated window and HOOKS its own IDXGISwapChain::Present (real vtable patch); the
// hook copies each backbuffer into a keyed-mutex SHARED texture that any process can read. Run this,
// then run `capture_demo --backend shared` in another terminal to capture it cross-process.
#include "capture/screen_shared.hpp"
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <cstdio>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

using Microsoft::WRL::ComPtr;
using namespace avp;

typedef HRESULT(STDMETHODCALLTYPE* PresentFn)(IDXGISwapChain*, UINT, UINT);
static PresentFn             g_orig  = nullptr;
static ID3D11Texture2D*      g_shared = nullptr;
static IDXGIKeyedMutex*      g_mutex = nullptr;
static ID3D11DeviceContext*  g_ctx   = nullptr;
static long                  g_hooks = 0;

// our hooked Present: copy the just-rendered backbuffer into the shared texture, then present.
static HRESULT STDMETHODCALLTYPE HookedPresent(IDXGISwapChain* sc, UINT si, UINT flags) {
  ID3D11Texture2D* bb = nullptr;
  if (SUCCEEDED(sc->GetBuffer(0, IID_PPV_ARGS(&bb))) && bb) {
    if (g_mutex && g_mutex->AcquireSync(0, 5) == S_OK) { g_ctx->CopyResource(g_shared, bb); g_mutex->ReleaseSync(0); ++g_hooks; }
    bb->Release();
  }
  return g_orig(sc, si, flags);
}

// minimal WndProc that actually quits the message loop when the window is closed (DefWindowProcW
// alone destroys the window but never posts WM_QUIT, so the render loop would spin forever).
static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  if (m == WM_DESTROY) { PostQuitMessage(0); return 0; }
  return DefWindowProcW(h, m, w, l);
}

int main() {
  const int W = 640, H = 360;
  WNDCLASSW wc{}; wc.lpfnWndProc = WndProc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"AvpPresentTarget";
  RegisterClassW(&wc);
  RECT r{ 0, 0, W, H }; AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
  HWND hwnd = CreateWindowW(L"AvpPresentTarget", L"AVP Present-Hook target (close to stop)", WS_OVERLAPPEDWINDOW,
                            CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top, nullptr, nullptr, wc.hInstance, nullptr);
  ShowWindow(hwnd, SW_SHOW);

  DXGI_SWAP_CHAIN_DESC sd{};
  sd.BufferCount = 2; sd.BufferDesc.Width = W; sd.BufferDesc.Height = H; sd.BufferDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
  sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.OutputWindow = hwnd; sd.SampleDesc.Count = 1; sd.Windowed = TRUE;
  sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
  ComPtr<ID3D11Device> dev; ComPtr<ID3D11DeviceContext> ctx; ComPtr<IDXGISwapChain> sc;
  if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
             nullptr, 0, D3D11_SDK_VERSION, &sd, &sc, &dev, nullptr, &ctx))) { std::printf("D3D init failed\n"); return 2; }
  ComPtr<ID3D11Texture2D> bb; sc->GetBuffer(0, IID_PPV_ARGS(&bb));
  ComPtr<ID3D11RenderTargetView> rtv; dev->CreateRenderTargetView(bb.Get(), nullptr, &rtv);

  // the keyed-mutex SHARED texture (Zoom's CD3d11SharedHandleHelper)
  D3D11_TEXTURE2D_DESC td{};
  td.Width = W; td.Height = H; td.MipLevels = 1; td.ArraySize = 1; td.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
  td.SampleDesc.Count = 1; td.Usage = D3D11_USAGE_DEFAULT; td.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
  td.MiscFlags = D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
  ComPtr<ID3D11Texture2D> shared; if (FAILED(dev->CreateTexture2D(&td, nullptr, &shared))) { std::printf("shared tex failed\n"); return 2; }
  ComPtr<IDXGIResource> res; shared.As(&res); HANDLE sh = nullptr; res->GetSharedHandle(&sh);
  ComPtr<IDXGIKeyedMutex> km; shared.As(&km);

  SharedInfo info{ kSharedMagic, W, H, (uint64_t)(uintptr_t)sh };
  HANDLE mapping = PublishSharedInfo(info);
  if (!mapping) { std::printf("publish failed\n"); return 2; }
  g_shared = shared.Get(); g_mutex = km.Get(); g_ctx = ctx.Get();

  // hook IDXGISwapChain::Present (vtable slot 8)
  void** vtbl = *reinterpret_cast<void***>(sc.Get());
  g_orig = reinterpret_cast<PresentFn>(vtbl[8]);
  DWORD oldp; VirtualProtect(&vtbl[8], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldp);
  vtbl[8] = reinterpret_cast<void*>(&HookedPresent);
  VirtualProtect(&vtbl[8], sizeof(void*), oldp, &oldp);

  std::printf("present_target: %dx%d, Present hooked, publishing shared surface as \"%ls\".\n", W, H, kSharedMapName);
  std::printf("now run:  capture_demo --backend shared\n");
  std::fflush(stdout);   // redirected stdout is fully buffered — flush the banner so consumers see it live

  // optional self-stop for scripted tests: AVP_PRESENT_SECONDS=N exits after N seconds.
  ULONGLONG stop_ms = 0; { char buf[32]; size_t n = 0;
    if (getenv_s(&n, buf, sizeof(buf), "AVP_PRESENT_SECONDS") == 0 && n > 0) stop_ms = (ULONGLONG)atoll(buf) * 1000; }

  ULONGLONG t0 = GetTickCount64();
  MSG msg{}; bool run = true;
  while (run) {
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { if (msg.message == WM_QUIT) run = false; TranslateMessage(&msg); DispatchMessageW(&msg); }
    if (stop_ms && GetTickCount64() - t0 >= stop_ms) run = false;
    float t = (GetTickCount64() - t0) / 1000.0f;
    float col[4] = { 0.5f + 0.5f * sinf(t), 0.5f + 0.5f * sinf(t + 2), 0.5f + 0.5f * sinf(t + 4), 1.0f };  // animated
    ctx->OMSetRenderTargets(1, rtv.GetAddressOf(), nullptr);
    ctx->ClearRenderTargetView(rtv.Get(), col);
    sc->Present(1, 0);   // -> HookedPresent copies backbuffer to the shared texture
  }
  if (mapping) CloseHandle(mapping);
  std::printf("present_target: stopped after %ld hooked presents.\n", g_hooks);
  return 0;
}
