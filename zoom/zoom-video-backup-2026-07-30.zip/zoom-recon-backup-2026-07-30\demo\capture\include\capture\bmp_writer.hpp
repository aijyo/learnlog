// bmp_writer.hpp — dump a BGRA VideoFrame to a .bmp (proof that real pixels were captured),
// and read one back (used by module 2 to load a real captured frame as preprocess input).
#pragma once
#include "video_frame.hpp"
#include <cstdint>
#include <cstdio>
#include <vector>

namespace avp {

inline bool write_bmp(const char* path, const VideoFrame& f) {
  if (f.format != PixelFormat::BGRA || !f.valid()) return false;
  const uint32_t rowsize = (uint32_t)f.width * 4;
  const uint32_t imgsize = rowsize * (uint32_t)f.height;
  const uint32_t filesize = 54 + imgsize;
  auto put32 = [](uint8_t* p, uint32_t v) { p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); };
  uint8_t fh[14] = { 'B','M', 0,0,0,0, 0,0, 0,0, 54,0,0,0 };
  put32(fh + 2, filesize);
  uint8_t ih[40] = {};
  ih[0] = 40;                       // header size
  put32(ih + 4, (uint32_t)f.width);
  put32(ih + 8, (uint32_t)f.height);// positive -> bottom-up
  ih[12] = 1;                       // planes
  ih[14] = 32;                      // bpp
  put32(ih + 20, imgsize);
  FILE* fp = nullptr; fopen_s(&fp, path, "wb"); if (!fp) return false;
  fwrite(fh, 1, 14, fp); fwrite(ih, 1, 40, fp);
  for (int y = f.height - 1; y >= 0; --y) fwrite(&f.data[(size_t)y * f.stride], 1, rowsize, fp);  // BMP is bottom-up
  fclose(fp);
  return true;
}

// Read a 32-bpp (or 24-bpp) bottom-up BMP back into a top-down BGRA VideoFrame. Returns false if the
// file is missing or not a simple uncompressed BMP. Enough to round-trip what write_bmp produced.
inline bool read_bmp(const char* path, VideoFrame& out) {
  FILE* fp = nullptr; fopen_s(&fp, path, "rb"); if (!fp) return false;
  uint8_t fh[14], ih[40];
  bool ok = fread(fh, 1, 14, fp) == 14 && fread(ih, 1, 40, fp) == 40 && fh[0] == 'B' && fh[1] == 'M';
  auto g32 = [](const uint8_t* p) { return (uint32_t)(p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t)p[3] << 24)); };
  auto g16 = [](const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); };
  if (ok) {
    uint32_t off = g32(fh + 10);
    int w = (int)g32(ih + 4); int h32 = (int)(int32_t)g32(ih + 8);
    int bpp = g16(ih + 14); uint32_t comp = g32(ih + 16);
    bool bottom_up = h32 > 0; int h = h32 < 0 ? -h32 : h32;
    if (comp != 0 || (bpp != 32 && bpp != 24) || w <= 0 || h <= 0) { fclose(fp); return false; }
    out.width = w; out.height = h; out.stride = w * 4; out.format = PixelFormat::BGRA;
    out.data.assign((size_t)w * h * 4, 255);
    const int src_bytes = bpp / 8; const uint32_t src_row = ((uint32_t)w * bpp + 31) / 32 * 4;  // 4-byte aligned
    std::vector<uint8_t> row(src_row);
    fseek(fp, (long)off, SEEK_SET);
    for (int r = 0; r < h; ++r) {
      if (fread(row.data(), 1, src_row, fp) != src_row) { fclose(fp); return false; }
      int dy = bottom_up ? (h - 1 - r) : r;
      for (int x = 0; x < w; ++x) {
        const uint8_t* s = &row[(size_t)x * src_bytes]; uint8_t* d = &out.data[((size_t)dy * w + x) * 4];
        d[0] = s[0]; d[1] = s[1]; d[2] = s[2]; d[3] = (src_bytes == 4) ? s[3] : 255;
      }
    }
    fclose(fp); return true;
  }
  fclose(fp); return false;
}

}  // namespace avp
