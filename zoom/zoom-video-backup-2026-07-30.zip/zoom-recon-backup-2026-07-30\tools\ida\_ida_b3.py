import idc, ida_hexrays, ida_funcs
out = idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L=[]
def decomp(ea,label):
    f=ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x %s"%(ea,label)); return
    try:
        L.append("\n// ===== %s %s (0x%x) ====="%(label,idc.get_func_name(f.start_ea),f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e: L.append("// FAIL 0x%x: %s"%(ea,e))
for ea,lab in [(0x1800E8C90,"cand1"),(0x1800E78C0,"cand2"),(0x1800E8D19,"cand3"),(0x1800E7915,"cand4")]:
    decomp(ea,lab)
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
