# verify.ps1 — run a headless peer A<->B pair for a few seconds and print every feature's metric line.
# Usage:
#   .\verify.ps1                         # default: synth screen, 8% loss, all features on
#   .\verify.ps1 -Loss 0.06              # vary injected loss
#   .\verify.ps1 -Source camera -Codec h264
#   .\verify.ps1 -Extra "--no-avsync"    # A/B a feature off (e.g. --no-avsync / --no-pli / --no-nack)
#   .\verify.ps1 -Extra "--no-nack --gop 300 -Loss 0.20"   # exercise PLI/FIR (isolate from NACK, rare periodic key)
param([double]$Loss = 0.08, [string]$Source = "synth", [string]$Codec = "vp9", [int]$Fps = 15, [int]$Seconds = 12, [string]$Extra = "")

$dir = "D:\code\work\av-pipeline\build-ff\apps\Release"
$oa = "$env:TEMP\verify_A.txt"; $ob = "$env:TEMP\verify_B.txt"
$c  = "--fps $Fps --loss $Loss --codec $Codec --source $Source --seconds $Seconds $Extra"
Write-Host "args: $c`n"
$a = Start-Process "$dir\peer.exe" -ArgumentList "--id A --local-port 50201 --remote-port 50202 $c" -WorkingDirectory $dir -RedirectStandardOutput $oa -PassThru -WindowStyle Hidden
$b = Start-Process "$dir\peer.exe" -ArgumentList "--id B --local-port 50202 --remote-port 50201 $c" -WorkingDirectory $dir -RedirectStandardOutput $ob -PassThru -WindowStyle Hidden
$a.WaitForExit(($Seconds + 15) * 1000) | Out-Null; $b.WaitForExit(($Seconds + 15) * 1000) | Out-Null
Start-Sleep -Milliseconds 300
foreach ($peer in @("A", "B")) {
  $f = if ($peer -eq "A") { $oa } else { $ob }
  Write-Host "===== peer $peer =====" -ForegroundColor Cyan
  Get-Content $f | Select-String -Pattern 'stopped|a/v-sync|pli/fir|rtt/delay|qos —|nack —' | ForEach-Object { ($_ -replace '\s+', ' ') }
  Get-Content $f | Select-String -Pattern 'kb/s:' | Select-Object -Last 1 | ForEach-Object { "  libx264 " + ($_ -replace '.*kb/s', 'kb/s') }
  Write-Host ""
}