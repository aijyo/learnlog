// svc_layers.hpp — SVC temporal layering (AV_PIPELINE_DETAILS.html §3.2): the dyadic ×0.5 frame-rate
// cascade (30 → 15 → 7.5 fps) an SFU can prune per receiver. Pure, testable index math.
//
// Standard dyadic hierarchical-P assignment: temporal_id(0) = 0 (base), else
//   temporal_id(i) = maxT - min(ctz(i), maxT)          (ctz = count-trailing-zeros)
// gives  i: 0 1 2 3 4 5 6 7  ->  tid: 0 2 1 2 0 2 1 2   for maxT=2 (3 layers).
// A receiver subscribed to layer L decodes frames with temporal_id <= L, yielding fps/2^(maxT-L).
#pragma once
#include <cstdint>

namespace avp {

struct TemporalLayering {
  int layers = 3;                 // number of temporal layers (>=1)

  int max_tid() const { return layers - 1; }

  // temporal_id for the frame at sequence index i (0-based, monotonically increasing).
  int temporal_id(uint64_t i) const {
    if (layers <= 1) return 0;
    if (i == 0) return 0;
    int tz = 0; while (((i >> tz) & 1u) == 0 && tz < 62) ++tz;   // count trailing zeros
    int m = max_tid();
    int c = tz < m ? tz : m;
    return m - c;
  }

  // Would a receiver subscribed up to layer `sub` (0..max_tid) keep frame i?
  bool subscribed(uint64_t i, int sub) const { return temporal_id(i) <= sub; }

  // Effective fps at subscription layer `sub` given the full `fps`.
  double fps_at(int sub, double fps) const {
    int drop = max_tid() - (sub < 0 ? 0 : (sub > max_tid() ? max_tid() : sub));
    double d = 1.0; for (int k = 0; k < drop; ++k) d *= 2.0;
    return fps / d;
  }
};

}  // namespace avp
