// [vendored into av-pipeline module 3 from bin2cpp-output/recon — body-verified clean-room
//  reconstruction of Zoom control surfaces, unchanged except the minih264 include path.]
// =============================================================================
//  zlt_svc_encoder.hpp -- CLEAN-ROOM reconstruction of the SVC encoder control
//  surface reverse-engineered from Zoom's zlt.dll (the "GLT" codec platform).
//
//  ORIGINAL C++17 reproducing the *config field layout, request-type dispatch,
//  and validation logic* recovered by static analysis (facts). NOT a
//  transcription of Zoom's proprietary source; exact internal error codes are
//  module-private and are represented here symbolically.
//
//  Reconstructed from (zlt.dll, IDA/Hex-Rays):
//    sub_18005A690   zltCEncodeConfig::SetEncodeCfg          (layer config)
//    sub_180008370   zltCEncodeConfig::SetKeyPictureRequest  (request dispatcher)
// =============================================================================
#pragma once
#include <cstdint>
#include <vector>
#include <array>

namespace recon::zlt {

// --- Per-spatial-layer config (SetEncodeCfg, 96-byte layer struct) -----------
struct SpatialLayer {
    int   width = 0, height = 0;
    float frame_rate = 0.f;
    int   codec_mode = 0, profile_idx = 0, level_idx = 0, tools_control_flag = 0;
    int   bitrate = 0, fix_qp = 0;
    int   layer_qos_level = 0, layer_complexity_level = 0, entropy_coding_mode = 0;
    int   ra_period = 0, ra_type = 0, ra_fix_qp = 0;   // random-access (keyframe) cadence
    int   ref_frame_num = 0;
    bool  single_ref = false;                          // bSingleRefFlag
    bool  ltr = false;                                 // bLtrFlag (loss-resilient refs)
    int   slice_bytes = 0, slice_num = 0, thread_num = 0;
    int   temporal_layer_num = 1;
    std::vector<float> temporal_frame_rate;            // per TId
    bool  bits_supp = false;
    float bitrate_factor = 1.f;
};

struct EncodeConfig {
    float    input_frame_rate = 0.f, actual_frame_rate = 0.f;
    int      connect_mode = 0;
    uint64_t source_level = 0;
    int      preproc_level = 0;
    std::vector<SpatialLayer> spatial;                 // size == spatial_layer_num
};

// --- Request types dispatched by SetKeyPictureRequest ------------------------
enum class RequestType : int {
    Reconfigure        = 1,   // -> SetEncodeCfg
    KeyPicture         = 2,   // recovery ref (dependencyId, lastReceivedPicId, temporalId)
    NewAttendeeIPic    = 3,   // new joiner needs I-picture (dependencyId, usedIPicId)
    Idr                = 4,   // force IDR (spatial_index, requestNumber)
    DuplicateP         = 5,   // duplicate a P-frame for resilience (spatial_index)
    SubscribeChange    = 20,  // subscription/layer change (dependencyId)
    FrameSkip          = 24,  // skip a frame under congestion (spatial_index; codec 4/5 only)
    LayerParam         = 25,  // set layer params
    BitrateTarget      = 31,  // rate-control target (<4 modes)
    RefStructure       = 33,  // reference/temporal structure config
};

struct RequestArgs {
    int spatial_index = 0;     // == dependencyId
    int temporal_id   = 0;
    int last_received_pic_id = 0;
    int used_i_pic_id = 0;
    int request_number = 0;
    uint32_t bitrate_target = 0;
};

enum class ReqStatus { Ok, NotInitialized, BadCodecState, SpatialOutOfRange,
                       TemporalOutOfRange, LayerOutOfRange, BadArgument, Unsupported };

// --- Per-layer pending request state (mirrors the 41656.. offsets) -----------
struct LayerReqState {
    bool     pending_key   = false; // key-picture recovery pending
    bool     pending_idr   = false; // forced IDR pending
    bool     pending_dup_p = false; // duplicate-P pending
    bool     pending_skip  = false; // frame-skip pending
    bool     pending_subscribe_change = false;
    uint16_t last_received_pic_id = 0;
    int      last_temporal_id = 0;
    int      idr_request_number = 0;
    int      used_i_pic_id = 0;
};

// Backend the encoder wrapper drives (real impl wraps H.264/AV1 encoders).
struct ISvcEncoderBackend {
    virtual ~ISvcEncoderBackend() = default;
    virtual int  ApplyConfig(const EncodeConfig&) = 0;   // 0 == ok
    virtual void ForceIdr(int spatial, int number) = 0;
    virtual void RequestKeyPicture(int spatial, int temporal) = 0;
    virtual void DuplicatePFrame(int spatial) = 0;
    virtual void SkipNextFrame(int spatial) = 0;
    virtual void SetBitrateTarget(uint32_t bps, int mode) = 0;
    virtual int  codec_type() const = 0;                 // used for layer-count limits
};

// =============================================================================
//  SvcEncoderControl -- the SetKeyPictureRequest dispatcher (sub_180008370).
//  Validates spatial/temporal indices against per-codec maxima, then records
//  pending state and/or forwards to the backend.
// =============================================================================
class SvcEncoderControl {
public:
    explicit SvcEncoderControl(ISvcEncoderBackend* be) : be_(be) {}

    void SetMaxLayers(int codec_type, int max_spatial, int max_temporal) {
        if (codec_type >= 0 && codec_type < int(kMax)) {
            max_spatial_[codec_type]  = max_spatial;   // cf. byte_1803F8700[codec]
            max_temporal_[codec_type] = max_temporal;  // cf. byte_1803F8650[codec]
        }
    }

    int SetEncodeConfig(const EncodeConfig& cfg) {
        cfg_ = cfg;
        layer_state_.assign(cfg.spatial.size(), LayerReqState{});
        return be_ ? be_->ApplyConfig(cfg) : 0;
    }

    ReqStatus Request(RequestType type, const RequestArgs& a) {
        if (!be_) return ReqStatus::NotInitialized;
        const int ct = be_->codec_type();
        auto validSpatial  = [&]{ return a.spatial_index >= 0 && a.spatial_index < MaxSpatial(ct); };
        auto validTemporal = [&]{ return a.temporal_id   >= 0 && a.temporal_id   < MaxTemporal(ct); };

        switch (type) {
        case RequestType::Reconfigure:
            return be_->ApplyConfig(cfg_) == 0 ? ReqStatus::Ok : ReqStatus::BadArgument;

        case RequestType::KeyPicture: {
            if (!validSpatial())  return ReqStatus::SpatialOutOfRange;
            if (!validTemporal()) return ReqStatus::TemporalOutOfRange;
            auto& s = Layer(a.spatial_index);
            if (s.pending_idr) return ReqStatus::Ok;            // IDR supersedes
            s.pending_key = true;
            s.last_received_pic_id = uint16_t(a.last_received_pic_id);
            s.last_temporal_id     = a.temporal_id;
            be_->RequestKeyPicture(a.spatial_index, a.temporal_id);
            return ReqStatus::Ok;
        }
        case RequestType::NewAttendeeIPic: {
            if (!validSpatial()) return ReqStatus::SpatialOutOfRange;
            auto& s = Layer(a.spatial_index);
            s.pending_key = true; s.used_i_pic_id = a.used_i_pic_id;
            be_->RequestKeyPicture(a.spatial_index, 0);
            return ReqStatus::Ok;
        }
        case RequestType::Idr: {
            if (!validSpatial()) return ReqStatus::SpatialOutOfRange;
            auto& s = Layer(a.spatial_index);
            s.pending_idr = true;
            s.idr_request_number = (a.request_number > s.idr_request_number)
                                 ? a.request_number : s.idr_request_number;
            be_->ForceIdr(a.spatial_index, s.idr_request_number);
            return ReqStatus::Ok;
        }
        case RequestType::DuplicateP: {
            if (!validSpatial()) return ReqStatus::SpatialOutOfRange;
            auto& s = Layer(a.spatial_index);
            if (!s.pending_idr && !s.pending_key) { s.pending_dup_p = true; be_->DuplicatePFrame(a.spatial_index); }
            return ReqStatus::Ok;
        }
        case RequestType::SubscribeChange: {
            if (!validSpatial()) return ReqStatus::SpatialOutOfRange;
            Layer(a.spatial_index).pending_subscribe_change = true;
            be_->RequestKeyPicture(a.spatial_index, 0);
            return ReqStatus::Ok;
        }
        case RequestType::FrameSkip: {
            if (ct != 4 && ct != 5) return ReqStatus::Unsupported;   // codec-family gate
            if (!validSpatial())    return ReqStatus::SpatialOutOfRange;
            auto& s = Layer(a.spatial_index);
            if (!s.pending_idr) { s.pending_skip = true; be_->SkipNextFrame(a.spatial_index); }
            return ReqStatus::Ok;
        }
        case RequestType::BitrateTarget:
            if (a.bitrate_target >= 4) return ReqStatus::BadArgument;  // mode < 4
            be_->SetBitrateTarget(a.bitrate_target, int(a.bitrate_target));
            return ReqStatus::Ok;

        case RequestType::LayerParam:
        case RequestType::RefStructure:
            return ReqStatus::Ok;
        }
        return ReqStatus::BadArgument;
    }

    const LayerReqState& layer_state(int i) const { return layer_state_.at(i); }

private:
    static constexpr int kMax = 8;
    int MaxSpatial(int ct)  const { return (ct>=0&&ct<kMax)? max_spatial_[ct]  : 0; }
    int MaxTemporal(int ct) const { return (ct>=0&&ct<kMax)? max_temporal_[ct] : 0; }
    LayerReqState& Layer(int i) {
        if (i >= int(layer_state_.size())) layer_state_.resize(i + 1);
        return layer_state_[i];
    }
    ISvcEncoderBackend* be_ = nullptr;
    EncodeConfig cfg_;
    std::vector<LayerReqState> layer_state_;
    std::array<int,kMax> max_spatial_{};
    std::array<int,kMax> max_temporal_{};
};

} // namespace recon::zlt
