// camera_mf.hpp — camera capture via Media Foundation (the modern Windows camera stack, matching
// Zoom's mfAdapter). Enumerate devices, open one via IMFSourceReader, let MF convert to RGB32
// (=BGRA), and pull frames. Format negotiation is delegated to the reader (video processing on).
#pragma once
#include "video_source.hpp"
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>
#include <wrl/client.h>
#include <string>
#include <vector>
#pragma comment(lib, "mfplat.lib")
#pragma comment(lib, "mf.lib")
#pragma comment(lib, "mfreadwrite.lib")
#pragma comment(lib, "mfuuid.lib")
#pragma comment(lib, "ole32.lib")

namespace avp {

using Microsoft::WRL::ComPtr;

inline std::string mf_narrow(const wchar_t* w) {
  if (!w) return "";
  int n = WideCharToMultiByte(CP_UTF8, 0, w, -1, nullptr, 0, nullptr, nullptr);
  std::string s(n > 0 ? n - 1 : 0, 0);
  if (n > 0) WideCharToMultiByte(CP_UTF8, 0, w, -1, &s[0], n, nullptr, nullptr);
  return s;
}
inline void mf_ensure() {
  static bool once = [] { CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED); MFStartup(MF_VERSION); return true; }();
  (void)once;
}

inline std::vector<std::string> EnumerateCameras() {
  mf_ensure();
  std::vector<std::string> names;
  ComPtr<IMFAttributes> attr;
  if (FAILED(MFCreateAttributes(&attr, 1))) return names;
  attr->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE, MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);
  IMFActivate** devs = nullptr; UINT32 count = 0;
  if (SUCCEEDED(MFEnumDeviceSources(attr.Get(), &devs, &count))) {
    for (UINT32 i = 0; i < count; ++i) {
      WCHAR* fn = nullptr; UINT32 len = 0;
      if (SUCCEEDED(devs[i]->GetAllocatedString(MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME, &fn, &len))) { names.push_back(mf_narrow(fn)); CoTaskMemFree(fn); }
      devs[i]->Release();
    }
    CoTaskMemFree(devs);
  }
  return names;
}

class MfCameraSource : public IVideoSource {
public:
  bool open(const CaptureConfig& cfg) override {
    mf_ensure();
    ComPtr<IMFAttributes> attr;
    if (FAILED(MFCreateAttributes(&attr, 1))) return false;
    attr->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE, MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);
    IMFActivate** devs = nullptr; UINT32 count = 0;
    if (FAILED(MFEnumDeviceSources(attr.Get(), &devs, &count)) || count == 0) { if (devs) CoTaskMemFree(devs); return false; }
    ComPtr<IMFMediaSource> source;
    UINT32 idx = (UINT32)cfg.camera_index < count ? (UINT32)cfg.camera_index : 0;
    HRESULT hr = devs[idx]->ActivateObject(IID_PPV_ARGS(&source));
    for (UINT32 i = 0; i < count; ++i) devs[i]->Release();
    CoTaskMemFree(devs);
    if (FAILED(hr) || !source) return false;

    ComPtr<IMFAttributes> ra;
    MFCreateAttributes(&ra, 1);
    ra->SetUINT32(MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING, TRUE);   // let the reader convert to RGB32
    if (FAILED(MFCreateSourceReaderFromMediaSource(source.Get(), ra.Get(), &reader_))) return false;

    ComPtr<IMFMediaType> want;
    MFCreateMediaType(&want);
    want->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    want->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_RGB32);
    if (FAILED(reader_->SetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, want.Get()))) return false;

    ComPtr<IMFMediaType> cur;
    if (FAILED(reader_->GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur))) return false;
    UINT32 w = 0, h = 0; MFGetAttributeSize(cur.Get(), MF_MT_FRAME_SIZE, &w, &h);
    w_ = (int)w; h_ = (int)h;
    LONG stride = 0; if (SUCCEEDED(cur->GetUINT32(MF_MT_DEFAULT_STRIDE, (UINT32*)&stride))) topdown_ = stride >= 0;
    return reader_ && w_ > 0 && h_ > 0;
  }

  bool grab(VideoFrame& out) override {
    if (!reader_) return false;
    DWORD flags = 0; LONGLONG ts = 0; ComPtr<IMFSample> sample;
    if (FAILED(reader_->ReadSample(MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, nullptr, &flags, &ts, &sample)) || !sample) return false;
    ComPtr<IMFMediaBuffer> buf;
    if (FAILED(sample->ConvertToContiguousBuffer(&buf))) return false;
    BYTE* p = nullptr; DWORD maxlen = 0, curlen = 0;
    if (FAILED(buf->Lock(&p, &maxlen, &curlen))) return false;
    out.width = w_; out.height = h_; out.stride = w_ * 4; out.format = PixelFormat::BGRA; out.timestamp_us = ts / 10;
    out.data.resize((size_t)out.stride * h_);
    for (int y = 0; y < h_; ++y) {
      int sy = topdown_ ? y : (h_ - 1 - y);
      memcpy(&out.data[(size_t)y * out.stride], p + (size_t)sy * out.stride, out.stride);
    }
    buf->Unlock();
    return true;
  }
  void close() override { reader_.Reset(); }
  const char* backend() const override { return "MediaFoundation-Camera"; }
  int width() const override { return w_; }
  int height() const override { return h_; }
private:
  ComPtr<IMFSourceReader> reader_;
  int w_ = 0, h_ = 0; bool topdown_ = true;
};

}  // namespace avp
#endif
