// [vendored into av-pipeline module 2 from bin2cpp-output/recon — verified
//  clean-room reconstruction, unchanged. Operates on raw 8-bit luma planes; the
//  module wrapper extracts the Y plane from an avp::VideoFrame and calls it.]
// zlt_denoise.hpp -- clean-room reconstruction of zlt.dll's classic (non-neural)
// denoise family (ns_vpp). Body-verified:
//   sub_1802A5260  zltCIIRDenoise -- recursive temporal IIR (EWMA):
//                  out = 0.37*input + 0.63*prev   (alpha = 0.37), param cmd 0x70004.
//   also zltCTemporalDenoise / zltCDenoise / zltCDenoiseASM (SSE/AVX SIMD variants).
// The neural EDNet (CVideoEDNetDenoise_AOM) is a WEIGHTS boundary -- not here.
//
// Temporal IIR trades a little motion trailing for strong random-noise suppression;
// on motion it needs compensation/reset (below: an optional per-pixel motion guard
// that falls back to the input when |in-prev| exceeds a threshold, to limit ghosting).
#pragma once
#include <cstdint>
#include <vector>
#include <cstddef>

namespace recon::zlt {

struct IIRDenoise {
    static constexpr float kAlpha = 0.37f;          // verified EWMA coefficient
    static constexpr int   kParamCmd = 0x70004;     // config command id (evidence anchor)

    float alpha = kAlpha;
    int   motion_guard = 0;   // 0 = pure IIR; >0 = if |in-prev|>guard, pass input (anti-ghost)

    // In-place recursive filter: state holds the previous (filtered) frame; both
    // are 8-bit luma planes of `n` samples. First call: copy input into state.
    void Apply(const uint8_t* in, uint8_t* out, uint8_t* state, size_t n, bool first) const {
        const float a = alpha, b = 1.0f - alpha;
        for (size_t i = 0; i < n; ++i) {
            int prev = state[i];
            int cur  = in[i];
            int v;
            if (first) {
                v = cur;
            } else if (motion_guard && (cur - prev > motion_guard || prev - cur > motion_guard)) {
                v = cur;                              // motion: don't trail, take input
            } else {
                v = int(a * cur + b * prev + 0.5f);   // out = 0.37*in + 0.63*prev
            }
            if (v < 0) v = 0; if (v > 255) v = 255;
            out[i] = uint8_t(v);
            state[i] = uint8_t(v);                    // recursive: feed back the output
        }
    }
};

// Convenience wrapper that owns the recursive state across a frame sequence.
class TemporalDenoiser {
public:
    explicit TemporalDenoiser(IIRDenoise cfg = {}) : cfg_(cfg) {}
    void Filter(const uint8_t* in, uint8_t* out, size_t n) {
        if (state_.size() != n) { state_.assign(n, 0); first_ = true; }
        cfg_.Apply(in, out, state_.data(), n, first_);
        first_ = false;
    }
    void Reset() { first_ = true; }
    const IIRDenoise& config() const { return cfg_; }
private:
    IIRDenoise cfg_;
    std::vector<uint8_t> state_;
    bool first_ = true;
};

} // namespace recon::zlt
