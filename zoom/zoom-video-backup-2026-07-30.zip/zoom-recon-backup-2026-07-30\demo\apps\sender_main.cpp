// sender_main.cpp — the SEND half of the two-process conference. Synthesizes (or would capture) video,
// runs preprocess → H.264 encode (layered) → packetize → FEC, and sends packets over a REAL UDP socket
// to the receiver process. Publishes live stats into shared memory for the WPF monitor. Optional
// congestion control adapts the encoder bitrate to a simulated bottleneck.
//
//   sender [--port P] [--fps F] [--loss P] [--seconds N|0] [--cc --link-kbps N]
#include "apps/ipc_shared.hpp"
#include "apps/ipc_writer.hpp"
#include "conference/media_channel.hpp"
#include "preprocess/video_preprocess.hpp"
#include "encode/h264_encoder.hpp"
#include "protect/packetizer.hpp"
#include "protect/fec.hpp"
#include "transport/socket_transport.hpp"
#include "transport/congestion.hpp"
#include "transport/net_sim.hpp"
#include "capture/capture_factory.hpp"
#include "apps/resample.hpp"              // Zoom VPP scaler (bicubic Catmull-Rom, anti-aliased) for capture->encode
#include <chrono>
#include <cstdio>
#include <cstring>
#include <memory>
#include <thread>

using namespace avp;
using clockt = std::chrono::steady_clock;

static uint32_t g_rng = 0x1234abcd;
static double urand() { g_rng = g_rng * 1664525u + 1013904223u; return (g_rng >> 8) / (double)(1u << 24); }

static VideoFrame synth(int w, int h, int t, bool hi) {
  VideoFrame f; f.width = w; f.height = h; f.stride = w * 4; f.format = PixelFormat::BGRA; f.data.resize((size_t)w * h * 4);
  int cx = (t * 7) % w, cy = (t * 5) % h;
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    uint8_t* p = &f.data[((size_t)y * w + x) * 4];
    int dx = x - cx, dy = y - cy; bool box = (dx * dx + dy * dy) < 1400;
    p[0] = (uint8_t)((x + t * 3) & 0xFF); p[1] = (uint8_t)((y + t * 2) & 0xFF);
    p[2] = box ? 245 : (uint8_t)((x + y) & 0xFF); p[3] = 255;
  }
  if (hi) { uint32_t r = 0x2545F491u * (uint32_t)(t + 1);
    for (int i = 0; i < w * h; ++i) { r = r * 1664525u + 1013904223u; int nz = (int)((r >> 8) % 140) - 70;
      uint8_t* p = &f.data[(size_t)i * 4]; for (int c = 0; c < 3; ++c) { int v = p[c] + nz; p[c] = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v); } } }
  return f;
}

// Aspect-preserving (letterbox) downscale of a captured BGRA frame to the pipeline's fixed size, using
// Zoom's VPP scaler: fit into dw x dh without stretching (black margins), resampling the fitted region
// with a bicubic Catmull-Rom (Keys a=-0.5) polyphase filter whose support widens with the shrink factor
// to anti-alias — the kernel/support reverse-engineered from zlt.dll ns_vpp (see apps/resample.hpp).
static VideoFrame downscale(const VideoFrame& big, int dw, int dh) {
  VideoFrame f; f.width = dw; f.height = dh; f.stride = dw * 4; f.format = PixelFormat::BGRA; f.data.assign((size_t)dw * dh * 4, 0);
  if (big.width <= 0 || big.height <= 0) return f;
  int bs = big.stride ? big.stride : big.width * 4;
  double scale = (double)dw / big.width, sy2 = (double)dh / big.height; if (sy2 < scale) scale = sy2;
  int sw = (int)(big.width * scale), shh = (int)(big.height * scale), ox = (dw - sw) / 2, oy = (dh - shh) / 2;
  if (sw < 1) sw = 1; if (shh < 1) shh = 1;
  std::vector<uint8_t> fit((size_t)sw * shh * 4);
  avp::resample::ResizeBGRA(big.data.data(), big.width, big.height, bs, fit.data(), sw, shh);
  for (int y = 0; y < shh; ++y)
    std::memcpy(&f.data[((size_t)(y + oy) * dw + ox) * 4], &fit[(size_t)y * sw * 4], (size_t)sw * 4);
  return f;
}

int main(int argc, char** argv) {
  int port = 50000, fps = 15; double loss = 0.05, seconds = 0, link_kbps = 800; bool cc_on = false;
  std::string source = "synth";
  for (int i = 1; i < argc; ++i) {
    if (!strcmp(argv[i], "--port") && i + 1 < argc) port = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--fps") && i + 1 < argc) fps = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--loss") && i + 1 < argc) loss = atof(argv[++i]);
    else if (!strcmp(argv[i], "--seconds") && i + 1 < argc) seconds = atof(argv[++i]);
    else if (!strcmp(argv[i], "--source") && i + 1 < argc) source = argv[++i];
    else if (!strcmp(argv[i], "--cc")) cc_on = true;
    else if (!strcmp(argv[i], "--link-kbps") && i + 1 < argc) link_kbps = atof(argv[++i]);
  }
  std::printf("sender: -> 127.0.0.1:%d  source=%s fps=%d loss=%.0f%% cc=%d\n", port, source.c_str(), fps, loss * 100, (int)cc_on);

  // real screen capture (downscaled to the pipeline size) when requested; else synthesized frames.
  std::unique_ptr<IVideoSource> screen; std::string notes;
  if (source == "screen") {
    CaptureConfig cap; screen = CreateBestScreenSource(cap, notes);
    std::printf("sender: screen backend = %s\n", screen ? screen->backend() : notes.c_str());
  }

  WsaScope wsa; UdpSocket tx; if (!tx.open(0)) { std::printf("udp open failed\n"); return 1; }
  ipc::ShmPublisher<ipc::SenderStats> shm;
  if (!shm.open(ipc::kSenderMap())) { std::printf("shm open failed\n"); return 1; }
  shm->magic = ipc::kMagic; shm->width = ipc::kW; shm->height = ipc::kH; shm->fps = fps; shm->loss_pct = (int)(loss * 100); shm->running = 1;
  ipc::ShmReader<ipc::ControlBlock> ctrl; ctrl.open(ipc::kControlMap());   // live control from the monitor (optional)

  VideoPreprocessor pp;
  VideoEncoderConfig ec; ec.width = ipc::kW; ec.height = ipc::kH; ec.fps = fps; ec.bitrate_bps = cc_on ? 2000000 : 1200000;
  ec.temporal_layers = 3; ec.layered_refs = true; ec.gop = 32;   // periodic IDR so lost keyframes recover
  H264Encoder enc; if (!enc.open(ec)) { std::printf("encoder open failed\n"); return 1; }
  Packetizer pk(1100); FecEncoder fenc;
  CongestionController cc(2000000, 100000, 4000000); BottleneckLink link(link_kbps * 1000, 40, 80000); int64_t vclk = 0;

  uint32_t ts = 3000; long bytes = 0; int pkts_sent = 0, fec_sent = 0;
  auto t0 = clockt::now(); const double period = 1.0 / fps;
  for (int i = 0;; ++i) {
    if (seconds > 0 && std::chrono::duration<double>(clockt::now() - t0).count() >= seconds) break;
    // live control: the monitor's sliders take effect here without a restart.
    if (ctrl.valid() && ctrl->magic == ipc::kMagic) {
      loss = ctrl->loss_pct / 100.0;
      cc_on = ctrl->cc_on != 0;
      if (ctrl->link_kbps > 0) link.set_capacity(ctrl->link_kbps * 1000.0);
      if (ctrl->stop) break;
      shm->loss_pct = ctrl->loss_pct;
    }
    VideoFrame frame;
    if (screen) { VideoFrame big; if (screen->grab(big) && big.width > 0) frame = downscale(big, ipc::kW, ipc::kH); else frame = synth(ipc::kW, ipc::kH, i, cc_on); }
    else frame = synth(ipc::kW, ipc::kH, i, cc_on);
    VideoPreprocessResult pr; pp.Process(frame, pr);
    EncodedFrame ef = enc.encode(pr.frame);
    if (ef.size() > 0) {
      auto pkts = pk.packetize(ef.data, ts);
      int level = SelectFecLevel(cc_on ? 0.03 : loss * 1.5);
      auto fecs = fenc.protect(pkts, level, 16);   // multi-group FEC (Zoom §4.1) — 16 source pkts per group
      for (auto& p : pkts) { if (urand() < loss) continue; auto b = wire::serialize(WirePacket{ false, p, {}, p.timestamp }); tx.send_to((uint16_t)port, b.data(), (int)b.size()); ++pkts_sent; bytes += b.size(); }
      for (auto& f : fecs) { if (urand() < loss) continue; WirePacket w{ true, {}, f, ts }; auto b = wire::serialize(w); tx.send_to((uint16_t)port, b.data(), (int)b.size()); ++fec_sent; bytes += b.size(); }

      int cc_target = 0;
      if (cc_on) {
        int intended = (int)(cc.target_bps() / 8.0 / fps); const int psz = 1100; int npk = intended / psz; if (npk < 2) npk = 2;
        int64_t gap = (int64_t)(1000000.0 / fps / npk);
        std::vector<PacketFeedback> fb;
        for (int j = 0; j < npk; ++j) { PacketFeedback f; f.seq = (uint16_t)j; f.size = psz; f.send_time_us = vclk; int64_t rx = 0; link.transmit(psz, f.send_time_us, rx); f.recv_time_us = rx; fb.push_back(f); vclk += gap; }
        cc.on_feedback(fb); enc.set_bitrate((int)cc.target_bps()); cc_target = (int)(cc.target_bps() / 1000);
      }
      shm->frame_index++; shm->encode_kbps = (int)(ef.size() * 8.0 * fps / 1000); shm->cc_target_kbps = cc_target;
      shm->pkts_sent = pkts_sent; shm->fec_sent = fec_sent; shm->bytes_sent = bytes;
      ts += 3000;
    }
    std::this_thread::sleep_until(t0 + std::chrono::duration_cast<clockt::duration>(std::chrono::duration<double>((i + 1) * period)));
  }
  shm->running = 0;
  std::printf("sender: stopped, %d media + %d fec packets sent\n", pkts_sent, fec_sent);
  return 0;
}
