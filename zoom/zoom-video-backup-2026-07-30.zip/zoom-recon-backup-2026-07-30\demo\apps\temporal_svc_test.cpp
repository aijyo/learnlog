// temporal_svc_test.cpp — TEMPORAL SVC, the Zoom mechanism (实证): ONE encode produces a layered bitstream
// where each frame carries a temporal id (TId) and a frame at layer L references only frames at layers <= L.
// So a downstream element (the mcm SFU, or the sender under congestion) can DROP the top temporal layer(s)
// WITHOUT re-encoding and the remaining base still decodes cleanly — at a lower frame rate. Zoom does exactly
// this: recovered `zltCEncodeConfig::temporal_layer_num`, AV1 OBU `temporal_id = (e>>5)&7`, `last_temporal_id`,
// and the log "Codec, ... TId = %d, nFrameRate = %.2f" (TId <-> frame-rate = temporal scalability). avcodec
// can't drive per-frame temporal layers, so — like svc_test (spatial) and ltr_test (LTR) — we use libvpx
// directly. 3 temporal layers, period 4, rate decimators {4,2,1} => operating points 7.5 / 15 / 30 fps from a
// single stream. Proves: dropping T2 (then T1) yields a self-contained lower-fps substream that decodes with
// ZERO broken references, and shows the bitrate each operating point costs (what an SFU forwards per receiver).
#include "preprocess/video_convert.hpp"
#include <cstdio>
#include <cstring>
#include <vector>
extern "C" {
#include "vpx/vpx_encoder.h"
#include "vpx/vp8cx.h"
#include "vpx/vpx_decoder.h"
#include "vpx/vp8dx.h"
#include "vpx/vpx_image.h"
}

using namespace avp;
static const int W = 640, H = 360, FRAMES = 48;         // multiple of the period (4) -> whole temporal cycles
static const int NUM_TL = 3, PERIOD = 4;
static const int kLayerId[PERIOD]   = { 0, 2, 1, 2 };   // canonical 3-TL pattern (WebRTC/Zoom): T0 T2 T1 T2
static const int kDecimator[NUM_TL] = { 4, 2, 1 };      // T0 = 1/4 rate, T0+T1 = 1/2, all = full

// A moving scene so P-frames carry real residual (a static scene would make every frame ~free, hiding cost).
static void fill(vpx_image_t* img, int t) {
  for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
    int v = ((x / 6 + y / 6) & 1) ? 210 : 40;                  // fine checker (high-freq detail)
    if (((x + t * 11) % 200) < 100) v = 128 + ((x + t) % 60);  // moving band -> real inter residual
    img->planes[0][(size_t)y * img->stride[0] + x] = (uint8_t)v;
  }
  for (int p = 1; p <= 2; ++p) for (int y = 0; y < H / 2; ++y)
    memset(img->planes[p] + (size_t)y * img->stride[p], 128, W / 2);
}

struct Enc { std::vector<uint8_t> data; int tid; };

// Decode only the frames whose temporal id <= max_tid (i.e. drop the higher temporal layers), in order, on a
// FRESH decoder. Returns decoded-OK count and sets fail. This is the receiver/SFU that took a lower-fps subset.
static int decode_subset(const std::vector<Enc>& stream, int max_tid, int& fail, long& bytes) {
  vpx_codec_ctx_t dec{}; vpx_codec_dec_init(&dec, vpx_codec_vp9_dx(), nullptr, 0);
  int ok = 0; fail = 0; bytes = 0;
  for (const auto& f : stream) {
    if (f.tid > max_tid) continue;                            // dropped: this layer isn't forwarded
    bytes += (long)f.data.size();
    if (vpx_codec_decode(&dec, f.data.data(), (unsigned)f.data.size(), nullptr, 0) == VPX_CODEC_OK) {
      vpx_codec_iter_t di = nullptr; vpx_image_t* out; bool got = false;
      while ((out = vpx_codec_get_frame(&dec, &di))) got = true;
      if (got) ++ok; else ++fail;
    } else ++fail;
  }
  vpx_codec_destroy(&dec);
  return ok;
}

int main() {
  vpx_codec_ctx_t enc{}; vpx_codec_enc_cfg_t cfg{};
  vpx_codec_enc_config_default(vpx_codec_vp9_cx(), &cfg, 0);
  cfg.g_w = W; cfg.g_h = H; cfg.g_timebase = { 1, 30 }; cfg.rc_target_bitrate = 800;
  cfg.rc_end_usage = VPX_CBR; cfg.g_lag_in_frames = 0; cfg.g_error_resilient = 1;
  cfg.kf_mode = VPX_KF_DISABLED; cfg.kf_max_dist = 99999;    // no auto keyframes: prove the LAYERING, not GOPs
  // Temporal SVC config: 3 layers, 4-frame period, rate decimators {4,2,1}. Cumulative per-layer bitrate.
  cfg.ss_number_layers = 1;
  cfg.ts_number_layers = NUM_TL; cfg.ts_periodicity = PERIOD;
  for (int i = 0; i < PERIOD; ++i) cfg.ts_layer_id[i] = kLayerId[i];
  for (int i = 0; i < NUM_TL; ++i) cfg.ts_rate_decimator[i] = kDecimator[i];
  cfg.ts_target_bitrate[0] = cfg.rc_target_bitrate * 2 / 4;  // T0     ~ 50%
  cfg.ts_target_bitrate[1] = cfg.rc_target_bitrate * 3 / 4;  // T0+T1  ~ 75%
  cfg.ts_target_bitrate[2] = cfg.rc_target_bitrate;          // all    = 100%
  if (vpx_codec_enc_init(&enc, vpx_codec_vp9_cx(), &cfg, 0)) { std::printf("enc init failed\n"); return 1; }
  vpx_codec_control(&enc, VP8E_SET_CPUUSED, 8);
  vpx_codec_control(&enc, VP9E_SET_SVC, 1);                  // enable SVC so libvpx manages the layered refs
  vpx_image_t img; vpx_img_alloc(&img, VPX_IMG_FMT_I420, W, H, 1);

  std::vector<Enc> stream; long bytes_tl[NUM_TL] = { 0, 0, 0 }; int cnt_tl[NUM_TL] = { 0, 0, 0 };

  std::printf("\n  TEMPORAL SVC — VP9, 3 temporal layers (Zoom zlt temporal_layer_num / AV1 OBU temporal_id / \"TId\").\n");
  std::printf("  pattern T0 T2 T1 T2 (period 4, decimators 4/2/1); ONE encode -> drop top layers for lower fps.\n");
  std::printf("  ------------------------------------------------------------------------------------------------\n");

  for (int t = 0; t < FRAMES; ++t) {
    fill(&img, t);
    int tid = kLayerId[t % PERIOD];
    vpx_svc_layer_id_t lid{}; lid.spatial_layer_id = 0; lid.temporal_layer_id = tid;
    vpx_codec_control(&enc, VP9E_SET_SVC_LAYER_ID, &lid);    // tell libvpx which temporal layer this frame is
    vpx_enc_frame_flags_t flags = (t == 0) ? VPX_EFLAG_FORCE_KF : 0;   // one seed keyframe
    if (vpx_codec_encode(&enc, &img, t, 1, flags, VPX_DL_REALTIME)) { std::printf("encode %d failed: %s\n", t, vpx_codec_error_detail(&enc)); return 1; }
    vpx_codec_iter_t it = nullptr; const vpx_codec_cx_pkt_t* pkt;
    while ((pkt = vpx_codec_get_cx_data(&enc, &it))) {
      if (pkt->kind != VPX_CODEC_CX_FRAME_PKT) continue;
      Enc e; e.tid = tid; e.data.assign((const uint8_t*)pkt->data.frame.buf, (const uint8_t*)pkt->data.frame.buf + pkt->data.frame.sz);
      bytes_tl[tid] += (long)e.data.size(); ++cnt_tl[tid];
      stream.push_back(std::move(e));
    }
  }
  vpx_img_free(&img); vpx_codec_destroy(&enc);

  // Three receivers/operating points, each a FRESH decoder taking a different temporal subset from the SAME stream.
  int fail0, fail1, fail2; long b0, b1, b2;
  int ok0 = decode_subset(stream, 0, fail0, b0);   // T0 only        -> 7.5 fps
  int ok1 = decode_subset(stream, 1, fail1, b1);   // T0+T1          -> 15 fps
  int ok2 = decode_subset(stream, 2, fail2, b2);   // T0+T1+T2 (all) -> 30 fps
  int fwd0 = ok0 + fail0, fwd1 = ok1 + fail1, fwd2 = ok2 + fail2;   // frames actually forwarded to each

  std::printf("  per-layer encoded:  T0 = %d frames / %ld B    T1 = %d / %ld B    T2 = %d / %ld B\n",
              cnt_tl[0], bytes_tl[0], cnt_tl[1], bytes_tl[1], cnt_tl[2], bytes_tl[2]);
  std::printf("  ------------------------------------------------------------------------------------------------\n");
  std::printf("  operating point        forwarded frames   decoded OK   fail   bitrate (of full)\n");
  std::printf("  T0 only     (7.5 fps)   %3d / %d            %3d          %d      %ld B  (%.0f%%)\n",
              fwd0, FRAMES, ok0, fail0, b0, b2 ? 100.0 * b0 / b2 : 0);
  std::printf("  T0+T1      (15 fps)     %3d / %d            %3d          %d      %ld B  (%.0f%%)\n",
              fwd1, FRAMES, ok1, fail1, b1, b2 ? 100.0 * b1 / b2 : 0);
  std::printf("  T0+T1+T2   (30 fps)     %3d / %d            %3d          %d      %ld B  (100%%)\n",
              fwd2, FRAMES, ok2, fail2, b2);
  std::printf("  ------------------------------------------------------------------------------------------------\n");
  bool clean = (fail0 == 0) && (fail1 == 0) && (fail2 == 0) && ok0 > 0 && ok1 > ok0 && ok2 > ok1;
  std::printf("  => %s: each temporal subset decoded with ZERO broken references — a downstream (mcm SFU / the\n",
              clean ? "SUCCESS" : "FAILURE");
  std::printf("     sender under congestion) drops T2 then T1 to shed frame-rate + bitrate from ONE encode, and the\n");
  std::printf("     base keeps decoding. That is Zoom's temporal scalability (TId <-> nFrameRate).\n");
  return clean ? 0 : 1;
}
