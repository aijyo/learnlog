import idc, ida_hexrays, ida_funcs, idautils
out=idc.ARGV[1]
try: ida_hexrays.init_hexrays_plugin()
except Exception: pass
L=[]
def d(ea,label):
    f=ida_funcs.get_func(ea)
    if not f: L.append("// NO FUNC 0x%x %s"%(ea,label)); return
    try:
        L.append("\n// ===== %s %s (0x%x) ====="%(label,idc.get_func_name(f.start_ea),f.start_ea))
        L.append(str(ida_hexrays.decompile(f.start_ea)))
    except Exception as e: L.append("// FAIL 0x%x: %s"%(ea,e))
def vt(addr,label,nd=4):
    slots=[]; ea=addr
    for i in range(12):
        p=idc.get_qword(ea)
        if not ida_funcs.get_func(p): break
        slots.append(p); ea+=8
    L.append("\n// ==== %s vtable 0x%x: %d slots ===="%(label,addr,len(slots)))
    for i,s in enumerate(slots): L.append("//  [%d] 0x%x %s"%(i,s,idc.get_func_name(s)))
    seen=set()
    for i,s in enumerate(slots[:nd]):
        if s in seen: continue
        seen.add(s); d(s,"%s.slot%d"%(label,i))
vt(0x180501520,"StaticDetection",5)
vt(0x180501600,"MotionMaskDetect",5)
vt(0x180504a08,"FlashDetection",5)
open(out,"w",encoding="utf-8",errors="replace").write("\n".join(L))
idc.qexit(0)
