// adaptive_qp_test.cpp — proves the reconstructed zlt adaptive-QP map (§3.3 TextureMotion) actually
// steers the encoder when injected. A camera-like frame = a SMOOTH subject ellipse over a BUSY textured
// background. The VideoPreprocessor computes Zoom's per-block QP-delta (flat->negative, busy->positive);
// we then encode the same frame with libx264 (zlt) at the SAME bitrate, once WITHOUT the map (encoder's
// own AQ) and once WITH set_qp_map(). Injecting it should move bits onto the smooth subject (the eye's
// focus) and off the busy background — i.e. subject-region luma PSNR goes UP, background PSNR goes DOWN.
#include "encode/vp9_screen.hpp"          // ScreenCodec factory (H264 -> ZltAvc libx264)
#include "encode/h264_decode_verify.hpp"  // PsnrY
#include "preprocess/video_preprocess.hpp"
#include "preprocess/video_convert.hpp"
#include "capture/video_frame.hpp"
#include <cmath>
#include <cstdio>
#include <vector>

using namespace avp;
static const int W = 1280, H = 720, FPS = 15, KBPS = 800, N = 8;
// subject ellipse (smooth) centered; the rest is busy texture.
static const int CX = W / 2, CY = H / 2, RX = 200, RY = 260;

static VideoFrame make_frame() {
  VideoFrame f; f.width = W; f.height = H; f.stride = W * 4; f.format = PixelFormat::BGRA; f.data.resize((size_t)W * H * 4);
  uint32_t r = 0x2468;
  auto rnd = [&]{ r = r * 1664525u + 1013904223u; return (int)((r >> 16) & 0xFF); };
  for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
    double dx = (x - CX) / (double)RX, dy = (y - CY) / (double)RY, d = dx * dx + dy * dy;
    int v;
    if (d < 1.0) v = (int)(150 + 40 * (1.0 - d));                 // subject: smooth gradient (low variance)
    else v = (rnd() & 1) ? 30 + (rnd() % 40) : 200 + (rnd() % 40); // background: busy high-contrast noise
    uint8_t g = (uint8_t)(v < 0 ? 0 : v > 255 ? 255 : v);
    uint8_t* p = &f.data[((size_t)y * W + x) * 4]; p[0] = p[1] = p[2] = g; p[3] = 255;
  }
  return f;
}
// mean luma PSNR over a rectangle
static double psnr_rect(const I420Image& a, const I420Image& b, int x0, int y0, int x1, int y1) {
  double mse = 0; long n = 0;
  for (int y = y0; y < y1; ++y) for (int x = x0; x < x1; ++x) { double e = (double)a.y[(size_t)y*W+x] - b.y[(size_t)y*W+x]; mse += e*e; ++n; }
  mse /= (n ? n : 1); return mse < 1e-9 ? 99.0 : 10.0 * std::log10(255.0*255.0/mse);
}

static void run(bool inject, const std::vector<int>& qp, int bw, int bh, const I420Image& src, double& subj, double& bg) {
  auto enc = MakeScreenEncoder(ScreenCodec::H264); auto dec = MakeScreenDecoder(ScreenCodec::H264);
  ScreenEncParams sp; sp.width = W; sp.height = H; sp.fps = FPS; sp.kbps = KBPS; sp.gop = 1000; sp.screen_content = false;
  sp.ext_qp_map = inject;   // inject=true -> codec AQ off, Zoom's map rules; false -> encoder's own AQ
  enc->open(sp); dec->open();
  I420Image out;
  for (int i = 0; i < N; ++i) {
    if (inject) enc->set_qp_map(qp, bw, bh, 16);
    std::vector<uint8_t> au; bool key = false; enc->encode(src, i == 0, au, key);
    if (!au.empty()) dec->decode(au, out);
  }
  subj = psnr_rect(src, out, CX - RX, CY - RY, CX + RX, CY + RY);
  bg   = psnr_rect(src, out, 0, 0, 200, 200);   // a busy background corner
}

int main() {
  VideoFrame fr = make_frame(); I420Image src; BgraToI420(fr, src);
  VideoPreprocessConfig cfg; cfg.denoise = false; cfg.adaptive_qp = true; cfg.raisr = false;
  VideoPreprocessor pp(cfg); VideoPreprocessResult pr; pp.Process(fr, pr);
  int neg = 0, pos = 0; for (int d : pr.qp_delta) { if (d < 0) ++neg; if (d > 0) ++pos; }
  std::printf("\n  Adaptive-QP injection A/B  (%dx%d, %d kbps; smooth subject over busy background)\n", W, H, KBPS);
  std::printf("  zlt TextureMotion map: %d blocks, %d flat(-QP) / %d busy(+QP)\n", (int)pr.qp_delta.size(), neg, pos);
  std::printf("  --------------------------------------------------------------\n");
  double s0, b0, s1, b1;
  run(false, pr.qp_delta, pr.qp_bw, pr.qp_bh, src, s0, b0);
  run(true,  pr.qp_delta, pr.qp_bw, pr.qp_bh, src, s1, b1);
  std::printf("  %-26s subject %6.2f dB   background %6.2f dB\n", "encoder default AQ", s0, b0);
  std::printf("  %-26s subject %6.2f dB   background %6.2f dB\n", "+ injected zlt QP map", s1, b1);
  std::printf("  --------------------------------------------------------------\n");
  std::printf("  subject gain from injection: %+.2f dB  (bits steered onto the subject)\n\n", s1 - s0);
  return 0;
}
