// =============================================================================
//  av1_bitstream.hpp -- self-contained AV1 IVF/OBU/sequence-header parser.
//  ORIGINAL clean-room C++17 from the public AV1 spec (AOMedia AV1 1.0.0).  No
//  external deps -- this is the offline-runnable half of the AV1 decode path and
//  the faithful reconstruction of the *parsing* logic we verified in zbt.dll
//  (zbtCObuHdrParser / sub_1801CFA10 seq header / sub_1801D0AA0 frame header).
//
//  It parses container + OBU structure + resolution + frame types.  Pixel decode
//  (the DSP) is delegated to a real AV1 decoder (dav1d) in av1_dav1d_decoder.hpp;
//  a conformant decoder decodes Zoom's AV1 regardless of which encoder produced
//  it, because the *bitstream* is standard AV1.
// =============================================================================
#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <string>

namespace recon::codec::av1 {

// ---- MSB-first bit reader (AV1 f(n)) ---------------------------------------
class BitReader {
public:
    BitReader(const uint8_t* p, size_t n) : p_(p), n_(n) {}
    uint32_t f(int bits) {                 // read `bits` MSB-first
        uint32_t v = 0;
        for (int i = 0; i < bits; ++i) {
            v <<= 1;
            if (bitpos_ < n_ * 8) {
                v |= (p_[bitpos_ >> 3] >> (7 - (bitpos_ & 7))) & 1;
                ++bitpos_;
            } else { overran_ = true; }
        }
        return v;
    }
    bool overran() const { return overran_; }
private:
    const uint8_t* p_; size_t n_; size_t bitpos_ = 0; bool overran_ = false;
};

// ---- uleb128 (OBU size) -----------------------------------------------------
inline bool Uleb128(const uint8_t* p, size_t n, size_t& off, uint64_t& out) {
    out = 0;
    for (int i = 0; i < 8; ++i) {
        if (off >= n) return false;
        uint8_t b = p[off++];
        out |= (uint64_t)(b & 0x7F) << (7 * i);
        if (!(b & 0x80)) return true;
    }
    return false;
}

// ---- OBU types (AV1 spec 6.2.2) --------------------------------------------
enum class ObuType : int {
    SequenceHeader = 1, TemporalDelimiter = 2, FrameHeader = 3, TileGroup = 4,
    Metadata = 5, Frame = 6, RedundantFrameHeader = 7, TileList = 8,
    Padding = 15, Reserved = 0
};
inline const char* ObuName(ObuType t) {
    switch (t) {
        case ObuType::SequenceHeader:       return "SEQUENCE_HEADER";
        case ObuType::TemporalDelimiter:    return "TEMPORAL_DELIMITER";
        case ObuType::FrameHeader:          return "FRAME_HEADER";
        case ObuType::TileGroup:            return "TILE_GROUP";
        case ObuType::Metadata:             return "METADATA";
        case ObuType::Frame:                return "FRAME";
        case ObuType::RedundantFrameHeader: return "REDUNDANT_FRAME_HEADER";
        case ObuType::TileList:             return "TILE_LIST";
        case ObuType::Padding:              return "PADDING";
        default:                            return "RESERVED";
    }
}
enum class FrameType { Key, Inter, IntraOnly, Switch, ShowExisting, Unknown };
inline const char* FrameTypeName(FrameType f) {
    switch (f) { case FrameType::Key:return "KEY"; case FrameType::Inter:return "INTER";
        case FrameType::IntraOnly:return "INTRA_ONLY"; case FrameType::Switch:return "SWITCH";
        case FrameType::ShowExisting:return "SHOW_EXISTING"; default:return "?"; }
}

struct Obu {
    ObuType  type = ObuType::Reserved;
    int      temporal_id = 0, spatial_id = 0;
    size_t   payload_off = 0, payload_len = 0;
};

struct SequenceHeader {
    bool     ok = false;
    int      seq_profile = 0;
    bool     reduced_still_picture = false;
    uint32_t max_width = 0, max_height = 0;
};

// ---- sequence header: recover profile + max dimensions (spec 5.5.1) --------
// Implements the real-time-video paths (reduced-still-picture, and full path
// with no timing-info / decoder-model).  Enough for resolution; bails honestly
// on the rarer paths rather than mis-parsing.
inline SequenceHeader ParseSequenceHeader(const uint8_t* p, size_t n) {
    SequenceHeader s; BitReader r(p, n);
    s.seq_profile = (int)r.f(3);
    /*still_picture*/ r.f(1);
    s.reduced_still_picture = r.f(1) != 0;
    if (s.reduced_still_picture) {
        r.f(5);                                   // seq_level_idx[0]
    } else {
        uint32_t timing = r.f(1);                 // timing_info_present_flag
        if (timing) { s.ok = false; return s; }   // (RT video: 0) bail if present
        /*initial_display_delay_present*/ uint32_t idd = r.f(1);
        uint32_t op_cnt = r.f(5);                  // operating_points_cnt_minus_1
        for (uint32_t i = 0; i <= op_cnt; ++i) {
            r.f(12);                               // operating_point_idc[i]
            uint32_t level = r.f(5);               // seq_level_idx[i]
            if (level > 7) r.f(1);                 // seq_tier[i]
            if (idd) { if (r.f(1)) r.f(4); }       // initial_display_delay
        }
    }
    int wbits = (int)r.f(4) + 1;                   // frame_width_bits_minus_1
    int hbits = (int)r.f(4) + 1;                   // frame_height_bits_minus_1
    s.max_width  = r.f(wbits) + 1;                 // max_frame_width_minus_1
    s.max_height = r.f(hbits) + 1;                 // max_frame_height_minus_1
    s.ok = !r.overran();
    return s;
}

// ---- classify a FRAME / FRAME_HEADER OBU (spec 5.9.1, RT sub-case) ----------
inline FrameType ClassifyFrame(const uint8_t* p, size_t n, const SequenceHeader& seq) {
    if (seq.reduced_still_picture) return FrameType::Key;
    BitReader r(p, n);
    if (r.f(1)) return FrameType::ShowExisting;    // show_existing_frame
    switch (r.f(2)) {                              // frame_type
        case 0: return FrameType::Key;   case 1: return FrameType::Inter;
        case 2: return FrameType::IntraOnly; case 3: return FrameType::Switch;
    }
    return FrameType::Unknown;
}

// ---- iterate low-overhead OBU stream (obu_has_size_field == 1) --------------
// Returns the OBUs; also fills seq/frame-type summary via callbacks-free scan.
inline bool ParseObuStream(const uint8_t* p, size_t n, std::vector<Obu>& out) {
    size_t off = 0;
    while (off < n) {
        uint8_t h = p[off++];
        if (h & 0x80) return false;                // forbidden bit
        Obu o;
        o.type = (ObuType)((h >> 3) & 0xF);
        bool ext = (h >> 2) & 1;
        bool has_size = (h >> 1) & 1;
        if (ext) {                                 // extension header byte
            if (off >= n) return false;
            uint8_t e = p[off++];
            o.temporal_id = (e >> 5) & 7;
            o.spatial_id  = (e >> 3) & 3;
        }
        uint64_t sz;
        if (has_size) {
            if (!Uleb128(p, n, off, sz)) return false;
        } else {
            sz = n - off;                          // last OBU consumes remainder
        }
        if (off + sz > n) return false;
        o.payload_off = off; o.payload_len = (size_t)sz;
        out.push_back(o);
        off += (size_t)sz;
    }
    return true;
}

// ---- IVF container header (DKIF) -------------------------------------------
struct IvfHeader { bool ok=false; char fourcc[5]={0}; uint16_t width=0, height=0; uint32_t frames=0; };
inline uint16_t rd16(const uint8_t* p){ return (uint16_t)(p[0] | (p[1]<<8)); }
inline uint32_t rd32(const uint8_t* p){ return (uint32_t)(p[0] | (p[1]<<8) | (p[2]<<16) | ((uint32_t)p[3]<<24)); }
inline IvfHeader ParseIvfHeader(const uint8_t* p, size_t n) {
    IvfHeader h;
    if (n < 32 || p[0]!='D'||p[1]!='K'||p[2]!='I'||p[3]!='F') return h;
    h.fourcc[0]=p[8];h.fourcc[1]=p[9];h.fourcc[2]=p[10];h.fourcc[3]=p[11];
    h.width  = rd16(p+12);
    h.height = rd16(p+14);
    h.frames = rd32(p+24);
    h.ok = true;
    return h;
}

} // namespace recon::codec::av1
