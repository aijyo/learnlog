// =============================================================================
//  av1_dav1d_decoder.hpp -- pixel-decode backend for recon::zbt::IAv1Decoder,
//  implemented against the dav1d C API (BSD-2-Clause; AV1 is royalty-free).
//
//  Because Zoom's AV1 (zbt.dll, proprietary encoder core zbtCScEncoderCore) emits
//  a STANDARD AV1 OBU bitstream (confirmed: the zbt OBU/seq/frame parser matches
//  the AV1 spec), any conformant decoder decodes it bit-exactly.  So this dav1d
//  adapter is an *interop-exact* decode of real Zoom AV1 -- the well-defined sense
//  of "1:1" for a decoder.
//
//  Gated behind RECON_WITH_DAV1D so the core project keeps building with zero
//  external deps.  Enable via the RECON_WITH_CODECS CMake option (which fetches
//  dav1d).  dav1d builds with meson + nasm.
// =============================================================================
#pragma once
#include "recon/zbt_av1_codec.hpp"
#include "recon/codec/av1_bitstream.hpp"
#include <vector>
#include <cstring>

#if defined(RECON_WITH_DAV1D)
#include <dav1d/dav1d.h>

namespace recon::codec::av1 {

// Implements the interface we reverse-engineered from zbt.dll.
class Dav1dDecoder : public recon::zbt::IAv1Decoder {
public:
    Dav1dDecoder() {
        Dav1dSettings s; dav1d_default_settings(&s);
        s.n_threads = 1;                 // deterministic for bit-exact comparison
        if (dav1d_open(&ctx_, &s) != 0) ctx_ = nullptr;
    }
    ~Dav1dDecoder() override { if (ctx_) dav1d_close(&ctx_); }

    // Decode one temporal unit of OBUs -> NV12 in `nv12`. Returns bytes written, <0 on error.
    int Decode(const uint8_t* obu, size_t n, uint8_t* nv12, size_t cap) override {
        if (!ctx_ || !obu || !n) return -1;
        Dav1dData data{};
        uint8_t* buf = dav1d_data_create(&data, n);
        if (!buf) return -1;
        std::memcpy(buf, obu, n);
        int r = dav1d_send_data(ctx_, &data);
        if (r < 0 && r != DAV1D_ERR(EAGAIN)) { dav1d_data_unref(&data); return -1; }

        Dav1dPicture pic{};
        r = dav1d_get_picture(ctx_, &pic);
        if (r < 0) { dav1d_data_unref(&data); last_ = recon::zbt::Av1ParseError::FrameHeader; return 0; }

        int w = pic.p.w, h = pic.p.h;
        size_t need = (size_t)w * h * 3 / 2;                  // NV12
        int written = 0;
        if ((size_t)need <= cap) {
            // Y plane
            const uint8_t* sy = (const uint8_t*)pic.data[0];
            for (int y = 0; y < h; ++y) std::memcpy(nv12 + (size_t)y * w, sy + (size_t)y * pic.stride[0], w);
            // interleave U,V (I420 -> NV12)
            const uint8_t* su = (const uint8_t*)pic.data[1];
            const uint8_t* sv = (const uint8_t*)pic.data[2];
            uint8_t* duv = nv12 + (size_t)w * h;
            for (int y = 0; y < h / 2; ++y)
                for (int x = 0; x < w / 2; ++x) {
                    duv[(size_t)y * w + 2 * x]     = su[(size_t)y * pic.stride[1] + x];
                    duv[(size_t)y * w + 2 * x + 1] = sv[(size_t)y * pic.stride[1] + x];
                }
            written = (int)need;
            last_ = recon::zbt::Av1ParseError::Ok;
        }
        last_w_ = w; last_h_ = h;
        dav1d_picture_unref(&pic);
        dav1d_data_unref(&data);
        return written;
    }
    recon::zbt::Av1ParseError last_parse_error() const override { return last_; }
    int width()  const { return last_w_; }
    int height() const { return last_h_; }

private:
    Dav1dContext* ctx_ = nullptr;
    recon::zbt::Av1ParseError last_ = recon::zbt::Av1ParseError::Ok;
    int last_w_ = 0, last_h_ = 0;
};

} // namespace recon::codec::av1
#endif // RECON_WITH_DAV1D
