#pragma once
// zlt_content_analysis.hpp -- CLEAN-ROOM reconstruction of Zoom's screen-content analysis
// cluster (the "video-in-share" detector): find the sub-region of a screen share that is a
// PLAYING VIDEO, so it can be encoded motion-optimized while the surrounding text/UI stays sharp.
//
// This is an ORIGINAL implementation of the analyzed algorithm (not a transcription). What was
// recovered maps to a family of cooperating stages:
//   * an async orchestrator that runs the analysis off the encode critical path (worker thread);
//   * a container configured for two low-res analysis scales (320x180 and 160x90), a 256px minimum
//     region size, and a ~30-frame temporal window, double-buffered for frame-to-frame comparison;
//   * a per-16x16-block MOTION-LABEL map (label 7 == "moving"); the exact per-block metric that
//     assigns labels is produced upstream in the encoder's block analysis -- see BOUNDARY below;
//   * a BOUNDING-BOX derivation by projecting "moving" blocks onto column/row histograms and
//     finding the sustained-motion band;  a GLOBAL-MOTION guard that rejects whole-frame motion
//     (camera pan);  and a REGION-CONFIRM test with fixed density/count thresholds;
//   * companion detectors: a static-region detector (adaptive threshold vs a 3072*cols reference),
//     a downscale+mask stage, and a global flash detector.
//
// FIDELITY:
//   [exact]  block projection + sustained-band scan (col>=5, row>=10, gap tol <8, min ~5),
//            box = band*16px;  region confirm: box>256x256 & not full-frame,
//            video iff 12*moving >= total (>=8.33%) AND moving >= 30 blocks;
//            static shortcut: <=15 blocks -> all-active;  static ref = 3072*block_cols.
//   [推断]   the per-16x16-block motion metric/label (upstream block analysis; BlockMotionLabel
//            below is a plausible frame-difference stand-in), and the global-motion guard's exact
//            axis-count math (GlobalMotionGuard here is a faithful-behavior approximation).
#include <cstdint>
#include <vector>
#include <array>
#include <cstddef>

namespace recon { namespace zlt {

// ---- configuration recovered from the container (analysis scales / min region / window) ----
struct ContentAnalysisConfig {
    int  analysis_w0 = 320, analysis_h0 = 180;   // primary low-res analysis scale
    int  analysis_w1 = 160, analysis_h1 = 90;    // secondary (coarser) scale
    int  block = 16;                             // 16x16 analysis block grid
    int  min_region_px = 256;                    // a video region must exceed this in each dim
    int  temporal_window = 30;                   // frames of hysteresis
    int  frame_edge_guard = 64;                  // region must sit >=64px inside the frame edge
};

// Block motion labels. Only label 7 ("moving") drives the projection; 6..9 form the motion band
// that the confirm step counts. Everything else is treated as static/text.
enum : uint8_t { LBL_STATIC = 0, LBL_MOVING = 7 };

struct VideoRegion { bool found = false; int x = 0, y = 0, w = 0, h = 0; };

// [推断] per-16x16-block motion label from a frame difference (stand-in for the upstream metric).
// Real Zoom labels come from the encoder's per-block motion analysis; here: mean abs frame diff
// over the block -> LBL_MOVING(7) when it exceeds a small activity threshold, else LBL_STATIC(0).
inline void BlockMotionLabel(const uint8_t* y, const uint8_t* prev, int w, int h, int block,
                             int bw, int bh, std::vector<uint8_t>& lbl, int move_thresh = 6) {
    lbl.assign((size_t)bw * bh, LBL_STATIC);
    if (!prev) return;
    for (int by = 0; by < bh; ++by)
        for (int bx = 0; bx < bw; ++bx) {
            long sad = 0; int n = 0;
            for (int j = 0; j < block; ++j) {
                int yy = by * block + j; if (yy >= h) break;
                for (int i = 0; i < block; ++i) {
                    int xx = bx * block + i; if (xx >= w) break;
                    size_t o = (size_t)yy * w + xx;
                    int d = int(y[o]) - int(prev[o]); sad += d < 0 ? -d : d; ++n;
                }
            }
            int m = n ? int(sad / n) : 0;
            lbl[(size_t)by * bw + bx] = (m >= move_thresh) ? LBL_MOVING : LBL_STATIC;
        }
}

// [exact] scan a projection histogram for the sustained band: return {startIndex, endIndex}
// (block units). A bin counts as "high" when hist[i] >= hi_thresh; we require ~5 highs to lock an
// edge and tolerate gaps < 8 low bins inside the band (morphological closing). fwd=false scans
// from the far end (to find the opposite edge).
inline int ScanBandEdge(const std::vector<int>& hist, int hi_thresh, bool fwd, int limit) {
    int highs = 0, gap = 0, edge = fwd ? (limit - 1) : 0, start = -1;
    for (int k = 0; k < limit; ++k) {
        int idx = fwd ? k : (limit - 1 - k);
        if (hist[idx] >= hi_thresh) {
            if (start < 0) start = idx;         // remember where the band began
            gap = 0;
            if (++highs >= 5) break;            // band locked
        } else if (start >= 0) {
            if (++gap >= 8) { start = -1; highs = 0; gap = 0; }  // band broken, restart
        }
    }
    return start >= 0 ? start : edge;
}

// [exact] derive the candidate video-region bounding box from the block label map.
inline VideoRegion DeriveMotionBox(const std::vector<uint8_t>& lbl, int bw, int bh, int block) {
    std::vector<int> col(bw, 0), row(bh, 0);
    for (int by = 0; by < bh; ++by)
        for (int bx = 0; bx < bw; ++bx)
            if (lbl[(size_t)by * bw + bx] == LBL_MOVING) { ++col[bx]; ++row[by]; }
    int left   = ScanBandEdge(col, 5,  true,  bw);   // columns: high >= 5 moving blocks
    int right  = ScanBandEdge(col, 5,  false, bw);
    int top    = ScanBandEdge(row, 10, true,  bh);   // rows: high >= 10 moving blocks
    int bottom = ScanBandEdge(row, 10, false, bh);
    VideoRegion r;
    r.x = 16 * left; r.y = 16 * top;
    r.w = 16 * (right  - left); if (r.w < 0) r.w = 0;
    r.h = 16 * (bottom - top);  if (r.h < 0) r.h = 0;
    return r;
}

// [推断] global-motion guard: if the "moving" band spans almost the whole frame on both axes,
// it's a camera pan / full-frame video, not a video-in-share -> reject region detection.
inline bool GlobalMotionGuard(const std::vector<uint8_t>& lbl, int bw, int bh) {
    long moving = 0; for (uint8_t v : lbl) moving += (v == LBL_MOVING);
    long total = (long)bw * bh;
    return total && moving * 100 >= total * 80;      // >=80% of blocks moving == global motion
}

// [exact] confirm the box is a genuine video region:
//   box exceeds min size and sits inside the frame edge, and within the box
//   moving-block density >= 1/12 (8.33%) AND absolute moving-block count >= 30.
inline VideoRegion DetectVideoRegion(const uint8_t* y, const uint8_t* prev, int w, int h,
                                     const ContentAnalysisConfig& cfg = {}) {
    VideoRegion none;
    if (w < 32 || h < 32 || !prev) return none;
    const int block = cfg.block, bw = (w + block - 1) / block, bh = (h + block - 1) / block;
    std::vector<uint8_t> lbl;
    BlockMotionLabel(y, prev, w, h, block, bw, bh, lbl);
    if (GlobalMotionGuard(lbl, bw, bh)) return none;               // camera pan -> no share-region

    VideoRegion r = DeriveMotionBox(lbl, bw, bh, block);
    if (r.w <= cfg.min_region_px || r.h <= cfg.min_region_px) return none;
    if (!(r.x + r.w < w - cfg.frame_edge_guard || r.y + r.h < h - cfg.frame_edge_guard)) return none;

    long moving = 0, cells = 0;                                    // count within the box
    int bx0 = r.x / block, by0 = r.y / block, bx1 = (r.x + r.w) / block, by1 = (r.y + r.h) / block;
    for (int by = by0; by < by1 && by < bh; ++by)
        for (int bx = bx0; bx < bx1 && bx < bw; ++bx) {
            ++cells;
            if (lbl[(size_t)by * bw + bx] == LBL_MOVING) ++moving;
        }
    if (12 * moving >= cells && moving >= 30) { r.found = true; return r; }
    return none;
}

// ---- StaticDetection: per-16x16-block "is this a static/flat frame" test ------------------
// [exact behavior] <=15 blocks -> treat whole frame as active (label 7); otherwise compute a
// per-block activity sum and compare an adaptive normalizer to a 3072*block_cols reference.
struct StaticDetection {
    static constexpr int kRefPerCol = 3072;     // static reference = 3072 * block_cols
    // returns true if the frame is judged static (below the activity reference).
    bool IsStatic(const uint8_t* y, const uint8_t* prev, int w, int h, int block = 16) const {
        int bw = (w + block - 1) / block, bh = (h + block - 1) / block;
        if ((long)bw * bh <= 15) return false;               // tiny grid -> "active" shortcut
        long activity = 0;
        for (int by = 0; by < bh; ++by)
            for (int bx = 0; bx < bw; ++bx) {
                long sad = 0;
                for (int j = 0; j < block; ++j) { int yy = by*block+j; if (yy>=h) break;
                    for (int i = 0; i < block; ++i) { int xx = bx*block+i; if (xx>=w) break;
                        size_t o = (size_t)yy*w+xx; int d = prev ? int(y[o])-int(prev[o]) : 0;
                        sad += d<0?-d:d; } }
                activity += sad;
            }
        long ref = (long)kRefPerCol * bw;
        return activity < ref;                               // below reference -> static
    }
};

}} // namespace recon::zlt
