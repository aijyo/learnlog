// =============================================================================
//  viperex_runtime.hpp -- viperex.dll: identity + RECOVERED control/scheduling
//  surface + a runnable model-container codec.  ORIGINAL clean-room C++17.
//
//  *** CORRECTED after decompiling the control path (was mislabeled). ***
//  viperex.dll is NOT a SNAC/DRED audio codec (earlier guess).  It is Zoom's
//  "Companion Mic" ML FEATURE ENGINE for viper: speaker-embedding (CAM++),
//  active-speaker / overlapped-speech detection ("Picknet"/OSD), and lipsync,
//  all run through OpenVINO.  ~64 MB of the 69.8 MB file is trained model
//  weights (embedded, obfuscated -- see below); those weights ARE the neural
//  behavior and are not reconstructable.  But the ORCHESTRATION around them is
//  fully recovered from function bodies and modeled here (some pieces runnable).
//
//  Evidence (viperex.dll, IDA/Hex-Rays):
//   - viperex_init      0x1800141F0  captures 2 host cfg ptrs (@+288,+296) once,
//                                    returns an API vtable (off_182B15000).
//   - viperex_version   0x180014230  strcpy "7.1.0.41345".
//   - OpenVINO bind     0x180179AF0  SetDllDirectoryW + LoadLibraryW("openvino_c.dll")
//                                    + ~19 GetProcAddress (bind the OpenVINO C API).
//   - model loader      0x180171020  FindResourceW(type "BIN") of
//                                    "embedding_model_xml_bin" / "osd_model_xml_bin",
//                                    LoadResource/LockResource, then the container
//                                    decode below (8B LE xml-length header + xml|bin,
//                                    every byte XOR 0xA7).
//   - worker thread     0x180014C60  _beginthreadex (1 MB stack) + priority map
//                                    {1:-1,2:0,3:1,4:2,5:15} (SetThreadPriority).
//   - periodic tick     0x180014820  WINMM timeSetEvent(period,0,cb,0, 0x21|0x10);
//                                    timeKillEvent on restart (0x21 = periodic).
//   - feature pipeline  0x18010AF30 -> 0x18010B6A0  16 kHz mono; each 1.5 s chunk
//                                    (24000 samples) EMA-smooths the Picknet score
//                                    (threshold-selected alpha), accumulates a 3 s
//                                    (48000-sample) window, then runs CAM++
//                                    ExtractEmbedding under a mutex; records a
//                                    (meeting_time, CAM++, Picknet, Picknet_Smoothed)
//                                    timeline; meeting_time += 1.5 s per chunk.
//   - lipsync           0x18003D8D0  lipsync_model_calculator.cpp (separate model).
// =============================================================================
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <cstddef>

namespace recon::viperex {

inline constexpr const char* kVersion = "7.1.0.41345";   // viperex_version

// --- export ABI loader (how viper.dll binds viperex) -------------------------
extern "C" {
    typedef int32_t     (*Fn_viperex_init)(void* hostCfg /*opaque; +288/+296 read*/,
                                           void** outApi /*receives vtable*/);
    typedef const char* (*Fn_viperex_version)(char* buf128);
}
class ViperexModule {
public:
    bool Load(const wchar_t* dllPath);       // LoadLibrary + GetProcAddress
    void Unload();
    bool ok() const { return module_ && init_ && version_; }
private:
    void*              module_  = nullptr;   // HMODULE
    Fn_viperex_init    init_    = nullptr;
    Fn_viperex_version version_ = nullptr;
};

// --- embedded-model container codec (sub_180171020) -- RUNNABLE --------------
// The OpenVINO IR (model.xml + model.bin) is stored in one PE "BIN" resource:
//   bytes[0..7]   = uint64 little-endian length of the XML part, each byte ^0xA7
//   bytes[8..]    = (xml bytes)(bin bytes), every byte ^0xA7
// This is plain XOR+length framing (no model IP); the codec round-trips.
struct ModelResourceCodec {
    static constexpr uint8_t kXorKey = 0xA7;

    // Body-verified in sub_180171020: models are NOT encrypted -- just single-byte
    // XOR 0xA7 obfuscation (no AES/CryptDecrypt/key). Stored as PE resources of type
    // L"BIN"; the decoded xml+bin is a standard OpenVINO IR loadable by core.read_model.
    static constexpr const wchar_t* kEmbeddingModel = L"embedding_model_xml_bin"; // CAM++
    static constexpr const wchar_t* kOsdModel       = L"osd_model_xml_bin";       // Picknet/OSD

    static bool Decode(const uint8_t* res, size_t n,
                       std::vector<uint8_t>& xml, std::vector<uint8_t>& bin) {
        if (!res || n < 8) return false;
        uint64_t xmlLen = 0;
        for (int i = 0; i < 8; ++i)
            xmlLen |= (uint64_t)(uint8_t)(res[i] ^ kXorKey) << (8 * i);
        size_t payload = n - 8;
        if (xmlLen > payload) return false;
        size_t binLen = payload - (size_t)xmlLen;
        xml.resize((size_t)xmlLen);
        bin.resize(binLen);
        for (size_t i = 0; i < (size_t)xmlLen; ++i) xml[i] = res[8 + i] ^ kXorKey;
        for (size_t i = 0; i < binLen; ++i)          bin[i] = res[8 + (size_t)xmlLen + i] ^ kXorKey;
        return true;
    }

    static std::vector<uint8_t> Encode(const std::vector<uint8_t>& xml,
                                       const std::vector<uint8_t>& bin) {
        std::vector<uint8_t> out(8 + xml.size() + bin.size());
        uint64_t xmlLen = xml.size();
        for (int i = 0; i < 8; ++i)
            out[i] = (uint8_t)((xmlLen >> (8 * i)) & 0xFF) ^ kXorKey;
        for (size_t i = 0; i < xml.size(); ++i) out[8 + i] = xml[i] ^ kXorKey;
        for (size_t i = 0; i < bin.size(); ++i) out[8 + xml.size() + i] = bin[i] ^ kXorKey;
        return out;
    }
};

// --- worker-thread priority map (sub_180014C60) ------------------------------
enum class WorkerPriority { BelowNormal = 1, Normal = 2, AboveNormal = 3, Highest = 4, TimeCritical = 5 };
inline int ToWin32ThreadPriority(WorkerPriority p) {
    switch (p) {                       // == the switch in sub_180014C60
        case WorkerPriority::BelowNormal:  return -1;
        case WorkerPriority::Normal:       return  0;
        case WorkerPriority::AboveNormal:  return  1;
        case WorkerPriority::Highest:      return  2;
        case WorkerPriority::TimeCritical: return 15;
    }
    return 0;
}
inline constexpr uint32_t kWorkerStackBytes = 0x100000;  // 1 MB (_beginthreadex arg)

// --- periodic multimedia-timer tick (sub_180014820) --------------------------
struct TimerConfig {
    uint32_t period_ms = 0;
    bool     periodic  = true;         // true => timeSetEvent flags 0x21, else 0x10
    unsigned Flags() const { return periodic ? 0x21u : 0x10u; }
};

// --- feature-pipeline constants (sub_18010AF30 / sub_18010B6A0) --------------
struct PipelineConstants {
    static constexpr int   kSampleRate    = 16000;  // mono
    static constexpr int   kChunkSamples  = 24000;  // 1.5 s working chunk
    static constexpr int   kCampWindow    = 48000;  // 3.0 s CAM++ input window
    static constexpr float kChunkSeconds  = 1.5f;   // meeting_time increment
    static constexpr float kActiveThresh  = 5.0f;   // picknet_smoothed > 5 => "active"
};

// --- runtime interface (weights behind it; features CORRECTED to reality) ----
struct IViperexRuntime {
    virtual ~IViperexRuntime() = default;
    virtual bool LoadModels() = 0;                       // decode+feed the 2 IR models to OpenVINO
    // CAM++ speaker embedding on a 3 s / 48000-sample window:
    virtual int  ExtractSpeakerEmbedding(const int16_t* pcm48k, size_t n, float* emb, size_t dim) = 0;
    virtual float CompareToEnrolled(const float* emb, size_t dim) = 0;   // enrollment match score
    // active-speaker / overlapped-speech ("Picknet"/OSD) score for a chunk:
    virtual float PicknetScore(const int16_t* pcm, size_t n) = 0;
    // lipsync feature (lipsync_model_calculator):
    virtual int  LipsyncFeature(const int16_t* pcm, size_t n, float* out, size_t cap) = 0;
};
// Concrete impl intentionally omitted: it drives OpenVINO over the (licensed,
// XOR-0xA7-obfuscated) embedded IR models -- weights are not reconstructable.

} // namespace recon::viperex
