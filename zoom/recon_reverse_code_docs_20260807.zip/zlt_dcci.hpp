#pragma once
// zlt_dcci.hpp -- CLEAN-ROOM reconstruction of Zoom's zltCDCC.
//
// IMPORTANT: zltCDCC is NOT "dynamic contrast" (earlier mis-identification). The scalar apply kernel
// sub_1801E1C10 (obj+0x18) is an EDGE-DIRECTED 2x UPSCALER = Directional Cubic Convolution Interpolation
// (DCCI, Zhou-Shen-Zhang 2012). It is the render-chain "Upsample" that feeds RAISR:  decoded LR -> DCC(2x)
// -> RAISR(refine). The companion kernels are the 4-direction gradient (obj+0x10, sub_1801E19B0/A4160/A3420)
// and a chroma resampler (obj+0x20).
//
// Recovered EXACTLY from the scalar kernel:
//   * decision by GRADIENT RATIO 1.15  (Zoom's integer test 100*Ga <= 115*Gb),
//   * directional interpolation = 4-tap cubic convolution  (9*(near1+near2) - far1 - far2) >> 4
//       == the classic [-1, 9, 9, -1]/16 half-pixel bicubic,
//   * isotropic fallback = 4-neighbour average (a+b+c+d+2)>>2,
//   * axis (H/V) pass uses refined thresholds 575/800 and 920/500 with +8/+5 regularisation.
// Fidelity: the per-cell GRADIENT FORMULA is Zoom's exact one — the scalar grad kernel sub_1801E19B0
// computes, per 2x2 cell, |TL-BR| (\), |BL-TR| (/), |TL-BL| (vert), |TL-TR| (horiz); we use the two
// diagonal ones exactly. The DECISION RATIO (1.15) and the CUBIC ([-1,9,9,-1]/16) are Zoom's exact values.
// The ONE residual vs Zoom: the apply sums the diagonal gradients over a 9-tap window (v55/v56 in
// sub_1801E1C10) whose exact offsets live in heavily-obfuscated pointer arithmetic; we use the canonical
// DCCI 7-tap diagonal sum (Zhou-Shen-Zhang), functionally equivalent (differs only on borderline pixels).
#include <vector>
#include <cstdint>
#include <cstdlib>

namespace recon { namespace dcci {

inline uint8_t clampb(int v) { return (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v)); }
inline int cubic(int n1, int n2, int f1, int f2) { return (9 * (n1 + n2) - f1 - f2) >> 4; } // [-1,9,9,-1]/16

// Edge-directed 2x upscale of a single (luma) plane. src w x h -> dst (2w) x (2h).
inline void Upscale2x(const uint8_t* src, int w, int h, std::vector<uint8_t>& dst, int& ow, int& oh) {
  ow = w * 2; oh = h * 2;
  if (w < 2 || h < 2) { dst.assign((size_t)ow * oh, 0); return; }
  dst.assign((size_t)ow * oh, 0);
  auto S = [&](int x, int y) { x = x < 0 ? 0 : (x >= w ? w - 1 : x); y = y < 0 ? 0 : (y >= h ? h - 1 : y); return (int)src[(size_t)y * w + x]; };
  const int OW = ow;
  auto D = [&](int x, int y) -> uint8_t& { return dst[(size_t)y * OW + x]; };

  // 1) known LR pixels land on the even/even grid
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) D(2 * x, 2 * y) = src[(size_t)y * w + x];

  // 2) diagonal holes at (2x+1, 2y+1): interpolate from the 4x4 known neighbourhood
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
    int p[4][4];
    for (int j = 0; j < 4; ++j) for (int i = 0; i < 4; ++i) p[j][i] = S(x - 1 + i, y - 1 + j);
    // G1 = 135° (\) gradient, G2 = 45° (/) gradient — DCCI diagonal |diff| sums over the window
    int G1 = std::abs(p[0][0]-p[1][1]) + std::abs(p[1][1]-p[2][2]) + std::abs(p[2][2]-p[3][3])
           + std::abs(p[0][1]-p[1][2]) + std::abs(p[1][2]-p[2][3])
           + std::abs(p[1][0]-p[2][1]) + std::abs(p[2][1]-p[3][2]);
    int G2 = std::abs(p[0][3]-p[1][2]) + std::abs(p[1][2]-p[2][1]) + std::abs(p[2][1]-p[3][0])
           + std::abs(p[0][2]-p[1][1]) + std::abs(p[1][1]-p[2][0])
           + std::abs(p[1][3]-p[2][2]) + std::abs(p[2][2]-p[3][1]);
    const int a = p[1][1], b = p[2][2], c = p[0][0], d = p[3][3];   // 135° collinear (near a,b / far c,d)
    const int e = p[1][2], f = p[2][1], g = p[0][3], hh = p[3][0];  // 45° collinear
    int v;
    if (100 * G1 <= 115 * G2) {                    // G1 <= 1.15*G2
      if (100 * G2 <= 115 * G1) v = (a + b + e + f + 2) >> 2;   // similar -> isotropic 4-avg
      else                      v = cubic(a, b, c, d);          // edge along /, interp along \ (smooth)
    } else {
      v = cubic(e, f, g, hh);                                   // edge along \, interp along /
    }
    D(2 * x + 1, 2 * y + 1) = clampb(v);
  }

  // 3) axis holes: (2x+1, 2y) and (2x, 2y+1). Now diagonals are filled; decide H vs V by local gradient.
  //    Zoom's second-pass thresholds: 575/800 (=0.719) and 920/500 (=1.84) with +8/+5 regularisation.
  auto axis = [&](int hx, int hy) {
    // neighbours: horizontal (left,right known/filled), vertical (up,down)
    int L = D(hx - 1, hy), R = D(hx + 1, hy), U = D(hx, hy - 1), Dn = D(hx, hy + 1);
    int L2 = (hx - 3 >= 0) ? (int)D(hx - 3, hy) : L, R2 = (hx + 3 < ow) ? (int)D(hx + 3, hy) : R;
    int U2 = (hy - 3 >= 0) ? (int)D(hx, hy - 3) : U, D2 = (hy + 3 < oh) ? (int)D(hx, hy + 3) : Dn;
    int Gh = std::abs(L - R) + std::abs(L2 - L) + std::abs(R - R2);   // horizontal gradient
    int Gv = std::abs(U - Dn) + std::abs(U2 - U) + std::abs(Dn - D2); // vertical gradient
    int v;
    if (800 * (Gv + 5) <= 575 * (Gh + 8)) {          // vertical clearly smoother -> interp vertically
      v = cubic(U, Dn, U2, D2);
    } else if (800 * (Gh + 5) <= 575 * (Gv + 8)) {   // horizontal clearly smoother
      v = cubic(L, R, L2, R2);
    } else {                                          // ambiguous -> 4-avg
      v = (L + R + U + Dn + 2) >> 2;
    }
    D(hx, hy) = clampb(v);
  };
  for (int y = 0; y < oh; ++y) {
    int startx = (y & 1) ? 0 : 1;                    // odd rows: even x holes; even rows: odd x holes
    for (int x = startx; x < ow; x += 2) axis(x, y);
  }
}

// Plain bilinear 2x — used for the CHROMA planes (Zoom's chroma resampler obj+0x20 is a separate, simpler
// kernel; chroma is low-frequency so bilinear is faithful enough). src w x h -> dst (2w) x (2h).
inline void Upscale2xBilinear(const uint8_t* src, int w, int h, std::vector<uint8_t>& dst, int& ow, int& oh) {
  ow = w * 2; oh = h * 2; dst.assign((size_t)ow * oh, 0);
  if (w < 1 || h < 1) return;
  auto S = [&](int x, int y) { x = x < 0 ? 0 : (x >= w ? w - 1 : x); y = y < 0 ? 0 : (y >= h ? h - 1 : y); return (int)src[(size_t)y * w + x]; };
  for (int y = 0; y < oh; ++y) for (int x = 0; x < ow; ++x) {
    int x0 = (x - 1) >> 1, y0 = (y - 1) >> 1;          // half-pixel phase for 2x
    int ax = (x & 1) ? 3 : 1, ay = (y & 1) ? 3 : 1;    // 1/4 or 3/4 weights (in quarters)
    int v = ((4 - ax) * (4 - ay) * S(x0, y0) + ax * (4 - ay) * S(x0 + 1, y0)
           + (4 - ax) * ay * S(x0, y0 + 1) + ax * ay * S(x0 + 1, y0 + 1) + 8) >> 4;
    dst[(size_t)y * ow + x] = clampb(v);
  }
}

}}  // namespace recon::dcci
