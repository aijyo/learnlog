// conti_session.hpp — clean-room reconstruction of zContinuityMedia.dll's IConti* RPC
// session/handoff layer, driving the REAL protobuf messages (continuity_media.pb.h,
// compiled by the real protoc 3.21.12 and linked against the real libprotobuf).
//
// Body-verified anchors (zContinuityMedia.dll):
//   ns_continuity_media::ContiMediaClient::Connect(IContiClientSink*)         -> RegisterRequest
//   ns_continuity_media::ContiClientMessage::SendMediaRequest(cb, MediaActionReq_MessageType, uint, uint)
//   ns_continuity_media::RequestProcessor::ProcessRequest(RPCRequest const&, void*, cb)
//   ns_continuity_media::ContiMediaServer::Start(IContiServer::InitInfo const&, IContiServerSink*)
//   ns_continuity_media::ContiMediaServer::OnRegisteredDevice(uint, MediaDeviceRegisterInfoProto const&)
//   factories: CreateContiMediaClient / CreateContiMediaServer
//
// The RPCRequest envelope carries a serialized inner message (RegisterReq / MediaActionReq),
// exactly matching the recovered RPCRequest shape (payload = field 5, LEN).
#pragma once
#include "continuity_media.pb.h"
#include <string>
#include <functional>
#include <cstdint>

namespace recon { namespace conti {

namespace pb = us::zoom::continuitymedia;

// RPCRequest.type (envelope field 4) — RequestProcessor::ProcessRequest dispatches on it.
// Exact integer values are inferred; the field itself is body-verified (varint, field 4).
enum RpcType : uint32_t {
  RPC_UNKNOWN           = 0,
  RPC_REGISTER          = 1,
  RPC_REGISTER_RESP     = 2,
  RPC_MEDIA_ACTION      = 3,
  RPC_MEDIA_ACTION_RESP = 4,
};

// ---- IConti* callback interfaces (reconstructed from the RTTI vtables) ----
struct IContiClientSink {
  virtual ~IContiClientSink() = default;
  virtual void OnRegisterResult(int result, uint32_t assigned_id) {}
  virtual void OnMediaActionResult(int result, const std::string& body) {}
};
struct IContiServerSink {
  virtual ~IContiServerSink() = default;
  // ContiMediaServer::OnRegisteredDevice(uint deviceId, MediaDeviceRegisterInfoProto const&)
  virtual bool OnRegisteredDevice(uint32_t device_id, const pb::MediaDeviceRegisterInfoProto& info) { return true; }
  virtual void OnMediaAction(pb::MediaActionReq_MessageType type, const std::string& body) {}
};

// Build an RPCRequest envelope carrying a serialized inner message — REAL protobuf serialize.
inline std::string make_envelope(const std::string& service, const std::string& method,
                                 const std::string& req_id, uint32_t type,
                                 const std::string& payload) {
  pb::RPCRequest env;
  env.set_service(service);
  env.set_method(method);
  env.set_req_id(req_id);
  env.set_type(type);
  env.set_payload(payload);
  std::string out;
  env.SerializeToString(&out);   // real libprotobuf
  return out;
}

// ---- ns_continuity_media::ContiMediaClient ----
struct ContiMediaClient {
  IContiClientSink* sink_ = nullptr;
  uint32_t seq_ = 0;
  std::function<std::string(const std::string&)> transport_;  // send req bytes -> resp bytes

  // ContiMediaClient::Connect(IContiClientSink*) — builds a RegisterReq, envelopes + sends it.
  int Connect(IContiClientSink* sink, const pb::MediaDeviceRegisterInfoProto& dev) {
    sink_ = sink;
    pb::RegisterReq reg;
    *reg.mutable_device() = dev;
    std::string payload;
    reg.SerializeToString(&payload);
    std::string req = make_envelope("conti", "Register",
                                    "req-" + std::to_string(++seq_), RPC_REGISTER, payload);
    std::string resp = transport_ ? transport_(req) : std::string();
    return handle_response(resp);
  }

  // ContiClientMessage::SendMediaRequest(cb, MediaActionReq_MessageType, uint, uint)
  int SendMediaRequest(pb::MediaActionReq_MessageType type, uint32_t flags, const std::string& body) {
    pb::MediaActionReq act;
    act.set_seq(++seq_);
    act.set_flags(flags);
    act.set_type(type);
    act.set_body(body);
    std::string payload;
    act.SerializeToString(&payload);
    std::string req = make_envelope("conti", "MediaAction",
                                    "req-" + std::to_string(seq_), RPC_MEDIA_ACTION, payload);
    std::string resp = transport_ ? transport_(req) : std::string();
    return handle_response(resp);
  }

  int handle_response(const std::string& bytes) {
    if (bytes.empty()) return -1;
    pb::RPCRequest env;
    if (!env.ParseFromString(bytes)) return -2;       // real libprotobuf parse
    if (env.type() == RPC_REGISTER_RESP) {
      pb::RegisterReq::Resp r; r.ParseFromString(env.payload());
      if (sink_) sink_->OnRegisterResult(r.result(), r.assigned_id());
    } else if (env.type() == RPC_MEDIA_ACTION_RESP) {
      pb::MediaActionReq::Resp r; r.ParseFromString(env.payload());
      if (sink_) sink_->OnMediaActionResult(r.result(), r.body());
    }
    return 0;
  }
};

// ---- ns_continuity_media::ContiMediaServer + RequestProcessor ----
struct ContiMediaServer {
  IContiServerSink* sink_ = nullptr;
  uint32_t next_device_id_ = 100;

  void Start(IContiServerSink* sink) { sink_ = sink; }   // ContiMediaServer::Start

  // RequestProcessor::ProcessRequest(RPCRequest const&, ...) — parse envelope, dispatch, respond.
  std::string ProcessRequest(const std::string& bytes) {
    pb::RPCRequest env;
    if (!env.ParseFromString(bytes)) return {};
    switch (env.type()) {
      case RPC_REGISTER: {
        pb::RegisterReq reg; reg.ParseFromString(env.payload());
        uint32_t did = next_device_id_++;
        bool ok = sink_ ? sink_->OnRegisteredDevice(did, reg.device()) : true;   // OnRegisteredDevice
        pb::RegisterReq::Resp resp;
        resp.set_result(ok ? 0 : -1);
        resp.set_assigned_id(did);
        std::string p; resp.SerializeToString(&p);
        return make_envelope("conti", "Register", env.req_id(), RPC_REGISTER_RESP, p);
      }
      case RPC_MEDIA_ACTION: {
        pb::MediaActionReq act; act.ParseFromString(env.payload());
        if (sink_) sink_->OnMediaAction(act.type(), act.body());
        pb::MediaActionReq::Resp resp;
        resp.set_result(0);
        resp.set_body("ack");
        std::string p; resp.SerializeToString(&p);
        return make_envelope("conti", "MediaAction", env.req_id(), RPC_MEDIA_ACTION_RESP, p);
      }
      default: return {};
    }
  }
};

}} // namespace recon::conti
