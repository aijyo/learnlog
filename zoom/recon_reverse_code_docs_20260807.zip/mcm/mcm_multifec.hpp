// mcm_multifec.hpp — clean-room reconstruction of mcm.dll's multi-layer FEC.
//
// Evidence (mcm.dll / viper build string):
//   * telemetry "total_decoded_3rd_4th_5th_fec_packets" + "cur_fec_packets_ratio"
//     => a LAYERED FEC with protection levels 3 / 4 / 5 (packets of FEC per group).
//   * Opus build string "1.3.1-fixed-extrafec-maxlbrr-multifec-dred" => in-band LBRR
//     FEC + an extra multi-layer FEC on top (this file = the multi-layer part).
//
// Reconstruction: level L in {3,4,5} = number of FEC (parity) packets per source group;
// higher measured loss -> higher level. Level *naming* (3/4/5) is EXACT from the binary;
// the loss thresholds are inferred. The GF(256) Reed-Solomon engine is the nydus-verified
// recon/algo/rs_fec.hpp (poly 0x11D) — reused, not re-derived.
#pragma once
#include "../algo/rs_fec.hpp"
#include <cstdint>
#include <vector>

namespace recon { namespace mcm {

// Loss-rate -> protection level. Thresholds inferred; the 3/4/5 tiering is from the binary.
struct MultiFecPolicy {
    static int SelectLevel(double loss_rate) {     // loss_rate in [0,1]
        if (loss_rate < 0.05) return 3;            // 3rd-level FEC
        if (loss_rate < 0.10) return 4;            // 4th-level FEC
        return 5;                                  // 5th-level FEC (heavy loss)
    }
};

struct FecShard { std::vector<uint8_t> data; bool is_parity = false; };

// One media group: K source packets + `level` parity packets (RS over GF256).
class MultiFecGroup {
public:
    MultiFecGroup(const std::vector<uint8_t>& payload, int k, int level)
        : k_(k), level_(level), orig_len_((uint32_t)payload.size()) {
        shard_len_ = (uint32_t)((payload.size() + k - 1) / k);
        if (shard_len_ == 0) shard_len_ = 1;
        std::vector<std::vector<uint8_t>> data(k_, std::vector<uint8_t>(shard_len_, 0));
        for (uint32_t i = 0; i < payload.size(); ++i)
            data[i / shard_len_][i % shard_len_] = payload[i];
        recon::algo::RsFec rs(k_, level_);
        auto parity = rs.Encode(data);
        for (auto& d : data)   shards_.push_back({ std::move(d), false });
        for (auto& p : parity) shards_.push_back({ std::move(p), true });
    }

    int      n() const { return k_ + level_; }
    int      k() const { return k_; }
    int      level() const { return level_; }
    uint32_t orig_len() const { return orig_len_; }
    uint32_t shard_len() const { return shard_len_; }
    const std::vector<FecShard>& shards() const { return shards_; }

    // Recover the original payload from a lossy set of shards (present[i]=false => lost).
    // Returns empty if fewer than K shards survived (unrecoverable).
    static std::vector<uint8_t> Recover(const std::vector<FecShard>& shards,
                                        const std::vector<char>& present,
                                        int k, int level, uint32_t orig_len, uint32_t shard_len) {
        std::vector<std::vector<uint8_t>> raw(shards.size());
        for (size_t i = 0; i < shards.size(); ++i)
            raw[i] = present[i] ? shards[i].data : std::vector<uint8_t>(shard_len, 0);
        recon::algo::RsFec rs(k, level);
        if (!rs.Decode(raw, present)) return {};      // < K survived
        std::vector<uint8_t> out;
        out.reserve((size_t)k * shard_len);
        for (int i = 0; i < k; ++i) out.insert(out.end(), raw[i].begin(), raw[i].end());
        out.resize(orig_len);
        return out;
    }

private:
    int k_, level_;
    uint32_t orig_len_, shard_len_;
    std::vector<FecShard> shards_;
};

}} // namespace recon::mcm
