// mcm_channel.hpp — the mcm media-channel ORCHESTRATOR: ties together the four facets
// the mcm function-map describes into one decision loop:
//   通道编排 (MediaChannel)  +  QoS/MOS (G.107)  +  多层FEC策略 (MultiFecPolicy)  +  带宽分配
// so a single QoS tick drives: metrics -> MOS -> net-score -> bw-level + FEC level.
//
// Body-verified anchors (mcm.dll):
//   sub_1801642D0     per-user audio MOS (ITU-T G.107 E-model): R->MOS polynomial +
//                     delay-impairment curve (breakpoints 100/500/1000/2000/3500 ms)
//   sub_18009CC20     MCM_NW_WARNING network-warning trigger (double-threshold hysteresis)
//   app_uplink_net_score_t (PDU 85)  net_score 0..5 / bw_level 1..4
//   QoS report (cmd 301): cur_packets_loss_rate / cur_fec_packets_ratio / cur_plc_packets_ratio /
//                         cur_jitter_ms / abs_net_delay_ms
//   score-report throttle ~9800 ms (0x2648)
//
// ============================================================================================
// CONGESTION CONTROL — how it ACTUALLY works (T4, RE'd 2025-07) [实证 architecture]
// ------------------------------------------------------------------------------------------
// Zoom video rate control is NOT a client-side Google Congestion Control. Exhaustive scans of
// mcm.dll and nydus.dll found NO trendline estimator, NO overuse detector, NO AIMD rate
// controller (those WebRTC-GCC symbols/algorithms are simply absent). Instead it is a
// SERVER-MEDIATED, DISCRETE-LEVEL scheme:
//   1) client (receiver) MEASURES raw per-stream QoS (the cmd-301 metrics above);
//   2) a discrete decision -> net_score in {0..5} and bw_level in {1..4} (+ receiver max_loss_rate,
//      app_receiver_max_loss_rate_t). The metric->score/level MAPPING is config/server-driven:
//      NO client function computes it — mcm only ROUTES the value. (Config hooks: Configrate*.)
//   3) FEEDBACK travels as app_uplink_net_score_t = ssb PDU id 85 [实证 sub_18000D600 sets
//      *(pdu+8)=85, net_score dword at +24, byte flag +28, property "mc_up_bw_level" in {1,2,3,4}];
//      parsed by sub_180041360 (net_score 0..5 switch), routed/stored per-stream by THREE identical
//      nodes sub_180057A10 / sub_1800D8310 / sub_1801D09A0 (stream keyed by a red-black tree on
//      value>>10; slots [10..13] = {net_score,bw_level} per direction);
//   4) SENDER applies bw_level -> target bitrate -> zltCVideoRateCtrl (recon/zlt_rate_control.hpp,
//      complexity->QP) ; loss_rate -> MultiFecPolicy FEC level 3/4/5.
// Client-side audio MOS (sub_1801642D0, G.107) is telemetry / NW_WARNING only (audio-domain).
//
// CONSEQUENCE for this recon: the metric->net_score thresholds and bw_level->kbps table are a
// genuine RE BOUNDARY (server/config, not in the client) — NOT recoverable and NOT invented here.
// ScoreFromMos / BwFromScore below are OUR behavioral STAND-IN so the local demo (which has no
// Zoom MMR) can still adapt; they are [推断/placeholder], explicitly NOT Zoom's real thresholds.
// ============================================================================================
//
// [实证]=recovered from bodies; [推断]=inferred shape.
#pragma once
#include "mcm_multifec.hpp"     // MultiFecPolicy
#include <cstdint>
#include <cmath>
#include <string>
#include <vector>
#include <utility>

namespace recon { namespace mcm {

// ---- QoS metrics carried by the mcm QoS report (cmd 301) [实证 keys] ----
struct AudioQosMetrics {
  double   loss_rate        = 0.0;   // cur_packets_loss_rate (0..1)
  double   fec_ratio        = 0.0;   // cur_fec_packets_ratio (fraction recovered by FEC)
  double   plc_ratio        = 0.0;   // cur_plc_packets_ratio (fraction concealed)
  uint32_t jitter_ms        = 0;     // cur_jitter_ms
  uint32_t abs_net_delay_ms = 0;     // abs_net_delay_ms
};

// ---- ITU-T G.107 E-model delay impairment Id (sub_1801642D0) [实证 — EXACT piecewise, log-based] ----
// Recovered bit-exact from the decompiled float math (NOT linear interpolation, which was an earlier approx).
// Breakpoints 100/500/1000/2000/3500 ms; the first two segments carry log2 terms, the rest linear w/ the
// slopes below; capped at 60. (0x64/0x1F4/0x3E8/0x7D0/0xDAC = 100/500/1000/2000/3500.)
inline double DelayImpairment(uint32_t d_ms) {
  double d = (double)d_ms;
  if (d <= 100.0)  return 0.0;
  if (d <= 500.0)  return std::log2(d / 100.0)              + (d - 100.0) / 55.0;                    // log2(d/100) + (d-100)/55
  if (d <= 1000.0) return 2.0 * std::log2((d - 400.0)/100.0) + 0.01  * (d - 500.0)  + 9.6;            // 2·log2((d-400)/100) + 0.01(d-500) + 9.6
  if (d <= 2000.0) return 0.008 * (d - 1000.0) + 19.8;
  if (d <= 3500.0) return 0.006 * (d - 2000.0) + 27.8;
  double id = 0.008 * (d - 3500.0) + 36.8;
  return id < 60.0 ? id : 60.0;
}
inline double RtoMos(double R) {                       // published G.107 formula
  if (R <= 0)   return 1.0;
  if (R >= 100) return 4.5;
  return 1.0 + 0.035*R + R*(R - 60.0)*(100.0 - R)*7.0e-6;
}
inline double EstimateMos(double R_base, uint32_t delay_ms, int* R_x10 = nullptr) {
  double R = R_base - DelayImpairment(delay_ms);
  if (R < 0) R = 0; else if (R > 93.2) R = 93.2;       // recovered clamp
  if (R_x10) *R_x10 = int(R * 10.0);
  return RtoMos(R);
}
// Base transmission rating R0 from loss/FEC/PLC. [推断 shape]: residual loss after FEC
// impairs R; PLC softens but does not fully hide it.
inline double BaseRfactor(const AudioQosMetrics& m) {
  double residual = m.loss_rate * (1.0 - m.fec_ratio);        // FEC recovers a fraction
  double R = 93.2 - residual*100.0*2.5 - m.plc_ratio*100.0*0.8;
  return R < 0 ? 0 : R;
}

// ---- uplink net-score 0..5 / bw-level 1..4 (app_uplink_net_score_t = ssb PDU id 85) ----
// [实证 wire format] PDU id=85; net_score is a dword (range 0..5, per sub_180041360's switch);
// bw_level rides as the property "mc_up_bw_level" in {1,2,3,4}. Constants below are bit-confirmed.
enum class NetScore : uint8_t { S0=0,S1,S2,S3,S4,S5 };
enum class BwLevel  : uint8_t { L1=1,L2,L3,L4 };
static constexpr uint16_t kPduUplinkNetScore = 85;              // [实证] sub_18000D600: *(pdu+8)=85
static constexpr const char* kPropBwLevel    = "mc_up_bw_level"; // [实证] property key, values {1,2,3,4}
// NOTE: the two mappings below are OUR demo STAND-IN for Zoom's server-side decision (see the
// congestion-control block at the top of this file). Zoom's client does NOT compute net_score from
// MOS — the real thresholds live server/config-side and are not in any client binary. [推断/placeholder]
inline NetScore ScoreFromMos(double mos) {             // [推断/placeholder — NOT Zoom's thresholds]
  if (mos >= 4.2) return NetScore::S5;
  if (mos >= 3.9) return NetScore::S4;
  if (mos >= 3.5) return NetScore::S3;
  if (mos >= 3.0) return NetScore::S2;
  if (mos >= 2.5) return NetScore::S1;
  return NetScore::S0;
}
inline BwLevel BwFromScore(NetScore s) {               // [推断/placeholder — NOT Zoom's mapping]
  switch (s) {
    case NetScore::S5: case NetScore::S4: return BwLevel::L4;
    case NetScore::S3:                    return BwLevel::L3;
    case NetScore::S2:                    return BwLevel::L2;
    default:                              return BwLevel::L1;
  }
}

// ---- MCM_NW_WARNING (sub_18009CC20) double-threshold hysteresis ----
class NetWarning {
public:
  // warn on when mos < on_thr; only clear when mos recovers above off_thr (>on_thr).
  bool Update(double mos, double on_thr = 3.0, double off_thr = 3.4) {
    bool prev = active_;
    if (!active_ && mos < on_thr)  active_ = true;
    else if (active_ && mos > off_thr) active_ = false;
    return active_ != prev;   // true == state changed (emit telemetry)
  }
  bool active() const { return active_; }
private:
  bool active_ = false;
};

// ---- bandwidth distribution by bw_level weight (bandwidth_distribute_info) ----
struct StreamBudget { uint32_t id; BwLevel level; uint32_t assigned_bps; };
inline std::vector<StreamBudget>
DistributeBandwidth(uint32_t total_bps, const std::vector<std::pair<uint32_t,BwLevel>>& streams) {
  uint32_t wsum = 0; for (auto& s : streams) wsum += uint32_t(s.second);
  std::vector<StreamBudget> out;
  for (auto& s : streams) {
    uint32_t w = uint32_t(s.second);
    out.push_back({ s.first, s.second, wsum ? uint32_t(uint64_t(total_bps)*w/wsum) : 0 });
  }
  return out;
}

// ---- the orchestrator: one QoS tick -> the whole adaptation decision ----
struct ChannelDecision {
  double   mos = 0;
  int      r_x10 = 0;
  NetScore score = NetScore::S5;
  BwLevel  bw = BwLevel::L4;
  int      fec_level = 3;       // 3/4/5 — from MultiFecPolicy, applied by mcm_multifec
  bool     warning = false;     // MCM_NW_WARNING active
  bool     warning_changed = false;
};

class MediaChannel {
public:
  static constexpr uint32_t kScoreReportPeriodMs = 9800;  // recovered throttle (~0x2648)
  static constexpr int      kQosCmd = 301;

  // ties: QoS metrics -> MOS -> net-score -> bw-level  +  loss -> FEC level.
  ChannelDecision OnQosTick(const AudioQosMetrics& m) {
    ChannelDecision d;
    d.mos       = EstimateMos(BaseRfactor(m), m.abs_net_delay_ms, &d.r_x10);
    d.score     = ScoreFromMos(d.mos);
    d.bw        = BwFromScore(d.score);
    d.fec_level = MultiFecPolicy::SelectLevel(m.loss_rate);     // <- the 3/4/5 FEC decision
    d.warning_changed = warn_.Update(d.mos);
    d.warning   = warn_.active();
    last_ = d;
    return d;
  }
  const ChannelDecision& last() const { return last_; }

  void AddStream(uint32_t id, BwLevel lvl) { streams_.push_back({id, lvl}); }
  std::vector<StreamBudget> Distribute(uint32_t total_bps) const {
    return DistributeBandwidth(total_bps, streams_);
  }

private:
  NetWarning warn_;
  ChannelDecision last_;
  std::vector<std::pair<uint32_t,BwLevel>> streams_;
};

}} // namespace recon::mcm
