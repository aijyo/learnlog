// ffmpeg_codec.hpp — the REAL third-party codec for the mcm slice.
//
// mcm.dll drives a customized FFmpeg (it loads "avcodec_zm61.dll"); where mcm hands a
// media frame to the codec, this slice calls the REAL FFmpeg avcodec (vcpkg FFmpeg 8.0,
// x64-windows-static). MJPEG is used because it is intra-only — one frame is one
// independent packet-set, which is exactly what a per-frame FEC group protects.
#pragma once
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
}
#include <cstdint>
#include <string>
#include <vector>

namespace recon { namespace mcm {

struct FfmpegMjpeg {
    // Encode a synthetic W x H frame to JPEG bytes via real avcodec.
    static std::vector<uint8_t> encode(int w, int h, uint32_t seed, std::string* err) {
        const AVCodec* enc = avcodec_find_encoder(AV_CODEC_ID_MJPEG);
        if (!enc) { if (err) *err = "no mjpeg encoder"; return {}; }
        AVCodecContext* c = avcodec_alloc_context3(enc);
        c->width = w; c->height = h;
        c->pix_fmt = AV_PIX_FMT_YUVJ420P;      // MJPEG full-range 4:2:0
        c->time_base = AVRational{1, 25};
        c->color_range = AVCOL_RANGE_JPEG;
        c->flags |= AV_CODEC_FLAG_QSCALE;
        c->global_quality = FF_QP2LAMBDA * 4;   // decent quality
        std::vector<uint8_t> out;
        if (avcodec_open2(c, enc, nullptr) < 0) { if (err) *err = "open enc"; avcodec_free_context(&c); return out; }
        AVFrame* f = av_frame_alloc();
        f->width = w; f->height = h; f->format = c->pix_fmt;
        if (av_frame_get_buffer(f, 0) < 0) { if (err) *err = "frame buf"; av_frame_free(&f); avcodec_free_context(&c); return out; }
        for (int y = 0; y < h; ++y)
            for (int x = 0; x < w; ++x)
                f->data[0][y * f->linesize[0] + x] = (uint8_t)((x + y + seed) & 0xFF);
        for (int y = 0; y < h / 2; ++y)
            for (int x = 0; x < w / 2; ++x) {
                f->data[1][y * f->linesize[1] + x] = (uint8_t)((x * 2 + seed) & 0xFF);
                f->data[2][y * f->linesize[2] + x] = (uint8_t)((y * 2 + seed) & 0xFF);
            }
        f->pts = 0;
        AVPacket* pkt = av_packet_alloc();
        if (avcodec_send_frame(c, f) == 0 && avcodec_send_frame(c, nullptr) == 0) {
            while (avcodec_receive_packet(c, pkt) == 0) {
                out.insert(out.end(), pkt->data, pkt->data + pkt->size);
                av_packet_unref(pkt);
            }
        } else if (err) *err = "encode";
        av_packet_free(&pkt); av_frame_free(&f); avcodec_free_context(&c);
        return out;
    }

    // Decode JPEG bytes to a YUV frame via real avcodec; report W/H + a Y-plane checksum.
    static bool decode(const std::vector<uint8_t>& jpeg, int* ow, int* oh, uint64_t* ychk, std::string* err) {
        const AVCodec* dec = avcodec_find_decoder(AV_CODEC_ID_MJPEG);
        if (!dec) { if (err) *err = "no mjpeg decoder"; return false; }
        AVCodecContext* c = avcodec_alloc_context3(dec);
        if (avcodec_open2(c, dec, nullptr) < 0) { if (err) *err = "open dec"; avcodec_free_context(&c); return false; }
        // FFmpeg requires the input buffer be padded by AV_INPUT_BUFFER_PADDING_SIZE.
        std::vector<uint8_t> padded(jpeg);
        padded.resize(jpeg.size() + AV_INPUT_BUFFER_PADDING_SIZE, 0);
        AVPacket* pkt = av_packet_alloc();
        pkt->data = padded.data(); pkt->size = (int)jpeg.size();
        AVFrame* f = av_frame_alloc();
        bool ok = false;
        if (avcodec_send_packet(c, pkt) == 0 && avcodec_receive_frame(c, f) == 0) {
            *ow = f->width; *oh = f->height;
            uint64_t s = 1469598103934665603ull;
            for (int y = 0; y < f->height; ++y)
                for (int x = 0; x < f->width; ++x)
                    s = (s ^ f->data[0][y * f->linesize[0] + x]) * 1099511628211ull;
            *ychk = s; ok = true;
        } else if (err) *err = "decode";
        av_frame_free(&f); av_packet_free(&pkt); avcodec_free_context(&c);
        return ok;
    }

    static std::string version() {
        unsigned v = avcodec_version();
        return std::to_string(v >> 16) + "." + std::to_string((v >> 8) & 0xFF) + "." + std::to_string(v & 0xFF);
    }
};

}} // namespace recon::mcm
