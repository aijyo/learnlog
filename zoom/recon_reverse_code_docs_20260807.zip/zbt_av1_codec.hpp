// =============================================================================
//  zbt_av1_codec.hpp -- CLEAN-ROOM reconstruction of the AV1 codec wrapper
//  reverse-engineered from Zoom's zbt.dll.  ORIGINAL C++17; faithful to the
//  recovered export ABI + parse surface.  No verbatim proprietary source.
//
//  *** RE-VERIFIED against decompiled function BODIES (this file held up well;
//  the fixes below tighten it to the evidence). ***
//
//  Decompiled evidence (zbt.dll, IDA/Hex-Rays):
//   - Av1EncInterfaceCreate 0x18009C920 / Av1DecInterfaceCreate 0x18009C680:
//       (a2 & 0xF) == 2 selects the SCREEN-CONTENT cores
//       ns_av1::zbtCScEncoderCore / zbtCScDecoderCore (else the normal cores).
//       enc object ~0x488F0..0x48900 bytes; dec object 0x1088.
//   - Av1EncSpecialFeature 0x18009CA80 / Av1DecSpecialFeature 0x18009C820:
//       INTEGER feature-id switch (not a bitmask).  Recovered ids:
//         enc base 0x850001 (8716289): id -> alloc encoder working-set;
//                                      id+2 -> ns_av1::zbtCObuHdrWriter (packetizer)
//         dec base 0x880001 (8912897): id   -> set a global sink;
//                                      id+1 -> ns_av1::zbtCObuHdrParser (depacketizer)
//       Sub-objects wrap ns_base::zltCPacketizedUnit / zbtCOpenBsUnitsHeader.
//   - Av1CreateWinHwDecSpecificCodec 0x18009CD10:
//       builds ns_av1::zltCWinHwDecSpecificCodecAV1 (HW/DXVA AV1 decode, 0x710).
//       NOTE: takes only the out-ptr; the D3D device is bound later, not here.
//   - SW OBU parser 0x1801CFA10 (sequence/metadata) + 0x1801D0AA0 (frame header):
//       full AV1 OBU parse (temporal-delimiter/seq/frame/tile-group/metadata incl
//       ITU-T T.35 + HDR CLL/mastering-display), AV1 set_frame_refs ref-sign-bias
//       selection over 8 slots, multithreaded tile decode (SRW + condition vars).
//       Diagnostics: "Error parsing sequence header / frame header / OBU data",
//       "Overrun in OBU bit buffer", "Unknown Metadata OBU type",
//       "Malformed ITU-T T.35 metadata message format".
//   - Error codes are large unsigned constants funneled through sub_18009C520.
// =============================================================================
#pragma once
#include <cstdint>
#include <cstddef>

namespace recon::zbt {

enum class Av1ParseError { Ok, SequenceHeader, FrameHeader, ObuData, ObuOverrun, BadT35Metadata };

// Codec "mode" low-nibble selector recovered from the Create bodies.
enum class CoreKind : int { Normal = 0, ScreenContent = 2 };  // (mode & 0xF)
inline CoreKind CoreKindOf(int mode) { return CoreKind(mode & 0xF); }

struct Av1EncParams {          // AV1 encode params the wrapper forwards
    int   width = 0, height = 0;
    float frame_rate = 30.f;
    int   bitrate = 0, qp = -1;
    int   spatial_layers = 1, temporal_layers = 1;
    bool  screen_content = false;   // maps to (mode&0xF)==2 -> zbtCScEncoderCore
    bool  hardware = false;         // prefer HW (D3D/DXVA) path
};

// Opaque codec handles (real impl wraps zbt AV1 cores / HW).
struct IAv1Encoder {
    virtual ~IAv1Encoder() = default;
    virtual int  Configure(const Av1EncParams&) = 0;
    virtual int  Encode(const uint8_t* nv12, size_t n, uint8_t* obu, size_t cap, size_t& outLen) = 0;
    virtual int  ForceKeyframe() = 0;
    virtual int  SetBitrate(int bps) = 0;
};
struct IAv1Decoder {
    virtual ~IAv1Decoder() = default;
    virtual int           Decode(const uint8_t* obu, size_t n, uint8_t* nv12, size_t cap) = 0;
    virtual Av1ParseError last_parse_error() const = 0;
};

// --- Reconstructed export ABI ------------------------------------------------
// The real exports take (out, mode, a3, a4, a5, a6, a7); mode's low nibble picks
// the screen-content core.  We surface a params struct for the clean-room API.
IAv1Encoder* Av1EncInterfaceCreate(const Av1EncParams& p);
void         Av1EncInterfaceDestroy(IAv1Encoder*);              // 0x18009C7F0
IAv1Decoder* Av1DecInterfaceCreate(int mode);
void         Av1DecInterfaceDestroy(IAv1Decoder*);

// HW decoder factory (HW/DXVA AV1).  Real create takes only the out-ptr; the
// D3D device is attached afterwards through a separate call.
IAv1Decoder* Av1CreateWinHwDecSpecificCodec();

// SpecialFeature: INTEGER feature-id switch that constructs helper sub-objects
// (OBU header writer/parser = (de)packetizers) or toggles internal sinks.
// These are the recovered base ids (see header comment); param carries the
// created sub-object out-pointer, not a bitmask.
enum : uint32_t {
    kEncFeat_Base       = 0x850001,   // alloc encoder working-set
    kEncFeat_Packetizer = 0x850001 + 2, // -> zbtCObuHdrWriter
    kDecFeat_Base       = 0x880001,   // set global sink
    kDecFeat_Depacketizer = 0x880001 + 1, // -> zbtCObuHdrParser
};
uint32_t Av1EncSpecialFeature(uint32_t featureId, void* param);  // 0x18009CA80
uint32_t Av1DecSpecialFeature(uint32_t featureId, void* param);  // 0x18009C820

} // namespace recon::zbt
