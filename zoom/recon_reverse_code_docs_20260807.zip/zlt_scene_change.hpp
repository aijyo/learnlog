// zlt_scene_change.hpp -- CLEAN-ROOM reconstruction of zlt.dll's SCENE-CHANGE / content-motion detector
// (ns_codec::zltCSceneChangeDetect, vftable 0x180501638). Body-verified from Hex-Rays decompilation:
//
//   sub_18009FE00  Process(frame)  -- per-frame entry: derives analysis buffers, downscales, runs the metric.
//   sub_18009FAD0  setup           -- ANALYSIS-RESOLUTION derivation (input/4, ~640x360 cap) + buffer alloc.
//   sub_1800A0190  per-frame stats -- 128-bin LUMA histogram + mean + dominant bin + brightness ratio (double-buffered).
//   sub_1800A03B0  decision        -- score -> threshold cascade (16 / 48 / 38 with chroma + 1/8-SAD confirm).
//   sub_1800A0790  score           -- BRIGHTNESS-INVARIANT histogram similarity (shift + ratio alignment), 0..64.
//   sub_1800A0CB0  chroma confirm  -- plain 128-bin histogram similarity on U/V (threshold 22).
//
// KEY RECOVERED FACTS (correcting earlier assumptions):
//   * Analysis resolution = INPUT / 4 (fixed factor 4 for <=1440p -> 1080p:480x270, 720p:320x180); ~640x360
//     only for >1440p/4K. NOT a fixed 640x360.
//   * Metric is LUMA-HISTOGRAM based (128 bins = luma>>1), NOT a pixel mean/BGR delta, and BRIGHTNESS-INVARIANT
//     (aligns the two frames' histograms by a small bin shift AND the measured mean-luma ratio before comparing).
//   * Per-bin similarity = min(a,b)*64/max(a,b); summed and normalized to 0..64 (64 = identical). HIGH = similar
//     (no change); LOW = scene change.
//   * Cascade thresholds are HARD-CODED constants (16/48/38 luma; 22 chroma; 55/52 on the 1/8-res SAD), NOT
//     config-blob values (only the higher-level video-mode enter/exit dwell is config).
//
// The 1/8-res SAD confirm calls an SSE/AVX SAD kernel via a fn-ptr (a1+16); reproduced here as a scalar
// mean-abs-diff. The exact obfuscated bin-shift indexing is simplified to an explicit +/-2 search (equivalent).
#pragma once
#include <cstdint>
#include <vector>
#include <algorithm>

namespace recon { namespace zlt {

struct SceneChangeResult {
    bool  scene_change = false;   // hard cut / big change (sub_1800A03B0 a1+24)
    bool  strong       = false;   // strong-change flag (a1+28)
    int   score        = 64;      // luma histogram similarity 0..64 (HIGH = similar / no change)
    int   analysis_w   = 0, analysis_h = 0;
};

class SceneChangeDetect {
public:
    // sub_18009FAD0: integer downscale so the frame fits ~640x360. factor=4 for <=1440p (1080p->480x270,
    // 720p->320x180); computed to reach ~640x360 for 4K. Dims rounded to even.
    static void AnalysisSize(int w, int h, int& aw, int& ah) {
        int factor;
        if ((int64_t)w * h <= 3686400) factor = 4;
        else {
            int tw = (w >= h) ? 640 : 360, th = (w >= h) ? 360 : 640;
            factor = std::max((w + tw - 1) / tw, (h + th - 1) / th);
        }
        if (factor < 1) factor = 1;
        aw = ((w / factor) + 1) & ~1;
        ah = ((h / factor) + 1) & ~1;
    }

    // One frame. y = full-res luma (w x h, stride). u,v = optional half-res chroma (cw x ch, cstride) for the
    // (38,48] chroma-confirm band. Returns the decision (score + change flags).
    SceneChangeResult Process(const uint8_t* y, int w, int h, int stride,
                              const uint8_t* u = nullptr, const uint8_t* v = nullptr,
                              int cw = 0, int ch = 0, int cstride = 0) {
        SceneChangeResult r;
        AnalysisSize(w, h, r.analysis_w, r.analysis_h);
        const int aw = r.analysis_w, ah = r.analysis_h;
        if (aw < 16 || ah < 16) return r;

        // downscale luma to analysis res (nearest; Zoom uses its VPP scaler)
        std::vector<uint8_t> ana((size_t)aw * ah);
        for (int j = 0; j < ah; ++j) for (int i = 0; i < aw; ++i)
            ana[(size_t)j * aw + i] = y[(size_t)(j * h / ah) * stride + (i * w / aw)];

        Frame f = BuildHist(ana.data(), aw, ah, aw, aw, ah);   // sub_1800A0190: 128-bin luma hist + stats

        if (!have_prev_) { prev_ = std::move(f); prev_ana_ = std::move(ana); have_prev_ = true; return r; }

        int score = HistSimilarityAligned(f, prev_);            // sub_1800A0790: brightness-invariant, 0..64
        r.score = score;

        // sub_1800A03B0 cascade (16/48/38 hard-coded)
        if (score <= 16) { r.scene_change = true; r.strong = true; }
        else if (score > 48) { r.scene_change = false; }
        else if (score > 38) {                                  // (38,48]: confirm on CHROMA (thr 22)
            if (u && v) {
                int caw = aw / 2, cah = ah / 2;
                Frame cu = BuildHist(u, cw, ch, cstride, caw, cah);
                Frame cv = BuildHist(v, cw, ch, cstride, caw, cah);
                int cs = std::min(HistSimilarityPlain(cu, prev_cu_), HistSimilarityPlain(cv, prev_cv_));
                r.scene_change = (cs < 22);
                prev_cu_ = std::move(cu); prev_cv_ = std::move(cv);
            }
        } else {                                                // (16,38]: confirm on 1/8-res luma SAD
            int sad = MeanSad8(ana.data(), aw, ah);
            int thr = (55 * (aw >> 3) * (ah >> 3)) >> 6;
            if (sad >= thr) { r.scene_change = true; r.strong = (sad >= thr); }
        }
        // keep chroma prev current even outside the (38,48] band, when available
        if (u && v && !(score > 38 && score <= 48)) {
            int caw = aw / 2, cah = ah / 2;
            prev_cu_ = BuildHist(u, cw, ch, cstride, caw, cah);
            prev_cv_ = BuildHist(v, cw, ch, cstride, caw, cah);
        }
        prev_ana_ = std::move(ana);
        prev_ = std::move(f);
        return r;
    }

private:
    struct Frame { std::vector<int> hist; int mean = 0, dominant = 0, peaky = 0; };

    // downscale a plane to (aw x ah) nearest, build a 128-bin histogram (bin = px>>1) + mean + dominant + peaky.
    static Frame BuildHist(const uint8_t* p, int pw, int ph, int stride, int aw, int ah) {
        Frame f; f.hist.assign(128, 0); long sum = 0; int N = aw * ah;
        for (int j = 0; j < ah; ++j) for (int i = 0; i < aw; ++i) {
            uint8_t px = p[(size_t)(j * ph / ah) * stride + (i * pw / aw)];
            sum += px; ++f.hist[px >> 1];
        }
        f.mean = N ? int(sum / N) : 0;
        f.dominant = int(std::max_element(f.hist.begin(), f.hist.end()) - f.hist.begin());
        f.peaky = N ? int(((long)f.hist[f.dominant] << 6) / N) : 0;
        return f;
    }
    // per-bin similarity min(a,b)*64/max(a,b), summed weighted, normalized to 0..64 (64 = identical).
    static int HistSimilarityPlain(const Frame& a, const Frame& b) {
        if (a.hist.empty() || b.hist.empty()) return 64;
        long acc = 0, tot = 0;
        for (int i = 0; i < 128; ++i) {
            int ha = a.hist[i], hb = b.hist[i], mx = std::max(ha, hb), mn = std::min(ha, hb);
            if (mx) acc += (long)ha * ((mn << 6) / mx);
            tot += ha;
        }
        return tot ? int(acc / tot) : 64;
    }
    // brightness-invariant: max similarity over a small bin shift (+/-2) AND a mean-ratio bin rescale.
    static int HistSimilarityAligned(const Frame& cur, const Frame& prev) {
        int best = 0;
        for (int s = -2; s <= 2; ++s) best = std::max(best, HistSimilarityShift(cur, prev, s));
        if (prev.mean > 0) {
            int ratio32 = 32 * cur.mean / prev.mean;            // a1[394]
            if (ratio32 > 0 && ratio32 != 32) {
                long acc = 0, tot = 0;
                for (int i = 0; i < 128; ++i) {
                    int j = std::min(127, 32 * i / ratio32);    // warp prev bin axis by the mean ratio
                    int ha = cur.hist[i], hb = prev.hist[j], mx = std::max(ha, hb), mn = std::min(ha, hb);
                    if (mx) acc += (long)ha * ((mn << 6) / mx);
                    tot += ha;
                }
                best = std::max(best, tot ? int(acc / tot) : 64);
            }
        }
        return best;
    }
    static int HistSimilarityShift(const Frame& cur, const Frame& prev, int shift) {
        long acc = 0, tot = 0;
        for (int i = 0; i < 128; ++i) {
            int j = i + shift; if (j < 0 || j > 127) continue;
            int ha = cur.hist[i], hb = prev.hist[j], mx = std::max(ha, hb), mn = std::min(ha, hb);
            if (mx) acc += (long)ha * ((mn << 6) / mx);
            tot += ha;
        }
        return tot ? int(acc / tot) : 64;
    }
    // 1/8-res mean absolute difference vs the previous analysis frame.
    int MeanSad8(const uint8_t* ana, int aw, int ah) const {
        if (prev_ana_.size() != (size_t)aw * ah) return 0;
        long sad = 0; int n = 0;
        for (int j = 0; j < ah; j += 8) for (int i = 0; i < aw; i += 8) {
            int d = (int)ana[(size_t)j * aw + i] - (int)prev_ana_[(size_t)j * aw + i];
            sad += d < 0 ? -d : d; ++n;
        }
        return n ? int(sad / n) : 0;
    }

    Frame prev_, prev_cu_, prev_cv_;
    std::vector<uint8_t> prev_ana_;
    bool have_prev_ = false;
};

}} // namespace recon::zlt
