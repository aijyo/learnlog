// zlt_resample.hpp -- clean-room reconstruction of the capture->encode SCALER used by
// zlt.dll (ns_vpp::zltCResample / ns_vpp::zltCGvdownsample). This is the resampler Zoom
// runs to shrink a captured native/4K frame down to the selected encode ladder rung
// (<=1080p, see ida_recovered_ladders.md #1) before the frame reaches the encoder.
//
// It is a POLYPHASE, SEPARABLE, SCALE-ADAPTIVE resampler with a BICUBIC reconstruction
// kernel -- not a box average and not plain bilinear. The STRUCTURE (kernel -> support law
// -> separable normalized taps) is code and is reconstructed here faithfully; there are no
// learned WEIGHTS involved (a resampler's taps are computed from the kernel, so nothing here
// is a data boundary -- this whole file is runnable reference).
//
// ---- IDA verification (zlt.dll, idat64 headless, 2026-07-27) --------------------------
//   Classes (ns_vpp vftables):
//     * zltCResample        0x180504F98 -- general resampler, arbitrary ratio; Transform
//                           sub_1801E2BF0; SetParam sub_1801E2B80 (selects quality/ratio);
//                           builds the 0x1260-byte engine via sub_18023C8B0.
//     * zltCGvdownsample    0x1805054A8 -- dedicated downsampler; Transform sub_18023C110;
//                           engine helper sub_1801BBCE0 HARD-WIRES the bicubic kernel.
//     * zltCNearest         0x1805053B0 -- integer-factor nearest decimation (div N<=7,
//                           sub_18021DAD0), a fast path; NOT interpolating.
//     * zltCBilinear / zltCUpSampleBilinear / zltCAlignedBilinearUpsample / zltCUpsample
//                        -- UPSCALE / receive-render side; not the send-side downscale.
//
//   Coefficient builder  sub_1801BC400 (实证, body):
//       ratio   = dst/src
//       fscale  = max(1, src/dst)          # widen support when shrinking (anti-alias)
//       support = base_radius * fscale      # base_radius = 2 for bicubic
//       taps    = ceil(2*support)           # tap count grows with shrink ratio
//     Separable: equal X/Y ratio -> sub_1801BD360; else per-axis sub_1801BCF00 (X then Y).
//
//   Weight generator      sub_1801BCF00 (实证, body):
//       for each output pixel o:
//         center = (o + phase)/ratio                       # source coord
//         [lo,hi] = [ceil(center-support), floor(center+support)] clamped to [0,src)
//         w[j]   = kernel( (j - center)/fscale )           # kernel via fn-ptr engine+0x318
//         normalize taps to sum = 16384 (Q14 int16); last tap absorbs rounding
//     Apply loops installed in 3 SIMD variants (scalar/SSE/AVX2) by CPU dispatch in the
//     engine ctor sub_18023C8B0 (fn-ptr pairs at +0x0D8/+0x0E0, +0x320/+0x328, +0x320/+0x328).
//
//   Kernels selectable by config (sub_1801BC6F0, case 1/2/3; installed at engine+0x318):
//     * case 1 (default): sub_1801BCCA0  support 2.0  bicubic Keys a=-0.5 (Catmull-Rom)
//     * case 2:           sub_1801BCE40  support 4.0  Lanczos-4 (windowed sinc)
//     * case 3:           sub_1801BCDA0  support 2.0  bicubic a=-0.5 (fabs form)
//   zltCGvdownsample uses case-1 bicubic unconditionally.
//
// The demo ships a BGRA-specialized port of this (avp::resample::ResizeBGRA in
// apps/resample.hpp). This header is the generic single-plane reference + all 3 kernels.

#pragma once
#include <vector>
#include <cmath>
#include <cstdint>
#include <functional>

namespace zlt {
namespace resample {

// ---- Kernels (weight as a function of signed distance) --------------------------------

// case 1/3: bicubic Keys convolution, a = -0.5 (Catmull-Rom). zlt sub_1801BCCA0 / sub_1801BCDA0.
//   |x|<1 : 1.5|x|^3 - 2.5|x|^2 + 1 ;  1<=|x|<2 : -0.5|x|^3 + 2.5|x|^2 - 4|x| + 2 ;  else 0
struct BicubicCatmullRom {
  static constexpr double radius = 2.0;
  double operator()(double x) const {
    double a = x < 0.0 ? -x : x;
    if (a < 1.0) return (1.5 * a - 2.5) * a * a + 1.0;
    if (a < 2.0) return ((-0.5 * a + 2.5) * a - 4.0) * a + 2.0;
    return 0.0;
  }
};

// case 2: Lanczos-4 windowed sinc. zlt sub_1801BCE40 (support [-4,4], sin(pi x/4)*sin(pi x)).
//   L(x) = sinc(x) * sinc(x/4) = [sin(pi x)/(pi x)] * [sin(pi x/4)/(pi x/4)] , |x|<4 else 0
struct Lanczos4 {
  static constexpr double radius = 4.0;
  double operator()(double x) const {
    if (x == 0.0) return 1.0;
    double a = x < 0.0 ? -x : x;
    if (a >= 4.0) return 0.0;
    const double pi = 3.14159265358979323846;
    double px = pi * x;
    return (std::sin(px) / px) * (std::sin(px * 0.25) / (px * 0.25));
  }
};

// ---- Polyphase axis taps (sub_1801BC400 support law + sub_1801BCF00 normalization) ----

struct AxisTaps { int start; std::vector<float> w; };

// Build per-output-pixel normalized taps for one axis. `radius` = kernel base radius (2 or 4).
template <class Kernel>
inline void BuildAxis(int src_len, int dst_len, const Kernel& k, std::vector<AxisTaps>& out) {
  out.assign(dst_len > 0 ? dst_len : 0, AxisTaps{});
  if (src_len <= 0 || dst_len <= 0) return;
  const double ratio  = (double)dst_len / (double)src_len;
  const double fscale = ratio < 1.0 ? 1.0 / ratio : 1.0;      // max(1, src/dst): anti-alias widening
  const double support = Kernel::radius * fscale;
  const double invf = 1.0 / fscale;
  for (int o = 0; o < dst_len; ++o) {
    const double center = ((double)o + 0.5) / ratio - 0.5;
    int lo = (int)std::ceil(center - support);
    int hi = (int)std::floor(center + support);
    AxisTaps t; t.start = lo; t.w.reserve((size_t)(hi - lo + 1));
    double sum = 0.0;
    for (int s = lo; s <= hi; ++s) { double w = k((s - center) * invf); t.w.push_back((float)w); sum += w; }
    if (sum != 0.0) { float inv = (float)(1.0 / sum); for (float& w : t.w) w *= inv; }
    out[o] = std::move(t);
  }
}

// ---- Separable resample of one float plane (luma or any channel) ----------------------
// Reference for the algorithm; the demo's BGRA path is apps/resample.hpp. Edge = clamp.
template <class Kernel = BicubicCatmullRom>
inline void ResizePlane(const float* src, int srcW, int srcH, int srcStride /*elems/row*/,
                        float* dst, int dstW, int dstH, int dstStride /*elems/row*/,
                        const Kernel& k = Kernel{}) {
  if (srcW <= 0 || srcH <= 0 || dstW <= 0 || dstH <= 0) return;
  std::vector<AxisTaps> tx, ty;
  BuildAxis(srcW, dstW, k, tx);
  BuildAxis(srcH, dstH, k, ty);
  std::vector<float> tmp((size_t)srcH * dstW, 0.0f);           // horizontal pass -> (srcH x dstW)
  for (int y = 0; y < srcH; ++y) {
    const float* srow = src + (size_t)y * srcStride;
    float* trow = tmp.data() + (size_t)y * dstW;
    for (int x = 0; x < dstW; ++x) {
      const AxisTaps& t = tx[x]; double acc = 0;
      for (size_t j = 0; j < t.w.size(); ++j) { int sx = t.start + (int)j; sx = sx < 0 ? 0 : (sx >= srcW ? srcW - 1 : sx); acc += srow[sx] * (double)t.w[j]; }
      trow[x] = (float)acc;
    }
  }
  for (int y = 0; y < dstH; ++y) {                              // vertical pass -> (dstH x dstW)
    const AxisTaps& t = ty[y];
    float* drow = dst + (size_t)y * dstStride;
    for (int x = 0; x < dstW; ++x) {
      double acc = 0;
      for (size_t j = 0; j < t.w.size(); ++j) { int sy = t.start + (int)j; sy = sy < 0 ? 0 : (sy >= srcH ? srcH - 1 : sy); acc += tmp[(size_t)sy * dstW + x] * (double)t.w[j]; }
      drow[x] = (float)acc;
    }
  }
}

} // namespace resample
} // namespace zlt
