// raisr_cam_gpu.hpp -- GPU (D3D11 compute) CAMERA RAISR, the full receive path on the GPU. CLEAN-ROOM:
// our own HLSL implementing the recovered zltCRaisr structure (22-bucket hash = 11 angle × 2 strength,
// 13-tap DIRECT LR-patch->HR-subpixel, phases = scale²), fed with OUR trained x2/x3 banks. Mirrors Zoom's
// GPU camera pipeline (ns_gct::CGPURaisr luma + ns_gct::CChromaUpsample luma-guided chroma), fused here
// into two dispatches:
//   Pass A : LR luma --direct 22-bucket/13-tap RAISR--> scale× luma
//   Pass B : scale× luma --bilinear resize--> display luma ; joint-bilateral (luma-guided) chroma ;
//            YUV(BT.601) -> BGRA (display).
// No Zoom .cso bytecode or ⛔W weights are embedded; the banks are ours (apps/raisr_train_camera.cpp).
#pragma once
#include <d3d11.h>
#include <d3dcompiler.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <vector>
#include <string>
#include <cstdint>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "dxgi.lib")

namespace recon { namespace zltcam {

class GpuCamRaisr {
  template <class T> using CP = Microsoft::WRL::ComPtr<T>;
public:
  // banks: x2 = 4 phases × 22 buckets × 13, x3 = 9 phases × 22 × 13 (either may be empty). nbuck=22, angleBins=11.
  bool init(int nbuck, int angleBins, float strT, const std::vector<float>& bankX2, const std::vector<float>& bankX3) {
    nbuck_ = nbuck; angleBins_ = angleBins; strT_ = strT;
    D3D_FEATURE_LEVEL fl;
    CP<IDXGIFactory1> fac; CP<IDXGIAdapter1> pick, a;
    if (SUCCEEDED(CreateDXGIFactory1(IID_PPV_ARGS(&fac)))) {
      SIZE_T best = 0;
      for (UINT i = 0; fac->EnumAdapters1(i, &a) != DXGI_ERROR_NOT_FOUND; ++i) {
        DXGI_ADAPTER_DESC1 d{}; a->GetDesc1(&d);
        if (!(d.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) && (!pick || d.DedicatedVideoMemory >= best)) { best = d.DedicatedVideoMemory; pick = a; }
        a.Reset();
      }
    }
    if (pick) D3D11CreateDevice(pick.Get(), D3D_DRIVER_TYPE_UNKNOWN, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &dev_, &fl, &ctx_);
    if (!dev_) for (D3D_DRIVER_TYPE dt : { D3D_DRIVER_TYPE_HARDWARE, D3D_DRIVER_TYPE_WARP })
      if (SUCCEEDED(D3D11CreateDevice(nullptr, dt, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &dev_, &fl, &ctx_))) break;
    if (!dev_) return false;
    if (!compile(hlslA(), "mainA", csA_)) return false;
    if (!compile(hlslB(), "mainB", csB_)) return false;
    haveX2_ = !bankX2.empty() && mkBank(bankX2, bankX2Buf_, bankX2SRV_);
    haveX3_ = !bankX3.empty() && mkBank(bankX3, bankX3Buf_, bankX3SRV_);
    D3D11_BUFFER_DESC cb{}; cb.ByteWidth = 64; cb.Usage = D3D11_USAGE_DYNAMIC; cb.BindFlags = D3D11_BIND_CONSTANT_BUFFER; cb.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    if (FAILED(dev_->CreateBuffer(&cb, nullptr, &cbuf_))) return false;
    CP<IDXGIDevice> dxgi; CP<IDXGIAdapter> ad;
    if (SUCCEEDED(dev_.As(&dxgi)) && SUCCEEDED(dxgi->GetAdapter(&ad))) { DXGI_ADAPTER_DESC d{}; ad->GetDesc(&d); char nm[256]; std::snprintf(nm, sizeof nm, "%ls", d.Description); adapter_ = nm; }
    ok_ = haveX2_ || haveX3_; return ok_;
  }
  bool ready() const { return ok_; }
  const std::string& adapter() const { return adapter_; }

  // LR I420 (planar y[w*h], u/v[cw*ch]) -> display BGRA (outW*outH*4). Picks x2/x3 by the display ratio.
  bool Upscale(const uint8_t* y, const uint8_t* u, const uint8_t* v, int w, int h, int cw, int ch,
               std::vector<uint8_t>& outBGRA, int outW, int outH) {
    if (!ok_) return false;
    double ratio = (double)outW / w; if ((double)outH / h > ratio) ratio = (double)outH / h;
    int scale = (ratio >= 2.5 && haveX3_) ? 3 : 2;
    ID3D11ShaderResourceView* bankSRV = (scale == 3 && haveX3_) ? bankX3SRV_.Get() : bankX2SRV_.Get();
    if (!bankSRV) { scale = 2; bankSRV = bankX2SRV_.Get(); if (!bankSRV) { scale = 3; bankSRV = bankX3SRV_.Get(); } }
    if (!bankSRV) return false;
    int OW = w * scale, OH = h * scale;
    ensureTex(w, h, cw, ch, OW, OH, outW, outH);
    uploadF(lrY_, y, w, h); uploadF(lrU_, u, cw, ch); uploadF(lrV_, v, cw, ch);
    struct C { int inW, inH, cw, ch, OW, OH, outW, outH, scale, nbuck, phases, taps, angleBins; float strT; int p0, p1; }
      c{ w, h, cw, ch, OW, OH, outW, outH, scale, nbuck_, scale * scale, 13, angleBins_, strT_, 0, 0 };
    D3D11_MAPPED_SUBRESOURCE m{};
    if (SUCCEEDED(ctx_->Map(cbuf_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) { std::memcpy(m.pData, &c, sizeof c); ctx_->Unmap(cbuf_.Get(), 0); }
    ID3D11Buffer* cbs = cbuf_.Get();
    // Pass A: LR Y (t1) + bank (t0) -> scale× Y (u0)
    ID3D11ShaderResourceView* srvA[2] = { bankSRV, lrYSRV_.Get() };
    ID3D11UnorderedAccessView* uavA = hrYUAV_.Get();
    ctx_->CSSetShader(csA_.Get(), nullptr, 0); ctx_->CSSetConstantBuffers(0, 1, &cbs);
    ctx_->CSSetShaderResources(0, 2, srvA); ctx_->CSSetUnorderedAccessViews(0, 1, &uavA, nullptr);
    ctx_->Dispatch((OW + 15) / 16, (OH + 15) / 16, 1);
    ID3D11UnorderedAccessView* nu = nullptr; ctx_->CSSetUnorderedAccessViews(0, 1, &nu, nullptr);
    ID3D11ShaderResourceView* nsrv[4] = { nullptr, nullptr, nullptr, nullptr }; ctx_->CSSetShaderResources(0, 4, nsrv);
    // Pass B: scale×Y(t0) + LR U(t1) + LR V(t2) + LR Y(t3) -> display BGRA (u0)
    ID3D11ShaderResourceView* srvB[4] = { hrYSRV_.Get(), lrUSRV_.Get(), lrVSRV_.Get(), lrYSRV_.Get() };
    ID3D11UnorderedAccessView* uavB = outUAV_.Get();
    ctx_->CSSetShader(csB_.Get(), nullptr, 0);
    ctx_->CSSetShaderResources(0, 4, srvB); ctx_->CSSetUnorderedAccessViews(0, 1, &uavB, nullptr);
    ctx_->Dispatch((outW + 15) / 16, (outH + 15) / 16, 1);
    ctx_->CSSetUnorderedAccessViews(0, 1, &nu, nullptr);
    // readback BGRA
    ctx_->CopyResource(outStage_.Get(), outTex_.Get());
    outBGRA.assign((size_t)outW * outH * 4, 0);
    if (SUCCEEDED(ctx_->Map(outStage_.Get(), 0, D3D11_MAP_READ, 0, &m))) {
      for (int yy = 0; yy < outH; ++yy) std::memcpy(outBGRA.data() + (size_t)yy * outW * 4, (uint8_t*)m.pData + (size_t)yy * m.RowPitch, (size_t)outW * 4);
      ctx_->Unmap(outStage_.Get(), 0);
    }
    return true;
  }

private:
  bool compile(const std::string& src, const char* entry, CP<ID3D11ComputeShader>& cs) {
    CP<ID3DBlob> code, err;
    if (FAILED(D3DCompile(src.c_str(), src.size(), "camraisr.hlsl", nullptr, nullptr, entry, "cs_5_0", 0, 0, &code, &err))) {
      if (err) std::fprintf(stderr, "GpuCamRaisr HLSL (%s) error:\n%.*s\n", entry, (int)err->GetBufferSize(), (const char*)err->GetBufferPointer());
      return false;
    }
    return SUCCEEDED(dev_->CreateComputeShader(code->GetBufferPointer(), code->GetBufferSize(), nullptr, &cs));
  }
  bool mkBank(const std::vector<float>& bank, CP<ID3D11Buffer>& buf, CP<ID3D11ShaderResourceView>& srv) {
    D3D11_BUFFER_DESC bd{}; bd.ByteWidth = (UINT)(bank.size() * 4); bd.Usage = D3D11_USAGE_IMMUTABLE; bd.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    bd.StructureByteStride = 4; bd.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;
    D3D11_SUBRESOURCE_DATA sd{}; sd.pSysMem = bank.data();
    if (FAILED(dev_->CreateBuffer(&bd, &sd, &buf))) return false;
    D3D11_SHADER_RESOURCE_VIEW_DESC sv{}; sv.ViewDimension = D3D11_SRV_DIMENSION_BUFFER; sv.Format = DXGI_FORMAT_UNKNOWN; sv.Buffer.NumElements = (UINT)bank.size();
    return SUCCEEDED(dev_->CreateShaderResourceView(buf.Get(), &sv, &srv));
  }
  CP<ID3D11Texture2D> mkTex(int w, int h, DXGI_FORMAT f, D3D11_USAGE u, UINT bind, UINT cpu) {
    CP<ID3D11Texture2D> t; D3D11_TEXTURE2D_DESC d{}; d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = f;
    d.SampleDesc.Count = 1; d.Usage = u; d.BindFlags = bind; d.CPUAccessFlags = cpu; dev_->CreateTexture2D(&d, nullptr, &t); return t;
  }
  void ensureTex(int w, int h, int cw, int ch, int OW, int OH, int outW, int outH) {
    if (w == tw_ && h == th_ && OW == tOW_ && outW == toutW_ && outH == toutH_) return;
    tw_ = w; th_ = h; tOW_ = OW; toutW_ = outW; toutH_ = outH;
    lrY_ = mkTex(w, h, DXGI_FORMAT_R32_FLOAT, D3D11_USAGE_DYNAMIC, D3D11_BIND_SHADER_RESOURCE, D3D11_CPU_ACCESS_WRITE);
    lrU_ = mkTex(cw, ch, DXGI_FORMAT_R32_FLOAT, D3D11_USAGE_DYNAMIC, D3D11_BIND_SHADER_RESOURCE, D3D11_CPU_ACCESS_WRITE);
    lrV_ = mkTex(cw, ch, DXGI_FORMAT_R32_FLOAT, D3D11_USAGE_DYNAMIC, D3D11_BIND_SHADER_RESOURCE, D3D11_CPU_ACCESS_WRITE);
    hrY_ = mkTex(OW, OH, DXGI_FORMAT_R32_FLOAT, D3D11_USAGE_DEFAULT, D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_UNORDERED_ACCESS, 0);
    outTex_ = mkTex(outW, outH, DXGI_FORMAT_R8G8B8A8_UNORM, D3D11_USAGE_DEFAULT, D3D11_BIND_UNORDERED_ACCESS, 0);
    outStage_ = mkTex(outW, outH, DXGI_FORMAT_R8G8B8A8_UNORM, D3D11_USAGE_STAGING, 0, D3D11_CPU_ACCESS_READ);
    lrYSRV_.Reset(); lrUSRV_.Reset(); lrVSRV_.Reset(); hrYSRV_.Reset(); hrYUAV_.Reset(); outUAV_.Reset();
    dev_->CreateShaderResourceView(lrY_.Get(), nullptr, &lrYSRV_);
    dev_->CreateShaderResourceView(lrU_.Get(), nullptr, &lrUSRV_);
    dev_->CreateShaderResourceView(lrV_.Get(), nullptr, &lrVSRV_);
    dev_->CreateShaderResourceView(hrY_.Get(), nullptr, &hrYSRV_);
    dev_->CreateUnorderedAccessView(hrY_.Get(), nullptr, &hrYUAV_);
    dev_->CreateUnorderedAccessView(outTex_.Get(), nullptr, &outUAV_);
  }
  void uploadF(CP<ID3D11Texture2D>& t, const uint8_t* src, int w, int h) {
    D3D11_MAPPED_SUBRESOURCE m{};
    if (FAILED(ctx_->Map(t.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) return;
    for (int y = 0; y < h; ++y) { float* d = (float*)((uint8_t*)m.pData + (size_t)y * m.RowPitch); const uint8_t* s = src + (size_t)y * w; for (int x = 0; x < w; ++x) d[x] = s[x]; }
    ctx_->Unmap(t.Get(), 0);
  }
  static const char* cbufDecl() {
    return "cbuffer C:register(b0){int inW,inH,cw,ch,OW,OH,outW,outH,scale,nbuck,phases,taps,angleBins;float strT;int p0,p1;};\n";
  }
  std::string hlslA() {
    return std::string(
"StructuredBuffer<float> gBank:register(t0);\n"
"Texture2D<float> gLRY:register(t1);\n"
"RWTexture2D<float> gHRY:register(u0);\n") + cbufDecl() +
// diamond order MUST match CPU PatchOffsets(13): for dy=-2..2, dx=-2..2, keep |dx|+|dy|<=2
"static const int DX[13]={0, -1,0,1, -2,-1,0,1,2, -1,0,1, 0};\n"
"static const int DY[13]={-2, -1,-1,-1, 0,0,0,0,0, 1,1,1, 2};\n"
"float LRY(int x,int y){x=clamp(x,0,inW-1);y=clamp(y,0,inH-1);return gLRY[int2(x,y)];}\n"
"float gX(int x,int y){return ((LRY(x+1,y-1)-LRY(x-1,y-1))+5.0*(LRY(x+1,y)-LRY(x-1,y))+(LRY(x+1,y+1)-LRY(x-1,y+1)))*(1.0/7.0);}\n"
"float gY(int x,int y){return ((LRY(x-1,y+1)-LRY(x-1,y-1))+5.0*(LRY(x,y+1)-LRY(x,y-1))+(LRY(x+1,y+1)-LRY(x+1,y-1)))*(1.0/7.0);}\n"
"[numthreads(16,16,1)]\n"
"void mainA(uint3 dt:SV_DispatchThreadID){\n"
" int hx=dt.x,hy=dt.y; if(hx>=OW||hy>=OH) return;\n"
" int lx=hx/scale, ly=hy/scale; int phase=(hy%scale)*scale+(hx%scale);\n"
" float a=0,b=0,c=0;\n"
" [unroll] for(int j=-1;j<=1;j++){ [unroll] for(int i=-1;i<=1;i++){ float gx=gX(lx+i,ly+j),gy=gY(lx+i,ly+j); a+=gx*gx; b+=gx*gy; c+=gy*gy; }}\n"
" a/=9.0; b/=9.0; c/=9.0;\n"
" float tr=a+c, disc=sqrt(max(0.0,0.25*tr*tr-(a*c-b*b)));\n"
" float l1=0.5*tr+disc, strength=sqrt(max(0.0,l1));\n"
" float th=0.5*atan2(2.0*b,a-c); if(th<0) th+=3.14159265;\n"
" int ab=(int)round(th*((float)(angleBins-1)/3.14159265)); ab=clamp(ab,0,angleBins-1);\n"
" int sb=strength>strT?1:0; int bucket=ab+angleBins*sb;\n"
" int bidx=(phase*nbuck+bucket)*taps; float acc=0;\n"
" [unroll] for(int k=0;k<13;k++){ acc+=gBank[bidx+k]*LRY(lx+DX[k],ly+DY[k]); }\n"
" gHRY[int2(hx,hy)]=clamp(acc,0.0,255.0);\n"
"}\n";
  }
  std::string hlslB() {
    return std::string(
"Texture2D<float> gHRY:register(t0);\n"
"Texture2D<float> gLRU:register(t1);\n"
"Texture2D<float> gLRV:register(t2);\n"
"Texture2D<float> gLRY:register(t3);\n"
"RWTexture2D<float4> gOut:register(u0);\n") + cbufDecl() +
"float bil(Texture2D<float> t,float fx,float fy,int w,int hgt){int x0=(int)floor(fx),y0=(int)floor(fy);float tx=fx-x0,ty=fy-y0;\n"
" int x1=clamp(x0+1,0,w-1),y1=clamp(y0+1,0,hgt-1); x0=clamp(x0,0,w-1); y0=clamp(y0,0,hgt-1);\n"
" float A=t[int2(x0,y0)],B=t[int2(x1,y0)],Cc=t[int2(x0,y1)],D=t[int2(x1,y1)];\n"
" return (A*(1-tx)+B*tx)*(1-ty)+(Cc*(1-tx)+D*tx)*ty;}\n"
"[numthreads(16,16,1)]\n"
"void mainB(uint3 dt:SV_DispatchThreadID){\n"
" int ox=dt.x,oy=dt.y; if(ox>=outW||oy>=outH) return;\n"
" float fx=(ox+0.5)*OW/(float)outW-0.5, fy=(oy+0.5)*OH/(float)outH-0.5;\n"
" float gh=bil(gHRY,fx,fy,OW,OH);\n"
" float cfx=(ox+0.5)*cw/(float)outW-0.5, cfy=(oy+0.5)*ch/(float)outH-0.5;\n"
" int cx0=(int)floor(cfx),cy0=(int)floor(cfy); float tx=cfx-cx0,ty=cfy-cy0;\n"
" float su=0,sv=0,sw=0;\n"
" [unroll] for(int j=0;j<2;j++){ [unroll] for(int i=0;i<2;i++){\n"
"   int cx=clamp(cx0+i,0,cw-1),cy=clamp(cy0+j,0,ch-1);\n"
"   float wsp=(i==1?tx:1-tx)*(j==1?ty:1-ty);\n"
"   float lumaLo=gLRY[int2(min(cx*2,inW-1),min(cy*2,inH-1))];\n"
"   float dl=gh-lumaLo; float wr=exp(-dl*dl/(2.0*16.0*16.0));\n"
"   float wgt=wsp*wr; su+=gLRU[int2(cx,cy)]*wgt; sv+=gLRV[int2(cx,cy)]*wgt; sw+=wgt; }}\n"
" float U=(sw>1e-6?su/sw:128.0)-128.0, V=(sw>1e-6?sv/sw:128.0)-128.0;\n"
" float R=clamp(gh+1.402*V,0.0,255.0), G=clamp(gh-0.344136*U-0.714136*V,0.0,255.0), Bl=clamp(gh+1.772*U,0.0,255.0);\n"
" gOut[int2(ox,oy)]=float4(Bl,G,R,255.0)/255.0;\n"   // R8G8B8A8 memory = B,G,R,A  == VideoFrame BGRA
"}\n";
  }

  bool ok_ = false, haveX2_ = false, haveX3_ = false;
  int nbuck_ = 22, angleBins_ = 11; float strT_ = 0.5f;
  int tw_ = 0, th_ = 0, tOW_ = 0, toutW_ = 0, toutH_ = 0;
  CP<ID3D11Device> dev_; CP<ID3D11DeviceContext> ctx_; CP<ID3D11ComputeShader> csA_, csB_;
  CP<ID3D11Buffer> cbuf_, bankX2Buf_, bankX3Buf_; CP<ID3D11ShaderResourceView> bankX2SRV_, bankX3SRV_;
  CP<ID3D11Texture2D> lrY_, lrU_, lrV_, hrY_, outTex_, outStage_;
  CP<ID3D11ShaderResourceView> lrYSRV_, lrUSRV_, lrVSRV_, hrYSRV_;
  CP<ID3D11UnorderedAccessView> hrYUAV_, outUAV_;
  std::string adapter_;
};

}}  // namespace recon::zltcam
