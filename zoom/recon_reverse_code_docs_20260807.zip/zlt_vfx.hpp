#pragma once
// zlt_vfx.hpp -- CLEAN-ROOM video effects reconstructed from Zoom's ns_vpp modules, operating on I420
// planes. Each is a classic CV op whose STRUCTURE + key params were recovered from zlt.dll (IDA); the
// SIMD kernels themselves are Zoom's (⛔S = CPU x86, referenceable), so these are our own implementations
// of the same operations. Chain order (Zoom's): LightAdapt -> ColorAdapt -> Clahe -> Sharpen (send side).
// NOTE: zltCDCC is NOT here — it was mis-identified as "contrast"; it is actually an edge-directed 2x
// upscaler (DCCI) and now lives in recon/zlt_dcci.hpp (recon::dcci::Upscale2x).
//
//   Sharpen  <- zltCSharpen (vft 0x1805049B8): EXACT kernel RE'd (3x3 Gaussian/16 + thresholded /128 unsharp).
//                            Apply sub_1801ABA20 confirms the wrapper: border-replicate top/bottom rows, then a
//                            2-pass separable dispatch -- horizontal kernel fn-ptr (a1+24) over radius = (analysis
//                            param - 2), then a combined kernel fn-ptr (a1+32) carrying the strength word a1+16.
//                            [实证 structure + exact taps; the SIMD micro-kernel is the referenceable ⛔S path.]
//   Clahe    <- zltCCLAHE   (vft 0x180504F28): tiled clip-limited hist EQ. Kernel sub_1801E0820 confirms the
//                            STRUCTURE exactly: v78[256] histogram, v79[64] = 8x8=64 tiles, v80[256] CDF/map.
//                            [T5 correction] apply sub_1801E10F0: the luma clamp is RANGE-FLAG driven --
//                            [16,235] (TV/limited range) or [0,255] (full range) selected by the frame's
//                            color-range field *(hdr+124); NOT the "254/255" noted earlier. The CLIP LIMIT is
//                            a CONFIG param (SetConfig cmd 0x70004 -> obj+312), not a hardcoded constant --
//                            our clip=3.0 default is a placeholder for that configurable value.
//   LightAdapt<- zltCLightAdaption (vft 0x180504CA8): auto-brightness = BACKLIGHT DETECTION + shadow lift.
//                            Fully RE'd 2025-07 [实证]: apply sub_1801BF500 -> resolution tier (min(w,h): >=720 ->
//                            subsample shift 3, >=360 -> 2, >=180 -> 1, else 0) -> attention_integ sub_1801C11D0
//                            (maps a normalized face/ROI rect, clamp[0,1], reject <1/64 area, 1/4 & 1/8 insets,
//                            adaptive subsample shift so ROI hist <=200 samples) -> curve_core sub_1801C1350
//                            (256-bin ROI luma hist -> GEOMETRIC-MEAN luma via sub_1801C1100 = exp(sum h[i]*log(i)
//                            / (N - h[0])), + Shannon entropy -Sum p*log2 p; if ROI geomean <= 100 [dark subject]:
//                            full-frame 256-bin hist -> highlight fraction = count(bins 240..255)/N; if highlight
//                            >= 10% AND frame geomean <= 170 -> set the "backlit -> brighten" flag). The pixel
//                            tone-map is then SIMD-dispatched (a1+56 or *(a1+160)+216, two variants) -- exact curve
//                            taps live in that ⛔S kernel; metrics + gating cascade below are 实证/bit-exact.
//   ColorAdapt<- zltCColorAdaption (vft 0x180504D18): auto white-balance on U/V. Apply sub_1801CB090 builds a
//                            4x4x192B color-correction LUT from a const seed table (qword_1804174C0) with a
//                            grayscale-diagonal init (triplet (v,v,v)) then a SIMD apply; kernels sub_1801CBD10/
//                            CBFC0 do a fixed-point neighbour-weighted chroma remap toward neutral 127/128 =
//                            intent is GRAY-WORLD WB. Modeled behaviorally as chroma-mean pull to 128.
//
//   NEW finds (2025-07), documented for completeness (not reimplemented as VFX ops here):
//   * zltCAttentionLight  (vft 0x180505040): the ROI/saliency front-end that FEEDS LightAdapt the face/subject
//     rect (a3 float[4]). slot3 config gates a3[3]==16 / a3[5]==3328; slot2 is telemetry-wrapped (MethodStatistics)
//     dispatch to a detector. This is a learned saliency/face locator -> boundary ⛔W: treat the ROI as an INPUT
//     (feed our own face/ROI box), do NOT lift Zoom's weights.
//   * zltCColorSpaceCvt   (vft 0x180505518): the pixel-format / color-space converter (fills the audit's
//     "color conversion" gap). slot2 sub_18023D890 -> format-pair dispatch sub_18023DEC0/sub_18023E100 -> SIMD
//     convert kernels (YUV<->RGB / packed<->planar). Standard reproducible CSC (✅ CPU SIMD).
#include <vector>
#include <cstdint>
#include <algorithm>
#include <cmath>

namespace recon { namespace vfx {

inline uint8_t clamp8(float v) { return (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v + 0.5f)); }

// ---- Zoom's EXACT zltCSharpen (RE'd from the scalar+SSE+AVX2 kernels sub_1801ABCA0 / sub_1801ABB90 /
// sub_180391440 / sub_180391760): a 3x3 GAUSSIAN (binomial) blur [1 2 1; 2 4 2; 1 2 1]/16, then a
// THRESHOLDED unsharp mask with a /128 fixed-point gain — out = Y + (gain·detail)>>7 only where
// |detail| = |Y-blur| > threshold (so flat-area noise isn't amplified). gain/threshold are Zoom's config
// knobs (packed hi16/lo16 in the object's +16 amount word); the KERNEL + fixed-point format are exact. ----
inline void Sharpen(uint8_t* Y, int w, int h, float gain = 0.9f, int threshold = 4) {
  if (w < 3 || h < 3) return;
  std::vector<int> blur((size_t)w * h);
  auto at = [&](int x, int y) { x = x < 0 ? 0 : (x >= w ? w - 1 : x); y = y < 0 ? 0 : (y >= h ? h - 1 : y); return (int)Y[(size_t)y * w + x]; };
  for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {                       // 3x3 Gaussian /16 (Zoom's exact taps)
    int s = at(x-1,y-1) + 2*at(x,y-1) + at(x+1,y-1)
          + 2*at(x-1,y) + 4*at(x,y) + 2*at(x+1,y)
          + at(x-1,y+1) + 2*at(x,y+1) + at(x+1,y+1);
    blur[(size_t)y * w + x] = (s + 8) >> 4;
  }
  const int g = (int)(gain * 128.f + 0.5f);                                        // Zoom's >>7 fixed-point gain
  for (int i = 0; i < w * h; ++i) {
    int detail = (int)Y[i] - blur[i];
    if (detail > threshold || detail < -threshold) Y[i] = clamp8((float)((int)Y[i] + ((detail * g) >> 7)));
  }
}

// ---- CLAHE (zltCCLAHE): gx*gy tiles, per-tile clip-limited hist EQ, bilinear-blended between tiles. ----
inline void Clahe(uint8_t* Y, int w, int h, int gx = 8, int gy = 8, float clip = 3.0f) {
  if (w < gx || h < gy) return;
  const int NB = 256;
  int tw = w / gx, th = h / gy;                          // tile size
  std::vector<std::vector<float>> map((size_t)gx * gy, std::vector<float>(NB));   // per-tile 256->256 LUT
  for (int ty = 0; ty < gy; ++ty) for (int tx = 0; tx < gx; ++tx) {
    int x0 = tx * tw, y0 = ty * th, x1 = (tx == gx - 1) ? w : x0 + tw, y1 = (ty == gy - 1) ? h : y0 + th;
    long hist[NB] = {0}, cnt = 0;
    for (int y = y0; y < y1; ++y) for (int x = x0; x < x1; ++x) { hist[Y[(size_t)y * w + x]]++; cnt++; }
    if (!cnt) { auto& m = map[(size_t)ty * gx + tx]; for (int i = 0; i < NB; ++i) m[i] = (float)i; continue; }
    long climit = (long)(clip * cnt / NB); if (climit < 1) climit = 1;
    long excess = 0; for (int i = 0; i < NB; ++i) if (hist[i] > climit) { excess += hist[i] - climit; hist[i] = climit; }
    double addF = (double)excess / NB;                                     // redistribute clipped mass (float, no truncation)
    auto& m = map[(size_t)ty * gx + tx]; double acc = 0, scale = 255.0 / cnt;
    for (int i = 0; i < NB; ++i) { acc += hist[i] + addF; m[i] = (float)(acc * scale); }   // CDF -> mapping
  }
  // bilinear blend between the 4 nearest tile centers
  std::vector<uint8_t> out((size_t)w * h);
  for (int y = 0; y < h; ++y) {
    float fy = (y + 0.5f) / th - 0.5f; int ty0 = (int)std::floor(fy); float wy = fy - ty0;
    int tya = ty0 < 0 ? 0 : (ty0 >= gy ? gy - 1 : ty0), tyb = ty0 + 1 < gy ? (ty0 + 1 < 0 ? 0 : ty0 + 1) : gy - 1; if (ty0 < 0) { tya = tyb = 0; wy = 0; } if (ty0 >= gy - 1) { tya = tyb = gy - 1; wy = 0; }
    for (int x = 0; x < w; ++x) {
      float fx = (x + 0.5f) / tw - 0.5f; int tx0 = (int)std::floor(fx); float wx = fx - tx0;
      int txa = tx0 < 0 ? 0 : (tx0 >= gx ? gx - 1 : tx0), txb = tx0 + 1 < gx ? tx0 + 1 : gx - 1; if (tx0 < 0) { txa = txb = 0; wx = 0; } if (tx0 >= gx - 1) { txa = txb = gx - 1; wx = 0; }
      int v = Y[(size_t)y * w + x];
      float a = map[(size_t)tya * gx + txa][v], b = map[(size_t)tya * gx + txb][v];
      float c = map[(size_t)tyb * gx + txa][v], d = map[(size_t)tyb * gx + txb][v];
      out[(size_t)y * w + x] = clamp8((a * (1 - wx) + b * wx) * (1 - wy) + (c * (1 - wx) + d * wx) * wy);
    }
  }
  std::copy(out.begin(), out.end(), Y);
}

// (zltCDCC is NOT a contrast op — it is an edge-directed 2x upscaler, DCCI. See recon/zlt_dcci.hpp.
//  recon::dcci::Upscale2x. This file no longer defines a DCC contrast function.)

// ================= LightAdapt (zltCLightAdaption) -- EXACT decision cascade RE'd 2025-07 ==================
// Zoom's LightAdaption is NOT a generic "pull mean to 128" gamma. It is a BACKLIGHT DETECTOR that lifts a
// dark subject sitting in front of a bright background. The metrics and gating below are bit-exact from
// sub_1801C1350 / sub_1801C1100 / sub_1801C11D0; only the final pixel tone-map is SIMD-dispatched (⛔S), so
// the CURVE SHAPE here is [推断] (a shadow-lift that protects highlights) while the TRIGGER is [实证].
//
//   metric_1 = GEOMETRIC-MEAN luma (Reinhard log-average key):  exp( Sum_i hist[i]*log(i) / (N - hist[0]) )
//   metric_2 = Shannon entropy of the luma histogram:           -Sum_i p_i * log2(p_i)
//   highlight_frac = count(luma in [240,255]) / N
//   BACKLIT  <=>  roi_geomean <= 100  AND  frame_highlight_frac >= 0.10  AND  frame_geomean <= 170
// The ROI is the attention/face box (zltCAttentionLight); with no detector we use the whole frame as ROI,
// which degrades gracefully (whole-frame geomean substitutes for subject geomean).

// exact geometric-mean luma over a 256-bin histogram, excluding the pure-black bin (matches sub_1801C1100).
inline double GeoMeanLuma(const long hist[256], long N) {
  long denom = N - hist[0]; if (denom <= 0) return 0.0;
  double s = 0.0;
  for (int i = 1; i < 256; ++i) if (hist[i]) s += (double)hist[i] * std::log((double)i);   // coef[i] = log(i)
  return std::exp(s / (double)denom);                                                        // Zoom rounds (+0.5)
}
inline double LumaEntropy(const long hist[256], long N) {                                    // -Sum p*log2 p
  if (N <= 0) return 0.0; double e = 0.0;
  for (int i = 0; i < 256; ++i) if (hist[i]) { double p = (double)hist[i] / (double)N; e -= p * std::log2(p); }
  return e;
}
// Zoom's per-axis analysis subsample shift from min(w,h): >=720->3, >=360->2, >=180->1, else 0 (1<<shift stride).
inline int LightTierShift(int w, int h) { int m = w < h ? w : h; return m >= 720 ? 3 : m >= 360 ? 2 : m >= 180 ? 1 : 0; }

// Full LightAdapt: rx0..ry1 is the subject ROI in pixels (pass the whole frame if no face detector).
inline void LightAdaptROI(uint8_t* Y, int w, int h, int rx0, int ry0, int rx1, int ry1, float strength = 0.5f) {
  const long n = (long)w * h; if (n < 64 || w < 2 || h < 2) return;
  if (rx0 < 0) rx0 = 0; if (ry0 < 0) ry0 = 0; if (rx1 > w) rx1 = w; if (ry1 > h) ry1 = h;
  if (rx1 - rx0 < 2 || ry1 - ry0 < 2) { rx0 = 0; ry0 = 0; rx1 = w; ry1 = h; }
  const int fs = 1 << LightTierShift(w, h);                                 // full-frame subsample step
  // ROI histogram (adaptive step so <=~200 samples, mirroring sub_1801C11D0's shift search)
  int rstep = 1; while ((long)((rx1 - rx0) / rstep) * ((ry1 - ry0) / rstep) > 200 && rstep < 64) rstep <<= 1;
  long rhist[256] = {0}, rc = 0;
  for (int y = ry0; y < ry1; y += rstep) for (int x = rx0; x < rx1; x += rstep) { rhist[Y[(size_t)y * w + x]]++; rc++; }
  if (rc < 8) return;
  const double roi_geo = GeoMeanLuma(rhist, rc);
  // full-frame histogram: geomean + highlight fraction (bins 240..255)
  long fhist[256] = {0}, fc = 0;
  for (int y = 0; y < h; y += fs) for (int x = 0; x < w; x += fs) { fhist[Y[(size_t)y * w + x]]++; fc++; }
  const double frame_geo = GeoMeanLuma(fhist, fc);
  long hi = 0; for (int i = 240; i < 256; ++i) hi += fhist[i];
  const double hl = fc ? (double)hi / (double)fc : 0.0;
  const bool backlit = roi_geo <= 100.0 && hl >= 0.10 && frame_geo <= 170.0;   // [实证] trigger cascade
  if (!backlit) return;                                                        // Zoom applies no lift otherwise
  // [推断] shadow-lift tone map: brighten shadows toward the subject target, hold highlights (>=240) at identity
  // so the bright background does not blow out. Lift amount scales with how dark the subject is and `strength`.
  const double target = 110.0;                                                 // subject brought up to ~110 key
  double gamma = std::log(target / 255.0) / std::log(std::max(1.0, roi_geo) / 255.0);   // gamma<1 lifts shadows
  gamma = 1.0 + (gamma - 1.0) * (double)strength;
  if (gamma < 0.2) gamma = 0.2; else if (gamma > 5.0) gamma = 5.0;
  uint8_t lut[256];
  for (int i = 0; i < 256; ++i) {
    double v = 255.0 * std::pow(i / 255.0, gamma);
    if (i >= 200) { double t = (i - 200) / 55.0; if (t > 1) t = 1; v = v * (1 - t) + i * t; }  // roll toward identity into highlights
    lut[i] = clamp8((float)v);
  }
  for (long i = 0; i < n; ++i) Y[i] = lut[Y[i]];
}
// Convenience whole-frame overload (no face detector): ROI = whole frame.
inline void LightAdapt(uint8_t* Y, int w, int h, float strength = 0.5f) {
  LightAdaptROI(Y, w, h, 0, 0, w, h, strength);
}

// ---- ColorAdapt (zltCColorAdaption): auto white-balance on the chroma planes. Kernels sub_1801CBD10/
// sub_1801CBFC0 RE'd: process U and V at 4:2:0 half-res with a fixed-point neighbour-weighted chroma remap
// `((25*a + 128*b + 13*c + 64)>>7) - bias` toward the neutral point (127/128). The correction the SIMD
// applies is derived per-frame from chroma statistics; the intent is GRAY-WORLD white balance (a neutral
// scene averages to chroma 128). Model: shift each chroma-plane mean toward 128 by `strength`. ----
inline void ColorAdapt(uint8_t* U, uint8_t* V, int cw, int ch, float strength = 0.5f) {
  const long n = (long)cw * ch; if (n < 16) return;
  double mu = 0, mv = 0; for (long i = 0; i < n; ++i) { mu += U[i]; mv += V[i]; }
  mu /= n; mv /= n;
  const double du = (128.0 - mu) * (double)strength, dv = (128.0 - mv) * (double)strength;   // gray-world pull
  for (long i = 0; i < n; ++i) { U[i] = clamp8((float)(U[i] + du)); V[i] = clamp8((float)(V[i] + dv)); }
}

}}  // namespace recon::vfx
