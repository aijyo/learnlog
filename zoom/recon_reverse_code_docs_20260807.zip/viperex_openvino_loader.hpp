// viperex_openvino_loader.hpp -- clean-room reconstruction of viperex.dll's OpenVINO
// model-load harness. Body-verified from sub_180179AF0, which GetProcAddress-resolves
// the OpenVINO **Inference Engine C API** (ie_core_*) out of openvino_c.dll and loads
// the model straight from memory:
//     ie_core_create
//     ie_core_read_network            / ie_core_read_network_from_memory   <-- in-memory
//     ie_core_get_available_devices   / ie_core_available_devices_free
//     ie_core_free
//
// The load path (reconstructed): XOR-0xA7-decode the PE resource -> xml buffer + bin
// (weights) buffer (viperex_runtime.hpp / sub_180171020) -> ie_core_create ->
// ie_core_read_network_from_memory(core, xml, xml_len, weights_blob, &network). No temp
// files. The OpenVINO runtime + the trained weights are boundaries (⛔ third-party / ⛔W);
// the C API signatures below are OpenVINO's public API (not IP), and the harness is
// injectable via a resolver so it runs and is testable without openvino_c.dll present.
#pragma once
#include <cstdint>
#include <cstddef>

namespace recon::viperex {

// Opaque OpenVINO IE C-API handles (real defs live in OpenVINO).
struct ie_core_t; struct ie_network_t; struct ie_blob_t;

// The exact C-API entry points viperex resolves (public OpenVINO signatures).
using Fn_core_create      = int  (*)(const char* xml_config, ie_core_t** core);
using Fn_read_from_memory  = int  (*)(ie_core_t* core, const uint8_t* xml, size_t xml_size,
                                      const ie_blob_t* weights, ie_network_t** network);
using Fn_get_devices       = int  (*)(const ie_core_t* core, void* avail_devices_out);
using Fn_devices_free      = void (*)(void* avail_devices);
using Fn_core_free         = void (*)(ie_core_t** core);

// Function-pointer table, filled by resolving symbols from a loaded openvino_c.dll
// (GetProcAddress), exactly as sub_180179AF0 does. Injectable for tests.
struct OvResolver {
    Fn_core_create     core_create      = nullptr;
    Fn_read_from_memory read_from_memory = nullptr;
    Fn_get_devices     get_devices      = nullptr;
    Fn_devices_free    devices_free     = nullptr;
    Fn_core_free       core_free        = nullptr;

    bool complete() const { return core_create && read_from_memory && core_free; }

    // Resolve all entry points from a module via a GetProcAddress-like callback.
    template <class GetProc>
    bool ResolveFrom(GetProc getproc) {
        core_create      = reinterpret_cast<Fn_core_create>(getproc("ie_core_create"));
        read_from_memory = reinterpret_cast<Fn_read_from_memory>(getproc("ie_core_read_network_from_memory"));
        get_devices      = reinterpret_cast<Fn_get_devices>(getproc("ie_core_get_available_devices"));
        devices_free     = reinterpret_cast<Fn_devices_free>(getproc("ie_core_available_devices_free"));
        core_free        = reinterpret_cast<Fn_core_free>(getproc("ie_core_free"));
        return complete();
    }
};

// The reconstructed load harness: decoded IR (xml + weights) -> OpenVINO network.
class OpenVinoLoader {
public:
    explicit OpenVinoLoader(const OvResolver& r) : r_(r) {}

    // create the IE core once (ie_core_create).
    int Open() {
        if (!r_.complete()) return -1;
        return r_.core_create(nullptr, &core_);   // xml_config = null (no plugins.xml)
    }
    // Load a model from the XOR-decoded in-memory IR (ie_core_read_network_from_memory).
    // `weights` is the .bin blob wrapped as an ie_blob_t by the caller (opaque here).
    int LoadModelFromMemory(const uint8_t* xml, size_t xml_len, const ie_blob_t* weights) {
        if (!core_) return -2;
        return r_.read_from_memory(core_, xml, xml_len, weights, &network_);
    }
    ie_network_t* network() const { return network_; }
    void Close() { if (core_ && r_.core_free) r_.core_free(&core_); core_ = nullptr; network_ = nullptr; }
    ~OpenVinoLoader() { Close(); }

private:
    OvResolver     r_;
    ie_core_t*     core_    = nullptr;
    ie_network_t*  network_ = nullptr;
};

} // namespace recon::viperex
