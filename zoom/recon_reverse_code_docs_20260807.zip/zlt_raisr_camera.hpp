#pragma once
// zlt_raisr_camera.hpp — CLEAN-ROOM reconstruction of Zoom's CAMERA RAISR *structure*
// (ns_vpp::zltCRaisr / ns_gct::CGPURaisr), recovered from the disassembled Raisrx2 cs_5_0 shader.
// See recon/zlt_raisr_camera.md. What is reproduced here is DESIGN (recovered, reproducible):
//
//   * 22-bucket gradient hash = 11 angle bins × 2 strength levels, NO coherence dimension
//     (screen RAISR adds coherence -> 48; camera is the lighter 11×2 = 22).
//   * multi-scale x1/x2/x3, phases = scale² (1/4/9), taps/phase = 25 (x1, 5×5) or 13 (x2/x3, diamond).
//   * structure-tensor math: [1,5,1]/7 gradients, 3×3 tensor average, λ1 eigenvalue, angle = atan(·)·10/π
//     rounded & clamped to [0,10], strength = sqrt(λ1) split at 0.5.
//   * source-size scale selection (cmd 3): off for ≥720p sources; breakpoints 180p/480p/720p + 1.18×.
//   * change-detection early-out (skip a tile that equals the previous frame).
//
// The learned COEFFICIENTS are a ⛔W boundary — supplied via IFilterBankCam (train your own, e.g. the
// raisr_train_matched per-(bucket,phase) least-squares adapted to this shape), defaulting to passthrough
// so the pipeline runs (bilinear) without a bank. Zoom's embedded .rdata weights are NOT used here.

#include <vector>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <algorithm>

namespace recon { namespace zltcam {

constexpr double kPI = 3.14159265358979323846;

struct CamRaisrConfig {
  int   scale        = 2;      // 1 / 2 / 3  (Raisrx1 / Raisrx2 / Raisrx3)
  int   angle_bins   = 11;     // shader: round(angle · 10/π), clamp [0,10]
  int   strength_bins= 2;      // shader: strength > str_thresh
  float str_thresh   = 0.5f;   // shader literal 0.5 on the eigenvalue-derived strength
  int   Buckets()      const { return angle_bins * strength_bins; }   // 22
  int   Phases()       const { return scale * scale; }                // 1 / 4 / 9
  int   TapsPerPhase() const { return scale == 1 ? 25 : 13; }         // 5×5 (x1) or diamond-13 (x2/x3)
};

// --- patch footprints matching the recovered tap counts (exact Zoom footprint is [推断]) ------------
// 25 taps = 5×5 square; 13 taps = Manhattan-diamond radius 2 (|dx|+|dy| ≤ 2 == 13 points).
inline const std::vector<std::pair<int,int>>& PatchOffsets(int taps) {
  static const std::vector<std::pair<int,int>> sq5 = [] {
    std::vector<std::pair<int,int>> v; for (int dy=-2;dy<=2;++dy) for (int dx=-2;dx<=2;++dx) v.push_back({dx,dy}); return v; }();
  static const std::vector<std::pair<int,int>> dia = [] {
    std::vector<std::pair<int,int>> v; for (int dy=-2;dy<=2;++dy) for (int dx=-2;dx<=2;++dx) if (std::abs(dx)+std::abs(dy)<=2) v.push_back({dx,dy}); return v; }();
  return taps == 25 ? sq5 : dia;
}

// --- 22-bucket structure-tensor hash (mirrors the Raisrx2 shader) ------------------------------------
inline float GradX(const float* im, int w, int h, int x, int y) {  // [1,5,1]/7 vertical smoothing, horiz diff
  auto P = [&](int xx,int yy){ xx=xx<0?0:(xx>=w?w-1:xx); yy=yy<0?0:(yy>=h?h-1:yy); return im[(size_t)yy*w+xx]; };
  return ((P(x+1,y-1)-P(x-1,y-1)) + 5.f*(P(x+1,y)-P(x-1,y)) + (P(x+1,y+1)-P(x-1,y+1))) * (1.f/7.f);
}
inline float GradY(const float* im, int w, int h, int x, int y) {  // [1,5,1]/7 horiz smoothing, vert diff
  auto P = [&](int xx,int yy){ xx=xx<0?0:(xx>=w?w-1:xx); yy=yy<0?0:(yy>=h?h-1:yy); return im[(size_t)yy*w+xx]; };
  return ((P(x-1,y+1)-P(x-1,y-1)) + 5.f*(P(x,y+1)-P(x,y-1)) + (P(x+1,y+1)-P(x+1,y-1))) * (1.f/7.f);
}
inline int ClassifyCam(const float* im, int w, int h, int cx, int cy, const CamRaisrConfig& cfg,
                       double* strengthOut = nullptr) {
  double a=0,b=0,c=0;                              // structure tensor {Σgx², Σgxgy, Σgy²} over 3×3 (×1/9)
  for (int dy=-1; dy<=1; ++dy) for (int dx=-1; dx<=1; ++dx) {
    double gx = GradX(im,w,h,cx+dx,cy+dy), gy = GradY(im,w,h,cx+dx,cy+dy);
    a += gx*gx; b += gx*gy; c += gy*gy;
  }
  a/=9.0; b/=9.0; c/=9.0;
  double tr = a + c, disc = std::sqrt(std::max(0.0, 0.25*tr*tr - (a*c - b*b)));
  double lam1 = 0.5*tr + disc, strength = std::sqrt(std::max(0.0, lam1));
  if (strengthOut) *strengthOut = strength;
  double theta = 0.5 * std::atan2(2.0*b, a - c);   // structure-tensor orientation, [-π/2,π/2)
  if (theta < 0) theta += kPI;                     // -> [0,π)
  int abin = (int)std::lround(theta * (cfg.angle_bins - 1) / kPI);  // ×10/π, [0,10]
  abin = abin < 0 ? 0 : (abin > cfg.angle_bins-1 ? cfg.angle_bins-1 : abin);
  int sbin = strength > cfg.str_thresh ? 1 : 0;
  return abin + cfg.angle_bins * sbin;             // [0,21]
}
inline int PhaseOf(int x, int y, int scale) { return (y % scale) * scale + (x % scale); }

// --- source-size scale selection (cmd 3, sub_1801B8EA0) ----------------------------------------------
// Returns 0 = do NOT super-res, else the Raisrx scale index (mapping {1->x2, 2->x3, x1 as 0-path} is 推断).
inline int SelectScale(int srcW, int srcH, int dstW, int dstH, int mode = 1) {
  long srcPx = (long)srcW * srcH;
  int v = (dstW <= (int)(srcW*1.18) || dstH <= (int)(srcH*1.18))
            ? ((srcW >= dstW || srcH >= dstH) ? 0 : 1) : 2;
  if (srcPx > 921600) return 0;                    // ≥720p source -> off
  if (srcPx <= 307200 || mode == 3) {              // ≤480p, or PPT/detail mode
    if (v) { if (srcPx <= 307200) { if (mode==1 && srcPx > 57600) v = 1; } else v = 1; }
  } else return 0;                                 // 480p..720p, non-PPT -> off
  return v;
}

// --- pluggable filter bank (our weights) -------------------------------------------------------------
struct IFilterBankCam {
  virtual ~IFilterBankCam() = default;
  virtual const float* filter(int phase, int bucket) const = 0;   // TapsPerPhase() coeffs, or null
  virtual int taps() const = 0;
};
struct PassthroughCam : IFilterBankCam {                          // no bank -> bilinear base only
  const float* filter(int,int) const override { return nullptr; }
  int taps() const override { return 0; }
};

// A trained bank: file = header {NPHASE, NBUCK, NTAPS, SCALE} (4 int) + data[NPHASE*NBUCK*NTAPS] float.
// Coefficients are OURS (train to this shape); this is the loader/holder, not Zoom's weights.
struct TrainedCamBank : IFilterBankCam {
  int nphase=0, nbuck=0, ntaps=0, scale=0; std::vector<float> data;
  bool load(const char* path) {
    std::FILE* f = std::fopen(path,"rb"); if (!f) return false; int h[4];
    bool ok = std::fread(h,sizeof(int),4,f)==4;
    if (ok) { nphase=h[0]; nbuck=h[1]; ntaps=h[2]; scale=h[3];
              data.assign((size_t)nphase*nbuck*ntaps,0.f);
              ok = nphase>0 && nbuck>0 && ntaps>0 && std::fread(data.data(),sizeof(float),data.size(),f)==data.size(); }
    std::fclose(f); return ok;
  }
  void fromMemory(int np,int nb,int nt,int sc,const std::vector<float>& d){ nphase=np;nbuck=nb;ntaps=nt;scale=sc;data=d; }
  bool save(const char* path) const {
    std::FILE* f=std::fopen(path,"wb"); if(!f) return false; int h[4]={nphase,nbuck,ntaps,scale};
    std::fwrite(h,sizeof(int),4,f); std::fwrite(data.data(),sizeof(float),data.size(),f); std::fclose(f); return true;
  }
  const float* filter(int phase,int bucket) const override {
    if (phase<0||phase>=nphase||bucket<0||bucket>=nbuck) return nullptr;
    return &data[((size_t)phase*nbuck+bucket)*ntaps];
  }
  int taps() const override { return ntaps; }
};

// --- change-detection early-out (shader stage 1): a tile identical to the previous frame is skipped ----
inline bool TileChanged(const float* cur, const float* prev, int w, int h, int x0, int y0, int tw, int th) {
  if (!prev) return true;
  for (int y=y0; y<y0+th && y<h; ++y) for (int x=x0; x<x0+tw && x<w; ++x)
    if (cur[(size_t)y*w+x] != prev[(size_t)y*w+x]) return true;
  return false;
}

// --- upscaler: Zoom's DIRECT convention -- classify on the LR, map an LR patch straight to each HR
// sub-pixel (per phase, per bucket). Matches the Raisrx2 shader (filter · LR-patch -> HR sub-pixel).
// Falls back to a bilinear base for cells with no trained filter (or a passthrough bank).
class CamRaisrUpscaler {
public:
  CamRaisrUpscaler(CamRaisrConfig cfg, const IFilterBankCam* bank) : cfg_(cfg), bank_(bank) {}
  void Upscale(const float* in, int w, int h, std::vector<float>& out, int& ow, int& oh) const {
    const int s = cfg_.scale; ow = w*s; oh = h*s; out.assign((size_t)ow*oh, 0.f);
    // bilinear base (the fallback; also the whole output for a passthrough bank)
    for (int oy=0; oy<oh; ++oy) {
      float fy = (oy+0.5f)/s - 0.5f; int y0=(int)std::floor(fy); float wy=fy-y0;
      int y1 = y0+1<h ? y0+1 : h-1; y0 = y0<0?0:(y0>=h?h-1:y0);
      for (int ox=0; ox<ow; ++ox) {
        float fx=(ox+0.5f)/s-0.5f; int x0=(int)std::floor(fx); float wx=fx-x0;
        int x1=x0+1<w?x0+1:w-1; x0=x0<0?0:(x0>=w?w-1:x0);
        float a=in[(size_t)y0*w+x0], b=in[(size_t)y0*w+x1], c=in[(size_t)y1*w+x0], d=in[(size_t)y1*w+x1];
        out[(size_t)oy*ow+ox] = (a*(1-wx)+b*wx)*(1-wy) + (c*(1-wx)+d*wx)*wy;
      }
    }
    if (!bank_ || bank_->taps() == 0) return;                    // passthrough -> bilinear only
    const int taps = cfg_.TapsPerPhase(); const auto& off = PatchOffsets(taps);
    for (int ly=0; ly<h; ++ly) for (int lx=0; lx<w; ++lx) {
      int bucket = ClassifyCam(in, w, h, lx, ly, cfg_);          // classify on the LR source
      for (int py=0; py<s; ++py) for (int px=0; px<s; ++px) {
        const float* f = bank_->filter(py*s + px, bucket);       // phase = py*s+px
        if (!f) continue;                                        // keep bilinear for untrained cells
        float acc = 0;
        for (int k=0;k<taps;++k) {
          int sx=lx+off[k].first, sy=ly+off[k].second;
          sx=sx<0?0:(sx>=w?w-1:sx); sy=sy<0?0:(sy>=h?h-1:sy);
          acc += in[(size_t)sy*w+sx]*f[k];
        }
        out[(size_t)(ly*s+py)*ow + (lx*s+px)] = acc;
      }
    }
  }
private:
  CamRaisrConfig cfg_;
  const IFilterBankCam* bank_;
};

}} // namespace recon::zltcam
