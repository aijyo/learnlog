// raisr_gpu.hpp -- GPU (D3D11 compute) RAISR apply. CLEAN-ROOM: this is our own HLSL implementing the
// RECOVERED algorithm (structure tensor -> coherence/angle -> 12/2/2 hash -> 121-tap bucket filter, the
// structure disassembled from zlt.dll's cs_5_0 kernel), fed with OUR trained bank. It does NOT embed Zoom's
// proprietary .cso bytecode (that would be verbatim proprietary code AND would need Zoom's ⛔W filterBuckets
// weights, incompatible with our bank). Same math as recon::zlt::Classify + RaisrUpscaler, moved to the GPU
// where Zoom runs it (the recovered 15ms watchdog confirms Zoom treats RAISR as a ~real-time GPU op).
#pragma once
#include <d3d11.h>
#include <d3dcompiler.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <vector>
#include <string>
#include <cmath>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "dxgi.lib")

namespace recon::zlt {

class GpuRaisr {
    template <class T> using CP = Microsoft::WRL::ComPtr<T>;
public:
    // patch=11, nbuck=49 (48 grad + flat), nphase=4; bank = nphase*nbuck*taps floats (our trained weights).
    bool init(int patch, int nbuck, int nphase, float flatT, float strT, const std::vector<float>& bank) {
        patch_ = patch; nbuck_ = nbuck; nphase_ = nphase; flatT_ = flatT; strT_ = strT; taps_ = patch*patch;
        // Pick a REAL hardware adapter explicitly. adapter=nullptr often yields "Microsoft Basic Render Driver"
        // (software WARP) which is ~20x slower. Enumerate via DXGI, skip the DXGI_ADAPTER_FLAG_SOFTWARE one,
        // and prefer the most dedicated VRAM (= the discrete GPU over an iGPU).
        D3D_FEATURE_LEVEL fl;
        Microsoft::WRL::ComPtr<IDXGIFactory1> fac; Microsoft::WRL::ComPtr<IDXGIAdapter1> pick, a;
        if (SUCCEEDED(CreateDXGIFactory1(IID_PPV_ARGS(&fac)))) {
            SIZE_T bestVram = 0;
            for (UINT i = 0; fac->EnumAdapters1(i, &a) != DXGI_ERROR_NOT_FOUND; ++i) {
                DXGI_ADAPTER_DESC1 d{}; a->GetDesc1(&d);
                if (!(d.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) && (!pick || d.DedicatedVideoMemory >= bestVram)) { bestVram = d.DedicatedVideoMemory; pick = a; }
                a.Reset();
            }
        }
        if (pick && SUCCEEDED(D3D11CreateDevice(pick.Get(), D3D_DRIVER_TYPE_UNKNOWN, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &dev_, &fl, &ctx_))) hw_ = true;
        if (!dev_)   // fallback: default hardware, then software WARP
            for (D3D_DRIVER_TYPE dt : { D3D_DRIVER_TYPE_HARDWARE, D3D_DRIVER_TYPE_WARP })
                if (SUCCEEDED(D3D11CreateDevice(nullptr, dt, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &dev_, &fl, &ctx_))) { hw_ = (dt == D3D_DRIVER_TYPE_HARDWARE); break; }
        if (!dev_) return false;

        std::string hlsl = buildHLSL();
        CP<ID3DBlob> code, err;
        if (FAILED(D3DCompile(hlsl.c_str(), hlsl.size(), "raisr.hlsl", nullptr, nullptr, "main", "cs_5_0", 0, 0, &code, &err))) {
            if (err) std::fprintf(stderr, "raisr_gpu HLSL compile error:\n%.*s\n", (int)err->GetBufferSize(), (const char*)err->GetBufferPointer());
            return false;
        }
        if (FAILED(dev_->CreateComputeShader(code->GetBufferPointer(), code->GetBufferSize(), nullptr, &cs_))) return false;

        // trained bank -> immutable structured buffer + SRV
        D3D11_BUFFER_DESC bd{}; bd.ByteWidth = (UINT)(bank.size()*4); bd.Usage = D3D11_USAGE_IMMUTABLE; bd.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        bd.StructureByteStride = 4; bd.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;
        D3D11_SUBRESOURCE_DATA sd{}; sd.pSysMem = bank.data();
        if (FAILED(dev_->CreateBuffer(&bd, &sd, &bankBuf_))) return false;
        D3D11_SHADER_RESOURCE_VIEW_DESC sv{}; sv.ViewDimension = D3D11_SRV_DIMENSION_BUFFER; sv.Format = DXGI_FORMAT_UNKNOWN; sv.Buffer.NumElements = (UINT)bank.size();
        if (FAILED(dev_->CreateShaderResourceView(bankBuf_.Get(), &sv, &bankSRV_))) return false;

        // constants
        D3D11_BUFFER_DESC cb{}; cb.ByteWidth = 32; cb.Usage = D3D11_USAGE_DYNAMIC; cb.BindFlags = D3D11_BIND_CONSTANT_BUFFER; cb.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        if (FAILED(dev_->CreateBuffer(&cb, nullptr, &cbuf_))) return false;

        // which adapter did D3D actually pick?
        Microsoft::WRL::ComPtr<IDXGIDevice> dxgi; Microsoft::WRL::ComPtr<IDXGIAdapter> ad;
        if (SUCCEEDED(dev_.As(&dxgi)) && SUCCEEDED(dxgi->GetAdapter(&ad))) {
            DXGI_ADAPTER_DESC d{}; ad->GetDesc(&d);
            char nm[256]; std::snprintf(nm, sizeof(nm), "%ls", d.Description); adapter_ = nm;
        }
        // timestamp queries -> pure GPU compute time (read AFTER the readback synced, so non-blocking)
        D3D11_QUERY_DESC qd{}; qd.Query = D3D11_QUERY_TIMESTAMP_DISJOINT; dev_->CreateQuery(&qd, &qDis_);
        qd.Query = D3D11_QUERY_TIMESTAMP; dev_->CreateQuery(&qd, &qT0_); dev_->CreateQuery(&qd, &qT1_);
        ok_ = true; return true;
    }

    // base = W*H bilinear-upscaled luma (the same base recon::zlt classifies on). out = W*H RAISR luma.
    // Caller measures wall-clock latency; computeMs (optional) = pure GPU compute time (excludes readback).
    bool upscale(const float* base, int W, int H, std::vector<float>& out, double* computeMs = nullptr) {
        if (!ok_) return false;
        ensureTex(W, H);
        // upload base
        D3D11_MAPPED_SUBRESOURCE m{};
        if (FAILED(ctx_->Map(inTex_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) return false;
        for (int y = 0; y < H; ++y) std::memcpy((uint8_t*)m.pData + (size_t)y*m.RowPitch, base + (size_t)y*W, (size_t)W*4);
        ctx_->Unmap(inTex_.Get(), 0);
        // constants
        struct C { int W, H, R, NBUCK; float flatT, strT; int TAPS, pad; } c{ W, H, patch_/2, nbuck_, flatT_, strT_, taps_, 0 };
        if (SUCCEEDED(ctx_->Map(cbuf_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) { std::memcpy(m.pData, &c, sizeof(c)); ctx_->Unmap(cbuf_.Get(), 0); }
        // bind + dispatch (timed)
        ID3D11ShaderResourceView* srvs[2] = { bankSRV_.Get(), inSRV_.Get() };
        ID3D11UnorderedAccessView* uav = outUAV_.Get(); ID3D11Buffer* cbs = cbuf_.Get();
        ctx_->CSSetShader(cs_.Get(), nullptr, 0);
        ctx_->CSSetShaderResources(0, 2, srvs);
        ctx_->CSSetUnorderedAccessViews(0, 1, &uav, nullptr);
        ctx_->CSSetConstantBuffers(0, 1, &cbs);
        ctx_->Begin(qDis_.Get()); ctx_->End(qT0_.Get());
        ctx_->Dispatch((W + 15) / 16, (H + 15) / 16, 1);
        ctx_->End(qT1_.Get()); ctx_->End(qDis_.Get());
        // unbind UAV so we can copy out
        ID3D11UnorderedAccessView* nu = nullptr; ctx_->CSSetUnorderedAccessViews(0, 1, &nu, nullptr);
        ctx_->CopyResource(stage_.Get(), outTex_.Get());
        // readback (Map READ syncs -> the GPU is finished here, so the timestamp GetData below won't block)
        out.assign((size_t)W*H, 0.f);
        if (SUCCEEDED(ctx_->Map(stage_.Get(), 0, D3D11_MAP_READ, 0, &m))) {
            for (int y = 0; y < H; ++y) std::memcpy(out.data() + (size_t)y*W, (uint8_t*)m.pData + (size_t)y*m.RowPitch, (size_t)W*4);
            ctx_->Unmap(stage_.Get(), 0);
        }
        if (computeMs) { *computeMs = 0;
            D3D11_QUERY_DATA_TIMESTAMP_DISJOINT dj{}; UINT64 t0 = 0, t1 = 0;
            if (ctx_->GetData(qDis_.Get(), &dj, sizeof(dj), 0) == S_OK && !dj.Disjoint && dj.Frequency
                && ctx_->GetData(qT0_.Get(), &t0, sizeof(t0), 0) == S_OK && ctx_->GetData(qT1_.Get(), &t1, sizeof(t1), 0) == S_OK)
                *computeMs = (double)(t1 - t0) / dj.Frequency * 1000.0;
        }
        return true;
    }
    bool ok() const { return ok_; }
    bool hardware() const { return hw_; }
    const std::string& adapter() const { return adapter_; }

private:
    void ensureTex(int W, int H) {
        if (W == texW_ && H == texH_ && inTex_) return;
        texW_ = W; texH_ = H;
        auto mk = [&](D3D11_USAGE u, UINT bind, UINT cpu, CP<ID3D11Texture2D>& t) {
            D3D11_TEXTURE2D_DESC d{}; d.Width = W; d.Height = H; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R32_FLOAT;
            d.SampleDesc.Count = 1; d.Usage = u; d.BindFlags = bind; d.CPUAccessFlags = cpu; t.Reset(); dev_->CreateTexture2D(&d, nullptr, &t);
        };
        mk(D3D11_USAGE_DYNAMIC, D3D11_BIND_SHADER_RESOURCE, D3D11_CPU_ACCESS_WRITE, inTex_);
        mk(D3D11_USAGE_DEFAULT, D3D11_BIND_UNORDERED_ACCESS, 0, outTex_);
        mk(D3D11_USAGE_STAGING, 0, D3D11_CPU_ACCESS_READ, stage_);
        inSRV_.Reset(); outUAV_.Reset();
        dev_->CreateShaderResourceView(inTex_.Get(), nullptr, &inSRV_);
        dev_->CreateUnorderedAccessView(outTex_.Get(), nullptr, &outUAV_);
    }

    std::string buildHLSL() {
        // gaussian patch weights, identical to recon::zlt::Classify (exp(-(i^2+j^2)/(2*(r/2)^2)))
        int r = patch_/2, P = 2*r+1; std::string gw = "static const float GW[" + std::to_string(P*P) + "]={";
        char b[32];
        for (int j = -r; j <= r; ++j) for (int i = -r; i <= r; ++i) { std::snprintf(b, sizeof(b), "%.8ff,", (float)std::exp(-(i*i+j*j)/(2.0*(r*0.5)*(r*0.5)))); gw += b; }
        gw += "};";
        int TILE = 16 + 2*(r + 1);   // 16x16 output block + (R+1) apron each side (Zoom loads a tile into TGSM)
        std::string td = std::to_string(TILE);
        return
"StructuredBuffer<float> gBank : register(t0);\n"
"Texture2D<float> gBase : register(t1);\n"
"RWTexture2D<float> gOut : register(u0);\n"
"cbuffer C : register(b0){int W;int H;int R;int NBUCK;float flatT;float strT;int TAPS;int pad;};\n"
+ gw + "\n"
"#define TILE " + td + "\n"
"groupshared float LDS[TILE*TILE];\n"   // co-op tile in shared memory (the recovered Zoom design)
"[numthreads(16,16,1)]\n"
"void main(uint3 gid:SV_GroupID, uint3 tg:SV_GroupThreadID, uint3 dt:SV_DispatchThreadID){\n"
" int2 gs=int2(gid.x*16,gid.y*16); int2 torg=gs-int2(R+1,R+1);\n"
" int lidx=tg.y*16+tg.x;\n"
" [loop] for(int t=lidx;t<TILE*TILE;t+=256){ int tx=t%TILE,ty=t/TILE; int sx=clamp(torg.x+tx,0,W-1),sy=clamp(torg.y+ty,0,H-1); LDS[t]=gBase[int2(sx,sy)]; }\n"
" GroupMemoryBarrierWithGroupSync();\n"
" int x=dt.x,y=dt.y; if(x>=W||y>=H) return;\n"
" int cx=tg.x+(R+1), cy=tg.y+(R+1); float bv=LDS[cy*TILE+cx];\n"
" if(x<R||y<R||x>=W-R||y>=H-R){ gOut[int2(x,y)]=bv; return; }\n"
" int P=2*R+1; float gxx=0,gyy=0,gxy=0;\n"
" [loop] for(int j=-R;j<=R;j++){ [loop] for(int i=-R;i<=R;i++){\n"
"   int lx=cx+i, ly=cy+j;\n"
"   float gx=LDS[ly*TILE+(lx+1)]-LDS[ly*TILE+(lx-1)];\n"
"   float gy=LDS[(ly+1)*TILE+lx]-LDS[(ly-1)*TILE+lx];\n"
"   float w=GW[(j+R)*P+(i+R)]; gxx+=w*gx*gx; gyy+=w*gy*gy; gxy+=w*gx*gy;\n"
" }}\n"
" float tr=gxx+gyy, d=sqrt((gxx-gyy)*(gxx-gyy)+4*gxy*gxy);\n"
" float l1=(tr+d)*0.5, l2=(tr-d)*0.5;\n"
" float s1=sqrt(max(0,l1)), s2=sqrt(max(0,l2));\n"
" float strength=s1, coh=(s1+s2>1e-9)?(s1-s2)/(s1+s2):0;\n"
" int bucket;\n"
" if(strength<flatT){ bucket=NBUCK-1; }\n"
" else { float ang=0.5*atan2(2*gxy,gxx-gyy); if(ang<0) ang+=3.14159265;\n"
"   int ab=(int)round(ang*(11.0/3.14159265)); ab=clamp(ab,0,11);\n"
"   int sb=strength>=strT?1:0; int cb=coh>=0.5?1:0; bucket=cb*24+sb*12+ab; }\n"
" int phase=(y%2)*2+(x%2); int bidx=(phase*NBUCK+bucket)*TAPS;\n"
" float acc=0; int k=0;\n"
" [loop] for(int j2=-R;j2<=R;j2++){ [loop] for(int i2=-R;i2<=R;i2++){ acc+=gBank[bidx+k]*LDS[(cy+j2)*TILE+(cx+i2)]; k++; }}\n"
" gOut[int2(x,y)]=clamp(acc,0.0,255.0);\n"
"}\n";
    }

    bool ok_ = false, hw_ = false; int patch_ = 11, nbuck_ = 49, nphase_ = 4, taps_ = 121; float flatT_ = 0, strT_ = 0; int texW_ = 0, texH_ = 0;
    CP<ID3D11Device> dev_; CP<ID3D11DeviceContext> ctx_; CP<ID3D11ComputeShader> cs_;
    CP<ID3D11Buffer> cbuf_, bankBuf_; CP<ID3D11ShaderResourceView> bankSRV_;
    CP<ID3D11Texture2D> inTex_, outTex_, stage_; CP<ID3D11ShaderResourceView> inSRV_; CP<ID3D11UnorderedAccessView> outUAV_;
    CP<ID3D11Query> qDis_, qT0_, qT1_; std::string adapter_;
};

}  // namespace recon::zlt
