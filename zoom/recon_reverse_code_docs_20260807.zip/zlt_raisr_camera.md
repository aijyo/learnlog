# Zoom camera RAISR — `ns_vpp::zltCRaisr` full recovery (IDA + shader disasm, 2026-07)

Deep dive of the CAMERA super-resolution path `ns_vpp::zltCRaisr` (distinct from the screen path
`zltCScreenRAISR` covered elsewhere). Everything below is tagged **实证** (read from the decompile /
the disassembled shader) or **推断** (inferred). EAs are image-relative (base `0x180000000`), zlt.dll.

Clean-room boundary: the *structure/algorithm* below is design (recovered, reproducible). The learned
filter coefficients are a ⛔W boundary — they DO sit as embedded `.rdata` float arrays here (unlike the
screen path's runtime texture), but they are NOT copied into the demo; we train our own to the same shape.

---

## 1. Architecture — thin dispatcher → GPU object — 实证

`zltCRaisr` (vftable `0x180504B58`) is a thin `ns_util::zltIVppAlgoBase` that owns a GPU object
`ns_gct::CGPURaisr` and forwards to it. Object layout (实证, from the vtable methods):

| off | meaning |
|-----|---------|
| +0  | vftable |
| +16 | inner `CGPURaisr*` (a **192-byte / 0xC0** object, ctor `sub_1802B5C70`) |
| +24 | configured/enabled flag |
| +32/+40 | watchdog: frame counter / accumulated GPU ms |
| +56/+64/+68 | watchdog: per-frame budget ms / strike count / strike threshold |
| +72 | watchdog: timed-out flag (RAISR self-disabled) |
| +88/+104/+112 | heartbeat timestamp / reset interval µs / retry cooldown µs |

**Command interface** (feature id in arg2):

| vtbl | fn | cmd | action |
|------|----|-----|--------|
| slot3 | `sub_1801B90F0` | 4 | **Configure** — `alloc(0xC0)` → `CGPURaisr` ctor → call its vtbl+8 (Init) with a 2-qword config |
| slot4 | `sub_1801B8E70` | 5 | query enabled (+24) |
| slot5 | `sub_1801B9200` | **0x70000000** | **Apply** (per frame, with watchdog); **cmd 3** = scale-select query (§5) |

`CGPURaisr` GPU apply is invoked through the GPU object's **vtbl+24** (slot3 `sub_1802B6990`).

## 2. Three scales + filter-bank layout — 实证 (Configure `sub_1802B6020`)

`CGPURaisr::Configure` loads three compute shaders by name — **`Raisrx1` / `Raisrx2` / `Raisrx3`**
(×1 / ×2 / ×3) — and, per scale, uploads two embedded coefficient arrays (A/B) into `filterBuckets`
textures. Per-scale float-count-per-bucket = `{25, 52, 117}` (loop `v67[]`, `while(<3)`).

**Bank layout = [22 buckets] × [per-bucket floats], per-bucket = phases × taps:**

| scale | floats/bucket | = phases × taps | phases (=scale²) | taps/phase | bank bytes (22 buckets) |
|-------|---------------|-----------------|------------------|------------|-------------------------|
| x1    | 25  | 1 × **25** (5×5) | 1 | 25 | 22×25×4 = **2200** ✓ |
| x2    | 52  | 4 × **13**       | 4 | 13 | 22×52×4 = **4576** ✓ |
| x3    | 117 | 9 × **13**       | 9 | 13 | 22×117×4 = **10296** ✓ |

Embedded arrays (analysis-only, NOT shipped): x1 `0x1804D0D80`/`0x1804D04E0`, x2 `0x1804CF300`/
`0x1804CB8E0`, x3 `0x1804CCAC0` (A/B share). Values are small (−0.09..+0.11) alternating-sign
high-pass coefficients. (My first pass mis-read the 22 as *taps*; it is the **bucket count** — the byte
totals match either way because 22 is a common factor, but §3 fixes the semantics.)

## 3. Raisrx2 algorithm — 实证 (disassembled cs_5_0, 346 instr, 64 threads 4×16)

Processes a **16×16 input tile → 32×32 output** (2×). Resources: `g_srcLuma`(t0 tex), `filterBuckets`
(t1 tex), `g_dstLuma`/`g_refLuma`/`g_buffLuma`(u0/u1/u2), cbuffer `imageInfo{imgSrcW,H,imgDstW,H}`.

1. **Tile cache** — load a **20×20** luma tile (16×16 + 2-px halo) into groupshared `g0` (400 floats).
   Copy to `g_buffLuma`; compare against `g_refLuma` → if the tile is unchanged, set a skip flag
   (raw TGSM `g2`) and `ret` early. **Change-detection early-out** — static regions cost ~0.

2. **Structure-tensor gradients** → groupshared `g1` (3 floats/pixel over an 18×18 inner region):
   - gradient = central difference with a `[1,5,1]` perpendicular smoothing, normalized **×1/7 (0.142857)**.
   - store `{gx², gy², gx·gy}` per pixel.

3. **Hash** (per output pixel; SIMD over 4 pixels):
   - accumulate the tensor over a **3×3** window (**×1/9 = 0.111111**) → `{a=Σgx², c=Σgy², b=Σgxgy}`.
   - eigenvalue `λ1 = (a+c)/2 + sqrt( ((a−c)/2)² + b² )`; `strength = sqrt(λ1)`.
   - **angle** = `atan(...)` via a 5-term minimax poly `{0.020835, −0.085133, 0.180141, −0.330299,
     0.999866}` (with π/2 = 1.570796, −π = 0xc0490fdb), then **× 10/π (3.183099)**, `round`, clamp
     **[0,10] → 11 angle bins**.
   - **bucket = angle + 11 × (strength > 0.5)** → **[0,21] = 22 buckets = 11 angle × 2 strength.**
   - **No coherence dimension** (the screen path adds a 2nd/coherence split → 48 buckets; camera is
     lighter: 11×2 = 22).

4. **Filter apply** — index `filterBuckets[bucket]` (52 floats = 4 phases × 13 taps), convolve the
   cached patch **symmetrically**, write the 4 sub-pixels (2×2 phases) to `g_dstLuma`.

## 4. Scale selection — 实证 (cmd 3, `sub_1801B8EA0`)

Given src dims, dst dims, and a mode, returns the scale factor (0/1/2 as a float). Thresholds:

```
srcPx = srcW·srcH
if (dstW ≤ srcW·1.18 || dstH ≤ srcH·1.18)        target < 1.18× bigger → small/no scale
else                                              ≥ 1.18× → prefer x2
clamp by source size:
  srcPx > 921600 (1280×720)                       → 0   (OFF — no super-res for ≥720p sources)
  307200 (640×480) < srcPx ≤ 921600 and mode≠3    → 0
  srcPx ≤ 307200 and mode==1 and srcPx > 57600    → x1  (57600 = 320×180)
```
Breakpoints = **180p / 480p / 720p pixel counts** + **1.18× ratio**. Decision is logged to
`zltCVppWrapper::MonitorLog_MethodStatistics`.

## 5. Performance watchdog — 实证 (`sub_1801B9200`)

```
each successful Apply:  accum_ms(+40) += GPU_ms ;  frameCount(+32)++
every 32-frame window:  if accum_ms ≥ 32 × budget(+56)  → strike(+64)++ ; accum = 0
every 320-frame cycle:  if strike ≥ threshold(+68)  → set timeout(+72), log macRaisr&timeout=1, DISABLE
every (+104) µs:        log method=Raisr&reset=1 (heartbeat)
```
Config values (IDA-verified earlier): **budget = 15 ms/frame**, **strike threshold = 2**, **reset = 60 s**
(+112 = 120 s cooldown). Window 32 frames, cycle 320 frames (10 windows).

## 6. Camera vs Screen RAISR

| | `zltCRaisr` (camera) | `zltCScreenRAISR` (screen) |
|---|---|---|
| GPU object | `CGPURaisr` | `CGPUScreenRaisr` |
| shaders | **Raisrx1/x2/x3** (multi-scale) | `ScreenRaisrx2` (single 2×) |
| hash | **22 = 11 angle × 2 strength** | 48 = 12 angle × 2 strength × 2 coherence |
| tile | 16×16→32×32, 20×20 TGSM | 16×16→32×32, 20×20 TGSM |
| weights | **embedded `.rdata`** | runtime `filterBuckets` texture |
| cbuffer | `{SrcW,H,DstW,H}` | `{SrcX,Y,W,H, DstX,Y,W,H}` (ROI/tiled) |

## 7. What the demo reuses (clean-room)

Reproducible design → `recon/zlt_raisr_camera.hpp` (`recon::zltcam`): 22-bucket hash (11 angle × 2
strength, no coherence), phases = scale², 13-tap (x2/x3) / 25-tap (x1) filters, change-detect early-out,
and the §4 source-size scale selection. Weights are OURS (trained per the raisr_train_matched pattern to
this shape, or passthrough) — Zoom's embedded coefficients are not used. Our clean-room trainer
`apps/raisr_train_camera.cpp` produces a bank in this shape (least squares, DIRECT LR-patch→HR-subpixel);
A/B vs bilinear = **+1.3 dB (synth) / +2.0 dB (camera)**. Our coefficients land in Zoom's regime
(|mean| 0.105 vs 0.149; per-filter sum 1.0 vs Zoom's 1.7 — see §8 on the two-bank difference).

## 8. The A/B two-bank question — static limit + dynamic plan

Configure builds **two filter banks per scale** (A at obj+24+16·s, B at obj+72+16·s), from separate
`.rdata` arrays. Static analysis (Path A) established:

- **实证**: exactly **4 unique RAISR shaders** (x1/x2/x3 + ScreenRaisrx2), each embedded twice
  (byte-identical copies = two GPU backends). **Each shader binds exactly ONE `filterBuckets` (t1).**
- **实证**: the 3 UAVs are **temporal, not two-pass** — `g_refLuma`(u1) = previous frame's result (read
  for the change-detect), `g_buffLuma`(u2) = current source saved as next frame's reference, `g_dstLuma`
  (u0) = output. The shader never READS u2, so there is no second pass *inside* the shader.
- **实证**: x1/x2 have **distinct** A/B arrays, but **x3 has A == B** (same pointer 0x1804CCAC0).
- The bank→t1 binding happens in the **ns_gct deferred command/descriptor layer**, not in the visible
  CPU code, so **how B participates is NOT statically recoverable**. x3's A==B rules out a simple
  two-pass-with-distinct-filters; a pure double-buffer is ruled out by x1/x2 A≠B. Both simple hypotheses
  fail → the combination is a runtime detail.

**Conclusion**: even a deep dig can't confirm the A/B combination rule, so **replicating it would be
invention** — the single least-squares bank (DC-normalized, the "merged equivalent") is the RE-faithful
choice, and it works (§7). Resolving A/B for certain needs **dynamic analysis**.

**Dynamic plan (RenderDoc)** — capture a live Zoom frame while camera RAISR is active (receive a ≤480p
remote video, §4), then inspect the compute dispatches. Tooling: `scratchpad/rd_analyze.py` (qrenderdoc
Python shell) or `renderdoccmd convert -c zip.xml` + parse. Read-off table:

| observed at the RAISR apply | verdict |
|---|---|
| **1 dispatch** per apply | A/B not a two-pass; B is a spare/double-buffer → **single bank is correct** |
| **2 dispatches**, t1 = A then B, and disp2.g_srcLuma == disp1.g_dstLuma | **two-pass (base + refine)** → replicating two banks is justified |
| 2 dispatches, not chained (parallel / temporal via g_refLuma) | A/B is temporal or another role → model per the capture |

Until a capture settles it, the demo ships the single bank (`apps/raisr_train_camera.cpp` → `recon/raisr_cam_bank.bin`).
