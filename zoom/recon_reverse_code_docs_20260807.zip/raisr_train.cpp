// raisr_train.cpp -- CLEAN-ROOM RAISR filter-bank trainer, built to Zoom's recovered bucket
// structure (from the zlt.dll shader RE) but trained on our OWN generic data.
//
// Structure/classify/apply all come from zlt_raisr.hpp (single source of truth): scale 2x, LUMA-only,
// gradient hash = coherence*24 + strength*12 + angle (12 angle x 2 strength x 2 coherence = 48 + flat),
// 4 sub-pixel phases. This trainer only LEARNS the coefficients (classic RAISR per-bucket least squares
// on our image), then hands the bank to the SAME RaisrUpscaler used by the recon library -- so the A/B
// numbers below are produced by the library itself. The coefficients are NOT Zoom's trained weights
// (that filterBuckets texture is a ⛔W boundary and not in the binary); + 8-fold dihedral augmentation.
#include "zlt_raisr.hpp"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
using std::vector;
using namespace recon::zlt;

static RaisrConfig CFG;                 // scale=2, patch=11 (recovered structure)

// ---------- image io / resample ----------
static bool loadBMPLuma(const char* path, vector<float>& Y, int& W, int& H) {
    FILE* f = fopen(path, "rb"); if (!f) return false;
    uint8_t h[54]; if (fread(h, 1, 54, f) != 54) { fclose(f); return false; }
    if (h[0] != 'B' || h[1] != 'M') { fclose(f); return false; }
    int w = *(int*)(h + 18), hh = *(int*)(h + 22); uint16_t bpp = *(uint16_t*)(h + 28);
    uint32_t off = *(uint32_t*)(h + 10);
    if (bpp != 32) { fclose(f); return false; }
    bool bottomUp = hh > 0; int ah = hh > 0 ? hh : -hh;
    fseek(f, off, SEEK_SET);
    vector<uint8_t> row((size_t)w * 4);
    Y.assign((size_t)w * ah, 0.f); W = w; H = ah;
    for (int r = 0; r < ah; r++) {
        if (fread(row.data(), 1, row.size(), f) != row.size()) { fclose(f); return false; }
        int y = bottomUp ? (ah - 1 - r) : r;
        for (int x = 0; x < w; x++)
            Y[(size_t)y * w + x] = 0.299f * row[x*4+2] + 0.587f * row[x*4+1] + 0.114f * row[x*4+0];
    }
    fclose(f); return true;
}
static void down2(const vector<float>& S, int W, int H, vector<float>& D, int& dW, int& dH) {
    dW = W / 2; dH = H / 2; D.assign((size_t)dW * dH, 0.f);
    for (int y = 0; y < dH; y++) for (int x = 0; x < dW; x++)
        D[(size_t)y*dW+x] = 0.25f*(S[(size_t)(2*y)*W+2*x]+S[(size_t)(2*y)*W+2*x+1]+S[(size_t)(2*y+1)*W+2*x]+S[(size_t)(2*y+1)*W+2*x+1]);
}
struct Base { vector<float> HR, B, LR; int W, H, lW, lH; };
static Base makeBase(const vector<float>& src, int sW, int sH) {
    Base r; r.W = sW & ~1; r.H = sH & ~1;
    r.HR.assign((size_t)r.W * r.H, 0.f);
    for (int y = 0; y < r.H; y++) for (int x = 0; x < r.W; x++) r.HR[(size_t)y*r.W+x] = src[(size_t)y*sW+x];
    down2(r.HR, r.W, r.H, r.LR, r.lW, r.lH);
    RaisrUpscaler(CFG, nullptr).UpscaleF(r.LR.data(), r.lW, r.lH, r.B, r.W, r.H);   // bilinear base (same code as apply)
    return r;
}
static void transformHR(const vector<float>& S, int W, int H, int t, vector<float>& D, int& dW, int& dH) {
    bool tr = t & 1, fx = (t>>1) & 1, fy = (t>>2) & 1;
    dW = tr ? H : W; dH = tr ? W : H; D.assign((size_t)dW*dH, 0.f);
    for (int y = 0; y < dH; y++) for (int x = 0; x < dW; x++) {
        int sx = tr ? y : x, sy = tr ? x : y;
        if (fx) sx = W-1-sx; if (fy) sy = H-1-sy;
        D[(size_t)y*dW+x] = S[(size_t)sy*W+sx];
    }
}
static void cropCols(const vector<float>& S, int W, int H, int x0, int x1, vector<float>& D, int& dW, int& dH) {
    dW = (x1-x0) & ~1; dH = H & ~1; D.assign((size_t)dW*dH, 0.f);
    for (int y = 0; y < dH; y++) for (int x = 0; x < dW; x++) D[(size_t)y*dW+x] = S[(size_t)y*W+(x0+x)];
}
static double psnr(const vector<float>& a, const vector<float>& b, int W, int H) {
    const int r = CFG.patch/2; double se = 0; long n = 0;
    for (int y = r; y < H-r; y++) for (int x = r; x < W-r; x++) { double d = a[(size_t)y*W+x]-b[(size_t)y*W+x]; se += d*d; ++n; }
    double mse = se / std::max(1L, n); return mse < 1e-9 ? 99.0 : 10.0*log10(255.0*255.0/mse);
}

// ---------- Cholesky solve (ridge added by caller) ----------
static bool solveSPD(vector<double>& A, vector<double>& b, int n) {
    for (int i = 0; i < n; i++) for (int j = 0; j <= i; j++) {
        double s = A[(size_t)i*n+j]; for (int k = 0; k < j; k++) s -= A[(size_t)i*n+k]*A[(size_t)j*n+k];
        if (i == j) { if (s <= 0) return false; A[(size_t)i*n+i] = sqrt(s); } else A[(size_t)i*n+j] = s / A[(size_t)j*n+j];
    }
    for (int i = 0; i < n; i++) { double s = b[i]; for (int k = 0; k < i; k++) s -= A[(size_t)i*n+k]*b[k]; b[i] = s/A[(size_t)i*n+i]; }
    for (int i = n-1; i >= 0; i--) { double s = b[i]; for (int k = i+1; k < n; k++) s -= A[(size_t)k*n+i]*b[k]; b[i] = s/A[(size_t)i*n+i]; }
    return true;
}

// ---------- normal-equation accumulation (uses the LIBRARY's Classify/PhaseOf) ----------
static vector<double> g_ATA, g_ATb; static vector<long> g_pop;
static void accumulate(const Base& im) {
    const int W = im.W, H = im.H, r = CFG.patch/2, TAPS = CFG.Taps(), NB = CFG.Buckets();
    vector<float> patch(TAPS);
    for (int y = r; y < H-r; y++) for (int x = r; x < W-r; x++) {
        int b = Classify(im.B.data(), W, H, x, y, CFG);
        int p = PhaseOf(x, y, CFG.scale);
        int k = 0; for (int j = -r; j <= r; j++) for (int i = -r; i <= r; i++) patch[k++] = im.B[(size_t)(y+j)*W + (x+i)];
        double t = im.HR[(size_t)y*W + x];
        size_t base = ((size_t)p*NB + b);
        double* A = &g_ATA[base*TAPS*TAPS]; double* Bv = &g_ATb[base*TAPS];
        for (int rr = 0; rr < TAPS; rr++) { double pr = patch[rr]; Bv[rr] += pr*t; double* Ar = A + (size_t)rr*TAPS; for (int c = rr; c < TAPS; c++) Ar[c] += pr*patch[c]; }
        g_pop[base]++;
    }
}

// Clean, SHARP training image: high-contrast rectangles + thin oriented lines (text-like strokes) + circles
// on a smooth gradient, NO noise. Teaches the filters to SHARPEN (recover the crisp edge a bilinear upscale
// blurs). Training on a NOISY real photo instead makes least-squares learn to SMOOTH (it can't predict noise)
// -> the bank denoises and looks softer than bilinear on text. This is the fix for exactly that.
static void makeSynthHR(vector<float>& Y, int W, int H, uint32_t seed) {
    Y.assign((size_t)W*H, 0.f);
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) Y[(size_t)y*W+x] = 55.f + 90.f*x/W + 45.f*y/H;   // smooth bg
    uint32_t s = seed*2654435761u + 12345u;
    auto rnd = [&](float a, float b) { s = s*1664525u + 1013904223u; return a + (b-a)*((s>>8)*(1.0f/16777216.0f)); };
    auto put = [&](int x, int y, float v) { if (x>=0 && x<W && y>=0 && y<H) Y[(size_t)y*W+x] = v; };
    for (int k = 0; k < 600; k++) {
        int type = (int)rnd(0, 3); float val = rnd(8, 247);
        if (type == 0) {                              // filled rectangle (block / text box)
            int rx=(int)rnd(0,W), ry=(int)rnd(0,H), rw=(int)rnd(3,55), rh=(int)rnd(3,55);
            for (int y=ry; y<ry+rh; y++) for (int x=rx; x<rx+rw; x++) put(x,y,val);
        } else if (type == 1) {                       // thin oriented line = text stroke, any angle
            float ang=rnd(0,3.14159f), len=rnd(15,110), cx=rnd(0,W), cy=rnd(0,H), th=rnd(0.6f,2.2f);
            float dx=std::cos(ang), dy=std::sin(ang);
            for (float t=-len/2; t<len/2; t+=0.5f) for (float w=-th; w<=th; w+=0.5f)
                put((int)(cx + t*dx - w*dy), (int)(cy + t*dy + w*dx), val);
        } else {                                      // filled circle -> curved edges at all orientations
            float cx=rnd(0,W), cy=rnd(0,H), rr=rnd(3,28);
            for (int y=(int)(cy-rr); y<=cy+rr; y++) for (int x=(int)(cx-rr); x<=cx+rr; x++)
                if ((x-cx)*(x-cx)+(y-cy)*(y-cy) <= rr*rr) put(x,y,val);
        }
    }
    for (auto& v : Y) v = v<0?0:(v>255?255:v);
}

int main(int argc, char** argv) {
    CFG.scale = 2; CFG.patch = 11;
    const int TAPS = CFG.Taps(), NB = CFG.Buckets(), NP = CFG.Phases();
    std::printf("\n  RAISR trainer -- library structure (2x, %d buckets x %d phases, %d taps), OUR weights, x8 aug\n", NB, NP, TAPS);

    // TRAIN on a clean SHARP synthetic (edges/strokes/shapes, no noise -> learns to SHARPEN, not smooth);
    // held-out TEST on a different-seed synth; plus a cross-domain check on the real camera frame.
    const int SW = 768, SH = 768;
    vector<float> leftHR, rightHR; int lW = SW, lH = SH, rW = SW, rH = SH;
    makeSynthHR(leftHR, SW, SH, 1); makeSynthHR(rightHR, SW, SH, 2);
    std::printf("  train: clean SHARP synthetic %dx%d (x8 aug); held-out test = synth seed 2 (+ real camera cross-domain)\n", SW, SH);

    // thresholds from the identity training crop (data-driven; the shader's exact scales weren't extracted)
    Base tr0 = makeBase(leftHR, lW, lH);
    vector<float> strg; strg.reserve(300000);
    for (int y = CFG.patch/2; y < tr0.H-CFG.patch/2; y += 2) for (int x = CFG.patch/2; x < tr0.W-CFG.patch/2; x += 2) { double s; Classify(tr0.B.data(), tr0.W, tr0.H, x, y, CFG, &s); strg.push_back((float)s); }
    std::sort(strg.begin(), strg.end());
    CFG.flat_thresh = strg[(size_t)(strg.size()*0.12)];
    CFG.str_thresh  = strg[(size_t)(strg.size()*0.55)];
    std::printf("  data-driven thresholds: flat<%.2f, strength-split=%.2f\n", CFG.flat_thresh, CFG.str_thresh);

    g_ATA.assign((size_t)NP*NB*TAPS*TAPS, 0.0); g_ATb.assign((size_t)NP*NB*TAPS, 0.0); g_pop.assign((size_t)NP*NB, 0);
    for (int t = 0; t < 8; t++) { vector<float> hr; int tW, tH; transformHR(leftHR, lW, lH, t, hr, tW, tH); accumulate(makeBase(hr, tW, tH)); }

    vector<float> bank((size_t)NP*NB*TAPS, 0.f);
    int solved = 0, fell = 0; long minpop = 1L<<30, maxpop = 0;
    vector<double> A((size_t)TAPS*TAPS), bb(TAPS);
    for (int p = 0; p < NP; p++) for (int b = 0; b < NB; b++) {
        size_t base = ((size_t)p*NB + b); float* out = &bank[base*TAPS];
        minpop = std::min(minpop, g_pop[base]); maxpop = std::max(maxpop, g_pop[base]);
        if (g_pop[base] < TAPS + 30) { out[TAPS/2] = 1.f; fell++; continue; }
        double* srcA = &g_ATA[base*TAPS*TAPS]; double* srcb = &g_ATb[base*TAPS];
        double diag = 0; for (int i = 0; i < TAPS; i++) diag += srcA[(size_t)i*TAPS+i]; diag /= TAPS;
        double lam = 1e-3 * diag + 1e-6;
        for (int rr = 0; rr < TAPS; rr++) { bb[rr] = srcb[rr]; for (int c = 0; c < TAPS; c++) A[(size_t)rr*TAPS+c] = (c>=rr?srcA[(size_t)rr*TAPS+c]:srcA[(size_t)c*TAPS+rr]); A[(size_t)rr*TAPS+rr] += lam; }
        if (solveSPD(A, bb, TAPS)) { double s = 0; for (int i = 0; i < TAPS; i++) s += bb[i]; if (s > 0.5) for (int i = 0; i < TAPS; i++) bb[i] /= s;
                                     for (int i = 0; i < TAPS; i++) out[i] = (float)bb[i]; solved++; }
        else { out[TAPS/2] = 1.f; fell++; }
    }
    std::printf("  trained %d/%d filters (%d passthrough); bucket population min=%ld max=%ld\n", solved, NP*NB, fell, minpop, maxpop);

    // save: header {NPHASE,NBUCK,TAPS,PATCH} + {flat,str} + data  (matches TrainedFilterBank::load)
    const char* bankPath = "D:/code/work/bin2cpp-output/recon/raisr_bank.bin";
    FILE* bf = fopen(bankPath, "wb");
    if (bf) { int hdr[4] = { NP, NB, TAPS, CFG.patch }; float th[2] = { CFG.flat_thresh, CFG.str_thresh };
              fwrite(hdr, sizeof(int), 4, bf); fwrite(th, sizeof(float), 2, bf); fwrite(bank.data(), sizeof(float), bank.size(), bf); fclose(bf);
              std::printf("  saved bank -> recon/raisr_bank.bin\n"); }

    // ---- A/B THROUGH THE RECON LIBRARY: load the saved bank into TrainedFilterBank + RaisrUpscaler ----
    TrainedFilterBank tfb;
    if (!tfb.load(bankPath)) { std::printf("  bank reload failed\n"); return 1; }
    RaisrConfig vcfg = CFG; tfb.fill(vcfg);        // patch + thresholds from the file
    RaisrUpscaler up(vcfg, &tfb);
    auto eval = [&](const Base& im, const char* tag) {
        vector<float> o; int ow, oh; up.UpscaleF(im.LR.data(), im.lW, im.lH, o, ow, oh);
        double pB = psnr(im.B, im.HR, im.W, im.H), pR = psnr(o, im.HR, im.W, im.H);
        std::printf("  %-22s bilinear = %.3f dB    RAISR = %.3f dB    gain = %+.3f dB\n", tag, pB, pR, pR-pB);
        return pR - pB;
    };
    Base te = makeBase(rightHR, rW, rH);
    std::printf("  ------------------------------------------------------------------------------------------------\n");
    std::printf("  A/B via recon library (RaisrUpscaler + TrainedFilterBank):\n");
    double g = eval(te,  "HELD-OUT synth:");
    eval(tr0, "(train synth:");
    { vector<float> cam; int cW, cH;   // cross-domain: real camera (noisy -> PSNR may be lower, but edges get sharpened)
      if (loadBMPLuma("D:/code/work/av-pipeline/camera_frame0.bmp", cam, cW, cH)) eval(makeBase(cam, cW, cH), "(real camera x-domain:"); }
    std::printf("  => %s on the sharp held-out set (%+.3f dB); the bank now SHARPENS edges (trained on clean sharp data).\n",
                g > 0 ? "SUCCESS" : "NO GAIN", g);
    return g > 0 ? 0 : 1;
}
