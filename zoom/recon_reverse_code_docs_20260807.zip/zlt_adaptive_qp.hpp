// zlt_adaptive_qp.hpp -- clean-room reconstruction of zlt.dll's perceptual
// adaptive-QP suite (ns_avc). Body-verified from:
//   sub_1800E7680          -- the 6-threshold "ladder" primitive (staircase classifier)
//   sub_1800E7610          -- the PER-FRAME threshold BUILDER (the key mechanism)
//   sub_1800E7A00 (vtable 0x180502738) -- TextureMotion: two per-block metrics, each with
//                             its own 6-threshold bank; per-block delta = texLevel + motLevel.
//   sub_1800E7C90          -- texture-metric aggregate + texture-ladder build
//   tables qword_1803FBDB0 (texture multipliers) / qword_1803FBDE0 (motion multipliers)
// RTTI family (adjacent vtables 0x180502718..798): zltCBackgroundAdaptQuant / zltCRoiAdaptQuant /
//   zltCTextureMotionAdaptQuant / zltCComAdaptQuant / zltCStaticAdaptQuant -> combined by
//   zltCBuQpCalc / zltCFrameQpCalc via zltCParamEstMethods into the per-CU QP offset map.
//
// HOW A BLOCK'S "TYPE" IS DECIDED (no discrete labels -- a continuous staircase):
//   1) two per-block metrics are measured: texture (spatial complexity, array @obj+104) and
//      motion (temporal, from motion estimation, array @obj+112). [metric FORMULA is computed one
//      level up in the encoder analysis pass via a virtual call -- see the boundary note below]
//   2) thresholds are PER-FRAME ADAPTIVE, not fixed constants (sub_1800E7610, EXACT):
//          thr[i] = (int)( metric_sum / block_count * mult[i] ) + 1     // i in 0..5, clamped u16
//      i.e. thr[i] = frame_mean_metric * mult[i] + 1.  The FIXED config is the 6 double
//      MULTIPLIERS (per metric, per analysis mode) -- so "busy" is measured RELATIVE to the
//      frame's own average block, not against an absolute number.
//      (This corrects the earlier "@136 / @120" note: +136/+120 are where the 6 built thresholds
//       are STORED on the object; the metric arrays live at +104/+112.)
//   3) staircase (sub_1800E7680, EXACT): level = -3 + count(metric >= thr[i]) in [-3,+3].
//      low metric (flat/static) -> few passed -> -3 (finer QP); high (busy/high-motion) ->
//      most passed -> +3 (coarser QP, error perceptually masked).
//   4) per-block QP offset = textureLevel + motionLevel, gated by the analysis mode
//      (texture-only / motion-only / both). ROI/face/text FINER-QP bias is a SEPARATE strategy
//      (zltCRoiAdaptQuant, fed by an ROI map) combined downstream in zltCBuQpCalc -- not here.
//
// BOUNDARY [推断]: the innermost per-block metric arithmetic (is "texture" a variance? a gradient
// sum? SATD?  is "motion" a MV magnitude? a SAD?) is produced by the encoder's analysis pass
// (a virtual call obj+32 -> slot+8 texture-aggregate / slot+16 motion, feeding arrays obj+104/+112),
// one level above what was decompiled. BlockVariance/BlockMotionSAD below are a PLAUSIBLE stand-in
// (spatial variance / mean abs ref-frame diff) so the demo runs end to end; the *classification*
// around them (frame-adaptive ladder + staircase + combine) is [实证/逐位].
//
// (b)-investigation findings (2025-07, sibling strategies):
//  * The whole family SHARES this staircase primitive; strategies differ only in which metric(s)
//    feed it. Confirmed: a TEXTURE-ONLY variant sub_1800E78C0 is byte-identical to sub_1800E7A00
//    minus the motion axis (same 6-threshold bank @obj+136). Strategies are dispatched via a packed
//    32-bit-RVA table @0x180527960 (not the thin RTTI vtables).
//  * Static/Background use a DIFFERENT, neighbourhood-based classifier (sub_1800E8C90): a spatial
//    scan with an activity threshold = clamp( 2.5 * frame_param[obj+396], 11468, 16384 ) rather than
//    the simple per-block staircase -- i.e. static/flat regions are found by local spatial analysis.
//    [structure-level; full body not reduced to bit-exact here]
//  * Roi (sub_1800EBD70 ctor, 0x80B) is ROI-MAP driven: it stores external pointers (obj+16/+24) =
//    the ROI/face/text mask, and biases those blocks finer. The mask SOURCE (face/text detection)
//    is the ⛔W/detection boundary -- feed our own ROI map. Roi/Static/Background offset maps are
//    all summed downstream in zltCBuQpCalc/zltCFrameQpCalc.
// Net: the TextureMotion axis is bit-exact; the remaining residual is (1) the two metric formulas
// (encoder-analysis virtual call, ⛔K-adjacent) and (2) Static/Background's neighbourhood-scan body.
#pragma once
#include <cstdint>
#include <array>
#include <vector>
#include <cstddef>

namespace recon::zlt {

// The 6-threshold ladder (EXACT reconstruction of sub_1800E7680). Maps a block metric to a QP
// offset level in [-3,+3] against ascending thr[0..5]:  level = -3 + count(val >= thr[i]).
struct QpLadder {
    std::array<int, 6> thr{{0,0,0,0,0,0}};

    int level(int val) const {
        int lvl = (val >= thr[0]) - 3 + 1;           // -2 or -1
        if (val < thr[1]) lvl = (val >= thr[0]) - 3; // -3 or -2  (overrides low end)
        if (val >= thr[2]) ++lvl;
        if (val >= thr[3]) ++lvl;
        if (val >= thr[4]) ++lvl;
        if (val >= thr[5]) ++lvl;
        return lvl;                                  // == -3 + count(val >= thr[i])
    }
};

// PER-FRAME threshold builder -- EXACT reconstruction of sub_1800E7610:
//   thr[i] = clamp_u16( (int)( metric_sum / block_count * mult[i] ) + 1 )
// so the ladder adapts to the frame: thr[i] = frame_mean_metric * mult[i] + 1.
inline QpLadder BuildLadder(double metric_sum, int block_count, const std::array<double, 6>& mult) {
    QpLadder L;
    if (block_count <= 0) { L.thr = {{0,0,0,0,0,0}}; return L; }
    for (int i = 0; i < 6; ++i) {
        int t = (int)(metric_sum * mult[i] / (double)block_count) + 1;   // frame_mean * mult[i] + 1
        L.thr[i] = (unsigned)t <= 0xFFFFu ? t : 0xFFFF;                  // clamp to u16 (overflow -> 0xFFFF)
    }
    return L;
}

// Per-block metric STAND-INS [推断] (actual metric is the encoder-analysis virtual call).
inline int BlockVariance(const uint8_t* y, int stride, int bx, int by, int bs, int w, int h) {
    long sum = 0, sum2 = 0; int n = 0;
    for (int j = 0; j < bs && (by + j) < h; ++j)
        for (int i = 0; i < bs && (bx + i) < w; ++i) {
            int p = y[(size_t)(by + j) * stride + (bx + i)];
            sum += p; sum2 += (long)p * p; ++n;
        }
    if (!n) return 0;
    long mean = sum / n;
    return int((sum2 / n) - mean * mean);            // spatial variance
}
inline int BlockMotionSAD(const uint8_t* y, const uint8_t* ref, int stride,
                          int bx, int by, int bs, int w, int h) {
    if (!ref) return 0;
    long sad = 0; int n = 0;
    for (int j = 0; j < bs && (by + j) < h; ++j)
        for (int i = 0; i < bs && (bx + i) < w; ++i) {
            size_t o = (size_t)(by + j) * stride + (bx + i);
            int d = int(y[o]) - int(ref[o]); sad += (d < 0 ? -d : d); ++n;
        }
    return n ? int(sad / n) : 0;                     // mean abs ref-frame diff
}

// Which axes contribute to the per-block offset (mirrors sub_1800E7A00's mode gate a1+72).
enum class AqMode { TextureOnly = 1, Both = 0, MotionOnly = 2, Static = 3 };

// zltCTextureMotionAdaptQuant. Two-pass, matching Zoom's flow exactly:
//   pass 1: measure per-block metrics, accumulate frame sums;
//   build:  per-frame ladders = BuildLadder(frame_sum, count, multipliers);
//   pass 2: per-block delta = textureLadder.level(tex) + motionLadder.level(mot)  (mode-gated).
struct TextureMotionAdaptQuant {
    std::array<double, 6> texture_mult{{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}};  // FIXED config (Zoom's table)
    std::array<double, 6> motion_mult {{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}};  // multipliers on frame mean
    int    block_size = 16;
    AqMode mode = AqMode::Both;

    float Compute(const uint8_t* y, const uint8_t* ref, int stride, int w, int h,
                  std::vector<int>& qp_delta) const {
        int bw = (w + block_size - 1) / block_size;
        int bh = (h + block_size - 1) / block_size;
        size_t nb = (size_t)bw * bh;
        qp_delta.assign(nb, 0);
        if (!nb) return 0.f;

        // pass 1: per-block metrics + frame aggregates
        std::vector<int> tex(nb), mot(nb);
        double tex_sum = 0, mot_sum = 0;
        for (int by = 0, b = 0; by < h; by += block_size)
            for (int bx = 0; bx < w; bx += block_size, ++b) {
                int v = BlockVariance(y, stride, bx, by, block_size, w, h);
                int s = BlockMotionSAD(y, ref, stride, bx, by, block_size, w, h);
                tex[b] = v; mot[b] = s; tex_sum += v; mot_sum += s;
            }
        // build per-frame adaptive ladders from the fixed multipliers
        QpLadder texL = BuildLadder(tex_sum, (int)nb, texture_mult);
        QpLadder motL = BuildLadder(mot_sum, (int)nb, motion_mult);

        // pass 2: staircase + mode-gated combine
        bool useTex = (mode == AqMode::TextureOnly || mode == AqMode::Both);
        bool useMot = (mode == AqMode::MotionOnly  || mode == AqMode::Both);
        long acc = 0;
        for (size_t b = 0; b < nb; ++b) {
            int d = (useTex ? texL.level(tex[b]) : 0) + (useMot ? motL.level(mot[b]) : 0);
            qp_delta[b] = d; acc += d;
        }
        return float(acc) / float(nb);
    }
};

// The other RTTI variants share this ladder primitive fed a different metric / multiplier bank
// (Roi -> finer on the ROI map; Background -> coarser; Static -> finer on unchanged blocks).
// Their per-block offset maps are summed in zltCBuQpCalc. Surfaced here as named configs.
enum class AdaptQuantKind { TextureMotion, Background, Roi, ScreenStatic, Common };

// Illustrative MULTIPLIER banks (the fixed config Zoom keeps in qword_1803FBDB0/DE0). Real values
// are the decompiled double table; these reproduce the documented -3..+3 relative behavior.
inline TextureMotionAdaptQuant MakeAdaptQuant(AdaptQuantKind k, int block_size = 16) {
    TextureMotionAdaptQuant q; q.block_size = block_size;
    switch (k) {
        case AdaptQuantKind::TextureMotion:
            q.texture_mult = {{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}};
            q.motion_mult  = {{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}};
            break;
        case AdaptQuantKind::Background:      // background: bias coarser (lower multipliers cross sooner)
            q.texture_mult = {{0.15, 0.5, 0.8, 1.2, 2.0, 3.2}};
            q.motion_mult  = {{0.15, 0.5, 0.8, 1.2, 2.0, 3.2}};
            break;
        case AdaptQuantKind::Roi:             // ROI/face: bias finer (higher multipliers cross later)
            q.texture_mult = {{0.5, 1.2, 1.8, 2.6, 4.0, 6.0}};
            q.motion_mult  = {{0.5, 1.2, 1.8, 2.6, 4.0, 6.0}};
            break;
        case AdaptQuantKind::ScreenStatic:    // screen/text: protect static/edges
            q.texture_mult = {{0.2, 0.6, 1.0, 1.6, 2.8, 4.5}};
            q.motion_mult  = {{0.1, 0.3, 0.6, 1.0, 1.8, 3.0}};
            break;
        case AdaptQuantKind::Common:
            q.texture_mult = {{0.3, 0.9, 1.3, 2.0, 3.2, 5.0}};
            q.motion_mult  = {{0.3, 0.9, 1.3, 2.0, 3.2, 5.0}};
            break;
    }
    return q;
}

} // namespace recon::zlt
