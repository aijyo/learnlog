// zbt_av1_encoder.hpp -- clean-room reconstruction of zbt.dll's AV1 ENCODER-side
// control/wrapper. Body-anchored:
//   Av1EncInterfaceCreate 0x18009C7F0 / SpecialFeature 0x18009CA80 ; the Create
//   "mode" low-nibble selects the core: (mode & 0xF) == 2 => screen-content core
//   (zbtCScEncoderCore). SpecialFeature(id) builds helper sub-objects (e.g. the OBU
//   header writer = packetizer).
//
// This is the CONTROL layer (config mapping, core selection, feature wiring, rate
// control driving) -- that part is code and is reconstructed. The AV1 CODING KERNEL
// (entropy/transform/ME) is libaom-derived: a K boundary, injected via IAv1Encoder.
// A NullAv1Encoder stub lets the control layer run + be tested without libaom.
#pragma once
#include "zbt_av1_codec.hpp"
#include <vector>
#include <cstring>

namespace recon::zbt {

// Map the encoder "mode" word (as passed to the Create export) to params.
inline void ApplyModeWord(int mode, Av1EncParams& p) {
    p.screen_content = (CoreKindOf(mode) == CoreKind::ScreenContent);   // (mode&0xF)==2
}

// Encoder control: owns a backend (real = libaom/zbt core; stub for structure),
// configures it, wires special-feature sub-objects, drives keyframe/rate control.
class Av1EncoderControl {
public:
    Av1EncoderControl(IAv1Encoder* backend) : be_(backend) {}

    int Open(const Av1EncParams& p) {
        params_ = p;
        if (!be_) return -1;
        int rc = be_->Configure(params_);
        // build the OBU packetizer sub-object (SpecialFeature) -- header writer
        Av1EncSpecialFeature(kEncFeat_Packetizer, &packetizer_);
        opened_ = (rc == 0);
        return rc;
    }
    // Encode one NV12 frame -> OBU temporal unit (via the backend kernel).
    int EncodeFrame(const uint8_t* nv12, size_t n, std::vector<uint8_t>& obu) {
        if (!opened_ || !be_) return -1;
        obu.resize((size_t)params_.width * params_.height);  // generous cap
        size_t outLen = 0;
        int rc = be_->Encode(nv12, n, obu.data(), obu.size(), outLen);
        if (rc == 0) obu.resize(outLen); else obu.clear();
        return rc;
    }
    int RequestKeyframe()      { return be_ ? be_->ForceKeyframe() : -1; }
    int SetBitrate(int bps)    { params_.bitrate = bps; return be_ ? be_->SetBitrate(bps) : -1; }
    bool screen_content() const { return params_.screen_content; }

private:
    IAv1Encoder* be_;
    Av1EncParams params_{};
    void*        packetizer_ = nullptr;   // zbtCObuHdrWriter (created via SpecialFeature)
    bool         opened_ = false;
};

// Structure stub of the coding kernel (records calls); real impl wraps libaom.
struct NullAv1Encoder : IAv1Encoder {
    Av1EncParams cfg{}; int keyframes = 0, bitrate = 0; bool configured = false;
    int Configure(const Av1EncParams& p) override { cfg = p; configured = true; return 0; }
    int Encode(const uint8_t*, size_t, uint8_t* obu, size_t cap, size_t& outLen) override {
        // emit a valid empty temporal-unit (TEMPORAL_DELIMITER OBU) as a placeholder
        if (cap < 2) { outLen = 0; return -1; }
        obu[0] = 0x12; obu[1] = 0x00; outLen = 2; return 0;   // real kernel = boundary (K)
    }
    int ForceKeyframe() override { ++keyframes; return 0; }
    int SetBitrate(int bps) override { bitrate = bps; return 0; }
};

// Minimal stubs for the reconstructed export ABI so the control layer links in the
// structural demo (a real build wires these to the zbt cores / libaom).
inline uint32_t Av1EncSpecialFeature(uint32_t, void*) { return 0; }

} // namespace recon::zbt
