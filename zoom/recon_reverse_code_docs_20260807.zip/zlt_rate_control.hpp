// zlt_rate_control.hpp -- clean-room reconstruction of the reconstructable parts of
// zlt's per-layer rate / temporal-structure logic (from sub_180062730, the config->
// encoder-core setup; a 16 KB float-heavy function). Two pieces are cleanly body-
// verified and reconstructed here; the rest of that function (full per-spatial-layer
// bitrate split + QP derivation) is only partially readable and is left as [partial].
//
// [body] Dyadic temporal frame-rate split (sub_180062730 lines ~402-419): the temporal
//        frame-rate array is filled TOP-down, each lower layer = HALF the one above:
//            fr[N-1] = R ; fr[N-2] = R/2 ; fr[N-3] = R/4 ; ... (v70 = v66*0.5 cascade)
//        i.e. a standard dyadic temporal hierarchy (T0 lowest fps, top = full fps).
// [body] Bitrate factor: dBitrateFactor = rawFixedPoint * 2^-10 (0.0009765625) -- a
//        Q10 fixed-point scalar applied to the target bitrate.
#pragma once
#include <vector>
#include <cstdint>
#include <cmath>
#include <utility>

namespace recon::zlt {

// zltCVideoRateCtrl (ns_avc, vtable 0x180502F20; base zltCRateCtrlBase, disable-variant zltCDisableRateCtrl)
// -- the zlt-side PER-FRAME rate controller. It is NOT purely codec-internal: zlt runs its own complexity-
// adaptive QP + leaky-bucket VBV on top of libx264/libaom, then hands the base QP down. Body-verified:
//   Init    sub_1801187B0  -- bitrate factor = target * 1024 (Q10, L352); loads qp_min/qp_max, buffer state.
//   Update  sub_1801193B0  -- per-frame: complexity-adaptive QP scale + VBV bucket + [qmin,qmax] clamp.
// [实证 formulas]:
//   * per-unit QP scale = clamp(pow(complexity / refComplexity, 0.3), 0.2, 5.0), stored Q10 (x1024).
//     The 0.3 exponent is the characteristic constant (libx264 qcompress default 0.6 -> Zoom's 0.3 gives a
//     FLATTER QP-vs-complexity curve = closer to constant quality). Clamps 0.2 / 5.0 are exact.
//   * frame QP = complexity-weighted aggregate of the per-unit scales; DEFAULT 28 when no complexity data.
//   * QP clamped to [qp_min(+82), qp_max(+83)] (matches the zlt H.264 [20,40] range).
//   * VBV leaky-bucket per frame: bucket += 1024000000 / bitrate  (a fixed-point time-fill; L951-952).
// The exact per-unit weighting (obfuscated field pairs) is approximated below; the pow/clamps/default/VBV
// are bit-faithful. Base QP -> the codec; the PERCEPTUAL per-block offset is TextureMotion (zlt_adaptive_qp).
struct VideoRateCtrl {
    static constexpr double kQpCompressExp = 0.3;   // [实证] pow exponent (vs libx264 0.6)
    static constexpr double kScaleMin = 0.2, kScaleMax = 5.0;
    static constexpr int    kDefaultQp = 28;         // [实证] no-complexity fallback

    // per-unit QP scale in Q10 (x1024): clamp(pow(C/Cref, 0.3), 0.2, 5.0)
    static int QpScaleQ10(double complexity, double ref) {
        double s = (ref > 0.0) ? std::pow(complexity / ref, kQpCompressExp) : 1.0;
        if (s < kScaleMin) s = kScaleMin; else if (s > kScaleMax) s = kScaleMax;
        return (int)(s * 1024.0);
    }
    // frame QP = complexity-weighted average of the per-unit scales (Q10), mapped back, default 28, clamped.
    // units = (complexity, weight); refComplexity = the RC's running reference (obj+280).
    static int FrameQp(const std::vector<std::pair<double,int>>& units, double refComplexity,
                       int qp_min, int qp_max) {
        long num = 0, den = 0;
        for (auto& u : units) { num += (long)QpScaleQ10(u.first, refComplexity) * u.second; den += u.second; }
        int qp = den ? (int)(((num + den / 2) / den) * kDefaultQp / 1024) : kDefaultQp;  // scale·default, Q10->QP
        if (qp < qp_min) qp = qp_min; else if (qp > qp_max) qp = qp_max;
        return qp;
    }
    // VBV leaky-bucket fill per frame (obj+624 double), fixed-point time units.
    static double VbvBucketFill(int bitrate_bps) { return bitrate_bps > 0 ? 1024000000.0 / bitrate_bps : 0.0; }
};

struct RateControl {
    // dBitrateFactor is stored as Q10 fixed point in the config; value = raw / 1024.
    static constexpr int   kBitrateFactorShift = 10;
    static constexpr float kBitrateFactorScale = 1.0f / 1024.0f;   // 0.0009765625

    static float BitrateFactorFromRaw(int32_t raw) { return raw * kBitrateFactorScale; }
    static int   ScaleBitrate(int bitrate, float factor) { return int(bitrate * factor + 0.5f); }

    // Dyadic temporal frame-rate assignment for `n` temporal layers at top rate `top`.
    // Returns fr[0..n-1] with fr[n-1]=top and each lower layer half the next.
    static std::vector<float> TemporalFrameRates(float top, int n) {
        if (n < 1) n = 1;
        std::vector<float> fr(n);
        float r = top;
        for (int i = n - 1; i >= 0; --i) { fr[i] = r; r *= 0.5f; }   // v70 = v66*0.5 cascade
        return fr;
    }

    // Validation the code performs: the top temporal layer's rate must equal the
    // spatial layer's configured frame rate (sub_180062730 line ~458).
    static bool TopRateMatches(const std::vector<float>& fr, float layer_frame_rate) {
        return !fr.empty() && fr.back() == layer_frame_rate;
    }
};

} // namespace recon::zlt
