#pragma once
// zlt_chroma.hpp -- CLEAN-ROOM reconstruction of Zoom's zltGPUChromaUpsample / CChromaUpsample
// (compute shader sh_804dec70, 754 instr, ⛔S -> RE algorithm + our own code). It is a LUMA-GUIDED chroma
// upsampler implemented as a GUIDED FILTER (He, Sun, Tang 2010), exactly recovered from the DXBC:
//
//   * guide  I = Y (downsampled 2x2-average to chroma resolution for the statistics; full-res for output),
//   * input  p = U (and V), both in [0,255],
//   * window = 3x3  (N = 9),
//   * a = (9*Sum(Y*U) - Sum(Y)*Sum(U)) / (9*Sum(Y*Y) - Sum(Y)^2 + EPS),   EPS = 105.3405  (N^2-scaled reg),
//   * b = (Sum(U) - a*Sum(Y)) / 9,
//   * output U_hr = a * Y_hr + b   at each full-res luma pixel  (Q9 fixed point: (a512*Y + b512 + 256) >> 9),
//   * EDGE / STABILITY GATE: the shader only guides a tile when the chroma has a *saturated colour edge*
//     ( (minU<96 || maxU>160) && (maxU-minU>4) ), and per-pixel falls back to bilinear when the guide
//     variance is too low (Zoom's var thresholds 5625 / 11250) — a flat guide makes 'a' unreliable.
//
// This lives ALONGSIDE the existing JBU path (recv_superres.hpp chromaAndCombine); it is the Zoom-exact
// alternative. Same [0,255] uint domain as Zoom's ftou.
#include <vector>
#include <cstdint>
#include <cmath>

namespace recon { namespace chroma {

inline uint8_t cl8(int v) { return (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v)); }

// Luma-guided chroma upsample. Yfull: w x h. U,V: cw x ch (4:2:0, cw≈w/2, ch≈h/2). Out: w x h.
inline void GuidedUpsample(const uint8_t* Yfull, int w, int h,
                           const uint8_t* U, const uint8_t* V, int cw, int ch,
                           std::vector<uint8_t>& outU, std::vector<uint8_t>& outV) {
  outU.assign((size_t)w * h, 128); outV.assign((size_t)w * h, 128);
  if (cw < 1 || ch < 1) return;
  auto cU = [&](int x, int y) { x = x < 0 ? 0 : (x >= cw ? cw - 1 : x); y = y < 0 ? 0 : (y >= ch ? ch - 1 : y); return (int)U[(size_t)y * cw + x]; };
  auto cV = [&](int x, int y) { x = x < 0 ? 0 : (x >= cw ? cw - 1 : x); y = y < 0 ? 0 : (y >= ch ? ch - 1 : y); return (int)V[(size_t)y * cw + x]; };
  auto cY = [&](int x, int y) { x = x < 0 ? 0 : (x >= w ? w - 1 : x); y = y < 0 ? 0 : (y >= h ? h - 1 : y); return (int)Yfull[(size_t)y * w + x]; };

  // Y downsampled to chroma resolution = 2x2 box average (Zoom's g0), clamped-edge
  std::vector<int> Yc((size_t)cw * ch);
  for (int y = 0; y < ch; ++y) for (int x = 0; x < cw; ++x)
    Yc[(size_t)y * cw + x] = (cY(2*x, 2*y) + cY(2*x+1, 2*y) + cY(2*x, 2*y+1) + cY(2*x+1, 2*y+1) + 2) >> 2;
  auto ycl = [&](int x, int y) { x = x < 0 ? 0 : (x >= cw ? cw - 1 : x); y = y < 0 ? 0 : (y >= ch ? ch - 1 : y); return Yc[(size_t)y * cw + x]; };

  const double EPS = 105.3405;
  const int VAR_MIN = 5625;               // Zoom's low-variance gate (N^2*var): below this, guide unreliable

  for (int cy = 0; cy < ch; ++cy) for (int cx = 0; cx < cw; ++cx) {
    // 3x3 window stats over (Yc, U, V)
    int Sy = 0, Syy = 0, Su = 0, Syu = 0, Sv = 0, Syv = 0;
    for (int j = -1; j <= 1; ++j) for (int i = -1; i <= 1; ++i) {
      int yv = ycl(cx + i, cy + j), uv = cU(cx + i, cy + j), vv = cV(cx + i, cy + j);
      Sy += yv; Syy += yv * yv; Su += uv; Syu += yv * uv; Sv += vv; Syv += yv * vv;
    }
    const int varN2 = 9 * Syy - Sy * Sy;                 // = N^2 * var(Y)  (Zoom's r2.w)
    // guided coefficients (float; Zoom uses Q9 fixed point, reproduced below)
    double aU = (9.0 * Syu - (double)Sy * Su) / (varN2 + EPS);
    double bU = (Su - aU * Sy) / 9.0;
    double aV = (9.0 * Syv - (double)Sy * Sv) / (varN2 + EPS);
    double bV = (Sv - aV * Sy) / 9.0;
    // Q9 fixed point exactly like the shader: aq=round(a*512), bq=round(b*512), out=(aq*Y+bq+256)>>9
    int aUq = (int)std::lround(aU * 512.0), bUq = (int)std::lround(bU * 512.0);
    int aVq = (int)std::lround(aV * 512.0), bVq = (int)std::lround(bV * 512.0);
    const bool guide = (varN2 >= VAR_MIN);               // flat guide -> fall back to bilinear

    for (int dy = 0; dy < 2; ++dy) for (int dx = 0; dx < 2; ++dx) {
      int px = 2 * cx + dx, py = 2 * cy + dy;
      if (px >= w || py >= h) continue;
      int uOut, vOut;
      if (guide) {
        int Yhr = cY(px, py);
        uOut = (aUq * Yhr + bUq + 256) >> 9;
        vOut = (aVq * Yhr + bVq + 256) >> 9;
      } else {                                            // bilinear fallback (half-pixel phase)
        double fx = (px + 0.5) / 2.0 - 0.5, fy = (py + 0.5) / 2.0 - 0.5;
        int x0 = (int)std::floor(fx), y0 = (int)std::floor(fy);
        double ax = fx - x0, ay = fy - y0;
        double u = cU(x0,y0)*(1-ax)*(1-ay) + cU(x0+1,y0)*ax*(1-ay) + cU(x0,y0+1)*(1-ax)*ay + cU(x0+1,y0+1)*ax*ay;
        double v = cV(x0,y0)*(1-ax)*(1-ay) + cV(x0+1,y0)*ax*(1-ay) + cV(x0,y0+1)*(1-ax)*ay + cV(x0+1,y0+1)*ax*ay;
        uOut = (int)std::lround(u); vOut = (int)std::lround(v);
      }
      outU[(size_t)py * w + px] = cl8(uOut);
      outV[(size_t)py * w + px] = cl8(vOut);
    }
  }
}

}}  // namespace recon::chroma
