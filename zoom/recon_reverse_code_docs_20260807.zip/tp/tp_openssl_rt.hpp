// tp_openssl_rt.hpp — runtime binding to the REAL OpenSSL 3 (libssl/libcrypto).
//
// Why runtime-resolve (LoadLibrary/GetProcAddress) instead of link-time?
//   1. It is FAITHFUL to tp.dll: tp imports OpenSSL's QUIC entry as
//      `__imp_OSSL_QUIC_client_method` and Zoom loads codec/runtime DLLs dynamically
//      (viperex loads openvino_c.dll the same way). We mirror that mechanism.
//   2. It needs no dev headers or import libs — we call the real, documented, stable
//      OpenSSL 3 C ABI directly against the libssl-3-x64.dll already on disk.
//
// This file is the "third-party = real library" side of the tp slice. The Zoom-own
// reconstruction (method-id table, create_ssl_ctx flow) lives in tp_transport.hpp and
// CALLS through this binding.
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <string>
#include <vector>
#include <cstdint>

namespace recon { namespace tp { namespace ossl {

// Opaque OpenSSL handles — we only ever pass pointers around.
using SSL_CTX   = void;
using SSL       = void;
using SSL_METHOD= void;
using SSL_CIPHER= void;

// ---- OpenSSL C ABI function pointer types (real signatures, OpenSSL 3) ----
using fn_method      = const SSL_METHOD* (__cdecl*)(void);              // TLS_client_method() etc.
using fn_method0     = const SSL_METHOD* (__cdecl*)(void);
using fn_CTX_new     = SSL_CTX* (__cdecl*)(const SSL_METHOD*);
using fn_CTX_free    = void     (__cdecl*)(SSL_CTX*);
using fn_CTX_set_verify = void  (__cdecl*)(SSL_CTX*, int, void*);
using fn_CTX_ctrl    = long     (__cdecl*)(SSL_CTX*, int, long, void*);
using fn_SSL_new     = SSL*     (__cdecl*)(SSL_CTX*);
using fn_SSL_free    = void     (__cdecl*)(SSL*);
using fn_SSL_set_fd  = int      (__cdecl*)(SSL*, int);
using fn_SSL_connect = int      (__cdecl*)(SSL*);
using fn_SSL_shutdown= int      (__cdecl*)(SSL*);
using fn_SSL_get_error = int    (__cdecl*)(const SSL*, int);
using fn_SSL_ctrl    = long     (__cdecl*)(SSL*, int, long, void*);
using fn_SSL_get_cur_cipher = const SSL_CIPHER* (__cdecl*)(const SSL*);
using fn_CIPHER_get_name = const char* (__cdecl*)(const SSL_CIPHER*);
using fn_SSL_get_version = const char* (__cdecl*)(const SSL*);
using fn_SSL_read    = int      (__cdecl*)(SSL*, void*, int);
using fn_SSL_write   = int      (__cdecl*)(SSL*, const void*, int);
using fn_ERR_get     = unsigned long (__cdecl*)(void);
using fn_ERR_str_n   = void     (__cdecl*)(unsigned long, char*, size_t);
using fn_OpenSSL_ver = const char* (__cdecl*)(int);

// OpenSSL numeric ctrl constants we use (stable ABI).
enum {
  SSL_CTRL_OPTIONS               = 32,   // SSL_CTX_set_options is a macro over this
  SSL_CTRL_SET_TLSEXT_HOSTNAME   = 55,   // SNI
  TLSEXT_NAMETYPE_host_name      = 0,
  SSL_VERIFY_NONE                = 0,
  SSL_VERIFY_PEER                = 1,
  OPENSSL_VERSION                = 0
};

struct Api {
  HMODULE hcrypto = nullptr, hssl = nullptr;
  std::string dir, load_error;
  bool ok = false;

  // method constructors (subset used by the id-table)
  fn_method  TLS_method=nullptr, TLS_client_method=nullptr, TLS_server_method=nullptr;
  fn_method  TLSv1_2_method=nullptr, TLSv1_2_client_method=nullptr, TLSv1_2_server_method=nullptr;
  fn_method  DTLS_method=nullptr, DTLS_client_method=nullptr, DTLS_server_method=nullptr;
  fn_method  OSSL_QUIC_client_method=nullptr;

  fn_CTX_new     CTX_new=nullptr;      fn_CTX_free CTX_free=nullptr;
  fn_CTX_set_verify CTX_set_verify=nullptr;  fn_CTX_ctrl CTX_ctrl=nullptr;
  fn_SSL_new     SSL_new_=nullptr;     fn_SSL_free SSL_free_=nullptr;
  fn_SSL_set_fd  SSL_set_fd_=nullptr;  fn_SSL_connect SSL_connect_=nullptr;
  fn_SSL_shutdown SSL_shutdown_=nullptr; fn_SSL_get_error SSL_get_error_=nullptr;
  fn_SSL_ctrl    SSL_ctrl_=nullptr;
  fn_SSL_get_cur_cipher SSL_get_current_cipher_=nullptr;
  fn_CIPHER_get_name CIPHER_get_name_=nullptr;
  fn_SSL_get_version SSL_get_version_=nullptr;
  fn_SSL_read    SSL_read_=nullptr;    fn_SSL_write SSL_write_=nullptr;
  fn_ERR_get     ERR_get_error_=nullptr; fn_ERR_str_n ERR_error_string_n_=nullptr;
  fn_OpenSSL_ver OpenSSL_version_=nullptr;

  template<class T> bool bind(HMODULE h, const char* name, T& p) {
    p = reinterpret_cast<T>(GetProcAddress(h, name));
    if (!p) { load_error += std::string(" missing:") + name; return false; }
    return true;
  }
};

// Candidate directories that hold libssl-3-x64.dll / libcrypto-3-x64.dll / libcurl-4.dll.
inline std::vector<std::wstring> candidate_dirs() {
  std::vector<std::wstring> v;
  wchar_t buf[512];
  DWORD n = GetEnvironmentVariableW(L"TP_OSSL_DIR", buf, 512);
  if (n && n < 512) v.push_back(buf);
  v.push_back(L"C:\\Program Files\\Git\\mingw64\\bin");
  v.push_back(L"C:\\Program Files (x86)\\Git\\mingw64\\bin");
  v.push_back(L"C:\\msys64\\mingw64\\bin");
  v.push_back(L"C:\\msys64\\ucrt64\\bin");
  return v;
}

inline HMODULE load_from(const std::wstring& dir, const wchar_t* dll) {
  std::wstring full = dir + L"\\" + dll;
  // ALTERED_SEARCH_PATH so co-located deps (libcrypto, zlib, ...) resolve from `dir`.
  return LoadLibraryExW(full.c_str(), nullptr, LOAD_WITH_ALTERED_SEARCH_PATH);
}

// Resolve the whole OpenSSL surface we need. Returns a populated Api (ok=false on failure).
inline Api& api() {
  static Api a;
  static bool tried = false;
  if (tried) return a;
  tried = true;
  for (auto& dir : candidate_dirs()) {
    HMODULE hc = load_from(dir, L"libcrypto-3-x64.dll");
    HMODULE hs = load_from(dir, L"libssl-3-x64.dll");
    if (!hc || !hs) continue;
    a.hcrypto = hc; a.hssl = hs;
    a.dir.assign(dir.begin(), dir.end());
    bool good = true;
    good &= a.bind(hs, "TLS_method", a.TLS_method);
    good &= a.bind(hs, "TLS_client_method", a.TLS_client_method);
    good &= a.bind(hs, "TLS_server_method", a.TLS_server_method);
    good &= a.bind(hs, "TLSv1_2_method", a.TLSv1_2_method);
    good &= a.bind(hs, "TLSv1_2_client_method", a.TLSv1_2_client_method);
    good &= a.bind(hs, "TLSv1_2_server_method", a.TLSv1_2_server_method);
    a.bind(hs, "DTLS_method", a.DTLS_method);              // optional
    a.bind(hs, "DTLS_client_method", a.DTLS_client_method);
    a.bind(hs, "DTLS_server_method", a.DTLS_server_method);
    good &= a.bind(hs, "OSSL_QUIC_client_method", a.OSSL_QUIC_client_method);
    good &= a.bind(hs, "SSL_CTX_new", a.CTX_new);
    good &= a.bind(hs, "SSL_CTX_free", a.CTX_free);
    good &= a.bind(hs, "SSL_CTX_set_verify", a.CTX_set_verify);
    good &= a.bind(hs, "SSL_CTX_ctrl", a.CTX_ctrl);
    good &= a.bind(hs, "SSL_new", a.SSL_new_);
    good &= a.bind(hs, "SSL_free", a.SSL_free_);
    good &= a.bind(hs, "SSL_set_fd", a.SSL_set_fd_);
    good &= a.bind(hs, "SSL_connect", a.SSL_connect_);
    a.bind(hs, "SSL_shutdown", a.SSL_shutdown_);
    good &= a.bind(hs, "SSL_get_error", a.SSL_get_error_);
    good &= a.bind(hs, "SSL_ctrl", a.SSL_ctrl_);
    good &= a.bind(hs, "SSL_get_current_cipher", a.SSL_get_current_cipher_);
    good &= a.bind(hs, "SSL_CIPHER_get_name", a.CIPHER_get_name_);
    good &= a.bind(hs, "SSL_get_version", a.SSL_get_version_);
    a.bind(hs, "SSL_read", a.SSL_read_);
    a.bind(hs, "SSL_write", a.SSL_write_);
    a.bind(hc, "ERR_get_error", a.ERR_get_error_);
    a.bind(hc, "ERR_error_string_n", a.ERR_error_string_n_);
    a.bind(hc, "OpenSSL_version", a.OpenSSL_version_);
    if (good) { a.ok = true; return a; }
  }
  if (a.load_error.empty()) a.load_error = "libssl-3-x64.dll / libcrypto-3-x64.dll not found in candidate dirs";
  return a;
}

inline std::string last_error() {
  Api& a = api();
  if (!a.ok || !a.ERR_get_error_ || !a.ERR_error_string_n_) return "";
  unsigned long e = a.ERR_get_error_();
  if (!e) return "";
  char buf[256] = {0};
  a.ERR_error_string_n_(e, buf, sizeof(buf));
  return buf;
}

inline std::string version_string() {
  Api& a = api();
  if (a.ok && a.OpenSSL_version_) return a.OpenSSL_version_(OPENSSL_VERSION);
  return "";
}

}}} // namespace recon::tp::ossl
