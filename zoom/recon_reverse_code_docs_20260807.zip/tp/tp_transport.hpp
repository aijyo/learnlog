// tp_transport.hpp — clean-room reconstruction of tp.dll's Zoom-own transport control
// surface, wired to REAL OpenSSL 3 / libcurl (via tp_openssl_rt / tp_curl_rt).
//
// Body-verified anchors (tp.dll, IDA):
//   ssb::ssl_ctx_t::create_ssl_ctx        @0x18008C770  method-id table 6..21 + SSL_CTX_new
//                                                       + set_verify + set_options(0x80000850)
//   quic_client_context_init              @0x180097A00  routes to ssl init with method id 21
//   ssb::socket_base_t::append_ssl        @0x180077E80  store SSL* (ret 12 if already set)
//   ssb::socket_base_t::config_tcp_cork_and_tcp_nodelay @0x180077EB0  setsockopt(6,1,..)
//   ssb::http_client_t::open              @ ...         new async_socket -> start_connect;
//                                                       status 17 == pending
//   ssb::async_http_sockets_pk_t::speed_up_pending_connectors  min-remaining timer collapse
//   ssb::socket_ctx_t::{set_ssl_verify_mode,set_ssl_hostname_verify,set_sec_version,...}
//   ssb::proxy_ctx_t::{get_proxy_host,get_proxy_port,get_type,append,begin,are_dead}
//
// Clean-room: behavior reproduced, not verbatim code. Third-party (OpenSSL/curl) = REAL.
#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include "tp_openssl_rt.hpp"
#include "tp_url.hpp"
#include <string>
#include <vector>
#include <cstdint>
#include <algorithm>

#pragma comment(lib, "ws2_32.lib")

namespace recon { namespace tp {

// ---------------------------------------------------------------------------
// ssb::socket_ctx_t — the per-connection parameter block (setters/getters are the
// real exported API; bodies just store into fields under a recursive mutex).
// ---------------------------------------------------------------------------
struct socket_ctx_t {
  uint8_t  sec_version = 0;          // set_sec_version(uchar)
  int      ssl_verify_mode = ossl::SSL_VERIFY_NONE;  // set_ssl_verify_mode(int)
  bool     ssl_verify_method = false;// set_ssl_verify_method(bool)
  bool     ssl_hostname_verify = false;// set_ssl_hostname_verify(bool)
  bool     tcp_cork = false;         // drives config_tcp_cork_and_tcp_nodelay()
  uint32_t ttl = 0;                  // set_ttl / get_ttl
  uint8_t  media_type = 0;           // set_media_type / get_media_type
  std::string traffic_id;            // set_traffic_id / get_traffic_id
  std::string alpn;                  // get_alpn
  std::string cert_info, cert_fingerprint, cert_public_key;
  std::string host; uint16_t port = 0;

  void set_sec_version(uint8_t v){ sec_version=v; }
  void set_ssl_verify_mode(int m){ ssl_verify_mode=m; }
  void set_ssl_verify_method(bool b){ ssl_verify_method=b; }
  void set_ssl_hostname_verify(bool b){ ssl_hostname_verify=b; }
  void set_ttl(uint32_t t){ ttl=t; }  uint32_t get_ttl() const { return ttl; }
  void set_media_type(uint8_t m){ media_type=m; } uint8_t get_media_type() const { return media_type; }
  void set_traffic_id(const char* s){ traffic_id = s?s:""; }
  const std::string& get_traffic_id() const { return traffic_id; }
};

// ---------------------------------------------------------------------------
// ssb::ssl_ctx_t — method-id table + create_ssl_ctx, calling REAL OpenSSL.
// The id numbers are exactly those decoded from create_ssl_ctx's switch.
// ---------------------------------------------------------------------------
enum ssl_method_id {
  M_TLS = 6, M_TLS_CLIENT = 7, M_TLS_SERVER = 8,
  M_TLSv1 = 9, M_TLSv1_CLIENT = 10, M_TLSv1_SERVER = 11,
  M_TLSv1_1 = 12, M_TLSv1_1_CLIENT = 13, M_TLSv1_1_SERVER = 14,
  M_TLSv1_2 = 15, M_TLSv1_2_CLIENT = 16, M_TLSv1_2_SERVER = 17,
  M_DTLS = 18, M_DTLS_CLIENT = 19, M_DTLS_SERVER = 20,
  M_QUIC_CLIENT = 21               // -> OSSL_QUIC_client_method()
};

// Faithful reproduction of create_ssl_ctx's method selection. Deprecated version-locked
// methods (TLSv1 / TLSv1_1) were removed from OpenSSL 3 exports; we substitute the
// generic TLS_* method (documented) so the id space stays complete and callable.
inline const ossl::SSL_METHOD* method_for_id(int id) {
  ossl::Api& a = ossl::api();
  if (!a.ok) return nullptr;
  switch (id) {
    case M_TLS:            return a.TLS_method ? a.TLS_method() : nullptr;
    case M_TLS_CLIENT:     return a.TLS_client_method ? a.TLS_client_method() : nullptr;
    case M_TLS_SERVER:     return a.TLS_server_method ? a.TLS_server_method() : nullptr;
    case M_TLSv1: case M_TLSv1_1:            return a.TLS_method ? a.TLS_method() : nullptr;
    case M_TLSv1_CLIENT: case M_TLSv1_1_CLIENT: return a.TLS_client_method ? a.TLS_client_method() : nullptr;
    case M_TLSv1_SERVER: case M_TLSv1_1_SERVER: return a.TLS_server_method ? a.TLS_server_method() : nullptr;
    case M_TLSv1_2:        return a.TLSv1_2_method ? a.TLSv1_2_method() : nullptr;
    case M_TLSv1_2_CLIENT: return a.TLSv1_2_client_method ? a.TLSv1_2_client_method() : nullptr;
    case M_TLSv1_2_SERVER: return a.TLSv1_2_server_method ? a.TLSv1_2_server_method() : nullptr;
    case M_DTLS:           return a.DTLS_method ? a.DTLS_method() : nullptr;
    case M_DTLS_CLIENT:    return a.DTLS_client_method ? a.DTLS_client_method() : nullptr;
    case M_DTLS_SERVER:    return a.DTLS_server_method ? a.DTLS_server_method() : nullptr;
    case M_QUIC_CLIENT:    return a.OSSL_QUIC_client_method ? a.OSSL_QUIC_client_method() : nullptr;
    default:               return nullptr;
  }
}

// The SSL_OP option mask create_ssl_ctx OR-s in unconditionally (disables legacy protos).
static const long TP_SSL_OPTIONS_MASK = 0x80000850L;

struct ssl_ctx_t {
  ossl::SSL_CTX* ctx = nullptr;
  int last_status = -1;

  // create_ssl_ctx(method_id, verify_mode, extra_options) -> REAL SSL_CTX.
  // returns 0 ok, 2 bad-method, 601 SSL_CTX_new failed.
  int create_ssl_ctx(int method_id, int verify_mode, long extra_options = 0) {
    ossl::Api& a = ossl::api();
    if (!a.ok) { last_status = -1; return -1; }
    const ossl::SSL_METHOD* m = method_for_id(method_id);
    if (!m) { last_status = 2; return 2; }
    ctx = a.CTX_new(m);
    if (!ctx) { last_status = 601; return 601; }
    a.CTX_set_verify(ctx, verify_mode, nullptr);
    a.CTX_ctrl(ctx, ossl::SSL_CTRL_OPTIONS, extra_options | TP_SSL_OPTIONS_MASK, nullptr);
    last_status = 0;
    return 0;
  }
  void free() { if (ctx) { ossl::api().CTX_free(ctx); ctx = nullptr; } }
  ~ssl_ctx_t() { free(); }
};

// quic_client_context_init — decompiled body just routes to the shared ssl init with
// method id 21 (QUIC). Reconstructed: create a real SSL_CTX on OSSL_QUIC_client_method.
inline int quic_client_context_init(ssl_ctx_t& out, int verify_mode = ossl::SSL_VERIFY_NONE) {
  return out.create_ssl_ctx(M_QUIC_CLIENT, verify_mode);
}

// ---------------------------------------------------------------------------
// ssb::proxy_ctx_t — an ordered proxy list with a cursor (append/begin/are_dead):
// the connect path walks proxies in order until one works or the list is exhausted.
// ---------------------------------------------------------------------------
enum proxy_type { PROXY_NONE = 0, PROXY_HTTP = 1, PROXY_SOCKS4 = 2, PROXY_SOCKS5 = 3 };
struct proxy_entry { proxy_type type = PROXY_NONE; std::string host; uint16_t port = 0; bool dead = false; };
struct proxy_ctx_t {
  std::vector<proxy_entry> list; size_t cursor = 0;
  void append(const proxy_entry& e){ list.push_back(e); }        // proxy_ctx_t::append
  void begin(){ cursor = 0; }                                    // proxy_ctx_t::begin
  bool are_dead() const {                                        // proxy_ctx_t::are_dead
    if (list.empty()) return true;
    for (auto& p : list) if (!p.dead) return false; return true;
  }
  proxy_entry* current(){ return cursor < list.size() ? &list[cursor] : nullptr; }
  const char* get_proxy_host() { auto* p=current(); return p?p->host.c_str():nullptr; }
  uint16_t    get_proxy_port() { auto* p=current(); return p?p->port:0; }
  int         get_type()       { auto* p=current(); return p?p->type:PROXY_NONE; }
  void mark_dead_advance(){ if (auto* p=current()){ p->dead=true; } ++cursor; }
};

// ---------------------------------------------------------------------------
// Transport selection: scheme -> {plain TCP, TLS-over-TCP, QUIC-over-UDP} + method id.
// ---------------------------------------------------------------------------
enum transport_kind { TK_PLAIN_TCP = 0, TK_TLS_TCP = 1, TK_QUIC_UDP = 2 };
struct transport_choice { transport_kind kind; int ssl_method_id; const char* why; };

inline transport_choice select_transport(scheme_type s) {
  switch (s) {
    case scheme_type::https: case scheme_type::wss:
      return { TK_TLS_TCP, M_TLS_CLIENT, "TLS: SSL_CTX on TLS_client_method (id 7) over TCP" };
    case scheme_type::quic:
      return { TK_QUIC_UDP, M_QUIC_CLIENT, "QUIC: SSL_CTX on OSSL_QUIC_client_method (id 21) over UDP" };
    case scheme_type::http: case scheme_type::ws: case scheme_type::tcp:
    default:
      return { TK_PLAIN_TCP, 0, "plain TCP (no TLS)" };
  }
}

// ---------------------------------------------------------------------------
// Connector racing — ssb::async_http_sockets_pk_t::speed_up_pending_connectors.
// The decompiled body: over all PENDING connectors, find the smallest remaining timer,
// then subtract that minimum from every pending connector's {remaining, backoff} and
// re-arm — collapsing the wait so the earliest attempt fires immediately.
// ---------------------------------------------------------------------------
struct pending_connector { uint32_t remaining_ms; uint32_t backoff_ms; bool active; };

inline uint32_t speed_up_pending_connectors(std::vector<pending_connector>& v) {
  uint32_t mn = UINT32_MAX; bool any = false;
  for (auto& c : v) if (c.active) { any = true; mn = std::min(mn, c.remaining_ms); }
  if (!any) return 0;
  for (auto& c : v) if (c.active) {
    c.remaining_ms = (mn < c.remaining_ms) ? c.remaining_ms - mn : 0;
    c.backoff_ms   = (mn < c.backoff_ms)   ? c.backoff_ms   - mn : 0;
  }
  return mn;   // the amount every pending connector was advanced by
}

// ---------------------------------------------------------------------------
// ssb::socket_base_t — real WinSock socket + TLS attach.  Real third-party calls.
// ---------------------------------------------------------------------------
struct tls_result { bool ok=false; std::string version, cipher, err; };

struct socket_base_t {
  SOCKET fd = INVALID_SOCKET;
  ossl::SSL* ssl = nullptr;                 // append_ssl slot

  static bool wsa_init() {
    static bool done=false; if(!done){ WSADATA w; done = (WSAStartup(MAKEWORD(2,2), &w)==0);} return done;
  }

  // ssb::socket_base_t::append_ssl(SSL*) — store SSL* (12 if already set), else 0.
  int append_ssl(ossl::SSL* s) { if (ssl) return 12; ssl = s; return 0; }

  // ssb::socket_base_t::config_tcp_cork_and_tcp_nodelay — setsockopt(IPPROTO_TCP, TCP_NODELAY).
  // Body: value = (cork flag set) ? 0 : 1  (i.e. NODELAY on unless cork requested).
  void config_tcp_cork_and_tcp_nodelay(const socket_ctx_t& c) {
    if (fd == INVALID_SOCKET) return;
    DWORD nodelay = c.tcp_cork ? 0 : 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (const char*)&nodelay, sizeof(nodelay));
  }

  // real TCP connect with timeout (getaddrinfo + non-blocking connect + select)
  int connect_tcp(const std::string& host, uint16_t port, int timeout_ms = 8000) {
    wsa_init();
    addrinfo hints{}; hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM; hints.ai_protocol = IPPROTO_TCP;
    addrinfo* res = nullptr;
    if (getaddrinfo(host.c_str(), std::to_string(port).c_str(), &hints, &res) != 0 || !res)
      return -1;
    int rc = -2;
    for (addrinfo* ai = res; ai; ai = ai->ai_next) {
      fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
      if (fd == INVALID_SOCKET) continue;
      u_long nb = 1; ioctlsocket(fd, FIONBIO, &nb);
      int cr = ::connect(fd, ai->ai_addr, (int)ai->ai_addrlen);
      if (cr == 0) { rc = 0; }
      else if (WSAGetLastError() == WSAEWOULDBLOCK) {
        fd_set wf; FD_ZERO(&wf); FD_SET(fd, &wf);
        timeval tv{ timeout_ms/1000, (timeout_ms%1000)*1000 };
        int sr = select(0, nullptr, &wf, nullptr, &tv);
        if (sr > 0) { int err=0; int len=sizeof(err);
                      getsockopt(fd, SOL_SOCKET, SO_ERROR, (char*)&err, &len);
                      rc = err==0 ? 0 : -3; }
        else rc = -4; // timeout
      }
      nb = 0; ioctlsocket(fd, FIONBIO, &nb);   // back to blocking
      if (rc == 0) break;
      closesocket(fd); fd = INVALID_SOCKET;
    }
    freeaddrinfo(res);
    return rc;
  }

  // real OpenSSL client handshake over the connected fd (SNI = host).
  tls_result do_tls_handshake(ssl_ctx_t& sc, const std::string& host) {
    tls_result r; ossl::Api& a = ossl::api();
    if (!a.ok) { r.err = "openssl not loaded"; return r; }
    if (fd == INVALID_SOCKET || !sc.ctx) { r.err = "no socket/ctx"; return r; }
    ossl::SSL* s = a.SSL_new_(sc.ctx);
    if (!s) { r.err = "SSL_new failed: " + ossl::last_error(); return r; }
    a.SSL_set_fd_(s, (int)fd);
    // SNI: SSL_set_tlsext_host_name(s, host)  ==  SSL_ctrl(s, 55, 0, host)
    a.SSL_ctrl_(s, ossl::SSL_CTRL_SET_TLSEXT_HOSTNAME, ossl::TLSEXT_NAMETYPE_host_name, (void*)host.c_str());
    int hs = a.SSL_connect_(s);
    if (hs == 1) {
      r.ok = true;
      if (a.SSL_get_version_) r.version = a.SSL_get_version_(s);
      if (a.SSL_get_current_cipher_ && a.CIPHER_get_name_) {
        const ossl::SSL_CIPHER* cip = a.SSL_get_current_cipher_(s);
        if (cip) r.cipher = a.CIPHER_get_name_(cip);
      }
      append_ssl(s);
    } else {
      int e = a.SSL_get_error_(s, hs);
      r.err = "SSL_connect failed (SSL_get_error=" + std::to_string(e) + ") " + ossl::last_error();
      a.SSL_free_(s);
    }
    return r;
  }

  void close_() {
    ossl::Api& a = ossl::api();
    if (ssl && a.SSL_free_) { if (a.SSL_shutdown_) a.SSL_shutdown_(ssl); a.SSL_free_(ssl); ssl=nullptr; }
    if (fd != INVALID_SOCKET) { closesocket(fd); fd = INVALID_SOCKET; }
  }
  ~socket_base_t() { close_(); }
};

// ---------------------------------------------------------------------------
// ssb::http_client_t::open / connect — the entry point tying it together.
// Reconstructed status codes: 0 ok, 2 invalid, 17 pending, other = error.
// ---------------------------------------------------------------------------
struct connect_report {
  int status = -1;                 // 0 ok, 2 invalid arg, 17 pending, else error
  transport_choice choice{ TK_PLAIN_TCP, 0, "" };
  std::string host; uint16_t port = 0;
  bool tcp_connected = false;
  tls_result tls;
};

struct http_client_t {
  socket_ctx_t   ctx;
  ssl_ctx_t      ssl;
  socket_base_t  sock;

  // open(url, proxy) — parse, select transport, resolve+connect (real), TLS if needed.
  connect_report open(const std::string& spec, proxy_ctx_t* proxy = nullptr) {
    connect_report rep;
    url_t u;
    if (!u.open_url(spec)) { rep.status = 2; return rep; }
    rep.host = u.get_host(); rep.port = u.get_port();
    rep.choice = select_transport(u.get_scheme_type());
    ctx.host = u.get_host(); ctx.port = u.get_port();

    // (proxy list would be walked here; for the direct demo we connect to origin)
    std::string connect_host = u.get_host(); uint16_t connect_port = u.get_port();
    if (proxy && !proxy->are_dead()) { proxy->begin();
      if (const char* ph = proxy->get_proxy_host()) { connect_host = ph; connect_port = proxy->get_proxy_port(); }
    }

    int cr = sock.connect_tcp(connect_host, connect_port);
    if (cr != 0) { rep.status = 100 + (-cr); return rep; }   // connect error family
    rep.tcp_connected = true;
    sock.config_tcp_cork_and_tcp_nodelay(ctx);

    if (rep.choice.kind == TK_TLS_TCP) {
      int sc = ssl.create_ssl_ctx(rep.choice.ssl_method_id, ctx.ssl_verify_mode);
      if (sc != 0) { rep.status = 600; return rep; }
      rep.tls = sock.do_tls_handshake(ssl, u.get_host());
      rep.status = rep.tls.ok ? 0 : 500;
    } else if (rep.choice.kind == TK_QUIC_UDP) {
      // real QUIC ctx (id 21); full UDP handshake is out of slice scope
      int sc = quic_client_context_init(ssl, ctx.ssl_verify_mode);
      rep.status = (sc == 0) ? 0 : 600;
    } else {
      rep.status = 0;   // plain TCP established
    }
    return rep;
  }
};

}} // namespace recon::tp
