// tp_url.hpp — clean-room reconstruction of ssb::url_t / ssb::http_url_t.
//
// Body-verified anchors (tp.dll):
//   ssb::url_t::get_scheme_type  @0x180013630  ->  return *(uint*)this;  (scheme enum at offset 0)
//   ssb::url_t::{get_host,get_port,get_path,get_user,get_pass,is_valid,clear}
//   ssb::http_url_t::open_url(std::string&)  @ ...  parses spec -> {scheme,host,port,path}
//   ssb::http_url_t::{get_scheme,get_host,get_port,get_path,get_spec,set_host_port}
//
// The exact integer values of Zoom's scheme enum are not recoverable from the bodies
// (they are compared against internal constants), so we define our own stable enum and
// reproduce the BEHAVIOR (scheme->default-port, component split). Clean-room.
#pragma once
#include <string>
#include <cstdint>
#include <cctype>
#include <algorithm>

namespace recon { namespace tp {

enum class scheme_type : uint32_t {   // stored at offset 0, per get_scheme_type()
  unknown = 0, http, https, ws, wss, quic, tcp, udp, socks4, socks5
};

inline const char* scheme_name(scheme_type s) {
  switch (s) {
    case scheme_type::http: return "http";   case scheme_type::https: return "https";
    case scheme_type::ws:   return "ws";     case scheme_type::wss:   return "wss";
    case scheme_type::quic: return "quic";   case scheme_type::tcp:   return "tcp";
    case scheme_type::udp:  return "udp";     case scheme_type::socks4:return "socks4";
    case scheme_type::socks5:return "socks5"; default: return "unknown";
  }
}
inline scheme_type scheme_from(const std::string& s) {
  std::string t; t.reserve(s.size());
  for (char c : s) t += (char)std::tolower((unsigned char)c);
  if (t=="http") return scheme_type::http;   if (t=="https") return scheme_type::https;
  if (t=="ws")   return scheme_type::ws;      if (t=="wss")  return scheme_type::wss;
  if (t=="quic"||t=="http3"||t=="h3") return scheme_type::quic;
  if (t=="tcp")  return scheme_type::tcp;     if (t=="udp")  return scheme_type::udp;
  if (t=="socks4")return scheme_type::socks4; if (t=="socks5"||t=="socks")return scheme_type::socks5;
  return scheme_type::unknown;
}
inline uint16_t default_port(scheme_type s) {
  switch (s) {
    case scheme_type::http: case scheme_type::ws:  return 80;
    case scheme_type::https:case scheme_type::wss:
    case scheme_type::quic:                        return 443;
    default:                                       return 0;
  }
}

// ssb::url_t — the parsed URL. Field order chosen so scheme_type is first (offset 0),
// matching get_scheme_type()'s `return *(uint*)this`.
struct url_t {
  scheme_type scheme = scheme_type::unknown;   // offset 0
  std::string host, path = "/", user, pass;
  uint16_t    port = 0;
  bool        valid = false;

  scheme_type get_scheme_type() const { return scheme; }     // == *(uint*)this
  const std::string& get_host() const { return host; }
  const std::string& get_path() const { return path; }
  const std::string& get_user() const { return user; }
  const std::string& get_pass() const { return pass; }
  uint16_t    get_port() const { return port; }
  bool        is_valid() const { return valid; }
  void        clear() { *this = url_t{}; }

  // ssb::http_url_t::open_url — parse "scheme://[user[:pass]@]host[:port][/path]".
  bool open_url(const std::string& spec) {
    clear();
    size_t p = spec.find("://");
    if (p == std::string::npos) return false;
    scheme = scheme_from(spec.substr(0, p));
    size_t authority = p + 3;
    size_t slash = spec.find('/', authority);
    std::string hostport = spec.substr(authority, (slash==std::string::npos? spec.size():slash) - authority);
    path = (slash==std::string::npos) ? "/" : spec.substr(slash);
    // optional userinfo
    size_t at = hostport.find('@');
    if (at != std::string::npos) {
      std::string ui = hostport.substr(0, at);
      hostport = hostport.substr(at + 1);
      size_t colon = ui.find(':');
      user = ui.substr(0, colon);
      if (colon != std::string::npos) pass = ui.substr(colon + 1);
    }
    // host[:port] (IPv6 in [..] tolerated)
    if (!hostport.empty() && hostport[0] == '[') {
      size_t rb = hostport.find(']');
      host = hostport.substr(1, rb==std::string::npos? std::string::npos : rb-1);
      size_t colon = hostport.find(':', rb==std::string::npos?0:rb);
      if (colon != std::string::npos) port = (uint16_t)std::stoi(hostport.substr(colon+1));
    } else {
      size_t colon = hostport.rfind(':');
      host = hostport.substr(0, colon);
      if (colon != std::string::npos) { try { port = (uint16_t)std::stoi(hostport.substr(colon+1)); } catch(...){} }
    }
    if (!port) port = default_port(scheme);
    valid = (scheme != scheme_type::unknown) && !host.empty();
    return valid;
  }

  std::string get_spec() const {   // http_url_t::get_spec — reassemble
    std::string s = scheme_name(scheme); s += "://"; s += host;
    if (port && port != default_port(scheme)) { s += ":"; s += std::to_string(port); }
    s += path; return s;
  }
};

}} // namespace recon::tp
