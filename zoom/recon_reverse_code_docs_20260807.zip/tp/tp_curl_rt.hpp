// tp_curl_rt.hpp — runtime binding to the REAL libcurl (libcurl-4.dll).
// Same rationale as tp_openssl_rt.hpp: tp.dll links libcurl (177 curl_* symbols); we
// call the real library via LoadLibrary/GetProcAddress so no dev headers/import libs
// are needed. This is the HTTP(S) transport the reconstructed http_client_t maps to.
#pragma once
#include <windows.h>
#include <string>
#include "tp_openssl_rt.hpp"   // reuse candidate_dirs()/load_from()

namespace recon { namespace tp { namespace curl {

// CURLoption / CURLINFO numeric constants (stable libcurl ABI).
enum {
  CURLOPT_URL             = 10002,
  CURLOPT_WRITEDATA       = 10001,
  CURLOPT_WRITEFUNCTION   = 20011,
  CURLOPT_USERAGENT       = 10018,
  CURLOPT_CAINFO          = 10065,
  CURLOPT_NOPROXY         = 10177,
  CURLOPT_TIMEOUT         = 13,
  CURLOPT_CONNECTTIMEOUT  = 78,
  CURLOPT_FOLLOWLOCATION  = 52,
  CURLOPT_SSL_VERIFYPEER  = 64,
  CURLOPT_SSL_VERIFYHOST  = 81,
  CURLOPT_NOBODY          = 44,
  CURLINFO_RESPONSE_CODE  = 0x200002,   // CURLINFO_LONG | 2
  CURLINFO_SSL_VERIFYRESULT = 0x200000 + 13,
  CURLE_OK                = 0,
  CURL_GLOBAL_DEFAULT     = 3
};

using fn_global_init = int   (__cdecl*)(long);
using fn_easy_init   = void* (__cdecl*)(void);
using fn_easy_setopt = int   (__cdecl*)(void*, int, ...);   // variadic
using fn_easy_perform= int   (__cdecl*)(void*);
using fn_easy_getinfo= int   (__cdecl*)(void*, int, ...);
using fn_easy_cleanup= void  (__cdecl*)(void*);
using fn_easy_strerror=const char* (__cdecl*)(int);

struct Api {
  HMODULE h = nullptr; bool ok = false; std::string dir, load_error;
  fn_global_init global_init=nullptr; fn_easy_init easy_init=nullptr;
  fn_easy_setopt easy_setopt=nullptr; fn_easy_perform easy_perform=nullptr;
  fn_easy_getinfo easy_getinfo=nullptr; fn_easy_cleanup easy_cleanup=nullptr;
  fn_easy_strerror easy_strerror=nullptr;
};

inline Api& api() {
  static Api a; static bool tried = false;
  if (tried) return a; tried = true;
  const wchar_t* names[] = { L"libcurl-4.dll", L"libcurl-openssl-4.dll", L"libcurl.dll" };
  for (auto& dir : ossl::candidate_dirs()) {
    for (auto* nm : names) {
      HMODULE h = ossl::load_from(dir, nm);
      if (!h) continue;
      a.h = h; a.dir.assign(dir.begin(), dir.end());
      a.global_init  = (fn_global_init) GetProcAddress(h, "curl_global_init");
      a.easy_init    = (fn_easy_init)   GetProcAddress(h, "curl_easy_init");
      a.easy_setopt  = (fn_easy_setopt) GetProcAddress(h, "curl_easy_setopt");
      a.easy_perform = (fn_easy_perform)GetProcAddress(h, "curl_easy_perform");
      a.easy_getinfo = (fn_easy_getinfo)GetProcAddress(h, "curl_easy_getinfo");
      a.easy_cleanup = (fn_easy_cleanup)GetProcAddress(h, "curl_easy_cleanup");
      a.easy_strerror= (fn_easy_strerror)GetProcAddress(h, "curl_easy_strerror");
      if (a.easy_init && a.easy_setopt && a.easy_perform && a.easy_getinfo && a.easy_cleanup) {
        if (a.global_init) a.global_init(CURL_GLOBAL_DEFAULT);
        a.ok = true; return a;
      }
    }
  }
  a.load_error = "libcurl-4.dll not found / missing exports";
  return a;
}

// sink that discards the body but counts bytes
inline size_t discard_cb(char*, size_t sz, size_t nm, void* userp) {
  if (userp) *reinterpret_cast<size_t*>(userp) += sz * nm;
  return sz * nm;
}

struct GetResult { bool ran=false; int curl_code=-1; long http_status=0; size_t bytes=0; std::string err; };

// Real HTTPS GET via libcurl. Proxy is disabled (CURLOPT_NOPROXY "*") so it connects
// directly — matching the environment where direct :443 works but the HTTP proxy 403s.
inline GetResult https_get(const std::string& url, const char* ca_bundle=nullptr, long timeout_s=8) {
  GetResult r; Api& a = api();
  if (!a.ok) { r.err = a.load_error; return r; }
  void* c = a.easy_init(); if (!c) { r.err = "easy_init failed"; return r; }
  size_t bytes = 0;
  a.easy_setopt(c, CURLOPT_URL, url.c_str());
  a.easy_setopt(c, CURLOPT_NOPROXY, "*");
  a.easy_setopt(c, CURLOPT_FOLLOWLOCATION, (long)1);
  a.easy_setopt(c, CURLOPT_TIMEOUT, (long)timeout_s);
  a.easy_setopt(c, CURLOPT_CONNECTTIMEOUT, (long)timeout_s);
  a.easy_setopt(c, CURLOPT_USERAGENT, "tp-slice/1.0");
  a.easy_setopt(c, CURLOPT_WRITEFUNCTION, (void*)&discard_cb);
  a.easy_setopt(c, CURLOPT_WRITEDATA, (void*)&bytes);
  if (ca_bundle) { a.easy_setopt(c, CURLOPT_CAINFO, ca_bundle);
                   a.easy_setopt(c, CURLOPT_SSL_VERIFYPEER, (long)1);
                   a.easy_setopt(c, CURLOPT_SSL_VERIFYHOST, (long)2); }
  else           { a.easy_setopt(c, CURLOPT_SSL_VERIFYPEER, (long)0);
                   a.easy_setopt(c, CURLOPT_SSL_VERIFYHOST, (long)0); }
  r.curl_code = a.easy_perform(c);
  r.ran = true;
  if (r.curl_code == CURLE_OK) a.easy_getinfo(c, CURLINFO_RESPONSE_CODE, &r.http_status);
  else if (a.easy_strerror)    r.err = a.easy_strerror(r.curl_code);
  r.bytes = bytes;
  a.easy_cleanup(c);
  return r;
}

}}} // namespace recon::tp::curl
