// snac_codec.hpp — viper's SNAC codec USAGE: the webrtc::SnacEncoder / SnacDecoder wrappers
// that the audio engine (ACM) drives. Ties together config + control gate + neural inference
// (⛔ boundary) + the real multi-resolution RVQ + RTP payload (de)serialization.
//
// Body-verified anchors (viper.dll):
//   webrtc::SnacEncoder / SnacDecoder (RTTI + vtables)  — the codec objects
//   EnableExtraSnacEncoding/Decoding (sub_1800C3CD0)    — control-word bit 0x4 gates encode
//   SnacInferenceEncoderAVX::Run (sub_18022F390)        — input tensor -> int codes (⛔)
//   SNAC_PAYLOAD_TYPE / SNAC_SEND_FREQ / SNAC_LBTCP     — RTP payload + low-bandwidth-TCP path
#pragma once
#include "snac_config.hpp"
#include "snac_rvq.hpp"
#include "snac_inference.hpp"
#include <vector>
#include <cstdint>
#include <memory>

namespace recon { namespace snac {

struct SnacPacket {
  uint8_t  payload_type = 0;
  uint16_t n_frames = 0;                       // latent frames (T) in this packet
  std::vector<std::vector<int>> codes;         // per-quantizer code streams
};

// serialize/parse the RTP payload: [PT][n_frames LE][n_quantizers]{ [n LE]{code LE16}* }*
inline std::vector<uint8_t> serialize(const SnacPacket& p) {
  std::vector<uint8_t> b;
  b.push_back(p.payload_type);
  b.push_back(p.n_frames & 0xFF); b.push_back(p.n_frames >> 8);
  b.push_back((uint8_t)p.codes.size());
  for (const auto& s : p.codes) {
    b.push_back(s.size() & 0xFF); b.push_back((s.size() >> 8) & 0xFF);
    for (int c : s) { b.push_back(c & 0xFF); b.push_back((c >> 8) & 0xFF); }
  }
  return b;
}
inline SnacPacket parse(const std::vector<uint8_t>& b) {
  SnacPacket p; size_t i = 0;
  p.payload_type = b[i++];
  p.n_frames = (uint16_t)(b[i] | (b[i+1] << 8)); i += 2;
  int nq = b[i++]; p.codes.resize(nq);
  for (int q = 0; q < nq; ++q) {
    int n = b[i] | (b[i+1] << 8); i += 2; p.codes[q].resize(n);
    for (int k = 0; k < n; ++k) { p.codes[q][k] = (int16_t)(b[i] | (b[i+1] << 8)); i += 2; }
  }
  return p;
}

// A base sharing the control gate + config + RVQ (encoder and decoder must share the model).
class SnacCodecBase {
public:
  SnacCodecBase(const SnacConfig& c, std::shared_ptr<ISnacInference> net, uint32_t model_seed)
    : cfg_(c), net_(std::move(net)),
      rvq_(c.num_quantizers, c.input_dim, c.codebook_size, c.codebook_dim, model_seed) {}
  // EnableExtra*: SNAC only runs when the control word has bit 0x4 AND enable is set.
  void SetEnable(bool enable, uint32_t control_word) {
    state_ = (enable && (control_word & kSnacControlBit)) ? SnacState::kReady : SnacState::kDisable;
  }
  SnacState state() const { return state_; }
  const MultiResolutionRVQ& rvq() const { return rvq_; }
protected:
  SnacConfig cfg_;
  std::shared_ptr<ISnacInference> net_;
  MultiResolutionRVQ rvq_;
  SnacState state_ = SnacState::kDisable;
};

// webrtc::SnacEncoder — PCM frame -> RVQ codes -> RTP payload.
class SnacEncoder : public SnacCodecBase {
public:
  using SnacCodecBase::SnacCodecBase;
  std::vector<uint8_t> Encode(const std::vector<int16_t>& pcm) {
    if (state_ != SnacState::kReady) return {};        // gated off
    auto latent = net_->EncodeToLatent(pcm);           // ⛔ net encoder
    auto codes  = rvq_.encode(latent);                 // real multi-resolution RVQ
    return serialize({ (uint8_t)cfg_.payload_type, (uint16_t)latent.size(), codes });
  }
};

// webrtc::SnacDecoder — RTP payload -> RVQ dequant -> PCM. `depth` optionally drops fine
// codebooks (SNAC scalability under low bandwidth).
class SnacDecoder : public SnacCodecBase {
public:
  using SnacCodecBase::SnacCodecBase;
  std::vector<int16_t> Decode(const std::vector<uint8_t>& payload, int depth = -1) {
    if (state_ != SnacState::kReady || payload.empty()) return {};
    SnacPacket p = parse(payload);
    auto latent = rvq_.decode(p.codes, p.n_frames, depth);   // real RVQ dequant
    return net_->DecodeFromLatent(latent);                   // ⛔ net decoder
  }
};

}} // namespace recon::snac
