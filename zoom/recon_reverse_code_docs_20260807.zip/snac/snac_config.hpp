// snac_config.hpp — how viper configures/gates the SNAC codec.
//
// Body-verified (viper.dll):
//   sub_18006852C   reads ini "SnacConfig" / "SnacConfig_EnableExtraCodec" (ssb::ini_t::read_int32),
//                   sets a codec-capable bit (0x1000) in two capability words.
//   config keys (strings): SNAC_CODEBOOK_SIZE / SNAC_MAX_CODEBOOK_NUM / SNAC_CODES_PER_FRMS /
//                   SNAC_NUM_20MS_PER_FRM / SNAC_PAYLOAD_TYPE / SNAC_SEND_FREQ / SNAC_REPEAT_TIME.
//   control word    bit 0x4 = "extra AI/SNAC encode" (sub_1800C3CD0 EnableExtraSnacEncoding).
//
// The RVQ model dims (num_quantizers / codebook_size / codebook_dim / input_dim) are the SNAC
// model's hyperparameters; their *names* are recovered, the *values* live in the SNAC model
// resource (⛔W), not as binary constants. Values below are representative for the demo.
#pragma once
#include <cstdint>
#include <vector>

namespace recon { namespace snac {

using Vec = std::vector<float>;

struct SnacConfig {
  // --- recovered param NAMES (viper strings); demo/representative values ---
  int  codebook_size    = 4096;  // SNAC_CODEBOOK_SIZE
  int  max_codebook_num = 4;     // SNAC_MAX_CODEBOOK_NUM  (upper bound on num_quantizers)
  int  codes_per_frame  = 0;     // SNAC_CODES_PER_FRMS
  int  num_20ms_per_frm = 1;     // SNAC_NUM_20MS_PER_FRM  (packet framing)
  int  payload_type     = 0x62;  // SNAC_PAYLOAD_TYPE      (RTP dynamic PT; demo value)
  int  send_freq        = 0;     // SNAC_SEND_FREQ
  int  repeat_time      = 0;     // SNAC_REPEAT_TIME
  bool enable_extra     = false; // SnacConfig_EnableExtraCodec (ini int32)

  // --- MultiResolutionRVQ dims (names recovered from ctors; demo values) ---
  int  input_dim     = 32;  // latent channels fed to the RVQ
  int  codebook_dim  = 8;   // low-dim factorized code (DAC/SNAC style: in_proj->codebook->out_proj)
  int  num_quantizers = 3;  // multi-resolution RVQ depth (coarse..fine)
};

// control-word gate (shared with recon/viper_codec_control.hpp): bit 0x4 = extra AI/SNAC encode
constexpr uint32_t kSnacControlBit = 0x4;

// SNAC enable state machine (sub_1800C39E0: atomic 0=kDisable / 1=kReady)
enum class SnacState { kDisable = 0, kReady = 1 };

}} // namespace recon::snac
