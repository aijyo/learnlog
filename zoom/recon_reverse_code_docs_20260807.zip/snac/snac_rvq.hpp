// snac_rvq.hpp — the reconstructable heart of SNAC: the multi-resolution residual vector
// quantizer, clean-room from viper's C++ reference classes.
//
// Body-verified structure (viper.dll):
//   CosineSimCodebook  sub_1802489E0  {codebook_size, codebook_dim} + codebook table
//   VectorQuantize     sub_180248360  {input_dim, codebook_size, codebook_dim};
//                        builds in_proj(input_dim->codebook_dim), out_proj(codebook_dim->input_dim),
//                        codebook(codebook_size, codebook_dim)   [DAC/SNAC factorized VQ]
//   MultiResolutionRVQ sub_18023CFD0  ctor(num_quantizers, input_dim, codebook_size, codebook_dim)
//                        builds a vector of `num_quantizers` VectorQuantize (residual across scales)
//
// The VQ ALGORITHM (L2-normalized cosine nearest-neighbour + residual + per-scale striding) is
// public math and is reconstructed here for real. The trained codebook + projection WEIGHTS are
// ⛔W (Zoom's SNAC model) — injectable; seeded deterministically for the runnable demo.
#pragma once
#include "snac_config.hpp"
#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>

namespace recon { namespace snac {

inline float rng_next(uint32_t& r){ r^=r<<13; r^=r>>17; r^=r<<5; return (r&0xFFFFFF)/8388608.0f - 1.0f; }
inline void  l2norm(Vec& v){ float n=0; for(float x:v) n+=x*x; n=std::sqrt(n)+1e-9f; for(float& x:v) x/=n; }

// CosineSimCodebook: nearest entry by cosine similarity (== L2 on normalized vectors).
struct CosineSimCodebook {
  int size, dim;
  std::vector<Vec> code;                     // size x dim  (⛔W trained; seeded)
  CosineSimCodebook(int s, int d, uint32_t seed) : size(s), dim(d), code(s, Vec(d)) {
    uint32_t r = seed ? seed : 1u;
    for (auto& c : code) { for (float& v : c) v = rng_next(r); l2norm(c); }
  }
  int encode(const Vec& z_in, Vec& zq) const {          // returns code index; zq = chosen entry
    Vec z = z_in; l2norm(z);
    int best = 0; float bs = -1e30f;
    for (int i = 0; i < size; ++i) {
      float s = 0; for (int d = 0; d < dim; ++d) s += z[d] * code[i][d];
      if (s > bs) { bs = s; best = i; }
    }
    zq = code[best]; return best;
  }
  const Vec& lookup(int idx) const { return code[idx]; }
};

// VectorQuantize: in_proj -> codebook -> out_proj (DAC/SNAC factorized VQ).
struct VectorQuantize {
  int input_dim, codebook_size, codebook_dim;
  std::vector<Vec> in_proj, out_proj;        // [cd x in], [in x cd]  (⛔W trained; seeded)
  CosineSimCodebook codebook;
  VectorQuantize(int in, int cs, int cd, uint32_t seed)
    : input_dim(in), codebook_size(cs), codebook_dim(cd),
      in_proj(cd, Vec(in)), out_proj(in, Vec(cd)), codebook(cs, cd, seed ^ 0x9E3779B9u) {
    uint32_t r = seed ? seed : 7u;
    for (auto& row : in_proj)  for (float& v : row) v = rng_next(r) * 0.3f;
    for (auto& row : out_proj) for (float& v : row) v = rng_next(r) * 0.3f;
  }
  static Vec matvec(const std::vector<Vec>& M, const Vec& x) {
    Vec y(M.size(), 0.f);
    for (size_t i = 0; i < M.size(); ++i) { float s = 0; for (size_t j = 0; j < x.size(); ++j) s += M[i][j]*x[j]; y[i]=s; }
    return y;
  }
  int encode(const Vec& x, Vec& xq) const {  // x:input_dim -> code + xq:input_dim (quantized)
    Vec z = matvec(in_proj, x);
    Vec zq; int code = codebook.encode(z, zq);
    xq = matvec(out_proj, zq);
    return code;
  }
  Vec decode(int code) const { return matvec(out_proj, codebook.lookup(code)); }
};

// MultiResolutionRVQ: SNAC's defining piece — quantizers operating at different temporal
// resolutions (strides), residual-quantizing coarse->fine.
struct MultiResolutionRVQ {
  int num_quantizers, input_dim, codebook_size, codebook_dim;
  std::vector<int> strides;                  // per-quantizer temporal downsample (coarse..fine)
  std::vector<VectorQuantize> vq;
  MultiResolutionRVQ(int nq, int in, int cs, int cd, uint32_t seed)
    : num_quantizers(nq), input_dim(in), codebook_size(cs), codebook_dim(cd) {
    for (int i = 0; i < nq; ++i) strides.push_back(1 << (nq - 1 - i));   // e.g. [4,2,1]
    for (int i = 0; i < nq; ++i) vq.emplace_back(in, cs, cd, seed + (uint32_t)i * 0x1000u);
  }

  // encode latent [T x input_dim] -> per-quantizer code streams (residual, multi-resolution)
  std::vector<std::vector<int>> encode(std::vector<Vec> residual) const {
    std::vector<std::vector<int>> codes(num_quantizers);
    for (int q = 0; q < num_quantizers; ++q) {
      int s = strides[q];
      for (size_t t = 0; t < residual.size(); t += s) {
        Vec pooled(input_dim, 0.f); int cnt = 0;                 // average-pool by stride
        for (int k = 0; k < s && t + k < residual.size(); ++k) { for (int d = 0; d < input_dim; ++d) pooled[d] += residual[t+k][d]; ++cnt; }
        for (float& v : pooled) v /= std::max(1, cnt);
        Vec xq; codes[q].push_back(vq[q].encode(pooled, xq));
        for (int k = 0; k < s && t + k < residual.size(); ++k) for (int d = 0; d < input_dim; ++d) residual[t+k][d] -= xq[d];  // subtract quantized
      }
    }
    return codes;
  }

  // decode per-quantizer codes back to latent [T x input_dim]. `depth` limits how many
  // quantizers are used (SNAC's scalability: fewer codebooks -> coarser/cheaper reconstruction).
  std::vector<Vec> decode(const std::vector<std::vector<int>>& codes, int T, int depth = -1) const {
    if (depth < 0 || depth > num_quantizers) depth = num_quantizers;
    std::vector<Vec> latent(T, Vec(input_dim, 0.f));
    for (int q = 0; q < depth; ++q) {
      int s = strides[q]; size_t ci = 0;
      for (size_t t = 0; t < (size_t)T; t += s, ++ci) {
        if (ci >= codes[q].size()) break;
        Vec xq = vq[q].decode(codes[q][ci]);
        for (int k = 0; k < s && t + k < (size_t)T; ++k) for (int d = 0; d < input_dim; ++d) latent[t+k][d] += xq[d];
      }
    }
    return latent;
  }
};

}} // namespace recon::snac
