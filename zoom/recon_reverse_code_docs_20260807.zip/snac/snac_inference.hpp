// snac_inference.hpp — the SNAC encoder/decoder NEURAL NET boundary.
//
// In viper the audio<->latent net is SnacInferenceEncoderAVX / SnacInferenceDecoderAVX
// (sub_18022F390 etc.): build an input tensor, call the fused AVX op (SnacOpImpl), read out
// codes/samples. Model handle at ctx+8; returns error if the model isn't loaded. The conv/Snake
// stack + trained weights are a ⛔ boundary (⛔K hand-vectorized kernel + ⛔W weights) — not
// statically reconstructable. This header defines only the INTERFACE viper calls, plus a
// deterministic invertible MOCK so the usage/data-flow demo runs without the real model.
#pragma once
#include "snac_config.hpp"
#include <vector>
#include <cstdint>
#include <algorithm>

namespace recon { namespace snac {

// Matches the shape of the AVX inference calls: audio frame(s) <-> latent [T x input_dim].
struct ISnacInference {
  virtual ~ISnacInference() = default;
  virtual std::vector<Vec>      EncodeToLatent(const std::vector<int16_t>& pcm) const = 0;  // net encoder
  virtual std::vector<int16_t>  DecodeFromLatent(const std::vector<Vec>& latent) const = 0; // net decoder
};

// Deterministic invertible mock (NOT the real net): frames the PCM into latent vectors and back,
// so SnacEncoder/Decoder can be exercised end-to-end. Real deployment injects the AVX inference.
struct MockSnacNet : ISnacInference {
  int input_dim, hop;
  MockSnacNet(int in, int h) : input_dim(in), hop(h) {}
  std::vector<Vec> EncodeToLatent(const std::vector<int16_t>& pcm) const override {
    std::vector<Vec> lat;
    for (size_t t = 0; t < pcm.size(); t += hop) {
      Vec f(input_dim, 0.f);
      for (int d = 0; d < input_dim; ++d) {
        size_t i = t + (size_t)d * hop / input_dim;
        f[d] = (i < pcm.size()) ? pcm[i] / 32768.f : 0.f;
      }
      lat.push_back(std::move(f));
    }
    return lat;
  }
  std::vector<int16_t> DecodeFromLatent(const std::vector<Vec>& lat) const override {
    std::vector<int16_t> pcm;
    for (const auto& f : lat)
      for (int k = 0; k < hop; ++k) {
        int d = k * input_dim / hop;
        float v = std::max(-1.f, std::min(1.f, f[d]));
        pcm.push_back((int16_t)(v * 32767.f));
      }
    return pcm;
  }
};

}} // namespace recon::snac
