// =============================================================================
//  rs_fec.hpp -- RUNNABLE clean-room Reed-Solomon erasure FEC over GF(2^8).
//
//  This mirrors the REAL nydus.dll share-FEC mechanism recovered by decompiling
//  the FEC cluster (RTTI->vftable walk):
//    * GF(2^8) with primitive polynomial 0x11D (x^8+x^4+x^3+x^2+1) -- exactly the
//      polynomial nydus sub_180005C44 builds from the 8-char bitstring "10111000"
//      @0x1801F4F28 (reduction low-byte 0x1D).  alpha=2 is primitive for 0x11D.
//    * systematic K data + R parity shards; erasure recovery via GF(256) linear
//      solve -- the clean-room equivalent of nydus sub_180005F34's polynomial
//      arithmetic over the 256x256 multiply table.
//
//  Reed-Solomon over GF(2^8) is public/textbook mathematics; this is ORIGINAL code
//  implementing it, using the recovered field polynomial.  No proprietary source.
// =============================================================================
#pragma once
#include <cstdint>
#include <vector>
#include <utility>

namespace recon::algo {

// GF(2^8), primitive polynomial 0x11D.  Table build matches nydus sub_180005C44:
// start at 1, multiply-by-2 each step, reduce with 0x1D when the high bit is set.
struct Gf256 {
    uint8_t exp[512];
    uint8_t logt[256];
    Gf256() {
        uint8_t x = 1;
        for (int i = 0; i < 255; ++i) {
            exp[i] = x;
            logt[x] = (uint8_t)i;
            uint8_t hi = x & 0x80;
            x = (uint8_t)(x << 1);
            if (hi) x ^= 0x1D;              // == the decompiled `v7 ^= v4`, v4 == 0x1D
        }
        for (int i = 255; i < 512; ++i) exp[i] = exp[i - 255];
        logt[0] = 0;                         // unused (0 has no log)
    }
    uint8_t mul(uint8_t a, uint8_t b) const {
        return (!a || !b) ? 0 : exp[logt[a] + logt[b]];
    }
    uint8_t inv(uint8_t a) const { return exp[255 - logt[a]]; }   // a != 0
};

// Systematic RS erasure code: K data shards + R parity shards, equal length.
// Any K of the N=K+R shards reconstruct the K data shards.  Parity is a Cauchy
// matrix (every square submatrix invertible => MDS), so any <=R erasures recover.
class RsFec {
public:
    RsFec(int k, int r) : k_(k), r_(r), cauchy_(r, std::vector<uint8_t>(k, 0)) {
        // C[i][j] = 1 / (x_i XOR y_j), x_i = i (0..r-1), y_j = r+j (r..r+k-1).
        // ranges are disjoint and within GF(256) as long as k+r <= 256.
        for (int i = 0; i < r_; ++i)
            for (int j = 0; j < k_; ++j)
                cauchy_[i][j] = gf_.inv((uint8_t)(i ^ (r_ + j)));
    }
    int k() const { return k_; }
    int r() const { return r_; }
    int n() const { return k_ + r_; }

    // Produce R parity shards from K data shards (all length `len`).
    std::vector<std::vector<uint8_t>>
    Encode(const std::vector<std::vector<uint8_t>>& data) const {
        size_t len = data.empty() ? 0 : data[0].size();
        std::vector<std::vector<uint8_t>> parity(r_, std::vector<uint8_t>(len, 0));
        for (int i = 0; i < r_; ++i)
            for (int j = 0; j < k_; ++j) {
                uint8_t c = cauchy_[i][j];
                if (!c) continue;
                const auto& dj = data[j];
                auto& pi = parity[i];
                for (size_t b = 0; b < len; ++b) pi[b] ^= gf_.mul(c, dj[b]);
            }
        return parity;
    }

    // shards: N entries (0..k-1 data, k..k+r-1 parity). present[i]=false => erased.
    // Reconstructs the erased DATA shards in place. false if fewer than K present.
    bool Decode(std::vector<std::vector<uint8_t>>& shards,
                const std::vector<char>& present) const {
        std::vector<int> rows;
        size_t len = 0;
        for (int i = 0; i < n() && (int)rows.size() < k_; ++i)
            if (present[i]) { rows.push_back(i); if (!shards[i].empty()) len = shards[i].size(); }
        if ((int)rows.size() < k_) return false;

        // k x k encoding matrix for the chosen surviving rows.
        std::vector<std::vector<uint8_t>> A(k_, std::vector<uint8_t>(k_, 0));
        for (int rr = 0; rr < k_; ++rr) {
            int idx = rows[rr];
            if (idx < k_) A[rr][idx] = 1;          // data row = e_idx (systematic)
            else          A[rr] = cauchy_[idx - k_]; // parity row = Cauchy row
        }
        std::vector<std::vector<uint8_t>> Ainv;
        if (!Invert(A, Ainv)) return false;

        // D = Ainv * received  (byte-wise over each shard column).
        for (int out = 0; out < k_; ++out) {
            if (present[out]) continue;             // only rebuild the erased data
            std::vector<uint8_t> dst(len, 0);
            for (int rr = 0; rr < k_; ++rr) {
                uint8_t c = Ainv[out][rr];
                if (!c) continue;
                const auto& src = shards[rows[rr]];
                for (size_t b = 0; b < len; ++b) dst[b] ^= gf_.mul(c, src[b]);
            }
            shards[out] = std::move(dst);
        }
        return true;
    }

private:
    // Gauss-Jordan inverse over GF(256).
    bool Invert(std::vector<std::vector<uint8_t>> m,
                std::vector<std::vector<uint8_t>>& out) const {
        int n = k_;
        out.assign(n, std::vector<uint8_t>(n, 0));
        for (int i = 0; i < n; ++i) out[i][i] = 1;
        for (int col = 0; col < n; ++col) {
            int piv = -1;
            for (int row = col; row < n; ++row) if (m[row][col]) { piv = row; break; }
            if (piv < 0) return false;
            std::swap(m[piv], m[col]);
            std::swap(out[piv], out[col]);
            uint8_t iv = gf_.inv(m[col][col]);
            for (int j = 0; j < n; ++j) { m[col][j] = gf_.mul(m[col][j], iv); out[col][j] = gf_.mul(out[col][j], iv); }
            for (int row = 0; row < n; ++row) {
                if (row == col || !m[row][col]) continue;
                uint8_t f = m[row][col];
                for (int j = 0; j < n; ++j) {
                    m[row][j]   ^= gf_.mul(f, m[col][j]);
                    out[row][j] ^= gf_.mul(f, out[col][j]);
                }
            }
        }
        return true;
    }

    int k_, r_;
    Gf256 gf_;
    std::vector<std::vector<uint8_t>> cauchy_;
};

} // namespace recon::algo
