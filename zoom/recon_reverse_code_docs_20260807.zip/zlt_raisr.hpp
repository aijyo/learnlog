// zlt_raisr.hpp -- clean-room reconstruction of the RAISR super-resolution APPLY
// pipeline used by zlt.dll (ns_vpp/ns_glt/ns_gct: zltCScreenRAISR / zltCRaisr /
// gltD3D11ScreenRaisr / CGPUScreenRaisr ...) and nydus (CDrawFunc_D3d11_Raisr).
//
// RAISR (Intel, published) = "Rapid and Accurate Image Super-Resolution": cheaply
// upscale, then for each output pixel classify the local gradient into a bucket
// (angle x strength x coherence x pixel-type) and apply that bucket's PRE-LEARNED
// linear filter over a patch. The STRUCTURE (classify -> hashed filter -> blend) is
// code and is reconstructed here; the FILTER-BANK COEFFICIENTS are trained data
// (a WEIGHTS boundary) -- injected via IFilterBank, defaulting to a passthrough so
// the pipeline runs without the learned bank.
//
// ---- IDA verification (zlt.dll, idat64 headless, 2026-07-24) --------------------
// Decompiled the real classes to check what's 实证 vs assumed:
//   * ns_vpp::zltCRaisr (vftable 0x180504B58) and ns_vpp::zltCScreenRAISR
//     (0x180504A40) are THIN DISPATCHERS, not CPU math. Configure (cmd 4) news an
//     inner GPU object -- zltCScreenRAISR -> ns_gct::CGPUScreenRaisr (sub_1802B4B80),
//     zltCRaisr -> ns_gct::CGPURaisr (sub_1802B5C70) -- and Apply (cmd 0/0x70000000)
//     calls that object's vtable+24. So Zoom's RAISR runs on the GPU (ns_gct, D3D11
//     compute); the ACTUAL classify+filter+scale live in a compiled HLSL shader,
//     NOT in x86 -> patch size / bucket counts / 2x scale are a COMPILED-SHADER
//     boundary. The CPU classify below is a faithful reference of the *algorithm*,
//     not a mirror of a Zoom CPU path (there isn't one). "ScreenRaisrx2" => 2x.
//   * The zlt-level config fields are a PERFORMANCE WATCHDOG (实证, sub_1801B9200):
//       +56 = 15   -> per-frame GPU time budget = 15 ms (accumulated ms per 32-frame
//                     window compared to 32*15)
//       +68 = 2    -> self-disable strike count: over a 320-frame cycle of 32-frame
//                     windows, if >= 2 windows blow the budget, set the timeout flag
//                     and STOP running RAISR (telemetry "method=macRaisr&timeout=1")
//       +104 = 60e6 -> 60 s reset/heartbeat (telemetry "method=Raisr&reset=1")
//       +112 = 120e6-> 120 s retry cooldown
//     i.e. super-res only stays on if the machine sustains it; it protects frame rate.
//     (My first pre-IDA read mis-labeled +56/+68 as patch/scale and +104/+112 as
//     60/120 ms -- corrected here.) Modeled as RaisrWatchdog below.
//
// ---- Shader recovery (zlt.dll DXBC extract + D3DDisassemble, 2026-07-24) --------
// zlt.dll embeds 33 compiled shaders (SM5 DXBC + SM6 DXIL). The RAISR kernels (8 of
// them) are identified by binding {g_srcLuma, filterBuckets, g_dstLuma, g_refLuma,
// g_buffLuma, imageInfo}. Disassembling the SM5 (cs_5_0) scale-2 kernel confirmed the
// algorithm is EXACTLY the classify below, and pinned the previously-ASSUMED numbers:
//   * GPU COMPUTE, LUMA-ONLY (g_srcLuma->g_dstLuma); chroma is a separate ChromaUpsample
//     shader. filterBuckets = a float2D texture = the learned bank (the WEIGHTS boundary,
//     confirmed as a real GPU resource). g_buffLuma = the cheap base upscale RAISR refines.
//   * Scale variants 1x/2x/3x (entry names RaisrX1/RaisrX2/RaisrX3). The 2x kernel classifies
//     4 pixel-types (2x2 sub-pixel phases) at once (all math is .xyzw).
//   * Tile-based: 16x16 output block <- 20x20 shared-mem source tile (2px apron). A 17x17
//     min/max pre-pass runs first.
//   * Classify = structure tensor (gxx,gyy,gxy, 1/7 weighting) -> eigenvalues
//     lambda=trace/2 +/- sqrt((trace/2)^2 - det) -> coherence=(sqrtL1-sqrtL2)/(sqrtL1+sqrtL2),
//     angle via an atan2 minimax poly. IDENTICAL to Classify() below.
//   * HASH (实证): mixed radix hash = coherence*24 + strength*12 + angle, with
//     angle = round(theta * 11/pi) in [0,11] (12 bins), strength & coherence each round-clamped
//     to {0,1} (2 bins) -> 48 gradient buckets; plus an 8-bit census/LBP edge classifier that
//     routes strong edges to bucket #49, and a degenerate bucket #0 (~50 filters). This
//     CORRECTS the recon's earlier ASSUMED 24x3x3=216 -> Zoom uses a coarser ~50-bucket hash.
#pragma once
#include <cstdint>
#include <cstdio>
#include <vector>
#include <cmath>
#include <cstddef>
#include <thread>

namespace recon::zlt {

struct RaisrConfig {
    int scale        = 2;    // 1x/2x/3x variants exist (shader entry names RaisrX1/X2/X3). [实证 shader]
    int patch        = 11;   // [ASSUMED] exact tap count is symmetry-folded in the shader; tile geometry is
                             // 16x16 output block from a 20x20 shared-mem source tile (2px apron). [实证 shader]
    // Gradient hash (实证, recovered from the cs_5_0 shader ISA, raisr scale-2 kernel in zlt.dll):
    //   hash = coherence*24 + strength*12 + angle   (mixed radix), then a flat bucket.
    int angle_bins   = 12;   // [实证] angle * (11/pi=3.501409), clamped [0,11]
    int strength_bins= 2;    // [实证] round+clamp to {0,1}
    int coherence_bins = 2;  // [实证] round+clamp to {0,1}   -> 12*2*2 = 48 gradient buckets
    // strength/coherence split points + flat cutoff. The shader's exact scales weren't extracted, so a
    // trained bank supplies these (data-driven); defaults 0 make everything a gradient bucket.
    float flat_thresh = 0.f, str_thresh = 0.f;
    int Taps()        const { return patch * patch; }                                 // 121
    int GradBuckets() const { return angle_bins * strength_bins * coherence_bins; }    // 48
    int FlatBucket()  const { return GradBuckets(); }                                  // 48
    int Buckets()     const { return GradBuckets() + 1; }                              // 49 (48 grad + flat)
    int Phases()      const { return scale * scale; }                                  // 2x -> 4 sub-pixel phases
};

// Sub-pixel phase (pixel-type) of an output pixel for a given scale (2x -> 0..3).
inline int PhaseOf(int x, int y, int scale) { return (y % scale) * scale + (x % scale); }

// Structure-tensor gradient hash on a FLOAT luma image, matching the recovered shader:
// tensor -> eigenvalues -> coherence=(sqrtL1-sqrtL2)/(sqrtL1+sqrtL2), angle via atan2; then
// hash = coherence*24 + strength*12 + angle (angle=round(theta*11/pi) in [0,11], strength/coherence
// 2 bins each). Low strength -> the flat bucket. Optionally returns the raw strength.
inline int Classify(const float* img, int w, int h, int cx, int cy, const RaisrConfig& cfg,
                    double* strengthOut = nullptr) {
    const int r = cfg.patch / 2, P = 2*r + 1;
    // Gaussian patch weights depend only on (i,j), not the pixel -> precompute once per thread (was a
    // per-pixel std::exp = ~121 exp() PER OUTPUT PIXEL, the dominant CPU cost). thread_local = safe under
    // the multithreaded UpscaleF below.
    static thread_local int cachedR = -1;
    static thread_local std::vector<double> Wt;
    if (cachedR != r) {
        Wt.assign((size_t)P*P, 0.0);
        for (int j = -r; j <= r; ++j) for (int i = -r; i <= r; ++i)
            Wt[(size_t)(j+r)*P + (i+r)] = std::exp(-(i*i + j*j) / (2.0 * (r*0.5) * (r*0.5)));
        cachedR = r;
    }
    double gxx = 0, gyy = 0, gxy = 0;
    for (int j = -r; j <= r; ++j) for (int i = -r; i <= r; ++i) {
        int x = cx + i, y = cy + j; if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
        double gx = img[(size_t)y*w + x + 1] - img[(size_t)y*w + x - 1];
        double gy = img[(size_t)(y + 1)*w + x] - img[(size_t)(y - 1)*w + x];
        double wgt = Wt[(size_t)(j+r)*P + (i+r)];
        gxx += wgt*gx*gx; gyy += wgt*gy*gy; gxy += wgt*gx*gy;
    }
    double t = gxx + gyy, d = std::sqrt((gxx - gyy)*(gxx - gyy) + 4*gxy*gxy);
    double l1 = (t + d)/2, l2 = (t - d)/2;
    double sl1 = std::sqrt(l1 > 0 ? l1 : 0), sl2 = std::sqrt(l2 > 0 ? l2 : 0);
    double strength = sl1, coherence = (sl1 + sl2 > 1e-9) ? (sl1 - sl2)/(sl1 + sl2) : 0;
    if (strengthOut) *strengthOut = strength;
    if (strength < cfg.flat_thresh) return cfg.FlatBucket();
    double ang = 0.5 * std::atan2(2*gxy, gxx - gyy); if (ang < 0) ang += 3.14159265358979;
    int ab = (int)std::lround(ang * (11.0 / 3.14159265358979)); if (ab < 0) ab = 0; if (ab > 11) ab = 11;
    int sb = strength  >= cfg.str_thresh ? 1 : 0;
    int cb = coherence >= 0.5f          ? 1 : 0;
    return cb*24 + sb*12 + ab;                                    // recovered mixed-radix hash [0..47]
}

// RaisrWatchdog -- the zlt-level self-disable control that gates whether RAISR runs
// at all (实证, zltCRaisr::Apply sub_1801B9200). Zoom measures RAISR's own GPU time
// and turns it OFF if the machine can't sustain it, protecting the frame rate. Values
// are the recovered constructor defaults (sub_1801858C0 case 8).
struct RaisrWatchdog {
    double budget_ms      = 15.0;  // +56: per-frame GPU-time budget
    int    window_frames  = 32;    // averaging window (accum ms compared to 32*budget)
    int    cycle_frames   = 320;   // evaluate strikes once per cycle (= 10 windows)
    int    disable_strikes= 2;     // +68: >= this many over-budget windows per cycle -> disable
    // running state
    double accum_ms = 0; int frame = 0, bad_windows = 0; bool disabled = false;

    // Call once per attempted frame with the measured RAISR cost; returns whether RAISR
    // should keep running. Mirrors the counter logic in sub_1801B9200.
    bool tick(double last_frame_ms) {
        if (disabled) return false;
        accum_ms += last_frame_ms;
        if (++frame % window_frames == 0) {              // close a window
            if (accum_ms >= window_frames * budget_ms) ++bad_windows;
            accum_ms = 0;
        }
        if (frame >= cycle_frames) {                     // close a cycle
            if (bad_windows >= disable_strikes) disabled = true;   // give up: too slow here
            frame = 0; bad_windows = 0;
        }
        return !disabled;
    }
    void reconfigure() { accum_ms = 0; frame = 0; bad_windows = 0; disabled = false; }  // on new dims / 60s reset
};

// Learned filter bank: (phase, bucket) -> patch*patch linear filter. The COEFFICIENTS are the
// WEIGHTS boundary (Zoom's trained filterBuckets texture is not reproducible); a bank is supplied
// externally. filter() returns nullptr to fall back to passthrough (bilinear) for that cell.
struct IFilterBank {
    virtual ~IFilterBank() = default;
    virtual const float* filter(int phase, int bucket) const = 0;
    virtual int taps() const = 0;
};

// Default bank: no learned coefficients -> passthrough (bilinear) everywhere.
struct PassthroughFilterBank : IFilterBank {
    int t; explicit PassthroughFilterBank(int patch = 11) : t(patch * patch) {}
    const float* filter(int, int) const override { return nullptr; }
    int taps() const override { return t; }
};

// A bank trained by raisr_train.cpp (clean-room, OUR weights on generic data -- NOT Zoom's).
// File = header {NPHASE,NBUCK,TAPS,PATCH} (4 int) + {flat_thresh,str_thresh} (2 float) + data
// (NPHASE*NBUCK*TAPS float). fill() copies the trained patch size + thresholds into a RaisrConfig
// so Classify() uses the same split points the bank was trained with.
struct TrainedFilterBank : IFilterBank {
    int nphase = 0, nbuck = 0, ntaps = 0, patch = 0; float flat = 0, str = 0;
    std::vector<float> data;
    bool load(const char* path) {
        std::FILE* f = std::fopen(path, "rb"); if (!f) return false;
        int hdr[4]; float th[2];
        bool ok = std::fread(hdr, sizeof(int), 4, f) == 4 && std::fread(th, sizeof(float), 2, f) == 2;
        if (ok) {
            nphase = hdr[0]; nbuck = hdr[1]; ntaps = hdr[2]; patch = hdr[3]; flat = th[0]; str = th[1];
            data.assign((size_t)nphase * nbuck * ntaps, 0.f);
            ok = std::fread(data.data(), sizeof(float), data.size(), f) == data.size();
        }
        std::fclose(f); return ok;
    }
    void fill(RaisrConfig& c) const { if (patch) c.patch = patch; c.flat_thresh = flat; c.str_thresh = str; }
    // Populate from an in-memory bank (same layout as load()) — used by trainers that hold several banks.
    void fromMemory(int np, int nb, int nt, int pt, float fl, float st, const std::vector<float>& d) {
        nphase = np; nbuck = nb; ntaps = nt; patch = pt; flat = fl; str = st; data = d;
    }
    const float* filter(int phase, int bucket) const override {
        if (phase < 0 || phase >= nphase || bucket < 0 || bucket >= nbuck) return nullptr;
        return &data[((size_t)phase * nbuck + bucket) * ntaps];
    }
    int taps() const override { return ntaps; }
};

class RaisrUpscaler {
public:
    RaisrUpscaler(RaisrConfig cfg, const IFilterBank* bank) : cfg_(cfg), bank_(bank) {}

    // FLOAT path (canonical). in: w*h luma; out: (w*scale)*(h*scale). Bilinear base, then per-pixel
    // (phase,bucket) -> learned filter; flat/border/no-filter cells keep the bilinear base.
    void UpscaleF(const float* in, int w, int h, std::vector<float>& out, int& ow, int& oh) const {
        const int s = cfg_.scale; ow = w * s; oh = h * s; out.assign((size_t)ow * oh, 0.f);
        for (int oy = 0; oy < oh; ++oy) {
            float fy = (oy + 0.5f) / s - 0.5f; int y0 = (int)std::floor(fy); float wy = fy - y0;
            for (int ox = 0; ox < ow; ++ox) {
                float fx = (ox + 0.5f) / s - 0.5f; int x0 = (int)std::floor(fx); float wx = fx - x0;
                out[(size_t)oy * ow + ox] = bilerp(in, w, h, x0, y0, wx, wy);
            }
        }
        if (!bank_) return;
        const int r = cfg_.patch / 2;
        std::vector<float> base = out;   // read-only source for classify+filter
        // per-pixel classify+filter is embarrassingly parallel across rows (base is read-only, out rows are
        // disjoint). A CPU-parallel stand-in for what Zoom does massively-parallel on the GPU (the recovered
        // compute shader). NOT a substitute for GPU throughput -- just enough to keep the CPU demo live.
        auto worker = [&](int ylo, int yhi) {
            for (int oy = ylo; oy < yhi; ++oy) for (int ox = r; ox < ow - r; ++ox) {
                int bucket = Classify(base.data(), ow, oh, ox, oy, cfg_);
                const float* f = bank_->filter(PhaseOf(ox, oy, s), bucket);
                if (!f) continue;
                float acc = 0; int k = 0;
                for (int j = -r; j <= r; ++j) for (int i = -r; i <= r; ++i, ++k) acc += f[k] * base[(size_t)(oy + j) * ow + (ox + i)];
                out[(size_t)oy * ow + ox] = acc < 0 ? 0 : (acc > 255 ? 255 : acc);
            }
        };
        int lo = r, hi = oh - r, T = (int)std::thread::hardware_concurrency();
        if (T < 1) T = 1; if (T > 16) T = 16;
        if (T == 1 || hi - lo < 2 * T) { worker(lo, hi); return; }
        std::vector<std::thread> pool; int chunk = (hi - lo + T - 1) / T;
        for (int t = 0; t < T; ++t) { int a = lo + t * chunk, b = a + chunk < hi ? a + chunk : hi; if (a < b) pool.emplace_back(worker, a, b); }
        for (auto& th : pool) th.join();
    }

    // uint8_t convenience (keeps the old API): converts to/from float around UpscaleF.
    void Upscale(const uint8_t* in, int w, int h, std::vector<uint8_t>& out, int& ow, int& oh) const {
        std::vector<float> fin((size_t)w * h); for (size_t i = 0; i < fin.size(); ++i) fin[i] = in[i];
        std::vector<float> fout; UpscaleF(fin.data(), w, h, fout, ow, oh);
        out.assign(fout.size(), 0);
        for (size_t i = 0; i < fout.size(); ++i) { int v = (int)(fout[i] + 0.5f); out[i] = (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v)); }
    }

private:
    static float bilerp(const float* in, int w, int h, int x0, int y0, float wx, float wy) {
        auto at = [&](int x, int y) -> float {
            x = x < 0 ? 0 : (x >= w ? w - 1 : x); y = y < 0 ? 0 : (y >= h ? h - 1 : y);
            return in[(size_t)y * w + x];
        };
        float a = at(x0, y0) * (1 - wx) + at(x0 + 1, y0) * wx;
        float b = at(x0, y0 + 1) * (1 - wx) + at(x0 + 1, y0 + 1) * wx;
        return a * (1 - wy) + b * wy;
    }
    RaisrConfig cfg_;
    const IFilterBank* bank_;
};

} // namespace recon::zlt
