// viperex_pipeline.hpp -- clean-room reconstruction of viperex.dll's audio-chunk
// pipeline orchestration (the "Companion-Mic" ML flow), body-anchored by:
//   [AUDIO-CHUNKS] Current meeting time ...      (chunking + meeting-time accrual)
//   [CAMPP] ExtractEmbedding FAILED on 3s window (CAM++ speaker embedding, 3s input)
//   Picknet / Picknet_Smoothed                   (active-speaker detector + smoothing)
//   lipsync_model_calculator.cpp                 (lipsync)
// PipelineConstants (verified): 16 kHz mono; 1.5 s (24000-sample) working chunk;
// 3.0 s (48000-sample) CAM++ window; picknet_smoothed > 5.0 => "active speaker".
//
// The NEURAL inference (Picknet, CAM++) runs on OpenVINO with TRAINED WEIGHTS -- a
// WEIGHTS boundary. It is injected via IViperexInference; a deterministic stub lets
// the orchestration run and be tested without the models.
#pragma once
#include "viperex_runtime.hpp"
#include <cstdint>
#include <vector>
#include <deque>
#include <cmath>
#include <cstddef>

namespace recon::viperex {

// Neural back-ends (OpenVINO + weights = boundary). Inject a real impl or the stub.
struct IViperexInference {
    virtual ~IViperexInference() = default;
    // Picknet active-speaker likelihood for one 1.5 s chunk.
    virtual float Picknet(const int16_t* pcm, size_t n) = 0;
    // CAM++ speaker embedding for the 3 s window (returns an L2-normalized vector).
    virtual std::vector<float> CampEmbedding(const int16_t* window, size_t n) = 0;
};

struct PipelineResult {
    double meeting_time_s = 0.0;   // accrues 1.5 s per processed chunk
    float  picknet = 0.f;
    float  picknet_smoothed = 0.f;
    bool   active_speaker = false; // picknet_smoothed > kActiveThresh (5.0)
    bool   embedding_ready = false;
    float  enrolled_match = -1.f;  // cosine vs enrolled embedding (if enrolled)
};

class ViperexPipeline {
public:
    explicit ViperexPipeline(IViperexInference* inf, float smooth = 0.6f)
        : inf_(inf), smooth_alpha_(smooth) {}

    // Feed arbitrary PCM (16 kHz mono int16). Emits one PipelineResult per completed
    // 1.5 s chunk into `out`. Maintains the rolling 3 s CAM++ window internally.
    void Feed(const int16_t* pcm, size_t n, std::vector<PipelineResult>& out) {
        chunk_.insert(chunk_.end(), pcm, pcm + n);
        while ((int)chunk_.size() >= PipelineConstants::kChunkSamples) {
            ProcessChunk(chunk_.data());
            out.push_back(last_);
            chunk_.erase(chunk_.begin(), chunk_.begin() + PipelineConstants::kChunkSamples);
        }
    }

    // Snapshot the most recent CAM++ embedding as the enrolled reference.
    bool Enroll() { if (embedding_.empty()) return false; enrolled_ = embedding_; return true; }

private:
    void ProcessChunk(const int16_t* chunk) {
        // rolling 3 s window for CAM++
        window_.insert(window_.end(), chunk, chunk + PipelineConstants::kChunkSamples);
        while ((int)window_.size() > PipelineConstants::kCampWindow)
            window_.pop_front();

        float p = inf_ ? inf_->Picknet(chunk, PipelineConstants::kChunkSamples) : 0.f;
        // Picknet_Smoothed: EWMA
        smoothed_ = have_smoothed_ ? (smooth_alpha_ * p + (1 - smooth_alpha_) * smoothed_) : p;
        have_smoothed_ = true;

        PipelineResult r;
        meeting_time_s_ += PipelineConstants::kChunkSeconds;   // +1.5 s
        r.meeting_time_s = meeting_time_s_;
        r.picknet = p;
        r.picknet_smoothed = smoothed_;
        r.active_speaker = smoothed_ > PipelineConstants::kActiveThresh;   // > 5.0

        if ((int)window_.size() >= PipelineConstants::kCampWindow && inf_) {
            std::vector<int16_t> w(window_.begin(), window_.end());
            embedding_ = inf_->CampEmbedding(w.data(), w.size());
            r.embedding_ready = !embedding_.empty();
            if (!enrolled_.empty() && embedding_.size() == enrolled_.size())
                r.enrolled_match = Cosine(embedding_, enrolled_);
        }
        last_ = r;
    }

    static float Cosine(const std::vector<float>& a, const std::vector<float>& b) {
        double dot = 0, na = 0, nb = 0;
        for (size_t i = 0; i < a.size(); ++i) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
        return (na > 0 && nb > 0) ? float(dot / (std::sqrt(na) * std::sqrt(nb))) : 0.f;
    }

    IViperexInference* inf_;
    float smooth_alpha_;
    std::vector<int16_t> chunk_;
    std::deque<int16_t>  window_;
    std::vector<float>   embedding_, enrolled_;
    float  smoothed_ = 0.f; bool have_smoothed_ = false;
    double meeting_time_s_ = 0.0;
    PipelineResult last_;
};

} // namespace recon::viperex
