# Zoom design-value recovery (IDA re-analysis, 2026-07)

Re-ran Hex-Rays over the existing `.i64` databases (mcm.dll, zlt.dll, nydus.dll, zbt.dll,
viper.dll) specifically to recover the *actual* adaptation design values for the parameters the
demo had been flagging as "no RE basis / engineering values". Every row below is tagged:

- **实证 (table/body)** — read directly out of a `.rdata` table or a decompiled function body.
- **实证 (constant present)** — the literal exists in the image with a code xref, but the exact
  comparison site was not fully pinned.
- **config-driven** — the *mechanism* is in the binary but the *value* is supplied at runtime
  (server/web-config or per-call config struct); there is no compile-time constant to recover.
- **not recoverable** — no evidence in the available binaries; must NOT be invented.

All EAs are image-relative (preferred base 0x180000000).

---

## 1. Resolution / frame-rate ladder  — 实证 (table) — mcm.dll

Two 4-rung tables, each rung a 16-byte struct `{ u32 width, u32 height, f32 fps, u32 reserved }`.
The selector `sub_1801E1DD0(a1, {w,h})` picks the rung whose **pixel count (w*h) is nearest** to the
requested `w*h`, returning rung index+1 (1..4). It chooses table B unless flag `*(a1+29)` is set.

### Table A `0x1802BEFC0` — high-frame-rate profile (camera / high motion)
| rung | width | height | fps |
|------|-------|--------|-----|
| 0    | 320   | 180    | 30  |
| 1    | 640   | 360    | 30  |
| 2    | 1280  | 720    | **60** |
| 3    | 1920  | 1080   | **60** |

### Table B `0x1802BF000` — 30 fps-capped profile (screen / default)
| rung | width | height | fps |
|------|-------|--------|-----|
| 0    | 320   | 180    | 30  |
| 1    | 640   | 360    | 30  |
| 2    | 1280  | 720    | 30  |
| 3    | 1920  | 1080   | 30  |

- The ladder height is **1080**, not 1088 (1088 is only the encoder's 16-align; the *design*
  value is 1080).
- The two tables differ **only in fps**: 720p/1080p run 60 fps in the motion profile, 30 fps in the
  default/screen profile. This is the concrete form of §1.4 "screen = low frame rate": same
  resolution rungs, fps capped at 30 for screen. (Screen additionally throttles fps *below* 30 on
  static content — that throttle is content-adaptive, not a fixed ladder value.)
- Adjacent extended ladders exist:
  - `0x18024C448` (4:3 + 16:9): 160×120, 320×240, 640×480, 1280×720, 1920×1080.
  - `0x1802BF000+0x40`: 1920×1080, 1440×900, 1280×720, 960×540, 640×360 (5-rung, incl. 16:10).
  - zlt.dll `0x1803F8520` full 16:9: 160×90, 320×180, 480×270, 640×360, 960×540, 1280×720 (+768×432,
    1024×576 variants).

## 2. Bitrate logic — 实证 (body) — mcm.dll

Bitrate is **computed, not tabled** (there is no per-rung kbps column).

### 2a. Bitrate-from-resolution formula — `sub_1801E1970`
Normalizes pixel count to 720p and shapes it with a log-power curve:
```
ratio = (w*h) / 921600.0            # 921600 = 1280*720
bitrate ∝ pow(ratio, 0.025*log2(ratio) + 0.8)  * coeff
```
Camera branch uses a flat `sqrt(1/15) ≈ 0.258` scale of the clamped input rate instead.
Up/down switch decision carries a **hysteresis factor: ×0.9 when stepping down, ×1.1 when stepping
up** (`v10==1 ? 0.9 : 1.1`).

### 2b. Bitrate budget from network metric — `sub_18001A890`
Breakpoints on the network metric `m` (`*(a1+44)`) with Mbit targets:
| metric range        | target (a1+4)              | base (a1+8)                    |
|---------------------|----------------------------|--------------------------------|
| m ≤ 10000           | uncapped (sentinel 100Mi)  | uncapped                       |
| 10000 < m ≤ 20000   | 4.0→3.0 Mbit (linear)      | 3.0→2.5 Mbit (`3.0 - (m-10000)*0.5/10000`) |
| 20000 < m ≤ 40000   | 3.0 Mbit                   | 2.5→2.2 Mbit (`2.5 - (m-20000)*0.3/20000`) |
| m > 40000           | 3.0 Mbit                   | 2.2 Mbit (2306867)             |
Per-stream floor = **0.25 Mbit** (0x40000). Total = target + base.
(NOTE: the 2.5/3.0/4.0 here are *megabit levels*, not MOS thresholds — do not confuse.)

## 3. Spatial SVC layers — 实证 (table) — mcm.dll

### 3-layer config `0x1802BC850`
| layer | width | height | fps | factor |
|-------|-------|--------|-----|--------|
| 0     | 160   | 90     | 12  | 0.80   |
| 1     | 320   | 180    | 12  | 0.85   |
| 2     | 640   | 360    | 24  | 0.95   |

### Pairwise base→enhance tables (`0x1802BA518`, `0x1802BCxxx` cluster)
- `640×360 → 1280×720`  (½ linear scaling)  ← confirms the demo's ½ spatial SVC
- `1280×720 → 2560×1440` (½ linear scaling)
- multi: `160×90 / 320×180 / 640×360 / 1280×720` (½ cascade)

### Temporal split — 实证 (body) — zlt `sub_180062730`
Dyadic: each lower temporal layer = **half** the fps of the one above (`fr[i-1] = fr[i]*0.5`).
Bitrate factor stored **Q10 fixed-point** (`raw * 2^-10 = raw*0.0009765625`).

## 4. Adaptive-QP — config-driven — zlt.dll

`sub_1800E7680` / `sub_1800E7740` are a 6-threshold bucketing primitive: a sample maps to a QP
offset in **[-3, +3]** against ascending `thr[0..5]` (`<thr0 → -3` … `≥thr5 → +3`); the combined
per-block delta = `textureLadder(variance) + motionLadder(SAD)` (`sub_1800E7A00`, vtable
0x180502738). **The 6 thresholds are passed in as a pointer argument — they are runtime config, not
compile-time constants.** So the *ladder shape* is recovered (实证) but the *threshold values* are
config-driven and cannot be pulled from the image. Do not invent specific thresholds; use the
[-3,+3] shape + texture+motion combine.

## 5. Net-score / MOS thresholds — mixed

- **MOS→net-score cut points**: the recon had `[推断] 4.2 / 3.9 / 3.5 / 3.0 / 2.5`. IDA scan of
  mcm `.rdata` doubles with xrefs: **4.2, 3.5, 3.0, 2.5 are all present as real constants**
  (实证 constant present); **3.9 is NOT present** — instead **3.64 and 3.75** appear. So the S4
  boundary in the recon (3.9) is almost certainly wrong; the real value is likely **3.75** (or
  3.64). The exact comparison function was not fully pinned (the xref'ing functions are large stats
  accumulators), so this stays "constant present" rather than fully body-verified.
- **G.107 E-model** (`sub_1801642D0`): R→MOS polynomial + delay-impairment breakpoints
  100/500/1000/2000/3500 ms — 实证 (already in recon).
- **MCM_NW_WARNING** (`sub_18009CC20`): confirmed to be the telemetry *emit* site (logs
  "MCM_NW_WARNING,"); the on/off threshold comparison is in its caller, not this function. The
  on=3.0/off=3.4 hysteresis pair stays [推断].
- **QoS report throttle**: 9800 ms (0x2648) — 实证 (prior).

## 6. FEC — mixed — mcm.dll

Protection **levels 3/4/5** = number of RS(GF256, poly 0x11D) parity packets per group — 实证 (from
telemetry string `total_decoded_3rd_4th_5th_fec_packets`). The **loss→level thresholds**
(0.05/0.10) remain [推断] — not found as constants.

## 7. NACK / retransmit timing — not recoverable

nydus.dll has **no** `nack` / `retrans` / `rtt` / `rto` / `resend` strings; recon/tp is TLS/HTTP
signalling (curl/openssl), not media retransmit. No RE basis for NACK RTO/timing in the available
binaries → must not be invented. The demo's NACK is a plausible engineering fill, explicitly *not*
Zoom-derived.

## 8. Capture → encode downscale kernel — 实证 (body) — zlt.dll `ns_vpp`

The scaler that shrinks a captured native/4K frame to the chosen ladder rung (§1) before encoding is a
**polyphase, separable, scale-adaptive bicubic** resampler — not a box average and not plain bilinear.
Two VPP classes share one engine:

- **`ns_vpp::zltCResample`** — general resampler, arbitrary ratio, quality selectable at runtime.
- **`ns_vpp::zltCGvdownsample`** — dedicated downsampler; **hard-wires the bicubic kernel**.
- `ns_vpp::zltCNearest` = integer-factor nearest decimation (÷N≤7 fast path, `sub_18021DAD0`);
  `zltCBilinear` / `zltCUpSampleBilinear` / `zltCAlignedBilinearUpsample` = **upscale / receive side**,
  not the send-side downscale.

### 8a. Kernel = bicubic Keys, a = −0.5 (Catmull-Rom) — `sub_1801BCCA0`
Installed as a function pointer at `engine+0x318` (read in the weight loop `sub_1801BCF00`). Weight vs
signed distance `x`, support radius 2 (⇒ 4 taps at unity):
```
k(x) =  1.5|x|^3 − 2.5|x|^2 + 1          for |x| < 1
       −0.5|x|^3 + 2.5|x|^2 − 4|x| + 2   for 1 ≤ |x| < 2
        0                                 for |x| ≥ 2
```
Verified term-for-term against the decompile (both the branchy signed form `sub_1801BCCA0` and the
`fabs` form `sub_1801BCDA0`). Zero at every nonzero integer ⇒ interpolating (sharp); small negative lobe
at |x|=1.5 (k=−0.0625) ⇒ mild edge enhancement. `zltCGvdownsample` uses this kernel unconditionally.

### 8b. Selectable kernels — `sub_1801BC6F0` (config case 1/2/3)
| case | fn | support radius | kernel |
|------|----|----------------|--------|
| 1 (default) | `sub_1801BCCA0` | 2.0 | bicubic Catmull-Rom (a=−0.5) |
| 2 | `sub_1801BCE40` | 4.0 | **Lanczos-4** — windowed sinc, `sin(πx/4)·sin(πx)` form, support [−4,4] |
| 3 | `sub_1801BCDA0` | 2.0 | bicubic a=−0.5 (fabs form; scalar/upscale variant) |

### 8c. Scale-adaptive anti-aliasing — `sub_1801BC400`
Filter support is widened by the downscale factor so the kernel low-passes the source and does not alias:
```
fscale  = max(1, src/dst)      # per axis; == 1 on upscale (plain bicubic interpolation)
support = 2 * fscale           # base bicubic radius 2, stretched
taps    = ceil(2 * support)    # tap count grows with the shrink ratio
kernel arg = (tap − center) / fscale
```
At unity scale it collapses to a bit-exact copy (Catmull-Rom passes through the samples).

### 8d. Separable + fixed-point weights — `sub_1801BCF00` / `sub_1801BD360`
Independent 1-D horizontal then vertical passes (equal-ratio fast path `sub_1801BD360`, else two
`sub_1801BCF00` calls). Per output pixel the taps are accumulated over the support window and **normalized
to sum = 16384 (Q14)** as `int16`, with the last tap absorbing the rounding error so the sum is exact.
The apply loops are installed in 3 SIMD variants (scalar / SSE / AVX2) by CPU dispatch in the engine
ctor `sub_18023C8B0` (fn-ptr pairs at `+0x0D8/+0x0E0`, `+0x320/+0x328`).

---

### Net effect on the demo (fidelity corrections to apply)
1. Resolution ladder rungs → **{320×180, 640×360, 1280×720, 1920×1080}** (was 1600×912 / 1088 / ad-hoc).
2. Screen fps cap → **30** (content-throttled lower); camera 720p/1080p may use **60**.
3. Bitrate hysteresis → **×0.9 down / ×1.1 up**.
4. SVC → recovered 3-layer {160×90@12, 320×180@12, 640×360@24} factors {0.8,0.85,0.95}; ½ scaling confirmed.
5. Net-score S4 cut → **3.75** (drop the invented 3.9).
6. QP → keep the [-3,+3] texture+motion ladder; thresholds stay config (no invented numbers).
7. Capture→encode downscale → **bicubic Catmull-Rom (a=−0.5), support = 2·max(1,src/dst) anti-alias,
   separable, Q14 weights** (was box average). Ported to the demo as `apps/resample.hpp`
   (`avp::resample::ResizeBGRA`); the higher-quality Lanczos-4 rung is available but not the default.
