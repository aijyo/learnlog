// zlt_encode_config.hpp -- clean-room reconstruction of zltCEncodeConfig::SetEncodeCfg
// APPLY logic (sub_18005A690), body-verified. This is the part of zlt that is its OWN
// logic (config state machine), distinct from the codec engine (the ~96% ⛔K boundary).
//
// What SetEncodeCfg does after ingesting the layered config:
//   1) unpack the 16-bit "structure mode" word into sub-fields (nibbles);
//      structure_mode = word & 0xF ; special-case: mode==3 -> mode:=2, field212:=1.
//   2) per spatial layer: derive the reference-buffer count from a per-layer flag
//      (flag==1 -> 8 DPB slots, else 16), and unpack the 6-bit tools-control flag
//      into 6 per-layer tool booleans.
//   3) change-detection vs the previous layer array -> set the reconfig-pending bit
//      (which also selects the double-buffer bank for the key-picture request slots,
//      see zlt_svc_encoder.hpp). Reconfig-while-pending is an error.
//   4) modes 4/5 (screen SVC) set an extra flag; a secondary (simulcast/dual) config
//      is applied when enabled and the state is in {5,6}.
#pragma once
#include "zlt_svc_encoder.hpp"
#include <array>
#include <vector>
#include <cstdint>

namespace recon::zlt {

// Unpacked "structure mode" word (cfg+136 and the derived sub-fields at +212/216/220/222).
struct StructureMode {
    int mode    = 0;   // cfg+136, low nibble  (0..5: simulcast/SVC/single/... )
    int field212 = 0;  // (word>>4)&0xF
    int field216 = 0;  // word>>8
    int field220 = 0;  // (word>>8)&0xF
    int field222 = 0;  // word>>12  (also the run-state checked as {5,6} elsewhere)

    static StructureMode Unpack(uint16_t word) {
        StructureMode m;
        m.field216 = word >> 8;
        m.field222 = word >> 12;
        m.field220 = (word >> 8) & 0xF;
        m.field212 = (word >> 4) & 0xF;
        m.mode     = word & 0xF;
        if (m.mode == 3) { m.field212 = 1; m.mode = 2; }   // verified special case
        return m;
    }
};

// Per-layer derived state produced by the apply pass.
struct LayerDerived {
    int ref_buffer_count = 16;          // cfg+34648[i]: (single_ref_flag==1) ? 8 : 16
    std::array<bool, 6> tool_bits{};    // cfg+34820[i*6..]: bits 0..5 of nToolsControlFlag
};

// Reconstructed config state + the SetEncodeCfg apply.
struct EncoderConfigState {
    StructureMode structure;
    std::vector<LayerDerived> layers;
    bool reconfig_pending = false;      // cfg+41640 (also the request-slot bank selector)
    bool screen_svc = false;            // codec mode in {4,5} -> extra flag (cfg+35224)
    std::vector<SpatialLayer> current;  // cfg+160 previous layer array (for change detect)

    // Returns 0 on success, negative on error (mirrors the recovered error codes).
    int ApplyEncodeCfg(const EncodeConfig& cfg, uint16_t structure_word, int codec_mode,
                       bool secondary_enabled) {
        structure = StructureMode::Unpack(structure_word);
        screen_svc = (unsigned(codec_mode - 4) <= 1);   // (mode-4)<=1  -> modes 4/5

        // per-layer derivation
        layers.assign(cfg.spatial.size(), {});
        for (size_t i = 0; i < cfg.spatial.size(); ++i) {
            const SpatialLayer& L = cfg.spatial[i];
            layers[i].ref_buffer_count = L.single_ref ? 8 : 16;   // verified: single-ref flag -> 8 DPB else 16
            for (int b = 0; b < 6; ++b)                                        // 6-bit tools flag
                layers[i].tool_bits[b] = (L.tools_control_flag >> b) & 1;
        }

        // change detection vs previous -> reconfig-pending bit (bank selector)
        bool changed = (current.size() != cfg.spatial.size());
        for (size_t i = 0; !changed && i < cfg.spatial.size(); ++i)
            changed = !SameLayer(current[i], cfg.spatial[i]);
        if (changed) {
            if (reconfig_pending) return kErrReconfigWhilePending;   // already pending
            reconfig_pending = true;
        }
        current = cfg.spatial;

        // secondary (simulcast/dual) config applies only in states 5/6
        (void)secondary_enabled;   // real path: if(secondary_enabled && field222 in {5,6}) apply cfg+4864
        return 0;
    }

    static constexpr int kErrReconfigWhilePending = -5;  // recovered raw code 0xE5A2..; surfaced as -5

    // reconfig-pending bit doubles as the request-slot double-buffer bank (0/1).
    int RequestSlotBank() const { return reconfig_pending ? 1 : 0; }

private:
    static bool SameLayer(const SpatialLayer& a, const SpatialLayer& b) {
        return a.width == b.width && a.height == b.height && a.bitrate == b.bitrate &&
               a.fix_qp == b.fix_qp && a.temporal_layer_num == b.temporal_layer_num &&
               a.single_ref == b.single_ref && a.ltr == b.ltr;
    }
};

} // namespace recon::zlt
