// webapp_settings.hpp — clean-room reconstruction of ssb_sdk.dll's *consumption pattern*
// for server-driven "webapp" settings, on top of the recovered com.saasbee.webapp.proto
// schema (real full-runtime protobuf).
//
// Honest boundary: ssb_sdk delivers these settings over its `topic`/`topicV2` pub/sub bus,
// which is a static-RE boundary here (no locatable topic/publish/subscribe symbols in the
// export table — the bus is templated/inlined). What IS recovered and reconstructed is the
// SCHEMA (exact message/field names) and the client-side read pattern below.
#pragma once
#include "webapp_aic.pb.h"
#include <string>

namespace recon { namespace ssb {

namespace pb = com::saasbee::webapp::proto;

// Client-side store: receives a serialized AICSetting (as the server pushes on the bus),
// parses it with REAL protobuf, and exposes typed reads — mirroring how ssb_sdk hands
// server config to the app layer.
struct WebAppSettingsStore {
  pb::AICSetting aic;
  bool loaded = false;

  bool LoadFromWire(const std::string& bytes) {          // real libprotobuf parse
    loaded = aic.ParseFromString(bytes);
    return loaded;
  }

  std::string advanced_setting_url() const { return aic.advancedsettingurl(); }
  int app_count() const { return aic.apps_size(); }
  int item_count() const { return aic.items_size(); }

  const pb::AICompanionAppItem* find_app(const std::string& service) const {
    for (int i = 0; i < aic.apps_size(); ++i)
      if (aic.apps(i).service() == service) return &aic.apps(i);
    return nullptr;
  }
};

}} // namespace recon::ssb
