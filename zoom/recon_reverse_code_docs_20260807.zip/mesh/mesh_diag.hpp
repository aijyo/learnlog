// mesh_diag.hpp — reconstruction of zMeshNetAgent's reactive data-binding + diagnostics.
//
// The DLL wires state via CMeshDataObserver<T> bound in MeshMeetingInfo::InitDataObservers /
// CMeshNetworkModule::InitDataObservers (dozens of lambdas), and feeds a CMeshDiagnosticProvider
// (VCMeshDiagnosticInfo) that reports topology/state to the admin dashboard. Reconstructed here so
// state changes really fan out to a diagnostic snapshot.
#pragma once
#include "mesh_types.hpp"
#include <functional>
#include <string>
#include <vector>

namespace recon { namespace mesh {

// CMeshDataObserver<T>: an observed value; setting it (when changed) notifies bound observers.
template <class T>
class CMeshDataObserver {
public:
  const T& Get() const { return value_; }
  void Set(const T& v) {
    bool changed = !(v == value_);
    value_ = v;
    if (changed) for (auto& f : obs_) f(v);
  }
  void Observe(std::function<void(const T&)> f) { obs_.push_back(std::move(f)); }
private:
  T value_{};
  std::vector<std::function<void(const T&)>> obs_;
};

// VCMeshDiagnosticInfo — the reportable snapshot.
struct MeshDiagnosticInfo {
  std::string node_id;
  MeshRole    role = MeshRole::Unset;
  std::string parent;
  int         children = 0;
  int         role_changes = 0;      // role transitions observed (incl. initial assignment)
  int         established_count = 0; // (re)establish events -> >1 means a failover happened
  NodeState   state = NodeState::Idle;
  std::string ToString() const {
    return std::string("{node:") + node_id + ", role:" + GetMeshRoleName(role)
         + ", parent:" + (parent.empty() ? "-" : parent) + ", children:" + std::to_string(children)
         + ", state:" + StateName(state) + ", role_changes:" + std::to_string(role_changes)
         + ", established:" + std::to_string(established_count) + "}";
  }
};

// CMeshDiagnosticProvider — observes a node's data and accumulates the snapshot.
class CMeshDiagnosticProvider {
public:
  void SetNode(const std::string& id) { info_.node_id = id; }
  void OnRole(const MeshRole& r)  { if (r != info_.role) { info_.role = r; ++info_.role_changes; } }
  void OnState(const NodeState& s){ info_.state = s; if (s == NodeState::Established) ++info_.established_count; }
  void OnParent(const std::string& p) { info_.parent = p; }
  void OnChildren(int n) { info_.children = n; }
  const MeshDiagnosticInfo& info() const { return info_; }
private:
  MeshDiagnosticInfo info_{};
};

}} // namespace recon::mesh
