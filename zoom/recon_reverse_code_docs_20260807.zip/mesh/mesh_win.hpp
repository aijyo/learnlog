// mesh_win.hpp — REAL Windows implementations of the mesh environment interfaces (block C).
// No stubs: these call the actual OS APIs zMeshNetAgent uses.
//   * WinNetworkCost : ICostNetworkDetect  -> INetworkCostManager::GetCost (NLM metered detection)
//                                             + INetworkListManager::IsConnectedToInternet
//                                             + WlanOpenHandle/WlanEnumInterfaces/WlanQueryInterface (SSID)
//   * WinFirewall    : IFirewall           -> INetFwPolicy2 / INetFwRule (real read; real add gated)
//   * WinHttpBackend : ISBWebServiceAPI     -> real WinHTTP GET to a real (local) HTTP server, JSON parse
//   * LocalHttpServer                       -> a real WinSock HTTP/1.1 server (127.0.0.1) for the demo
#pragma once
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <winhttp.h>
#include <wlanapi.h>
#include <netlistmgr.h>
#include <netfw.h>
#include <objbase.h>
#include <atomic>
#include <string>
#include <thread>
#include <vector>
#include "mesh_env.hpp"

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "wlanapi.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")

namespace recon { namespace mesh {

inline std::wstring to_w(const std::string& s) {
  if (s.empty()) return L"";
  int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
  std::wstring w(n, 0); MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &w[0], n); return w;
}

// ---------------------------------------------------------------------------
// WinNetworkCost — real network-cost / connectivity / WiFi SSID
// ---------------------------------------------------------------------------
struct WinNetworkCost : ICostNetworkDetect {
  NetCost QueryCostForAllInterface() override {
    NetCost r;
    // (1) metered detection via INetworkCostManager (NLM)
    INetworkCostManager* ncm = nullptr;
    if (SUCCEEDED(CoCreateInstance(__uuidof(NetworkListManager), nullptr, CLSCTX_ALL,
                                   __uuidof(INetworkCostManager), (void**)&ncm)) && ncm) {
      DWORD cost = NLM_CONNECTION_COST_UNKNOWN;
      if (SUCCEEDED(ncm->GetCost(&cost, nullptr))) {
        r.cost_flags = cost;
        // UNRESTRICTED = unmetered; treat that as mesh-eligible
        r.has_unmetered_lan = (cost & NLM_CONNECTION_COST_UNRESTRICTED) != 0;
      }
      ncm->Release();
    }
    // (2) connectivity via INetworkListManager
    INetworkListManager* nlm = nullptr;
    if (SUCCEEDED(CoCreateInstance(__uuidof(NetworkListManager), nullptr, CLSCTX_ALL,
                                   __uuidof(INetworkListManager), (void**)&nlm)) && nlm) {
      VARIANT_BOOL c = VARIANT_FALSE; nlm->get_IsConnectedToInternet(&c);
      r.connected = (c == VARIANT_TRUE);
      nlm->Release();
    }
    // (3) connected WiFi SSID via WLAN API
    r.wlan_ssid = QueryWlanSsid();
    return r;
  }
  static std::string QueryWlanSsid() {
    HANDLE h = nullptr; DWORD ver = 0; std::string ssid;
    if (WlanOpenHandle(2, nullptr, &ver, &h) != ERROR_SUCCESS) return "";
    WLAN_INTERFACE_INFO_LIST* list = nullptr;
    if (WlanEnumInterfaces(h, nullptr, &list) == ERROR_SUCCESS && list) {
      for (DWORD i = 0; i < list->dwNumberOfItems; ++i) {
        if (list->InterfaceInfo[i].isState != wlan_interface_state_connected) continue;
        WLAN_CONNECTION_ATTRIBUTES* a = nullptr; DWORD sz = 0; WLAN_OPCODE_VALUE_TYPE vt;
        if (WlanQueryInterface(h, &list->InterfaceInfo[i].InterfaceGuid,
              wlan_intf_opcode_current_connection, nullptr, &sz, (PVOID*)&a, &vt) == ERROR_SUCCESS && a) {
          auto& s = a->wlanAssociationAttributes.dot11Ssid;
          ssid.assign((const char*)s.ucSSID, s.uSSIDLength);
          WlanFreeMemory(a);
        }
      }
      WlanFreeMemory(list);
    }
    WlanCloseHandle(h, nullptr);
    return ssid;
  }
};

// ---------------------------------------------------------------------------
// WinFirewall — real INetFwPolicy2 read; real add is gated (modifies security settings)
// ---------------------------------------------------------------------------
struct WinFirewall : IFirewall {
  const wchar_t* kRuleName = L"Zoom Mesh (demo)";

  bool IsFwRuleAdded(const std::string& /*app*/) override {
    INetFwPolicy2* pol = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(NetFwPolicy2), nullptr, CLSCTX_INPROC_SERVER,
                                __uuidof(INetFwPolicy2), (void**)&pol)) || !pol) return false;
    INetFwRules* rules = nullptr; bool found = false;
    if (SUCCEEDED(pol->get_Rules(&rules)) && rules) {
      INetFwRule* r = nullptr;
      // fast path: query by our rule name
      if (SUCCEEDED(rules->Item(SysAllocString(kRuleName), &r)) && r) { found = true; r->Release(); }
      rules->Release();
    }
    pol->Release();
    return found;
  }

  // Real add. Requires admin (rules->Add -> E_ACCESSDENIED otherwise). Returns HRESULT via ok.
  bool AddFirewallException(const std::string& app, MeshRole /*role*/) override {
    last_hr = E_FAIL;
    INetFwPolicy2* pol = nullptr;
    if (FAILED(CoCreateInstance(__uuidof(NetFwPolicy2), nullptr, CLSCTX_INPROC_SERVER,
                                __uuidof(INetFwPolicy2), (void**)&pol)) || !pol) return false;
    INetFwRules* rules = nullptr; INetFwRule* rule = nullptr; bool ok = false;
    if (SUCCEEDED(pol->get_Rules(&rules)) && rules &&
        SUCCEEDED(CoCreateInstance(__uuidof(NetFwRule), nullptr, CLSCTX_INPROC_SERVER,
                                   __uuidof(INetFwRule), (void**)&rule)) && rule) {
      std::wstring wapp = to_w(app);
      rule->put_Name(SysAllocString(kRuleName));
      rule->put_Description(SysAllocString(L"Zoom eCDN mesh super-node inbound (demo, temporary)"));
      rule->put_ApplicationName(SysAllocString(wapp.c_str()));
      rule->put_Protocol(NET_FW_IP_PROTOCOL_TCP);
      rule->put_Direction(NET_FW_RULE_DIR_IN);
      rule->put_Action(NET_FW_ACTION_ALLOW);
      rule->put_Enabled(VARIANT_TRUE);
      last_hr = rules->Add(rule);            // <- needs elevation
      ok = SUCCEEDED(last_hr);
      rule->Release();
    }
    if (rules) rules->Release();
    pol->Release();
    return ok;
  }
  void RemoveRule() {
    INetFwPolicy2* pol = nullptr;
    if (SUCCEEDED(CoCreateInstance(__uuidof(NetFwPolicy2), nullptr, CLSCTX_INPROC_SERVER,
                                   __uuidof(INetFwPolicy2), (void**)&pol)) && pol) {
      INetFwRules* rules = nullptr;
      if (SUCCEEDED(pol->get_Rules(&rules)) && rules) { rules->Remove(SysAllocString(kRuleName)); rules->Release(); }
      pol->Release();
    }
  }
  HRESULT last_hr = S_OK;
};

// ---------------------------------------------------------------------------
// LocalHttpServer — a real HTTP/1.1 server on 127.0.0.1 (WinSock), for the backend demo.
// Serves GET /mesh/assign?node=<id> -> JSON mesh assignment (encodes the SN/NN topology).
// ---------------------------------------------------------------------------
class LocalHttpServer {
public:
  bool Start(const std::string& primary_sn, const std::string& primary_addr,
             const std::string& backup_sn, const std::string& backup_addr) {
    primary_sn_ = primary_sn; primary_addr_ = primary_addr; backup_sn_ = backup_sn; backup_addr_ = backup_addr;
    listen_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listen_ == INVALID_SOCKET) return false;
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = 0;
    if (bind(listen_, (sockaddr*)&a, sizeof(a)) != 0) return false;
    int alen = sizeof(a); getsockname(listen_, (sockaddr*)&a, &alen); port_ = ntohs(a.sin_port);
    if (::listen(listen_, 8) != 0) return false;
    running_ = true;
    thread_ = std::thread([this] { Loop(); });
    return true;
  }
  int port() const { return port_; }
  void Stop() {
    running_ = false;
    if (listen_ != INVALID_SOCKET) { closesocket(listen_); listen_ = INVALID_SOCKET; }
    if (thread_.joinable()) thread_.join();
  }
  ~LocalHttpServer() { Stop(); }
private:
  std::string BodyForNode(const std::string& node) {
    if (node == primary_sn_ || node == backup_sn_)
      return "{\"role\":\"SuperNode\"}";
    return std::string("{\"role\":\"NormalNode\",\"sn_id\":\"") + primary_sn_ +
           "\",\"sn_addr\":\"" + primary_addr_ + "\",\"backup_id\":\"" + backup_sn_ +
           "\",\"backup_addr\":\"" + backup_addr_ + "\"}";
  }
  static std::string QueryParam(const std::string& req, const std::string& key) {
    auto p = req.find(key + "="); if (p == std::string::npos) return "";
    p += key.size() + 1; auto e = req.find_first_of(" &", p); return req.substr(p, e - p);
  }
  void Loop() {
    while (running_) {
      SOCKET c = accept(listen_, nullptr, nullptr);
      if (c == INVALID_SOCKET) break;
      char buf[2048]; int n = recv(c, buf, sizeof(buf) - 1, 0);
      if (n > 0) {
        buf[n] = 0; std::string req(buf, n);
        std::string node = QueryParam(req, "node");
        std::string body = BodyForNode(node);
        std::string resp = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: " +
                           std::to_string(body.size()) + "\r\nConnection: close\r\n\r\n" + body;
        send(c, resp.c_str(), (int)resp.size(), 0);
      }
      closesocket(c);
    }
  }
  SOCKET listen_ = INVALID_SOCKET; int port_ = 0;
  std::atomic<bool> running_{false}; std::thread thread_;
  std::string primary_sn_, primary_addr_, backup_sn_, backup_addr_;
};

// tiny but real JSON string-field reader: "key":"value"
inline std::string json_str(const std::string& j, const std::string& key) {
  auto p = j.find("\"" + key + "\""); if (p == std::string::npos) return "";
  p = j.find(':', p); if (p == std::string::npos) return "";
  p = j.find('"', p); if (p == std::string::npos) return "";
  auto e = j.find('"', p + 1); if (e == std::string::npos) return "";
  return j.substr(p + 1, e - p - 1);
}

// ---------------------------------------------------------------------------
// WinHttpBackend — real WinHTTP GET to the (local) mesh server; parses JSON -> MeshAssignment
// ---------------------------------------------------------------------------
struct WinHttpBackend : ISBWebServiceAPI {
  std::string host = "127.0.0.1"; int port = 0;
  std::string last_json;

  MeshAssignment ReportMeshNetwork(const std::string& node_id) override {
    MeshAssignment out;
    std::string body = HttpGet("/mesh/assign?node=" + node_id);
    last_json = body;
    if (body.empty()) return out;
    std::string role = json_str(body, "role");
    if (role == "SuperNode") { out.role = MeshRole::SuperNode; return out; }
    out.role = MeshRole::NormalNode;
    out.super_node = { json_str(body, "sn_id"), json_str(body, "sn_addr"), MeshRole::SuperNode };
    std::string bid = json_str(body, "backup_id"), badr = json_str(body, "backup_addr");
    if (!bid.empty()) out.backup_sn.push_back({ bid, badr, MeshRole::SuperNode });
    return out;
  }

  std::string HttpGet(const std::string& path) {
    std::string result;
    HINTERNET s = WinHttpOpen(L"ZoomMeshAgent/1.0", WINHTTP_ACCESS_TYPE_NO_PROXY,
                              WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!s) return result;
    HINTERNET conn = WinHttpConnect(s, to_w(host).c_str(), (INTERNET_PORT)port, 0);
    if (conn) {
      HINTERNET req = WinHttpOpenRequest(conn, L"GET", to_w(path).c_str(), nullptr,
                                         WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
      if (req) {
        if (WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) &&
            WinHttpReceiveResponse(req, nullptr)) {
          DWORD avail = 0;
          do {
            avail = 0; WinHttpQueryDataAvailable(req, &avail);
            if (avail) {
              std::vector<char> buf(avail + 1, 0); DWORD got = 0;
              if (WinHttpReadData(req, buf.data(), avail, &got) && got) result.append(buf.data(), got);
            }
          } while (avail > 0);
        }
        WinHttpCloseHandle(req);
      }
      WinHttpCloseHandle(conn);
    }
    WinHttpCloseHandle(s);
    return result;
  }
};

}} // namespace recon::mesh
#endif // _WIN32
