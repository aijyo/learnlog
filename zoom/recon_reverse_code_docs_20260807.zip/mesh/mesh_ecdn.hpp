// mesh_ecdn.hpp — a complete, real-socket eCDN mesh demo built on the recovered principle:
//   ORIGIN (Zoom cloud)  --pull once per Super Node-->  SUPER NODE  --relay over LAN-->  NORMAL NODEs
// A SCHEDULER (mesh server) assigns roles/topology. Everything runs over real WinSock TCP on
// 127.0.0.1 across threads, so the data plane (relay) and the bandwidth saving are real & measured.
#pragma once
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <utility>
#include <vector>
#include "mesh_types.hpp"
#pragma comment(lib, "ws2_32.lib")

namespace recon { namespace mesh {

// ---- socket + framing helpers ----
inline bool send_all(SOCKET s, const char* p, int n) { while (n > 0) { int k = send(s, p, n, 0); if (k <= 0) return false; p += k; n -= k; } return true; }
inline bool recv_all(SOCKET s, char* p, int n) { while (n > 0) { int k = recv(s, p, n, 0); if (k <= 0) return false; p += k; n -= k; } return true; }
inline void put_u32(std::vector<char>& b, uint32_t v) { b.push_back((char)(v & 0xff)); b.push_back((char)((v >> 8) & 0xff)); b.push_back((char)((v >> 16) & 0xff)); b.push_back((char)((v >> 24) & 0xff)); }
inline bool recv_u32(SOCKET s, uint32_t& v) { char b[4]; if (!recv_all(s, b, 4)) return false; v = (uint8_t)b[0] | ((uint8_t)b[1] << 8) | ((uint8_t)b[2] << 16) | ((uint32_t)(uint8_t)b[3] << 24); return true; }

inline SOCKET listen_on(int& port) {
  SOCKET ls = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); if (ls == INVALID_SOCKET) return ls;
  sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = 0;
  if (bind(ls, (sockaddr*)&a, sizeof a) != 0) { closesocket(ls); return INVALID_SOCKET; }
  int l = sizeof a; getsockname(ls, (sockaddr*)&a, &l); port = ntohs(a.sin_port);
  if (::listen(ls, 32) != 0) { closesocket(ls); return INVALID_SOCKET; }
  return ls;
}
inline SOCKET connect_to(int port) {
  SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); if (s == INVALID_SOCKET) return s;
  sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = htons((u_short)port);
  if (connect(s, (sockaddr*)&a, sizeof a) != 0) { closesocket(s); return INVALID_SOCKET; }
  return s;
}
inline std::string rpc_line(int port, const std::string& cmd) {
  SOCKET s = connect_to(port); if (s == INVALID_SOCKET) return "";
  std::string c = cmd + "\n"; send_all(s, c.data(), (int)c.size());
  std::string resp; char ch; while (recv(s, &ch, 1, 0) == 1) { if (ch == '\n') break; resp += ch; }
  closesocket(s); return resp;
}

// ---- the "media stream" (a webinar segment = N chunks) ----
struct MediaStream {
  std::vector<std::vector<char>> chunks;
  uint64_t checksum = 0;
  static uint64_t fnv(uint64_t h, unsigned char b) { return (h ^ b) * 1099511628211ull; }
  static MediaStream make(int n, int chunkSize) {
    MediaStream m; uint64_t cs = 1469598103934665603ull;
    for (int i = 0; i < n; ++i) { std::vector<char> c(chunkSize);
      for (int j = 0; j < chunkSize; ++j) { c[j] = (char)((i * 131 + j * 7) & 0xff); cs = fnv(cs, (unsigned char)c[j]); }
      m.chunks.push_back(std::move(c)); }
    m.checksum = cs; return m;
  }
  void computeChecksum() { uint64_t cs = 1469598103934665603ull; for (auto& c : chunks) for (char b : c) cs = fnv(cs, (unsigned char)b); checksum = cs; }
  uint64_t payloadBytes() const { uint64_t t = 0; for (auto& c : chunks) t += c.size(); return t; }
};

// serve a stream on a connected socket; returns payload bytes sent
inline uint64_t serve_stream(SOCKET c, const MediaStream& m) {
  std::vector<char> hdr; put_u32(hdr, (uint32_t)m.chunks.size());
  if (!send_all(c, hdr.data(), (int)hdr.size())) return 0;
  uint64_t sent = 0;
  for (auto& ch : m.chunks) {
    std::vector<char> lh; put_u32(lh, (uint32_t)ch.size());
    if (!send_all(c, lh.data(), 4) || !send_all(c, ch.data(), (int)ch.size())) break;
    sent += ch.size();
  }
  return sent;
}
// receive a full stream; fills `out` (+ checksum) and returns payload bytes
inline uint64_t recv_stream(SOCKET s, MediaStream& out) {
  uint32_t n = 0; if (!recv_u32(s, n)) return 0;
  uint64_t got = 0;
  for (uint32_t i = 0; i < n; ++i) {
    uint32_t len = 0; if (!recv_u32(s, len)) break;
    std::vector<char> c(len); if (len && !recv_all(s, c.data(), (int)len)) break;
    got += len; out.chunks.push_back(std::move(c));
  }
  out.computeChecksum();
  return got;
}

// ---- ORIGIN server (simulates Zoom cloud): every connection = one full-stream pull (WAN) ----
class OriginServer {
public:
  bool start(const MediaStream* s) { stream_ = s; ls_ = listen_on(port_); if (ls_ == INVALID_SOCKET) return false; run_ = true; th_ = std::thread([this] { loop(); }); return true; }
  int port() const { return port_; }
  uint64_t bytes_served() const { return served_; }
  int pulls() const { return pulls_; }
  void stop() { run_ = false; if (ls_ != INVALID_SOCKET) { closesocket(ls_); ls_ = INVALID_SOCKET; } if (th_.joinable()) th_.join(); }
  ~OriginServer() { stop(); }
private:
  void loop() { while (run_) { SOCKET c = accept(ls_, nullptr, nullptr); if (c == INVALID_SOCKET) break; served_ += serve_stream(c, *stream_); ++pulls_; closesocket(c); } }
  SOCKET ls_ = INVALID_SOCKET; int port_ = 0;
  std::atomic<bool> run_{false}; std::thread th_;
  const MediaStream* stream_ = nullptr;
  std::atomic<uint64_t> served_{0}; std::atomic<int> pulls_{0};
};

// ---- SCHEDULER (mesh server): assigns roles + hands NN the SN endpoint ----
class Scheduler {
public:
  void configure_sn(const std::string& lan, const std::string& node) { sn_of_lan_[lan] = node; }
  bool start() { ls_ = listen_on(port_); if (ls_ == INVALID_SOCKET) return false; run_ = true; th_ = std::thread([this] { loop(); }); return true; }
  int port() const { return port_; }
  void stop() { run_ = false; if (ls_ != INVALID_SOCKET) { closesocket(ls_); ls_ = INVALID_SOCKET; } if (th_.joinable()) th_.join(); }
  ~Scheduler() { stop(); }
private:
  void loop() { while (run_) { SOCKET c = accept(ls_, nullptr, nullptr); if (c == INVALID_SOCKET) break; handle(c); closesocket(c); } }
  void handle(SOCKET c) {
    std::string line; char ch; while (recv(c, &ch, 1, 0) == 1) { if (ch == '\n') break; line += ch; }
    std::istringstream is(line); std::string op; is >> op; std::string resp = "ERR";
    if (op == "REGISTER") {
      std::string node, lan; is >> node >> lan;
      std::lock_guard<std::mutex> g(mu_);
      if (sn_of_lan_.count(lan) && sn_of_lan_[lan] == node) resp = "ROLE SN";
      else { auto it = announced_.find(lan); resp = it != announced_.end() ? ("ROLE NN 127.0.0.1 " + std::to_string(it->second)) : "ROLE NN WAIT"; }
    } else if (op == "ANNOUNCE") {
      std::string node, lan, host; int p = 0; is >> node >> lan >> host >> p;
      std::lock_guard<std::mutex> g(mu_); announced_[lan] = p; resp = "OK";
    }
    resp += "\n"; send_all(c, resp.data(), (int)resp.size());
  }
  SOCKET ls_ = INVALID_SOCKET; int port_ = 0;
  std::atomic<bool> run_{false}; std::thread th_;
  std::map<std::string, std::string> sn_of_lan_;   // lan -> configured SN node
  std::map<std::string, int> announced_;           // lan -> SN relay port
  std::mutex mu_;
};

// ---- client result (for assertions) ----
struct ClientResult {
  std::string node, lan;
  MeshRole role = MeshRole::Unset;
  uint64_t recv_bytes = 0, recv_checksum = 0, relayed_bytes = 0;
  int served_children = 0;
  bool ok = false;
};

// one mesh client. SN: announce -> pull from origin -> relay to `expect_children` NNs.
// NN: (retry) get SN endpoint -> pull from SN.
inline void run_client(ClientResult* out, std::string node, std::string lan,
                       int sched_port, int origin_port, int expect_children) {
  out->node = node; out->lan = lan;
  std::string role = rpc_line(sched_port, "REGISTER " + node + " " + lan);
  if (role.rfind("ROLE SN", 0) == 0) {
    out->role = MeshRole::SuperNode;
    int relay_port = 0; SOCKET ls = listen_on(relay_port);
    if (ls == INVALID_SOCKET) return;
    rpc_line(sched_port, "ANNOUNCE " + node + " " + lan + " 127.0.0.1 " + std::to_string(relay_port));
    // pull the stream ONCE from the origin (this is the only WAN egress for the LAN)
    SOCKET o = connect_to(origin_port); MediaStream got;
    if (o != INVALID_SOCKET) { out->recv_bytes = recv_stream(o, got); out->recv_checksum = got.checksum; closesocket(o); }
    // relay the pulled stream to each normal node over the LAN
    for (int i = 0; i < expect_children; ++i) {
      SOCKET c = accept(ls, nullptr, nullptr); if (c == INVALID_SOCKET) break;
      out->relayed_bytes += serve_stream(c, got); ++out->served_children; closesocket(c);
    }
    closesocket(ls); out->ok = true;
  } else {
    out->role = MeshRole::NormalNode;
    int sn_port = 0;
    for (int tries = 0; tries < 100 && sn_port == 0; ++tries) {   // wait for SN to announce
      std::istringstream is(role); std::string a, b, host; int p = 0; is >> a >> b >> host >> p; // ROLE NN host port
      if (b == "NN" && p > 0) { sn_port = p; break; }
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
      role = rpc_line(sched_port, "REGISTER " + node + " " + lan);
    }
    if (sn_port == 0) return;
    SOCKET s = connect_to(sn_port); MediaStream got;
    if (s != INVALID_SOCKET) { out->recv_bytes = recv_stream(s, got); out->recv_checksum = got.checksum; closesocket(s); out->ok = true; }
  }
}

}} // namespace recon::mesh
#endif // _WIN32
