// mesh_types.hpp — clean-room reconstruction of zMeshNetAgent's core types.
//
// Body/string-verified (zMeshNetAgent.dll): MeshNetworkRole (Super Node / Normal Node),
// GetMeshRoleName, Parent/Child tree, MeshMeetingInfo, CPeerNodeInfo, gating flags
// (EnableMeshNetworking / EnableGuestMesh GPO, account webinar/meeting mesh, user option),
// config keys cdn_sn_addr / cdn_sn_node_id / cdn_role_type, and the handshake/event messages.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace recon { namespace mesh {

// MeshNetworkRole + GetMeshRoleName (strings recovered)
enum class MeshRole { Unset, SuperNode, NormalNode };
inline const char* GetMeshRoleName(MeshRole r) {
  switch (r) { case MeshRole::SuperNode: return "SuperNode";
               case MeshRole::NormalNode: return "NormalNode"; default: return "Unset"; }
}

// meeting types the mesh gating distinguishes ("enable webinar mesh / meeting mesh / external")
enum class MeetingType { Webinar, Meeting, External };

// NN handshake state machine (from the trace strings: Connecting->Requesting->Confirming->Established)
enum class NodeState { Idle, Requesting, Confirming, Established, Broken };
inline const char* StateName(NodeState s) {
  switch (s){ case NodeState::Requesting:return "Requesting"; case NodeState::Confirming:return "Confirming";
              case NodeState::Established:return "Established"; case NodeState::Broken:return "Broken"; default:return "Idle"; }
}

// EnableGuestMesh GPO tri-state (FormatGuestMeshStatus)
enum class GuestMeshGPO { NotConfigured, Enabled, Disabled };

// CPeerNodeInfo / MeshPeerNodeInfo
struct PeerNodeInfo {
  std::string node_id;     // cdn_sn_node_id / cdn_nn_node_id
  std::string address;     // cdn_sn_addr (host:port)
  MeshRole    role = MeshRole::Unset;
};

// gating inputs (account plan + GPO + user option + meeting type) -> IsMeshEnable
struct MeshGating {
  bool         account_ecdn            = true;   // account plan supports eCDN
  bool         enable_mesh_networking  = true;   // EnableMeshNetworking (GPO)
  bool         account_webinar_mesh    = true;   // AccountSupportWebinarMesh
  bool         account_meeting_mesh    = true;   // AccountSupportMeetingMesh
  GuestMeshGPO guest_mesh              = GuestMeshGPO::Enabled;  // EnableGuestMesh (GPO)
  bool         user_option             = true;   // user enabled mesh

  // returns {ok, reason-if-not}
  bool IsMeshEnable(MeetingType t, std::string& why) const {
    if (!account_ecdn)           { why = "don't support ecdn: Account not enable mesh"; return false; }
    if (!enable_mesh_networking) { why = "EnableMeshNetworking off (GPO)";              return false; }
    if (!user_option)            { why = "user option off";                             return false; }
    if (t == MeetingType::Webinar && !account_webinar_mesh) { why = "webinar mesh not supported"; return false; }
    if (t == MeetingType::Meeting && !account_meeting_mesh) { why = "meeting mesh not supported"; return false; }
    if (t == MeetingType::External && guest_mesh != GuestMeshGPO::Enabled) { why = "EnableGuestMesh off"; return false; }
    return true;
  }
};

// mesh signaling messages (recovered message names: Node Event / Backup Super Node List /
// AskChildDrop / downstream-broken + the handshake steps)
enum class MsgType {
  HandshakeRequest,   // NN -> SN
  HandshakeResponse,  // SN -> NN (accept/reject)
  HandshakeConfirm,   // NN -> SN
  Established,        // SN -> NN (signal connection established)
  BackupSNList,       // SN -> NN (backup super node list)
  AskChildDrop,       // SN -> NN
  DownstreamBroken,   // parent lost
  NodeEvent           // role/state change
};

struct MeshMessage {
  MsgType     type;
  std::string from;
  std::string to;
  bool        accept = true;                 // HandshakeResponse
  std::vector<PeerNodeInfo> backup_sn;       // BackupSNList
  std::string note;
};

}} // namespace recon::mesh
