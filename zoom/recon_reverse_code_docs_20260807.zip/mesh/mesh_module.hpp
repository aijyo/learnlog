// mesh_module.hpp — CMeshNetworkModule reconstructed as a runnable state machine + an in-process
// MeshFabric that transports SERIALIZED signaling frames (MeshWire) between node instances, so the
// SN/NN handshake, failover, wire round-trip and the reactive observer/diagnostic all execute.
//
// Reconstructed control flow (zMeshNetAgent.dll):
//   StartMeeting: gating (IsMeshEnable) -> cost detect (CCostNetworkDetect) -> report to backend
//   (SB_webservice ReportMeshNetwork / OnGetMeshSvrResponse) -> role. SuperNode: firewall+listen.
//   NormalNode: handshake to SN (Requesting->Confirming->Established). Resilience: downstream-broken
//   -> auto_switch_parent -> next backup SN. Reactive state via CMeshDataObserver -> diagnostics.
#pragma once
#include "mesh_types.hpp"
#include "mesh_env.hpp"
#include "mesh_diag.hpp"
#include "mesh_wire.hpp"
#include <map>
#include <set>
#include <string>
#include <vector>

namespace recon { namespace mesh {

class CMeshNetworkModule;

// in-process signaling fabric — transports serialized frames (a real encode/parse per hop)
class MeshFabric {
public:
  void Register(const std::string& id, CMeshNetworkModule* n) { nodes_[id] = n; }
  bool Online(const std::string& id) const { return nodes_.count(id) && !offline_.count(id); }
  bool Send(const MeshMessage& m);                 // encodes to bytes; false if `to` offline
  void CrashNode(const std::string& id);           // offline + notify children (heartbeat detect)
  size_t wire_bytes() const { return wire_bytes_; }
private:
  std::map<std::string, CMeshNetworkModule*> nodes_;
  std::set<std::string> offline_;
  size_t wire_bytes_ = 0;
};

class CMeshNetworkModule {
public:
  CMeshNetworkModule(std::string node_id, std::string address, MeshFabric* fabric,
                     ISBWebServiceAPI* web, ICostNetworkDetect* cost, IFirewall* fw)
    : node_id_(std::move(node_id)), address_(std::move(address)),
      fabric_(fabric), web_(web), cost_(cost), fw_(fw) {
    InitDataObservers();                       // bind reactive state -> diagnostics
    fabric_->Register(node_id_, this);
  }
  CMeshNetworkModule(const CMeshNetworkModule&) = delete;
  CMeshNetworkModule& operator=(const CMeshNetworkModule&) = delete;

  bool StartMeeting(uint64_t meetingNum, MeetingType type, const MeshGating& gating) {
    meeting_num_ = meetingNum; type_ = type;
    log("Meeting " + std::to_string(meetingNum) + " GetMeetingStartParam");
    std::string why;
    if (!gating.IsMeshEnable(type, why)) { log("Meeting " + std::to_string(meetingNum) + " " + why); return false; }
    NetCost nc = cost_->QueryCostForAllInterface();
    if (!nc.has_unmetered_lan) { log("no unmetered LAN interface -> skip mesh"); return false; }
    MeshAssignment a = web_->ReportMeshNetwork(node_id_);      // report -> OnGetMeshSvrResponse
    role_.Set(a.role);
    log("assigned role: " + std::string(GetMeshRoleName(role_.Get())));
    if (a.role == MeshRole::SuperNode) {
      fw_->AddFirewallException(app_, a.role); listening_ = true;
      log("Listen success (super node), firewall exception added");
    } else if (a.role == MeshRole::NormalNode) {
      backup_sn_ = a.backup_sn;
      connectToSuperNode(a.super_node);
    }
    return true;
  }

  void OnMessage(const MeshMessage& m) {
    switch (m.type) {
      case MsgType::HandshakeRequest:                          // SN side
        children_.insert(m.from); diag_.OnChildren((int)children_.size());
        log("Accept connection from normal node " + m.from);
        fabric_->Send({ MsgType::HandshakeResponse, node_id_, m.from, true });
        log("Response handshake to normal node " + m.from);
        break;
      case MsgType::HandshakeResponse:                         // NN side
        if (m.accept) {
          state_.Set(NodeState::Confirming);
          log("Confirming handshake to super node: " + m.from);
          fabric_->Send({ MsgType::HandshakeConfirm, node_id_, m.from });
        } else { log("super node rejected: " + m.from); autoSwitchParent(); }
        break;
      case MsgType::HandshakeConfirm:                          // SN side
        log("Finish handshake to normal node " + m.from);
        fabric_->Send({ MsgType::Established, node_id_, m.from });
        break;
      case MsgType::Established:                               // NN side
        parent_.Set(m.from); state_.Set(NodeState::Established);
        log("Signal connection established with super node: " + m.from);
        break;
      case MsgType::BackupSNList: backup_sn_ = m.backup_sn; break;
      case MsgType::AskChildDrop: log("HandleAskChildDropMsg"); OnParentLost(); break;
      case MsgType::DownstreamBroken: OnParentLost(); break;
      case MsgType::NodeEvent: log("Node Event Message: " + m.note); break;
    }
  }

  void OnParentLost() {
    log("Meeting " + std::to_string(meeting_num_) + " Receive downstream broken message");
    if (!parent_.Get().empty()) log("Child Disconnect from Parent: " + parent_.Get());
    parent_.Set(std::string()); state_.Set(NodeState::Broken);
    autoSwitchParent();
  }

  void ApplyRole(MeshRole newRole) {
    if (newRole == role_.Get()) return;
    log(std::string("Node change from ") + GetMeshRoleName(role_.Get()) + " to " + GetMeshRoleName(newRole));
    role_.Set(newRole);
    if (newRole == MeshRole::SuperNode) {
      fw_->AddFirewallException(app_, newRole); listening_ = true; parent_.Set(std::string());
      log("Listen success (super node), firewall exception added");
    }
  }

  // --- accessors ---
  const std::string& id() const { return node_id_; }
  MeshRole role() const { return role_.Get(); }
  NodeState state() const { return state_.Get(); }
  const std::string& parentId() const { return parent_.Get(); }
  std::vector<std::string> children() const { return { children_.begin(), children_.end() }; }
  bool listening() const { return listening_; }
  const std::vector<std::string>& trace() const { return trace_; }
  const MeshDiagnosticInfo& diagnostics() const { return diag_.info(); }

private:
  void InitDataObservers() {                    // CMeshNetworkModule::InitDataObservers
    diag_.SetNode(node_id_);
    role_.Observe([this](const MeshRole& r)   { diag_.OnRole(r); });
    state_.Observe([this](const NodeState& s) { diag_.OnState(s); });
    parent_.Observe([this](const std::string& p) { diag_.OnParent(p); });
  }
  void connectToSuperNode(const PeerNodeInfo& sn) {
    state_.Set(NodeState::Requesting);
    log("Connecting to super node: " + sn.node_id);
    log("Requesting handshake to super node: " + sn.node_id + ", super node address: " + sn.address);
    if (!fabric_->Send({ MsgType::HandshakeRequest, node_id_, sn.node_id })) {
      log("super node unreachable: " + sn.node_id);
      autoSwitchParent();
    }
  }
  void autoSwitchParent() {
    log("auto_switch_parent");
    if (!backup_sn_.empty()) {
      PeerNodeInfo next = backup_sn_.front();
      backup_sn_.erase(backup_sn_.begin());
      log("switching to backup super node: " + next.node_id);
      connectToSuperNode(next);
    } else {
      log("no backup super node left -> re-report to mesh server");
      MeshAssignment a = web_->ReportMeshNetwork(node_id_);
      if (a.role == MeshRole::NormalNode) { backup_sn_ = a.backup_sn; connectToSuperNode(a.super_node); }
    }
  }
  void log(const std::string& s) { trace_.push_back("[MeshNetwork TraceLog] " + node_id_ + ": " + s); }

  std::string node_id_, address_, app_ = "Zoom.exe";
  MeshFabric* fabric_; ISBWebServiceAPI* web_; ICostNetworkDetect* cost_; IFirewall* fw_;
  CMeshDataObserver<MeshRole>    role_;
  CMeshDataObserver<NodeState>   state_;
  CMeshDataObserver<std::string> parent_;
  std::set<std::string> children_;
  std::vector<PeerNodeInfo> backup_sn_;
  bool listening_ = false;
  uint64_t meeting_num_ = 0;
  MeetingType type_ = MeetingType::Meeting;
  std::vector<std::string> trace_;
  CMeshDiagnosticProvider diag_;
};

inline bool MeshFabric::Send(const MeshMessage& m) {
  std::vector<uint8_t> frame = MeshWire::encode(m);   // real serialize per hop
  wire_bytes_ += frame.size();
  if (!Online(m.to)) return false;
  nodes_[m.to]->OnMessage(MeshWire::decode(frame));   // real parse on the receiver
  return true;
}
inline void MeshFabric::CrashNode(const std::string& id) {
  offline_.insert(id);
  for (auto& kv : nodes_)
    if (kv.first != id && kv.second->parentId() == id) kv.second->OnParentLost();
}

}} // namespace recon::mesh
