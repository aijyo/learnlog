// mesh_cli.hpp — shared plumbing for the interactive multi-process eCDN mesh CLI
// (mesh_scheduler / mesh_origin / mesh_node). Real WinSock TCP, length-prefixed messages,
// timestamped logging, tiny arg/host:port parsing.
#pragma once
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#pragma comment(lib, "ws2_32.lib")

namespace recon { namespace mesh {

inline void net_init() { WSADATA w; WSAStartup(MAKEWORD(2, 2), &w); }

inline bool send_all(SOCKET s, const char* p, int n) { while (n > 0) { int k = send(s, p, n, 0); if (k <= 0) return false; p += k; n -= k; } return true; }
inline bool recv_all(SOCKET s, char* p, int n) { while (n > 0) { int k = recv(s, p, n, 0); if (k <= 0) return false; p += k; n -= k; } return true; }

// length-prefixed message: [u32 len][bytes]
inline bool write_msg(SOCKET s, const std::string& m) {
  uint32_t n = (uint32_t)m.size();
  char h[4] = { (char)(n & 0xff), (char)((n >> 8) & 0xff), (char)((n >> 16) & 0xff), (char)((n >> 24) & 0xff) };
  return send_all(s, h, 4) && (n == 0 || send_all(s, m.data(), (int)n));
}
inline bool read_msg(SOCKET s, std::string& m) {
  char h[4]; if (!recv_all(s, h, 4)) return false;
  uint32_t n = (uint8_t)h[0] | ((uint8_t)h[1] << 8) | ((uint8_t)h[2] << 16) | ((uint32_t)(uint8_t)h[3] << 24);
  m.resize(n); return n == 0 || recv_all(s, &m[0], (int)n);
}

inline SOCKET listen_on(int port, int& outPort) {
  SOCKET ls = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); if (ls == INVALID_SOCKET) return ls;
  BOOL yes = TRUE; setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, (char*)&yes, sizeof yes);
  sockaddr_in a{}; a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_LOOPBACK); a.sin_port = htons((u_short)port);
  if (bind(ls, (sockaddr*)&a, sizeof a) != 0) { closesocket(ls); return INVALID_SOCKET; }
  int l = sizeof a; getsockname(ls, (sockaddr*)&a, &l); outPort = ntohs(a.sin_port);
  if (::listen(ls, 32) != 0) { closesocket(ls); return INVALID_SOCKET; }
  return ls;
}
inline SOCKET connect_host(const std::string& host, int port) {
  SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); if (s == INVALID_SOCKET) return s;
  sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons((u_short)port);
  if (InetPtonA(AF_INET, host.c_str(), &a.sin_addr) != 1) { closesocket(s); return INVALID_SOCKET; }
  if (connect(s, (sockaddr*)&a, sizeof a) != 0) { closesocket(s); return INVALID_SOCKET; }
  return s;
}
// one-shot request/response on a fresh connection
inline std::string rpc(const std::string& host, int port, const std::string& req) {
  SOCKET s = connect_host(host, port); if (s == INVALID_SOCKET) return "";
  std::string resp; if (write_msg(s, req)) read_msg(s, resp); closesocket(s); return resp;
}

inline std::vector<std::string> split(const std::string& s) { std::vector<std::string> v; std::istringstream is(s); std::string t; while (is >> t) v.push_back(t); return v; }
inline std::string arg(int c, char** v, const std::string& name, const std::string& def) { for (int i = 1; i + 1 < c; ++i) if (name == v[i]) return v[i + 1]; return def; }
inline std::pair<std::string, int> hostport(const std::string& s, int defport) { auto p = s.find(':'); if (p == std::string::npos) return { s, defport }; return { s.substr(0, p), atoi(s.substr(p + 1).c_str()) }; }
inline std::string now() { SYSTEMTIME t; GetLocalTime(&t); char b[16]; sprintf(b, "%02d:%02d:%02d", t.wHour, t.wMinute, t.wSecond); return b; }
inline void logl(const std::string& s) { printf("%s  %s\n", now().c_str(), s.c_str()); fflush(stdout); }

}} // namespace recon::mesh
#endif
