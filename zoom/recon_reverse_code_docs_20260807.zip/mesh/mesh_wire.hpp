// mesh_wire.hpp — reconstructed on-wire serialization for the mesh signaling messages.
//
// The DLL carries these as typed messages (Node Event / Backup Super Node List / handshake).
// Their exact byte layout was NOT recovered (a `[推断]` boundary), so this is a plausible compact
// TLV framing — the point is that the fabric now transports *bytes*, and every message survives a
// real encode/parse round-trip (like a real socket hop), not struct passing.
#pragma once
#include "mesh_types.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace recon { namespace mesh {

struct MeshWire {
  static void putStr(std::vector<uint8_t>& b, const std::string& s) {
    uint16_t n = (uint16_t)s.size();
    b.push_back(n & 0xFF); b.push_back(n >> 8);
    b.insert(b.end(), s.begin(), s.end());
  }
  static std::string getStr(const std::vector<uint8_t>& b, size_t& i) {
    uint16_t n = (uint16_t)(b[i] | (b[i + 1] << 8)); i += 2;
    std::string s(reinterpret_cast<const char*>(&b[i]), n); i += n; return s;
  }
  // frame: [type][from][to][accept][n_backup]{node_id,address,role}*[note]
  static std::vector<uint8_t> encode(const MeshMessage& m) {
    std::vector<uint8_t> b;
    b.push_back((uint8_t)m.type);
    putStr(b, m.from); putStr(b, m.to);
    b.push_back(m.accept ? 1 : 0);
    b.push_back((uint8_t)m.backup_sn.size());
    for (const auto& p : m.backup_sn) { putStr(b, p.node_id); putStr(b, p.address); b.push_back((uint8_t)p.role); }
    putStr(b, m.note);
    return b;
  }
  static MeshMessage decode(const std::vector<uint8_t>& b) {
    MeshMessage m; size_t i = 0;
    m.type = (MsgType)b[i++];
    m.from = getStr(b, i); m.to = getStr(b, i);
    m.accept = b[i++] != 0;
    int n = b[i++];
    for (int k = 0; k < n; ++k) {
      PeerNodeInfo p; p.node_id = getStr(b, i); p.address = getStr(b, i); p.role = (MeshRole)b[i++];
      m.backup_sn.push_back(p);
    }
    m.note = getStr(b, i);
    return m;
  }
};

}} // namespace recon::mesh
