// mesh_env.hpp — the environment zMeshNetAgent depends on, behind interfaces.
//
// In the DLL these are: CCostNetworkDetect::QueryCostForAllInterface (Windows NLM network-cost
// API + Wlan* for WiFi grouping), IsFwRuleAddedImpl / CheckAddFirewallException (Windows Firewall
// INetFwRule), and SB_webservice::ISBWebServiceAPI (the mesh-server backend: report + role
// assignment). Here they are interfaces with test mocks — a real build injects the OS/backend impls.
#pragma once
#include "mesh_types.hpp"
#include <map>
#include <string>
#include <vector>

namespace recon { namespace mesh {

// ---- CCostNetworkDetect : is this a mesh-eligible network? ----
struct NetCost {
  bool has_unmetered_lan = true;   // an unmetered LAN/WiFi interface exists (else don't mesh)
  std::string wlan_ssid;           // Wlan* : SSID used to group same-LAN peers
  unsigned cost_flags = 0;         // NLM_CONNECTION_COST bits (real INetworkCostManager::GetCost)
  bool connected = false;          // INetworkListManager::IsConnectedToInternet
};
struct ICostNetworkDetect {
  virtual ~ICostNetworkDetect() = default;
  virtual NetCost QueryCostForAllInterface() = 0;
};
struct MockCost : ICostNetworkDetect {
  NetCost c;
  explicit MockCost(bool unmetered = true, std::string ssid = "corp-wifi") { c.has_unmetered_lan = unmetered; c.wlan_ssid = ssid; }
  NetCost QueryCostForAllInterface() override { return c; }
};

// ---- Windows Firewall (super node must accept inbound peer connections) ----
struct IFirewall {
  virtual ~IFirewall() = default;
  virtual bool IsFwRuleAdded(const std::string& app) = 0;
  virtual bool AddFirewallException(const std::string& app, MeshRole role) = 0;
};
struct MockFirewall : IFirewall {
  std::map<std::string, bool> rules;
  bool IsFwRuleAdded(const std::string& app) override { return rules.count(app) && rules[app]; }
  bool AddFirewallException(const std::string& app, MeshRole) override { rules[app] = true; return true; }
};

// ---- SB_webservice backend : the mesh server that assigns topology ----
struct MeshAssignment {
  MeshRole              role = MeshRole::Unset;
  PeerNodeInfo          super_node;      // for a NormalNode: which SN to connect to (cdn_sn_addr/id)
  std::vector<PeerNodeInfo> backup_sn;   // backup super node list (failover)
};
struct ISBWebServiceAPI {
  virtual ~ISBWebServiceAPI() = default;
  // MeshNetworkReportRequest -> OnGetMeshSvrResponse (role + super node + backups)
  virtual MeshAssignment ReportMeshNetwork(const std::string& node_id) = 0;
};

// Mock coordinator: a configurable "mesh server". Primary SN + backup SN + the rest are NNs
// pointing at the primary with [backup] as failover.
struct MockMeshServer : ISBWebServiceAPI {
  PeerNodeInfo primary_sn, backup_sn;
  MockMeshServer(PeerNodeInfo primary, PeerNodeInfo backup) : primary_sn(primary), backup_sn(backup) {
    primary_sn.role = MeshRole::SuperNode; backup_sn.role = MeshRole::SuperNode;
  }
  MeshAssignment ReportMeshNetwork(const std::string& node_id) override {
    MeshAssignment a;
    if (node_id == primary_sn.node_id)      { a.role = MeshRole::SuperNode; }
    else if (node_id == backup_sn.node_id)  { a.role = MeshRole::SuperNode; }
    else { a.role = MeshRole::NormalNode; a.super_node = primary_sn; a.backup_sn = { backup_sn }; }
    return a;
  }
};

}} // namespace recon::mesh
