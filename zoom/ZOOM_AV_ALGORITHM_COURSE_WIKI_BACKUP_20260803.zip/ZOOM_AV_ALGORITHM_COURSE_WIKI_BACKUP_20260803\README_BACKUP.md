# Zoom AV Algorithm Course Wiki — backup

Created: 2026-08-03 14:53:20 +08:00

## Open the course

Open v-pipeline/ZOOM_AV_ALGORITHM_COURSE_WIKI.html in a browser. The package preserves the
original v-pipeline/, in2cpp-output/, and esearch/learnlog/ layout, so all relative links
to source HTML, clean-room C++, evidence ledgers, and reference implementations continue to work.

## Scope

- The course HTML and every non-anchor local file linked from it.
- The recursive closure of quoted local C/C++ includes used by those linked source files.
- System headers, third-party libraries, codec kernels, and neural weights are external boundaries
  and are intentionally not copied.

## Integrity

MANIFEST.sha256 covers every packaged file except itself. PACKAGE_CONTENTS.tsv records package
path, byte length, SHA-256, source classification, and original absolute source path.