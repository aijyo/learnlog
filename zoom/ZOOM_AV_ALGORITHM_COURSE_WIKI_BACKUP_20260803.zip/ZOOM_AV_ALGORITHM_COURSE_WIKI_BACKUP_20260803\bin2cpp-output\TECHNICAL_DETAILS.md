# Technical details — viperex.dll / zlt.dll / zbt.dll

Body-verified mechanism, with function EA anchors (reproducible in IDA 7.5 against the `.i64`).
Evidence tags: `[body]` read+understood · `[rtti]` type/vtable confirmed · `[str]` string-anchored.

---

## 1. viperex.dll — OpenVINO audio-extension ML

Identity `[str]`/`[body]`: an OpenVINO-based "Companion-Mic" ML engine — CAM++ speaker embedding,
Picknet/OSD active-speaker, lipsync. PE layout: small `.text` + huge `.rdata`/`.rsrc` (entropy ~7.3–7.5
= embedded trained **weights**).

### 1.1 Model-resource codec `[body]` — `ModelResourceCodec`
Models ship as PE resources (`FindResourceW`, type `L"BIN"`, ids `embedding_model_xml_bin` /
`osd_model_xml_bin`) obfuscated with a trivial scheme, decoded at load:
```
header = 8 bytes, little-endian xml-length, each byte XOR 0xA7
payload = (xml bytes)(bin bytes), each XOR 0xA7
=> Decode: xmlLen = Σ (res[i] ^ 0xA7) << 8i  (i=0..7); then xml = res[8..8+xmlLen] ^ 0xA7; bin = rest ^ 0xA7
```
The `.xml` (OpenVINO IR topology) + `.bin` (weights) are fed to `openvino_c.dll`. Reconstructed +
round-trip tested in `recon/viperex_runtime.hpp` (`Encode`/`Decode`).

### 1.2 Control surface `[body]`
- `viperex_init` `0x1800141F0` / `viperex_version` `0x180014230` (="7.1.0.41345").
- Worker threads via `_beginthreadex` (1 MB stack); **WorkerPriority** map 1..5 (`0x180014C60`).
- Periodic tick via WINMM `timeSetEvent(period,0,cb,0, 0x21|0x10)` (`0x180014820`).
- **PipelineConstants**: 16 kHz mono, 24000-sample (1.5 s) working chunk, 48000-sample (3.0 s) CAM++
  window, `picknet_smoothed > 5.0` ⇒ "active speaker".
- ⛔W: the CAM++/Picknet/lipsync **weights** are trained data — harness is code, weights are not.

---

## 2. zlt.dll — video SVC encode + adaptive control

### 2.1 SVC encode config `[body]` — `SetEncodeCfg` `sub_18005A690`
Top-level `nSpatialLayerNum`; each spatial layer is a **96-byte struct** (`Width`/`Height`/`nFrameRate`/
`nCodecMode`/`nBitrate`/`nFixQp`/`nRaPeriod`/`nRefFrameNum`/`bSingleRefFlag`/`bLtrFlag`/
`nTemporalLayerNum`/… + per-temporal frame-rate array). On apply: mode-nibble unpack (`cfg+136`→
`+216/220/222/212`, mode==3 special-case), per-layer reference-buffer count (flag→8/16), per-layer
tool-bits (ToolsControlFlag bits 0..5), change-detection vs current config sets a reconfig
double-buffer bit. `recon/zlt_svc_encoder.hpp` (`EncodeConfig`/`SpatialLayer`/`SetEncodeConfig`).

### 2.2 Key-picture / reference request dispatcher `[body]` — `SetKeyPictureRequest` `sub_180008370`
A **52-byte per-layer request slot** array `slot = cfg + 41644 + 52·(spatial + 5·bank)`; bounds checked
against per-codec-mode capability tables (`byte_1803F8700[mode]` spatial, `byte_1803F863C[mode+20]`
temporal). Cases (reconstructed as `RequestType` + `SvcEncoderControl::Request`):

| case | request | mechanism |
|---|---|---|
| 2  | KeyPicture      | LTR-style recovery — reference a known-good earlier frame (coalesces newest; clamps min picId) |
| 3  | NewAttendeeIPic | late joiner references most-recent sent I-frame; fall back to IDR only if needed |
| 4  | Idr             | force IDR; request-number `max`-dedup |
| 5  | DuplicateP      | redundant P (not advancing the ref chain); skipped if IDR/key already pending |
| 20 | SubscribeChange | receiver switches subscribed spatial layer → minimal key |
| 24 | FrameSkip       | drop this layer's next frame (only codec family 4/5) |
| 25/31/33 | layer-mask / run-mode switch / layered-bitrate | |

**demo** exercises Idr→ForceIdr, DuplicateP→DuplicatePFrame, FrameSkip→SkipNextFrame, and out-of-range
spatial → `SpatialOutOfRange`.

### 2.3 Perceptual / denoise `[body]`/`[rtti]`
- Adaptive-QP suite (RTTI): `zltCBackgroundAdaptQuant` / `zltCRoiAdaptQuant` /
  `zltCTextureMotionAdaptQuant` / `zltCScStaticAdaptQuant` — 6-threshold ladder → QP offset
  (`sub_1800E7680/7740`); TextureMotion (`sub_1800E7A00`) combines texture(variance)+motion(ref-diff).
- `zltCIIRDenoise` `sub_1802A5260`: EWMA `new = 0.37·in + 0.63·prev` (α=0.37).
- RAISR `zltCScreenRAISR` (ns_vpp/ns_glt/ns_gct variants): structure `[body]`, **filter-bank
  coefficients = ⛔W**. EDNet `CVideoEDNetDenoise_AOM`: ⛔W.

---

## 3. zbt.dll — AV1 codec backend

### 3.1 Wrapper `[body]`
AV1 enc/dec/create interfaces (`0x18009C820/920/CD10`); the **Screen-Content core** is selected by
`(mode & 0xF) == 2` (`CoreKindOf`); SpecialFeature ids forwarded. `recon/zbt_av1_codec.hpp`.

### 3.2 Bitstream parse `[body]` — `recon/codec/av1_bitstream.hpp`
Self-contained OBU/IVF parser: uleb128 sizes, OBU header → `ObuType`, sequence-header → profile/dims,
`ClassifyFrame` → KEY/INTER/…, IVF (`DKIF`) container. Anchored by `zbt sub_1801D0AA0` (str
`Error parsing frame header`). **demo** parses a TEMPORAL_DELIMITER OBU + an AV01 IVF header.

### 3.3 Boundary
⛔K: AV1 entropy/transform/tile coding is libaom/dav1d-derived (10⁴ routines) — verify wrapper + parse,
decode via **dav1d** (BSD) through `recon/codec/av1_dav1d_decoder.hpp` (`-DRECON_WITH_DAV1D=ON`).
**Real decode loop closed in this deliverable**: `demo/demo_av1_decode.cpp` feeds `testdata/red.obu`
(2040-byte AV1 keyframe TU) through the `recon::zbt::IAv1Decoder` backend → **800×800 NV12 frame,
Y-mean 55.4** (real pixels). The `IAv1Decoder` interface is ours (clean-room); the coding math is dav1d's.
