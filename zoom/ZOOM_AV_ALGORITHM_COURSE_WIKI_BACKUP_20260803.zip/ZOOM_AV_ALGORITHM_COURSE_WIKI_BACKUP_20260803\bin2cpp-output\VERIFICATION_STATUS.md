# Verification status — viperex.dll / zlt.dll / zbt.dll

Per-claim ledger for this bin2cpp deliverable. Legend: `✅ BODY` (read+understood from the decompiled
function body) · `✅ SYMBOL` (proven present by its exact RTTI/vftable/method symbol, not a function-body
read) · `◑ PARTIAL` (structure read, named sub-detail still inferred) · `⛔ BOUNDARY`
(`W`=trained neural weights, `K`=third-party DSP kernel). Only `✅` meets the bar.

Fresh extraction this run (skill scripts, config-driven) reproduced every function below — see
`decomp/{zbt,zlt,viperex}.json` + `decomp/zlt.rtti.json`. Runnable checks `demo/demo_three_modules.cpp`
+ `demo/demo_full_modules.cpp` + `demo/demo_av1_decode.cpp` = **ALL PASS**.

## Implementation coverage (~1200 lines recon; what is CODE vs BOUNDARY)
| Reconstructed as runnable code (✅) | Boundary — interface/injectable + reference lib |
|---|---|
| viperex: resource codec (XOR-0xA7), control surface, **chunk/CAM++/active-speaker pipeline** | CAM++/Picknet/lipsync **model weights** (⛔W) — behind `IViperexInference` |
| zlt: SVC config + key-picture dispatcher, **adaptive-QP ladder + TextureMotion + variants**, **IIR denoise (α=0.37)**, **RAISR classify+apply** | RAISR filter-bank **coefficients** (⛔W) — behind `IFilterBank`; EDNet weights (⛔W); base video-codec entropy/transform (⛔K) |
| zbt: interface/ABI, **encoder control (SC core + special-feature + rate)**, OBU/IVF parse, **real dav1d decode loop** | AV1 coding **kernel** (⛔K) — behind `IAv1Encoder`/`IAv1Decoder`, decode via dav1d (BSD) |

## viperex.dll — OpenVINO audio-extension ML engine
| Claim | Status | Anchor (EA / symbol) | Notes |
|---|---|---|---|
| `viperex_init` / `viperex_version` (="7.1.0.41345") entry | ✅ BODY | `0x1800141F0` / `0x180014230` | export entry points |
| OpenVINO load (`LoadLibrary openvino_c.dll`) + model feed | ✅ BODY | `0x180179AF0` (str `openvino_c.dll`) | control/harness only |
| **ModelResourceCodec** — models are **NOT encrypted**, only **single-byte XOR 0xA7 obfuscation** | ✅ BODY | `sub_180171020` (GetModuleHandleW `viperex.dll` → FindResourceW `embedding_model_xml_bin`/`osd_model_xml_bin`, type `BIN`) | 8-byte LE length header XOR-0xA7 splits `.xml`(topology)/`.bin`(weights); payload XOR-0xA7; no AES/CryptDecrypt/key. Decoded = standard OpenVINO IR, `core.read_model` loads it directly. **demo round-trips.** Weights themselves = ⛔W (Zoom IP) |
| **OpenVINO model-load harness** — resolves IE C-API (`ie_core_create`, **`ie_core_read_network_from_memory`**, `ie_core_get_available_devices`, `ie_core_free`), loads model from the XOR-decoded **in-memory** IR (no temp files) | ✅ BODY | `sub_180179AF0` (GetProcAddress from `openvino_c.dll`) | `recon/viperex_openvino_loader.hpp` (demo runs the resolve→create→read-from-memory sequence). OpenVINO runtime + weights = boundary |
| WorkerPriority map (1..5) / TimerConfig (`timeSetEvent` flags 0x21\|0x10) | ✅ BODY | `0x180014820`, `0x180014C60` | demo checks TimeCritical==5 |
| PipelineConstants 16000 / 24000 / 48000 / 1.5s / active>5.0 | ✅ BODY | `[AUDIO-CHUNKS]` str | demo prints them |
| CAM++ speaker embedding / Picknet(OSD) / lipsync **models** | ⛔ (W) | `[CAMPP] ExtractEmbedding`, `lipsync_model_calculator` | trained weights — harness is code, weights are not |

## zlt.dll — video SVC encode + adaptive control
| Claim | Status | Anchor | Notes |
|---|---|---|---|
| SVC `SetEncodeCfg` — **96-byte per-spatial-layer struct**, per-temporal frame-rate, mode-nibble unpack, per-layer tool bits, ref-buffer count (8/16), reconfig double-buffer | ✅ BODY | `sub_18005A690` | `recon/zlt_svc_encoder.hpp` |
| **`SetKeyPictureRequest` dispatcher** — 52-byte per-layer request slot, per-codec bounds tables, cases 2/3/4/5/20/24/25/31/33 (LTR recovery / new-attendee I-ref / IDR / dup-P / subscribe / frame-skip / mode-switch / layer-bitrate) | ✅ BODY | `sub_180008370` | **demo exercises Idr/DupP/FrameSkip + bounds** |
| Perceptual adaptive-QP: 6-threshold ladder + TextureMotion (2 metrics) | ✅ BODY | `sub_1800E7680/7740/7A00` | `zltCBackgroundAdaptQuant`/`zltCTextureMotionAdaptQuant` (RTTI confirmed) |
| IIR temporal denoise EWMA `new = 0.37·in + 0.63·prev` (α=0.37) | ✅ BODY | `sub_1802A5260` | `zltCIIRDenoise` (RTTI confirmed) |
| RAISR super-res (CPU/GPU/Screen variants) | ✅ BODY (structure) / ⛔ (W) | `zltCScreenRAISR` (RTTI confirmed) | **filter-bank coefficients = trained data** |
| SetEncodeCfg apply state-machine (nibble unpack + mode==3 + ref-buffer 8/16 + tool bits + reconfig bank) | ✅ BODY | `sub_18005A690` | `recon/zlt_encode_config.hpp` |
| Rate/temporal: **dyadic temporal frame-rate split** (×0.5 cascade) + Q10 bitrate factor (raw·2⁻¹⁰) | ✅ BODY | `sub_180062730` (lines ~402-419) | `recon/zlt_rate_control.hpp` ([partial]: full 16 KB per-layer bitrate/QP allocation only partly read) |
| **Real H.264 encode loop** (option A: control → real encoder → pixels→H.264) | ✅ RUNNABLE (T1) | `recon/zlt_h264_backend.hpp` + `demo/demo_zlt_encode.cpp` (minih264) | reconstructed `SvcEncoderControl`/`ISvcEncoderBackend` drives a real encoder: **frame0 SPS+PPS+IDR (3316 B), P-frames → 3725 B H.264**. Engine = reference codec (⛔K) |
| **video-codec engine** (entropy/transform/ME/RDO/deblock + SIMD) — ~96% of the DLL | ⛔ BOUNDARY (K) | — | standard-codec algorithms + hand SIMD; not zlt-unique source (see `ZLT_FUNCTION_MAP.md`) |
| EDNet neural denoise | ⛔ (W) | `CVideoEDNetDenoise_AOM` | weights |

## zbt.dll — AV1 codec backend
| Claim | Status | Anchor | Notes |
|---|---|---|---|
| AV1 enc/dec/create interface + Screen-Content core `(mode&0xF)==2` + SpecialFeature ids | ✅ BODY | `0x18009C820/920/CD10` | `recon/zbt_av1_codec.hpp` |
| OBU seq/frame-header parse + classify | ✅ BODY | `0x1801D0AA0` (str `Error parsing frame header`) | `recon/codec/av1_bitstream.hpp` — **demo parses OBU + IVF** |
| **AV1 real decode loop** (interface → pixels) | ✅ RUNNABLE (T1) | `recon/codec/av1_dav1d_decoder.hpp` + `demo/demo_av1_decode.cpp` | **`testdata/red.obu` → 800×800 NV12, Y-mean 55.4** — the `recon::zbt::IAv1Decoder` interface drives a real decode via dav1d |
| AV1 entropy/transform/tile **DSP kernel** | ⛔ (K) | — | libaom/dav1d-derived coding math; we reconstruct the wrapper + bitstream parse, decode through dav1d (BSD) |

## viper.dll — audio weak-network engine ([map](VIPER_FUNCTION_MAP.md); ~24% control = biggest surface)
| Claim | Status | Anchor | Where |
|---|---|---|---|
| AI-codec(121) enable gate — main∈{113,116}, key `(rate<<16)\|ch`, error map −301..−308 | ✅ BODY | `sub_1800CE540` | `recon/viper_codec_control.hpp` |
| Control word — 10-bit, **bit 0x4** = extra AI/SNAC enc, change → event 44 | ✅ BODY | `sub_1800594C0` | same |
| SNAC decode **state machine** — atomic 0=kDisable/1=kReady, register/deregister, bit 0x4 recv-side | ✅ BODY | `sub_1800C39E0` | same |
| SNAC-TCP → Opus fallback thresholds — outage ≥2000ms, ts-range ≥2500, loss ≤0.5/0.2 | ✅ BODY | `sub_1800D1BE0/D2A60` | same |
| **SNAC 3-level hierarchy** — `webrtc::SnacEncoder/Decoder` → `ISnacInferenceEncoder/Decoder` → `SnacInferenceEncoderAVX/DecoderAVX` (95 snac syms) | ✅ SYMBOL | RTTI/vftable in `viper.dll.i64` | AVX classes = inference kernel (⛔K+⛔W); `VIPER_FUNCTION_MAP.md` |
| **Speaker embedding** — `webrtc::OpenMicSpeakerEmbController` / `ISpeakerEmbController` / `ISpeakerEmbNotify` (20 syms) | ✅ SYMBOL | RTTI + vftable | viperex hook confirmed |
| **`webrtc::IndepEncoderGroupImpl::CreateIndepEncoder(IndepEncoderParam,…)`** (2 syms) | ✅ SYMBOL | method signature | independent-encoder group |
| Customized Opus — 37 opus-named syms, **mostly config/log strings** (`check_opus_loss_rate`, `opus_lowlatency`, `opus_max_sn`…) | ✅ SYMBOL / ◑ | string refs | proves Opus customized (SN bounds, loss gate, low-latency); codec DSP still `⛔K` |
| Opus decode loop | ✅ RUNNABLE | libopus | `demo_opus` (parent) |
| Opus/SNAC/DRED **DSP** | ⛔ (K)/(W) | libopus fork · SNAC/DRED weights | boundary |

## nydus.dll — app-share media engine + video wall renderer ([map](NYDUS_FUNCTION_MAP.md))
| Claim | Status | Anchor | Where |
|---|---|---|---|
| Reed–Solomon share FEC — GF(2⁸) poly **0x11D**, systematic Cauchy + Gauss erasure | ✅ RUNNABLE | `sub_180005C44/5F34` | `recon/algo/rs_fec.hpp` (demo: K=6+R=3, erase 3 → recover; K-1 → refuse) |
| FEC grouping / shared keyed-mutex texture / Present-hook | ✅ BODY | `FecRtpPacketGroup`, `CD3d11SharedHandleHelper`, `SafePresent` | `recon/nydus_as_engine.hpp` + parent docs |
| Video wall-renderer GPU path (I420→tex upload, YUV→RGB shader) | ⛔ static-RE floor | `CWallRenderer` (COM vtbl + compiled shader) | needs dynamic capture (RenderDoc/PIX) |

## Boundaries (by nature)
- **(W) weights**: CAM++/Picknet/lipsync (viperex), RAISR filter-banks + EDNet (zlt). Body-level applies
  only to the inference harness/apply-path; the learned function is float data, not code.
- **(K) kernel**: AV1 coding routines (zbt) — verify the wrapper + bitstream parse, decode via dav1d.
