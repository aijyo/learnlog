#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
struct Obu{int type,temporal,spatial;size_t size,offset;};
uint64_t uleb(const std::vector<uint8_t>&b,size_t&p){uint64_t v=0;for(int s=0;s<=56;s+=7){if(p>=b.size())throw std::runtime_error("truncated uleb128");uint8_t x=b[p++];v|=uint64_t(x&127)<<s;if(!(x&128))return v;}throw std::runtime_error("uleb128 overflow");}
std::vector<Obu> parse(const std::vector<uint8_t>&b,size_t p=0,size_t end=0){if(!end)end=b.size();std::vector<Obu>o;while(p<end){size_t at=p;uint8_t h=b[p++];if(h&0x80)throw std::runtime_error("forbidden bit");int type=(h>>3)&15,tid=0,sid=0;if(h&4){if(p>=end)throw std::runtime_error("missing extension");uint8_t e=b[p++];tid=(e>>5)&7;sid=(e>>3)&3;}if(!(h&2))throw std::runtime_error("OBU without size field");auto n=uleb(b,p);if(n>end-p)throw std::runtime_error("payload overrun");o.push_back({type,tid,sid,size_t(n),at});p+=size_t(n);}return o;}
uint32_t le32(const std::vector<uint8_t>&b,size_t p){return uint32_t(b[p])|uint32_t(b[p+1])<<8|uint32_t(b[p+2])<<16|uint32_t(b[p+3])<<24;}
int main(int ac,char**av){std::vector<uint8_t>b;if(ac>1){std::ifstream f(av[1],std::ios::binary);b.assign(std::istreambuf_iterator<char>(f),{});}else b={0x12,0x00,0x0a,0x02,0x11,0x22};
 try{size_t p=0,end=b.size();if(b.size()>=32&&std::equal(b.begin(),b.begin()+4,"DKIF")){std::cout<<"IVF "<<le32(b,12)<<"x"<<le32(b,16)<<"\n";p=32;if(p+12>b.size())throw std::runtime_error("missing IVF frame");uint32_t n=le32(b,p);p+=12;end=std::min(b.size(),p+n);}for(auto&o:parse(b,p,end))std::cout<<"offset="<<o.offset<<" type="<<o.type<<" tid="<<o.temporal<<" sid="<<o.spatial<<" bytes="<<o.size<<"\n";}
 catch(const std::exception&e){std::cerr<<"malformed: "<<e.what()<<"\n";return 2;}}
