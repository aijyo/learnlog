# AV1 IVF / OBU bitstream inspector

Python 方便检查 OBU 时间线与错误注入；C++ 实现 IVF 帧边界、OBU header、extension、ULEB128 和越界校验。

- `[BODY]`：解析路径、OBU type、temporal/spatial id、size field 和错误边界。
- `BOUNDARY`：像素解码交给 dav1d；DXVA/D3D11 输出属于系统适配层。未安装 dav1d 时，本 demo 不声称完成像素解码。

无输入时使用最小合成 OBU；也可传入 IVF/OBU 文件。证据：`codec/av1_bitstream.hpp`、`codec/av1_dav1d_decoder.hpp`、`zbt_av1_codec.hpp`。
