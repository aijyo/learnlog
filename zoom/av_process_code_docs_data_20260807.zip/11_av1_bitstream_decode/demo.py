#!/usr/bin/env python3
from pathlib import Path
import argparse,struct
from PIL import Image,ImageDraw
def uleb(b,p):
 v=s=0
 while s<=56:
  if p>=len(b):raise ValueError('truncated uleb128')
  x=b[p];p+=1;v|=(x&127)<<s
  if not x&128:return v,p
  s+=7
 raise ValueError('uleb128 overflow')
def parse(b,p=0,end=None):
 end=len(b) if end is None else end;out=[]
 while p<end:
  at=p;h=b[p];p+=1
  if h&128:raise ValueError('forbidden bit')
  typ=(h>>3)&15;tid=sid=0
  if h&4:e=b[p];p+=1;tid=(e>>5)&7;sid=(e>>3)&3
  if not h&2:raise ValueError('missing size field')
  n,p=uleb(b,p)
  if p+n>end:raise ValueError('payload overrun')
  out.append((at,typ,tid,sid,n));p+=n
 return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('input',nargs='?',type=Path);ap.add_argument('--out',type=Path,default=Path('output'));a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 b=a.input.read_bytes() if a.input else bytes([0x12,0,0x0a,2,0x11,0x22]);p=0;end=len(b);title='raw OBU'
 if b[:4]==b'DKIF':w,h=struct.unpack_from('<HH',b,12);n=struct.unpack_from('<I',b,32)[0];p=44;end=p+n;title=f'IVF {w}x{h}'
 rows=parse(b,p,end);im=Image.new('RGB',(920,160+70*len(rows)),'white');d=ImageDraw.Draw(im);d.text((30,20),title,fill='black')
 colors=['#4f86c6','#e07a5f','#81b29a','#f2cc8f']
 for i,(off,t,tid,sid,n) in enumerate(rows):y=70+i*70;d.rectangle((40,y,40+max(30,n*20),y+38),fill=colors[i%4]);d.text((50,y+10),f'OBU type={t} tid={tid} sid={sid} payload={n} offset={off}',fill='black')
 im.save(a.out/'av1_obu_timeline.png')
 try:parse(bytes([0x12,5,1]))
 except ValueError as e:print('malformed path:',e)
 print(rows,a.out.resolve())
if __name__=='__main__':main()
