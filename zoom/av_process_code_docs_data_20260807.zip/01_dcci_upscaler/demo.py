#!/usr/bin/env python3
"""
DCCI 2x 边缘定向插值超分 RGB 全彩色肖像 Demo (Directional Cubic Convolution Interpolation Full-Color RGB Demo)

本脚本使用 24-bit RGB 全彩色人物肖像图片 (Full-Color Portrait Image)：
1. 下载/加载 24-bit RGB 全彩色人物肖像图 (保留帽子、发丝、皮肤与背景丰富色彩)；
2. 降采样至 128x128 低分辨率模拟低清晰度彩色画面；
3. 对 R, G, B 3 通道应用 DCCI 2x 边缘定向放大到 256x256，展示人像边缘与细节平滑度；
4. 导出与传统双线性插值 (Bilinear 2x) 的全彩色 PNG 人像对比效果图 `dcci_comparison.png`。

用法:
    python demo.py
"""

import numpy as np
from PIL import Image
import urllib.request
import os

PORTRAIT_URLS = [
    "https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg",
    "https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg"
]

def cubic(n1, n2, f1, f2):
    """[-1, 9, 9, -1]/16 4-tap 双三次卷积内核"""
    v = (9.0 * (n1 + n2) - f1 - f2) / 16.0
    return np.clip(v, 0, 255)

def dcci_upscale_channel_2x(src: np.ndarray) -> np.ndarray:
    """对单通道应用 DCCI 2x 超分"""
    h, w = src.shape
    ow, oh = w * 2, h * 2
    dst = np.zeros((oh, ow), dtype=np.float32)

    dst[0::2, 0::2] = src.astype(np.float32)

    for y in range(h):
        for x in range(w):
            p = np.zeros((4, 4), dtype=np.float32)
            for j in range(4):
                for i in range(4):
                    py = np.clip(y - 1 + j, 0, h - 1)
                    px = np.clip(x - 1 + i, 0, w - 1)
                    p[j, i] = src[py, px]

            G1 = (abs(p[0,0]-p[1,1]) + abs(p[1,1]-p[2,2]) + abs(p[2,2]-p[3,3]) +
                  abs(p[0,1]-p[1,2]) + abs(p[1,2]-p[2,3]) + abs(p[1,0]-p[2,1]) + abs(p[2,1]-p[3,2]))
            G2 = (abs(p[0,3]-p[1,2]) + abs(p[1,2]-p[2,1]) + abs(p[2,1]-p[3,0]) +
                  abs(p[0,2]-p[1,1]) + abs(p[1,1]-p[2,0]) + abs(p[1,3]-p[2,2]) + abs(p[2,2]-p[3,1]))

            a, b, c, d = p[1,1], p[2,2], p[0,0], p[3,3]
            e, f, g, hh = p[1,2], p[2,1], p[0,3], p[3,0]

            if 100 * G1 <= 115 * G2:
                if 100 * G2 <= 115 * G1:
                    v = (a + b + e + f) / 4.0
                else:
                    v = cubic(a, b, c, d)
            else:
                v = cubic(e, f, g, hh)
            dst[2*y+1, 2*x+1] = v

    for y in range(oh):
        startx = 0 if (y & 1) else 1
        for x in range(startx, ow, 2):
            L = dst[y, np.clip(x-1, 0, ow-1)]
            R = dst[y, np.clip(x+1, 0, ow-1)]
            U = dst[np.clip(y-1, 0, oh-1), x]
            Dn = dst[np.clip(y+1, 0, oh-1), x]

            L2 = dst[y, np.clip(x-3, 0, ow-1)]
            R2 = dst[y, np.clip(x+3, 0, ow-1)]
            U2 = dst[np.clip(y-3, 0, oh-1), x]
            D2 = dst[np.clip(y+3, 0, oh-1), x]

            Gh = abs(L - R) + abs(L2 - L) + abs(R - R2)
            Gv = abs(U - Dn) + abs(U2 - U) + abs(Dn - D2)

            if 800 * (Gv + 5) <= 575 * (Gh + 8):
                v = cubic(U, Dn, U2, D2)
            elif 800 * (Gh + 5) <= 575 * (Gv + 8):
                v = cubic(L, R, L2, R2)
            else:
                v = (L + R + U + Dn) / 4.0
            dst[y, x] = v

    return np.clip(dst, 0, 255).astype(np.uint8)

def dcci_upscale_rgb_2x(src_rgb: np.ndarray) -> np.ndarray:
    """对 RGB 3 通道依次应用 DCCI 2x 超分"""
    h, w, c = src_rgb.shape
    out = np.zeros((h * 2, w * 2, 3), dtype=np.uint8)
    for ch in range(3):
        out[:, :, ch] = dcci_upscale_channel_2x(src_rgb[:, :, ch])
    return out

def get_real_color_portrait(width=128, height=128):
    """获取 24-bit RGB 全彩色人物肖像测试原图"""
    local_path = "portrait_color_base.jpg"
    if not os.path.exists(local_path):
        print("   正在从开源测试样本库下载 RGB 全彩色人物肖像图片...")
        for url in PORTRAIT_URLS:
            try:
                urllib.request.urlretrieve(url, local_path)
                print("   ✔ 成功下载 RGB 全彩色人物肖像图！")
                break
            except Exception as e:
                print(f"   下载失败 ({e})，尝试下一个镜像...")

    if os.path.exists(local_path):
        img = Image.open(local_path).convert('RGB')
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        return np.array(img, dtype=np.uint8)
    else:
        print("   使用本地生成的彩色测试图...")
        arr = np.zeros((height, width, 3), dtype=np.uint8)
        arr[:, :, 0] = 180; arr[:, :, 1] = 120; arr[:, :, 2] = 80
        return arr

if __name__ == '__main__':
    print("==========================================================")
    print("  DCCI 2x Edge-Directed Upscaler - RGB 全彩色肖像 Demo")
    print("==========================================================")

    print("\n1. 正在获取 RGB 24-bit 全彩色人物肖像测试低分辨率原图 (128x128)...")
    src_img = get_real_color_portrait(128, 128)
    Image.fromarray(src_img).save("dcci_input_128x128.png")

    print("2. 正在运行 DCCI 2x 边缘定向插值超分放大人像到 256x256...")
    dcci_out = dcci_upscale_rgb_2x(src_img)
    Image.fromarray(dcci_out).save("dcci_output_256x256.png")

    print("3. 正在生成传统双线性插值 (Bilinear 2x) 彩色人像作为对比...")
    bilinear_pil = Image.fromarray(src_img).resize((256, 256), resample=Image.BILINEAR)
    bilinear_out = np.array(bilinear_pil, dtype=np.uint8)
    bilinear_pil.save("bilinear_output_256x256.png")

    # 导出彩色人像轮廓/五官/发丝处的差异放大热力图 (|DCCI - Bilinear| * 4)
    diff_map = np.clip(np.abs(dcci_out.astype(np.int16) - bilinear_out.astype(np.int16)) * 4, 0, 255).astype(np.uint8)
    Image.fromarray(diff_map).save("dcci_vs_bilinear_diff.png")

    # 4. 拼接导出 1024x256 的 24-bit 全彩色人像对比大图 `dcci_comparison.png`
    comparison_img = Image.new('RGB', (256 * 4, 256))
    
    src_padded = Image.new('RGB', (256, 256), color=(20, 20, 20))
    src_padded.paste(Image.fromarray(src_img), (64, 64))
    
    comparison_img.paste(src_padded, (0, 0))
    comparison_img.paste(bilinear_pil, (256, 0))
    comparison_img.paste(Image.fromarray(dcci_out), (512, 0))
    comparison_img.paste(Image.fromarray(diff_map), (768, 0))

    comparison_img.save("dcci_comparison.png")

    print("\n运行成功！生成的 RGB 全彩色人物肖像对比图片列表:")
    print("  └─ dcci_input_128x128.png        : 128x128 原始低分辨率 RGB 全彩人物肖像图")
    print("  └─ bilinear_output_256x256.png   : 双线性 2x 彩色放大图 (人脸边缘与发丝模糊发虚)")
    print("  └─ dcci_output_256x256.png       : DCCI 2x 边缘定向超分图 (彩色人像五官与轮廓保持锐利)")
    print("  └─ dcci_vs_bilinear_diff.png     : 彩色差异热力图 (高亮区即为被 DCCI 纠正的边缘)")
    print("  └─ dcci_comparison.png           : 4 并排 1024x256 RGB 全彩色人像对比大图")
