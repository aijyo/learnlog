# 01_dcci_upscaler — 边缘定向 2x 插值超分独立项目

> 证据校准：`[BODY]` 覆盖 DCCI 四方向梯度选择与方向插值主体；残余 9-tap 窗口和边界舍入仅为 `[PARTIAL]`，不应解读为逐位复刻。

本目录为一个**完全自包含 (Standalone)** 的独立小项目，展示实时音视频管线中用于图像 2x 快速放大的 **Directional Cubic Convolution Interpolation (DCCI)** 边缘定向插值算法。

---

## 目录结构

```
01_dcci_upscaler/
├── CMakeLists.txt         # 独立 CMake 构建脚本
├── include/
│   └── dcci_upscaler.hpp  # 自包含 C++ 算法头文件 (零依赖)
├── main.cpp               # C++ 默认独立调用示例
└── demo.py                # Python 效果展示与算法演示
```

---

## 编译与运行方式

### 1. Python 示例运行

直接运行 Python 算法脚本（只需安装 NumPy）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\dcci_upscaler_demo.exe

# Linux/macOS 运行:
./build/dcci_upscaler_demo
```

---

## 算法技术关键点

1. **梯度比率决策**: 计算 135° 与 45° 方向的 7-tap 梯度 $G_1, G_2$。当 $100 \cdot G_1 \le 115 \cdot G_2$ 时判定为沿 45° 存在边缘，沿 135° 平滑方向进行插值。
2. **四抽头双三次内核**: 沿边缘平滑方向应用 $[-1, 9, 9, -1] / 16$ 4-tap 双三次卷积 Kernel。
3. **二阶段轴向决策**: 采用 $575/800$ 与 $920/500$ 正则化比例评估水平与垂直梯度，消除边缘锯齿。
