#pragma once
/**
 * @file dcci_upscaler.hpp
 * @brief 自包含的 Directional Cubic Convolution Interpolation (DCCI 2x) 超分算法
 * 
 * 完全独立，不依赖任何第三方库，仅依赖标准 C++17 库。
 */

#include <vector>
#include <cstdint>
#include <cstdlib>

namespace standalone::dcci {

inline uint8_t clampb(int v) { 
    return (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v)); 
}

// [-1, 9, 9, -1] / 16 4-tap 双三次卷积内核
inline int cubic(int n1, int n2, int f1, int f2) { 
    return (9 * (n1 + n2) - f1 - f2) >> 4; 
}

/**
 * @brief 对单通道 Luma 图像进行边缘定向 2x 放大
 * @param src 原始图像数据 (w x h)
 * @param w 原始宽度
 * @param h 原始高度
 * @param dst [out] 放大后的图像数据 (2w x 2h)
 * @param ow [out] 目标宽度
 * @param oh [out] 目标高度
 */
inline void Upscale2x(const uint8_t* src, int w, int h, std::vector<uint8_t>& dst, int& ow, int& oh) {
    ow = w * 2; 
    oh = h * 2;
    if (w < 2 || h < 2) { 
        dst.assign((size_t)ow * oh, 0); 
        return; 
    }
    dst.assign((size_t)ow * oh, 0);

    auto S = [&](int x, int y) {
        x = x < 0 ? 0 : (x >= w ? w - 1 : x);
        y = y < 0 ? 0 : (y >= h ? h - 1 : y);
        return (int)src[(size_t)y * w + x];
    };
    const int OW = ow;
    auto D = [&](int x, int y) -> uint8_t& { return dst[(size_t)y * OW + x]; };

    // 1) 已知的 LR 像素落于偶数采样网格 (2x, 2y)
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            D(2 * x, 2 * y) = src[(size_t)y * w + x];
        }
    }

    // 2) 对角半像素点 (2x+1, 2y+1): 结合 135° 与 45° 梯度进行方向选择
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            int p[4][4];
            for (int j = 0; j < 4; ++j) {
                for (int i = 0; i < 4; ++i) {
                    p[j][i] = S(x - 1 + i, y - 1 + j);
                }
            }
            
            // G1 = 135° (\) 梯度, G2 = 45° (/) 梯度
            int G1 = std::abs(p[0][0]-p[1][1]) + std::abs(p[1][1]-p[2][2]) + std::abs(p[2][2]-p[3][3])
                   + std::abs(p[0][1]-p[1][2]) + std::abs(p[1][2]-p[2][3])
                   + std::abs(p[1][0]-p[2][1]) + std::abs(p[2][1]-p[3][2]);
                   
            int G2 = std::abs(p[0][3]-p[1][2]) + std::abs(p[1][2]-p[2][1]) + std::abs(p[2][1]-p[3][0])
                   + std::abs(p[0][2]-p[1][1]) + std::abs(p[1][1]-p[2][0])
                   + std::abs(p[1][3]-p[2][2]) + std::abs(p[2][2]-p[3][1]);

            const int a = p[1][1], b = p[2][2], c = p[0][0], d = p[3][3];
            const int e = p[1][2], f = p[2][1], g = p[0][3], hh = p[3][0];
            int v;
            
            if (100 * G1 <= 115 * G2) { // 100 * G1 <= 115 * G2，说明 135° 方向梯度小（平滑）
                if (100 * G2 <= 115 * G1) {
                    v = (a + b + e + f + 2) >> 2; // 梯度接近，各向同性 4 邻域均值
                } else {
                    v = cubic(a, b, c, d);          // 沿 135° 插值
                }
            } else {
                v = cubic(e, f, g, hh);             // 沿 45° 插值
            }
            D(2 * x + 1, 2 * y + 1) = clampb(v);
        }
    }

    // 3) 轴向半像素点 (2x+1, 2y) 与 (2x, 2y+1)
    auto axis = [&](int hx, int hy) {
        int L = D(hx - 1, hy), R = D(hx + 1, hy), U = D(hx, hy - 1), Dn = D(hx, hy + 1);
        int L2 = (hx - 3 >= 0) ? (int)D(hx - 3, hy) : L, R2 = (hx + 3 < ow) ? (int)D(hx + 3, hy) : R;
        int U2 = (hy - 3 >= 0) ? (int)D(hx, hy - 3) : U, D2 = (hy + 3 < oh) ? (int)D(hx, hy + 3) : Dn;
        
        int Gh = std::abs(L - R) + std::abs(L2 - L) + std::abs(R - R2);
        int Gv = std::abs(U - Dn) + std::abs(U2 - U) + std::abs(Dn - D2);
        int v;
        
        if (800 * (Gv + 5) <= 575 * (Gh + 8)) {
            v = cubic(U, Dn, U2, D2);
        } else if (800 * (Gh + 5) <= 575 * (Gv + 8)) {
            v = cubic(L, R, L2, R2);
        } else {
            v = (L + R + U + Dn + 2) >> 2;
        }
        D(hx, hy) = clampb(v);
    };

    for (int y = 0; y < oh; ++y) {
        int startx = (y & 1) ? 0 : 1;
        for (int x = startx; x < ow; x += 2) {
            axis(x, y);
        }
    }
}

} // namespace standalone::dcci
