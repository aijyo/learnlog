#include "dcci_upscaler.hpp"
#include <iostream>
#include <vector>
#include <iomanip>

int main() {
    std::cout << "==========================================" << std::endl;
    std::cout << "  DCCI 2x Edge-Directed Upscaler (C++ Demo)" << std::endl;
    std::cout << "==========================================" << std::endl;

    int w = 8, h = 8;
    std::vector<uint8_t> src(w * h, 0);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            if (x == y || x == y + 1) {
                src[y * w + x] = 255;
            }
        }
    }

    std::cout << "\n[原始图像数据 (8x8)]:" << std::endl;
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            std::cout << std::setw(4) << (int)src[y * w + x];
        }
        std::cout << "\n";
    }

    std::vector<uint8_t> dst;
    int ow = 0, oh = 0;
    standalone::dcci::Upscale2x(src.data(), w, h, dst, ow, oh);

    std::cout << "\n[DCCI 2x 放大后图像数据 (" << ow << "x" << oh << ")]:" << std::endl;
    for (int y = 0; y < oh; ++y) {
        for (int x = 0; x < ow; ++x) {
            std::cout << std::setw(4) << (int)dst[y * ow + x];
        }
        std::cout << "\n";
    }

    std::cout << "\n成功完成 DCCI 2x 边缘定向放大！" << std::endl;
    return 0;
}
