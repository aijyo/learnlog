#include "content_analysis.hpp"
#include <cstdint>
#include <iostream>
#include <vector>

int main() {
    using namespace standalone::content_analysis;
    constexpr int w = 1280, h = 720;
    std::vector<uint8_t> prev(size_t(w) * h, 228), cur = prev;
    for (int y = 40; y < h; y += 32) for (int x = 30; x < w - 30; ++x)
        prev[size_t(y) * w + x] = cur[size_t(y) * w + x] = uint8_t(40 + x % 30);
    for (int y = 288; y < 608; ++y) for (int x = 736; x < 1152; ++x)
        cur[size_t(y) * w + x] = uint8_t((x * 7 + y * 13) & 255);

    AnalysisConfig cfg;
    auto region = DetectVideoRegion(cur.data(), prev.data(), w, h, cfg);
    std::cout << "Video-in-Share projection demo\n"
              << "  block=16, column threshold=5, row threshold=10, gap tolerance<8\n"
              << "  confirm: box>256x256, moving>=30, moving/total>=1/12\n"
              << "  result=" << (region.found ? "FOUND" : "NOT FOUND")
              << " box=(" << region.x << ',' << region.y << ',' << region.w << ',' << region.h << ")\n"
              << "Boundary: motion metric and exact global-motion axis math are stand-ins.\n";
    return region.found ? 0 : 2;
}

