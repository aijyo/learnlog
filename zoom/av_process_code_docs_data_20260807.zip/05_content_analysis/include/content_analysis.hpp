#pragma once
/**
 * @file content_analysis.hpp
 * @brief Video-in-Share 运动区域投影与确认；四类语义图仅为教学 stand-in
 * 
 * 零外部依赖，仅包含 C++ 标准库 <cstdint>, <vector>, <cmath>, <algorithm>, <cstddef>.
 */

#include <cstdint>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstddef>

namespace standalone::content_analysis {

/**
 * @brief 4 大内容分类标签 (Content Type Labels)
 */
enum ContentLabel : uint8_t {
    LABEL_SCREEN_STATIC  = 0, // 静态屏幕/代码/文档文字区 (Screen Static, 保护文本清晰度)
    LABEL_BACKGROUND     = 1, // 平坦背景墙/渐变区 (Background, 可提 QP 节省码率)
    LABEL_ROI_FACE_TEXT  = 2, // 人脸/焦点活动文字/光标区 (ROI, 优先保证画质与码率)
    LABEL_VIDEO_SHARE    = 7  // 动态画中画视频播放区 (Video-in-Share, 高帧率平滑)
};

/**
 * @brief 屏幕内容分析配置参数
 */
struct AnalysisConfig {
    int block            = 16;   // 16x16 宏块网格
    int min_region_px    = 256;  // 视频区域最小长宽 (256x256)
    int move_sad_thresh  = 5;    // 运动 SAD 门限
    int flat_var_thresh  = 12;   // 平坦背景方差门限
    int frame_edge_guard = 64;   // [PARTIAL] 全局运动防护边距
};

/**
 * @brief 识别出的画中画视频区域
 */
struct VideoRegion {
    bool found = false;
    int x = 0;
    int y = 0;
    int w = 0;
    int h = 0;
};

/**
 * @brief 1. 静态屏幕与文档检测器 (StaticDetection)
 * 根据活动度 Activity Sum 与 3072 * block_cols 动态参考值判定是否整体为 Screen Static
 */
struct StaticDetection {
    static constexpr int kRefPerCol = 3072; // 参考门限: 3072 * block_cols

    static bool IsStatic(const uint8_t* cur, const uint8_t* prev, int w, int h, int block = 16) {
        int bw = (w + block - 1) / block;
        int bh = (h + block - 1) / block;
        if (bw * bh <= 15 || !prev || !cur) return false;

        long activity = 0;
        for (int by = 0; by < bh; ++by) {
            for (int bx = 0; bx < bw; ++bx) {
                long sad = 0;
                for (int j = 0; j < block; ++j) {
                    int yy = by * block + j;
                    if (yy >= h) break;
                    for (int i = 0; i < block; ++i) {
                        int xx = bx * block + i;
                        if (xx >= w) break;
                        size_t off = (size_t)yy * w + xx;
                        int diff = (int)cur[off] - (int)prev[off];
                        sad += (diff < 0) ? -diff : diff;
                    }
                }
                activity += sad;
            }
        }
        long ref = (long)kRefPerCol * bw;
        return activity < ref; // 低于参考门限即判定为全屏 Screen Static
    }
};

/**
 * @brief 2. 全图 16x16 宏块 4 色语义内容特征 Map 生成器
 */
inline void AnalyzeFullContentMap(const uint8_t* cur, const uint8_t* prev, int w, int h,
                                  int block, int bw, int bh,
                                  std::vector<uint8_t>& label_map,
                                  const AnalysisConfig& cfg = {}) {
    label_map.assign((size_t)bw * bh, LABEL_SCREEN_STATIC);
    if (!cur) return;

    for (int by = 0; by < bh; ++by) {
        for (int bx = 0; bx < bw; ++bx) {
            long sum = 0, sum2 = 0, sad = 0;
            int n = 0;

            for (int j = 0; j < block; ++j) {
                int yy = by * block + j;
                if (yy >= h) break;
                for (int i = 0; i < block; ++i) {
                    int xx = bx * block + i;
                    if (xx >= w) break;
                    size_t off = (size_t)yy * w + xx;
                    uint8_t val = cur[off];
                    sum += val;
                    sum2 += (long)val * val;
                    if (prev) {
                        int diff = (int)val - (int)prev[off];
                        sad += (diff < 0) ? -diff : diff;
                    }
                    n++;
                }
            }

            if (!n) continue;
            long mean = sum / n;
            long var = (sum2 / n) - mean * mean;
            int avg_sad = n ? (int)(sad / n) : 0;

            size_t idx = (size_t)by * bw + bx;

            if (avg_sad >= cfg.move_sad_thresh) {
                label_map[idx] = LABEL_VIDEO_SHARE; // 动态视频/大运动区
            } else if (var < cfg.flat_var_thresh) {
                label_map[idx] = LABEL_BACKGROUND;  // 平坦背景区
            } else if (var > 800) {
                label_map[idx] = LABEL_ROI_FACE_TEXT; // 高频文字/人脸边缘 ROI 关注区
            } else {
                label_map[idx] = LABEL_SCREEN_STATIC; // 静态文本/文档区
            }
        }
    }
}

/**
 * @brief 3. 带状投影扫描 (ScanBandEdge)
 */
inline int ScanBandEdge(const std::vector<int>& hist, int hi_thresh, bool fwd, int limit) {
    int highs = 0, gap = 0, edge = fwd ? (limit - 1) : 0, start = -1;
    for (int k = 0; k < limit; ++k) {
        int idx = fwd ? k : (limit - 1 - k);
        if (hist[idx] >= hi_thresh) {
            if (start < 0) start = idx;
            gap = 0;
            if (++highs >= 5) break; // [BODY] sustained band needs about five high bins
        } else if (start >= 0) {
            if (++gap >= 8) {
                start = -1;
                highs = 0;
                gap = 0;
            }
        }
    }
    return start >= 0 ? start : edge;
}

/**
 * @brief 4. 画中画视频 Bounding Box 定位
 */
inline VideoRegion DetectVideoRegion(const uint8_t* cur, const uint8_t* prev, int w, int h,
                                     const AnalysisConfig& cfg = {}) {
    VideoRegion none;
    if (w < 64 || h < 64 || !prev || !cur) return none;

    const int block = cfg.block;
    const int bw = (w + block - 1) / block;
    const int bh = (h + block - 1) / block;

    std::vector<uint8_t> labels;
    AnalyzeFullContentMap(cur, prev, w, h, block, bw, bh, labels, cfg);

    std::vector<int> col(bw, 0), row(bh, 0);
    for (int by = 0; by < bh; ++by) {
        for (int bx = 0; bx < bw; ++bx) {
            if (labels[(size_t)by * bw + bx] == LABEL_VIDEO_SHARE) {
                col[bx]++;
                row[by]++;
            }
        }
    }

    // [BODY] asymmetric projection thresholds: columns >=5 moving blocks, rows >=10.
    int left   = ScanBandEdge(col, 5, true,  bw);
    int right  = ScanBandEdge(col, 5, false, bw);
    int top    = ScanBandEdge(row, 10, true,  bh);
    int bottom = ScanBandEdge(row, 10, false, bh);

    if (right < left) std::swap(left, right);
    if (bottom < top) std::swap(top, bottom);

    VideoRegion r;
    r.x = block * left;
    r.y = block * top;
    r.w = std::max(block, block * (right - left + 1));
    r.h = std::max(block, block * (bottom - top + 1));

    int moving = 0, total = 0;
    for (int by = top; by <= bottom; ++by) for (int bx = left; bx <= right; ++bx) {
        if (by < 0 || bx < 0 || by >= bh || bx >= bw) continue;
        ++total;
        moving += labels[(size_t)by * bw + bx] == LABEL_VIDEO_SHARE;
    }
    // [PARTIAL] whole-frame-motion guard: exact axis math remains only structure-level;
    // reject a candidate touching almost the entire frame so camera pans are not PIP.
    const bool global_motion = r.w >= w - 2 * cfg.frame_edge_guard && r.h >= h - 2 * cfg.frame_edge_guard;
    // [BODY] box >256x256; moving >=30; 12*moving >= total (8.33%).
    if (!global_motion && r.w > cfg.min_region_px && r.h > cfg.min_region_px &&
        moving >= 30 && 12 * moving >= total) {
        r.found = true;
        return r;
    }
    return none;
}

} // namespace standalone::content_analysis
