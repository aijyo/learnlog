#!/usr/bin/env python3
"""Video-in-Share label-7 projection demo using an open-source video."""
from pathlib import Path
import argparse
import cv2
import numpy as np

DEFAULT_VIDEO = Path(r"D:\code\work\research\ai-harness\data\videos\dance_outdoor.mp4")
B = 16

def compose(raw, box=(768, 320, 384, 288)):
    x, y, w, h = box
    out = np.full((720, 1280, 3), (224, 220, 214), np.uint8)
    cv2.rectangle(out, (20, 20), (720, 680), (28, 24, 20), -1)
    cv2.rectangle(out, (20, 20), (720, 62), (56, 48, 40), -1)
    for i in range(18):
        cv2.putText(out, f"{i+1:02d}  process_media_region(frame);", (42, 88+i*30),
                    cv2.FONT_HERSHEY_SIMPLEX, .47, (220, 170, 90), 1, cv2.LINE_AA)
    out[y:y+h, x:x+w] = cv2.resize(raw, (w, h), interpolation=cv2.INTER_AREA)
    cv2.rectangle(out, (x-2, y-28), (x+w+2, y), (66, 56, 48), -1)
    cv2.putText(out, "Open-source video in shared content", (x+8, y-8),
                cv2.FONT_HERSHEY_SIMPLEX, .48, (245, 245, 245), 1, cv2.LINE_AA)
    cv2.rectangle(out, (x-2, y-2), (x+w+2, y+h+2), (255, 190, 80), 2)
    return out

def label7(cur, prev, threshold=5.0):
    a = cv2.cvtColor(cur, cv2.COLOR_BGR2GRAY).astype(np.int16)
    b = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY).astype(np.int16)
    h, w = a.shape
    labels = np.zeros(((h+B-1)//B, (w+B-1)//B), np.uint8)
    for by in range(labels.shape[0]):
        for bx in range(labels.shape[1]):
            ys, xs = by*B, bx*B
            if np.abs(a[ys:ys+B, xs:xs+B]-b[ys:ys+B, xs:xs+B]).mean() >= threshold:
                labels[by, bx] = 7
    return labels

def detect(labels, shape):
    moving = labels == 7
    col, row = moving.sum(0), moving.sum(1)
    xs, ys = np.flatnonzero(col >= 5), np.flatnonzero(row >= 10)  # [BODY]
    if len(xs) < 5 or len(ys) < 5:
        return None, col, row
    l, r, t, b = int(xs[0]), int(xs[-1]), int(ys[0]), int(ys[-1])
    x, y, w, h = l*B, t*B, (r-l+1)*B, (b-t+1)*B
    candidate = moving[t:b+1, l:r+1]
    count, total = int(candidate.sum()), int(candidate.size)
    # [PARTIAL] exact production global-motion axis math is not recovered.
    global_motion = w >= shape[1]-128 and h >= shape[0]-128
    ok = not global_motion and w > 256 and h > 256 and count >= 30 and 12*count >= total
    return ((x, y, w, h) if ok else None), col, row

def annotate(frame, labels, region):
    out = frame.copy()
    mask = cv2.resize((labels == 7).astype(np.uint8), (out.shape[1], out.shape[0]),
                      interpolation=cv2.INTER_NEAREST).astype(bool)
    out[mask] = (.45*out[mask] + .55*np.array([40, 70, 245])).astype(np.uint8)
    if region:
        x, y, w, h = region
        cv2.rectangle(out, (x, y), (x+w, y+h), (50, 240, 80), 3)
    cv2.putText(out, "label 7 -> col>=5 / row>=10 -> >256px, >=30, >=1/12",
                (18, 706), cv2.FONT_HERSHEY_SIMPLEX, .55, (255,255,255), 2)
    return out

def projection(col, row):
    img = np.full((480, 960, 3), 248, np.uint8)
    for i, v in enumerate(col):
        x = 60 + i*10
        cv2.rectangle(img, (x, 210), (x+8, 210-min(160, int(v)*7)),
                      (40,180,70) if v >= 5 else (60,120,220), -1)
    for i, v in enumerate(row):
        y = 270 + i*4
        cv2.rectangle(img, (60, y), (60+min(180, int(v)*4), y+3),
                      (40,180,70) if v >= 10 else (220,120,60), -1)
    cv2.putText(img, "column high >= 5", (60,35), 0, .8, (30,30,30), 2)
    cv2.putText(img, "row high >= 10", (60,255), 0, .8, (30,30,30), 2)
    return img

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--video", type=Path, default=DEFAULT_VIDEO)
    p.add_argument("--out", type=Path, default=Path("output"))
    p.add_argument("--frames", type=int, default=60)
    a = p.parse_args(); a.out.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(a.video))
    if not cap.isOpened(): raise SystemExit(f"cannot open {a.video}")
    writer = cv2.VideoWriter(str(a.out/"content_analysis_pip.mp4"),
        cv2.VideoWriter_fourcc(*"mp4v"), cap.get(cv2.CAP_PROP_FPS) or 25, (1280,720))
    prev = None; hits = 0; saved = False
    for _ in range(a.frames):
        ok, raw = cap.read()
        if not ok: break
        cur = compose(raw)
        if prev is not None:
            labels = label7(cur, prev); region, col, row = detect(labels, cur.shape)
            out = annotate(cur, labels, region); writer.write(out)
            hits += region is not None
            if region and not saved:
                cv2.imwrite(str(a.out/"content_analysis_comparison.png"), np.hstack((cur,out)))
                cv2.imwrite(str(a.out/"content_analysis_projection.png"), projection(col,row)); saved=True
        prev = cur
    cap.release(); writer.release()
    print(f"confirmed_frames={hits}; output={a.out.resolve()}")
    return 0 if hits else 2

if __name__ == "__main__": raise SystemExit(main())
