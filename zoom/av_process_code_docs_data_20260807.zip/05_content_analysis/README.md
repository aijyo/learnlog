# 05_content_analysis — Video-in-Share 运动区域检测

本 demo 的 Zoom-derived 核心是 **moving label 7 的消费方式**，不是一个已恢复的“四类 AI
语义分类器”。`LABEL_BACKGROUND`、`LABEL_ROI_FACE_TEXT` 等只用于教学可视化；per-block
motion label 来自编码器上游分析，当前以 frame-difference stand-in 代替。

## 已恢复后处理

- 16×16 block 投影；列门限 5、行门限 10。
- gap tolerance `<8`，约 5 个持续高 bin 后锁定边缘。
- 候选框 `>256×256`，moving block `>=30` 且占比 `>=1/12`。
- 全局运动 guard 的结构已确认，精确轴计数仍为 `[PARTIAL]`。

Python demo 默认读取 `D:\code\work\research\ai-harness\data\videos\dance_outdoor.mp4`，
将视频嵌入合成的文档/代码屏幕；C++ 展示工业实现、确认条件和调用接口。

```powershell
python demo.py
cmake -S . -B build
cmake --build build --config Release
.\build\Release\content_analysis_demo.exe
```

证据：`recon/zlt_content_analysis.hpp`。
