#!/usr/bin/env python3
from pathlib import Path
import argparse,cv2,numpy as np
VIDEO=Path(r'D:\code\work\research\ai-harness\data\videos\portrait.mp4')
def main():
 p=argparse.ArgumentParser();p.add_argument('--video',type=Path,default=VIDEO);p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cap=cv2.VideoCapture(str(a.video));ok,src=cap.read();cap.release()
 if not ok:raise SystemExit(f'cannot read {a.video}')
 src=cv2.resize(src,(480,270));dark=np.clip(src.astype(np.float32)*.48,0,255).astype(np.uint8);y=cv2.cvtColor(dark,cv2.COLOR_BGR2GRAY);mean=float(y.mean());hi=float((y>220).mean());gain=min(2.,96/max(1.,mean)) if mean<80 and hi<.15 else 1.;light=np.clip(dark.astype(float)*gain,0,255).astype(np.uint8)
 m=light.reshape(-1,3).mean(0);g=m.mean();color=np.clip(light.astype(float)*(g/np.maximum(m,1)),0,255).astype(np.uint8)
 lab=cv2.cvtColor(color,cv2.COLOR_BGR2LAB);lab[:,:,0]=cv2.createCLAHE(2.0,(8,8)).apply(lab[:,:,0]);clahe=cv2.cvtColor(lab,cv2.COLOR_LAB2BGR)
 blur=cv2.GaussianBlur(clahe,(3,3),0);delta=clahe.astype(np.int16)-blur.astype(np.int16);sharp=np.clip(clahe.astype(np.int16)+np.where(np.abs(delta)>4,delta,0),0,255).astype(np.uint8)
 panel=np.hstack([dark,light,color,clahe,sharp]);cv2.imwrite(str(a.out/'vfx_stages.png'),panel);print(f'mean={mean:.2f} highlight={hi:.4f} gate={gain>1} gain={gain:.3f}')
if __name__=='__main__':main()
