#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>
struct RGB{double r,g,b;};
RGB gray_world(RGB p,RGB mean){double g=(mean.r+mean.g+mean.b)/3;return{std::clamp(p.r*g/mean.r,0.,255.),std::clamp(p.g*g/mean.g,0.,255.),std::clamp(p.b*g/mean.b,0.,255.)};}
int main(){std::vector<uint8_t> y(64*64,35);for(int j=16;j<48;j++)for(int i=16;i<48;i++)y[j*64+i]=120;double mean=0,hi=0;for(auto v:y){mean+=v;hi+=v>220;}mean/=y.size();hi/=y.size();bool backlight=mean<80&&hi<.15;double gain=backlight?std::min(2.0,96/std::max(1.,mean)):1.;for(auto&v:y)v=uint8_t(std::clamp(v*gain,0.,255.));auto p=gray_world({80,110,170},{80,110,170});std::cout<<"mean="<<mean<<" highlight_fraction="<<hi<<" gate="<<backlight<<" gain="<<gain<<"\n";std::cout<<"gray_world="<<p.r<<","<<p.g<<","<<p.b<<"\n";std::cout<<"pipeline: Light -> Color -> CLAHE(8x8) -> 3x3 thresholded unsharp\n";}
