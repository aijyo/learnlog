# Send-side VFX：Light → Color → CLAHE → Sharpen

Python 从开源 `portrait.mp4` 取帧并输出五阶段 A/B；C++ 展示无依赖的 gate、增益与 gray-world 调用。证据来自 `recon/zlt_vfx.hpp`。

- `[BODY]`：模块次序、ROI 统计形状、8×8 CLAHE、3×3 Gaussian 与 thresholded unsharp。
- `[PARTIAL]`：教学脚本中的触发阈值和目标亮度。
- `BOUNDARY`：AttentionLight 网络权重作为外部 ROI 输入，不重建权重。
