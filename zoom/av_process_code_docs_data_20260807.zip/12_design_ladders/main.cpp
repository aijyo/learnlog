#include <array>
#include <cmath>
#include <iostream>
struct R{int w,h,fps;double factor;};
constexpr std::array<R,4> ladder{{{320,180,30,0},{640,360,30,0},{1280,720,60,0},{1920,1080,60,0}}};
constexpr std::array<R,3> svc{{{160,90,12,.80},{320,180,12,.85},{640,360,24,.95}}};
R nearest(int w,int h,bool camera){auto r=ladder[0];long long p=1LL*w*h,best=1LL<<62;for(auto x:ladder){x.fps=camera?x.fps:30;auto d=std::llabs(1LL*x.w*x.h-p);if(d<best){best=d;r=x;}}return r;}
double scale(int w,int h){double r=double(w)*h/921600.;return std::pow(r,.025*std::log2(r)+.8);}
std::pair<double,double> budget(int m){if(m<=10000)return{100,100};if(m<=20000){double t=(m-10000)/10000.;return{4-t,3-.5*t};}if(m<=40000)return{3,2.5-.3*(m-20000)/20000.};return{3,2.2};}
int main(){constexpr std::array<std::array<int,2>,3> queries{{{500,300},{1000,700},{1600,900}}};for(auto q:queries){auto c=nearest(q[0],q[1],true),s=nearest(q[0],q[1],false);std::cout<<q[0]<<"x"<<q[1]<<" -> "<<c.w<<"x"<<c.h<<" camera@"<<c.fps<<" screen@"<<s.fps<<" scale="<<scale(c.w,c.h)<<"\n";}for(int m:{10000,15000,30000,50000}){auto b=budget(m);std::cout<<"metric="<<m<<" target="<<b.first<<"M base="<<b.second<<"M\n";}for(auto l:svc)std::cout<<"SVC "<<l.w<<"x"<<l.h<<"@"<<l.fps<<" factor="<<l.factor<<"\n";std::cout<<"hysteresis down=.9 up=1.1\n";}
