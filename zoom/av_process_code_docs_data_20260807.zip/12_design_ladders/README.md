# 分辨率 / FPS / bitrate / SVC 设计档位

展示 nearest-pixel-count rung、camera 60fps 与 screen 30fps、log-power bitrate、0.9/1.1 hysteresis、网络 metric 分段和 3-layer SVC 表。

表格与公式均为 `[BODY]`；“推荐用户采用哪个档位”属于产品策略，不由逆向结果推出。Python 生成面板，C++ 展示工业选择函数。证据：`recon/ida_recovered_ladders.md`。
