#!/usr/bin/env python3
from pathlib import Path
import argparse,math
from PIL import Image,ImageDraw
R=[(320,180,30),(640,360,30),(1280,720,60),(1920,1080,60)]
def scale(p):r=p/921600;return r**(.025*math.log2(r)+.8)
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 im=Image.new('RGB',(1100,680),'white');d=ImageDraw.Draw(im);d.text((30,20),'Recovered design ladders [BODY]',fill='black')
 for i,(w,h,fps) in enumerate(R):x=80+i*240;y=520-int(scale(w*h)*170);d.rectangle((x,y,x+150,520),fill=(55,125,205));d.text((x,535),f'{w}x{h}',fill='black');d.text((x,y-42),f'camera {fps} / screen 30',fill='black')
 d.text((30,610),'ratio^(0.025*log2(ratio)+0.8) | hysteresis down .9 / up 1.1',fill='black')
 for i,t in enumerate([(160,90,12,.80),(320,180,12,.85),(640,360,24,.95)]):d.text((650,100+i*38),f'L{i}: {t[0]}x{t[1]} @{t[2]} factor {t[3]}',fill=(20,80,150))
 im.save(a.out/'design_ladders.png');print(a.out.resolve())
if __name__=='__main__':main()
