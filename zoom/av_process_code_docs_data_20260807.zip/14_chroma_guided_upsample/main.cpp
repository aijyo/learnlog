#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
int main(){constexpr int W=16,H=8;std::vector<double>y(W*H),c(W*H);for(int j=0;j<H;j++)for(int i=0;i<W;i++){y[j*W+i]=i<8?25:220;c[j*W+i]=i<8?90:170;}double my=0,mc=0,v=0,cov=0;for(int j=2;j<5;j++)for(int i=6;i<9;i++){my+=y[j*W+i];mc+=c[j*W+i];}my/=9;mc/=9;for(int j=2;j<5;j++)for(int i=6;i<9;i++){double dy=y[j*W+i]-my;v+=dy*dy;cov+=dy*(c[j*W+i]-mc);}v/=9;cov/=9;double a=v>5625?0:cov/(v+105.3405),b=mc-a*my;int aq9=int(std::round(a*512));std::cout<<"variance="<<v<<" gate="<<(v<=5625)<<" a_q9="<<aq9<<" b="<<b<<"\n";for(double yy:{25.,220.})std::cout<<"guided("<<yy<<")="<<std::clamp(a*yy+b,0.,255.)<<"\n";}
