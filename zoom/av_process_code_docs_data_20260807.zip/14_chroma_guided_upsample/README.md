# 亮度引导色度上采样

使用开源 `beach_hat.mp4` 比较 bilinear 与 luma-guided U/V，并输出 variance gate。C++ 展示 3×3 统计、Q9 系数和调用方式。

`[BODY]`：EPS=105.3405、Q9、variance 5625 gate；`[PARTIAL]`：Python 用浮点 box-filter 表达生产定点/边界路径。证据：`recon/zlt_chroma.hpp`。
