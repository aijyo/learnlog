#!/usr/bin/env python3
from pathlib import Path
import argparse,cv2,numpy as np
VIDEO=Path(r'D:\code\work\research\ai-harness\data\videos\beach_hat.mp4')
def guide(y,c):
 y=y.astype(np.float32);c=c.astype(np.float32);my=cv2.boxFilter(y,-1,(3,3));mc=cv2.boxFilter(c,-1,(3,3));var=cv2.boxFilter(y*y,-1,(3,3))-my*my;cov=cv2.boxFilter(y*c,-1,(3,3))-my*mc;a=cov/(var+105.3405);a[var>5625]=0;b=mc-a*my;return np.clip(a*y+b,0,255).astype(np.uint8),var
def main():
 p=argparse.ArgumentParser();p.add_argument('--video',type=Path,default=VIDEO);p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cap=cv2.VideoCapture(str(a.video));ok,bgr=cap.read();cap.release()
 if not ok:raise SystemExit(f'cannot read {a.video}')
 bgr=cv2.resize(bgr,(640,360));yuv=cv2.cvtColor(bgr,cv2.COLOR_BGR2YUV);y,u,v=cv2.split(yuv);u2=cv2.resize(u,(320,180),interpolation=cv2.INTER_AREA);v2=cv2.resize(v,(320,180),interpolation=cv2.INTER_AREA)
 ub=cv2.resize(u2,(640,360),interpolation=cv2.INTER_LINEAR);vb=cv2.resize(v2,(640,360),interpolation=cv2.INTER_LINEAR);ug,var=guide(y,ub);vg,_=guide(y,vb)
 bil=cv2.cvtColor(cv2.merge([y,ub,vb]),cv2.COLOR_YUV2BGR);guided=cv2.cvtColor(cv2.merge([y,ug,vg]),cv2.COLOR_YUV2BGR);gate=np.where(var<=5625,255,0).astype(np.uint8);gate=cv2.cvtColor(gate,cv2.COLOR_GRAY2BGR)
 cv2.imwrite(str(a.out/'chroma_guided_comparison.png'),np.hstack([bgr,bil,guided,gate]));print(a.out.resolve())
if __name__=='__main__':main()
