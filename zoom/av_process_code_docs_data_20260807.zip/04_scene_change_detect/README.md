# 04_scene_change_detect — 亮度无关场景切换级联

> 2026-08 证据修订：本项目已改用 `zlt.dll` 函数体恢复的 **0..64** 相似度与
> `16 / 38 / 48` 多阶段级联。旧文档中的“均值/方差直方图对齐 + 0.38 单阈值”
> 不是最新 body-verified 逻辑，不再作为 Zoom-derived 结论。

本目录为一个自包含项目，C++ 展示工业实现和调用方式；Python 默认从
`D:\code\work\research\ai-harness\data\videos\portrait.mp4` 与 `demo.mp4`
取帧，生成“同内容变暗”和“真实切场景”的可视化结果。

---

## 目录结构

```
04_scene_change_detect/
├── CMakeLists.txt              # 独立 CMake 构建脚本
├── include/
│   └── scene_change_detector.hpp# 零依赖自包含 C++ 算法头文件
├── main.cpp                    # C++ 控制台调试示例 (关灯误判防护 & 切场景指令)
├── demo.py                     # Python 24-bit 全彩肖像/场景图对齐分析 Demo
├── README.md                   # 本独立小项目说明文档
├── scene_change_comparison.png # 3 并排真实画面对比图
├── scene_change_panel.png      # 直方图对齐与 Scene Change 阈值分析面板图
└── scene_change_wiki.html      # 暗色极客风格原理与 Wiki 说明网页
```

---

## 编译与运行方式

### 1. Python 示例运行

直接运行 Python 算法脚本（只需安装 NumPy / Pillow）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\scene_change_detect_demo.exe

# Linux/macOS 运行:
./build/scene_change_detect_demo
```

---

## 算法技术关键点

1. **[BODY] 128-bin 比率相似度**：逐 bin 使用 `min(a,b)*64/max(a,b)`，64 表示相同。
2. **[BODY] 亮度免疫**：在 ±2 bin shift 和 mean-ratio warp 中取最佳值。
3. **[BODY] 判定级联**：`score<=16` 强切换；`(16,38]` 进入 1/8 SAD；
   `(38,48]` 进入 chroma（门限 22）；`score>48` 稳定。
4. **[PARTIAL] 静态 demo 为 luma-only**：chroma 分支和 SIMD SAD 累加器单位不猜测，
   C++ 输出会明确显示 `needs-chroma` 边界。

证据锚点：`recon/zlt_scene_change.hpp`，`sub_18009FE00/A0190/A03B0/A0790/A0CB0`。
