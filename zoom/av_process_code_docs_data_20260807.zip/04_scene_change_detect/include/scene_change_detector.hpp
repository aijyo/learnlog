#pragma once
// Clean-room teaching implementation of the body-verified zlt scene-change path.
// Evidence: zlt.dll sub_18009FE00/A0190/A03B0/A0790/A0CB0.
// Similarity is 0..64 (64 = identical), replacing the old 0..1 mean/std demo.
#include <algorithm>
#include <cstdint>
#include <vector>

namespace standalone::scene_detect {

struct DetectionResult {
    bool scene_change = false, strong = false;
    int score = 64, sad8 = 0, analysis_w = 0, analysis_h = 0;
    const char* branch = "first-frame";
};

class SceneChangeDetector {
public:
    static void AnalysisSize(int w, int h, int& aw, int& ah) {
        int factor = 4;
        if (static_cast<int64_t>(w) * h > 3686400) {
            const int tw = w >= h ? 640 : 360, th = w >= h ? 360 : 640;
            factor = std::max((w + tw - 1) / tw, (h + th - 1) / th);
        }
        factor = std::max(factor, 1);
        aw = ((w / factor) + 1) & ~1; ah = ((h / factor) + 1) & ~1;
    }

    DetectionResult Process(const uint8_t* y, int w, int h, int stride) {
        DetectionResult out; AnalysisSize(w, h, out.analysis_w, out.analysis_h);
        const int aw = out.analysis_w, ah = out.analysis_h;
        if (!y || aw < 16 || ah < 16) { out.branch = "invalid"; return out; }
        std::vector<uint8_t> ana(static_cast<size_t>(aw) * ah);
        for (int j = 0; j < ah; ++j) for (int i = 0; i < aw; ++i)
            ana[static_cast<size_t>(j) * aw + i] = y[static_cast<size_t>(j * h / ah) * stride + i * w / aw];
        Frame cur = BuildHist(ana.data(), aw, ah, aw);
        if (!have_prev_) { prev_ = std::move(cur); prev_ana_ = std::move(ana); have_prev_ = true; return out; }

        out.score = Aligned(cur, prev_);
        if (out.score <= 16) { out.scene_change = out.strong = true; out.branch = "score<=16 strong-cut"; }
        else if (out.score > 48) out.branch = "score>48 stable";
        else if (out.score > 38) out.branch = "38<score<=48 needs-chroma";
        else {
            out.sad8 = MeanSad8(ana.data(), aw, ah);
            const int threshold = out.score <= 24 ? 52 : 55;
            out.scene_change = out.sad8 >= threshold;
            out.strong = out.scene_change && out.score <= 24;
            out.branch = out.scene_change ? "16<score<=38 SAD-confirmed" : "16<score<=38 SAD-rejected";
        }
        prev_ = std::move(cur); prev_ana_ = std::move(ana); return out;
    }

private:
    struct Frame { std::vector<int> hist; int mean = 0; };
    static Frame BuildHist(const uint8_t* p, int w, int h, int stride) {
        Frame f; f.hist.assign(128, 0); long sum = 0;
        for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
            uint8_t v = p[static_cast<size_t>(y) * stride + x]; ++f.hist[v >> 1]; sum += v;
        }
        f.mean = w && h ? static_cast<int>(sum / (w * h)) : 0; return f;
    }
    static int Similarity(const Frame& a, const Frame& b, int shift = 0) {
        long acc = 0, total = 0;
        for (int i = 0; i < 128; ++i) {
            int j = i + shift; if (j < 0 || j >= 128) continue;
            int x = a.hist[i], y = b.hist[j], hi = std::max(x, y), lo = std::min(x, y);
            if (hi) acc += static_cast<long>(x) * ((lo << 6) / hi); total += x;
        }
        return total ? static_cast<int>(acc / total) : 64;
    }
    static int Aligned(const Frame& cur, const Frame& prev) {
        int best = 0; for (int s = -2; s <= 2; ++s) best = std::max(best, Similarity(cur, prev, s));
        if (prev.mean > 0) {
            int ratio32 = 32 * cur.mean / prev.mean;
            if (ratio32 > 0 && ratio32 != 32) {
                Frame warped; warped.hist.assign(128, 0);
                for (int i = 0; i < 128; ++i) warped.hist[std::min(127, 32 * i / ratio32)] += prev.hist[i];
                best = std::max(best, Similarity(cur, warped));
            }
        }
        return best;
    }
    int MeanSad8(const uint8_t* cur, int w, int h) const {
        if (prev_ana_.size() != static_cast<size_t>(w) * h) return 0;
        long sad = 0; int n = 0;
        for (int y = 0; y < h; y += 8) for (int x = 0; x < w; x += 8) {
            int d = int(cur[static_cast<size_t>(y) * w + x]) - int(prev_ana_[static_cast<size_t>(y) * w + x]);
            sad += d < 0 ? -d : d; ++n;
        }
        return n ? static_cast<int>(sad / n) : 0;
    }
    Frame prev_; std::vector<uint8_t> prev_ana_; bool have_prev_ = false;
};
} // namespace standalone::scene_detect
