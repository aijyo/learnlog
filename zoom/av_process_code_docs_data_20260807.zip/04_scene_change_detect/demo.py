#!/usr/bin/env python3
"""Body-verified 0..64 scene-change cascade, driven by open-source videos."""
from pathlib import Path
import argparse
import cv2
import numpy as np
from PIL import Image, ImageDraw

VIDEO_ROOT = Path(r"D:\code\work\research\ai-harness\data\videos")

def first_frame(path, size=(640, 360)):
    cap = cv2.VideoCapture(str(path)); ok, frame = cap.read(); cap.release()
    if not ok: raise RuntimeError(f"cannot read {path}")
    return cv2.resize(frame, size, interpolation=cv2.INTER_AREA)

def luma(frame): return cv2.cvtColor(frame, cv2.COLOR_BGR2YUV)[:, :, 0]

def hist_info(y):
    return np.bincount(y.reshape(-1) >> 1, minlength=128).astype(np.int64), int(y.mean())

def similarity(a, b, shift=0):
    acc, total = 0, int(a.sum())
    for i in range(128):
        j = i + shift
        if 0 <= j < 128:
            hi, lo = max(int(a[i]), int(b[j])), min(int(a[i]), int(b[j]))
            if hi: acc += int(a[i]) * ((lo << 6) // hi)
    return acc // total if total else 64

def aligned_score(cur_y, prev_y):
    cur, cm = hist_info(cur_y); prev, pm = hist_info(prev_y)
    best = max(similarity(cur, prev, s) for s in range(-2, 3))
    if pm:
        ratio32 = 32 * cm // pm
        if ratio32 and ratio32 != 32:
            acc, total = 0, int(cur.sum())
            for i in range(128):
                j = min(127, 32 * i // ratio32)
                hi, lo = max(int(cur[i]), int(prev[j])), min(int(cur[i]), int(prev[j]))
                if hi: acc += int(cur[i]) * ((lo << 6) // hi)
            if total: best = max(best, acc // total)
    return best

def decision(score, cur_y, prev_y):
    sad8 = int(np.abs(cur_y[::8,::8].astype(np.int16)-prev_y[::8,::8].astype(np.int16)).mean())
    if score <= 16: return True, "strong cut", sad8
    if score <= 38:
        hit = sad8 >= (52 if score <= 24 else 55)
        return hit, "SAD confirmed" if hit else "SAD rejected", sad8
    if score <= 48: return False, "needs chroma", sad8
    return False, "stable", sad8

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", type=Path, default=VIDEO_ROOT / "portrait.mp4")
    ap.add_argument("--cut", type=Path, default=VIDEO_ROOT / "demo.mp4")
    ap.add_argument("--out", type=Path, default=Path("output"))
    a = ap.parse_args(); a.out.mkdir(parents=True, exist_ok=True)
    base = first_frame(a.base)
    dark = np.clip(base.astype(np.float32) * .75, 0, 255).astype(np.uint8)
    cut = first_frame(a.cut)
    base_y, dark_y, cut_y = luma(base), luma(dark), luma(cut)
    light_score = aligned_score(dark_y, base_y); light = decision(light_score, dark_y, base_y)
    cut_score = aligned_score(cut_y, dark_y); cut_dec = decision(cut_score, cut_y, dark_y)

    canvas = Image.new("RGB", (1920, 430), (8,13,22)); d = ImageDraw.Draw(canvas)
    for i, (frame, title) in enumerate(((base,"source video"),(dark,"same frame x0.75"),(cut,"different video"))):
        canvas.paste(Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)), (640*i, 0))
        d.text((640*i+16, 374), title, fill=(230,238,248))
    d.text((16,402), f"light score={light_score}/64 sad8={light[2]} ({light[1]})", fill=(110,231,168))
    d.text((700,402), f"cut score={cut_score}/64 sad8={cut_dec[2]} ({cut_dec[1]})", fill=(255,124,139))
    canvas.save(a.out / "scene_change_comparison.png")

    panel = Image.new("RGB", (920,420), (8,13,22)); p = ImageDraw.Draw(panel)
    p.text((28,20), "Body-verified zlt scene-change decision cascade", fill="white")
    colors=[(255,124,139),(255,171,86),(255,202,104),(110,231,168)]
    bands=[(0,16,"strong cut"),(16,38,"1/8 SAD"),(38,48,"chroma"),(48,64,"stable")]
    x0,y0,w,h=70,110,790,100
    for color,(lo,hi,name) in zip(colors,bands):
        xa=x0+int(w*lo/64); xb=x0+int(w*hi/64)
        p.rectangle((xa,y0,xb,y0+h),fill=color); p.text((xa+7,y0+39),name,fill=(8,13,22))
    for score,name,color in ((light_score,"light",(86,212,255)),(cut_score,"cut",(255,255,255))):
        x=x0+int(w*score/64); p.line((x,y0-25,x,y0+h+25),fill=color,width=4)
        p.text((x-22,y0+h+35),f"{name}:{score}",fill=color)
    p.text((28,300),"BODY: luma 16/38/48; chroma 22; SAD path constants 55/52.",fill=(170,186,208))
    p.text((28,330),"Boundary: production chroma and SIMD accumulator units are not invented.",fill=(170,186,208))
    panel.save(a.out / "scene_change_panel.png")
    print(f"light={light_score}/64 sad8={light[2]} change={light[0]} {light[1]}")
    print(f"cut={cut_score}/64 sad8={cut_dec[2]} change={cut_dec[0]} {cut_dec[1]}")
    if light[0] or not cut_dec[0]: raise SystemExit("smoke assertion failed")
    print(a.out.resolve())

if __name__ == "__main__": main()
