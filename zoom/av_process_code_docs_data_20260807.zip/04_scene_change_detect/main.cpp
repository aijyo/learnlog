#include "scene_change_detector.hpp"
#include <cstdint>
#include <iostream>
#include <vector>

static void show(const char* name, const standalone::scene_detect::DetectionResult& r) {
    std::cout << name << ": score=" << r.score << "/64 sad8=" << r.sad8
              << " branch=" << r.branch << " change=" << (r.scene_change ? "yes" : "no") << '\n';
}

int main() {
    constexpr int w = 320, h = 180;
    std::vector<uint8_t> base(size_t(w) * h), dark(base.size()), cut(base.size());
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
        int v = 45 + x * 130 / w + ((x / 12 + y / 12) % 2) * 35;
        base[size_t(y) * w + x] = uint8_t(v);
        dark[size_t(y) * w + x] = uint8_t(v * 75 / 100);
        cut[size_t(y) * w + x] = uint8_t(((x / 8) ^ (y / 8)) & 1 ? 235 : 18);
    }
    standalone::scene_detect::SceneChangeDetector d;
    show("baseline", d.Process(base.data(), w, h, w));
    show("same-content/darker", d.Process(dark.data(), w, h, w));
    auto result = d.Process(cut.data(), w, h, w); show("hard-cut", result);
    std::cout << "\n0..64 cascade: <=16 strong; (16,38] SAD; (38,48] chroma; >48 stable.\n";
    return result.scene_change ? 0 : 2;
}
