# Capture→Encode 多相抗混叠重采样

Python 从开源 `walk_indoor.mp4` 比较 linear、area/box、Catmull-Rom、Lanczos-4；C++ 输出 kernel taps 与 scale-adaptive support。

`[BODY]`：kernel cases、缩小时 support 扩展、每输出像素归一化、水平/垂直两遍；OpenCV 仅作 OSS 对照适配器。证据：`recon/zlt_resample.hpp`。
