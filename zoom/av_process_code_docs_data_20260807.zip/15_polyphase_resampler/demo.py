#!/usr/bin/env python3
from pathlib import Path
import argparse,cv2,numpy as np
VIDEO=Path(r'D:\code\work\research\ai-harness\data\videos\walk_indoor.mp4')
def main():
 p=argparse.ArgumentParser();p.add_argument('--video',type=Path,default=VIDEO);p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cap=cv2.VideoCapture(str(a.video));ok,src=cap.read();cap.release()
 if not ok:raise SystemExit(f'cannot read {a.video}')
 target=(640,360);tiles=[]
 for name,mode in [('linear',cv2.INTER_LINEAR),('box',cv2.INTER_AREA),('catmull',cv2.INTER_CUBIC),('lanczos4',cv2.INTER_LANCZOS4)]:
  z=cv2.resize(src,target,interpolation=mode);cv2.putText(z,name,(15,32),0,1,(0,255,255),2);tiles.append(z)
 cv2.imwrite(str(a.out/'resampler_comparison.png'),np.vstack([np.hstack(tiles[:2]),np.hstack(tiles[2:])]))
 print(f'input={src.shape[1]}x{src.shape[0]} output=640x360')
if __name__=='__main__':main()
