#include <cmath>
#include <iostream>
double catmull(double x){x=std::abs(x);return x<1?1.5*x*x*x-2.5*x*x+1:x<2?-.5*x*x*x+2.5*x*x-4*x+2:0;}
double lanczos4(double x){x=std::abs(x);if(x<1e-9)return 1;if(x>=4)return 0;double p=3.141592653589793*x;return std::sin(p)/p*std::sin(p/4)/(p/4);}
int main(){for(double x=-4;x<=4;x+=.5)std::cout<<x<<","<<catmull(x)<<","<<lanczos4(x)<<"\n";double scale=.5,support=4/std::min(1.,scale);std::cout<<"downscale="<<scale<<" adaptive_support="<<support<<" separable=horizontal+vertical\n";}
