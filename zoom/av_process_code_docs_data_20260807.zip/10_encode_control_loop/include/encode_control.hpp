#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

namespace demo::encode_control {
struct StructureMode {
  int mode{}, field212{}, field216{}, field220{}, field222{};
  static StructureMode unpack(uint16_t w) { // [BODY]
    StructureMode s{int(w&15), int((w>>4)&15), int(w>>8), int((w>>8)&15), int(w>>12)};
    if (s.mode==3) { s.mode=2; s.field212=1; }
    return s;
  }
};
struct LayerConfig { int width{},height{},bitrate{},tools{}; bool single_ref{}; };
struct DerivedLayer { int dpb{}; std::array<bool,6> tool{}; };
class ConfigBank {
  std::vector<LayerConfig> current_;
public:
  bool pending{};
  int apply(const std::vector<LayerConfig>& v) { // [BODY]
    bool changed=current_.size()!=v.size();
    for(size_t i=0;!changed&&i<v.size();++i) changed=std::memcmp(&current_[i],&v[i],sizeof(LayerConfig))!=0;
    if(changed&&pending) return -5;
    pending=changed; current_=v; return 0;
  }
  int request_bank() const { return pending?1:0; }
  void commit(){ pending=false; }
  static DerivedLayer derive(const LayerConfig& l){
    DerivedLayer d; d.dpb=l.single_ref?8:16;
    for(int i=0;i<6;++i)d.tool[i]=(l.tools>>i)&1; return d;
  }
};
enum class Request { Key=2,Idr=4,DuplicateP=5,Skip=24 };
struct Pending { bool key{},idr{},duplicate{},skip{}; int idr_number{}; };
inline void dispatch(Pending& p, Request r, int number=0, bool screen_codec=true){ // [BODY]
  if(r==Request::Idr){p.idr=true;p.idr_number=std::max(p.idr_number,number);p.duplicate=p.skip=false;}
  else if(r==Request::Key&&!p.idr)p.key=true;
  else if(r==Request::DuplicateP&&!p.idr&&!p.key)p.duplicate=true;
  else if(r==Request::Skip&&screen_codec&&!p.idr)p.skip=true;
}
inline std::vector<double> dyadic_fps(double top,int n){ // [BODY]
  n=std::max(1,n);std::vector<double> out(n);for(int i=n-1;i>=0;--i){out[i]=top;top*=.5;}return out;
}
inline int qp_scale_q10(double complexity,double reference){ // [BODY]
  double s=reference>0?std::pow(complexity/reference,.3):1.;s=std::clamp(s,.2,5.);return int(s*1024.);
}
inline int frame_qp(double complexity,double reference,int qmin=20,int qmax=40){
  return std::clamp((qp_scale_q10(complexity,reference)*28+512)/1024,qmin,qmax);
}
inline double vbv_fill(int bitrate){return bitrate>0?1024000000.0/bitrate:0.;} // [BODY]
} // namespace demo::encode_control
