# 编码控制闭环

Python 输出 QP/VBV 曲线；C++ 展示结构字拆包、DPB/工具位派生、双缓冲 pending bank、请求冲突和定点公式。

- `[BODY]`：mode 3 特例；single-ref→8 DPB、否则 16；6-bit tools；reconfig pending；dyadic fps；Q10 复杂度 QP 的 `pow(...,0.3)` 与 `0.2..5.0`；VBV `1024000000/bitrate`；IDR 请求优先级。
- `[PARTIAL]`：复杂度单元聚合权重、backend 状态和错误码语义。
- `BOUNDARY`：真正 H.264 Annex-B 编码由 minih264/x264/OpenH264 适配层承担，本目录不伪造编码器内核。

证据：`recon/zlt_svc_encoder.hpp`、`zlt_encode_config.hpp`、`zlt_rate_control.hpp`、`zlt_h264_backend.hpp`。
