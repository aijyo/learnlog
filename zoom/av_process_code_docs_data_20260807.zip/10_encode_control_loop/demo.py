#!/usr/bin/env python3
from pathlib import Path
import argparse
from PIL import Image,ImageDraw
def q10(c):return int(max(.2,min(5.,c**.3))*1024)
def qp(c):return max(20,min(40,(q10(c)*28+512)//1024))
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cs=[.1+i*.05 for i in range(199)];im=Image.new('RGB',(1000,620),'white');d=ImageDraw.Draw(im)
 d.text((30,18),'Encode control: QP=clamp(28*(C/Cref)^0.3), scale 0.2..5.0',fill='black')
 for i in range(1,len(cs)):d.line((70+(i-1)*4,520-(qp(cs[i-1])-20)*20,70+i*4,520-(qp(cs[i])-20)*20),fill=(35,105,200),width=3)
 for q in range(20,41,5):d.text((25,515-(q-20)*20),str(q),fill='black')
 d.text((650,75),'IDR > Key > Duplicate-P / Skip',fill=(180,40,40));d.text((650,115),'3T @30 fps: 7.5 / 15 / 30',fill='black');d.text((650,145),f'VBV @1.2Mbps: {1024000000/1200000:.2f}',fill='black')
 im.save(a.out/'encode_control_loop.png');print(a.out.resolve())
if __name__=='__main__':main()
