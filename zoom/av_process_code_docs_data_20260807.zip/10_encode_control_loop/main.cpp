#include "encode_control.hpp"
#include <iostream>
using namespace demo::encode_control;
int main(){
 auto s=StructureMode::unpack(0x5613);std::cout<<"mode="<<s.mode<<" f212="<<s.field212<<" f222="<<s.field222<<"\n";
 LayerConfig l{1280,720,1200000,43,true};ConfigBank b;std::cout<<"apply="<<b.apply({l})<<" bank="<<b.request_bank()<<"\n";
 std::cout<<"pending_reconfig="<<b.apply({LayerConfig{1920,1080,2400000,3,false}})<<"\n";
 auto d=ConfigBank::derive(l);std::cout<<"dpb="<<d.dpb<<" tools=";for(bool x:d.tool)std::cout<<x;std::cout<<"\n";
 Pending p;dispatch(p,Request::Key);dispatch(p,Request::Idr,7);dispatch(p,Request::DuplicateP);
 std::cout<<"key="<<p.key<<" idr="<<p.idr<<" duplicate="<<p.duplicate<<" idr#="<<p.idr_number<<"\n";
 for(double f:dyadic_fps(30,3))std::cout<<"fps="<<f<<" ";std::cout<<"\n";
 for(double c:{.2,.5,1.,2.,5.})std::cout<<"C="<<c<<" q10="<<qp_scale_q10(c,1)<<" qp="<<frame_qp(c,1)<<"\n";
 std::cout<<"vbv="<<vbv_fill(1200000)<<"\n";
}
