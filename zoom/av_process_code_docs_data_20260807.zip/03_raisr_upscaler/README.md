# 03_raisr_upscaler — RAISR 结构张量超分、模型训练与 GPU Watchdog 机制独立项目

> 证据校准：当前 C++/Python 执行的是 CPU 教学路径；训练得到的 filter bank 是本 demo 自有数据。D3D11 compute、49/22 bucket 生产 bank 与真实 GPU timestamp 尚属 `BOUNDARY/PARTIAL`，文中 “GPU Compute Shader” 表示接口结构而非已完成 GPU 执行。

本目录为一个**完全自包含 (Standalone)** 的独立小项目，展示实时音视频管线中用于图像高质超分的 **RAISR (Rapid and Accurate Image Super-Resolution)** 结构张量哈希分类算法、**最小二乘离线训练管线 (Training Pipeline)**、**GPU 计算着色器 (Compute Shader)** 以及配套的 **15ms GPU 耗时性能 Watchdog** 防卡顿关停机制。

---

## 目录结构

```
03_raisr_upscaler/
├── CMakeLists.txt           # 独立 CMake 构建脚本
├── include/
│   └── raisr_upscaler.hpp   # 自包含 C++ 算法头文件 (零依赖)
├── main.cpp                 # C++ 控制台调试示例 (测试哈希分类与 Watchdog 状态机)
├── demo.py                  # Python 24-bit 全彩色肖像图 RAISR 训练与 2x 演示脚本
├── README.md                # 本独立小项目说明文档
├── raisr_comparison.png     # 生成导出的 4 并排 1024x256 RGB 全彩肖像对比大图
├── watchdog_simulation_panel.png # 320 帧 Watchdog 动态关停折线监控图
└── raisr_upscaler_wiki.html # 暗色极客风格原理、模型结构、训练与 Wiki 说明网页
```

---

## 编译与运行方式

### 1. Python 示例运行 (包含现场正规方程训练演示)

直接运行 Python 算法脚本（只需安装 NumPy / Pillow）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\raisr_upscaler_demo.exe

# Linux/macOS 运行:
./build/raisr_upscaler_demo
```

---

## 算法技术关键点

1. **模型结构 (Model Architecture)**: 4 Phases $\times$ 49 Buckets $\times$ 121 Taps。结构张量由协方差矩阵特征值 $\lambda_1, \lambda_2$ 求解强度 $S$、一致性 $C$ 与角度 $\theta$，哈希桶映射 $k \in [0..48]$。
2. **离线训练管线 (Training Pipeline)**: 使用岭回归 / 最小二乘正规方程求解每个桶的最优加权系数：
   $$h_{p, k} = \left( A_{p, k}^T A_{p, k} + \lambda I \right)^{-1} A_{p, k}^T b_{p, k}$$
3. **GPU 耗时 Watchdog 防卡顿机制**: 设单帧预算为 $15\text{ms}$，在 32 帧窗口统计超时；在 320 帧总周期内若超过 2 次 Strike 连续超时，系统自适应关闭/降级 RAISR，避免渲染拖垮帧率。
