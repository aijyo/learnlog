#!/usr/bin/env python3
"""
RAISR 全套权重 (.bin)、Camera 特化 22 桶算法 & Watchdog 机制 Demo
(RAISR Full Bank Files, Camera Optimized Algorithm & Watchdog Demo)

用法:
    python demo.py
"""

import numpy as np
from PIL import Image, ImageDraw
import urllib.request
import os

PORTRAIT_URLS = [
    "https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg",
    "https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg"
]

def load_raisr_bank_bin(filepath):
    """【通用与 Camera 权重解析】直接读取加载 raisr_bank.bin / raisr_cam_bank*.bin 权重文件"""
    if not os.path.exists(filepath):
        return None, None
    with open(filepath, "rb") as f:
        hdr = np.fromfile(f, dtype=np.int32, count=4)
        th = np.fromfile(f, dtype=np.float32, count=2)
        nphase, nbuck, taps, patch = hdr
        flat_t, str_t = th
        
        target_size = nphase * nbuck * taps
        data = np.fromfile(f, dtype=np.float32)
        if len(data) < target_size:
            data = np.pad(data, (0, target_size - len(data)))
        else:
            data = data[:target_size]
            
        filters = data.reshape((nphase, nbuck, taps))
        return filters, (flat_t, str_t)

def get_real_color_portrait(width=128, height=128):
    """获取 24-bit RGB 全彩色人物肖像测试原图"""
    local_path = "portrait_color_base.jpg"
    if not os.path.exists(local_path):
        print("   正在从开源测试样本库下载 RGB 全彩色人物肖像图片...")
        for url in PORTRAIT_URLS:
            try:
                urllib.request.urlretrieve(url, local_path)
                print("   ✔ 成功下载 RGB 全彩色人物肖像图！")
                break
            except Exception as e:
                print(f"   下载失败 ({e})，尝试下一个镜像...")

    if os.path.exists(local_path):
        img = Image.open(local_path).convert('RGB')
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        return np.array(img, dtype=np.uint8)
    else:
        arr = np.zeros((height, width, 3), dtype=np.uint8)
        arr[:, :, 0] = 180; arr[:, :, 1] = 120; arr[:, :, 2] = 80
        return arr

def raisr_classify_pixel(img_channel, cx, cy, patch_size=11, flat_thresh=5.0):
    """49 桶 Screen RAISR 结构张量哈希"""
    r = patch_size // 2
    h, w = img_channel.shape
    if cx <= r or cy <= r or cx >= w - r or cy >= h - r:
        return 48

    patch = img_channel[cy-r:cy+r+1, cx-r:cx+r+1].astype(np.float32)
    gx = patch[:, 2:] - patch[:, :-2]
    gy = patch[2:, :] - patch[:-2, :]
    
    min_h = min(gx.shape[0], gy.shape[0])
    min_w = min(gx.shape[1], gy.shape[1])
    gx = gx[:min_h, :min_w]
    gy = gy[:min_h, :min_w]

    gxx = np.sum(gx * gx)
    gyy = np.sum(gy * gy)
    gxy = np.sum(gx * gy)

    t = gxx + gyy
    d = np.sqrt((gxx - gyy)**2 + 4 * gxy**2)
    l1 = (t + d) / 2.0
    l2 = (t - d) / 2.0
    
    sl1 = np.sqrt(max(0.0, l1))
    sl2 = np.sqrt(max(0.0, l2))
    
    strength = sl1
    coherence = (sl1 - sl2) / (sl1 + sl2) if (sl1 + sl2 > 1e-9) else 0.0

    if strength < flat_thresh:
        return 48

    ang = 0.5 * np.arctan2(2 * gxy, gxx - gyy)
    if ang < 0: ang += np.pi
    
    ab = int(round(ang * (11.0 / np.pi)))
    ab = max(0, min(11, ab))
    
    sb = 1 if strength >= 15.0 else 0
    cb = 1 if coherence >= 0.5 else 0

    return cb * 24 + sb * 12 + ab

def raisr_classify_pixel_cam(img_channel, cx, cy):
    """Camera 特化 22 桶轻量哈希 (11 angle x 2 strength)"""
    h, w = img_channel.shape
    if cx <= 2 or cy <= 2 or cx >= w - 2 or cy >= h - 2:
        return 0

    patch = img_channel[cy-1:cy+2, cx-1:cx+2].astype(np.float32)
    gx = patch[:, 2:] - patch[:, :-2]
    gy = patch[2:, :] - patch[:-2, :]
    
    gxx = np.sum(gx * gx) / 9.0
    gyy = np.sum(gy * gy) / 9.0
    gxy = np.sum(gx * gy) / 9.0

    tr = gxx + gyy
    disc = np.sqrt(max(0.0, 0.25 * tr * tr - (gxx * gyy - gxy * gxy)))
    lam1 = 0.5 * tr + disc
    strength = np.sqrt(max(0.0, lam1))

    theta = 0.5 * np.arctan2(2.0 * gxy, gxx - gyy)
    if theta < 0: theta += np.pi
    
    abin = int(round(theta * 10.0 / np.pi))
    abin = max(0, min(10, abin))
    sbin = 1 if strength > 0.5 else 0
    return abin + 11 * sbin # [0..21]

def raisr_upscale_rgb_with_bank(img_rgb, filters):
    """使用 bin 加载的真实 11x11 或菱形 13 Tap 滤镜组重构"""
    h, w, c = img_rgb.shape
    oh, ow = h * 2, w * 2
    out = np.zeros((oh, ow, 3), dtype=np.uint8)
    
    is_cam = (filters.shape[1] == 22)
    r = 5
    scale = 2
    
    for ch in range(3):
        img_ch = img_rgb[:, :, ch]
        base_pil = Image.fromarray(img_ch).resize((ow, oh), Image.Resampling.BILINEAR)
        base = np.array(base_pil, dtype=np.float32)
        res = base.copy()
        
        for oy in range(r, oh - r):
            for ox in range(r, ow - r):
                p = (oy % scale) * scale + (ox % scale)
                
                if is_cam:
                    b = raisr_classify_pixel_cam(base, ox, oy)
                    f = filters[p, b]
                    if len(f) == 121:
                        patch = base[oy-r:oy+r+1, ox-r:ox+r+1].flatten()
                        res[oy, ox] = np.dot(patch, f)
                    elif len(f) == 13:
                        pts = []
                        for dy in range(-2, 3):
                            for dx in range(-2, 3):
                                if abs(dx) + abs(dy) <= 2:
                                    pts.append(base[oy+dy, ox+dx])
                        res[oy, ox] = np.dot(np.array(pts), f)
                else:
                    b = raisr_classify_pixel(base, ox, oy)
                    f = filters[p, b]
                    patch = base[oy-r:oy+r+1, ox-r:ox+r+1].flatten()
                    res[oy, ox] = np.dot(patch, f)
                    
        out[:, :, ch] = np.clip(res, 0, 255).astype(np.uint8)
        
    return out

def generate_watchdog_simulation_panel(filename="watchdog_simulation_panel.png"):
    """绘制 15ms GPU Watchdog 连续 320 帧监控面板与耗时回落可视化图"""
    width, height = 800, 360
    img = Image.new('RGB', (width, height), color=(11, 15, 25))
    draw = ImageDraw.Draw(img)

    frame_times = []
    disabled = False
    bad_windows = 0
    accum = 0
    trigger_frame = -1

    for f in range(1, 321):
        if disabled:
            t = 2.0 + np.random.uniform(-0.3, 0.3)
        else:
            if 129 <= f <= 192:
                t = 22.0 + np.random.uniform(-1.5, 1.5)
            else:
                t = 11.0 + np.random.uniform(-1.0, 1.0)

        frame_times.append(t)
        
        if not disabled:
            accum += t
            if f % 32 == 0:
                if accum >= 32 * 15.0:
                    bad_windows += 1
                accum = 0
            if bad_windows >= 2:
                disabled = True
                trigger_frame = f

    margin_l, margin_r, margin_t, margin_b = 60, 40, 60, 50
    plot_w = width - margin_l - margin_r
    plot_h = height - margin_t - margin_b

    for y_val in [0, 10, 15, 20, 30]:
        y_pos = margin_t + plot_h - int(y_val / 30.0 * plot_h)
        draw.line([(margin_l, y_pos), (width - margin_r, y_pos)], fill=(31, 41, 55), width=1)
        draw.text((15, y_pos - 6), f"{y_val}ms", fill=(156, 163, 175))

    budget_y = margin_t + plot_h - int(15.0 / 30.0 * plot_h)
    draw.line([(margin_l, budget_y), (width - margin_r, budget_y)], fill=(239, 68, 68), width=2)
    draw.text((width - 110, budget_y - 15), "15ms GPU Budget", fill=(239, 68, 68))

    for w_idx in range(1, 11):
        f_idx = w_idx * 32
        x_pos = margin_l + int(f_idx / 320.0 * plot_w)
        draw.line([(x_pos, margin_t), (x_pos, margin_t + plot_h)], fill=(31, 41, 55), width=1)

    points = []
    for idx, t in enumerate(frame_times):
        x = margin_l + int((idx + 1) / 320.0 * plot_w)
        y = margin_t + plot_h - int(min(t, 30.0) / 30.0 * plot_h)
        points.append((x, y))

    for i in range(len(points) - 1):
        color = (56, 189, 248) if i < trigger_frame else (52, 211, 153)
        draw.line([points[i], points[i+1]], fill=color, width=2)

    if trigger_frame > 0:
        tx = margin_l + int(trigger_frame / 320.0 * plot_w)
        ty = margin_t + plot_h - int(2.0 / 30.0 * plot_h)
        draw.ellipse([tx - 6, ty - 6, tx + 6, ty + 6], fill=(239, 68, 68), outline=(255, 255, 255), width=2)
        draw.line([(tx, margin_t), (tx, margin_t + plot_h)], fill=(239, 68, 68), width=2)
        draw.text((tx + 10, margin_t + 20), f"Frame {trigger_frame}: 2-Strike Event\nRAISR Auto Disabled -> 2ms", fill=(239, 68, 68))

    draw.text((margin_l, 15), "GPU Performance Watchdog Simulation Panel (320 Frames Cycle)", fill=(255, 255, 255))
    draw.text((margin_l, 35), "32-frame Window | 2 Strikes Threshold | Auto-Fallback to Bilinear (2ms)", fill=(156, 163, 175))

    img.save(filename)
    return filename

if __name__ == '__main__':
    print("==========================================================")
    print("  RAISR 全套权重 (.bin) 包含 Camera 特化 22 桶 Demo")
    print("==========================================================")

    bin_files = [
        "raisr_bank.bin",
        "raisr_cam_bank.bin",
        "raisr_cam_bank_x2.bin",
        "raisr_cam_bank_x3.bin"
    ]

    print("\n1. 正在解析检验全套离线二进制权重数据文件 (data/*.bin)...")
    for fname in bin_files:
        fpath = os.path.join("data", fname)
        flt, (fl_t, st_t) = load_raisr_bank_bin(fpath)
        if flt is not None:
            kind = "Camera 22 桶特化" if flt.shape[1] == 22 else "Screen 49 桶通用"
            print(f"   ✔ 成功解析 {fname:22s} | 类型: {kind} | 形状: {flt.shape}")

    # 读取 Camera 2x 权重做推理
    cam_x2_path = os.path.join("data", "raisr_cam_bank_x2.bin")
    cam_filters, _ = load_raisr_bank_bin(cam_x2_path)

    print("\n2. 正在获取 24-bit RGB 全彩肖像测试原图 (128x128)...")
    src_rgb = get_real_color_portrait(128, 128)
    Image.fromarray(src_rgb).save("raisr_input_128x128.png")

    print("\n3. 使用 Camera 特化二进制权重 (raisr_cam_bank_x2.bin) 运行 2x 超分重构...")
    raisr_out = raisr_upscale_rgb_with_bank(src_rgb, cam_filters)
    Image.fromarray(raisr_out).save("raisr_output_256x256.png")

    print("\n4. 生成传统双线性插值 (Bilinear 2x) 彩色人像作为对比...")
    bilinear_pil = Image.fromarray(src_rgb).resize((256, 256), Image.Resampling.BILINEAR)
    bilinear_out = np.array(bilinear_pil, dtype=np.uint8)
    bilinear_pil.save("bilinear_output_256x256.png")

    diff_map = np.clip(np.abs(raisr_out.astype(np.int16) - bilinear_out.astype(np.int16)) * 4, 0, 255).astype(np.uint8)
    Image.fromarray(diff_map).save("raisr_vs_bilinear_diff.png")

    comparison_img = Image.new('RGB', (256 * 4, 256))
    src_padded = Image.new('RGB', (256, 256), color=(20, 20, 20))
    src_padded.paste(Image.fromarray(src_rgb), (64, 64))
    
    comparison_img.paste(src_padded, (0, 0))
    comparison_img.paste(bilinear_pil, (256, 0))
    comparison_img.paste(Image.fromarray(raisr_out), (512, 0))
    comparison_img.paste(Image.fromarray(diff_map), (768, 0))
    comparison_img.save("raisr_comparison.png")

    print("\n5. 正在导出 Watchdog 15ms 预算 320 帧动态耗时监控面板图...")
    panel_file = generate_watchdog_simulation_panel("watchdog_simulation_panel.png")
    print(f"   ✔ 成功导出 Watchdog 运行折线与自适应关停面板: {panel_file}")

    print("\n处理完成！全套文件列表:")
    print("  └─ raisr_comparison.png           : 4 并排 1024x256 RGB 全彩肖像超分对比大图")
    print("  └─ watchdog_simulation_panel.png  : 320 帧 15ms 预算 Watchdog 动态关停曲线面板图")
