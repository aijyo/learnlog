#include "raisr_upscaler.hpp"
#include "raisr_trainer.hpp"
#include <iostream>
#include <vector>
#include <iomanip>
#include <string>

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "  RAISR 全套权重 (.bin) 检验与 Watchdog 全能 Demo (C++)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    // 1. 遍历测试全套 5 个权重 bin 文件
    std::vector<std::string> bin_files = {
        "data/raisr_bank.bin",
        "data/raisr_cam_bank.bin",
        "data/raisr_cam_bank_x2.bin",
        "data/raisr_cam_bank_x3.bin",
        "data/my_custom_raisr.bin"
    };

    std::cout << "\n[1. 遍历解析全套离线二进制权重库 (data/*.bin)]:" << std::endl;
    for (const auto& path : bin_files) {
        standalone::raisr::TrainedFilterBank bank;
        if (bank.LoadFromBin(path)) {
            std::cout << "  ✔ [加载成功] " << std::setw(26) << std::left << path
                      << " | 类型: " << (bank.is_camera() ? "Camera 22 桶特化" : "Screen 49 桶通用")
                      << " | 相位: " << bank.phases()
                      << " | 桶数: " << bank.buckets()
                      << " | Taps: " << bank.taps() << std::endl;
        } else {
            std::cout << "  ⚠ [未找到/跳过] " << path << std::endl;
        }
    }

    // 2. 现场离线训练测试 (RaisrTrainer)
    std::cout << "\n[2. C++ RAISR 现场离线训练器测试 (RaisrTrainer)]:" << std::endl;
    standalone::raisr::RaisrConfig train_cfg;
    train_cfg.scale = 2;
    train_cfg.patch = 11;

    standalone::raisr::RaisrTrainer trainer(train_cfg);
    std::vector<float> synth_hr;
    trainer.GenerateSyntheticTrainingImage(synth_hr, 256, 256, 12345);
    trainer.AccumulateImage(synth_hr, 256, 256);

    std::string custom_bin = "data/my_custom_raisr.bin";
    trainer.SolveAndSaveBin(custom_bin);

    // 3. 载入并测试 Camera 2x 权重做超分
    std::cout << "\n[3. 运行 Camera 特化权重 (raisr_cam_bank_x2.bin) 2x 重构]:" << std::endl;
    standalone::raisr::TrainedFilterBank cam_bank;
    cam_bank.LoadFromBin("data/raisr_cam_bank_x2.bin");

    standalone::raisr::RaisrConfig cfg;
    cfg.scale = 2;
    cam_bank.UpdateConfig(cfg);

    standalone::raisr::RaisrUpscaler upscaler(cfg, &cam_bank);

    int w = 16, h = 16;
    std::vector<uint8_t> in_img((size_t)w * h, 100);
    for (int i = 0; i < 16; ++i) in_img[i * w + i] = 255;

    std::vector<uint8_t> out_img;
    int ow = 0, oh = 0;
    upscaler.Upscale(in_img.data(), w, h, out_img, ow, oh);

    std::cout << "  - 输入尺寸: " << w << "x" << h << std::endl;
    std::cout << "  - Camera RAISR 2x 输出尺寸: " << ow << "x" << oh << " (输出 " << out_img.size() << " 像素)" << std::endl;

    // 4. 模拟 320 帧 15ms GPU Watchdog 性能监控
    std::cout << "\n[4. 15ms GPU Watchdog 320 帧防护监控模拟]:" << std::endl;
    standalone::raisr::RaisrWatchdog watchdog;
    watchdog.budget_ms = 15.0;
    watchdog.window_frames = 32;
    watchdog.cycle_frames = 320;
    watchdog.disable_strikes = 2;

    int strike_count = 0;
    for (int frame = 1; frame <= 320; ++frame) {
        double sim_gpu_time = (frame >= 129 && frame <= 192) ? 22.0 : 10.0;
        if (watchdog.disabled) sim_gpu_time = 2.0;

        bool raisr_enabled = watchdog.tick(sim_gpu_time);

        if (frame % 32 == 0) {
            std::cout << "  Frame " << std::setw(3) << frame 
                      << " | 窗口 32 帧 | 平均耗时: " << std::setw(5) << std::fixed << std::setprecision(1) << sim_gpu_time << " ms"
                      << " | Bad Windows (Strikes): " << watchdog.bad_windows
                      << " | RAISR 状态: " << (raisr_enabled ? "【开启 ON】" : "【已自适应停用 OFF】") << std::endl;
        }

        if (!raisr_enabled && strike_count == 0) {
            strike_count = watchdog.bad_windows;
            std::cout << "  --------------------------------------------------------" << std::endl;
            std::cout << "  🚨 [Watchdog 警报]: 在第 " << frame << " 帧捕捉到 2 次 Strike 窗口超时！" << std::endl;
            std::cout << "  🚨 已自动停用 RAISR 超分机制，耗时降至 2ms，恢复帧率流畅！" << std::endl;
            std::cout << "  --------------------------------------------------------" << std::endl;
        }
    }

    std::cout << "\n全套 C++ 5 种 bin 权重解析与 Watchdog 演示完成！" << std::endl;
    return 0;
}
