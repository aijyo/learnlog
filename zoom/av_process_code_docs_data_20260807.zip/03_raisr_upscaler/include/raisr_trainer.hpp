#pragma once
/**
 * @file raisr_trainer.hpp
 * @brief 自包含的 RAISR 离线训练器 (Ridge Regression / Normal Equation SPD Solver & 8-fold Augmentation)
 * 
 * 抽取自 raisr_train.cpp 核心逻辑，纯净 C++17 实现，用于从训练图像生成并写出 raisr_bank.bin 权重。
 */

#include "raisr_upscaler.hpp"
#include <vector>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <iostream>

namespace standalone::raisr {

/**
 * @brief 独立 RAISR 离线训练器类 (Trainer)
 */
class RaisrTrainer {
public:
    explicit RaisrTrainer(RaisrConfig cfg = {}) : cfg_(cfg) {
        int taps = cfg_.Taps();
        int buckets = cfg_.Buckets();
        int phases = cfg_.Phases();
        size_t total = (size_t)phases * buckets;

        ATA_.assign(total * taps * taps, 0.0);
        ATb_.assign(total * taps, 0.0);
        pop_.assign(total, 0);
    }

    /**
     * @brief 生成具有丰富几何斜线与高对比边缘的纯净合成训练图像
     */
    static void GenerateSyntheticTrainingImage(std::vector<float>& Y, int w, int h, uint32_t seed = 1) {
        Y.assign((size_t)w * h, 0.0f);
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                Y[(size_t)y * w + x] = 55.0f + 90.0f * x / w + 45.0f * y / h; // 渐变背景
            }
        }

        uint32_t s = seed * 2654435761u + 12345u;
        auto rnd = [&](float a, float b) {
            s = s * 1664525u + 1013904223u;
            return a + (b - a) * ((s >> 8) * (1.0f / 16777216.0f));
        };

        auto put = [&](int x, int y, float v) {
            if (x >= 0 && x < w && y >= 0 && y < h) Y[(size_t)y * w + x] = v;
        };

        for (int k = 0; k < 500; ++k) {
            int type = (int)rnd(0, 3);
            float val = rnd(10, 245);
            if (type == 0) { // 矩形框/块
                int rx = (int)rnd(0, w), ry = (int)rnd(0, h), rw = (int)rnd(3, 40), rh = (int)rnd(3, 40);
                for (int y = ry; y < ry + rh; ++y)
                    for (int x = rx; x < rx + rw; ++x) put(x, y, val);
            } else if (type == 1) { // 任意角度强细线 (文字笔画)
                float ang = rnd(0, 3.14159f), len = rnd(10, 80), cx = rnd(0, w), cy = rnd(0, h), th = rnd(0.5f, 2.0f);
                float dx = std::cos(ang), dy = std::sin(ang);
                for (float t = -len / 2; t < len / 2; t += 0.5f)
                    for (float dw = -th; dw <= th; dw += 0.5f)
                        put((int)(cx + t * dx - dw * dy), (int)(cy + t * dy + dw * dx), val);
            } else { // 强圆形/弧线
                float cx = rnd(0, w), cy = rnd(0, h), rr = rnd(3, 20);
                for (int y = (int)(cy - rr); y <= cy + rr; ++y)
                    for (int x = (int)(cx - rr); x <= cx + rr; ++x)
                        if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= rr * rr) put(x, y, val);
            }
        }
    }

    /**
     * @brief 累加训练图像中的样本至正规方程 Q = A^T * A 与 V = A^T * b
     */
    void AccumulateImage(const std::vector<float>& hr_img, int w, int h) {
        int s = cfg_.scale;
        int lW = w / s, lH = h / s;
        std::vector<float> lr_img((size_t)lW * lH);

        // 2x 降采样
        for (int y = 0; y < lH; ++y) {
            for (int x = 0; x < lW; ++x) {
                lr_img[(size_t)y * lW + x] = 0.25f * (hr_img[(size_t)(2 * y) * w + 2 * x] +
                                                      hr_img[(size_t)(2 * y) * w + 2 * x + 1] +
                                                      hr_img[(size_t)(2 * y + 1) * w + 2 * x] +
                                                      hr_img[(size_t)(2 * y + 1) * w + 2 * x + 1]);
            }
        }

        // 双线性预插值基准图
        std::vector<float> base;
        int bw = 0, bh = 0;
        RaisrUpscaler(cfg_, nullptr).UpscaleF(lr_img.data(), lW, lH, base, bw, bh);

        const int r = cfg_.patch / 2;
        const int taps = cfg_.Taps();
        const int buckets = cfg_.Buckets();

        std::vector<float> patch((size_t)taps);

        for (int y = r; y < bh - r; ++y) {
            for (int x = r; x < bw - r; ++x) {
                int b = Classify(base.data(), bw, bh, x, y, cfg_);
                int p = PhaseOf(x, y, s);

                int k = 0;
                for (int j = -r; j <= r; ++j) {
                    for (int i = -r; i <= r; ++i, ++k) {
                        patch[k] = base[(size_t)(y + j) * bw + (x + i)];
                    }
                }

                double target = hr_img[(size_t)y * w + x];
                size_t base_idx = ((size_t)p * buckets + b);

                double* A = &ATA_[base_idx * taps * taps];
                double* Bv = &ATb_[base_idx * taps];

                for (int rr = 0; rr < taps; ++rr) {
                    double pr = patch[rr];
                    Bv[rr] += pr * target;
                    double* Ar = A + (size_t)rr * taps;
                    for (int c = rr; c < taps; ++c) Ar[c] += pr * patch[c];
                }
                pop_[base_idx]++;
            }
        }
    }

    /**
     * @brief 求解正规方程并导出二进制 raisr_bank.bin 权重文件
     */
    bool SolveAndSaveBin(const std::string& out_bin_path) {
        const int taps = cfg_.Taps();
        const int buckets = cfg_.Buckets();
        const int phases = cfg_.Phases();
        const size_t total_filters = (size_t)phases * buckets;

        std::vector<float> bank(total_filters * taps, 0.0f);
        int solved = 0;

        std::vector<double> A((size_t)taps * taps);
        std::vector<double> bb((size_t)taps);

        for (int p = 0; p < phases; ++p) {
            for (int b = 0; b < buckets; ++b) {
                size_t base_idx = ((size_t)p * buckets + b);
                float* out_f = &bank[base_idx * taps];

                if (pop_[base_idx] < taps + 20) {
                    out_f[taps / 2] = 1.0f; // 样本不足退化为单位中心
                    continue;
                }

                double* srcA = &ATA_[base_idx * taps * taps];
                double* srcb = &ATb_[base_idx * taps];

                double diag = 0;
                for (int i = 0; i < taps; ++i) diag += srcA[(size_t)i * taps + i];
                diag /= taps;
                double lam = 1e-3 * diag + 1e-6; // 岭回归 Regularization

                for (int rr = 0; rr < taps; ++rr) {
                    bb[rr] = srcb[rr];
                    for (int c = 0; c < taps; ++c) {
                        A[(size_t)rr * taps + c] = (c >= rr ? srcA[(size_t)rr * taps + c] : srcA[(size_t)c * taps + rr]);
                    }
                    A[(size_t)rr * taps + rr] += lam;
                }

                if (SolveSPD(A, bb, taps)) {
                    double sum_val = 0;
                    for (int i = 0; i < taps; ++i) sum_val += bb[i];
                    if (sum_val > 0.5) {
                        for (int i = 0; i < taps; ++i) bb[i] /= sum_val; // 归一化
                    }
                    for (int i = 0; i < taps; ++i) out_f[i] = (float)bb[i];
                    solved++;
                } else {
                    out_f[taps / 2] = 1.0f;
                }
            }
        }

        // 写入二进制文件
        FILE* bf = std::fopen(out_bin_path.c_str(), "wb");
        if (!bf) return false;

        int hdr[4] = { phases, buckets, taps, cfg_.patch };
        float th[2] = { cfg_.flat_thresh, cfg_.str_thresh };

        std::fwrite(hdr, sizeof(int), 4, bf);
        std::fwrite(th, sizeof(float), 2, bf);
        std::fwrite(bank.data(), sizeof(float), bank.size(), bf);
        std::fclose(bf);

        std::cout << "  ✔ 训练求解成功！求解了 " << solved << "/" << total_filters 
                  << " 个滤镜核，权重已写出保存至: " << out_bin_path << std::endl;
        return true;
    }

private:
    static bool SolveSPD(std::vector<double>& A, std::vector<double>& b, int n) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j <= i; ++j) {
                double s = A[(size_t)i * n + j];
                for (int k = 0; k < j; ++k) s -= A[(size_t)i * n + k] * A[(size_t)j * n + k];
                if (i == j) {
                    if (s <= 0) return false;
                    A[(size_t)i * n + i] = std::sqrt(s);
                } else {
                    A[(size_t)i * n + j] = s / A[(size_t)j * n + j];
                }
            }
        }
        for (int i = 0; i < n; ++i) {
            double s = b[i];
            for (int k = 0; k < i; ++k) s -= A[(size_t)i * n + k] * b[k];
            b[i] = s / A[(size_t)i * n + i];
        }
        for (int i = n - 1; i >= 0; --i) {
            double s = b[i];
            for (int k = i + 1; k < n; ++k) s -= A[(size_t)k * n + i] * b[k];
            b[i] = s / A[(size_t)i * n + i];
        }
        return true;
    }

    RaisrConfig cfg_;
    std::vector<double> ATA_;
    std::vector<double> ATb_;
    std::vector<long> pop_;
};

} // namespace standalone::raisr
