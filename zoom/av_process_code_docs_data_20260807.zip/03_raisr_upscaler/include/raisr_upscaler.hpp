#pragma once
/**
 * @file raisr_upscaler.hpp
 * @brief 自包含的 RAISR 超级分辨率重构 (支持通用 49 桶 & Camera 特化 22 桶二选一 & .bin 动态载入 & Watchdog)
 * 
 * 零外部依赖，仅包含 C++ 标准库 <cstdint>, <vector>, <cmath>, <thread>, <cstddef>, <memory>, <cstdio>, <string>, <algorithm>。
 */

#include <cstdint>
#include <vector>
#include <cmath>
#include <cstddef>
#include <thread>
#include <algorithm>
#include <iostream>
#include <cstdio>
#include <string>

namespace standalone::raisr {

/**
 * @brief 通用 Screen RAISR 分类与滤波器组配置参数 (48 梯度桶 + 1 平坦桶)
 */
struct RaisrConfig {
    int scale          = 2;   // 放缩倍数 1x/2x/3x
    int patch          = 11;  // 滤波核 Patch 尺寸 (11x11 = 121 taps)
    int angle_bins     = 12;  // 主梯度角度分布桶 (0..11)
    int strength_bins  = 2;   // 梯度强度离散桶 (0,1)
    int coherence_bins = 2;   // 梯度方向一致性桶 (0,1)
    
    float flat_thresh  = 5.0f;  // 平坦区域门限
    float str_thresh   = 15.0f; // 强梯度门限

    int Taps()        const { return patch * patch; }                              // 121
    int GradBuckets() const { return angle_bins * strength_bins * coherence_bins; } // 48
    int FlatBucket()  const { return GradBuckets(); }                               // 48
    int Buckets()     const { return GradBuckets() + 1; }                           // 49
    int Phases()      const { return scale * scale; }                               // 4
};

/**
 * @brief Camera 摄像头特化轻量 RAISR 配置参数 (22 桶 = 11 角度 x 2 强度，无 Coherence 维)
 */
struct CamRaisrConfig {
    int   scale         = 2;    // 2x / 3x
    int   angle_bins    = 11;   // 角度桶 0..10
    int   strength_bins = 2;    // 强度 0..1
    float str_thresh    = 0.5f; // 0.5 门限
    int   Buckets()       const { return angle_bins * strength_bins; } // 22 桶
    int   Phases()        const { return scale * scale; }              // 2x 为 4，3x 为 9
    int   TapsPerPhase()  const { return scale == 1 ? 25 : 13; }       // 5x5(25) 或 菱形 13 点阵
};

/**
 * @brief 智能源图像分辨率 Scale 决断选择器 (按分辨率自适应降级)
 */
inline int SelectCamScale(int srcW, int srcH, int dstW, int dstH) {
    long srcPx = (long)srcW * srcH;
    if (srcPx > 921600) return 0; // >= 720p 原图则关闭超分
    if (srcPx <= 307200) {        // <= 480p 支持 2x/3x
        return (dstW >= srcW * 2.5f) ? 3 : 2;
    }
    return 2;
}

inline int PhaseOf(int x, int y, int scale) { 
    return (y % scale) * scale + (x % scale); 
}

/**
 * @brief 通用 49 桶 结构张量 (Structure Tensor) 梯度哈希分类器
 */
inline int Classify(const float* img, int w, int h, int cx, int cy, const RaisrConfig& cfg, double* strengthOut = nullptr) {
    const int r = cfg.patch / 2, P = 2 * r + 1;
    
    static thread_local int cachedR = -1;
    static thread_local std::vector<double> Wt;
    if (cachedR != r) {
        Wt.assign((size_t)P * P, 0.0);
        for (int j = -r; j <= r; ++j) {
            for (int i = -r; i <= r; ++i) {
                Wt[(size_t)(j + r) * P + (i + r)] = std::exp(-(i * i + j * j) / (2.0 * (r * 0.5) * (r * 0.5)));
            }
        }
        cachedR = r;
    }

    double gxx = 0, gyy = 0, gxy = 0;
    for (int j = -r; j <= r; ++j) {
        for (int i = -r; i <= r; ++i) {
            int x = cx + i, y = cy + j;
            if (x <= 0 || y <= 0 || x >= w - 1 || y >= h - 1) continue;
            double gx = img[(size_t)y * w + x + 1] - img[(size_t)y * w + x - 1];
            double gy = img[(size_t)(y + 1) * w + x] - img[(size_t)(y - 1) * w + x];
            double wgt = Wt[(size_t)(j + r) * P + (i + r)];
            gxx += wgt * gx * gx; 
            gyy += wgt * gy * gy; 
            gxy += wgt * gx * gy;
        }
    }

    double t = gxx + gyy, d = std::sqrt((gxx - gyy) * (gxx - gyy) + 4 * gxy * gxy);
    double l1 = (t + d) / 2.0, l2 = (t - d) / 2.0;
    double sl1 = std::sqrt(l1 > 0 ? l1 : 0), sl2 = std::sqrt(l2 > 0 ? l2 : 0);
    double strength = sl1;
    double coherence = (sl1 + sl2 > 1e-9) ? (sl1 - sl2) / (sl1 + sl2) : 0.0;
    
    if (strengthOut) *strengthOut = strength;
    if (strength < cfg.flat_thresh) return cfg.FlatBucket();

    double ang = 0.5 * std::atan2(2 * gxy, gxx - gyy);
    if (ang < 0) ang += 3.14159265358979;
    
    int ab = (int)std::lround(ang * (11.0 / 3.14159265358979));
    if (ab < 0) ab = 0; if (ab > 11) ab = 11;
    
    int sb = (strength >= cfg.str_thresh) ? 1 : 0;
    int cb = (coherence >= 0.5f)          ? 1 : 0;
    
    return cb * 24 + sb * 12 + ab;
}

/**
 * @brief Camera 22 桶轻量结构张量分类器
 */
inline int ClassifyCam(const float* img, int w, int h, int cx, int cy, const CamRaisrConfig& cfg) {
    double a = 0, b = 0, c = 0;
    for (int dy = -1; dy <= 1; ++dy) {
        for (int dx = -1; dx <= 1; ++dx) {
            int x = std::clamp(cx + dx, 1, w - 2);
            int y = std::clamp(cy + dy, 1, h - 2);
            double gx = (img[y * w + x + 1] - img[y * w + x - 1]) * 0.5;
            double gy = (img[(y + 1) * w + x] - img[(y - 1) * w + x]) * 0.5;
            a += gx * gx; b += gx * gy; c += gy * gy;
        }
    }
    double tr = a + c;
    double disc = std::sqrt(std::max(0.0, 0.25 * tr * tr - (a * c - b * b)));
    double lam1 = 0.5 * tr + disc;
    double strength = std::sqrt(std::max(0.0, lam1));

    double theta = 0.5 * std::atan2(2.0 * b, a - c);
    if (theta < 0) theta += 3.14159265358979;
    
    int abin = (int)std::lround(theta * 10.0 / 3.14159265358979);
    abin = std::clamp(abin, 0, 10);
    int sbin = (strength > cfg.str_thresh) ? 1 : 0;
    return abin + cfg.angle_bins * sbin; // 22 桶 (0..21)
}

/**
 * @brief 抽象滤镜组接口 (Filter Bank)
 */
struct IFilterBank {
    virtual ~IFilterBank() = default;
    virtual const float* filter(int phase, int bucket) const = 0;
    virtual int taps() const = 0;
};

/**
 * @brief 从离线二进制 raisr_bank.bin 或 raisr_cam_bank*.bin 动态解析载入的通用与 Camera 权重解析类
 */
class TrainedFilterBank : public IFilterBank {
public:
    TrainedFilterBank() = default;

    /**
     * @brief 加载通用或 Camera 的二进制 .bin 权重文件
     */
    bool LoadFromBin(const std::string& bin_path) {
        FILE* f = std::fopen(bin_path.c_str(), "rb");
        if (!f) return false;

        int hdr[4];   // NPHASE, NBUCKET, TAPS, PATCH
        float th[2];  // flat_thresh, str_thresh
        if (std::fread(hdr, sizeof(int), 4, f) != 4) { std::fclose(f); return false; }
        if (std::fread(th, sizeof(float), 2, f) != 2) { std::fclose(f); return false; }

        nphase_      = hdr[0];
        nbuck_       = hdr[1];
        taps_        = hdr[2];
        patch_       = hdr[3];
        flat_thresh_ = th[0];
        str_thresh_  = th[1];

        size_t total = (size_t)nphase_ * nbuck_ * taps_;
        filters_.resize(total);

        if (std::fread(filters_.data(), sizeof(float), total, f) != total) {
            std::fclose(f);
            return false;
        }

        std::fclose(f);
        loaded_ = true;
        is_camera_ = (nbuck_ == 22); // 22 桶即为 Camera 特化版
        return true;
    }

    void UpdateConfig(RaisrConfig& cfg) const {
        if (!loaded_) return;
        cfg.patch = patch_;
        cfg.flat_thresh = flat_thresh_;
        cfg.str_thresh = str_thresh_;
    }

    const float* filter(int phase, int bucket) const override {
        if (!loaded_ || phase < 0 || phase >= nphase_ || bucket < 0 || bucket >= nbuck_) {
            return nullptr;
        }
        return &filters_[(size_t)(phase * nbuck_ + bucket) * taps_];
    }

    int taps() const override { return taps_; }
    bool is_loaded() const { return loaded_; }
    bool is_camera() const { return is_camera_; }
    int buckets() const { return nbuck_; }
    int phases() const { return nphase_; }
    float flat_thresh() const { return flat_thresh_; }
    float str_thresh() const { return str_thresh_; }

private:
    bool loaded_ = false;
    bool is_camera_ = false;
    int nphase_ = 4;
    int nbuck_ = 49;
    int taps_ = 121;
    int patch_ = 11;
    float flat_thresh_ = 0.0f;
    float str_thresh_ = 0.0f;
    std::vector<float> filters_;
};

/**
 * @brief 性能/耗时 Watchdog 控制器 (15ms 预算，32 帧窗口，2 Strike 自适应关停)
 */
struct RaisrWatchdog {
    double budget_ms       = 15.0; // 单帧耗时预算 (15ms)
    int    window_frames   = 32;   // 统计窗口 (32 帧)
    int    cycle_frames    = 320;  // 评估周期 (320 帧，10 个窗口)
    int    disable_strikes = 2;    // Strike 关停阈值 (超过 2 次 Strike 触发停用)

    double accum_ms = 0; 
    int frame = 0; 
    int bad_windows = 0; 
    bool disabled = false;

    bool tick(double last_frame_ms) {
        if (disabled) return false;
        accum_ms += last_frame_ms;
        
        if (++frame % window_frames == 0) {
            if (accum_ms >= window_frames * budget_ms) {
                ++bad_windows;
            }
            accum_ms = 0;
        }
        
        if (frame >= cycle_frames) {
            if (bad_windows >= disable_strikes) {
                disabled = true;
            }
            frame = 0; 
            bad_windows = 0;
        }
        return !disabled;
    }

    void reset() { 
        accum_ms = 0; 
        frame = 0; 
        bad_windows = 0; 
        disabled = false; 
    }
};

/**
 * @brief RAISR 2x 超分放大器类
 */
class RaisrUpscaler {
public:
    RaisrUpscaler(RaisrConfig cfg, const IFilterBank* bank) : cfg_(cfg), bank_(bank) {}

    void UpscaleF(const float* in, int w, int h, std::vector<float>& out, int& ow, int& oh) const {
        const int s = cfg_.scale; 
        ow = w * s; 
        oh = h * s; 
        out.assign((size_t)ow * oh, 0.0f);

        // 1) 基础双线性插值
        for (int oy = 0; oy < oh; ++oy) {
            float fy = (oy + 0.5f) / s - 0.5f; 
            int y0 = (int)std::floor(fy); 
            float wy = fy - y0;
            for (int ox = 0; ox < ow; ++ox) {
                float fx = (ox + 0.5f) / s - 0.5f; 
                int x0 = (int)std::floor(fx); 
                float wx = fx - x0;
                
                int px0 = std::clamp(x0, 0, w - 1);
                int px1 = std::clamp(x0 + 1, 0, w - 1);
                int py0 = std::clamp(y0, 0, h - 1);
                int py1 = std::clamp(y0 + 1, 0, h - 1);
                
                float p00 = in[(size_t)py0 * w + px0];
                float p10 = in[(size_t)py0 * w + px1];
                float p01 = in[(size_t)py1 * w + px0];
                float p11 = in[(size_t)py1 * w + px1];
                
                float v = (1.0f - wx) * (1.0f - wy) * p00 + wx * (1.0f - wy) * p10 +
                          (1.0f - wx) * wy * p01 + wx * wy * p11;
                out[(size_t)oy * ow + ox] = v;
            }
        }

        if (!bank_) return;
        const int r = cfg_.patch / 2;
        std::vector<float> base = out;

        // 2) 查表调用预训练 11x11 线性滤镜组微调边缘
        for (int oy = r; oy < oh - r; ++oy) {
            for (int ox = r; ox < ow - r; ++ox) {
                int bucket = Classify(base.data(), ow, oh, ox, oy, cfg_);
                const float* f = bank_->filter(PhaseOf(ox, oy, s), bucket);
                if (!f) continue;

                float acc = 0; 
                int k = 0;
                for (int j = -r; j <= r; ++j) {
                    for (int i = -r; i <= r; ++i, ++k) {
                        acc += f[k] * base[(size_t)(oy + j) * ow + (ox + i)];
                    }
                }
                out[(size_t)oy * ow + ox] = std::clamp(acc, 0.0f, 255.0f);
            }
        }
    }

    void Upscale(const uint8_t* in, int w, int h, std::vector<uint8_t>& out, int& ow, int& oh) const {
        std::vector<float> fin((size_t)w * h);
        for (size_t i = 0; i < fin.size(); ++i) fin[i] = (float)in[i];
        
        std::vector<float> fout;
        UpscaleF(fin.data(), w, h, fout, ow, oh);
        
        out.assign(fout.size(), 0);
        for (size_t i = 0; i < fout.size(); ++i) {
            out[i] = (uint8_t)std::clamp((int)(fout[i] + 0.5f), 0, 255);
        }
    }

private:
    RaisrConfig cfg_;
    const IFilterBank* bank_;
};

} // namespace standalone::raisr
