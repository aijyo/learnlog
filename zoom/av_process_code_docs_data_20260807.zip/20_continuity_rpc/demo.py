#!/usr/bin/env python3
from pathlib import Path
import argparse
from PIL import Image,ImageDraw
def vi(v):
 b=bytearray()
 while v>127:b.append((v&127)|128);v>>=7
 b.append(v);return b
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 device=b'device-A';wire=vi(8)+vi(1)+vi(18)+vi(len(device))+device;steps=['Client','RPCRequest envelope','RegisterReq','Server assigns device id','MediaActionReq','Callback sink'];im=Image.new('RGB',(1150,300),'white');d=ImageDraw.Draw(im)
 for i,s in enumerate(steps):x=25+i*185;d.rectangle((x,100,x+150,165),fill=(65,125,205));d.text((x+8,120),s,fill='white')
 for i in range(5):d.line((175+i*185,132,210+i*185,132),fill='black',width=3)
 d.text((25,25),'wire hex: '+wire.hex(),fill='black');im.save(a.out/'continuity_rpc.png');print(wire.hex())
if __name__=='__main__':main()
