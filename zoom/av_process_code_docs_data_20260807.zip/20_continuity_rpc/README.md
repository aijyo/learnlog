# Continuity Media protobuf RPC

Python 显示 request/response 时序和 wire hex；C++ 演示 protobuf varint/length-delimited envelope 的工业错误边界。

`[INFERRED]`：RpcType 数值；`BOUNDARY`：真实 message 必须由 `continuity_media.pb.h` / protobuf 生成代码提供，本目录的最小 wire 只用于说明消费方式，不冒充完整 schema。证据：`recon/conti/conti_session.hpp`。
