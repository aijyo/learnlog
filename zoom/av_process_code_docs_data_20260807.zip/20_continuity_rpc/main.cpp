#include <cstdint>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
void varint(std::vector<uint8_t>&b,uint64_t v){while(v>127){b.push_back(uint8_t(v)|128);v>>=7;}b.push_back(uint8_t(v));}
uint64_t read(const std::vector<uint8_t>&b,size_t&p){uint64_t v=0;for(int s=0;s<64;s+=7){if(p>=b.size())throw std::runtime_error("truncated");auto x=b[p++];v|=uint64_t(x&127)<<s;if(!(x&128))return v;}throw std::runtime_error("overflow");}
int main(){std::vector<uint8_t>w;varint(w,8);varint(w,1);std::string id="device-A";varint(w,18);varint(w,id.size());w.insert(w.end(),id.begin(),id.end());std::cout<<"wire=";for(auto x:w)std::cout<<std::hex<<std::setw(2)<<std::setfill('0')<<int(x);std::cout<<"\n";size_t p=0;std::cout<<"field1="<<read(w,p)<<":"<<read(w,p)<<" field2="<<read(w,p)<<" len="<<read(w,p)<<"\n";}
