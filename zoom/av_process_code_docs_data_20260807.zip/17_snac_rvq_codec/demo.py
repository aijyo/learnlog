#!/usr/bin/env python3
from pathlib import Path
import argparse,math,wave
import numpy as np
from PIL import Image,ImageDraw
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 t=np.arange(24000)/16000.;x=.55*np.sin(2*np.pi*220*t)+.2*np.sin(2*np.pi*440*t);steps=[.5,.25,.125,.0625];res=x.copy();recon=np.zeros_like(x);errs=[]
 for s in steps:q=np.round(res/s)*s;recon+=q;res=x-recon;errs.append(float(np.sqrt(np.mean(res*res))))
 with wave.open(str(a.out/'rvq_reconstruction.wav'),'wb') as w:w.setparams((1,2,16000,len(x),'NONE',''));w.writeframes((np.clip(recon,-1,1)*32767).astype('<i2').tobytes())
 im=Image.new('RGB',(800,480),'white');d=ImageDraw.Draw(im);d.text((30,20),'Mock multi-resolution RVQ (weights boundary)',fill='black')
 for i,e in enumerate(errs):d.rectangle((100+i*150,400-int(e*3000),200+i*150,400),fill=(60,130,210));d.text((115+i*150,420),f'depth {i+1}',fill='black');d.text((110+i*150,370-int(e*3000)),f'{e:.4f}',fill='black')
 im.save(a.out/'rvq_depth_curve.png');print(errs)
if __name__=='__main__':main()
