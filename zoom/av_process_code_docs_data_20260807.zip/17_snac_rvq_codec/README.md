# SNAC 控制门 → 多分辨率 RVQ → payload

Python 用可逆 mock signal 展示 residual depth scalability 并输出 WAV/误差图；C++ 实现 coarse→fine 最近码本搜索。

`[BODY]`：多分辨率 RVQ 控制结构、深度可伸缩和 payload 状态；`BOUNDARY ⛔W/⛔K`：神经 encoder/decoder 权重和融合 AVX kernel 不重建，mock 仅用于讲清调用链。证据：`recon/snac/*.hpp`、`viper_codec_control.hpp`。
