#include <array>
#include <cmath>
#include <iostream>
#include <vector>
using V=std::array<double,2>;double d2(V a,V b){return(a[0]-b[0])*(a[0]-b[0])+(a[1]-b[1])*(a[1]-b[1]);}
int main(){std::vector<std::vector<V>>books{{{-1,-1},{-1,1},{1,-1},{1,1}},{{-.5,0},{.5,0},{0,-.5},{0,.5}}};V x{.72,.28},sum{0,0};for(size_t depth=0;depth<books.size();++depth){V r{x[0]-sum[0],x[1]-sum[1]};int best=0;for(int i=1;i<4;i++)if(d2(r,books[depth][i])<d2(r,books[depth][best]))best=i;sum[0]+=books[depth][best][0];sum[1]+=books[depth][best][1];std::cout<<"depth="<<depth+1<<" code="<<best<<" recon="<<sum[0]<<","<<sum[1]<<" error="<<std::sqrt(d2(x,sum))<<"\n";}std::cout<<"neural encoder/decoder weights are external boundaries\n";}
