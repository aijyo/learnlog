#!/usr/bin/env python3
"""
感知自适应 QP 阶梯控制 - 基于真实本地视频 (dance_outdoor.mp4) 热力视频 Demo
(Perceptual Adaptive-QP Ladder Video Heatmap Demo)

用法:
    python demo.py
"""

import cv2
import numpy as np
from PIL import Image, ImageDraw
import os

VIDEO_PATH = r"D:\code\work\research\ai-harness\data\videos\dance_outdoor.mp4"

def compute_block_variance_and_sad(cur_luma, prev_luma, block_size=16):
    """计算 16x16 宏块纹理方差与运动 SAD"""
    h, w = cur_luma.shape
    bw, bh = w // block_size, h // block_size
    var_map = np.zeros((bh, bw), dtype=np.float32)
    sad_map = np.zeros((bh, bw), dtype=np.float32)

    for by in range(bh):
        for bx in range(bw):
            patch_c = cur_luma[by*block_size:(by+1)*block_size, bx*block_size:(bx+1)*block_size]
            var_map[by, bx] = np.var(patch_c)

            if prev_luma is not None:
                patch_p = prev_luma[by*block_size:(by+1)*block_size, bx*block_size:(bx+1)*block_size]
                sad_map[by, bx] = np.mean(np.abs(patch_c - patch_p))

    return var_map, sad_map

def build_ladder(metric_sum, block_count, multipliers):
    """构建当前帧自适应 6 阈值阶梯: thr[i] = mean * mult[i] + 1"""
    if block_count <= 0 or metric_sum <= 0:
        return [0] * 6
    mean_val = metric_sum / float(block_count)
    return [int(mean_val * m) + 1 for m in multipliers]

def apply_ladder(val, thresholds):
    """映射特征值至阶梯 level [-3, +3]"""
    count = sum(1 for t in thresholds if val >= t)
    return count - 3

def generate_qp_heatmap_frame(img_rgb, qp_map, block_size=16):
    """在 RGB 帧图上叠加渲染 16x16 宏块 QP Delta 热力图 (蓝色: 降QP保画质, 红色: 升QP省码率)"""
    h, w, c = img_rgb.shape
    bh, bw = qp_map.shape

    overlay = img_rgb.copy().astype(np.float32)

    for by in range(bh):
        for bx in range(bw):
            q = qp_map[by, bx]
            # normalize q from [-6, +6] to [0.0, 1.0]
            norm_q = (q + 6.0) / 12.0
            norm_q = max(0.0, min(1.0, norm_q))

            # 色彩映射: 蓝色(降QP) -> 绿/黄 -> 红色(升QP)
            if norm_q < 0.5:
                r_c, g_c, b_c = 0, int(norm_q * 2 * 255), int((0.5 - norm_q) * 2 * 255)
            else:
                r_c, g_c, b_c = int((norm_q - 0.5) * 2 * 255), int((1.0 - norm_q) * 2 * 255), 0

            py0, py1 = by * block_size, (by + 1) * block_size
            px0, px1 = bx * block_size, (bx + 1) * block_size

            overlay[py0:py1, px0:px1, 0] = overlay[py0:py1, px0:px1, 0] * 0.55 + r_c * 0.45
            overlay[py0:py1, px0:px1, 1] = overlay[py0:py1, px0:px1, 1] * 0.55 + g_c * 0.45
            overlay[py0:py1, px0:px1, 2] = overlay[py0:py1, px0:px1, 2] * 0.55 + b_c * 0.45

    out_img = np.clip(overlay, 0, 255).astype(np.uint8)
    
    # 绘制顶部文字与图例栏
    pil_img = Image.fromarray(out_img)
    draw = ImageDraw.Draw(pil_img)
    draw.rectangle([0, 0, w, 40], fill=(0, 0, 0))
    draw.text((15, 12), "Adaptive QP Ladder Heatmap - dance_outdoor.mp4 (Blue: QP-3, Red: QP+3)", fill=(255, 255, 255))

    return np.array(pil_img)

if __name__ == '__main__':
    print("==========================================================")
    print("  感知自适应 QP 阶梯控制 - 本地 dance_outdoor.mp4 视频 Demo")
    print("==========================================================")

    if not os.path.exists(VIDEO_PATH):
        print(f"❌ 未找到本地视频文件: {VIDEO_PATH}")
        exit(1)

    print(f"\n1. 正在从本地视频文件读取约 10 秒 (250 帧) 视频数据...")
    cap = cv2.VideoCapture(VIDEO_PATH)
    
    raw_frames = []
    # 适当 resize 提高计算与渲染效率 (如 640x360)
    target_w, target_h = 640, 360
    
    while len(raw_frames) < 250: # 约 10 秒
        ret, frame = cap.read()
        if not ret: break
        resized = cv2.resize(frame, (target_w, target_h), interpolation=cv2.INTER_AREA)
        rgb_frame = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        raw_frames.append(rgb_frame)
    cap.release()

    print(f"   ✔ 成功读取 {len(raw_frames)} 帧 (10 秒) 真实室外舞蹈视频！")

    print("\n2. 正在进行 Pass 1 (动态 6 阈值阶梯构建) & Pass 2 (宏块 QP Delta 热力图生成)...")
    tex_mult = [0.25, 0.75, 1.0, 1.5, 2.5, 4.0]
    mot_mult = [0.25, 0.75, 1.0, 1.5, 2.5, 4.0]

    heatmap_frames_pil = []
    prev_luma = None

    for idx, frame_rgb in enumerate(raw_frames):
        luma = 0.299 * frame_rgb[:,:,0] + 0.587 * frame_rgb[:,:,1] + 0.114 * frame_rgb[:,:,2]
        
        var_map, sad_map = compute_block_variance_and_sad(luma, prev_luma, block_size=16)
        bh, bw = var_map.shape
        nb = bh * bw

        # 构建当前帧的自适应阶梯
        tex_ladders = build_ladder(np.sum(var_map), nb, tex_mult)
        mot_ladders = build_ladder(np.sum(sad_map), nb, mot_mult)

        qp_map = np.zeros((bh, bw), dtype=np.int32)
        for by in range(bh):
            for bx in range(bw):
                lvl_t = apply_ladder(var_map[by, bx], tex_ladders)
                lvl_m = apply_ladder(sad_map[by, bx], mot_ladders)
                qp_map[by, bx] = lvl_t + lvl_m

        # 叠加生成热力帧
        heatmap_rgb = generate_qp_heatmap_frame(frame_rgb, qp_map, block_size=16)
        heatmap_pil = Image.fromarray(heatmap_rgb)
        heatmap_frames_pil.append(heatmap_pil)

        if idx == 50: # 导出第 50 帧作为关键对比静态图
            heatmap_pil.save("qp_heatmap_256x256.png")
            
            comp = Image.new('RGB', (target_w * 2, target_h))
            comp.paste(Image.fromarray(frame_rgb), (0, 0))
            comp.paste(heatmap_pil, (target_w, 0))
            comp.save("qp_ladder_comparison.png")

        prev_luma = luma

    print("\n3. 正在将连续分析热力帧导出为动态 GIF 动图与 10 秒 MP4 视频...")
    
    # 导出 GIF 动图 (抽帧控制大小)
    gif_path = "qp_ladder_dance.gif"
    sub_sample = heatmap_frames_pil[::2] # 12.5 fps GIF
    sub_sample[0].save(
        gif_path,
        save_all=True,
        append_images=sub_sample[1:],
        duration=80, # ~12.5 fps
        loop=0
    )

    # 导出 10 秒 25fps 高清 MP4 视频
    mp4_path = "qp_ladder_dance.mp4"
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_writer = cv2.VideoWriter(mp4_path, fourcc, 25.0, (target_w, target_h))
    for pimg in heatmap_frames_pil:
        bgr = cv2.cvtColor(np.array(pimg), cv2.COLOR_RGB2BGR)
        out_writer.write(bgr)
    out_writer.release()

    print(f"\n✔ 处理完成！全套真实 10 秒视频 Demo 产物导出完毕:")
    print(f"  └─ qp_ladder_dance.gif           : 包含实时动态 QP Delta 调控热力图演变的 GIF 动图")
    print(f"  └─ qp_ladder_dance.mp4           : 导出的 10 秒 25fps 高清热力图 MP4 视频")
    print(f"  └─ qp_heatmap_256x256.png        : 单帧高清 QP 热力图")
    print(f"  └─ qp_ladder_comparison.png      : 原图 vs QP 热力图 2 并排对比图")
