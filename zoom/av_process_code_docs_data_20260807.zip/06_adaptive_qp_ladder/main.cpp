#include "adaptive_qp_ladder.hpp"
#include <iostream>
#include <vector>
#include <iomanip>

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "  感知自适应 QP 阶梯控制 (Adaptive QP Ladder) Demo (C++)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    // 1. 验证 6 阈值阶梯逻辑 (QpLadder)
    std::cout << "\n[1. 验证 6 阈值阶梯 Primitive (QpLadder)]:" << std::endl;
    standalone::adaptive_qp::QpLadder ladder;
    ladder.thr = {{10, 30, 50, 100, 200, 400}};

    std::vector<int> test_vals = {5, 20, 40, 80, 150, 300, 500};
    for (int v : test_vals) {
        int lvl = ladder.level(v);
        std::cout << "  - 输入特征值 Metric: " << std::setw(4) << v 
                  << " -> 映射阶梯 Level: " << std::setw(2) << std::showpos << lvl << std::noshowpos << std::endl;
    }

    // 2. 验证整帧 Pass 1 & Pass 2 双轴宏块 QP Map 生成
    int w = 64, h = 64, stride = 64;
    std::vector<uint8_t> cur_frame((size_t)w * h, 120);
    std::vector<uint8_t> ref_frame((size_t)w * h, 120);

    // 在右下角区域 (x>=32, y>=32) 制造强纹理与强运动
    for (int y = 32; y < h; ++y) {
        for (int x = 32; x < w; ++x) {
            cur_frame[y * w + x] = (x + y) % 2 == 0 ? 255 : 0; // 棋盘高频纹理
            ref_frame[y * w + x] = 120;                        // 产生强 SAD 运动
        }
    }

    std::cout << "\n[2. 验证整帧 Pass 1 & Pass 2 16x16 宏块 QP Map 调控]:" << std::endl;
    auto adapt_quant = standalone::adaptive_qp::MakeAdaptQuant(standalone::adaptive_qp::AdaptQuantKind::TextureMotion);

    std::vector<int> qp_deltas;
    float mean_delta = adapt_quant.Compute(cur_frame.data(), ref_frame.data(), stride, w, h, qp_deltas);

    int bw = w / 16, bh = h / 16;
    std::cout << "  - 整帧平均 QP 调控 Delta: " << std::fixed << std::setprecision(2) << mean_delta << std::endl;
    std::cout << "  - 16x16 宏块 QP Delta 映射网格 (4x4 宏块):" << std::endl;
    for (int by = 0; by < bh; ++by) {
        std::cout << "      ";
        for (int bx = 0; bx < bw; ++bx) {
            int delta = qp_deltas[by * bw + bx];
            std::cout << std::setw(4) << std::showpos << delta << std::noshowpos << " ";
        }
        std::cout << "\n";
    }

    std::cout << "\n演示完成！" << std::endl;
    return 0;
}
