# 06_adaptive_qp_ladder — 感知自适应 QP 阶梯控制独立项目

> 证据校准：TextureMotion 核心分类/偏移为 `[BODY]`；demo 中的 metric 计算、倍率表及 static/background/ROI 策略属于 `[PARTIAL]` 教学近似。

本目录为一个**完全自包含 (Standalone)** 的独立小项目，展示实时音视频编码器中用于率失真优化 (RDO) 的 **感知自适应 QP 阶梯控制 (Adaptive QP Ladder & TextureMotion Classifier)** 算法。

---

## 目录结构

```
06_adaptive_qp_ladder/
├── CMakeLists.txt              # 独立 CMake 构建脚本
├── include/
│   └── adaptive_qp_ladder.hpp  # 零依赖自包含 C++ 算法头文件
├── main.cpp                    # C++ 控制台调试示例 (验证 6 阈值阶梯与 Pass1/2 调控)
├── demo.py                     # Python 24-bit 全彩肖像热力图分析 Demo
├── README.md                   # 本独立小项目说明文档
├── qp_heatmap_256x256.png      # QP Delta 调控彩色热力覆盖图
├── qp_ladder_comparison.png    # 3 并排真实画面对比图 (肖像原图 -> 纹理方差 -> QP 热力图)
├── qp_ladder_panel.png         # 6 阈值阶梯步阶与 Thr 分布面板图
└── adaptive_qp_wiki.html       # 暗色极客风格原理与 Wiki 说明网页
```

---

## 编译与运行方式

### 1. Python 示例运行

直接运行 Python 算法脚本（只需安装 NumPy / Pillow）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\adaptive_qp_ladder_demo.exe

# Linux/macOS 运行:
./build/adaptive_qp_ladder_demo
```

---

## 算法技术关键点

1. **6 阈值自适应阶梯 Primitive (`QpLadder`)**: 将宏块特征值映射到区间 $[-3, +3]$ 的 QP Delta 调整量：
   $$\text{level} = -3 + \sum_{i=0}^5 [val \ge thr[i]]$$
2. **每帧自适应动态门限构建 (`BuildLadder`)**: 门限由当前帧平均特征值乘以固定 6 倍率表生成：
   $$thr[i] = \text{clamp}_{u16} \left( \frac{\sum Metric}{N} \cdot mult[i] + 1 \right)$$
3. **双轴联合调控与多策略变体**: 支持 Texture-Motion 双轴调控，以及 ROI/人像降 QP 保画质、背景区升高 QP 节省码率等多重场景策略变体。
