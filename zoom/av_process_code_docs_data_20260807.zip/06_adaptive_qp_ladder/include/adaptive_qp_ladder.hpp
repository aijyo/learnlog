#pragma once
/**
 * @file adaptive_qp_ladder.hpp
 * @brief 自包含的感知自适应 QP 阶梯控制算法 (Perceptual Adaptive-QP Ladder & Texture-Motion Classifier)
 * 
 * 零外部依赖，仅包含 C++ 标准库 <cstdint>, <vector>, <array>, <cmath>, <algorithm>, <cstddef>。
 */

#include <cstdint>
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include <cstddef>

namespace standalone::adaptive_qp {

/**
 * @brief 6 阈值自适应阶梯 (QpLadder)
 * 将宏块特征值映射到 [-3, +3] 的 QP Delta 量: level = -3 + count(val >= thr[i])
 */
struct QpLadder {
    std::array<int, 6> thr{{0, 0, 0, 0, 0, 0}};

    int level(int val) const {
        int lvl = (val >= thr[0]) - 3 + 1;
        if (val < thr[1]) lvl = (val >= thr[0]) - 3;
        if (val >= thr[2]) ++lvl;
        if (val >= thr[3]) ++lvl;
        if (val >= thr[4]) ++lvl;
        if (val >= thr[5]) ++lvl;
        return lvl; // 范围 [-3, +3]
    }
};

/**
 * @brief 动态生成当前帧的 6 阈值阶梯: thr[i] = clamp_u16( frame_mean * mult[i] + 1 )
 */
inline QpLadder BuildLadder(double metric_sum, int block_count, const std::array<double, 6>& mult) {
    QpLadder L;
    if (block_count <= 0) return L;
    for (int i = 0; i < 6; ++i) {
        int t = (int)(metric_sum * mult[i] / (double)block_count) + 1;
        L.thr[i] = (unsigned)t <= 0xFFFFu ? t : 0xFFFF;
    }
    return L;
}

/**
 * @brief 宏块空间纹理方差计算
 */
inline int BlockVariance(const uint8_t* y, int stride, int bx, int by, int bs, int w, int h) {
    long sum = 0, sum2 = 0; 
    int n = 0;
    for (int j = 0; j < bs && (by + j) < h; ++j) {
        for (int i = 0; i < bs && (bx + i) < w; ++i) {
            int p = y[(size_t)(by + j) * stride + (bx + i)];
            sum += p; 
            sum2 += (long)p * p; 
            ++n;
        }
    }
    if (!n) return 0;
    long mean = sum / n;
    return (int)((sum2 / n) - mean * mean);
}

/**
 * @brief 宏块时域运动 SAD 计算
 */
inline int BlockMotionSAD(const uint8_t* y, const uint8_t* ref, int stride,
                          int bx, int by, int bs, int w, int h) {
    if (!ref) return 0;
    long sad = 0; 
    int n = 0;
    for (int j = 0; j < bs && (by + j) < h; ++j) {
        for (int i = 0; i < bs && (bx + i) < w; ++i) {
            size_t o = (size_t)(by + j) * stride + (bx + i);
            int d = (int)y[o] - (int)ref[o]; 
            sad += (d < 0 ? -d : d); 
            ++n;
        }
    }
    return n ? (int)(sad / n) : 0;
}

enum class AqMode { TextureOnly = 1, Both = 0, MotionOnly = 2 };
enum class AdaptQuantKind { TextureMotion, Background, Roi, ScreenStatic, Common };

/**
 * @brief 纹理-运动自适应 QP 控制器类 (TextureMotionAdaptQuant)
 */
struct TextureMotionAdaptQuant {
    std::array<double, 6> texture_mult{{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}}; // 离散倍率
    std::array<double, 6> motion_mult {{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}};
    int block_size = 16;
    AqMode mode = AqMode::Both;

    /**
     * @brief 两遍扫描 Pass 1 & Pass 2 计算整帧所有宏块的 QP Delta 调控图
     */
    float Compute(const uint8_t* y, const uint8_t* ref, int stride, int w, int h,
                  std::vector<int>& qp_delta) const {
        int bw = (w + block_size - 1) / block_size;
        int bh = (h + block_size - 1) / block_size;
        size_t nb = (size_t)bw * bh;
        qp_delta.assign(nb, 0);
        if (!nb) return 0.0f;

        // Pass 1: 统计全局特征均值
        std::vector<int> tex(nb), mot(nb);
        double tex_sum = 0, mot_sum = 0;
        for (int by = 0, b = 0; by < h; by += block_size) {
            for (int bx = 0; bx < w; bx += block_size, ++b) {
                int v = BlockVariance(y, stride, bx, by, block_size, w, h);
                int s = BlockMotionSAD(y, ref, stride, bx, by, block_size, w, h);
                tex[b] = v; 
                mot[b] = s; 
                tex_sum += v; 
                mot_sum += s;
            }
        }

        // 构建当前帧自适应阶梯
        QpLadder texL = BuildLadder(tex_sum, (int)nb, texture_mult);
        QpLadder motL = BuildLadder(mot_sum, (int)nb, motion_mult);

        // Pass 2: 双轴融合计算每个宏块的 QP Delta
        bool useTex = (mode == AqMode::TextureOnly || mode == AqMode::Both);
        bool useMot = (mode == AqMode::MotionOnly  || mode == AqMode::Both);
        long acc = 0;
        for (size_t b = 0; b < nb; ++b) {
            int d = (useTex ? texL.level(tex[b]) : 0) + (useMot ? motL.level(mot[b]) : 0);
            qp_delta[b] = d; 
            acc += d;
        }
        return (float)acc / (float)nb;
    }
};

/**
 * @brief 策略工厂构造不同场景类型的 QP 控制器
 */
inline TextureMotionAdaptQuant MakeAdaptQuant(AdaptQuantKind k, int block_size = 16) {
    TextureMotionAdaptQuant q; 
    q.block_size = block_size;
    switch (k) {
        case AdaptQuantKind::TextureMotion:
            q.texture_mult = {{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}};
            q.motion_mult  = {{0.25, 0.75, 1.0, 1.5, 2.5, 4.0}};
            break;
        case AdaptQuantKind::Background: // 背景: 快速升 QP (+3) 节省码率
            q.texture_mult = {{0.15, 0.5, 0.8, 1.2, 2.0, 3.2}};
            q.motion_mult  = {{0.15, 0.5, 0.8, 1.2, 2.0, 3.2}};
            break;
        case AdaptQuantKind::Roi: // 人像/ROI: 护画质降 QP (-3)
            q.texture_mult = {{0.5, 1.2, 1.8, 2.6, 4.0, 6.0}};
            q.motion_mult  = {{0.5, 1.2, 1.8, 2.6, 4.0, 6.0}};
            break;
        case AdaptQuantKind::ScreenStatic: // 屏幕共享/静态文字区
            q.texture_mult = {{0.2, 0.6, 1.0, 1.6, 2.8, 4.5}};
            q.motion_mult  = {{0.1, 0.3, 0.6, 1.0, 1.8, 3.0}};
            break;
        case AdaptQuantKind::Common:
            q.texture_mult = {{0.3, 0.9, 1.3, 2.0, 3.2, 5.0}};
            q.motion_mult  = {{0.3, 0.9, 1.3, 2.0, 3.2, 5.0}};
            break;
    }
    return q;
}

} // namespace standalone::adaptive_qp
