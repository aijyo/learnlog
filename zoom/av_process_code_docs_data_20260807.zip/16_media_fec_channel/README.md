# 真实媒体帧 + FEC channel

Python 从开源 `demo.mp4` 取帧，JPEG 编码→分片→丢失→恢复→解码，证明 FEC 可承载真实媒体。C++ 展示最小单擦除 plumbing。

`[BODY]`：生产 MultiFEC level 3/4/5；`[INFERRED]`：旧 demo 的 5%/10% loss 映射，不再宣称为实证；`BOUNDARY`：完整 RS 实现在 07，JPEG 由 OpenCV/FFmpeg OSS adapter 提供。证据：`mcm_multifec.hpp`、`mcm_channel.hpp`。
