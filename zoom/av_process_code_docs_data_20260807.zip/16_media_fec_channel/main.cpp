#include <cstdint>
#include <iostream>
#include <vector>
int main(){std::vector<std::vector<uint8_t>>d{{1,2,3,4},{5,6,7,8},{9,10,11,12}},p(1,std::vector<uint8_t>(4));for(auto&s:d)for(int i=0;i<4;i++)p[0][i]^=s[i];auto lost=d[1];d[1].assign(4,0);for(int i=0;i<4;i++){uint8_t x=p[0][i];for(int k:{0,2})x^=d[k][i];d[1][i]=x;}std::cout<<"single-erasure recovered="<<(d[1]==lost)<<"\n";std::cout<<"production profiles 3/4/5 use MultiFEC RS; this XOR shard is the media plumbing demo\n";}
