#!/usr/bin/env python3
from pathlib import Path
import argparse,cv2,numpy as np
VIDEO=Path(r'D:\code\work\research\ai-harness\data\videos\demo.mp4')
def main():
 p=argparse.ArgumentParser();p.add_argument('--video',type=Path,default=VIDEO);p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cap=cv2.VideoCapture(str(a.video));ok,frame=cap.read();cap.release()
 if not ok:raise SystemExit(f'cannot read {a.video}')
 ok,enc=cv2.imencode('.jpg',frame,[cv2.IMWRITE_JPEG_QUALITY,85]);raw=enc.tobytes();n=8;size=(len(raw)+n-1)//n;shards=[bytearray(raw[i*size:(i+1)*size].ljust(size,b'\0')) for i in range(n)];parity=bytearray(size)
 for s in shards:
  for i,x in enumerate(s):parity[i]^=x
 lost=3;shards[lost]=None;rec=bytearray(parity)
 for s in shards:
  if s is not None:
   for i,x in enumerate(s):rec[i]^=x
 shards[lost]=rec;joined=b''.join(shards)[:len(raw)];dec=cv2.imdecode(np.frombuffer(joined,np.uint8),cv2.IMREAD_COLOR)
 if dec is None:raise SystemExit('decode failed')
 cv2.imwrite(str(a.out/'fec_recovered_frame.jpg'),dec);print(f'jpeg={len(raw)} shard={size} lost={lost} recovered={joined==raw}')
if __name__=='__main__':main()
