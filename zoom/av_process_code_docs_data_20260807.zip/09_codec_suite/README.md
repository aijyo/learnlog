# 09_codec_suite — 编解码器矩阵 (Codec Suite) 与 SVC 控制面独立项目

> 证据校准：本目录是 codec matrix 概览，真实 SVC request dispatcher/config bank/RC 在 `10_encode_control_loop`，AV1 OBU/IVF 在 `11_av1_bitstream_decode`，SNAC RVQ 在 `17_snac_rvq_codec`；旧版简单 SVC 配置不应视为完整生产控制面。

本目录为一个**完全自包含 (Standalone)** 的独立小项目，展示音视频传输控制中用于多编解码器调度的 **编解码器矩阵 (Codec Suite)**、**屏幕内容双核模式 (Normal vs ScreenContent)**、**SVC 多空域/多时域分层重配置**、**关键帧/恢复帧事件派发** 与 **AI 音频编解码器 (SNAC 121) 准入门限**。

---

## 目录结构

```
09_codec_suite/
├── CMakeLists.txt              # 独立 CMake 构建脚本
├── include/
│   └── codec_suite.hpp         # 零依赖自包含 C++ 算法头文件
├── main.cpp                    # C++ 控制台调试示例 (验证双核切换、SVC 分层、事件派发与 AI 音频准入)
├── demo.py                     # Python 真实 dance_outdoor.mp4 视频双核切换 Demo
├── README.md                   # 本独立小项目说明文档
├── codec_suite_dance.gif       # 展示双核切换演变的 GIF 动图
├── codec_suite_dance.mp4       # 导出的 1280x720 60 帧 MP4 视频
├── codec_suite_panel.png       # 编解码器矩阵与 SVC 控制面架构路由面板图
└── codec_suite_wiki.html       # 暗色极客风格原理与 Wiki 说明网页
```

---

## 编译与运行方式

### 1. Python 示例运行

直接运行 Python 算法脚本（只需安装 OpenCV / NumPy / Pillow）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\codec_suite_demo.exe

# Linux/macOS 运行:
./build/codec_suite_demo
```

---

## 算法技术关键点

1. **屏幕内容双核机制 (CoreKind)**: 当 `mode & 0xF == 2` 或内容分析指示屏幕共享时，自动切入 `ScreenContent` 编码内核。
2. **SVC 多空域/多时域分层 (SVC Layering)**: 支持 3 层空域 (180p/360p/720p) 与 3 层二分级联时域帧率 ($T_0..T_2$)。
3. **AI 音频准入门限 (`AiCodecGate`)**: 只有主音频编码为 113 (Opus) 或 116 时，才允许开启 121 (SNAC) 伴随编码。
