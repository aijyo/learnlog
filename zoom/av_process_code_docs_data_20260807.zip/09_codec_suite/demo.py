#!/usr/bin/env python3
"""
编解码器矩阵与 SVC 控制面 - 基于真实本地视频 (dance_outdoor.mp4) Demo
(Codec Suite & SVC Control Real Demo)

用法:
    python demo.py
"""

import cv2
import numpy as np
from PIL import Image, ImageDraw
import os

VIDEO_PATH = r"D:\code\work\research\ai-harness\data\videos\dance_outdoor.mp4"

def generate_codec_suite_panel(filename="codec_suite_panel.png"):
    """绘制编解码器矩阵架构路由与 SVC 时空分层分析面板"""
    width, height = 800, 360
    img = Image.new('RGB', (width, height), color=(11, 15, 25))
    draw = ImageDraw.Draw(img)

    # 绘制 4 编解码器卡片 (H.264, AV1, Opus, SNAC)
    codecs = [
        ("AV1 (Normal/Screen)", "Mode 0/2 | OBU | HW/DXVA", (56, 189, 248), 50, 60),
        ("H.264 (AVC/SVC)", "Spatial S0-S2 | Temporal T0-T2", (167, 139, 250), 420, 60),
        ("Opus 113 (Main Audio)", "In-band LBRR | 48kHz", (52, 211, 153), 50, 200),
        ("SNAC 121 (AI Audio)", "Gate Preflight | CtrlWord 0x4", (251, 146, 60), 420, 200)
    ]

    for title, desc, color, x, y in codecs:
        draw.rectangle([x, y, x + 330, y + 100], fill=(17, 24, 39), outline=color, width=2)
        draw.rectangle([x, y, x + 330, y + 30], fill=(31, 41, 55))
        draw.text((x + 15, y + 7), title, fill=color)
        draw.text((x + 15, y + 45), desc, fill=(200, 200, 220))

    draw.text((50, 15), "Codec Suite & SVC Control Surface Architecture Panel", fill=(255, 255, 255))
    draw.text((50, 320), "SVC Layering: S0(360p/15fps) -> S1(720p/30fps) | AI Gate: MainCodec=113/116 Allowed", fill=(156, 163, 175))

    img.save(filename)
    return filename

if __name__ == '__main__':
    print("==========================================================")
    print("  编解码器矩阵 (Codec Suite) - 本地 dance_outdoor.mp4 Demo")
    print("==========================================================")

    if not os.path.exists(VIDEO_PATH):
        print(f"❌ 未找到本地视频文件: {VIDEO_PATH}")
        exit(1)

    print(f"\n1. 正在从本地视频读取帧数据...")
    cap = cv2.VideoCapture(VIDEO_PATH)
    
    raw_frames = []
    while len(raw_frames) < 60:
        ret, frame = cap.read()
        if not ret: break
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        raw_frames.append(rgb_frame)
    cap.release()

    print(f"   ✔ 成功读取 {len(raw_frames)} 帧真实舞蹈视频！")

    print("\n2. 模拟 Normal 核心 (摄像头肖像) 与 ScreenContent 核心 (屏幕代码) 编码展示...")
    annotated_frames_pil = []

    for idx, frame_rgb in enumerate(raw_frames):
        mode = 2 if (idx % 20 < 10) else 0 # 模拟模式动态切替
        core_str = "ScreenContent Core (Mode 2)" if mode == 2 else "Normal Core (Mode 0)"

        pimg = Image.fromarray(frame_rgb).resize((1280, 720), Image.Resampling.LANCZOS)
        draw = ImageDraw.Draw(pimg)

        # 顶部绘制 Codec 状态
        draw.rectangle([0, 0, 1280, 45], fill=(0, 0, 0))
        draw.text((15, 12), f"Frame {idx+1:2d} | Codec: AV1 | Core: {core_str} | SVC: S2 720p/30fps | Gate 121: OK", fill=(56, 189, 248))

        annotated_frames_pil.append(pimg)

        if idx == 15:
            pimg.save("codec_suite_frame15.png")

    print("\n3. 正在导出 60 帧动态 GIF 与 MP4 视频...")
    
    gif_path = "codec_suite_dance.gif"
    sub_sample = annotated_frames_pil[::2]
    sub_sample[0].save(
        gif_path,
        save_all=True,
        append_images=sub_sample[1:],
        duration=80,
        loop=0
    )

    mp4_path = "codec_suite_dance.mp4"
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_writer = cv2.VideoWriter(mp4_path, fourcc, 25.0, (1280, 720))
    for pimg in annotated_frames_pil:
        bgr = cv2.cvtColor(np.array(pimg), cv2.COLOR_RGB2BGR)
        out_writer.write(bgr)
    out_writer.release()

    panel_file = generate_codec_suite_panel("codec_suite_panel.png")

    print(f"\n✔ 处理完成！全套真实 Demo 产物导出完毕:")
    print(f"  └─ codec_suite_dance.gif       : 展示 Codec 双核动态演变的 GIF 动图")
    print(f"  └─ codec_suite_dance.mp4       : 导出的 1280x720 60 帧 MP4 视频")
    print(f"  └─ codec_suite_panel.png       : 编解码器矩阵与 SVC 控制面架构路由面板图")
