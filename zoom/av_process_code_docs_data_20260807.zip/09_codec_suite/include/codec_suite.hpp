#pragma once
/**
 * @file codec_suite.hpp
 * @brief 自包含的音视频编解码器矩阵、SVC 时空分层与统一控制面算法 (Codec Suite & SVC Control)
 * 
 * 零外部依赖，仅包含 C++ 标准库 <cstdint>, <vector>, <string>, <array>, <memory>, <algorithm>, <cstddef>.
 */

#include <cstdint>
#include <vector>
#include <string>
#include <array>
#include <memory>
#include <algorithm>
#include <cstddef>

namespace standalone::codec_suite {

/**
 * @brief 编解码器种类 (Codec Kind)
 */
enum class CodecKind : int {
    H264 = 1,
    AV1  = 2,
    Opus = 113,
    SNAC = 121 // AI 神经网络音频编解码器
};

/**
 * @brief 编码器内核模式 (Core Kind: Normal 摄像头 vs ScreenContent 屏幕代码)
 */
enum class CoreKind : int {
    Normal        = 0, // 正常摄像头肖像模式
    ScreenContent = 2  // 屏幕共享高细节文本模式 ((mode & 0xF) == 2)
};

inline CoreKind CoreKindOf(int mode) {
    return (mode & 0xF) == 2 ? CoreKind::ScreenContent : CoreKind::Normal;
}

/**
 * @brief SVC 空间分层配置 (Spatial Layer Config)
 */
struct SpatialLayer {
    int   spatial_idx = 0;
    int   width = 1280;
    int   height = 720;
    float frame_rate = 30.0f;
    int   bitrate_bps = 1500000;
    int   fix_qp = 28;
    bool  single_ref = false;
    bool  ltr_enabled = false;
    int   temporal_layer_num = 3;
};

/**
 * @brief 编解码请求类型 (KeyPictureRequest Types)
 */
enum class RequestType : int {
    Reconfigure     = 1,  // 参数重配置
    KeyPicture      = 2,  // 恢复关键帧
    ForceIdr        = 4,  // 强制插入 IDR
    DuplicateP      = 5,  // 复制 P 帧抗丢包
    SubscribeChange = 20, // 订阅图层切换
    FrameSkip       = 24  // 拥塞跳帧
};

/**
 * @brief AI 音频编解码器 (SNAC 121) 准入控制逻辑 (AiCodecGate)
 */
struct AiCodecGate {
    enum Err {
        Ok = 0,
        NoMainCodec = -301,
        MainNotAllowed = -302,
        NoCodec121 = -304
    };

    static bool MainCodecAllowed(int main_codec) {
        return main_codec == 113 || main_codec == 116; // 仅当主音频编码为 113/116 时允许开启 AI 121 伴随编解码器
    }

    static Err PreflightEnable(int main_codec, bool found_121) {
        if (main_codec == 0) return NoMainCodec;
        if (!MainCodecAllowed(main_codec)) return MainNotAllowed;
        if (!found_121) return NoCodec121;
        return Ok;
    }
};

/**
 * @brief 10-bit 控制字与 SNAC 状态机 (ControlWord)
 */
struct ControlWord {
    static constexpr uint32_t kMask = 0x3FF;
    static constexpr uint32_t kBitExtraEnc = 0x4; // Bit 0x4 开启额外 AI/SNAC 编码

    static bool IsExtraEncEnabled(uint32_t ctrl_word) {
        return (ctrl_word & kBitExtraEnc) != 0;
    }
};

/**
 * @brief 抽象编解码器统一接口 (ICodecInstance)
 */
class ICodecInstance {
public:
    virtual ~ICodecInstance() = default;
    virtual CodecKind kind() const = 0;
    virtual CoreKind core_kind() const = 0;
    virtual int ApplyConfig(const std::vector<SpatialLayer>& layers) = 0;
    virtual bool HandleRequest(RequestType req, int spatial_idx) = 0;
};

/**
 * @brief AV1 统一编解码器代理类 (Av1CodecInstance)
 */
class Av1CodecInstance : public ICodecInstance {
public:
    explicit Av1CodecInstance(int mode) : mode_(mode) {
        core_ = CoreKindOf(mode);
    }

    CodecKind kind() const override { return CodecKind::AV1; }
    CoreKind core_kind() const override { return core_; }

    int ApplyConfig(const std::vector<SpatialLayer>& layers) override {
        layers_ = layers;
        return 0;
    }

    bool HandleRequest(RequestType req, int spatial_idx) override {
        switch (req) {
            case RequestType::ForceIdr:
                idr_count_++;
                return true;
            case RequestType::DuplicateP:
                dup_p_count_++;
                return true;
            case RequestType::FrameSkip:
                skip_count_++;
                return true;
            default:
                return true;
        }
    }

    int idr_count() const { return idr_count_; }
    int dup_p_count() const { return dup_p_count_; }
    int skip_count() const { return skip_count_; }

private:
    int mode_;
    CoreKind core_;
    std::vector<SpatialLayer> layers_;
    int idr_count_ = 0;
    int dup_p_count_ = 0;
    int skip_count_ = 0;
};

/**
 * @brief 编解码器矩阵控制器工厂 (CodecSuiteController)
 */
class CodecSuiteController {
public:
    std::unique_ptr<ICodecInstance> CreateVideoEncoder(CodecKind kind, int mode) {
        if (kind == CodecKind::AV1) {
            return std::make_unique<Av1CodecInstance>(mode);
        }
        return nullptr;
    }

    AiCodecGate::Err TryEnableAiAudioCodec(int main_codec, bool has_snac) {
        return AiCodecGate::PreflightEnable(main_codec, has_snac);
    }
};

} // namespace standalone::codec_suite
