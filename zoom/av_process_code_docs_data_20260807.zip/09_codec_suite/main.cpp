#include "codec_suite.hpp"
#include <iostream>
#include <vector>
#include <iomanip>

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "  编解码器矩阵 (Codec Suite) 与 SVC 控制面 Demo (C++)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    standalone::codec_suite::CodecSuiteController controller;

    // 1. 验证 Codec 双核机制: Normal 摄像头 (mode=0) vs ScreenContent 屏幕代码 (mode=2)
    std::cout << "\n[1. 验证 Codec 双核内核自动切换 (Normal vs ScreenContent)]:" << std::endl;
    auto enc_normal = controller.CreateVideoEncoder(standalone::codec_suite::CodecKind::AV1, 0); // Normal
    auto enc_screen = controller.CreateVideoEncoder(standalone::codec_suite::CodecKind::AV1, 2); // ScreenContent (mode&0xF == 2)

    std::cout << "  - 编码模式 mode=0 -> 映射内核类型: " 
              << (enc_normal->core_kind() == standalone::codec_suite::CoreKind::Normal ? "【Normal 摄像人像内核】" : "【ScreenContent】") << std::endl;
    std::cout << "  - 编码模式 mode=2 -> 映射内核类型: " 
              << (enc_screen->core_kind() == standalone::codec_suite::CoreKind::ScreenContent ? "【ScreenContent 屏幕代码内核】" : "【Normal】") << std::endl;

    // 2. 验证 SVC 3 层空域分层配置与事件派发
    std::cout << "\n[2. 验证 SVC 3 层空域分层配置与 Request 事件派发]:" << std::endl;
    std::vector<standalone::codec_suite::SpatialLayer> layers = {
        { 0, 320,  180, 15.0f,  200000, 32, false, false, 2 }, // S0: 180p
        { 1, 640,  360, 30.0f,  600000, 28, false, true,  3 }, // S1: 360p
        { 2, 1280, 720, 30.0f, 1500000, 26, true,  true,  3 }  // S2: 720p
    };

    enc_screen->ApplyConfig(layers);
    std::cout << "  - 已应用 SVC 3 空域图层配置 (S0: 180p, S1: 360p, S2: 720p)" << std::endl;

    // 派发请求事件
    enc_screen->HandleRequest(standalone::codec_suite::RequestType::ForceIdr, 2);
    enc_screen->HandleRequest(standalone::codec_suite::RequestType::DuplicateP, 1);
    enc_screen->HandleRequest(standalone::codec_suite::RequestType::FrameSkip, 0);

    std::cout << "  - 派发网络事件结果: IDR 请求数=" << dynamic_cast<standalone::codec_suite::Av1CodecInstance*>(enc_screen.get())->idr_count()
              << ", 复制 P 帧数=" << dynamic_cast<standalone::codec_suite::Av1CodecInstance*>(enc_screen.get())->dup_p_count()
              << ", 拥塞跳帧数=" << dynamic_cast<standalone::codec_suite::Av1CodecInstance*>(enc_screen.get())->skip_count() << std::endl;

    // 3. 验证 AI 音频编解码器 (SNAC 121) 准入关卡
    std::cout << "\n[3. 验证 AI 音频编解码器 (SNAC 121) 准入门限 (AiCodecGate)]:" << std::endl;
    int test_codecs[] = { 113, 100, 116 };
    for (int main_codec : test_codecs) {
        auto err = controller.TryEnableAiAudioCodec(main_codec, true);
        std::cout << "  - 主音频 Codec ID = " << std::setw(3) << main_codec 
                  << " -> AI 121 准入结果: " << (err == standalone::codec_suite::AiCodecGate::Ok ? "【✔ 允许开启 AI 121 伴随编码】" : "【❌ 拒绝开启 (MainNotAllowed)】") << std::endl;
    }

    std::cout << "\n全套 C++ 编解码器矩阵与 SVC 控制面演示完成！" << std::endl;
    return 0;
}
