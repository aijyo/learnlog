#!/usr/bin/env python3
from pathlib import Path
import argparse
from urllib.parse import urlsplit
from PIL import Image,ImageDraw
def main():
 p=argparse.ArgumentParser();p.add_argument('--url',default='https://media.example:8443/connect?q=1');p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 u=urlsplit(a.url);states=['parse URL',f'{u.scheme} transport','proxy A failed','proxy B TCP connected','TCP_NODELAY','TLS ready','QUIC context (boundary)'];im=Image.new('RGB',(1100,300),'white');d=ImageDraw.Draw(im)
 for i,s in enumerate(states):x=30+i*150;d.rounded_rectangle((x,100,x+125,175),10,fill=(60,125,205) if 'failed' not in s else (210,80,70));d.text((x+8,120),s,fill='white'); 
 for i in range(len(states)-1):d.line((155+i*150,137,180+i*150,137),fill='black',width=3)
 d.text((30,30),f'{u.scheme}://{u.hostname}:{u.port or 443}{u.path}',fill='black');im.save(a.out/'transport_state_machine.png');print(states)
if __name__=='__main__':main()
