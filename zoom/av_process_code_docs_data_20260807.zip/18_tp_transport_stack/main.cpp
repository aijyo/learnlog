#include <iostream>
#include <map>
#include <string>
struct Url{std::string scheme,host,path;int port;};
Url parse(std::string s){auto p=s.find("://");Url u{s.substr(0,p),"","/",0};size_t a=p==std::string::npos?0:p+3;size_t e=s.find('/',a);std::string hp=s.substr(a,e-a);size_t c=hp.rfind(':');u.host=hp.substr(0,c);u.port=c==std::string::npos?(u.scheme=="https"?443:80):std::stoi(hp.substr(c+1));if(e!=std::string::npos)u.path=s.substr(e);return u;}
int main(){auto u=parse("https://media.example:8443/connect?q=1");std::cout<<u.scheme<<" host="<<u.host<<" port="<<u.port<<" path="<<u.path<<"\n";std::map<int,std::string>ssl{{6,"TLS_method"},{20,"TLS_client_method"},{21,"TLS_server_method"}};for(auto x:ssl)std::cout<<"method_id="<<x.first<<" -> "<<x.second<<"\n";std::cout<<"proxy[0] fail -> proxy[1] connect -> TCP_NODELAY -> TLS; collapse stale timer generation\n";std::cout<<"openssl_options=0x80000850\n";}
