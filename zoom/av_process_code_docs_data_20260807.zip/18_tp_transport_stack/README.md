# TP Transport：URL / proxy / connector race / TLS / QUIC context

Python 可视化连接状态；C++ 实现 URL 拆分、默认端口、method-id 表和 proxy failover 调用顺序。

`[BODY]`：scheme→transport、OpenSSL method id 6..21、options `0x80000850`、TCP_NODELAY、pending timer collapse 结构；`BOUNDARY`：真实 TLS/QUIC 由 OpenSSL/curl/platform adapter 完成，本 demo 不访问公网。证据：`recon/tp/*.hpp`。
