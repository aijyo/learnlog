#pragma once
/**
 * @file rs_fec_engine.hpp
 * @brief 自包含的 GF(256) Cauchy 里德-所罗门 (Reed-Solomon) 擦除码引擎与多层 FEC (Level 3/4/5) 防护策略
 * 
 * 零外部依赖，仅包含 C++ 标准库 <cstdint>, <vector>, <utility>, <algorithm>, <cstddef>.
 */

#include <cstdint>
#include <vector>
#include <utility>
#include <algorithm>
#include <cstddef>

namespace standalone::fec {

/**
 * @brief GF(2^8) / GF(256) 伽罗瓦域与对数/指数表 (生成多项式 0x11D)
 */
struct Gf256 {
    uint8_t exp[512];
    uint8_t logt[256];

    Gf256() {
        uint8_t x = 1;
        for (int i = 0; i < 255; ++i) {
            exp[i] = x;
            logt[x] = (uint8_t)i;
            uint8_t hi = x & 0x80;
            x = (uint8_t)(x << 1);
            if (hi) x ^= 0x1D; // 约简多项式 0x11D (低 8 位 0x1D)
        }
        for (int i = 255; i < 512; ++i) exp[i] = exp[i - 255];
        logt[0] = 0;
    }

    uint8_t mul(uint8_t a, uint8_t b) const {
        return (!a || !b) ? 0 : exp[logt[a] + logt[b]];
    }

    uint8_t inv(uint8_t a) const {
        return exp[255 - logt[a]];
    }
};

/**
 * @brief 系统化 Cauchy 矩阵 Reed-Solomon 前向纠错编解码器 (RsFec)
 */
class RsFec {
public:
    RsFec(int k, int r) : k_(k), r_(r), cauchy_(r, std::vector<uint8_t>(k, 0)) {
        // 构建 Cauchy 柯西矩阵 C[i][j] = 1 / (i XOR (r + j))
        for (int i = 0; i < r_; ++i) {
            for (int j = 0; j < k_; ++j) {
                cauchy_[i][j] = gf_.inv((uint8_t)(i ^ (r_ + j)));
            }
        }
    }

    int k() const { return k_; }
    int r() const { return r_; }
    int n() const { return k_ + r_; }

    /**
     * @brief 由 K 个数据 Shard 生成 R 个 Parity 校验 Shard
     */
    std::vector<std::vector<uint8_t>> Encode(const std::vector<std::vector<uint8_t>>& data) const {
        size_t len = data.empty() ? 0 : data[0].size();
        std::vector<std::vector<uint8_t>> parity(r_, std::vector<uint8_t>(len, 0));
        for (int i = 0; i < r_; ++i) {
            for (int j = 0; j < k_; ++j) {
                uint8_t c = cauchy_[i][j];
                if (!c) continue;
                const auto& dj = data[j];
                auto& pi = parity[i];
                for (size_t b = 0; b < len; ++b) {
                    pi[b] ^= gf_.mul(c, dj[b]);
                }
            }
        }
        return parity;
    }

    /**
     * @brief 从丢包损坏的 Shard 集合中，通过 Gauss-Jordan 域消元完全恢复丢失的数据
     */
    bool Decode(std::vector<std::vector<uint8_t>>& shards, const std::vector<char>& present) const {
        std::vector<int> rows;
        size_t len = 0;
        for (int i = 0; i < n() && (int)rows.size() < k_; ++i) {
            if (present[i]) {
                rows.push_back(i);
                if (!shards[i].empty()) len = shards[i].size();
            }
        }
        if ((int)rows.size() < k_) return false; // 存活包 < K，不可恢复

        std::vector<std::vector<uint8_t>> A(k_, std::vector<uint8_t>(k_, 0));
        for (int rr = 0; rr < k_; ++rr) {
            int idx = rows[rr];
            if (idx < k_) A[rr][idx] = 1;
            else          A[rr] = cauchy_[idx - k_];
        }

        std::vector<std::vector<uint8_t>> Ainv;
        if (!Invert(A, Ainv)) return false;

        for (int out = 0; out < k_; ++out) {
            if (present[out]) continue;
            std::vector<uint8_t> dst(len, 0);
            for (int rr = 0; rr < k_; ++rr) {
                uint8_t c = Ainv[out][rr];
                if (!c) continue;
                const auto& src = shards[rows[rr]];
                for (size_t b = 0; b < len; ++b) {
                    dst[b] ^= gf_.mul(c, src[b]);
                }
            }
            shards[out] = std::move(dst);
        }
        return true;
    }

private:
    bool Invert(std::vector<std::vector<uint8_t>> m, std::vector<std::vector<uint8_t>>& out) const {
        int n_dim = k_;
        out.assign(n_dim, std::vector<uint8_t>(n_dim, 0));
        for (int i = 0; i < n_dim; ++i) out[i][i] = 1;

        for (int col = 0; col < n_dim; ++col) {
            int piv = -1;
            for (int row = col; row < n_dim; ++row) {
                if (m[row][col]) { piv = row; break; }
            }
            if (piv < 0) return false;
            std::swap(m[piv], m[col]);
            std::swap(out[piv], out[col]);

            uint8_t iv = gf_.inv(m[col][col]);
            for (int j = 0; j < n_dim; ++j) {
                m[col][j]   = gf_.mul(m[col][j], iv);
                out[col][j] = gf_.mul(out[col][j], iv);
            }
            for (int row = 0; row < n_dim; ++row) {
                if (row == col || !m[row][col]) continue;
                uint8_t f = m[row][col];
                for (int j = 0; j < n_dim; ++j) {
                    m[row][j]   ^= gf_.mul(f, m[col][j]);
                    out[row][j] ^= gf_.mul(f, out[col][j]);
                }
            }
        }
        return true;
    }

    int k_, r_;
    Gf256 gf_;
    std::vector<std::vector<uint8_t>> cauchy_;
};

/**
 * @brief 多层 FEC 防护级别的决策逻辑 (Level 3 / 4 / 5 Protection)
 */
struct MultiFecPolicy {
    static int SelectLevel(double loss_rate) {
        if (loss_rate < 0.05) return 3; // 5% 以下: Level 3 Protection (增加 3 个校验包)
        if (loss_rate < 0.10) return 4; // 5%~10%: Level 4 Protection (增加 4 个校验包)
        return 5;                       // 10% 以上高丢包: Level 5 Protection (增加 5 个校验包)
    }
};

struct FecShard {
    std::vector<uint8_t> data;
    bool is_parity = false;
};

/**
 * @brief 包含数据包切片与多层 Parity 冗余包构造的数据组 (MultiFecGroup)
 */
class MultiFecGroup {
public:
    MultiFecGroup(const std::vector<uint8_t>& payload, int k, int level)
        : k_(k), level_(level), orig_len_((uint32_t)payload.size()) {
        shard_len_ = (uint32_t)((payload.size() + k - 1) / k);
        if (shard_len_ == 0) shard_len_ = 1;

        std::vector<std::vector<uint8_t>> data(k_, std::vector<uint8_t>(shard_len_, 0));
        for (uint32_t i = 0; i < payload.size(); ++i) {
            data[i / shard_len_][i % shard_len_] = payload[i];
        }

        RsFec rs(k_, level_);
        auto parity = rs.Encode(data);

        for (auto& d : data)   shards_.push_back({ std::move(d), false });
        for (auto& p : parity) shards_.push_back({ std::move(p), true });
    }

    int k() const { return k_; }
    int level() const { return level_; }
    uint32_t orig_len() const { return orig_len_; }
    uint32_t shard_len() const { return shard_len_; }
    const std::vector<FecShard>& shards() const { return shards_; }

    /**
     * @brief 恢复丢包数据
     */
    static std::vector<uint8_t> Recover(const std::vector<FecShard>& shards,
                                        const std::vector<char>& present,
                                        int k, int level, uint32_t orig_len, uint32_t shard_len) {
        std::vector<std::vector<uint8_t>> raw(shards.size());
        for (size_t i = 0; i < shards.size(); ++i) {
            raw[i] = present[i] ? shards[i].data : std::vector<uint8_t>(shard_len, 0);
        }
        RsFec rs(k, level);
        if (!rs.Decode(raw, present)) return {};
        
        std::vector<uint8_t> out;
        out.reserve((size_t)k * shard_len);
        for (int i = 0; i < k; ++i) {
            out.insert(out.end(), raw[i].begin(), raw[i].end());
        }
        out.resize(orig_len);
        return out;
    }

private:
    int k_, level_;
    uint32_t orig_len_, shard_len_;
    std::vector<FecShard> shards_;
};

} // namespace standalone::fec
