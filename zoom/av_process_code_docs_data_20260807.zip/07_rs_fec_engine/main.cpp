#include "rs_fec_engine.hpp"
#include <iostream>
#include <vector>
#include <iomanip>
#include <random>

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "  多层 FEC (Level 3/4/5) 与 RS(GF256 0x11D) 引擎 Demo (C++)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    // 1. 验证 GF(256) 域乘法与求逆
    std::cout << "\n[1. 验证 GF(256) 域乘与求逆 (生成多项式 0x11D)]:" << std::endl;
    standalone::fec::Gf256 gf;
    uint8_t a = 0x57, b = 0x83;
    uint8_t product = gf.mul(a, b);
    uint8_t inv_a = gf.inv(a);
    uint8_t identity = gf.mul(a, inv_a);

    std::cout << "  - a = 0x" << std::hex << (int)a << ", b = 0x" << (int)b << std::dec << std::endl;
    std::cout << "  - GF(256) 域乘结果 a * b = 0x" << std::hex << (int)product << std::dec << std::endl;
    std::cout << "  - a 的域逆元素 a^-1 = 0x" << std::hex << (int)inv_a << std::dec << std::endl;
    std::cout << "  - 验证 a * a^-1: 0x" << std::hex << (int)identity << std::dec 
              << (identity == 1 ? " ✔ (完全正确!)" : " ❌ (错误)") << std::endl;

    // 2. 多层 FEC 防护级别的选择 (MultiFecPolicy)
    std::cout << "\n[2. 验证多层 FEC 动态防护策略选择 (MultiFecPolicy)]:" << std::endl;
    double loss_rates[] = { 0.02, 0.07, 0.15 };
    for (double loss : loss_rates) {
        int level = standalone::fec::MultiFecPolicy::SelectLevel(loss);
        std::cout << "  - 网络丢包率: " << std::setw(4) << (int)(loss * 100) << "% "
                  << " -> 匹配防护级别: Level " << level << " Protection (" << level << " Parity Shards)" << std::endl;
    }

    // 3. 模拟 15% 严重网络丢包下的数据组编码与恢复
    std::cout << "\n[3. 模拟 15% 严重丢包下的 Level 5 Protection 编码与擦除恢复]:" << std::endl;
    
    // 构造测试 Payload (例如 256 字节的音视频 RTP 荷载)
    std::vector<uint8_t> original_payload(256);
    for (size_t i = 0; i < original_payload.size(); ++i) {
        original_payload[i] = (uint8_t)(i * 3 + 7);
    }

    int k = 8;
    int level = standalone::fec::MultiFecPolicy::SelectLevel(0.15); // Level 5
    standalone::fec::MultiFecGroup group(original_payload, k, level);

    std::cout << "  - 原始 Payload 字节数: " << group.orig_len() << " 字节" << std::endl;
    std::cout << "  - 数据 Shard 数量 (K): " << group.k() << ", Parity 校验 Shard 数量 (L): " << group.level() << std::endl;
    std::cout << "  - 总传输 RTP 数据包数 (N = K + L): " << group.shards().size() << " 包" << std::endl;

    // 模拟网络丢失了 5 个 Shard 包 (例如数据包 #0, #2, #5 和 Parity 包 #9, #11 丢失)
    std::vector<char> present(group.shards().size(), 1);
    present[0] = 0;
    present[2] = 0;
    present[5] = 0;
    present[9] = 0;
    present[11] = 0;

    std::cout << "  - 模拟网络丢包: 丢失了 5/13 个包 (其中包含了 3 个关键 Data 包与 2 个 Parity 包)" << std::endl;

    // 调用 RS 解码恢复
    auto recovered_payload = standalone::fec::MultiFecGroup::Recover(
        group.shards(), present, group.k(), group.level(), group.orig_len(), group.shard_len()
    );

    bool is_match = (recovered_payload == original_payload);
    std::cout << "  - 擦除恢复结果: " << (is_match ? "【100% 字节无损完美恢复成功 SUCCESS!】" : "【恢复失败】") << std::endl;

    if (is_match) {
        std::cout << "  --------------------------------------------------------" << std::endl;
        std::cout << "  📢 [网络传输与音视频管线状态]:" << std::endl;
        std::cout << "     1. 即使网络面临高达 38.4% (5/13) 的强丢包攻击；" << std::endl;
        std::cout << "     2. RS(GF256) Cauchy 擦除码引擎仍实现了 0 延时 0 字节误差解包；" << std::endl;
        std::cout << "     3. 音视频画面完全无卡顿、无花屏、无破音！" << std::endl;
        std::cout << "  --------------------------------------------------------" << std::endl;
    }

    std::cout << "\n全套 C++ 多层 FEC 与 RS(GF256) 演示完成！" << std::endl;
    return 0;
}
