# 07_rs_fec_engine — 多层 FEC (Level 3/4/5) 与 RS(GF256) 引擎独立项目

> 证据校准：GF(256)、RS 与 FEC level 3/4/5 为 `[BODY]`；5%/10%/15% 等丢包场景是测试注入或 `[INFERRED]` 策略，不是已确认的生产阈值。

本目录为一个**完全自包含 (Standalone)** 的独立小项目，展示实时音视频传输网络中用于抗极重弱网丢包的 **多层 FEC (Level 3/4/5 Protection Policy)** 与 **Cauchy 柯西矩阵系统 Reed-Solomon (GF256, 生成多项式 0x11D) 前向纠错擦除码引擎**。

---

## 目录结构

```
07_rs_fec_engine/
├── CMakeLists.txt              # 独立 CMake 构建脚本
├── include/
│   └── rs_fec_engine.hpp       # 零依赖自包含 C++ 算法头文件 (GF256 & Cauchy RS & MultiFecPolicy)
├── main.cpp                    # C++ 控制台调试示例 (验证 GF256 域乘/求逆 & 15% 丢包恢复)
├── demo.py                     # Python 24-bit 全彩肖像网络 38.4% 丢包花屏与无损恢复 Demo
├── README.md                   # 本独立小项目说明文档
├── rs_fec_comparison.png       # 4 并排真实画面对比图 (原图 -> 丢包花屏 -> RS(GF256)恢复 -> 0误差残差)
├── rs_fec_panel.png            # 多层 FEC (Level 3/4/5) 防护与丢包恢复率分析面板图
└── rs_fec_wiki.html            # 暗色极客风格原理与 Wiki 说明网页
```

---

## 编译与运行方式

### 1. Python 示例运行

直接运行 Python 算法脚本（只需安装 NumPy / Pillow）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\rs_fec_engine_demo.exe

# Linux/macOS 运行:
./build/rs_fec_engine_demo
```

---

## 算法技术关键点

1. **$GF(2^8)$ / $GF(256)$ 伽罗瓦域 (Primitive Polynomial $0x11D$)**:
   - $p(x) = x^8 + x^4 + x^3 + x^2 + 1 \implies 0x11D$ (低 8 位 $0x1D$)；
   - 快速对数/指数表 `exp[512]` 与 `logt[256]`，全表零分支域乘法与求逆。
2. **Cauchy 柯西矩阵 systems RS 擦除码引擎 (`RsFec`)**:
   - $K$ 个数据 Shard + $R$ 个校验 Parity Shard；
   - Cauchy 矩阵 $C_{i, j} = \frac{1}{x_i \oplus y_j}$（保证 MDS 满秩特性）；
   - 在任意 $\le R$ 个 Shard 被网络丢弃时，利用 Gauss-Jordan 域消元完全无损还原。
3. **多层 FEC 动态防护策略 (`MultiFecPolicy`)**:
   - $Loss < 5\% \implies$ **Level 3 Protection**；
   - $5\% \le Loss < 10\% \implies$ **Level 4 Protection**；
   - $Loss \ge 10\% \implies$ **Level 5 Protection**（最高可强力防御 38.4% 强丢包！）。
