#include <cstdint>
#include <iostream>
#include <map>
#include <string>
#include <vector>
void put(std::vector<uint8_t>&b,std::string k,std::string v){b.push_back(uint8_t(k.size()));b.insert(b.end(),k.begin(),k.end());b.push_back(uint8_t(v.size()));b.insert(b.end(),v.begin(),v.end());}
int main(){std::vector<uint8_t>w;put(w,"service","media");put(w,"enabled","true");put(w,"future","ignored");std::map<std::string,std::string>s;for(size_t p=0;p<w.size();){int kn=w[p++];std::string k(w.begin()+p,w.begin()+p+kn);p+=kn;int vn=w[p++];std::string v(w.begin()+p,w.begin()+p+vn);p+=vn;s[k]=v;}std::cout<<"wire_bytes="<<w.size()<<" service="<<s["service"]<<" enabled="<<s["enabled"]<<" unknown_preserved="<<s.count("future")<<"\n";}
