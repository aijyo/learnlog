#!/usr/bin/env python3
from pathlib import Path
import argparse,json
from PIL import Image,ImageDraw
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 cfg={'aic':{'service':'media','enabled':True,'quality':3},'unknown_future_field':{'v':1}};wire=json.dumps(cfg,separators=(',',':')).encode();im=Image.new('RGB',(900,440),'white');d=ImageDraw.Draw(im);d.text((25,20),f'typed settings consumer | wire bytes={len(wire)}',fill='black')
 lines=['AICSetting','  aic','    service: media','    enabled: true','    quality: 3','  unknown_future_field','    v: 1 (preserved/ignored by old reader)']
 for i,x in enumerate(lines):d.text((50,70+i*42),x,fill=(20,70,150) if i<5 else (120,80,30))
 im.save(a.out/'webapp_settings_tree.png');(a.out/'settings_wire.json').write_bytes(wire);print(wire.decode())
if __name__=='__main__':main()
