# WebApp Settings typed consumption

Python 生成配置树和 wire；C++ 展示 typed query、service lookup 与未知字段兼容的最小消费模式。

`[BODY]`：配置消费/lookup 结构；`BOUNDARY`：真实 AICSetting 二进制必须由 protobuf schema 生成，本目录的 length-prefix/JSON 是可运行教学 stand-in，不声称 wire-compatible。topic/pub-sub 总线仍是 static-RE floor。证据：`recon/ssb/webapp_settings.hpp`。
