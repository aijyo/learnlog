#!/usr/bin/env python3
from pathlib import Path
import argparse
from PIL import Image,ImageDraw
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 im=Image.new('RGB',(1100,620),'white');d=ImageDraw.Draw(im);pts={'origin':(80,260),'scheduler':(410,60),'sn-a (failed)':(410,240),'sn-b (promoted)':(410,430),'nn-1':(820,200),'nn-2':(820,410)}
 edges=[('origin','sn-a (failed)','WAN x1'),('origin','sn-b (promoted)','failover'),('scheduler','sn-a (failed)','assign'),('scheduler','sn-b (promoted)','promote'),('sn-b (promoted)','nn-1','LAN'),('sn-b (promoted)','nn-2','LAN')]
 for a1,b,label in edges:d.line((*pts[a1],*pts[b]),fill=(90,90,90),width=3);d.text(((pts[a1][0]+pts[b][0])//2,(pts[a1][1]+pts[b][1])//2),label,fill='black')
 for name,(x,y) in pts.items():d.ellipse((x-55,y-35,x+90,y+35),fill=(205,70,65) if 'failed' in name else (55,130,205));d.text((x-42,y-8),name,fill='white')
 d.text((30,20),'eCDN Mesh: one WAN pull, LAN fanout, primary-SN failover',fill='black');im.save(a.out/'mesh_failover.png');print(a.out.resolve())
if __name__=='__main__':main()
