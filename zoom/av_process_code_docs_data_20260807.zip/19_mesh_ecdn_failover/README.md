# eCDN Mesh 角色、转发与故障切换

Python 输出拓扑与 failover 图；C++ 演示 scheduler/origin/SN/NN 状态和 WAN 节省计数。

`[BODY]`：角色、gating→cost→assignment→handshake→forward→diagnostics 模块边界；`[PARTIAL]`：计时、wire 字段和真实选举条件。证据：`recon/mesh/mesh_types|env|wire|diag|module|ecdn|win|cli.hpp`。
