#include <iostream>
#include <string>
#include <vector>
enum class Role{Origin,Scheduler,SuperNode,NormalNode};struct Node{std::string id;Role role;bool alive=true;};
int main(){std::vector<Node>n{{"origin",Role::Origin},{"scheduler",Role::Scheduler},{"sn-a",Role::SuperNode},{"sn-b",Role::SuperNode},{"nn-1",Role::NormalNode},{"nn-2",Role::NormalNode}};int wan=1,lan=2;std::cout<<"gate=on cost=eligible assignment=sn-a backup=sn-b\n";n[2].alive=false;std::cout<<"sn-a crash -> heartbeat timeout -> sn-b promoted\n";std::cout<<"WAN pulls="<<wan<<" LAN forwards="<<lan<<" saved="<<lan<<" origin fetches\n";}
