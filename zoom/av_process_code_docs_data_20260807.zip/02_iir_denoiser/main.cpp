#include "iir_denoiser.hpp"
#include <iostream>
#include <vector>
#include <iomanip>
#include <cmath>

int main() {
    std::cout << "==========================================" << std::endl;
    std::cout << "  Temporal EWMA IIR Denoise (C++ Demo)" << std::endl;
    std::cout << "==========================================" << std::endl;

    int w = 8, h = 8;
    size_t n = w * h;

    standalone::denoise::IirDenoise cfg;
    cfg.alpha = 0.37f;
    cfg.motion_guard = 25;

    standalone::denoise::TemporalDenoiser denoiser(cfg);

    std::vector<uint8_t> frame_in(n);
    std::vector<uint8_t> frame_out(n);

    std::cout << "\n--- 模拟 5 帧图像序列去噪过程 ---" << std::endl;

    for (int frame_idx = 1; frame_idx <= 5; ++frame_idx) {
        uint8_t base_val = (frame_idx >= 4) ? 200 : 120;
        for (size_t i = 0; i < n; ++i) {
            int noise = (i % 2 == 0) ? (frame_idx * 5) % 15 : -(frame_idx * 7) % 15;
            frame_in[i] = (uint8_t)(base_val + noise);
        }

        denoiser.Filter(frame_in.data(), frame_out.data(), n);

        std::cout << "\n帧 [" << frame_idx << "] (基准值: " << (int)base_val << "):" << std::endl;
        std::cout << "  输入 [0..3]: " << (int)frame_in[0] << " " << (int)frame_in[1] 
                  << " " << (int)frame_in[2] << " " << (int)frame_in[3] << std::endl;
        std::cout << "  滤波 [0..3]: " << (int)frame_out[0] << " " << (int)frame_out[1] 
                  << " " << (int)frame_out[2] << " " << (int)frame_out[3] << std::endl;
    }

    std::cout << "\n去噪处理演示完成！" << std::endl;
    return 0;
}
