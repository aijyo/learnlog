# 02_iir_denoiser — 时域 EWMA IIR 去噪算法独立项目

> 证据校准：EWMA alpha/状态更新为 `[BODY]`；demo 的 motion guard 是工程增强，用于防拖影，不是从逆向主体中证明的原始分支。

本目录为一个**完全自包含 (Standalone)** 的独立小项目，展示实时音视频管线预处理阶段用于传感器噪点抑制的 **Temporal EWMA IIR (Exponentially Weighted Moving Average)** 时域去噪算法。

---

## 目录结构

```
02_iir_denoiser/
├── CMakeLists.txt         # 独立 CMake 构建脚本
├── include/
│   └── iir_denoiser.hpp   # 自包含 C++ 算法头文件 (零依赖)
├── main.cpp               # C++ 默认独立调用示例
├── demo.py                # Python 效果展示与算法演示
└── iir_denoiser_wiki.html # 暗色极客风格算法原理与细节说明文档
```

---

## 编译与运行方式

### 1. Python 示例运行

直接运行 Python 算法脚本（只需安装 NumPy）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\iir_denoiser_demo.exe

# Linux/macOS 运行:
./build/iir_denoiser_demo
```

---

## 算法技术关键点

1. **EWMA 一阶 IIR 递归滤波**: $\text{out} = 0.37 \cdot \text{in} + 0.63 \cdot \text{prev}$。利用传感器噪点在时间上的随机不相关性，加权历史滤波平滑随机噪点，大幅降低编码器的帧间残差 (Residual)。
2. **Motion Guard 拖影/防鬼影机制**: 针对运动物体，如果仍强行滑动平均会产生严重的拖影 (Ghosting)。算法计算 $|in - prev|$，当像素差超过 `motion_guard` 阈值时强制直通原输入像素，完美兼顾静态去噪与动态防鬼影。
