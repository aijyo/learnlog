#!/usr/bin/env python3
"""
时域 EWMA IIR 去噪算法 RGB 全彩色肖像 Demo (Temporal IIR Denoise with Full-Color RGB Image)

本脚本使用 24-bit 全彩色人物肖像图片 (Full-Color RGB Image)：
1. 下载/加载开源标准 RGB 全彩色人物肖像图 (保留帽子、发丝、皮肤与背景丰富色彩)；
2. 在彩色人像上叠加摄像机感光元件 (CMOS Sensor) 高斯 ISO 彩色噪点；
3. 模拟帧 4 中人物平移运动；
4. 处理后导出全彩色 PNG 图像，并合成直观的彩色并排对比大图 `denoise_comparison.png`。

用法:
    python demo.py
"""

import numpy as np
from PIL import Image
import urllib.request
import os

PORTRAIT_URLS = [
    "https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg",
    "https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg"
]

def get_real_color_portrait(width=256, height=256):
    """
    获取 24-bit RGB 全彩色人物肖像图片。
    """
    local_path = "portrait_color_base.jpg"
    if not os.path.exists(local_path):
        print("   正在从开源测试样本库下载 RGB 全彩色人物肖像图片...")
        for url in PORTRAIT_URLS:
            try:
                urllib.request.urlretrieve(url, local_path)
                print("   ✔ 成功下载 24-bit RGB 全彩色人物肖像图！")
                break
            except Exception as e:
                print(f"   下载失败 ({e})，尝试下一个镜像...")

    if os.path.exists(local_path):
        img = Image.open(local_path).convert('RGB')
        img = img.resize((width, height), Image.Resampling.LANCZOS)
        return np.array(img, dtype=np.uint8)
    else:
        # 保底彩图生成
        print("   使用本地生成的彩色测试图...")
        arr = np.zeros((height, width, 3), dtype=np.uint8)
        arr[:, :, 0] = 180 # R
        arr[:, :, 1] = 120 # G
        arr[:, :, 2] = 80  # B
        return arr

def create_moving_color_frame(base_portrait, pos_shift=0):
    """
    对 RGB 彩色人物肖像施加水平位移，模拟视频序列中的人物运动
    """
    if pos_shift == 0:
        return base_portrait.copy()
    
    h, w, c = base_portrait.shape
    shifted = np.full_like(base_portrait, 40) # 移出区域填暗色背景
    if pos_shift > 0:
        shifted[:, pos_shift:, :] = base_portrait[:, :-pos_shift, :]
    else:
        shifted[:, :pos_shift, :] = base_portrait[:, -pos_shift:, :]
    return shifted

def apply_color_iir_denoise(frame_in: np.ndarray, state: np.ndarray, alpha: float = 0.37, motion_guard: int = 25, is_first: bool = False):
    """
    对 RGB 3 通道全彩色图像应用 EWMA IIR 去噪
    """
    h, w, c = frame_in.shape
    out = np.zeros_like(frame_in, dtype=np.uint8)
    
    if is_first:
        out[:] = frame_in[:]
        state[:] = frame_in[:]
        return out, state

    a = alpha
    b = 1.0 - alpha
    
    cur = frame_in.astype(np.float32)
    prev = state.astype(np.float32)
    
    # 按照 Luma / RGB 均值差判断运动幅度
    diff = np.max(np.abs(cur - prev), axis=2) # 3 通道最大差值

    if motion_guard > 0:
        mask = (diff > motion_guard)[:, :, np.newaxis] # 扩维广播至 3 通道
        filtered = a * cur + b * prev + 0.5
        res = np.where(mask, cur, filtered)
    else:
        res = a * cur + b * prev + 0.5

    out = np.clip(res, 0, 255).astype(np.uint8)
    state[:] = out[:]
    return out, state

if __name__ == '__main__':
    print("==========================================================")
    print("  Temporal EWMA IIR Denoise - RGB 全彩色肖像 Demo")
    print("==========================================================")

    np.random.seed(42)
    width, height = 256, 256
    
    state_pure = np.zeros((height, width, 3), dtype=np.uint8)
    state_guard = np.zeros((height, width, 3), dtype=np.uint8)

    print("\n1. 正在获取并准备 RGB 24-bit 全彩色人物肖像测试基准图 (256x256)...")
    base_portrait = get_real_color_portrait(width, height)

    frames_noisy = []
    frames_pure = []
    frames_guard = []

    print("\n2. 正在模拟 5 帧 RGB 彩色人物摄像视频序列...")
    print("   - 帧 1~3: 静态彩色人像，叠加真实 Sensor RGB 高斯噪点 (σ = 20)")
    print("   - 帧 4~5: 人物在镜头前发生水平运动 (位移 35 像素)")

    for frame_idx in range(1, 6):
        shift = 0 if frame_idx < 4 else 35
        clean_frame = create_moving_color_frame(base_portrait, pos_shift=shift)

        # 叠加 RGB 3 通道彩色高斯噪点
        noise = np.random.normal(0, 20, (height, width, 3))
        noisy_frame = np.clip(clean_frame.astype(np.float32) + noise, 0, 255).astype(np.uint8)

        # 应用纯 IIR 去噪 (无 Guard)
        pure_out, state_pure = apply_color_iir_denoise(noisy_frame, state_pure, alpha=0.37, motion_guard=0, is_first=(frame_idx==1))
        
        # 应用带 Motion Guard 的 IIR 去噪 (Guard = 25)
        guard_out, state_guard = apply_color_iir_denoise(noisy_frame, state_guard, alpha=0.37, motion_guard=25, is_first=(frame_idx==1))

        frames_noisy.append(noisy_frame)
        frames_pure.append(pure_out)
        frames_guard.append(guard_out)

    print("\n3. 正在导出处理后的全彩色 PNG 图像并合成 RGB 对比大图...")

    # 保存关键的 帧 4 (人物运动突变帧) 全彩色图像
    Image.fromarray(frames_noisy[3]).save("frame4_input_noisy.png")
    Image.fromarray(frames_pure[3]).save("frame4_output_pure_iir.png")
    Image.fromarray(frames_guard[3]).save("frame4_output_motion_guard.png")

    # 导出彩色人像拖影残差差异图 (|pure - guard| * 3.5)
    ghost_diff = np.abs(frames_pure[3].astype(np.int16) - frames_guard[3].astype(np.int16)) * 3.5
    ghost_diff_img = np.clip(ghost_diff, 0, 255).astype(np.uint8)
    Image.fromarray(ghost_diff_img).save("frame4_ghost_residual.png")

    # 拼接合成 1024x256 的全彩色人物肖像对比大图 `denoise_comparison.png`
    comparison_img = Image.new('RGB', (width * 4, height))
    comparison_img.paste(Image.fromarray(frames_noisy[3]), (0, 0))
    comparison_img.paste(Image.fromarray(frames_pure[3]), (width, 0))
    comparison_img.paste(Image.fromarray(frames_guard[3]), (width * 2, 0))
    comparison_img.paste(Image.fromarray(ghost_diff_img), (width * 3, 0))
    
    comparison_img.save("denoise_comparison.png")

    print("\nRGB 全彩色人物肖像处理完成！导出的对比图片:")
    print("  └─ frame4_input_noisy.png          : RGB 全彩色噪点输入帧 (帧4)")
    print("  └─ frame4_output_pure_iir.png       : 纯 IIR 滤波 (彩色人脸去噪，但左侧有彩色人像鬼影)")
    print("  └─ frame4_output_motion_guard.png   : 带 Motion Guard 直通 (RGB 全彩去噪且五官无鬼影)")
    print("  └─ frame4_ghost_residual.png        : 彩色鬼影拖影残差图")
    print("  └─ denoise_comparison.png           : 4 并排 1024x256 全彩色人像对比大图")
