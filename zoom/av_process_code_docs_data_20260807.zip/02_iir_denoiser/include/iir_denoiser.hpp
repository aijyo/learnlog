#pragma once
/**
 * @file iir_denoiser.hpp
 * @brief 自包含的时域 EWMA IIR 视频去噪算法 (Temporal IIR Denoise)
 * 
 * 零外部依赖，仅包含 C++ 标准库 <cstdint>, <vector>, <cstddef>。
 */

#include <cstdint>
#include <vector>
#include <cstddef>

namespace standalone::denoise {

/**
 * @brief 时域 EWMA IIR 去噪配置与核心 Apply 函数
 */
struct IirDenoise {
    static constexpr float kAlpha = 0.37f; // 默认 EWMA 系数 (0.37 * in + 0.63 * prev)

    float alpha = kAlpha;
    int   motion_guard = 0; // 0 = 纯 IIR; >0 = 当 |in - prev| > motion_guard 时启用防拖影直通

    /**
     * @brief 原平去噪计算 (In-place/递归状态更新)
     * @param in 输入当前帧 Luma 内存指针
     * @param out 输出去噪帧 Luma 内存指针
     * @param state 历史滤波状态帧 Luma 内存指针 (尺寸同 input)
     * @param n 采样点总数 (w * h)
     * @param first 是否为视频序列的首帧 (首帧直接拷贝输入)
     */
    void Apply(const uint8_t* in, uint8_t* out, uint8_t* state, size_t n, bool first) const {
        const float a = alpha, b = 1.0f - alpha;
        for (size_t i = 0; i < n; ++i) {
            int prev = state[i];
            int cur  = in[i];
            int v;
            if (first) {
                v = cur;
            } else if (motion_guard && (cur - prev > motion_guard || prev - cur > motion_guard)) {
                v = cur;                              // 运动区域直通，防止运动拖影/鬼影
            } else {
                v = int(a * cur + b * prev + 0.5f);   // out = 0.37*in + 0.63*prev (EWMA 一阶 IIR)
            }
            if (v < 0) v = 0; 
            if (v > 255) v = 255;
            out[i] = uint8_t(v);
            state[i] = uint8_t(v);                    // 递归反馈状态
        }
    }
};

/**
 * @brief 自动维护历史帧状态的 TemporalDenoiser 封装类
 */
class TemporalDenoiser {
public:
    explicit TemporalDenoiser(IirDenoise cfg = {}) : cfg_(cfg) {}

    /**
     * @brief 对输入的当前帧做 IIR 去噪处理
     */
    void Filter(const uint8_t* in, uint8_t* out, size_t n) {
        if (state_.size() != n) { 
            state_.assign(n, 0); 
            first_ = true; 
        }
        cfg_.Apply(in, out, state_.data(), n, first_);
        first_ = false;
    }

    /**
     * @brief 重置状态（场景切换或切流时调用）
     */
    void Reset() { 
        first_ = true; 
    }

    const IirDenoise& config() const { return cfg_; }
    IirDenoise& config() { return cfg_; }

private:
    IirDenoise cfg_;
    std::vector<uint8_t> state_;
    bool first_ = true;
};

} // namespace standalone::denoise
