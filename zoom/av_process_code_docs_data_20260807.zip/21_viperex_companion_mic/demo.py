#!/usr/bin/env python3
from pathlib import Path
import argparse,math,wave
import numpy as np
from PIL import Image,ImageDraw
def pack(xml,blob):return len(xml).to_bytes(8,'little')+bytes(x^0xa7 for x in xml+blob)
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=Path('output'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 xml=b'<net name="fake"/>';resource=pack(xml,b'\x01\x02\x03');(a.out/'mock_resource.bin').write_bytes(resource)
 scores=[2,4,8,9,3,10];e=0;ew=[]
 for s in scores:e=.7*e+.3*s;ew.append(e)
 im=Image.new('RGB',(1000,430),'white');d=ImageDraw.Draw(im);d.text((25,20),'Companion Mic scheduler: 1.5s chunks / 3s CAM++ window',fill='black')
 for i,v in enumerate(ew):x=80+i*140;y=350-int(v*28);d.rectangle((x,y,x+90,350),fill=(50,170,80) if v>5 else (70,120,210));d.text((x,365),f'{i*1.5:.1f}s',fill='black');d.text((x,y-20),f'{v:.2f}',fill='black')
 im.save(a.out/'companion_mic_timeline.png');print(f'resource={len(resource)} ewma={ew}')
if __name__=='__main__':main()
