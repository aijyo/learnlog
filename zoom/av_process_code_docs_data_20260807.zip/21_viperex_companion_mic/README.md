# Companion Mic 资源容器、调度与 OpenVINO 边界

演示 XOR-0xA7 + 8-byte XML length 资源、1.5s chunk、3s CAM++ window 和 Picknet EWMA>5。Python 输出调度图与 mock 容器；C++ 展示容器 round-trip。

`[BODY]`：容器/时间窗/优先级结构；`BOUNDARY ⛔W`：CAM++、Picknet、embedding 模型和 OpenVINO resolver 由用户自备模型/OSS runtime 注入。证据：`viperex_runtime.hpp`、`viperex_pipeline.hpp`、`viperex_openvino_loader.hpp`。
