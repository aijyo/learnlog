#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
std::vector<uint8_t> pack(std::string xml,std::vector<uint8_t>bin){std::vector<uint8_t>o(8);uint64_t n=xml.size();for(int i=0;i<8;i++)o[i]=uint8_t(n>>(8*i));for(char c:xml)o.push_back(uint8_t(c)^0xA7);for(auto b:bin)o.push_back(b^0xA7);return o;}
int main(){auto r=pack("<net/>",{1,2,3,4});uint64_t n=0;for(int i=0;i<8;i++)n|=uint64_t(r[i])<<(8*i);std::string xml;for(size_t i=8;i<8+n;i++)xml.push_back(char(r[i]^0xA7));std::cout<<"resource bytes="<<r.size()<<" xml_len="<<n<<" xml="<<xml<<"\n";double ewma=0;for(double score:{2.,4.,8.,9.}){ewma=.7*ewma+.3*score;std::cout<<"picknet ewma="<<ewma<<" active="<<(ewma>5)<<"\n";}std::cout<<"chunk=1.5s cam_window=3s\n";}
