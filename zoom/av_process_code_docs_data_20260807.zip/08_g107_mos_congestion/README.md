# 08_g107_mos_congestion — G.107 MOS 评估、迟滞告警与离散带宽分配独立项目

> 证据校准：当前 MOS→score、score→带宽和 3.0/3.4/3.9 阈值是教学 stand-in；逆向中可见的候选点包括 3.75/3.64，但服务端映射仍为 `[PARTIAL/INFERRED]`，不能把 demo 数值当作生产常量。

本目录为一个**完全自包含 (Standalone)** 的独立小项目，展示实时音视频传输控制中用于 QoS 评估的 **ITU-T G.107 E-Model MOS 估算**、**双门限迟滞网络告警 (NetWarning Hysteresis)** 与 **服务端主导离散带宽按权分配 (`DistributeBandwidth`)** 算法。

---

## 目录结构

```
08_g107_mos_congestion/
├── CMakeLists.txt              # 独立 CMake 构建脚本
├── include/
│   └── g107_mos_congestion.hpp # 零依赖自包含 C++ 算法头文件
├── main.cpp                    # C++ 控制台调试示例 (时延衰减、迟滞告警与多流带宽分配)
├── demo.py                     # Python 真实 dance_outdoor.mp4 视频网络拥塞与 MOS 降级 Demo
├── README.md                   # 本独立小项目说明文档
├── mos_congestion_dance.gif    # 展示 MOS 降级与迟滞告警演变的 GIF 动图
├── mos_congestion_dance.mp4    # 导出的 1280x720 100 帧 MP4 视频
├── mos_congestion_panel.png    # G.107 MOS 评估折线与双门限迟滞告警区间分析面板图
└── mos_congestion_wiki.html   # 暗色极客风格原理与 Wiki 说明网页
```

---

## 编译与运行方式

### 1. Python 示例运行

直接运行 Python 算法脚本（只需安装 OpenCV / NumPy / Pillow）：

```bash
python demo.py
```

### 2. C++ 项目编译与运行

在任意操作系统（Windows / Linux / macOS）下均可独立编译：

```bash
cmake -S . -B build
cmake --build build --config Release

# Windows 运行:
.\build\Release\g107_mos_congestion_demo.exe

# Linux/macOS 运行:
./build/g107_mos_congestion_demo
```

---

## 算法技术关键点

1. **ITU-T G.107 E-Model MOS 估算**: 根据网络丢包、时延及 FEC 恢复率，通过非线性 log 损伤函数计算 R-Factor 并归一化为 MOS 评分 ($1.0 \sim 4.5$)。
2. **双门限迟滞告警 (`NetWarning`)**: 触发门限 $MOS < 3.0$；解除门限 $MOS > 3.4$。有效避免网络轻微抖动时告警信号频繁闪烁。
3. **离散带宽按权分配 (`DistributeBandwidth`)**: 根据各流的 `BwLevel` (L1~L4) 权重切分总带宽 $B_{total}$，实现平滑降级。
