#pragma once
/**
 * @file g107_mos_congestion.hpp
 * @brief 自包含的 ITU-T G.107 MOS 评估、双门限迟滞告警与服务端主导离散带宽分配算法
 * 
 * 零外部依赖，仅包含 C++ 标准库 <cstdint>, <vector>, <utility>, <cmath>, <algorithm>, <string>, <cstddef>.
 */

#include <cstdint>
#include <vector>
#include <utility>
#include <cmath>
#include <algorithm>
#include <string>
#include <cstddef>

namespace standalone::congestion {

/**
 * @brief 网络 QoS 测量指标
 */
struct QosMetrics {
    double   loss_rate        = 0.0; // 丢包率 (0.0 .. 1.0)
    double   fec_ratio        = 0.0; // FEC 纠错恢复率 (0.0 .. 1.0)
    double   plc_ratio        = 0.0; // 丢包隐藏占比 (0.0 .. 1.0)
    uint32_t jitter_ms        = 0;   // 抖动 (毫秒)
    uint32_t abs_net_delay_ms = 0;   // 绝对网络延迟 (毫秒)
};

/**
 * @brief ITU-T G.107 E-Model 时延损伤计算 Id (精确分段 log 函数)
 */
inline double DelayImpairment(uint32_t delay_ms) {
    double d = (double)delay_ms;
    if (d <= 100.0)  return 0.0;
    if (d <= 500.0)  return std::log2(d / 100.0) + (d - 100.0) / 55.0;
    if (d <= 1000.0) return 2.0 * std::log2((d - 400.0) / 100.0) + 0.01 * (d - 500.0) + 9.6;
    if (d <= 2000.0) return 0.008 * (d - 1000.0) + 19.8;
    if (d <= 3500.0) return 0.006 * (d - 2000.0) + 27.8;
    double id = 0.008 * (d - 3500.0) + 36.8;
    return id < 60.0 ? id : 60.0;
}

/**
 * @brief R-Factor 转化为 MOS 评分 (1.0 .. 4.5)
 */
inline double RtoMos(double R) {
    if (R <= 0.0)   return 1.0;
    if (R >= 100.0) return 4.5;
    return 1.0 + 0.035 * R + R * (R - 60.0) * (100.0 - R) * 7.0e-6;
}

/**
 * @brief 计算基础 R 因子与最终 MOS 分值
 */
inline double BaseRfactor(const QosMetrics& m) {
    double residual = m.loss_rate * (1.0 - m.fec_ratio); // FEC 恢复后的残余丢包
    double R = 93.2 - residual * 100.0 * 2.5 - m.plc_ratio * 100.0 * 0.8;
    return R < 0.0 ? 0.0 : R;
}

inline double EstimateMos(const QosMetrics& m, int* R_x10 = nullptr) {
    double R = BaseRfactor(m) - DelayImpairment(m.abs_net_delay_ms);
    if (R < 0.0) R = 0.0; 
    else if (R > 93.2) R = 93.2;
    if (R_x10) *R_x10 = (int)(R * 10.0);
    return RtoMos(R);
}

enum class NetScore : uint8_t { S0=0, S1, S2, S3, S4, S5 };
enum class BwLevel  : uint8_t { L1=1, L2, L3, L4 };

inline NetScore ScoreFromMos(double mos) {
    if (mos >= 4.2) return NetScore::S5;
    if (mos >= 3.9) return NetScore::S4;
    if (mos >= 3.5) return NetScore::S3;
    if (mos >= 3.0) return NetScore::S2;
    if (mos >= 2.5) return NetScore::S1;
    return NetScore::S0;
}

inline BwLevel BwFromScore(NetScore s) {
    switch (s) {
        case NetScore::S5: case NetScore::S4: return BwLevel::L4;
        case NetScore::S3:                    return BwLevel::L3;
        case NetScore::S2:                    return BwLevel::L2;
        default:                              return BwLevel::L1;
    }
}

/**
 * @brief 双门限迟滞网络告警触发器 (NetWarning / MCM_NW_WARNING)
 * MOS < 3.0 触发告警；只有当 MOS 回升恢复至 > 3.4 时才解除告警，有效防止告警频繁抖动闪烁！
 */
class NetWarning {
public:
    bool Update(double mos, double on_thr = 3.0, double off_thr = 3.4) {
        bool prev = active_;
        if (!active_ && mos < on_thr)       active_ = true;
        else if (active_ && mos > off_thr) active_ = false;
        return active_ != prev; // 状态发生改变返回 true
    }
    bool active() const { return active_; }

private:
    bool active_ = false;
};

/**
 * @brief 按 BwLevel 权重切分分配总带宽 (DistributeBandwidth)
 */
struct StreamBudget {
    uint32_t id;
    BwLevel  level;
    uint32_t assigned_bps;
};

inline std::vector<StreamBudget> DistributeBandwidth(uint32_t total_bps,
                                                      const std::vector<std::pair<uint32_t, BwLevel>>& streams) {
    uint32_t wsum = 0;
    for (const auto& s : streams) wsum += (uint32_t)s.second;

    std::vector<StreamBudget> out;
    for (const auto& s : streams) {
        uint32_t w = (uint32_t)s.second;
        uint32_t assigned = wsum ? (uint32_t)((uint64_t)total_bps * w / wsum) : 0;
        out.push_back({ s.first, s.second, assigned });
    }
    return out;
}

/**
 * @brief 媒体通道总调度器 (MediaChannel)
 */
struct ChannelDecision {
    double   mos = 0.0;
    int      r_x10 = 0;
    NetScore score = NetScore::S5;
    BwLevel  bw = BwLevel::L4;
    int      fec_level = 3;       // 对应 Level 3/4/5 防护
    bool     warning = false;     // 网络告警状态
    bool     warning_changed = false;
};

class MediaChannel {
public:
    ChannelDecision OnQosTick(const QosMetrics& m) {
        ChannelDecision d;
        d.mos             = EstimateMos(m, &d.r_x10);
        d.score           = ScoreFromMos(d.mos);
        d.bw              = BwFromScore(d.score);
        d.fec_level       = (m.loss_rate < 0.05) ? 3 : ((m.loss_rate < 0.10) ? 4 : 5);
        d.warning_changed = warn_.Update(d.mos);
        d.warning         = warn_.active();
        last_ = d;
        return d;
    }

    const ChannelDecision& last() const { return last_; }

    void AddStream(uint32_t id, BwLevel lvl) {
        streams_.push_back({ id, lvl });
    }

    std::vector<StreamBudget> Distribute(uint32_t total_bps) const {
        return DistributeBandwidth(total_bps, streams_);
    }

private:
    NetWarning warn_;
    ChannelDecision last_;
    std::vector<std::pair<uint32_t, BwLevel>> streams_;
};

} // namespace standalone::congestion
