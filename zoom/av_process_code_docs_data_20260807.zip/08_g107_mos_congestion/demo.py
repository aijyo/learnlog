#!/usr/bin/env python3
"""
G.107 MOS 评估、迟滞告警与离散带宽分配 - 基于真实本地视频 (dance_outdoor.mp4) Demo
(G.107 MOS Evaluation, NetWarning Hysteresis & Bandwidth Distribution Demo)

用法:
    python demo.py
"""

import cv2
import numpy as np
from PIL import Image, ImageDraw
import os

VIDEO_PATH = r"D:\code\work\research\ai-harness\data\videos\dance_outdoor.mp4"

def delay_impairment(delay_ms):
    """G.107 E-Model 时延损伤计算"""
    d = float(delay_ms)
    if d <= 100.0: return 0.0
    if d <= 500.0: return np.log2(d / 100.0) + (d - 100.0) / 55.0
    if d <= 1000.0: return 2.0 * np.log2((d - 400.0) / 100.0) + 0.01 * (d - 500.0) + 9.6
    if d <= 2000.0: return 0.008 * (d - 1000.0) + 19.8
    if d <= 3500.0: return 0.006 * (d - 2000.0) + 27.8
    id_val = 0.008 * (d - 3500.0) + 36.8
    return min(60.0, id_val)

def estimate_mos(delay_ms, loss_rate):
    """估算 G.107 MOS 评分 (1.0 .. 4.5)"""
    r_base = 93.2 - loss_rate * 250.0
    r = max(0.0, min(93.2, r_base - delay_impairment(delay_ms)))
    
    if r <= 0: return 1.0
    if r >= 100: return 4.5
    mos = 1.0 + 0.035 * r + r * (r - 60.0) * (100.0 - r) * 7.0e-6
    return max(1.0, min(4.5, mos))

def generate_congestion_panel(filename="mos_congestion_panel.png"):
    """绘制 G.107 MOS 评分折线、迟滞告警区间与带宽分配分析面板"""
    width, height = 800, 360
    img = Image.new('RGB', (width, height), color=(11, 15, 25))
    draw = ImageDraw.Draw(img)

    margin_l, margin_r, margin_t, margin_b = 60, 40, 60, 50
    plot_w = width - margin_l - margin_r
    plot_h = height - margin_t - margin_b

    # 背景网格
    for mos_val in [1.0, 2.0, 3.0, 3.4, 4.0, 4.5]:
        y_pos = margin_t + plot_h - int((mos_val - 1.0) / 3.5 * plot_h)
        draw.line([(margin_l, y_pos), (width - margin_r, y_pos)], fill=(31, 41, 55), width=1)
        draw.text((15, y_pos - 6), f"MOS {mos_val:.1f}", fill=(156, 163, 175))

    # 3.0 (ON) 和 3.4 (OFF) 双门限迟滞红/绿虚线
    on_y = margin_t + plot_h - int((3.0 - 1.0) / 3.5 * plot_h)
    off_y = margin_t + plot_h - int((3.4 - 1.0) / 3.5 * plot_h)
    draw.line([(margin_l, on_y), (width - margin_r, on_y)], fill=(239, 68, 68), width=2)
    draw.line([(margin_l, off_y), (width - margin_r, off_y)], fill=(52, 211, 153), width=2)
    
    draw.text((width - 150, on_y - 15), "3.0 Warning ON Threshold", fill=(239, 68, 68))
    draw.text((width - 150, off_y + 5), "3.4 Warning OFF Threshold", fill=(52, 211, 153))

    # 模拟 100 帧网络传输 MOS 变化
    delays = [50]*30 + [int(50 + (i-30)*35) for i in range(30, 70)] + [int(1450 - (i-70)*35) for i in range(70, 100)]
    mos_list = [estimate_mos(d, 0.02) for d in delays]

    # 迟滞告警逻辑
    active = False
    warn_flags = []
    for m in mos_list:
        if not active and m < 3.0: active = True
        elif active and m > 3.4: active = False
        warn_flags.append(active)

    points = []
    for idx, m in enumerate(mos_list):
        x = margin_l + int((idx + 1) / 100.0 * plot_w)
        y = margin_t + plot_h - int((m - 1.0) / 3.5 * plot_h)
        points.append((x, y))

    for i in range(len(points) - 1):
        color = (239, 68, 68) if warn_flags[i] else (56, 189, 248)
        draw.line([points[i], points[i+1]], fill=color, width=3)

    draw.text((margin_l, 15), "ITU-T G.107 MOS Evaluation & Hysteresis NetWarning Panel", fill=(255, 255, 255))
    draw.text((margin_l, 35), "Blue Line: MOS Score | Red Line Segment: Active Warning Zone (Prevent Flashing)", fill=(156, 163, 175))

    img.save(filename)
    return filename

if __name__ == '__main__':
    print("==========================================================")
    print("  G.107 MOS 评估与离散带宽分配 - 本地 dance_outdoor.mp4 Demo")
    print("==========================================================")

    if not os.path.exists(VIDEO_PATH):
        print(f"❌ 未找到本地视频文件: {VIDEO_PATH}")
        exit(1)

    print(f"\n1. 正在从本地视频读取数据...")
    cap = cv2.VideoCapture(VIDEO_PATH)
    
    raw_frames = []
    while len(raw_frames) < 100:
        ret, frame = cap.read()
        if not ret: break
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        raw_frames.append(rgb_frame)
    cap.release()

    print(f"   ✔ 成功读取 {len(raw_frames)} 帧真实舞蹈视频！")

    print("\n2. 正在模拟 100 帧网络延迟抖动、G.107 MOS 评估与分辨率自适应调控...")
    delays = [50]*30 + [int(50 + (i-30)*35) for i in range(30, 70)] + [int(1450 - (i-70)*35) for i in range(70, 100)]
    
    annotated_frames_pil = []
    warn_active = False

    for idx, frame_rgb in enumerate(raw_frames):
        d_ms = delays[idx]
        mos = estimate_mos(d_ms, 0.02)

        # 迟滞告警逻辑
        if not warn_active and mos < 3.0: warn_active = True
        elif warn_active and mos > 3.4: warn_active = False

        # 根据 MOS 决定带宽级别 BwLevel，并进行降采样/恢复
        if mos < 2.5:
            # 极差网络 (BwLevel L1): 降采样至 320x180 保证不卡顿
            resized = Image.fromarray(frame_rgb).resize((320, 180), Image.Resampling.BILINEAR)
            rendered = resized.resize((1280, 720), Image.Resampling.NEAREST)
            mode_str = "BwLevel L1 (Low-Res 320x180 Mode)"
        elif mos < 3.5:
            # 弱网 (BwLevel L2/L3): 标清 640x360
            resized = Image.fromarray(frame_rgb).resize((640, 360), Image.Resampling.BILINEAR)
            rendered = resized.resize((1280, 720), Image.Resampling.BILINEAR)
            mode_str = "BwLevel L2/L3 (SD 640x360 Mode)"
        else:
            # 良好 (BwLevel L4): 原画 1280x720
            rendered = Image.fromarray(frame_rgb).resize((1280, 720), Image.Resampling.LANCZOS)
            mode_str = "BwLevel L4 (HD 1280x720 Mode)"

        draw = ImageDraw.Draw(rendered)
        draw.rectangle([0, 0, 1280, 45], fill=(0, 0, 0))
        
        status_color = (239, 68, 68) if warn_active else (52, 211, 153)
        draw.text((15, 12), f"Frame {idx+1:3d} | Delay: {d_ms:4d} ms | G.107 MOS: {mos:.2f} | Mode: {mode_str} | Warning: {'🚨 ON' if warn_active else 'OFF'}", fill=status_color)

        annotated_frames_pil.append(rendered)

        if idx == 55: # 严重拥塞关键帧
            rendered.save("mos_congestion_frame55.png")

    print("\n3. 正在导出 100 帧动态 GIF 与 MP4 视频...")
    
    gif_path = "mos_congestion_dance.gif"
    sub_sample = annotated_frames_pil[::2]
    sub_sample[0].save(
        gif_path,
        save_all=True,
        append_images=sub_sample[1:],
        duration=80,
        loop=0
    )

    mp4_path = "mos_congestion_dance.mp4"
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out_writer = cv2.VideoWriter(mp4_path, fourcc, 25.0, (1280, 720))
    for pimg in annotated_frames_pil:
        bgr = cv2.cvtColor(np.array(pimg), cv2.COLOR_RGB2BGR)
        out_writer.write(bgr)
    out_writer.release()

    panel_file = generate_congestion_panel("mos_congestion_panel.png")

    print(f"\n✔ 处理完成！全套真实 Demo 产物导出完毕:")
    print(f"  └─ mos_congestion_dance.gif     : 展示拥塞时 MOS 降级与迟滞告警演变的 GIF 动图")
    print(f"  └─ mos_congestion_dance.mp4     : 导出的高清 1280x720 100 帧 MP4 视频")
    print(f"  └─ mos_congestion_panel.png     : G.107 MOS 评估折线与双门限迟滞告警区间分析面板图")
