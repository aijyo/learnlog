#include "g107_mos_congestion.hpp"
#include <iostream>
#include <vector>
#include <iomanip>

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "  G.107 MOS 评估、迟滞告警与离散带宽分配 Demo (C++)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    // 1. 验证网络时延与丢包下的 G.107 MOS 衰减
    std::cout << "\n[1. 验证 ITU-T G.107 E-Model 时延与 MOS 评估衰减]:" << std::endl;
    uint32_t delays_ms[] = { 50, 150, 450, 800, 1500, 3000 };
    for (uint32_t d : delays_ms) {
        standalone::congestion::QosMetrics m;
        m.abs_net_delay_ms = d;
        m.loss_rate = 0.02; // 2% 丢包
        double mos = standalone::congestion::EstimateMos(m);
        auto score = standalone::congestion::ScoreFromMos(mos);
        auto bw = standalone::congestion::BwFromScore(score);

        std::cout << "  - 网络时延: " << std::setw(4) << d << " ms "
                  << " | G.107 MOS: " << std::fixed << std::setprecision(2) << mos
                  << " | NetScore: S" << (int)score
                  << " | BwLevel: L" << (int)bw << std::endl;
    }

    // 2. 验证双门限迟滞网络告警 (NetWarning / MCM_NW_WARNING)
    std::cout << "\n[2. 验证双门限迟滞网络告警 (防止告警频繁抖动闪烁)]:" << std::endl;
    standalone::congestion::NetWarning warn;
    double sim_mos[] = { 4.2, 3.8, 2.8, 3.2, 3.3, 3.6, 4.1 };

    for (double mos : sim_mos) {
        bool state_changed = warn.Update(mos, 3.0, 3.4);
        std::cout << "  - MOS: " << std::fixed << std::setprecision(1) << mos
                  << " | 告警状态: " << (warn.active() ? "【🚨 告警 ON】" : "【正常 OFF】")
                  << (state_changed ? " <-- (状态发生切换/触发通信)" : "") << std::endl;
    }

    // 3. 验证多流离散带宽分配 (DistributeBandwidth)
    std::cout << "\n[3. 验证多流离散带宽分配 (总可用带宽: 2.0 Mbps)]:" << std::endl;
    standalone::congestion::MediaChannel channel;
    channel.AddStream(101, standalone::congestion::BwLevel::L4); // 主人像视频流 (L4, 权重 4)
    channel.AddStream(102, standalone::congestion::BwLevel::L3); // 屏幕共享流 (L3, 权重 3)
    channel.AddStream(103, standalone::congestion::BwLevel::L1); // 语音音频流 (L1, 权重 1)

    uint32_t total_bandwidth = 2000000; // 2.0 Mbps
    auto budgets = channel.Distribute(total_bandwidth);

    std::cout << "  - 总传输带宽: " << total_bandwidth / 1000 << " Kbps" << std::endl;
    for (const auto& b : budgets) {
        std::cout << "      Stream ID: " << b.id 
                  << " | BwLevel: L" << (int)b.level 
                  << " | 配给带宽: " << b.assigned_bps / 1000 << " Kbps ("
                  << std::fixed << std::setprecision(1) << (b.assigned_bps * 100.0 / total_bandwidth) << "%)" << std::endl;
    }

    std::cout << "\n演示完成！" << std::endl;
    return 0;
}
