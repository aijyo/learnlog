# Codec Reconstruction — Feasibility & Architecture Plan

Scope of this document: **plan only** — no external libraries are pulled and no code is
landed. It defines *what* a codec reconstruction would mean, *how far* it can honestly go,
*which* libraries and interfaces we'd use, and *how* we'd prove fidelity. Decision gate before
any integration work.

Grounded in what we already reverse-engineered (see `zoom_weaknet_capture_analysis.html` §6 and
the `recon/` headers). Nothing here proposes copying Zoom's proprietary source — it proposes
wiring **permissively-licensed reference codecs** behind the interfaces we recovered, driven by
the control parameters/constants we recovered.

---

## 0. Verdict at a glance

| Codec | Decode | Encode | Basis |
|---|---|---|---|
| **AV1** (zbt) | ✅ **interop-exact — BUILT+RUN** (dav1d C-only; decoded a real 800×800 AV1 keyframe) | ⚠️ **functional-equivalent only** (libaom/SVT-AV1) | AOMedia, royalty-free; decoder is spec-determined |
| **Opus** (viper) | ✅ **interop-exact — BUILT+RUN** (libopus 1.5.2; decoded a real Opus packet + PLC) | ⚠️ **functional-equivalent only** (libopus) | IETF RFC 6716, royalty-free |
| **SNAC / AI-codec 121** (viperex/viper) | ❌ needs trained weights | ❌ | neural; weights unrecoverable + are Zoom IP |
| **DRED PLC** | ⚠️ arch open in Opus 1.5 | ⚠️ | upstreamed to libopus 1.5, but Zoom's tuning/model differs |
| **CAM++ / Picknet / RAISR / EDNet** | ❌ trained weights | ❌ | neural; interfaces only (see `viperex_runtime.hpp`) |

"interop-exact" = our decoder produces the **same samples/frames** as any conformant decoder,
so it decodes real Zoom streams correctly. That is the legitimate meaning of "1:1" for a
standardized codec. "functional-equivalent" = same capability and knobs, **not** byte-identical
bitstream (encoder output is not uniquely determined by the spec).

---

## 1. What "复刻编解码器" can mean (three fidelity tiers)

- **T-interop (decoder)** — behavior fixed by the standard. Any conformant implementation yields
  identical output for a given bitstream. Reproducible, and it interoperates with Zoom.
- **T-functional (encoder)** — the spec constrains the *bitstream syntax*, not the *encoder
  choices* (rate control, mode decisions, SC-tool heuristics, SVC layering). We can match the
  **capabilities and parameters** we recovered, producing valid streams a Zoom client decodes,
  but not Zoom's exact bytes. Byte-exact would require Zoom's encoder source + tuning.
- **T-impossible (neural)** — the "algorithm" is trained weights. Not recoverable from static RE;
  reproducing them would also be Zoom's IP. We keep interfaces + I/O shapes + scheduling only.

---

## 2. Codec inventory (from our reverse engineering)

- **AV1 — `zbt.dll`** (`zbt_av1_codec.hpp`): `Av1EncInterfaceCreate/DecInterfaceCreate`,
  screen-content cores `zbtCScEncoderCore/zbtCScDecoderCore` selected by `(mode & 0xF) == 2`,
  `Av1{Enc,Dec}SpecialFeature` (OBU-header/packetizer sub-objects), HW decode
  `zltCWinHwDecSpecificCodecAV1`, and a full software OBU parser (seq/frame/metadata incl.
  ITU-T T.35 + HDR, multithreaded tiles). Bitstream = standard AV1 OBUs.
  **Encoder fingerprint (binary string scan of `zbt.dll`):** ZERO hits for `AOMedia`, `aom_codec`,
  `libaom`, `SVT-AV1`, `dav1d`, `libvpx`, `WebM`. Combined with the Zoom-only class names
  (`ns_av1::zbtCScEncoderCore`, `zbtCObuHdrParser`), this says zbt's AV1 codec is **Zoom-proprietary**
  (symbols stripped, no OSS attribution) — it is **not** an identifiable, pinnable build of a public
  encoder. This is the decisive input to the "byte-identical encoder?" question (§5.1).
- **Opus — `viper.dll`** (`viper_audio_engine.hpp`, `weaknet_reference.hpp`): Opus-derived with
  in-band FEC (`extrafec`), max low-bitrate-redundancy (`maxlbrr`), multi-FEC, and deep-redundancy
  PLC (DRED). Recovered control gates: main-codec 113/116 → enable AI-codec 121; `SetFECStatus`
  returns −1/8003 for RED; SNAC↔Opus switching thresholds.
- **Neural — `viperex.dll`** (`viperex_runtime.hpp`): CAM++ speaker embedding, Picknet/OSD
  active-speaker, lipsync — OpenVINO IR models embedded as XOR-`0xA7` PE resources. Plus SNAC
  neural audio codec and AI-codec 121 referenced from viper. **Weights = the codec.**

---

## 3. Library selection & licensing (all permissive, AV1/Opus royalty-free)

| Need | Library | License | Notes |
|---|---|---|---|
| AV1 decode | **dav1d** | BSD-2-Clause | fast, portable, VLC/FFmpeg decoder; decodes SC tools |
| AV1 decode/encode (ref) | **libaom** | BSD-2-Clause + **AOM Patent License 1.0** | reference enc+dec; `AOM_CONTENT_SCREEN` |
| AV1 encode (fast) | **SVT-AV1** | BSD-3-Clause-Clear + AOM patent | production encoder; `--scm` screen-content mode |
| Opus enc/dec | **libopus** | BSD-3-Clause | RFC 6716; **1.5** adds DRED + neural PLC |

Royalty posture: **AV1 is royalty-free** under AOMedia; **Opus is royalty-free** (IETF/Xiph).
No patent-pool exposure like H.264/HEVC. (If Zoom ever used H.264/HEVC we'd flag MPEG-LA/Access
Advance — not the case here.)

---

## 4. Architecture — wiring reference libs behind the interfaces we already built

The `recon/` interfaces were reconstructed to match Zoom's ABI shape, so the reference codecs
slot in behind them with a thin adapter. No Zoom code involved; only our interface + the lib.

### 4.1 AV1 decode → `recon::zbt::IAv1Decoder` (interop-exact)
```
IAv1Decoder::Decode(obu, n, nv12, cap)
   └── dav1d:  dav1d_open(&ctx, &settings)
              dav1d_send_data(ctx, {obu,n})
              dav1d_get_picture(ctx, &pic)   → copy pic.data → nv12
   last_parse_error() ← map dav1d error codes onto our Av1ParseError enum
```
The OBU parser we verified (seq/frame/metadata) confirms the input is spec AV1, so dav1d decodes
Zoom's `zbtCScDecoderCore` output directly. **This is the closest thing to true 1:1** and the
recommended first deliverable.

### 4.2 AV1 encode → `recon::zbt::IAv1Encoder` (functional-equivalent)
```
Av1EncParams (recovered)         →  libaom / SVT-AV1 knob
  screen_content=true            →  AOME_SET_TUNE_CONTENT = AOM_CONTENT_SCREEN  (SVT: --scm 2)
  (mode & 0xF)==2 (SC core)      →  enable palette + IntraBC (aom does under screen tune)
  spatial_layers/temporal_layers →  AV1E_SET_SVC_PARAMS (aom_svc_params_t)
  bitrate / qp / frame_rate      →  aom rc_target_bitrate / cq_level / g_timebase
  ForceKeyframe()                →  AOM_EFLAG_FORCE_KF
```
Produces valid AV1 a Zoom client decodes; **not** byte-identical to Zoom's encoder.

### 4.3 Opus → viper audio path (decode interop-exact; encode functional)
```
decode:  opus_decoder_create(48000, ch) ; opus_decode(...)            → interop-exact
encode:  opus_encoder_create(...) driven by recovered gates:
  extrafec  → OPUS_SET_INBAND_FEC(1)
  maxlbrr / loss → OPUS_SET_PACKET_LOSS_PERC(p)
  bitrate   → OPUS_SET_BITRATE(bps)
  DRED (1.5)→ OPUS_SET_DRED_DURATION(...)   (approximation of Zoom's deep redundancy)
```

### 4.4 Neural (SNAC / AI-121 / CAM++ / Picknet / RAISR / EDNet)
Interfaces only (already in `viperex_runtime.hpp` / `viper_audio_engine.hpp`). A *functional*
twin would require: (a) re-implement the published architectures (SNAC, CAM++ are public archs),
(b) obtain/So train equivalent weights — **out of scope** and legally Zoom's. We can wire an
OpenVINO/ONNX backend to satisfy the interface if someone supplies licensed weights.

---

## 5. Fidelity — what each path proves

- **Decoders**: AV1 (dav1d) and Opus (libopus) are deterministic per spec → our decoded
  output equals any conformant decoder's, i.e. equals what Zoom's own decoder yields. **1:1 in the
  only sense that is well-defined for a decoder.**
- **Encoders**: functional equivalence (valid, decodable, same feature set + recovered params).
  Byte-exactness is explicitly a **non-goal** (impossible without Zoom's encoder internals; also
  not meaningful).
- **Neural**: no fidelity claim without weights.

---

## 5.1 Can the encoder be byte-identical (from IDA analysis)? — direct answer

**No — and the binary evidence rules out even the one path that could have worked.** Three
independent reasons, in order of decisiveness:

1. **zbt's encoder is Zoom-proprietary, not a pinnable OSS build.** The only route to a byte-exact
   encoder is: "it's an *unmodified* known encoder (libaom/SVT-AV1) at an *identifiable* version, so
   we link that exact version and feed the exact params." The fingerprint scan (§2) kills this —
   **zero** `AOMedia`/`aom`/`SVT`/`dav1d`/`libaom` strings; the codec is `ns_av1::zbtCScEncoderCore`,
   Zoom's own. We can't pin a version because there's no public encoder to pin.
2. **Encoder output isn't determined by the spec.** Even with the exact encoder, the bytes depend on
   thousands of internal decisions — RDO lambdas, motion search, partition/mode decision, per-block
   quantizer, entropy-context modeling, tile/thread determinism. IDA gives us the *config* (which
   tools, SVC layout, rate targets), not these micro-decisions.
3. **The per-frame parameter sequence is runtime/network-driven, not in the binary.** Zoom's rate
   controller picks QP/bitrate/frame-type *live* from network feedback (the mcm/asproxy bw_level and
   loss signals we reverse-engineered). Those choices don't exist statically — they only exist during
   a call. So even a perfect encoder clone would need the exact live input frames + exact live RC
   decisions to emit the same bytes.

**What IDA analysis *does* buy us (closest achievable = "same recipe"):** the enabled AV1 tool set
(screen-content/palette/IntraBC via the SC core), SVC spatial/temporal layout (from zlt), keyframe/
GOP policy (zlt key-picture dispatcher), and the bitrate/QP targets driven by the recovered
bw_level tables. Feed those to libaom/SVT-AV1 and you get a **functional-equivalent** encoder whose
streams a Zoom client decodes and whose rate/structure track Zoom's — but the bytes differ.

> Same logic applies to **Opus encode**: viper's is Opus-**1.3.1**-derived (`opus`×28, `1.3.1`×4,
> `SILK`×3 in `viper.dll`; no `libopus`/`Xiph` attribution). A libopus encoder driven by the recovered
> gates (inband-FEC/loss-perc/bitrate/DRED) is functional-equivalent, not byte-identical.

**Bottom line:** byte-identical *decode* — yes (spec-determined). Byte-identical *encode* — no, not
from static analysis, and the fingerprint shows we can't even pin an OSS encoder to try. Highest
honest target for encode is a same-recipe functional twin.

## 6. Validation plan (how we'd prove it)

1. **Conformance first (offline, no Zoom needed):** run AOM AV1 test vectors through the dav1d
   adapter and Opus test vectors (RFC 8251) through the libopus adapter — establishes our adapters
   are spec-correct.
2. **Real-stream interop (dynamic; needs a running Zoom + your go-ahead):** capture actual Zoom
   media payloads — AV1 OBUs / Opus packets — at the RTP layer (the nydus/viper media path, or a
   pcap of a self-hosted test call). Decode with our path; confirm frames/audio reconstruct and,
   for AV1, that our decode matches a `libaom`-reference decode **bit-for-bit**.
3. **Encoder round-trip:** encode with our functional encoder → decode with dav1d → PSNR/quality
   check; and confirm a Zoom client accepts the stream (dynamic).

> Note: step 2/3 dynamic capture is out of scope for static RE and requires your environment +
> permission. Step 1 is fully offline.

---

## 7. Build / integration plan (when green-lit)

> **Status (Step-1 landed this pass):** the offline half is built + tested —
> `recon/codec/av1_bitstream.hpp` (IVF/OBU/seq-header/frame-type parser, clean-room from the AV1
> spec, matching the zbt parser we verified) and `demo/demo_av1parse.cpp` (`--selftest` passes 9/9:
> parses a hand-crafted 320×240 sequence header + IVF header).
>
> **AV1 pixel decode — CLOSED LOOP (built + run here).** dav1d 1.4.3 built **C-only** (`-Denable_asm=false`
> ⇒ **no nasm needed**); our adapter `recon/codec/av1_dav1d_decoder.hpp` (behind `recon::zbt::IAv1Decoder`)
> decodes real AV1. The proxy here allowlists github.com but blocks pypi/videolan, so all sources came
> from github:
> ```
> git clone --depth1 -b 1.4.0 https://github.com/mesonbuild/meson   # pure-python; run meson.py directly, no pip
> git clone --depth1 -b 1.4.3 https://github.com/videolan/dav1d     # github mirror
> python meson/meson.py setup build_dav1d dav1d -Denable_asm=false -Denable_tools=false \
>        -Denable_tests=false --default-library=static --buildtype=release   # meson auto-activates MSVC (vsenv)
> python meson/meson.py compile -C build_dav1d                      # -> src/libdav1d.a
> cmake -S . -B build -DRECON_WITH_CODECS=ON -DDAV1D_INCLUDE_DIR=<pfx>/include -DDAV1D_LIBRARY=<pfx>/lib/dav1d.lib
> ```
> Test vector: a real AV1 keyframe extracted from an AVIF sample (`avif_to_obu.py` parses the HEIF
> boxes → av1C seq-header OBU + primary-item frame OBUs). `demo_codec red.obu` → our parser reports
> profile 0 / **800×800** / KEY and **libdav1d decodes 1 picture at 800×800 → PASS, exit 0**; the
> parser's resolution matches the reference decoder's (cross-validation).
>
> **Opus decode — CLOSED LOOP (built + run here).** `-DRECON_WITH_OPUS=ON` FetchContent-builds
> **libopus 1.5.2** from source (CMake, no nasm), behind `recon/codec/opus_decoder.hpp`. `demo_opus`
> makes a valid Opus packet (FEC on, driven by the recovered viper gates), **decodes it via the
> reference decoder** (85-byte packet → 960 samples/ch), and exercises the PLC path (960 concealed).
> Result: **PASS, exit 0** — real reference-library decode of a standard Opus bitstream, which is
> exactly what a captured Zoom Opus packet is. This validates the whole codec-integration pattern
> (interface adapter + FetchContent + demo) end-to-end.

- Dependency acquisition: `vcpkg` (`dav1d`, `libopus`, `aom`) or git submodules + CMake
  `FetchContent`. Keep them behind a `RECON_WITH_CODECS` CMake option so the core project still
  builds with zero external deps (as it does today).
- New adapter TUs: `recon/codec/av1_dav1d_decoder.cpp`, `recon/codec/av1_aom_encoder.cpp`,
  `recon/codec/opus_codec.cpp` — each implementing the existing interface.
- New demo: `demo_codec.cpp` — decode a supplied `.obu`/`.opus` file → PNG / PCM.
- Rough effort: decoder adapters + conformance harness ≈ small–medium; functional encoder ≈
  medium; dynamic real-stream validation ≈ separate spike (depends on capture).

---

## 8. Risks & hard boundaries

- **Encoder byte-exactness is unreachable** — state this up front to avoid a false "1:1" claim.
- **Neural weights are a hard wall** — SNAC/AI-121/CAM++/Picknet/RAISR/EDNet cannot be reproduced.
- **Real-stream validation needs runtime capture** — dynamic, permissioned, not static RE.
- **Dependency size/build** — libaom/SVT pull real build weight; gate behind a CMake flag.
- **Film-grain / non-normative post-processing** in AV1 is applied outside core decode; align
  options with the reference to keep decode comparisons bit-exact.

---

## 9. Recommendation (first concrete step, when you want to proceed)

Start with **AV1 decode via dav1d behind `IAv1Decoder`** + the **offline conformance harness**
(AOM test vectors). It is the highest-fidelity, lowest-risk, fully-offline piece and yields a
decoder that provably decodes real Zoom AV1. Add **Opus decode via libopus** next. Treat encoders
and any real-stream/neural work as later, separately-scoped spikes.
