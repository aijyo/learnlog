// =============================================================================
//  magnifier_capturer.hpp -- REAL screen capture with WINDOW EXCLUSION via the
//  Windows Magnification API. This is the technique used to capture the screen
//  while hiding chosen windows (e.g. the sharer's own toolbar/preview) that the
//  analysis attributed to CptHost's "Magnification" backend.
//
//  ORIGINAL code, public API only (magnification.h). Link: Magnification.lib.
//
//  How it works:
//   - MagInitialize + a host top-level window + a WC_MAGNIFIER child control.
//   - MagSetWindowFilterList(mag, MW_FILTERMODE_EXCLUDE, ...) hides windows.
//   - MagSetWindowSource(mag, rect) sets the screen region to capture.
//   - MagSetImageScalingCallback delivers the (filtered) source pixels, which we
//     copy out as BGRA. (The callback path is legacy but functional; documented.)
//
//  NOTE (verified in Zoom CptHost.exe): MagSetImageScalingCallback crashes on some
//  machines, so Zoom implements a SECOND branch that avoids the callback entirely:
//  it creates a PRIVATE Direct3DCreate9Ex/CreateDeviceEx device on the magnifier
//  window (CptHost sub_140062ACC, device stored at ctx+208), drives a frame with
//  SendMessage(hMagHost, 0x500, rect) (sub_1400370D8), and reads the D3D9 surface
//  DIRECTLY via GetRenderTargetData -> CreateOffscreenPlainSurface(D3DPOOL_SYSTEMMEM)
//  -> LockRect -> copy by Pitch -- the SAME readback family as nydus SafeLockRect
//  (sub_1801D0F88) and recon/capture/d3d9_surface_reader.hpp. sub_140037DD8(ctx,
//  useDx9) selects callback vs this DX9-direct-read path. This capturer implements
//  the callback path (SEH-guarded); use d3d9_surface_reader.hpp for the direct read.
// =============================================================================
#pragma once
#include "capture_common.hpp"
#include <magnification.h>
#include <cstring>

namespace recon::capture {

class MagnifierCapturer : public ICaptureBackend {
public:
    void SetSourceRect(RECT r) { source_ = r; }

    bool Start() override {
        if (!MagInitialize()) return false;
        HINSTANCE inst = GetModuleHandleW(nullptr);
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = DefWindowProcW;
        wc.hInstance = inst;
        wc.lpszClassName = L"ReconMagHostWnd";
        RegisterClassExW(&wc);
        host_ = CreateWindowExW(WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW,
                                wc.lpszClassName, L"", WS_POPUP,
                                0, 0, 0, 0, nullptr, nullptr, inst, nullptr);
        if (!host_) { MagUninitialize(); return false; }
        mag_ = CreateWindowW(WC_MAGNIFIERW, L"ReconMag", WS_CHILD | MS_CLIPAROUNDCURSOR,
                             0, 0, 0, 0, host_, nullptr, inst, nullptr);
        if (!mag_) { DestroyWindow(host_); host_ = nullptr; MagUninitialize(); return false; }
        s_active = this;
        SetWindowLongPtrW(host_, GWLP_USERDATA, (LONG_PTR)this);   // route callback to instance (== CptHost sub_140038040)
        MagSetImageScalingCallback(mag_, &MagnifierCapturer::ScalingCallback);
        if (!exclude_.empty())
            MagSetWindowFilterList(mag_, MW_FILTERMODE_EXCLUDE,
                                   (int)exclude_.size(), exclude_.data());
        return true;
    }

    bool SupportsExclude() const override { return true; }
    void SetExcludeWindows(const std::vector<HWND>& list) override {
        exclude_ = list;
        if (mag_)
            MagSetWindowFilterList(mag_, MW_FILTERMODE_EXCLUDE,
                                   (int)exclude_.size(), exclude_.empty() ? nullptr : exclude_.data());
    }

    std::optional<CapturedFrame> Grab() override {
        RECT r = (source_.right > source_.left) ? source_ : VirtualScreenRect();
        int w = r.right - r.left, h = r.bottom - r.top;
        if (w <= 0 || h <= 0) return std::nullopt;
        SetWindowPos(host_, HWND_TOPMOST, r.left, r.top, w, h, SWP_NOACTIVATE);
        SetWindowPos(mag_, nullptr, 0, 0, w, h, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
        ShowWindow(host_, SW_SHOWNA);
        got_ = false;
        bool ok = DriveCapture(r);           // SEH-guarded (legacy callback can fault)
        ShowWindow(host_, SW_HIDE);
        if (!ok || !got_ || !frame_.ok()) return std::nullopt;
        return frame_;
    }

    void Stop() override {
        if (mag_)  { DestroyWindow(mag_);  mag_ = nullptr; }
        if (host_) { DestroyWindow(host_); host_ = nullptr; }
        if (s_active == this) s_active = nullptr;
        MagUninitialize();
    }
    Backend kind() const override { return Backend::Magnifier; }
    ~MagnifierCapturer() override { Stop(); }

private:
    // Sets source + pumps the render loop until the callback delivers a frame.
    // SEH-guarded: the legacy Magnification callback can fault on some builds;
    // on a fault we bail (nullopt) and the CaptureHost falls back to DXGI/GDI.
    // (No C++ objects with destructors live in this scope -> __try is legal.)
    bool DriveCapture(RECT r) {
        __try {
            if (!MagSetWindowSource(mag_, r)) return false;
            for (int i = 0; i < 60 && !got_; ++i) {
                InvalidateRect(mag_, nullptr, TRUE);
                UpdateWindow(mag_);
                MSG m;
                while (PeekMessageW(&m, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
                Sleep(5);
            }
            return true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    // Legacy image-scaling callback: receives the (filtered) source bitmap.
    static BOOL CALLBACK ScalingCallback(HWND hwnd, void* srcdata, MAGIMAGEHEADER srch,
                                         void*, MAGIMAGEHEADER, RECT, RECT, HRGN) {
        // recover the instance from the host window's GWLP_USERDATA (== CptHost sub_140038040)
        HWND root = GetAncestor(hwnd, GA_ROOT);
        MagnifierCapturer* self = root ? (MagnifierCapturer*)GetWindowLongPtrW(root, GWLP_USERDATA) : nullptr;
        if (!self) self = s_active;
        if (!self || !srcdata) return FALSE;
        const int w = (int)srch.width, h = (int)srch.height;
        const size_t stride = (size_t)srch.stride;         // bytes per source row (32bpp)
        if (w <= 0 || h <= 0 || stride < (size_t)w * 4) return FALSE;
        self->frame_.width = w; self->frame_.height = h; self->frame_.pitch = w * 4;
        self->frame_.pixels.assign((size_t)w * h * 4, 0);  // C++ alloc OUTSIDE the __try
        self->CopyRows(srcdata, w, h, stride);
        return self->got_ ? TRUE : FALSE;
    }

    // SEH-guarded row copy: the callback's srcdata extent is not contractually
    // guaranteed, so a bad stride/clip could over-read -> catch and mark failed.
    void CopyRows(const void* srcdata, int w, int h, size_t stride) {
        __try {
            for (int y = 0; y < h; ++y)
                std::memcpy(frame_.pixels.data() + (size_t)y * w * 4,
                            (const uint8_t*)srcdata + (size_t)y * stride, (size_t)w * 4);
            got_ = true;
        } __except (EXCEPTION_EXECUTE_HANDLER) {
            got_ = false;
        }
    }

    HWND host_ = nullptr, mag_ = nullptr;
    RECT source_{ 0, 0, 0, 0 };
    std::vector<HWND> exclude_;
    CapturedFrame frame_;
    volatile bool got_ = false;
    static MagnifierCapturer* s_active;   // Magnification is single-threaded per process
};

inline MagnifierCapturer* MagnifierCapturer::s_active = nullptr;

} // namespace recon::capture
