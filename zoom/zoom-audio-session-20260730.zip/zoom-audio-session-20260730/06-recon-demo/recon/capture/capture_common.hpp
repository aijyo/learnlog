// =============================================================================
//  capture_common.hpp -- common types + backend interface for the capture
//  subsystem. ORIGINAL code (public Win32 APIs). Each backend is its own class.
// =============================================================================
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <cstdint>
#include <vector>
#include <optional>

namespace recon::capture {

// Captured pixels are 32bpp BGRA, top-down.
struct CapturedFrame {
    int width = 0, height = 0, pitch = 0;
    std::vector<uint8_t> pixels;
    bool ok() const { return width > 0 && height > 0 && !pixels.empty(); }
};

enum class Backend { Auto, Wgc, DxgiDuplication, Magnifier, Gdi, PrintWindow };

inline const char* ToString(Backend b) {
    switch (b) {
        case Backend::Auto: return "Auto";
        case Backend::Wgc: return "WGC";
        case Backend::DxgiDuplication: return "DXGI-Duplication";
        case Backend::Magnifier: return "Magnifier";
        case Backend::Gdi: return "GDI";
        case Backend::PrintWindow: return "PrintWindow";
    }
    return "?";
}

// Common interface implemented by every backend class.
struct ICaptureBackend {
    virtual ~ICaptureBackend() = default;
    virtual bool Start() = 0;
    virtual std::optional<CapturedFrame> Grab() = 0;
    virtual void Stop() = 0;
    virtual Backend kind() const = 0;
    // Only Magnifier (and WGC per-window) can hide windows from the capture.
    virtual bool SupportsExclude() const { return false; }
    virtual void SetExcludeWindows(const std::vector<HWND>&) {}
};

// Whole virtual-desktop rectangle helper.
inline RECT VirtualScreenRect() {
    return RECT{ GetSystemMetrics(SM_XVIRTUALSCREEN), GetSystemMetrics(SM_YVIRTUALSCREEN),
                 GetSystemMetrics(SM_XVIRTUALSCREEN) + GetSystemMetrics(SM_CXVIRTUALSCREEN),
                 GetSystemMetrics(SM_YVIRTUALSCREEN) + GetSystemMetrics(SM_CYVIRTUALSCREEN) };
}

} // namespace recon::capture
