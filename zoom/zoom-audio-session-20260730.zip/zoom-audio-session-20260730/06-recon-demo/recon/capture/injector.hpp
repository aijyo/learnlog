// =============================================================================
//  injector.hpp -- cross-process injection of the capture DLL, mirroring
//  CptShare.dll (which imports SetWindowsHookExW / CallNextHookEx / LoadLibraryEx).
//
//  A global WH_GETMESSAGE hook whose hook proc lives in the to-be-injected DLL
//  makes Windows map that DLL into the target GUI thread's process; the DLL's
//  DllMain (or first hook call) then installs the PresentHook. ORIGINAL code of
//  the standard technique. CreateRemoteThread+LoadLibrary is the usual alternative.
// =============================================================================
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>

namespace recon::capture {

class HookInjector {
public:
    // hookModule: HMODULE of the DLL exporting `getMsgProc`. tid: target GUI thread id.
    bool Inject(HMODULE hookModule, HOOKPROC getMsgProc, DWORD targetThreadId) {
        h_ = SetWindowsHookExW(WH_GETMESSAGE, getMsgProc, hookModule, targetThreadId);
        if (h_) PostThreadMessageW(targetThreadId, WM_NULL, 0, 0);  // nudge so the DLL maps in
        return h_ != nullptr;
    }
    void Remove() { if (h_) { UnhookWindowsHookEx(h_); h_ = nullptr; } }
    ~HookInjector() { Remove(); }
private:
    HHOOK h_ = nullptr;
};

// Alternative: classic LoadLibrary-via-remote-thread injection.
inline bool InjectViaRemoteThread(DWORD pid, const wchar_t* dllPath) {
    HANDLE proc = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION |
                              PROCESS_VM_WRITE | PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
                              FALSE, pid);
    if (!proc) return false;
    SIZE_T n = (wcslen(dllPath) + 1) * sizeof(wchar_t);
    void* remote = VirtualAllocEx(proc, nullptr, n, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    bool ok = false;
    if (remote && WriteProcessMemory(proc, remote, dllPath, n, nullptr)) {
        auto loadLib = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleW(L"kernel32"), "LoadLibraryW");
        HANDLE th = CreateRemoteThread(proc, nullptr, 0, loadLib, remote, 0, nullptr);
        if (th) { WaitForSingleObject(th, 5000); CloseHandle(th); ok = true; }
    }
    if (remote) VirtualFreeEx(proc, remote, 0, MEM_RELEASE);
    CloseHandle(proc);
    return ok;
}

// Example hook proc (would live in the injected DLL); the first invocation inside
// the target finds the app's swapchain and calls PresentHook::Instance().Install(sc).
inline LRESULT CALLBACK ExampleGetMsgProc(int code, WPARAM w, LPARAM l) {
    return CallNextHookEx(nullptr, code, w, l);
}

} // namespace recon::capture
