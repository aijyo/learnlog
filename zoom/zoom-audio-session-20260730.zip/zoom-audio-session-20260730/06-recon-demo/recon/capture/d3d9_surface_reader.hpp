// =============================================================================
//  d3d9_surface_reader.hpp -- D3D9 surface pixel readback via LockRect.
//
//  This is the readback mechanism confirmed in nydus.dll: the capture frame is
//  produced by locking a D3D9 surface (Nydus::SafeLockRect), copying pBits/Pitch
//  into the frame, then unlocking (Nydus::SafeUnlockRect); the device comes from
//  Direct3DCreate9Ex. Used by the Magnification / D3D9 capture path (the magnifier
//  composites the desktop minus excluded windows into a surface, which is then
//  LockRect-read here). ORIGINAL code of the standard D3D9 readback technique.
//  Link: d3d9.lib
// =============================================================================
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <d3d9.h>
#include <wrl/client.h>
#include <cstdint>
#include <vector>
#include <optional>

namespace recon::capture {

class D3d9SurfaceReader {
    template <class T> using C = Microsoft::WRL::ComPtr<T>;
public:
    bool Init() {
        if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, d3d_.GetAddressOf()))) return false;
        D3DPRESENT_PARAMETERS pp{};
        pp.BackBufferWidth = 1; pp.BackBufferHeight = 1;
        pp.BackBufferFormat = D3DFMT_A8R8G8B8; pp.BackBufferCount = 1;
        pp.SwapEffect = D3DSWAPEFFECT_DISCARD; pp.Windowed = TRUE;
        pp.hDeviceWindow = GetDesktopWindow();
        pp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
        return SUCCEEDED(d3d_->CreateDeviceEx(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, pp.hDeviceWindow,
                         D3DCREATE_HARDWARE_VERTEXPROCESSING | D3DCREATE_MULTITHREADED,
                         &pp, nullptr, dev_.GetAddressOf()));
    }
    IDirect3DDevice9Ex* device() const { return dev_.Get(); }

    // GPU render-target -> system-memory surface -> LockRect readback (BGRA).
    std::optional<std::vector<uint8_t>> ReadRenderTarget(IDirect3DSurface9* rt, int& w, int& h, int& pitch) {
        D3DSURFACE_DESC d{};
        if (!rt || FAILED(rt->GetDesc(&d))) return std::nullopt;
        C<IDirect3DSurface9> sys;
        if (FAILED(dev_->CreateOffscreenPlainSurface(d.Width, d.Height, D3DFMT_A8R8G8B8,
                                                     D3DPOOL_SYSTEMMEM, sys.GetAddressOf(), nullptr)))
            return std::nullopt;
        if (FAILED(dev_->GetRenderTargetData(rt, sys.Get()))) return std::nullopt;
        return LockCopy(sys.Get(), w, h, pitch);
    }

    // Whole primary front buffer (desktop) -> LockRect readback. GetFrontBufferData
    // is the classic D3D9 desktop grab; combined with the magnifier's window filter
    // it yields the excluded-windows-removed frame.
    std::optional<std::vector<uint8_t>> ReadFrontBuffer(int& w, int& h, int& pitch) {
        int cx = GetSystemMetrics(SM_CXSCREEN), cy = GetSystemMetrics(SM_CYSCREEN);
        C<IDirect3DSurface9> sys;
        if (FAILED(dev_->CreateOffscreenPlainSurface(cx, cy, D3DFMT_A8R8G8B8,
                                                     D3DPOOL_SYSTEMMEM, sys.GetAddressOf(), nullptr)))
            return std::nullopt;
        if (FAILED(dev_->GetFrontBufferData(0, sys.Get()))) return std::nullopt;
        return LockCopy(sys.Get(), w, h, pitch);
    }

private:
    // The confirmed readback: LockRect -> copy pBits by Pitch -> UnlockRect.
    std::optional<std::vector<uint8_t>> LockCopy(IDirect3DSurface9* s, int& w, int& h, int& pitch) {
        D3DSURFACE_DESC d{}; s->GetDesc(&d);
        D3DLOCKED_RECT lr{};
        if (FAILED(s->LockRect(&lr, nullptr, D3DLOCK_READONLY))) return std::nullopt;  // Nydus::SafeLockRect
        w = (int)d.Width; h = (int)d.Height; pitch = (int)d.Width * 4;
        std::vector<uint8_t> px((size_t)pitch * h);                                     // A8R8G8B8 == BGRA in memory
        for (int y = 0; y < h; ++y)
            memcpy(px.data() + (size_t)y * pitch, (uint8_t*)lr.pBits + (size_t)y * lr.Pitch, pitch);
        s->UnlockRect();                                                                // Nydus::SafeUnlockRect
        return px;
    }

    Microsoft::WRL::ComPtr<IDirect3D9Ex>       d3d_;
    Microsoft::WRL::ComPtr<IDirect3DDevice9Ex> dev_;
};

} // namespace recon::capture
