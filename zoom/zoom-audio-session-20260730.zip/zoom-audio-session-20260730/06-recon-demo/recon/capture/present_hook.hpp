// =============================================================================
//  present_hook.hpp -- vtable hook of IDXGISwapChain::Present, the in-target
//  capture point. Mirrors nydus.dll's "Nydus::SafePresent" wrapper: on each
//  Present it mirrors the back-buffer into a shared surface, then chains to the
//  original Present. ORIGINAL code implementing the standard swapchain-hook
//  technique (public D3D11/DXGI) -- not Zoom's source.
// =============================================================================
#pragma once
#include "shared_surface.hpp"

namespace recon::capture {

class PresentHook {
public:
    using PresentFn = HRESULT (STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);

    static PresentHook& Instance() { static PresentHook inst; return inst; }

    // Patch the swapchain's vtable slot for Present (index 8) to our thunk.
    bool Install(IDXGISwapChain* sc) {
        if (installed_ || !sc) return installed_;
        void** vtbl = *reinterpret_cast<void***>(sc);
        slot_ = &vtbl[8];                                  // IDXGISwapChain::Present == vtbl[8]
        original_ = reinterpret_cast<PresentFn>(*slot_);
        DWORD old = 0;
        if (!VirtualProtect(slot_, sizeof(void*), PAGE_EXECUTE_READWRITE, &old)) return false;
        *slot_ = reinterpret_cast<void*>(&PresentHook::Thunk);
        VirtualProtect(slot_, sizeof(void*), old, &old);
        installed_ = true;
        return true;
    }

    void Uninstall() {
        if (!installed_) return;
        DWORD old = 0;
        VirtualProtect(slot_, sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
        *slot_ = reinterpret_cast<void*>(original_);
        VirtualProtect(slot_, sizeof(void*), old, &old);
        installed_ = false;
    }

    HANDLE shared_handle() { return writer_.handle(); }
    bool   published() const { return published_; }

private:
    static HRESULT STDMETHODCALLTYPE Thunk(IDXGISwapChain* sc, UINT sync, UINT flags) {
        PresentHook& self = Instance();
        ComPtr<ID3D11Texture2D> bb;
        if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)bb.GetAddressOf())) && bb) {
            ComPtr<ID3D11Device> dev; bb->GetDevice(dev.GetAddressOf());
            ComPtr<ID3D11DeviceContext> ctx; if (dev) dev->GetImmediateContext(ctx.GetAddressOf());
            if (dev && ctx && self.writer_.EnsureFor(dev.Get(), bb.Get())) {
                self.writer_.Publish(ctx.Get(), bb.Get());
                self.published_ = true;
            }
        }
        return self.original_(sc, sync, flags);            // chain to the real Present
    }

    void**    slot_ = nullptr;
    PresentFn original_ = nullptr;
    bool      installed_ = false, published_ = false;
    SharedSurfaceWriter writer_;
};

} // namespace recon::capture
