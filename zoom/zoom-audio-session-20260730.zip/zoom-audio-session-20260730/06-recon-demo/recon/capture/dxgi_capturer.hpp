// =============================================================================
//  dxgi_capturer.hpp -- REAL full-monitor GPU capture via DXGI Desktop
//  Duplication (IDXGIOutputDuplication). ORIGINAL code, public D3D11/DXGI APIs.
//  Link: d3d11.lib dxgi.lib
// =============================================================================
#pragma once
#include "capture_common.hpp"
#include <d3d11.h>
#include <dxgi1_2.h>
#include <wrl/client.h>

namespace recon::capture {

class DxgiDuplicationCapturer : public ICaptureBackend {
    template <class T> using ComPtr = Microsoft::WRL::ComPtr<T>;
public:
    explicit DxgiDuplicationCapturer(int outputIndex = 0) : output_(outputIndex) {}

    bool Start() override {
        D3D_FEATURE_LEVEL fl;
        if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
                                     nullptr, 0, D3D11_SDK_VERSION,
                                     dev_.GetAddressOf(), &fl, ctx_.GetAddressOf())))
            return false;
        ComPtr<IDXGIDevice> dxgi;
        if (FAILED(dev_.As(&dxgi))) return false;
        ComPtr<IDXGIAdapter> adapter;
        if (FAILED(dxgi->GetAdapter(adapter.GetAddressOf()))) return false;
        ComPtr<IDXGIOutput> out;
        if (FAILED(adapter->EnumOutputs(output_, out.GetAddressOf()))) return false;
        if (FAILED(out.As(&output1_))) return false;
        if (FAILED(output1_->DuplicateOutput(dev_.Get(), dupl_.GetAddressOf()))) return false;
        return true;
    }

    std::optional<CapturedFrame> Grab() override {
        if (!dupl_) return std::nullopt;
        DXGI_OUTDUPL_FRAME_INFO info{};
        ComPtr<IDXGIResource> res;
        HRESULT hr = dupl_->AcquireNextFrame(200, &info, res.GetAddressOf());
        if (hr == DXGI_ERROR_WAIT_TIMEOUT) { return std::nullopt; }
        if (FAILED(hr)) return std::nullopt;

        ComPtr<ID3D11Texture2D> tex;
        std::optional<CapturedFrame> out;
        if (SUCCEEDED(res.As(&tex))) {
            D3D11_TEXTURE2D_DESC d{}; tex->GetDesc(&d);
            D3D11_TEXTURE2D_DESC sd = d;
            sd.Usage = D3D11_USAGE_STAGING; sd.BindFlags = 0;
            sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ; sd.MiscFlags = 0;
            ComPtr<ID3D11Texture2D> staging;
            if (SUCCEEDED(dev_->CreateTexture2D(&sd, nullptr, staging.GetAddressOf()))) {
                ctx_->CopyResource(staging.Get(), tex.Get());
                D3D11_MAPPED_SUBRESOURCE m{};
                if (SUCCEEDED(ctx_->Map(staging.Get(), 0, D3D11_MAP_READ, 0, &m))) {
                    CapturedFrame f; f.width = d.Width; f.height = d.Height; f.pitch = d.Width * 4;
                    f.pixels.resize((size_t)f.pitch * f.height);
                    for (int y = 0; y < f.height; ++y)
                        memcpy(f.pixels.data() + (size_t)y * f.pitch,
                               (uint8_t*)m.pData + (size_t)y * m.RowPitch, f.pitch);
                    ctx_->Unmap(staging.Get(), 0);
                    out = std::move(f);   // format is typically DXGI_FORMAT_B8G8R8A8_UNORM (BGRA)
                }
            }
        }
        dupl_->ReleaseFrame();
        return out;
    }

    void Stop() override { dupl_.Reset(); output1_.Reset(); ctx_.Reset(); dev_.Reset(); }
    Backend kind() const override { return Backend::DxgiDuplication; }
    ~DxgiDuplicationCapturer() override { Stop(); }

private:
    int output_ = 0;
    ComPtr<ID3D11Device>          dev_;
    ComPtr<ID3D11DeviceContext>   ctx_;
    ComPtr<IDXGIOutput1>          output1_;
    ComPtr<IDXGIOutputDuplication> dupl_;
};

} // namespace recon::capture
