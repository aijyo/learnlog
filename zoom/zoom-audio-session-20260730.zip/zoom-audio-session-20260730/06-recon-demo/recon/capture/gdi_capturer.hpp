// =============================================================================
//  gdi_capturer.hpp -- REAL GDI screen-region capture (BitBlt + CAPTUREBLT).
//  ORIGINAL code, public Win32 GDI APIs. The universal fallback backend.
//  Link: gdi32.lib user32.lib
// =============================================================================
#pragma once
#include "capture_common.hpp"

namespace recon::capture {

class GdiCapturer : public ICaptureBackend {
public:
    void SetRect(RECT r) { rect_ = r; }

    bool Start() override { return true; }

    std::optional<CapturedFrame> Grab() override {
        RECT r = (rect_.right > rect_.left) ? rect_ : VirtualScreenRect();
        int w = r.right - r.left, h = r.bottom - r.top;
        if (w <= 0 || h <= 0) return std::nullopt;

        HDC screen = GetDC(nullptr);
        HDC mem = CreateCompatibleDC(screen);

        BITMAPINFO bi{};
        bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h;   // top-down
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;
        void* bits = nullptr;
        HBITMAP dib = CreateDIBSection(screen, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        HGDIOBJ old = SelectObject(mem, dib);

        // CAPTUREBLT includes layered windows; SRCCOPY for the rest.
        BOOL ok = BitBlt(mem, 0, 0, w, h, screen, r.left, r.top, SRCCOPY | CAPTUREBLT);

        std::optional<CapturedFrame> out;
        if (ok && bits) {
            CapturedFrame f; f.width = w; f.height = h; f.pitch = w * 4;
            f.pixels.assign((uint8_t*)bits, (uint8_t*)bits + (size_t)f.pitch * h);
            out = std::move(f);
        }
        SelectObject(mem, old); DeleteObject(dib); DeleteDC(mem); ReleaseDC(nullptr, screen);
        return out;
    }

    void Stop() override {}
    Backend kind() const override { return Backend::Gdi; }

private:
    RECT rect_{ 0, 0, 0, 0 };
};

} // namespace recon::capture
