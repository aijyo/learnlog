// =============================================================================
//  shared_surface.hpp -- keyed-mutex shared D3D11 texture used to move a captured
//  frame from the target process to the Zoom host process, zero-copy on the GPU.
//
//  This is the mechanism reverse-engineered from nydus.dll: CD3d11SharedHandleHelper
//  + CVideoSharePresent. ORIGINAL code implementing the standard shared-texture /
//  IDXGIKeyedMutex technique (public D3D11/DXGI APIs) -- not Zoom's source.
//
//  Producer (SharedSurfaceWriter) runs in the hooked target; Consumer
//  (SharedSurfaceReader) runs in the Zoom host and OpenSharedResource()'s the handle.
// =============================================================================
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <cstdint>
#include <vector>
#include <optional>

namespace recon::capture {

template <class T> using ComPtr = Microsoft::WRL::ComPtr<T>;

// Producer side: allocate a shared texture matching `src` and blit into it.
// Keying: producer Acquire(0)/Release(1); consumer Acquire(1)/Release(0).
class SharedSurfaceWriter {
public:
    bool EnsureFor(ID3D11Device* dev, ID3D11Texture2D* src) {
        D3D11_TEXTURE2D_DESC d{}; src->GetDesc(&d);
        if (shared_ && d.Width == w_ && d.Height == h_ && d.Format == fmt_) return true;
        shared_.Reset(); km_.Reset();
        w_ = d.Width; h_ = d.Height; fmt_ = d.Format;

        D3D11_TEXTURE2D_DESC sd{};
        sd.Width = d.Width; sd.Height = d.Height; sd.MipLevels = 1; sd.ArraySize = 1;
        sd.Format = d.Format; sd.SampleDesc.Count = 1; sd.Usage = D3D11_USAGE_DEFAULT;
        sd.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
        sd.MiscFlags = D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
        if (FAILED(dev->CreateTexture2D(&sd, nullptr, shared_.ReleaseAndGetAddressOf()))) return false;

        ComPtr<IDXGIResource> res;
        if (FAILED(shared_.As(&res)) || FAILED(res->GetSharedHandle(&handle_))) return false;
        return SUCCEEDED(shared_.As(&km_));
    }

    // Called from the hooked Present: copy the back-buffer into the shared texture.
    void Publish(ID3D11DeviceContext* ctx, ID3D11Texture2D* src) {
        if (!shared_ || !km_) return;
        if (SUCCEEDED(km_->AcquireSync(0, 1000))) {
            ctx->CopyResource(shared_.Get(), src);
            km_->ReleaseSync(1);
        }
    }

    HANDLE      handle() const { return handle_; }
    UINT        width()  const { return w_; }
    UINT        height() const { return h_; }
    DXGI_FORMAT format() const { return fmt_; }

private:
    ComPtr<ID3D11Texture2D> shared_;
    ComPtr<IDXGIKeyedMutex> km_;
    HANDLE      handle_ = nullptr;
    UINT        w_ = 0, h_ = 0;
    DXGI_FORMAT fmt_ = DXGI_FORMAT_UNKNOWN;
};

// Consumer side (Zoom host): open the shared handle on its OWN device, read BGRA.
class SharedSurfaceReader {
public:
    bool Open(ID3D11Device* dev, ID3D11DeviceContext* ctx, HANDLE h) {
        dev_ = dev; ctx_ = ctx;
        if (!h || FAILED(dev->OpenSharedResource(h, __uuidof(ID3D11Texture2D),
                                                 (void**)shared_.ReleaseAndGetAddressOf())))
            return false;
        return SUCCEEDED(shared_.As(&km_));
    }

    std::optional<std::vector<uint8_t>> Read(int& w, int& h, int& pitch) {
        if (!shared_ || !km_) return std::nullopt;
        D3D11_TEXTURE2D_DESC d{}; shared_->GetDesc(&d);
        D3D11_TEXTURE2D_DESC sd = d;
        sd.Usage = D3D11_USAGE_STAGING; sd.BindFlags = 0;
        sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ; sd.MiscFlags = 0;
        ComPtr<ID3D11Texture2D> staging;
        if (FAILED(dev_->CreateTexture2D(&sd, nullptr, staging.GetAddressOf()))) return std::nullopt;

        if (FAILED(km_->AcquireSync(1, 1000))) return std::nullopt;
        ctx_->CopyResource(staging.Get(), shared_.Get());
        km_->ReleaseSync(0);

        D3D11_MAPPED_SUBRESOURCE m{};
        if (FAILED(ctx_->Map(staging.Get(), 0, D3D11_MAP_READ, 0, &m))) return std::nullopt;
        w = d.Width; h = d.Height; pitch = d.Width * 4;
        std::vector<uint8_t> px((size_t)pitch * h);
        for (int y = 0; y < h; ++y)
            memcpy(px.data() + (size_t)y * pitch, (uint8_t*)m.pData + (size_t)y * m.RowPitch, pitch);
        ctx_->Unmap(staging.Get(), 0);
        return px;
    }

private:
    ID3D11Device* dev_ = nullptr;
    ID3D11DeviceContext* ctx_ = nullptr;
    ComPtr<ID3D11Texture2D> shared_;
    ComPtr<IDXGIKeyedMutex> km_;
};

} // namespace recon::capture
