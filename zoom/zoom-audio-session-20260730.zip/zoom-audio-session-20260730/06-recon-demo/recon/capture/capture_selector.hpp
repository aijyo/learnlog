// =============================================================================
//  capture_selector.hpp -- CaptureHost: picks a backend and drives one capture,
//  with an exclude-window list (which forces the Magnifier backend) and a
//  fallback chain. ORIGINAL code. Mirrors CptHost's backend-selection intent.
// =============================================================================
#pragma once
#include "capture_common.hpp"
#include "magnifier_capturer.hpp"
#include "dxgi_capturer.hpp"
#include "gdi_capturer.hpp"
#include <memory>

namespace recon::capture {

class CaptureHost {
public:
    void ExcludeWindow(HWND h) { if (h) exclude_.push_back(h); }
    Backend last_backend() const { return last_; }

    // Capture the given screen rect once. If windows are excluded, the Magnifier
    // backend is used (only it can hide windows); otherwise DXGI, then GDI.
    std::optional<CapturedFrame> CaptureOnce(RECT rect, Backend want = Backend::Auto) {
        if (want == Backend::Auto)
            want = !exclude_.empty() ? Backend::Magnifier : Backend::DxgiDuplication;

        if (auto f = Try(want, rect)) return f;
        if (want == Backend::Magnifier) {        // exclusion unavailable -> best effort
            if (auto f = Try(Backend::DxgiDuplication, rect)) return f;
        }
        return Try(Backend::Gdi, rect);          // universal fallback
    }

private:
    std::unique_ptr<ICaptureBackend> Make(Backend b, RECT rect) {
        switch (b) {
            case Backend::Magnifier: {
                auto c = std::make_unique<MagnifierCapturer>();
                c->SetSourceRect(rect); c->SetExcludeWindows(exclude_);
                return c;
            }
            case Backend::DxgiDuplication:
                return std::make_unique<DxgiDuplicationCapturer>();
            case Backend::Gdi:
            default: {
                auto c = std::make_unique<GdiCapturer>();
                c->SetRect(rect);
                return c;
            }
        }
    }

    std::optional<CapturedFrame> Try(Backend b, RECT rect) {
        auto cap = Make(b, rect);
        if (b == Backend::Magnifier && !exclude_.empty()) cap->SetExcludeWindows(exclude_);
        if (!cap->Start()) return std::nullopt;
        auto f = cap->Grab();
        cap->Stop();
        if (f && f->ok()) { last_ = b; return f; }
        return std::nullopt;
    }

    std::vector<HWND> exclude_;
    Backend last_ = Backend::Auto;
};

} // namespace recon::capture
