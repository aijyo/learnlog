// =============================================================================
//  nydus_as_engine.hpp -- CLEAN-ROOM reconstruction of the application-share (AS)
//  media engine reverse-engineered from Zoom's nydus.dll.  ORIGINAL C++17
//  modeling the *architecture* recovered from the C++ RTTI/class inventory
//  (capturer types, GPU render/convert/super-res pipeline, FEC packet groups).
//  No verbatim proprietary source.
//
//  Reconstructed from (nydus.dll) exports + RTTI:
//    exports: GetMethod, GetAPISet, ConfigrateTrace/Monitor/GlobalDescription
//    capturers: CASCapturer, CDSVideoCapturer/CDSAudioCapturer, CMFVideoCapturer,
//               CNDICapturer, IASCapturer_MirrorServer, IVideoCapturerH264,
//               IASCapturer_ExternalSource, CDummyVideoCapturer
//    render:    CWallRenderer / CSpotRenderer / CMemoryWallRenderer, SetPresentMode,
//               SetASCursor, CASCursorDecoder
//    D3D11:     CDrawPic_D3d11_{NV12,YUV420Planar,YUV422Packed,YUV444Planar,RGB},
//               MaskBlend/AlphaMask (virtual-bg), *_WithUpsample/WithChromaUpsample,
//               CDrawFunc_D3d11_Raisr (super-res), CVideoTemporalDenoise (EDNet),
//               CD3d11SharedHandleHelper (zero-copy)
//    FEC:       IFecBufferManage, PacketFecProcessBase, ClientFecRtpPacketGroup
//
//  *** RE-VERIFIED against decompiled BODIES (nydus FEC + SafeLockRect readback): ***
//   - D3D9 surface READBACK is CONFIRMED from bodies: sub_1801D0F88 does
//       SafeLockRect (sub_1801CF340, vtbl+152 = IDirect3DSurface9::LockRect, SEH-guarded)
//       -> row-copy by Pitch (sub_1800B0F30) -> SafeUnlockRect (sub_1801CF3D8, vtbl+160)
//       -> push to sink (sub_1801CF53C).  Four sibling callers (sub_18017B1CC/2B0/370,
//       sub_18017C420) memcpy `rows x bytes` by the locked Pitch.  Adapters are
//       enumerated via Nydus::SafeDirect3DCreate9 (sub_1800A4B9C).  Source files:
//       draw_d3d9.cpp / vasimulator.cpp / systeminfo.cpp.  This matches the RUNNABLE
//       recon/capture/d3d9_surface_reader.hpp (verified 256x144).
//   - FEC is now VERIFIED from member bodies (reached via an RTTI->vftable walk +
//       decompiling the FEC code cluster 0x180001000..0x180006000):
//       Zoom's share FEC is SYSTEMATIC REED-SOLOMON over GF(2^8), NOT plain XOR.
//         * sub_180005C44 builds the GF(256) exp/log tables; the primitive polynomial
//           is read from an 8-char ASCII bitstring "10111000" @0x1801F4F28 -> 0x11D
//           (x^8+x^4+x^3+x^2+1, the standard RS poly; NOT AES 0x11B).  Inverse table
//           at word_1802C2CF0; 256x256 multiply table in `Block`.
//         * sub_180005F34 is the RS encode/erasure-solve: GF polynomial arithmetic
//           over `Block` (v31[i+1] ^= Block[256*c + v31[i+2]]), recovered symbols
//           written back strided by the group width (systematic layout).
//         * sub_180005D3C inserts a packet into a CriticalSection-guarded group map
//           keyed by size/seq; sub_180005DFC tears the groups down.
//       Class hierarchy (RTTI): FecRtpPacketGroupBase <- Nydus::ClientFecRtpPacketGroup;
//       IFecBufferManage (4 pure virtuals + dtor); PacketFecProcessBase <-
//       Nydus::ClientRtpPacketProcess (holds Nydus::ClientDataRtpPacketList /
//       DataRtpPacketListBase media+fec RTP lists, ctor sub_180002614).
//       A RUNNABLE clean-room RS(GF256, 0x11D) matching this lives in
//       recon/algo/rs_fec.hpp; recon/algo/fec_group.hpp (XorFec) remains the simpler
//       single-parity variant.
// =============================================================================
#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <memory>

namespace recon::nydus {

// --- Capture sources ---------------------------------------------------------
enum class CapturerType {
    AppShare,        // CASCapturer (screen/window/app)
    DShowVideo, DShowAudio,
    MediaFoundation, // CMFVideoCapturer (camera)
    Ndi,             // CNDICapturer
    MirrorServer,    // IASCapturer_MirrorServer (mirror driver)
    H264Direct,      // IVideoCapturerH264 (HW camera direct-to-H264)
    ExternalSource,  // IASCapturer_ExternalSource (injected frames)
    Dummy
};
enum class PresentMode { Fit, Fill, Original };   // ASPresentMode

struct Frame { const uint8_t* data=nullptr; int w=0,h=0,pitch=0; int fourcc=0; };

struct ICapturer {
    virtual ~ICapturer() = default;
    virtual bool Start() = 0;
    virtual void Stop() = 0;
    virtual bool GetFrame(Frame& out) = 0;
    virtual CapturerType type() const = 0;
};

// --- GPU render / color-convert / enhancement pipeline (D3D11) ----------------
enum class PixelPath { NV12, YUV420Planar, YUV422Packed, YUV444Planar, RGB };
struct RenderOptions {
    PixelPath path        = PixelPath::NV12;
    bool      mask_blend  = false;   // virtual-background / alpha mask compositing
    bool      upsample    = false;   // spatial upsample
    bool      chroma_upsample = false;
    bool      raisr       = false;   // RAISR super-resolution (recover HD from low bitrate)
    bool      temporal_denoise = false; // EDNet neural temporal denoise
};
struct IAsRenderer {                // Wall / Spot / MemoryWall
    virtual ~IAsRenderer() = default;
    virtual void SetPresentMode(PresentMode) = 0;
    virtual void SetCursor(const Frame& cursor, int x, int y) = 0;   // SetASCursor
    virtual bool Present(const Frame& src, const RenderOptions&) = 0;
};

// --- FEC RTP packet group [VERIFIED: systematic Reed-Solomon over GF(2^8)] ------
//   Nydus::ClientFecRtpPacketGroup (<- FecRtpPacketGroupBase) holds K media + R
//   parity RTP packets; recovery is RS erasure decode over GF(256) poly 0x11D
//   (sub_180005C44 tables + sub_180005F34 solve).  Runnable: recon/algo/rs_fec.hpp.
struct FecPacketGroup {
    uint32_t base_seq = 0;
    std::vector<std::vector<uint8_t>> media;   // K source packets (systematic)
    std::vector<std::vector<uint8_t>> fec;     // R parity packets
    // Recover erased media packets (positions known from RTP seq gaps) as long as
    // received(media)+received(fec) >= K.  Backed by rs_fec.hpp (GF256, 0x11D).
    bool Recover(std::vector<std::vector<uint8_t>>& outMedia) const;
};
// IFecBufferManage: 4 pure virtuals + a scalar-deleting dtor (vtable 0x1801F4EF0).
// The concrete manager owns per-group buffers and drives RS encode/decode; the
// group map is keyed by packet size/seq and guarded by a CriticalSection
// (insert = sub_180005D3C, teardown = sub_180005DFC).
struct IFecBufferManage {
    virtual ~IFecBufferManage() = default;
    virtual void OnMediaPacket(uint32_t seq, const uint8_t* p, size_t n) = 0;
    virtual void OnFecPacket(uint32_t seq, const uint8_t* p, size_t n) = 0;
    virtual bool TryRecover(FecPacketGroup& grp) = 0;
    virtual void Reset() = 0;
};

// --- Engine facade (GetMethod / GetAPISet export surface) --------------------
struct AsEngineApi {
    std::unique_ptr<ICapturer>  (*createCapturer)(CapturerType) = nullptr;
    std::unique_ptr<IAsRenderer>(*createRenderer)(bool spot)    = nullptr; // Wall vs Spot
    std::unique_ptr<IFecBufferManage>(*createFec)()             = nullptr;
};
const AsEngineApi* GetAPISet();                 // GetAPISet
void*              GetMethod(const char* name); // GetMethod (named entry lookup)
void ConfigrateTrace(int level);
void ConfigrateMonitor(bool on);

} // namespace recon::nydus
