// =============================================================================
//  wgc_capturer.hpp  --  CLEAN-ROOM reconstruction of the Windows screen-capture
//  behavior reverse-engineered from Zoom's CptUwpCapture.dll / CptHost.exe.
//
//  This is ORIGINAL code that reproduces the *observed behavior* (backend choice,
//  D3D11 HW->WARP fallback with BGRA, WGC frame-pool pull model, PrintWindow
//  fallback with transparent-border auto-crop, HDC pooling, retry cap). It is
//  built entirely on public Win32 / WinRT / Direct3D11 APIs. It does NOT contain
//  any of Zoom's proprietary source; only the standard techniques + the numeric
//  constants recovered during analysis are reproduced (those are facts).
//
//  Build: C++17, /std:c++17, C++/WinRT.
//  Link : windowsapp.lib d3d11.lib dxgi.lib dwmapi.lib gdi32.lib user32.lib
// =============================================================================
#pragma once
#include <windows.h>
#include <dwmapi.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <winrt/Windows.Graphics.DirectX.h>
#include <winrt/Windows.Graphics.DirectX.Direct3D11.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <cstdint>
#include <vector>
#include <optional>

namespace recon {

// --- limits/constants recovered from CptUwpCapture (sub_180002C60) ------------
inline constexpr int   kMaxDim          = 4132;   // reject windows larger than this
inline constexpr int   kMinCoord        = -15360; // reject off-screen placements
inline constexpr int   kAutoCropMaxEdge = 100;    // scan at most 100px per edge
inline constexpr int   kAutoCropHint    = 18;     // "keep one more px" heuristic
inline constexpr int   kRetryCap        = 20;     // give up after N failed pulls
inline constexpr HRESULT kDxgiUnsupported = HRESULT(0x887A0004); // DXGI_ERROR_UNSUPPORTED

namespace wgc  = winrt::Windows::Graphics::Capture;
namespace wdx  = winrt::Windows::Graphics::DirectX;
namespace wd3d = winrt::Windows::Graphics::DirectX::Direct3D11;

// -----------------------------------------------------------------------------
//  RgbaFrame: CPU-side BGRA32 frame (top-down), plus valid content rectangle.
// -----------------------------------------------------------------------------
struct RgbaFrame {
    int width = 0, height = 0, pitch = 0;
    std::vector<uint8_t> pixels;     // BGRA, size = pitch*height
    RECT contentRect{};              // valid (non-transparent) sub-rect
    bool ok() const { return width > 0 && height > 0 && !pixels.empty(); }
};

// =============================================================================
//  1) Shared D3D11 device — mirrors CptUwpCapture capture_item_factory ctor:
//     HARDWARE + BGRA_SUPPORT, WARP fallback on DXGI_ERROR_UNSUPPORTED, then
//     wrapped as a WinRT IDirect3DDevice for the WGC frame pool.
// =============================================================================
class D3DContext {
public:
    bool Create() {
        UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
        HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags,
                                       nullptr, 0, D3D11_SDK_VERSION,
                                       device_.put(), nullptr, context_.put());
        if (hr == kDxgiUnsupported) {                       // no HW path -> WARP
            device_ = nullptr; context_ = nullptr;
            hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, flags,
                                   nullptr, 0, D3D11_SDK_VERSION,
                                   device_.put(), nullptr, context_.put());
        }
        if (FAILED(hr) || !device_) return false;

        winrt::com_ptr<IDXGIDevice> dxgi;
        if (FAILED(device_->QueryInterface(dxgi.put_void()))) return false;
        winrt::com_ptr<::IInspectable> insp;
        if (FAILED(CreateDirect3D11DeviceFromDXGIDevice(dxgi.get(), insp.put()))) return false;
        rtDevice_ = insp.as<wd3d::IDirect3DDevice>();
        return true;
    }
    ID3D11Device*        d3d()      const { return device_.get(); }
    ID3D11DeviceContext* ctx()      const { return context_.get(); }
    wd3d::IDirect3DDevice rtDevice() const { return rtDevice_; }
private:
    winrt::com_ptr<ID3D11Device>        device_;
    winrt::com_ptr<ID3D11DeviceContext> context_;
    wd3d::IDirect3DDevice               rtDevice_{ nullptr };
};

// =============================================================================
//  2) WGC capturer — mirrors CreateItemForWindow/Monitor + FramePool pull model
//     (HasNextFrame / GetNextFrame) + IsCursorCaptureEnabled toggle.
// =============================================================================
class WgcCapturer {
public:
    explicit WgcCapturer(D3DContext& gpu) : gpu_(gpu) {}

    bool StartForWindow(HWND hwnd)      { return Start(ItemFromHwnd(hwnd)); }
    bool StartForMonitor(HMONITOR mon)  { return Start(ItemFromMonitor(mon)); }

    // Cursor capture toggle (WGC GraphicsCaptureSession.IsCursorCaptureEnabled).
    void SetCursorCaptureEnabled(bool en) {
        if (session_) try { session_.IsCursorCaptureEnabled(en); } catch (...) {}
    }

    bool HasNextFrame() const { return pool_ != nullptr; }

    // Pull the next available frame as a BGRA staging copy (nullopt if none yet).
    std::optional<RgbaFrame> GetNextFrame() {
        if (!pool_) return std::nullopt;
        auto frame = pool_.TryGetNextFrame();
        if (!frame) return std::nullopt;
        return CopyToCpu(frame.Surface());
    }

    void Stop() {
        if (session_) { session_.Close(); session_ = nullptr; }
        if (pool_)    { pool_.Close();    pool_ = nullptr; }
        item_ = nullptr;
    }
    ~WgcCapturer() { Stop(); }

private:
    static wgc::GraphicsCaptureItem ItemFromHwnd(HWND hwnd) {
        auto interop = winrt::get_activation_factory<wgc::GraphicsCaptureItem,
                                                     IGraphicsCaptureItemInterop>();
        wgc::GraphicsCaptureItem item{ nullptr };
        winrt::check_hresult(interop->CreateForWindow(
            hwnd, winrt::guid_of<wgc::GraphicsCaptureItem>(), winrt::put_abi(item)));
        return item;
    }
    static wgc::GraphicsCaptureItem ItemFromMonitor(HMONITOR mon) {
        auto interop = winrt::get_activation_factory<wgc::GraphicsCaptureItem,
                                                     IGraphicsCaptureItemInterop>();
        wgc::GraphicsCaptureItem item{ nullptr };
        winrt::check_hresult(interop->CreateForMonitor(
            mon, winrt::guid_of<wgc::GraphicsCaptureItem>(), winrt::put_abi(item)));
        return item;
    }

    bool Start(wgc::GraphicsCaptureItem item) {
        if (!item) return false;
        item_ = item;
        auto size = item_.Size();
        pool_ = wgc::Direct3D11CaptureFramePool::CreateFreeThreaded(
                    gpu_.rtDevice(), wdx::DirectXPixelFormat::B8G8R8A8UIntNormalized,
                    2 /*buffers*/, size);
        session_ = pool_.CreateCaptureSession(item_);
        session_.StartCapture();
        return true;
    }

    // Copy a captured D3D surface into a CPU staging buffer (BGRA).
    std::optional<RgbaFrame> CopyToCpu(wd3d::IDirect3DSurface surface) {
        auto access = surface.as<Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();
        winrt::com_ptr<ID3D11Texture2D> tex;
        if (FAILED(access->GetInterface(winrt::guid_of<ID3D11Texture2D>(), tex.put_void())))
            return std::nullopt;
        D3D11_TEXTURE2D_DESC d{}; tex->GetDesc(&d);

        D3D11_TEXTURE2D_DESC sd = d;
        sd.Usage = D3D11_USAGE_STAGING; sd.BindFlags = 0;
        sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ; sd.MiscFlags = 0;
        winrt::com_ptr<ID3D11Texture2D> staging;
        if (FAILED(gpu_.d3d()->CreateTexture2D(&sd, nullptr, staging.put())))
            return std::nullopt;
        gpu_.ctx()->CopyResource(staging.get(), tex.get());

        D3D11_MAPPED_SUBRESOURCE m{};
        if (FAILED(gpu_.ctx()->Map(staging.get(), 0, D3D11_MAP_READ, 0, &m)))
            return std::nullopt;
        RgbaFrame f; f.width = d.Width; f.height = d.Height; f.pitch = d.Width * 4;
        f.pixels.resize(size_t(f.pitch) * f.height);
        for (int y = 0; y < f.height; ++y)
            memcpy(f.pixels.data() + size_t(y) * f.pitch,
                   (uint8_t*)m.pData + size_t(y) * m.RowPitch, f.pitch);
        gpu_.ctx()->Unmap(staging.get(), 0);
        f.contentRect = RECT{ 0, 0, f.width, f.height };
        return f;
    }

    D3DContext&                          gpu_;
    wgc::GraphicsCaptureItem             item_{ nullptr };
    wgc::Direct3D11CaptureFramePool      pool_{ nullptr };
    wgc::GraphicsCaptureSession          session_{ nullptr };
};

// =============================================================================
//  3) PrintWindow fallback + transparent-border auto-crop.
//     Mirrors CptUwpCapture sub_180002C60: skip minimized, DWM extended-frame
//     rect, bound checks, top-down 32bpp DIB, PW_RENDERFULLCONTENT, alpha-based
//     edge crop (<=100px, +18px hint), retry cap 20.
// =============================================================================
class PrintWindowCapturer {
public:
    // Returns a cropped BGRA frame, or nullopt if not capturable this attempt.
    static std::optional<RgbaFrame> Capture(HWND hwnd, bool clientOnly = false) {
        WINDOWPLACEMENT wp{ sizeof(wp) };
        if (!GetWindowPlacement(hwnd, &wp)) return std::nullopt;
        if (wp.showCmd == SW_SHOWMINIMIZED) return std::nullopt;
        if (!(GetWindowLongW(hwnd, GWL_STYLE) & WS_VISIBLE)) return std::nullopt;

        RECT rc{};
        // Prefer DWM's true (shadow-excluded) frame bounds; fall back to GetWindowRect.
        if (FAILED(DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, &rc, sizeof(rc))))
            if (!GetWindowRect(hwnd, &rc)) return std::nullopt;

        if (rc.left < kMinCoord || rc.top < kMinCoord) return std::nullopt;
        int w = rc.right - rc.left, h = rc.bottom - rc.top;
        if (w <= 0 || h <= 0 || w > kMaxDim || h > kMaxDim) return std::nullopt;

        BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h; // top-down
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;

        HDC screen = GetDC(nullptr);
        HDC mem = CreateCompatibleDC(screen);
        void* bits = nullptr;
        HBITMAP dib = CreateDIBSection(screen, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        HGDIOBJ old = SelectObject(mem, dib);

        UINT flags = PW_RENDERFULLCONTENT | (clientOnly ? PW_CLIENTONLY : 0u);
        BOOL ok = PrintWindow(hwnd, mem, flags);

        std::optional<RgbaFrame> result;
        if (ok && bits) {
            RgbaFrame f; f.width = w; f.height = h; f.pitch = w * 4;
            f.pixels.assign((uint8_t*)bits, (uint8_t*)bits + size_t(f.pitch) * h);
            f.contentRect = AutoCropTransparentBorders(f);
            result = std::move(f);
        }
        SelectObject(mem, old); DeleteObject(dib); DeleteDC(mem); ReleaseDC(nullptr, screen);
        return result;
    }

private:
    // A pixel counts as "content" if it is not fully transparent black.
    static bool IsContent(uint32_t bgra) { return ((bgra + 0x01000000u) & 0xFEFFFFFFu) != 0; }

    static RECT AutoCropTransparentBorders(const RgbaFrame& f) {
        auto* px = reinterpret_cast<const uint32_t*>(f.pixels.data());
        const int W = f.width, H = f.height, stride = f.pitch / 4;
        auto rowEmpty = [&](int y){ for (int x=0;x<W;++x) if (IsContent(px[y*stride+x])) return false; return true; };
        auto colEmpty = [&](int x){ for (int y=0;y<H;++y) if (IsContent(px[y*stride+x])) return false; return true; };

        int top=0;    while (top    < std::min(H,kAutoCropMaxEdge) && rowEmpty(top))    ++top;
        int bottom=0; while (bottom < std::min(H,kAutoCropMaxEdge) && rowEmpty(H-1-bottom)) ++bottom;
        int left=0;   while (left   < std::min(W,kAutoCropMaxEdge) && colEmpty(left))   ++left;
        int right=0;  while (right  < std::min(W,kAutoCropMaxEdge) && colEmpty(W-1-right))  ++right;
        // Zoom keeps one extra pixel once a border exceeds the ~18px hint.
        auto adjust=[&](int v){ return v>kAutoCropHint ? v-1 : (v>=std::min(H,kAutoCropMaxEdge)?0:v); };
        top=adjust(top); bottom=adjust(bottom); left=adjust(left); right=adjust(right);
        return RECT{ left, top, W-right, H-bottom };
    }
};

// =============================================================================
//  4) High-level selector — mirrors CptHost capture-mode selection order:
//     WGC (Win10 1903+, DWM composited) -> PrintWindow fallback.
//     (DXGI desktop-duplication / GDI BitBlt paths are analogous; add as needed.)
// =============================================================================
enum class CaptureMode { Auto, Wgc, PrintWindow };

inline bool WgcAvailable() {
    try { return wgc::GraphicsCaptureSession::IsSupported(); } catch (...) { return false; }
}

} // namespace recon
