// =============================================================================
//  mcm_media_channel.hpp -- CLEAN-ROOM reconstruction of the weak-network
//  decision logic in Zoom's mcm.dll (Media Channel Manager).
//
//  ORIGINAL C++17. Reproduces the *state, metrics, formulas and constants*
//  recovered by static analysis (facts) -- notably the ITU-T G.107 E-model MOS
//  estimation (a public standard) and the QoS metric set. NOT a transcription of
//  Zoom's proprietary source.
//
//  Reconstructed from (mcm.dll, IDA/Hex-Rays):
//    sub_18000D600 / sub_180041360   app_uplink_net_score_t PDU (build/parse)
//    sub_1800188B0                    per-stream config apply (net_score/bw_level/...)
//    sub_1801642D0                    per-user audio MOS score (G.107 E-model)
//    sub_18009CC20                    MCM_NW_WARNING network-warning trigger
// =============================================================================
#pragma once
#include <cstdint>
#include <cmath>
#include <string>
#include <vector>
#include <functional>
#include "weaknet_reference.hpp"   // NetScore / BwLevel / MultiFecStats / DistributeBandwidth

namespace recon::mcm {

using recon::weaknet::NetScore;
using recon::weaknet::BwLevel;

// --- Per-stream codec config (from sub_1800188B0 codec_conf) ------------------
struct CodecConf {
    uint32_t sample_rate = 48000;
    int      codec_type  = 0;
    uint32_t bit_rate    = 0;
    bool     extra_fec   = false;   // extra_fec flag
};

// --- Per-stream attributes parsed/applied (sub_1800188B0) ---------------------
struct StreamConfig {
    uint32_t ssrc = 0;
    NetScore up_net_score = NetScore::Invalid; // mc_up_net_score  0..5
    BwLevel  up_bw_level  = BwLevel::L4;        // mc_up_bw_level   1..4
    bool     record_flag  = false;              // c_rcd_flg (==3 -> set)
    uint32_t anno_version = 0;                  // anno_version
    uint32_t as_ctrl_id   = 0;                  // as_ctrl_id
    CodecConf codec;
};

// =============================================================================
//  A) ITU-T G.107 E-model audio MOS estimation  (sub_1801642D0).
//     R-factor -> MOS via the standard G.107 polynomial; abs network delay is
//     turned into a delay impairment (Id) via a piecewise curve whose breakpoints
//     (100/500/1000/2000/3500 ms) and anchor values were recovered.
// =============================================================================
struct AudioQosMetrics {                 // exactly the JSON keys emitted by mcm
    uint32_t recv_packet_since_last     = 0;
    uint32_t cur_packets_loss_rate      = 0;   // x10 fixed-point in the wire form
    uint32_t max_packets_lost_once      = 0;
    uint32_t continuou_packets_lost_ratio = 0;
    uint32_t cur_fec_packets_ratio      = 0;
    uint32_t cur_plc_packets_ratio      = 0;
    uint32_t avg_iat_ms                 = 0;
    uint32_t max_iat_ms                 = 0;
    uint32_t cur_jitter_ms              = 0;
    uint32_t abs_net_delay_ms           = 0;
    // outputs:
    float    cur_mos_score              = 0.f; // 1.0 .. 4.5
    int      cur_score                  = 0;   // R-factor * 10
};

// Delay impairment Id(d): monotonic, recovered anchor points (ms -> impairment).
inline float DelayImpairment(uint32_t d_ms) {
    struct P { float d, id; };
    // recovered breakpoints/anchors (approximation of the observed curve)
    static const P k[] = { {100,0.f},{500,9.6f},{1000,19.8f},{2000,27.8f},{3500,36.8f},{12000,60.f} };
    if (d_ms <= k[0].d) return 0.f;
    for (size_t i = 1; i < sizeof(k)/sizeof(k[0]); ++i)
        if (d_ms <= k[i].d) {
            float t = (float(d_ms) - k[i-1].d) / (k[i].d - k[i-1].d);
            return k[i-1].id + t * (k[i].id - k[i-1].id);
        }
    return 60.f; // clamp
}

// R -> MOS: the published ITU-T G.107 formula (public standard).
inline float RtoMos(float R) {
    if (R <= 0.f)   return 1.0f;
    if (R >= 100.f) return 4.5f;
    return 1.0f + 0.035f * R + R * (R - 60.0f) * (100.0f - R) * 7.0e-6f;
}

// Compute MOS from a base transmission-rating R0 (derived from loss/FEC/PLC) and
// the measured absolute network delay. Mirrors sub_1801642D0's math.
inline float EstimateMos(float R_base, uint32_t abs_net_delay_ms, int* out_R_x10 = nullptr) {
    float R = R_base - DelayImpairment(abs_net_delay_ms);
    if (R < 0.f) R = 0.f; else if (R > 93.2f) R = 93.2f;   // recovered clamp
    if (out_R_x10) *out_R_x10 = int(R * 10.0f);
    return RtoMos(R);
}

// =============================================================================
//  B) MCM_NW_WARNING trigger (sub_18009CC20) with on/off hysteresis.
//     Uses two distinct threshold counters so the warning does not flap.
// =============================================================================
class NetWarning {
public:
    static constexpr uint16_t kMonitorPduType = 79; // monitor_info_t
    struct Thresholds { uint32_t on_value; uint32_t off_value; }; // a1+2036 / a1+2080

    // returns true if warning state changed (caller emits the telemetry PDU).
    bool Update(bool condition, const Thresholds& th, uint32_t meeting_id) {
        bool prev = active_;
        active_ = condition ? true : (active_ && condition); // set on cond; hysteresis off
        if (condition && !prev) { active_ = true; last_value_ = th.on_value; }
        else if (!condition && prev) { active_ = false; last_value_ = th.off_value; }
        meeting_id_ = meeting_id;
        return active_ != prev;
    }
    bool active() const { return active_; }
    // "MCM_NW_WARNING,<meeting>,<on>,<value>,<localdate>"
    std::string FormatTelemetry() const {
        return "MCM_NW_WARNING," + std::to_string(meeting_id_) + "," +
               std::to_string(active_ ? 1 : 0) + "," + std::to_string(last_value_);
    }
private:
    bool active_ = false; uint32_t last_value_ = 0, meeting_id_ = 0;
};

// =============================================================================
//  C) Media Channel Manager -- ties it together.
// =============================================================================
class MediaChannelManager {
public:
    static constexpr uint32_t kScoreReportPeriodMs = 9800; // recovered throttle (~0x2648)
    static constexpr int      kQosCmd = 301, kQosSub = 327;

    struct Deps {
        std::function<uint32_t()> now_ms;
        std::function<float(const AudioQosMetrics&)> baseRfactor; // loss/FEC/PLC -> R0
        std::function<void(uint32_t ssrc, const AudioQosMetrics&)> reportQos;
        std::function<void(const std::string&)> emitNwWarning;
    };
    explicit MediaChannelManager(Deps d) : d_(std::move(d)) {}

    // Called each stats tick with the raw per-user metrics; forces on 'force'.
    void OnAudioStats(uint32_t ssrc, AudioQosMetrics m, bool force = false) {
        const uint32_t t = d_.now_ms ? d_.now_ms() : 0;
        if (!force && last_report_ && (t - last_report_) < kScoreReportPeriodMs) return;
        float R0 = d_.baseRfactor ? d_.baseRfactor(m) : 93.2f;
        m.cur_mos_score = EstimateMos(R0, m.abs_net_delay_ms, &m.cur_score);
        if (d_.reportQos) d_.reportQos(ssrc, m);
        last_report_ = t;
    }

    // Total uplink budget split across streams by bw_level weight.
    std::vector<recon::weaknet::StreamBudget> Distribute(uint32_t total_bps) const {
        std::vector<std::pair<uint32_t,BwLevel>> v;
        for (auto& s : streams_) v.push_back({ s.ssrc, s.up_bw_level });
        return recon::weaknet::DistributeBandwidth(total_bps, v);
    }

    void ApplyStreamConfig(const StreamConfig& c) {
        for (auto& s : streams_) if (s.ssrc == c.ssrc) { s = c; return; }
        streams_.push_back(c);
    }
    NetWarning& warning() { return warning_; }

private:
    Deps d_;
    std::vector<StreamConfig> streams_;
    NetWarning warning_;
    uint32_t   last_report_ = 0;
};

} // namespace recon::mcm
