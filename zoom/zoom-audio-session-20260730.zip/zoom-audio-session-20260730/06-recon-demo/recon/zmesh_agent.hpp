// =============================================================================
//  zmesh_agent.hpp -- CLEAN-ROOM reconstruction of the eCDN / mesh-networking
//  agent reverse-engineered from Zoom's zMeshNetAgent.dll.  ORIGINAL C++17;
//  faithful to the recovered interface, super-node model, config toggles and
//  meeting-state transitions. No verbatim proprietary source.
//
//  Reconstructed from (zMeshNetAgent.dll + Cmmlib ECDN messages):
//    exports: GetMeshNetworkInterface / ReleaseMeshNetworkInterface
//    config : EnableMeshNetworking, webinar-mesh, guest-mesh (+ GPO), cdn_meeting_id
//    supernode: ECDNSwitchSuperNode, ECDNSetBackupSuperNodeInfo,
//               ECDNUpdateSuperNodeMaxLoad, ECDNInfo
//    security: create_zbtls_cert_with_public_key
//    state  : FormatMeetingState() transitions (state 1 stamps start,
//             state 4 triggers erase/cleanup)
// =============================================================================
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <functional>

namespace recon::zmesh {

// Group Policy tri-state seen in the traces (EnableGuestMesh GPO).
enum class GpoState { NotSet, ForceOff, ForceOn };

struct MeshConfig {
    bool     enable_mesh        = false;   // EnableMeshNetworking
    bool     account_webinar_mesh = false; // enable webinar mesh
    bool     meeting_mesh       = false;   // enable meeting mesh
    GpoState guest_mesh_gpo     = GpoState::NotSet; // EnableGuestMesh (GPO)
};

// --- Super-node model (eCDN): one client relays streams to same-LAN peers -----
enum class MeshRole { Leaf, SuperNode, BackupSuperNode };

struct SuperNodeInfo {
    std::string node_id;
    std::string address;        // LAN address peers connect to
    uint32_t    max_load = 0;   // ECDNUpdateSuperNodeMaxLoad (max downstream peers)
    uint32_t    cur_load = 0;
};

// --- Meeting state machine (FormatMeetingState) ------------------------------
//  Numeric transitions are facts; names are inferred. Observed: entering state 1
//  records the meeting start time; entering state 4 runs cleanup/erase.
enum class MeshMeetingState : int {
    Unknown   = 0,
    Init      = 1,   // stamps start time (a1+368)
    Connecting= 2,
    Active    = 3,
    Erasing   = 4,   // triggers teardown (sub_18000E550)
};

// Callbacks the host wires to the media path.
struct MeshCallbacks {
    std::function<void(const SuperNodeInfo&)> onSwitchSuperNode;   // ECDNSwitchSuperNode
    std::function<void(const SuperNodeInfo&)> onBackupSuperNode;   // ECDNSetBackupSuperNodeInfo
    std::function<void(MeshMeetingState)>     onMeetingState;
    std::function<void(const std::string&)>   trace;               // "[MeshNetwork TraceLog]"
};

// --- The mesh network interface (GetMeshNetworkInterface returns this) --------
struct IMeshNetwork {
    virtual ~IMeshNetwork() = default;

    virtual bool Initialize(const MeshConfig&, MeshCallbacks) = 0;
    virtual void SetMeeting(uint64_t meetingNum, const std::string& cdnMeetingId) = 0;

    // super-node lifecycle
    virtual void BecomeSuperNode(const SuperNodeInfo&) = 0;         // local promotion
    virtual void SwitchSuperNode(const SuperNodeInfo&) = 0;         // ECDNSwitchSuperNode
    virtual void SetBackupSuperNode(const SuperNodeInfo&) = 0;      // ECDNSetBackupSuperNodeInfo
    virtual void UpdateSuperNodeMaxLoad(uint32_t maxLoad) = 0;      // ECDNUpdateSuperNodeMaxLoad
    virtual MeshRole role() const = 0;

    // meeting state pump (drives FormatMeetingState transitions)
    virtual void OnMeetingState(MeshMeetingState) = 0;
    virtual MeshMeetingState meeting_state() const = 0;

    // secure channel between mesh peers
    virtual bool CreateZbtlsCert(const uint8_t* publicKey, size_t n) = 0; // create_zbtls_cert_with_public_key

    virtual void HandleResourceLimit(const std::string& json) = 0; // HandleResourceLimitMsg
};

// --- Reconstructed export ABI ------------------------------------------------
IMeshNetwork* GetMeshNetworkInterface();
void          ReleaseMeshNetworkInterface(IMeshNetwork*);

// Reference skeleton implementing the state-transition side effects faithfully.
class MeshMeetingStateMachine {
public:
    explicit MeshMeetingStateMachine(MeshCallbacks cb) : cb_(std::move(cb)) {}
    void Transition(MeshMeetingState next, std::function<uint64_t()> now_ms) {
        if (next == state_) return;
        if (cb_.trace) cb_.trace("[MeshNetwork TraceLog] Meeting move to " +
                                 std::to_string(int(next)));
        state_ = next;
        if (next == MeshMeetingState::Init) {          // state 1: stamp start time
            if (!start_ms_ && now_ms) start_ms_ = now_ms();
            end_ms_ = 0;
        } else if (next == MeshMeetingState::Erasing) { // state 4: cleanup/erase
            OnErase();
        }
        if (cb_.onMeetingState) cb_.onMeetingState(next);
    }
    MeshMeetingState state() const { return state_; }
private:
    void OnErase() { end_ms_ = start_ms_; /* release peers / tear down relay */ }
    MeshCallbacks cb_;
    MeshMeetingState state_ = MeshMeetingState::Unknown;
    uint64_t start_ms_ = 0, end_ms_ = 0;
};

} // namespace recon::zmesh
