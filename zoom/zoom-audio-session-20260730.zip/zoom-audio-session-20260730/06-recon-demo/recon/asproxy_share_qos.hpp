// =============================================================================
//  asproxy_share_qos.hpp -- CLEAN-ROOM reconstruction of the Application-Share
//  proxy from Zoom's asproxy.dll.  ORIGINAL C++17 modeling the recovered control
//  protocol + session/QoS structures.  No verbatim proprietary source.
//
//  *** CORRECTED after reading the decompiled function BODIES (re-verification). ***
//  The earlier version of this file invented a "NACK / FEC / congestion_control"
//  engine.  The actual asproxy.dll bodies show NO nack/fec logic at all.  What it
//  really is: an XML "asp" CONTROL-PROTOCOL client that negotiates an application
//  -sharing session with the server, authenticates, receives a "welcome" carrying
//  a data-relay endpoint + bind token, opens an ssb async-socket DATA CHANNEL, and
//  reports link QoS as a "network-info" PDU (type 53) carrying a per-channel
//  bw_level.  Corrected to match the evidence below.
//
//  Decompiled evidence (asproxy.dll, IDA/Hex-Rays):
//   - CreateASProxy      0x180001850  -> allocs 1184-byte ASP::CASProxyImp
//                                        (async_socket_sink_it + timer_sink_it +
//                                         ref_count_t + queriable_it + IASProxy)
//   - SetDispatchSink    0x180001810  -> stores global dispatch sink
//   - InitLib/UninitLib  0x180001640/0x1800017A0 (util_init, tp_init, register_logger)
//   - dispatch-by-cmd    0x1800057E8  -> parse XML <protocol name="asp" ver cmd=..>,
//                                        switch(cmd): negotiate / authenticate /
//                                        reauthenticate / welcome / monitor /
//                                        message / bye.  auth,reauth set state=3.
//   - negotiate builder  0x180006D84  -> <protocol name="asp" cmd="negotiate">
//                                        device info: "cpu num","cpu freqx100",
//                                        "hw info type","as profile","audio codec",
//                                        "share audio","client ver","ext ver".
//   - welcome/bind token 0x18000623C  -> parse "data ip","data port","bind token",
//                                        "asdata ssrc","adata ssrc","as profile",
//                                        "srn rsln"; socket_ctx_t::new_instance(ip,
//                                        port,8,..) ver=3 alive=0x927C0(600000ms),
//                                        async_socket_it connect timeout 5000ms,
//                                        state=4 (connected).
//   - qos network-info   0x180013B98  -> builds qos_network_info_pdu_t (TYPE 53);
//                                        iterates 8 channels; sets variant keyed by
//                                        channel: 1="bw_level_audio",2="bw_level_ds",
//                                        3="bw_level_video"; channel 7 gated on a
//                                        flag; dispatch via sub_180013DF0.
// =============================================================================
#pragma once
#include <cstdint>
#include <cstddef>
#include <array>
#include <string>
#include <vector>

namespace recon::asproxy {

// -----------------------------------------------------------------------------
// Session state machine (recovered numeric values from the state word @ +1072).
// authenticate / reauthenticate set 3; welcome (data channel up) sets 4.
// -----------------------------------------------------------------------------
enum class SessionState : int {
    Idle          = 0,
    Negotiating   = 1,
    Authenticating= 3,   // set by "authenticate"/"reauthenticate"
    Connected     = 4,   // set by "welcome" after data socket connects
};

// Control commands carried by the XML "asp" protocol (cmd= attribute), 0x1800057E8.
enum class AspCommand {
    Negotiate, Authenticate, Reauthenticate, Welcome, Monitor, Message, Bye, Unknown
};
// strcmp table recovered from the cmd dispatch switch in sub_1800057E8.
inline AspCommand ParseAspCommand(const char* cmd) {
    if (!cmd) return AspCommand::Unknown;
    struct { const char* s; AspCommand c; } tbl[] = {
        {"negotiate",      AspCommand::Negotiate},
        {"authenticate",   AspCommand::Authenticate},
        {"reauthenticate", AspCommand::Reauthenticate},
        {"welcome",        AspCommand::Welcome},
        {"monitor",        AspCommand::Monitor},
        {"message",        AspCommand::Message},
        {"bye",            AspCommand::Bye},
    };
    for (auto& e : tbl) {
        const char* a = cmd; const char* b = e.s;
        while (*a && *b && *a == *b) { ++a; ++b; }
        if (*a == *b) return e.c;   // both hit '\0'
    }
    return AspCommand::Unknown;
}

// -----------------------------------------------------------------------------
// Media channel indices used by the QoS network-info PDU (0x180013B98).
// The bw_level variant is keyed by the channel index below.  ds = DESKTOP SHARE
// (application share), NOT "downstream" (that was the earlier file's error).
// -----------------------------------------------------------------------------
enum class Channel : uint8_t {
    Ch0 = 0,
    Audio = 1,          // "bw_level_audio"
    DesktopShare = 2,   // "bw_level_ds"
    Video = 3,          // "bw_level_video"
    Ch4 = 4, Ch5 = 5, Ch6 = 6,
    Ch7 = 7,            // only emitted when the gating flag (@+2404)==1
};
inline const char* BwLevelKey(Channel c) {
    switch (c) {
        case Channel::Audio:        return "bw_level_audio";
        case Channel::DesktopShare: return "bw_level_ds";
        case Channel::Video:        return "bw_level_video";
        default:                    return nullptr;   // only 1/2/3 are keyed
    }
}

// Per-channel bandwidth tier value carried in the network-info PDU.
using BwLevel = uint8_t;   // recovered as an 8-bit variant value per channel

// One channel slot as packed by 0x180013B98 (fields at +52/+266/+267/+272/+288).
struct QosChannelInfo {
    bool     active   = false;   // (slot+52): channel present this report
    BwLevel  bw_level = 0;       // (slot+267) -> variant "bw_level_*"
    uint8_t  flag8    = 0;       // (slot+266)
    uint32_t val_a    = 0;       // (slot+272)
    uint32_t val_b    = 0;       // (slot+288)
};

// qos_network_info_pdu_t -- PDU TYPE 53 (v26 = 53 in 0x180013B98).
struct QosNetworkInfoPdu {
    static constexpr uint8_t kPduType = 53;
    std::array<QosChannelInfo, 8> channels{};   // 8 media channels
    bool channel7_enabled = false;              // gate @+2404==1
};

// -----------------------------------------------------------------------------
// "negotiate" payload (device-info advertised to the server), 0x180006D84.
// -----------------------------------------------------------------------------
struct NegotiateInfo {
    int         cpu_num        = 0;     // "cpu num"
    int         cpu_freq_x100  = 0;     // "cpu freqx100"
    int         hw_info_type   = 0;     // "hw info type"
    uint32_t    as_profile     = 0;     // "as profile"
    std::string audio_codec;            // "audio codec"
    bool        share_audio    = false; // "share audio"
    std::string client_ver;             // "client ver" (e.g. "7.1.0.41345")
    int         ext_ver        = 0;     // "ext ver"
};

// -----------------------------------------------------------------------------
// "welcome" payload (server-assigned data relay + bind token), 0x18000623C.
// -----------------------------------------------------------------------------
struct WelcomeInfo {
    std::string data_ip;                 // "data ip"
    uint16_t    data_port   = 0;         // "data port"
    std::string bind_token;              // "bind token"
    uint32_t    asdata_ssrc = 0;         // "asdata ssrc" (share-data SSRC)
    uint32_t    adata_ssrc  = 0;         // "adata ssrc"  (audio-data SSRC)
    uint32_t    as_profile  = 0;         // "as profile"
    std::string srn_rsln;                // "srn rsln"
};

// Data-channel parameters recovered from the welcome handler (0x18000623C):
//   ssb::socket_ctx_t::new_instance(ip, port, media_type=8, ..),
//   set_version(3), set_alive_time(600000ms); async connect timeout 5000ms.
struct DataChannelParams {
    static constexpr uint8_t  kMediaType     = 8;
    static constexpr uint8_t  kSocketVersion = 3;
    static constexpr uint32_t kAliveTimeMs   = 600000;  // 0x927C0
    static constexpr uint32_t kConnectTimeoutMs = 5000;
};

// -----------------------------------------------------------------------------
// Memory hooks (ASPMemAlloc/ASPMemFree) so the host owns allocation.
// -----------------------------------------------------------------------------
using AspAlloc = void* (*)(size_t);
using AspFree  = void  (*)(void*);
void InitLib(AspAlloc = nullptr, AspFree = nullptr);   // InitLib   0x180001640
void UninitLib();                                      // UninitLib 0x1800017A0
void* ASPMemAlloc(size_t);                             // ASPMemAlloc 0x180001900

// Sink the proxy reports session/QoS events back through (SetDispatchSink).
struct IDispatchSink {
    virtual ~IDispatchSink() = default;
    virtual void OnStateChanged(SessionState) {}
    virtual void OnWelcome(const WelcomeInfo&) {}                 // data channel ready
    virtual void OnQosNetworkInfo(const QosNetworkInfoPdu&) {}    // type-53 uplink QoS
    virtual void OnData(const uint8_t* p, size_t n) { (void)p;(void)n; } // AS data channel rx
};

// The AS proxy interface (CreateASProxy returns the IASProxy subobject).
struct IASProxy {
    virtual ~IASProxy() = default;
    virtual void SetDispatchSink(IDispatchSink*) = 0;               // SetDispatchSink
    // control protocol (XML "asp")
    virtual int  OnControlMessage(const char* xml, size_t n) = 0;   // 0x1800057E8 dispatch
    virtual int  SendNegotiate(const NegotiateInfo&) = 0;           // 0x180006D84
    virtual int  Authenticate() = 0;                                // "authenticate"
    virtual int  Reauthenticate() = 0;                              // "reauthenticate"
    // session / data channel
    virtual SessionState state() const = 0;
    virtual bool ConnectDataChannel(const WelcomeInfo&) = 0;        // welcome -> socket_ctx
    // QoS uplink
    virtual void ReportQosNetworkInfo(const QosNetworkInfoPdu&) = 0;// type-53 PDU
    virtual bool ShareAudioEnabled() const = 0;                     // "share audio"
};

IASProxy* CreateASProxy(/*context*/ void* ctx);   // CreateASProxy  0x180001850
void      DestroyASProxy(IASProxy*);              // DestroyASProxy 0x1800018D0

} // namespace recon::asproxy
