// =============================================================================
//  printwindow_capturer.hpp -- WinRT-free GDI window capturer (clean-room).
//  A standalone variant of the PrintWindow fallback reconstructed from
//  CptUwpCapture (sub_180002C60): DWM extended-frame rect, bounds sanity,
//  top-down 32bpp DIB, PW_RENDERFULLCONTENT, transparent-border auto-crop.
//  ORIGINAL code, public Win32/DWM APIs only. Namespace recon::pw so it never
//  clashes with the WGC-integrated copy in wgc_capturer.hpp.
//
//  Link: dwmapi.lib gdi32.lib user32.lib
// =============================================================================
#pragma once
#ifndef NOMINMAX
#define NOMINMAX          // keep <windows.h> from defining min()/max() macros
#endif
#include <windows.h>
#include <dwmapi.h>
#include <vector>
#include <optional>
#include <cstdint>
#include <algorithm>

namespace recon::pw {

inline constexpr int kMaxDim         = 4132;   // recovered upper bound
inline constexpr int kMinCoord       = -15360; // reject far off-screen
inline constexpr int kAutoCropMaxEdge= 100;
inline constexpr int kAutoCropHint   = 18;

struct RgbaFrame {                     // BGRA32, top-down
    int width = 0, height = 0, pitch = 0;
    std::vector<uint8_t> pixels;       // size = pitch*height
    RECT contentRect{};                // valid (non-transparent) sub-rect
    bool ok() const { return width > 0 && height > 0 && !pixels.empty(); }
};

class PrintWindowCapturer {
public:
    static std::optional<RgbaFrame> Capture(HWND hwnd, bool clientOnly = false) {
        WINDOWPLACEMENT wp{ sizeof(wp) };
        if (!hwnd || !GetWindowPlacement(hwnd, &wp)) return std::nullopt;
        if (wp.showCmd == SW_SHOWMINIMIZED) return std::nullopt;
        if (!(GetWindowLongW(hwnd, GWL_STYLE) & WS_VISIBLE)) return std::nullopt;

        RECT rc{};
        if (FAILED(DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, &rc, sizeof(rc))))
            if (!GetWindowRect(hwnd, &rc)) return std::nullopt;
        if (rc.left < kMinCoord || rc.top < kMinCoord) return std::nullopt;

        int w = rc.right - rc.left, h = rc.bottom - rc.top;
        if (w <= 0 || h <= 0 || w > kMaxDim || h > kMaxDim) return std::nullopt;

        BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bi.bmiHeader.biWidth = w; bi.bmiHeader.biHeight = -h;   // top-down
        bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;

        HDC screen = GetDC(nullptr);
        HDC mem = CreateCompatibleDC(screen);
        void* bits = nullptr;
        HBITMAP dib = CreateDIBSection(screen, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        HGDIOBJ old = SelectObject(mem, dib);

        UINT flags = PW_RENDERFULLCONTENT | (clientOnly ? PW_CLIENTONLY : 0u);
        BOOL ok = PrintWindow(hwnd, mem, flags);

        std::optional<RgbaFrame> out;
        if (ok && bits) {
            RgbaFrame f; f.width = w; f.height = h; f.pitch = w * 4;
            f.pixels.assign((uint8_t*)bits, (uint8_t*)bits + size_t(f.pitch) * h);
            f.contentRect = AutoCrop(f);
            out = std::move(f);
        }
        SelectObject(mem, old); DeleteObject(dib); DeleteDC(mem); ReleaseDC(nullptr, screen);
        return out;
    }

private:
    static bool IsContent(uint32_t bgra) { return ((bgra + 0x01000000u) & 0xFEFFFFFFu) != 0; }

    static RECT AutoCrop(const RgbaFrame& f) {
        auto* px = reinterpret_cast<const uint32_t*>(f.pixels.data());
        const int W = f.width, H = f.height, s = f.pitch / 4;
        auto rowEmpty = [&](int y){ for (int x=0;x<W;++x) if (IsContent(px[y*s+x])) return false; return true; };
        auto colEmpty = [&](int x){ for (int y=0;y<H;++y) if (IsContent(px[y*s+x])) return false; return true; };
        int t=0;  while (t < (std::min)(H,kAutoCropMaxEdge) && rowEmpty(t)) ++t;
        int b=0;  while (b < (std::min)(H,kAutoCropMaxEdge) && rowEmpty(H-1-b)) ++b;
        int l=0;  while (l < (std::min)(W,kAutoCropMaxEdge) && colEmpty(l)) ++l;
        int r=0;  while (r < (std::min)(W,kAutoCropMaxEdge) && colEmpty(W-1-r)) ++r;
        auto adj=[&](int v){ return v>kAutoCropHint ? v-1 : v; };
        t=adj(t); b=adj(b); l=adj(l); r=adj(r);
        return RECT{ l, t, W-r, H-b };
    }
};

} // namespace recon::pw
