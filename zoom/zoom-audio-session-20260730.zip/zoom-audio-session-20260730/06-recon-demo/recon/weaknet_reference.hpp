// =============================================================================
//  weaknet_reference.hpp -- CLEAN-ROOM technique reference reconstructed from the
//  weak-network media logic reverse-engineered in Zoom's viper / zlt / mcm.
//
//  ORIGINAL code. It reproduces the *algorithms, thresholds, and interface shape*
//  observed during analysis (all facts), expressed in clean, portable C++17. It
//  is NOT a transcription of Zoom's decompiled functions and contains none of
//  their proprietary source. The neural pieces (SNAC codec, DRED PLC, audio/video
//  super-resolution, denoise) are model-weights + inference and cannot be
//  reproduced from static analysis -- they appear here only as interface stubs.
// =============================================================================
#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <string>
#include <utility>

namespace recon::weaknet {

// =============================================================================
//  A) Audio: reliable-TCP -> Opus recovery gate.
//     Reconstructed from viper.dll sub_1800D1BE0 / sub_1800D2A60
//     ("snac-tcp-to-opus" tier II / III). Constants are the recovered values.
// =============================================================================
struct OpusPacketSpan {
    uint16_t min_seq = 0, max_seq = 0;   // RTP sequence range present in buffer
    uint32_t min_ts  = 0, max_ts  = 0;   // 48 kHz timestamps
    uint32_t packet_count = 0;           // actually-received packet records
};

enum class RecoveryTier { II, III };

struct OpusGateConfig {
    uint32_t min_gap_since_tcp_ms   = 2000; // only recover after UDP silence >= 2s
    uint32_t min_valid_window_ms    = 2500; // need >=2.5s of usable audio
    float    max_loss_tier_II       = 0.50f; // tier II tolerates <=50% loss
    float    max_loss_tier_III      = 0.20f; // tier III tolerates <=20% loss
};

struct OpusGateResult { bool accept = false; float loss = 0.f; const char* reject = nullptr; };

// samples_per_ms = 48 (48 kHz). +20ms accounts for one trailing frame.
inline OpusGateResult EvaluateOpusRecovery(const OpusPacketSpan& s,
                                           uint32_t ms_since_last_tcp,
                                           RecoveryTier tier,
                                           const OpusGateConfig& cfg = {}) {
    OpusGateResult r;
    if (ms_since_last_tcp < cfg.min_gap_since_tcp_ms) { r.reject = "recv_no_snac_tcp_pack"; return r; }
    const uint32_t window_ms = (s.max_ts - s.min_ts) / 48u + 20u;
    if (window_ms < cfg.min_valid_window_ms)          { r.reject = "check_opus_has_enough_valid_data"; return r; }
    const uint32_t expected = uint32_t(uint16_t(s.max_seq - s.min_seq)) + 1u;
    if (expected == 0)                                 { r.reject = "empty"; return r; }
    r.loss = float(int(expected) - int(s.packet_count)) / float(expected);
    const float thr = (tier == RecoveryTier::III) ? cfg.max_loss_tier_III : cfg.max_loss_tier_II;
    if (r.loss > thr)                                  { r.reject = "check_opus_loss_rate"; return r; }
    r.accept = true;
    return r;
}

// =============================================================================
//  B) Multi-layer FEC accounting. Reconstructed from mcm.dll counters
//     (total_decoded_3rd_4th_5th_fec_packets, cur_fec_packets_ratio).
// =============================================================================
struct MultiFecStats {
    uint64_t media_packets = 0;
    uint64_t fec_level_recovered[6]{}; // index = FEC order (1..5 used)
    uint64_t effective_recovered_by_fec = 0;
    double fec_ratio() const {
        uint64_t fec = 0; for (auto v : fec_level_recovered) fec += v;
        return media_packets ? double(fec) / double(media_packets + fec) : 0.0;
    }
};

// =============================================================================
//  C) Uplink network feedback. Reconstructed from mcm.dll app_uplink_net_score_t
//     (PDU type 85): net_score 0..5, bw_level 1..4.  This is a re-expression of
//     the *shape* of the feedback, not the wire format.
// =============================================================================
enum class NetScore : uint8_t { S0=0,S1,S2,S3,S4,S5, Invalid=0xFF };
enum class BwLevel  : uint8_t { L1=1,L2,L3,L4 };

struct UplinkNetScorePdu {
    static constexpr uint16_t kPduType = 85;
    uint32_t stream_id = 0;
    NetScore net_score = NetScore::Invalid;
    BwLevel  bw_level  = BwLevel::L4;
    bool     record_flag = false;   // c_rcd_flg
    uint32_t anno_version = 0;       // anno_version
};

// Allocates a total estimated uplink budget across streams by bw_level weight.
// Reconstructed intent of bandwidth_distribute_info.
struct StreamBudget { uint32_t stream_id; BwLevel level; uint32_t assigned_bps; };
inline std::vector<StreamBudget> DistributeBandwidth(
        uint32_t total_bps, const std::vector<std::pair<uint32_t,BwLevel>>& streams) {
    std::vector<StreamBudget> out; uint32_t wsum = 0;
    for (auto& s : streams) wsum += uint32_t(s.second); // weight = level
    for (auto& s : streams) {
        uint32_t w = uint32_t(s.second);
        out.push_back({ s.first, s.second, wsum ? uint32_t(uint64_t(total_bps)*w/wsum) : 0 });
    }
    return out;
}

// =============================================================================
//  D) Video: SVC layer config + key-picture request dispatcher.
//     Reconstructed from zlt.dll zltCEncodeConfig::SetEncodeCfg (field layout)
//     and SetKeyPictureRequest dispatcher (case enum).
// =============================================================================
struct SvcSpatialLayer {
    int   width = 0, height = 0;
    float frame_rate = 0.f;
    int   codec_mode = 0, profile_idx = 0, level_idx = 0, tools_ctrl_flag = 0;
    int   bitrate = 0, fix_qp = 0;
    int   layer_qos_level = 0, layer_complexity_level = 0, entropy_coding_mode = 0;
    int   ra_period = 0, ra_type = 0, ra_fix_qp = 0;   // random-access (keyframe) cadence
    int   ref_frame_num = 0;
    bool  single_ref = false, ltr = false;             // long-term reference for loss recovery
    int   slice_bytes = 0, slice_num = 0, thread_num = 0;
    int   temporal_layer_num = 1;                      // + per-TId frame rates below
    std::vector<float> temporal_frame_rate;            // size = temporal_layer_num
    bool  bits_supp = false; float bitrate_factor = 1.f;
};

struct SvcEncodeConfig {
    float input_frame_rate = 0.f, actual_frame_rate = 0.f;
    int   connect_mode = 0;
    uint64_t source_level = 0;
    int   preproc_level = 0;
    std::vector<SvcSpatialLayer> spatial;   // size = spatial_layer_num
};

// Mirrors the request types dispatched by SetKeyPictureRequest (cases 2/3/4/5/20/24/31).
enum class KeyPictureRequest {
    KeyPicture,             // 2  : recovery reference for a spatial layer
    NewAttendeeIPicture,    // 3  : new joiner needs an I-picture
    Idr,                    // 4  : force IDR
    DuplicateP,             // 5  : duplicate a P-frame for resilience
    SubscribeChange,        // 20 : layer subscription changed
    FrameSkip,              // 24 : drop/skip a frame under congestion
    BitrateTarget           // 31 : rate-control target (<4 modes)
};

struct KeyPicRequestArgs {
    int dependency_id = 0;   // == spatial index
    int temporal_id = 0;
    int last_received_pic_id = 0;
    int used_i_pic_id = 0;
    int request_number = 0;
    uint32_t bitrate_target = 0;
};

// Interface an encoder wrapper would implement; a decoder/RWG calls Request(...).
struct ISvcEncoderControl {
    virtual ~ISvcEncoderControl() = default;
    virtual int  SetEncodeConfig(const SvcEncodeConfig&) = 0;
    virtual int  Request(KeyPictureRequest type, const KeyPicRequestArgs&) = 0;
    // Validate spatial/temporal indices against the codec's max layer counts.
    virtual bool ValidIndices(int spatial, int temporal) const = 0;
};

// =============================================================================
//  E) Neural enhancement -- interface stubs only (models not reproducible).
// =============================================================================
struct INeuralAudio {       // SNAC codec / DRED PLC / denoise / bandwidth-extension
    virtual ~INeuralAudio() = default;
    virtual bool  LoadModel(const std::string& path) = 0;      // 64MB weights blob
    virtual int   EncodeExtra(const int16_t* pcm, size_t n, std::vector<uint8_t>& out) = 0;
    virtual int   DecodeConceal(const uint8_t* pkt, size_t n, int16_t* pcm, size_t cap) = 0;
    virtual void  SetSpeakerEmbedding(const float* emb, size_t dim) = 0; // personalized
};
struct INeuralVideo {       // RAISR super-res / temporal (EDNet) denoise
    virtual ~INeuralVideo() = default;
    virtual bool LoadModel(const std::string& path) = 0;
    virtual bool SuperResolve(const uint8_t* in, int w, int h, uint8_t* out, int scale) = 0;
    virtual bool TemporalDenoise(uint8_t* frame, int w, int h) = 0;
};

} // namespace recon::weaknet
