// =============================================================================
//  viper_audio_engine.hpp -- CLEAN-ROOM reconstruction of the audio weak-network
//  decision engine reverse-engineered from Zoom's viper.dll (the "ssb audio SDK").
//
//  ORIGINAL code. It models the *state machines, decision gates, codec IDs, error
//  codes, control bits and thresholds* recovered by static analysis (all facts),
//  expressed in clean C++17. It is NOT a transcription of Zoom's decompiled
//  functions and contains none of their proprietary source. Real codecs/DSP
//  (Opus, the neural SNAC/AI codec, NetEQ) sit behind the interfaces below --
//  the neural pieces are trained models + inference and are not reproducible
//  from decompilation.
//
//  Reconstructed from (viper.dll, IDA/Hex-Rays):
//    sub_1800CE540  EnableExtraAiCodec        (codec-gate + module bring-up)
//    sub_1800594C0  OnExtraAiCodecCtrlEvent   (control-word bit 0x4 toggle)
//    sub_1800C39E0  EnableExtraSnacDecoding   (kDisable<->kReady state machine)
//    sub_1800D1BE0  SnacTcpToOpus tier II     (loss<=50%)     -> weaknet_reference
//    sub_1800D2A60  SnacTcpToOpus tier III    (loss<=20%)     -> weaknet_reference
//    sub_1800A1180  SetFECStatus              (RED unsupported, err 8003)
//    sub_18009FC50  GetFECStatus              (RED unsupported)
//    sub_180074920  [CODEC] mode switch
// =============================================================================
#pragma once
#include <cstdint>
#include <functional>
#include <optional>
#include <string>
#include "weaknet_reference.hpp"   // OpusPacketSpan / EvaluateOpusRecovery / RecoveryTier

namespace recon::viper {

// --- Codec type IDs (Send/Recv codec selection) ------------------------------
enum class CodecId : int {
    OpusMain    = 113,  // primary Opus variant the AI codec may overlay
    OpusMainAlt = 116,  // alternate Opus variant
    AiCodec     = 121,  // "extra" neural AI codec (overlay), looked up by id 121
};
inline bool IsAiOverlayBase(int mainCodecId) {           // gate in sub_1800CE540
    return mainCodecId == int(CodecId::OpusMain) || mainCodecId == int(CodecId::OpusMainAlt);
}

// --- Error codes returned by EnableExtraAiCodec (negative == failure) --------
enum class AiCodecError : int32_t {
    Ok               =    0,
    FailGetMainCodec = -301, // "failed to get main SendCodec"
    CannotEnable     = -302, // "can not enable aicodec, main SendCodec: <id>"
    GetCodecFailed   = -303, // "get codec failed"
    AiCodecNotFound  = -304, // "failed to find aicodec(121)"
    CreateAcmFailed  = -305, // "failed to create AudioCodingModule"
    InitAcmFailed    = -306, // "failed to init AudioCodingModule"
    CreateRtpFailed  = -307, // "failed to create RtpRtcpModule"
    InitRtpFailed    = -308, // "failed to init RtpRtcpModule"
};

// --- SNAC decoder status machine (viper stores this at object+51152) ---------
enum class SnacStatus : int32_t { kDisable = 0, kReady = 1, kActive = 2 };

// --- Control-word carried by the extra-codec control event -------------------
namespace ctrl {
    inline constexpr uint32_t kParamMask = 0x3FF; // low 10 bits = codec params id
    inline constexpr uint32_t kCtrlEnc   = 0x4;   // bit toggles EXTRA encoding on/off
}
inline constexpr int kEventBusExtraCodec = 44;    // republished when params change

// --- FEC: this build does NOT support RED FEC (in-band Opus FEC used instead) -
inline constexpr int kFecErrRedUnsupported = 8003;

// =============================================================================
//  Dependency interfaces (real implementations are Opus / neural / WebRTC).
// =============================================================================
struct ICodecEnumerator {                 // enumerate negotiated codecs
    virtual ~ICodecEnumerator() = default;
    virtual int  Count() const = 0;
    virtual int  IdAt(int index) const = 0;   // returns codec id, or -1
};
struct IMainCodecQuery {
    virtual ~IMainCodecQuery() = default;
    virtual bool GetMainSendCodec(int& outId) = 0;   // false on failure
    virtual void SetExtraEncodeEnabled(bool on) = 0; // vtable+1184 in orig
};
struct IAudioCodingModule {                // ACM for the AI/extra codec
    virtual ~IAudioCodingModule() = default;
    virtual bool Init() = 0;
    virtual bool RegisterSendCodec(int id) = 0;
};
struct IRtpRtcpModule {                    // RTP/RTCP transport for the extra codec
    virtual ~IRtpRtcpModule() = default;
    virtual bool Init() = 0;
    virtual void SetSending(bool on) = 0;
};
struct INetEq {                            // adaptive jitter buffer (WebRTC NetEQ)
    virtual ~INetEq() = default;
    virtual bool SetPlayoutMode(int mode) = 0;   // SetNetEQPlayoutMode
    virtual bool GetJitterStatistics(uint32_t& jitterMs) = 0;
};
// Neural codec (SNAC) -- model + inference, interface only.
struct INeuralAudioCodec {
    virtual ~INeuralAudioCodec() = default;
    virtual bool LoadModel(const std::string& path) = 0;   // 64MB weights (viperex)
    virtual int  EncodeExtra(const int16_t* pcm, size_t n, std::vector<uint8_t>& out) = 0;
    virtual int  DecodeConceal(const uint8_t* pkt, size_t n, int16_t* pcm, size_t cap) = 0;
};

struct EngineDeps {
    ICodecEnumerator*  codecs      = nullptr;
    IMainCodecQuery*   mainCodec   = nullptr;
    INetEq*            neteq       = nullptr;
    INeuralAudioCodec* snac        = nullptr;
    // factories for the extra-codec modules (bring-up in EnableExtraAiCodec)
    std::function<IAudioCodingModule*()> makeAcm;
    std::function<IRtpRtcpModule*()>     makeRtp;
    // republish codec params on the event bus (event id 44)
    std::function<void(int eventId, uint32_t params)> publish;
    // structured logger (mirrors the "[snac-tcp.feat]" / "[CODEC]" traces)
    std::function<void(const std::string&)> log;
};

// =============================================================================
//  AudioWeakNetEngine -- the decision core.
// =============================================================================
class AudioWeakNetEngine {
public:
    explicit AudioWeakNetEngine(EngineDeps d) : d_(std::move(d)) {}

    // --- sub_1800CE540: enable/disable the extra AI codec (id 121) -----------
    AiCodecError EnableExtraAiCodec(bool enable) {
        if (!enable) { TeardownExtraCodec(); return AiCodecError::Ok; }

        int mainId = -1;
        if (!d_.mainCodec || !d_.mainCodec->GetMainSendCodec(mainId))
            return Fail(AiCodecError::FailGetMainCodec, "failed to get main SendCodec");

        // Gate: the AI codec may only overlay Opus id 113/116.
        if (!IsAiOverlayBase(mainId))
            return Fail(AiCodecError::CannotEnable,
                        "can not enable aicodec, main SendCodec: " + std::to_string(mainId));

        // Locate the AI codec (id 121) among the negotiated codecs.
        if (!FindCodec(int(CodecId::AiCodec)))
            return Fail(AiCodecError::AiCodecNotFound, "failed to find aicodec(121)");

        if (!acm_) { acm_ = d_.makeAcm ? d_.makeAcm() : nullptr;
                     if (!acm_) return Fail(AiCodecError::CreateAcmFailed, "failed to create AudioCodingModule"); }
        if (!acm_->Init() || !acm_->RegisterSendCodec(int(CodecId::AiCodec)))
                     return Fail(AiCodecError::InitAcmFailed,  "failed to init AudioCodingModule");
        if (!rtp_) { rtp_ = d_.makeRtp ? d_.makeRtp() : nullptr;
                     if (!rtp_) return Fail(AiCodecError::CreateRtpFailed, "failed to create RtpRtcpModule"); }
        if (!rtp_->Init())
                     return Fail(AiCodecError::InitRtpFailed,  "failed to init RtpRtcpModule");
        rtp_->SetSending(true);
        return AiCodecError::Ok;
    }

    // --- sub_1800594C0: control event; bit kCtrlEnc toggles extra encoding ----
    void OnExtraAiCodecControlEvent(uint32_t controlWord, uint32_t paramsPayload) {
        const uint32_t newField = controlWord & ctrl::kParamMask;
        const uint32_t oldField = ctrlField_ & ctrl::kParamMask;
        ctrlField_ = (ctrlField_ & ~ctrl::kParamMask) | newField;

        if (controlWord & ctrl::kCtrlEnc) {
            aiEncOn_ = true;
            if (d_.mainCodec) d_.mainCodec->SetExtraEncodeEnabled(true);
        } else {
            aiEncOn_ = false;
            if (d_.mainCodec) d_.mainCodec->SetExtraEncodeEnabled(false);
        }
        if (newField != oldField && d_.publish)     // params changed -> republish
            d_.publish(kEventBusExtraCodec, paramsPayload);
        Log("[ExtraAiCodecEvent_kCtrlEnc] enc=" + std::to_string(aiEncOn_));
    }

    // --- sub_1800C39E0: SNAC decoder enable state machine --------------------
    // flags bit 0x4 => decode SNAC delivered over the reliable TCP path.
    void EnableExtraSnacDecoding(bool enable, uint32_t flags) {
        Log("[snac-tcp.feat] EnableExtraSnacDecoding(enable: " + std::to_string(enable) + ")");
        if (enable) {
            if (snac_ == SnacStatus::kDisable) {
                Log(", ExtraSnacCodecStatus, change: kDisable -> kReady");
                snac_ = SnacStatus::kReady;
            }
        } else {
            if (snac_ == SnacStatus::kReady || snac_ == SnacStatus::kActive) {
                Log(", ExtraSnacCodecStatus, change: -> kDisable");
                snac_ = SnacStatus::kDisable;
            }
        }
        snacFlags_ = flags;
        snacOverTcp_ = (flags & 0x4) != 0;
    }

    // --- sub_1800D1BE0 / sub_1800D2A60: accept SNAC-over-TCP -> Opus rebuild --
    bool AcceptSnacTcpToOpus(const weaknet::OpusPacketSpan& span,
                             uint32_t ms_since_last_tcp,
                             weaknet::RecoveryTier tier) {
        auto r = weaknet::EvaluateOpusRecovery(span, ms_since_last_tcp, tier);
        if (!r.accept)
            Log(std::string("{check_") + (r.reject ? r.reject : "?") +
                "} fail, loss=" + std::to_string(r.loss));
        return r.accept;
    }

    // --- sub_1800A1180 / sub_18009FC50: RED FEC unsupported in this build -----
    int SetFECStatus(bool /*enable*/) { LogFecUnsupported(); return -1; }
    int GetFECStatus()                { LogFecUnsupported(); return -1; }

    // --- sub_180074920: [CODEC] mode switch (mode 9/10 reconfigure codec) -----
    void OnCodecModeChanged(int mode) {
        Log("[CODEC] mode = " + std::to_string(mode));
        codecMode_ = mode;               // 9/10 trigger extra-codec table re-lookup
    }

    // --- NetEQ passthrough (sub_18009B8C0 / sub_1800CA290) -------------------
    bool SetNetEqPlayoutMode(int mode) { return d_.neteq && d_.neteq->SetPlayoutMode(mode); }

    // accessors
    SnacStatus snac_status()  const { return snac_; }
    bool       snac_over_tcp() const { return snacOverTcp_; }
    bool       ai_encoding()  const { return aiEncOn_; }
    int        codec_mode()   const { return codecMode_; }

private:
    bool FindCodec(int id) {
        if (!d_.codecs) return false;
        for (int i = 0, n = d_.codecs->Count(); i < n; ++i)
            if (d_.codecs->IdAt(i) == id) return true;
        return false;
    }
    void TeardownExtraCodec() {
        if (rtp_) { rtp_->SetSending(false); rtp_ = nullptr; }
        acm_ = nullptr;
        Log("extra AI codec disabled / torn down");
    }
    AiCodecError Fail(AiCodecError e, const std::string& msg) { Log(msg); return e; }
    void LogFecUnsupported() { Log("SetFECStatus() RED is not supported (error=" +
                                   std::to_string(kFecErrRedUnsupported) + ")"); }
    void Log(const std::string& s) { if (d_.log) d_.log(s); }

    EngineDeps           d_;
    IAudioCodingModule*  acm_ = nullptr;
    IRtpRtcpModule*      rtp_ = nullptr;
    SnacStatus           snac_ = SnacStatus::kDisable;
    uint32_t             snacFlags_ = 0, ctrlField_ = 0;
    bool                 snacOverTcp_ = false, aiEncOn_ = false;
    int                  codecMode_ = 0;
};

// =============================================================================
//  DECISION CHAIN -- who decides Opus <-> AI-codec(121) <-> SNAC-over-TCP?
//  Static RE shows the DECISION IS SERVER-SIDE (MMR/RWG + account feature
//  toggles). The client's role, per module:
//    (1) mcm reports QoS upstream: G.107 MOS, loss, jitter, FEC/PLC ratios,
//        net_score(0-5), bw_level(1-4)          [mcm_media_channel.hpp]
//    (2) mcm receives a feature/control message and dispatches by type
//        (0x11, 0x31 MIC-MODE, 0x50 per-stream codec-feature bitmask using the
//        0xFFFFFC00|0x200 bit-set, 0x27 INTERPRETATION) -- recovered from
//        mcm sub_18007CFA0; it then TELEMETERS the outcome (EXTRA_AICODEC_EVENT
//        / EXTRA_AICODEC_STATUS_CODE as monitor_info PDU type 79).
//    (3) the per-stream control word reaches viper; bit 0x4 (kCtrlEnc) flips the
//        extra AI/SNAC *encoding* in OnExtraAiCodecControlEvent (this file).
//
//  AiSwitchInputs captures the client metrics that FEED the server decision.
//  ReferenceSwitchPolicy is an ILLUSTRATIVE client-side hint (the real policy is
//  server-side; these thresholds are NOT recovered constants) -- it exists so a
//  demo can show the end-to-end flow deterministically.
// =============================================================================
struct AiSwitchInputs {
    float    mos = 4.5f;            // mcm G.107 MOS estimate
    float    loss_rate = 0.f;       // 0..1
    uint32_t jitter_ms = 0;
    uint32_t rtt_ms = 0;
    int      net_score = 5;         // 0..5  (mc_up_net_score)
    int      bw_level = 4;          // 1..4  (mc_up_bw_level)
    bool     feature_enabled = true;// account toggle (Audio_Enable_OPUS_DRED_Codec / aicodec)
};
enum class CodecChoice { Opus, OpusDred, AiCodec, SnacOverTcp };
inline const char* ToString(CodecChoice c) {
    switch (c) { case CodecChoice::Opus:return "Opus";
        case CodecChoice::OpusDred:return "Opus+DRED"; case CodecChoice::AiCodec:return "AI-codec(121)";
        case CodecChoice::SnacOverTcp:return "SNAC-over-TCP"; } return "?";
}
// ILLUSTRATIVE only (thresholds not recovered): escalate resilience as the net degrades.
inline CodecChoice ReferenceSwitchPolicy(const AiSwitchInputs& in) {
    if (!in.feature_enabled) return CodecChoice::Opus;
    if (in.mos < 2.8f || in.loss_rate > 0.30f || in.net_score <= 1) return CodecChoice::SnacOverTcp;
    if (in.mos < 3.6f || in.loss_rate > 0.10f || in.bw_level <= 2)  return CodecChoice::AiCodec;
    if (in.loss_rate > 0.02f)                                       return CodecChoice::OpusDred;
    return CodecChoice::Opus;
}

} // namespace recon::viper
