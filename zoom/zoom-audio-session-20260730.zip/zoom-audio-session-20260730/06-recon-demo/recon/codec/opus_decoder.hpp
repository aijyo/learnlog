// =============================================================================
//  opus_decoder.hpp -- Opus decode backend wrapping the reference libopus
//  (BSD-3-Clause; Opus is royalty-free, RFC 6716).
//
//  viper.dll's audio is Opus-1.3.1-derived (fingerprint: opus/1.3.1/SILK strings,
//  no third-party attribution).  A Zoom Opus packet is RFC-6716 conformant, so the
//  reference libopus decoder decodes it bit-exactly -- interop-exact decode, the
//  well-defined "1:1" for a decoder.  The recovered viper control gates map onto
//  libopus encoder CTLs (documented in CODEC_RECONSTRUCTION_PLAN.md §4.3):
//     extrafec  -> OPUS_SET_INBAND_FEC
//     maxlbrr   -> OPUS_SET_PACKET_LOSS_PERC
//     DRED      -> OPUS_SET_DRED_DURATION (libopus 1.5)
//
//  Gated behind RECON_WITH_OPUS so the core project keeps zero external deps.
// =============================================================================
#pragma once
#include <cstdint>

#if defined(RECON_WITH_OPUS)
#include <opus.h>

namespace recon::codec::opus {

class OpusDecoderAdapter {
public:
    OpusDecoderAdapter(int sample_rate = 48000, int channels = 1)
        : sr_(sample_rate), ch_(channels) {
        int err = 0;
        dec_ = opus_decoder_create(sample_rate, channels, &err);
        if (err != OPUS_OK) dec_ = nullptr;
    }
    ~OpusDecoderAdapter() { if (dec_) opus_decoder_destroy(dec_); }
    bool ok() const { return dec_ != nullptr; }

    // Decode one Opus packet -> interleaved int16 PCM. Returns samples/channel, <0 on error.
    int Decode(const uint8_t* pkt, int len, int16_t* pcm, int max_samples_per_ch) {
        if (!dec_) return -1;
        return opus_decode(dec_, pkt, len, pcm, max_samples_per_ch, 0);
    }
    // Packet-loss concealment (what viper's PLC path leans on): pass a null packet.
    int Conceal(int16_t* pcm, int samples_per_ch) {
        if (!dec_) return -1;
        return opus_decode(dec_, nullptr, 0, pcm, samples_per_ch, 0);
    }
    // Decode using in-band FEC recovered from the *next* packet (extrafec path).
    int DecodeFec(const uint8_t* nextPkt, int len, int16_t* pcm, int samples_per_ch) {
        if (!dec_) return -1;
        return opus_decode(dec_, nextPkt, len, pcm, samples_per_ch, /*decode_fec=*/1);
    }

    static const char* version() { return opus_get_version_string(); }

private:
    OpusDecoder* dec_ = nullptr;
    int sr_, ch_;
};

} // namespace recon::codec::opus
#endif // RECON_WITH_OPUS
