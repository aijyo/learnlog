// =============================================================================
//  tp_transport.hpp -- CLEAN-ROOM reconstruction of the transport layer
//  reverse-engineered from Zoom's tp.dll ("Transport Module").  ORIGINAL C++17.
//  No verbatim proprietary source.
//
//  *** RE-VERIFIED against decompiled function BODIES. ***
//  The n=21 functions that actually decompiled are ALL ssb::socket_ctx_t
//  accessors -- so the VERIFIED surface of tp.dll is the secure-transport
//  endpoint descriptor below (TLS config + certificate pinning + traffic/media
//  tagging + websocket keepalive).  The DNS / link-metric / net-adaptor / trust
//  -store pieces further down were NOT decompiled (only inferred from RTTI /
//  imports) and are labeled as such -- do not treat them as verified.
//
//  Verified from socket_ctx_t bodies (field offsets in comments):
//    set_sec_version(u8)            @ +336
//    set_ssl_hostname_verify(bool)  @ +296
//    set_ssl_verify_mode(int)       @ +72  (dword)
//    set_ssl_verify_method(bool)    @ +73  (1, or 3 when true)
//    set/get_cert_info(string)      @ +304
//    get_error_code()               @ +75  (dword)
//    set_ws_alive(u32 iv,u32 to)    @ +90/+91 (websocket keepalive)
//    set/get_traffic_id(char*)      @ +376  (max 200 / 0xC8 chars)
//    set/get_media_type(u8)         @ +408
//    set/get_cert_fingerprint(str)  @ +416  (cert pin)
//    set/get_cert_public_key(str)   @ +448  (SPKI pin)
// =============================================================================
#pragma once
#include <cstdint>
#include <cstddef>
#include <functional>
#include <string>
#include <vector>

namespace recon::tp {

enum class Proto { Udp, Tcp, Tls, WebSocket };

// TLS peer-verification mode (ssl_verify_mode / ssl_verify_method).
enum class SslVerifyMode : int {
    None       = 0,
    Peer       = 1,   // verify_method default writes 1
    PeerStrict = 3,   // verify_method(true) writes 3 (peer + fail-if-no-cert)
};

// =============================================================================
//  VERIFIED: ssb::socket_ctx_t -- one secure transport endpoint's configuration.
//  Every field below maps to a decompiled accessor (offsets above).
// =============================================================================
struct SocketConfig {
    // --- TLS / security ---
    uint8_t       sec_version        = 0;      // set_sec_version           (+336)
    bool          ssl_hostname_verify= true;   // set_ssl_hostname_verify   (+296)
    SslVerifyMode ssl_verify_mode    = SslVerifyMode::Peer;  // set_ssl_verify_mode (+72)
    std::string   cert_info;                    // set/get_cert_info         (+304)
    std::string   cert_fingerprint;             // set/get_cert_fingerprint  (+416) — pin
    std::string   cert_public_key;              // set/get_cert_public_key   (+448) — SPKI pin
    // --- tagging / keepalive ---
    std::string   traffic_id;                   // set_traffic_id (<=200)    (+376)
    uint8_t       media_type         = 0;       // set/get_media_type        (+408)
    uint32_t      ws_alive_interval  = 0;       // set_ws_alive.a2           (+90)
    uint32_t      ws_alive_timeout   = 0;       // set_ws_alive.a3           (+91)

    static constexpr size_t kMaxTrafficId = 200; // strnlen guard (0xC8) in set_traffic_id
    // set_traffic_id returns 2 (error) if the id exceeds kMaxTrafficId.
    bool valid_traffic_id() const { return traffic_id.size() <= kMaxTrafficId; }
    // set_ssl_verify_method(true) => PeerStrict(3), else Peer(1).
    void set_verify_method(bool strict) {
        ssl_verify_mode = strict ? SslVerifyMode::PeerStrict : SslVerifyMode::Peer;
    }
};

struct Endpoint { std::string host; uint16_t port = 0; };

// ssb::socket_ctx_t -- transport connection (config = SocketConfig above).
// Open/Send/Recv are the expected I/O surface (WS2_32 imports) -- these method
// SIGNATURES are inferred; the CONFIG accessors above are the decompiled facts.
struct ISocketCtx {
    virtual ~ISocketCtx() = default;
    virtual SocketConfig&       config() = 0;
    virtual const SocketConfig& config() const = 0;
    virtual bool Open(const Endpoint&, Proto) = 0;              // [inferred]
    virtual int  Send(const uint8_t* p, size_t n) = 0;         // WSASend/WSASendTo [inferred]
    virtual int  Recv(uint8_t* p, size_t cap) = 0;             // WSARecv/recvfrom  [inferred]
    virtual void Close() = 0;
    virtual int  error_code() const = 0;                       // get_error_code (+75)
    virtual Proto proto() const = 0;
};

// =============================================================================
//  NOT VERIFIED (RTTI / imports only -- function bodies were NOT decompiled).
//  Kept as plausible abstractions; flagged so they are not mistaken for facts.
// =============================================================================

// [RTTI-only] ssb::dns_provider_t -- async resolution (imports suggest c-ares).
struct IDnsProvider {
    virtual ~IDnsProvider() = default;
    virtual void Resolve(const std::string& host,
                         std::function<void(const std::vector<std::string>&)> cb) = 0;
};

// [RTTI-only] ssb::jitter_t / bandwidth_t / throughput_t -- link measurement.
struct LinkMetrics {
    uint32_t jitter_ms      = 0;   // jitter_t       [RTTI-only]
    uint32_t bandwidth_bps  = 0;   // bandwidth_t    [RTTI-only]
    uint32_t throughput_bps = 0;   // throughput_t   [RTTI-only]
    uint32_t rtt_ms         = 0;
    float    loss_rate      = 0.f;
};
struct ILinkMonitor {              // [RTTI-only]
    virtual ~ILinkMonitor() = default;
    virtual void OnPacketSent(size_t bytes, uint32_t ts_ms) = 0;
    virtual void OnPacketAcked(size_t bytes, uint32_t rtt_ms) = 0;
    virtual LinkMetrics snapshot() const = 0;
};

// [import-only] ssb::net_adaptors_t -- NIC/route change (roaming) via IPHLPAPI.
struct INetAdaptorMonitor {
    virtual ~INetAdaptorMonitor() = default;
    virtual void Start(std::function<void()> onChange) = 0;    // NotifyAddrChange
    virtual std::vector<std::string> LocalAddresses() const = 0; // GetAdaptersAddresses
};

// [inference] embedded root-CA trust list for pinning validation.
struct ITrustStore {
    virtual ~ITrustStore() = default;
    virtual bool IsTrustedRoot(const uint8_t* der, size_t n) const = 0;
    virtual size_t RootCount() const = 0;
};

// Transport module facade.
struct TransportApi {
    ISocketCtx*  (*createSocket)() = nullptr;   // VERIFIED type (socket_ctx_t)
    IDnsProvider* dns = nullptr;                // [RTTI-only]
    ITrustStore*  trust = nullptr;              // [inference]
    ILinkMonitor* (*createLinkMonitor)() = nullptr; // [RTTI-only]
    INetAdaptorMonitor* netmon = nullptr;       // [import-only]
};

} // namespace recon::tp
