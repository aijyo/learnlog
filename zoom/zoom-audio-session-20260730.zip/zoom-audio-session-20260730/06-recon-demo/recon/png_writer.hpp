// =============================================================================
//  png_writer.hpp -- minimal self-contained PNG writer (8-bit RGBA).
//  ORIGINAL code. Uses zlib "stored" (uncompressed) DEFLATE blocks so there is
//  no external dependency. Input is BGRA (as produced by GDI DIB sections).
// =============================================================================
#pragma once
#include <cstdint>
#include <cstdio>
#include <vector>
#include <string>

namespace recon {

namespace pngdetail {

inline uint32_t crc32(const uint8_t* p, size_t n, uint32_t crc = 0xFFFFFFFFu) {
    static uint32_t tbl[256]; static bool init = false;
    if (!init) { for (uint32_t i=0;i<256;i++){ uint32_t c=i; for(int k=0;k<8;k++) c = (c&1)?(0xEDB88320u^(c>>1)):(c>>1); tbl[i]=c; } init=true; }
    for (size_t i=0;i<n;i++) crc = tbl[(crc ^ p[i]) & 0xFF] ^ (crc >> 8);
    return crc;
}
inline uint32_t adler32(const uint8_t* p, size_t n) {
    uint32_t a = 1, b = 0;
    for (size_t i=0;i<n;i++){ a=(a+p[i])%65521; b=(b+a)%65521; }
    return (b<<16)|a;
}
inline void putBE32(std::vector<uint8_t>& v, uint32_t x) {
    v.push_back(uint8_t(x>>24)); v.push_back(uint8_t(x>>16));
    v.push_back(uint8_t(x>>8));  v.push_back(uint8_t(x));
}
inline void chunk(std::vector<uint8_t>& out, const char* type, const std::vector<uint8_t>& data) {
    putBE32(out, uint32_t(data.size()));
    std::vector<uint8_t> td(type, type+4);
    td.insert(td.end(), data.begin(), data.end());
    out.insert(out.end(), td.begin(), td.end());
    uint32_t c = crc32(td.data(), td.size()) ^ 0xFFFFFFFFu;
    putBE32(out, c);
}
} // namespace pngdetail

// Write BGRA (top-down) pixels as an RGBA PNG. forceOpaque sets alpha=255.
inline bool write_png_bgra(const std::string& path, const uint8_t* bgra,
                           int w, int h, int pitch, bool forceOpaque = true) {
    using namespace pngdetail;
    // raw = per-row [filter=0][RGBA...]
    std::vector<uint8_t> raw;
    raw.reserve(size_t(h) * (1 + size_t(w) * 4));
    for (int y = 0; y < h; ++y) {
        raw.push_back(0);
        const uint8_t* row = bgra + size_t(y) * pitch;
        for (int x = 0; x < w; ++x) {
            uint8_t B=row[x*4+0], G=row[x*4+1], R=row[x*4+2], A=row[x*4+3];
            raw.push_back(R); raw.push_back(G); raw.push_back(B);
            raw.push_back(forceOpaque ? 255 : A);
        }
    }
    // zlib stream: header + stored deflate blocks + adler32
    std::vector<uint8_t> z; z.push_back(0x78); z.push_back(0x01);
    size_t off = 0;
    while (off < raw.size()) {
        size_t n = raw.size() - off; if (n > 65535) n = 65535;
        bool final = (off + n >= raw.size());
        z.push_back(final ? 1 : 0);                        // BFINAL, BTYPE=00
        z.push_back(uint8_t(n)); z.push_back(uint8_t(n>>8));
        uint16_t nn = uint16_t(~n);
        z.push_back(uint8_t(nn)); z.push_back(uint8_t(nn>>8));
        z.insert(z.end(), raw.begin()+off, raw.begin()+off+n);
        off += n;
    }
    uint32_t ad = adler32(raw.data(), raw.size());
    z.push_back(uint8_t(ad>>24)); z.push_back(uint8_t(ad>>16));
    z.push_back(uint8_t(ad>>8));  z.push_back(uint8_t(ad));

    std::vector<uint8_t> out = {0x89,'P','N','G',0x0D,0x0A,0x1A,0x0A};
    std::vector<uint8_t> ihdr;
    putBE32(ihdr, uint32_t(w)); putBE32(ihdr, uint32_t(h));
    ihdr.push_back(8); ihdr.push_back(6); ihdr.push_back(0); ihdr.push_back(0); ihdr.push_back(0); // 8-bit RGBA
    chunk(out, "IHDR", ihdr);
    chunk(out, "IDAT", z);
    chunk(out, "IEND", {});

    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    std::fwrite(out.data(), 1, out.size(), f);
    std::fclose(f);
    return true;
}

} // namespace recon
