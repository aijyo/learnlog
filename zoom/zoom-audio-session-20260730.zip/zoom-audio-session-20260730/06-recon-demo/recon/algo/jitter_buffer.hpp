// =============================================================================
//  jitter_buffer.hpp -- REAL adaptive playout jitter buffer (working impl).
//  RFC-3550 jitter estimate -> adaptive target delay; in-order playout with
//  packet-loss concealment accounting. Models the NetEQ-style buffer viper
//  drives. ORIGINAL code (RFC-3550 is a public standard).
// =============================================================================
#pragma once
#include <cstdint>
#include <map>
#include <vector>
#include <optional>

namespace recon::algo {

class AdaptiveJitterBuffer {
public:
    struct Packet { uint16_t seq; uint32_t ts_ms; std::vector<uint8_t> data; };
    struct Stats { double jitter_ms; uint32_t target_delay_ms; uint32_t played; uint32_t concealed; };

    AdaptiveJitterBuffer(uint32_t frame_ms = 20, uint32_t min_ms = 40, uint32_t max_ms = 400)
        : frame_ms_(frame_ms), min_ms_(min_ms), max_ms_(max_ms) {}

    void Push(uint16_t seq, uint32_t ts_ms, uint32_t recv_ms, std::vector<uint8_t> data) {
        if (have_prev_) {
            int32_t d = int32_t(recv_ms - prev_recv_) - int32_t(ts_ms - prev_ts_);
            if (d < 0) d = -d;
            jitter_ += (double(d) - jitter_) / 16.0;         // RFC-3550 interarrival jitter
        }
        prev_recv_ = recv_ms; prev_ts_ = ts_ms; have_prev_ = true;

        uint32_t tgt = uint32_t(2.0 * jitter_);              // ~2x jitter, rounded to a frame
        tgt = ((tgt + frame_ms_ - 1) / frame_ms_) * frame_ms_;
        target_ = tgt < min_ms_ ? min_ms_ : (tgt > max_ms_ ? max_ms_ : tgt);

        if (!started_) { return_seq_ = seq; started_ = true; }
        buf_[seq] = Packet{ seq, ts_ms, std::move(data) };
    }

    // Returns the next in-order packet; nullopt means a concealment slot (gap) or
    // an underrun. Advances past a gap once a later packet has arrived.
    std::optional<Packet> Pop() {
        if (!started_) return std::nullopt;
        auto it = buf_.find(return_seq_);
        if (it != buf_.end()) {
            Packet p = std::move(it->second);
            buf_.erase(it);
            ++return_seq_; ++played_;
            return p;
        }
        if (!buf_.empty() && uint16_t(buf_.begin()->first - return_seq_) < 0x8000) {
            ++return_seq_; ++concealed_;                     // conceal the lost packet
            return std::nullopt;
        }
        return std::nullopt;                                 // underrun: wait for more
    }

    Stats  stats() const { return Stats{ jitter_, target_, played_, concealed_ }; }
    size_t depth() const { return buf_.size(); }

private:
    uint32_t frame_ms_, min_ms_, max_ms_;
    std::map<uint16_t, Packet> buf_;
    double   jitter_ = 0.0;
    uint32_t target_ = 0, prev_recv_ = 0, prev_ts_ = 0;
    bool     have_prev_ = false, started_ = false;
    uint16_t return_seq_ = 0;
    uint32_t played_ = 0, concealed_ = 0;
};

} // namespace recon::algo
