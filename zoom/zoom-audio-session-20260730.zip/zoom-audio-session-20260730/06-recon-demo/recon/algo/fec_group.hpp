// =============================================================================
//  fec_group.hpp -- REAL interleaved-XOR erasure FEC (working implementation).
//  Models the "multi-level FEC" packet-group concept (mcm 3rd/4th/5th FEC,
//  nydus ClientFecRtpPacketGroup): K media packets protected by M parity
//  packets, parity[j] = XOR of media[i] where i % M == j. Recovers one loss per
//  parity group; iterating recovers more. ORIGINAL code (standard XOR erasure
//  coding). Production uses Reed-Solomon for >1-per-group; noted.
// =============================================================================
#pragma once
#include <cstdint>
#include <vector>

namespace recon::algo {

class XorFec {
public:
    using Packet = std::vector<uint8_t>;

    // Produce M parity packets protecting `media` (interleaved by i % M).
    static std::vector<Packet> Encode(const std::vector<Packet>& media, int m) {
        size_t maxlen = 0;
        for (const auto& p : media) if (p.size() > maxlen) maxlen = p.size();
        std::vector<Packet> parity(m, Packet(maxlen, 0));
        for (size_t i = 0; i < media.size(); ++i) {
            Packet& par = parity[i % m];
            for (size_t b = 0; b < media[i].size(); ++b) par[b] ^= media[i][b];
        }
        return parity;
    }

    // Recover erasures in place. present[i]==false marks a lost media packet;
    // recovered packets are written back and marked present. Returns #recovered.
    static int Recover(std::vector<Packet>& media, std::vector<bool>& present,
                       const std::vector<Packet>& parity, size_t pktLen) {
        const int m = (int)parity.size();
        int recovered = 0, progress = 1;
        while (progress) {
            progress = 0;
            for (int j = 0; j < m; ++j) {
                int missing = -1, missCount = 0;
                for (size_t i = j; i < media.size(); i += m)
                    if (!present[i]) { ++missCount; missing = (int)i; }
                if (missCount == 1) {                       // one erasure -> solvable
                    Packet rec = parity[j];
                    for (size_t i = j; i < media.size(); i += m)
                        if (present[i])
                            for (size_t b = 0; b < media[i].size(); ++b) rec[b] ^= media[i][b];
                    rec.resize(pktLen);
                    media[missing] = rec;
                    present[missing] = true;
                    ++recovered; progress = 1;
                }
            }
        }
        return recovered;
    }
};

} // namespace recon::algo
