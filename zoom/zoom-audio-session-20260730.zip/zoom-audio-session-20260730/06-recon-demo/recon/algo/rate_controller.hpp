// =============================================================================
//  rate_controller.hpp -- REAL loss-based AIMD rate controller (working impl).
//  Additive-increase / multiplicative-decrease on measured loss, mapped to the
//  1..4 bandwidth tier (matches mc_up_bw_level buckets). ORIGINAL code.
// =============================================================================
#pragma once
#include <cstdint>

namespace recon::algo {

class RateController {
public:
    RateController(uint32_t min_bps = 64000, uint32_t max_bps = 2500000, uint32_t start_bps = 800000)
        : min_(min_bps), max_(max_bps), rate_(start_bps) {}

    void OnFeedback(float loss, uint32_t /*rtt_ms*/ = 0) {
        if (loss > 0.10f)        rate_ = uint32_t(rate_ * 0.85f);   // multiplicative decrease
        else if (loss < 0.02f)   rate_ += 50000;                    // additive increase
        if (rate_ < min_) rate_ = min_;
        if (rate_ > max_) rate_ = max_;
    }

    uint32_t rate_bps() const { return rate_; }
    int bw_level() const {                                          // 1..4
        if (rate_ >= 1500000) return 4;
        if (rate_ >=  800000) return 3;
        if (rate_ >=  300000) return 2;
        return 1;
    }

private:
    uint32_t min_, max_, rate_;
};

} // namespace recon::algo
