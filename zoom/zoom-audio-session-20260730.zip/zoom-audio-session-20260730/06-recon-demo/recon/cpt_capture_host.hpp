// =============================================================================
//  cpt_capture_host.hpp -- CLEAN-ROOM reconstruction of the capture host and
//  backend-selection logic reverse-engineered from Zoom's CptHost.exe /
//  CptShare.dll.  ORIGINAL C++17 (public Win32/WinRT APIs).
//
//  Reconstructed from (CptHost.exe, IDA/Hex-Rays):
//    sub_14007CF44   capture-mode / "AS" config parse + per-process role branch
//    sub_140077CA0   DWM/UxTheme capability probe (dynamic GetProcAddress)
//    sub_140021D14   capturer main thread bring-up (event + 10s init wait)
//  Backend set confirmed via imports: d3d11, d3d9, dxgi, dcomp, Magnification,
//  GDI (BitBlt/StretchBlt/PrintWindow) + WGC helper (CptUwpCapture.dll).
//
//  The actual WGC / PrintWindow capture lives in wgc_capturer.hpp.
// =============================================================================
#pragma once
#include <windows.h>
#include <dwmapi.h>
#include <string>
#include "wgc_capturer.hpp"

namespace recon::cpt {

// --- process role (sub_14007CF44 branch on argv[0] basename) -----------------
enum class HostRole { Share, Install, Service, Control, Unknown };

inline HostRole RoleFromProcessName(const std::wstring& lowerExe) {
    if (lowerExe.find(L"cptinstall") != std::wstring::npos) return HostRole::Install;
    if (lowerExe.find(L"cptservice") != std::wstring::npos) return HostRole::Service;
    if (lowerExe.find(L"cptshare")   != std::wstring::npos) return HostRole::Share;
    if (lowerExe.find(L"cptcontrol") != std::wstring::npos) return HostRole::Control;
    return HostRole::Unknown;
}

// --- "AS" (Application Sharing) config keys recovered from sub_14007CF44 ------
struct AsCaptureConfig {
    bool dump_img          = false;
    int  dump_img_interval = 0;
    int  dump_img_count    = 0;      // clamped to <= 50
    bool dump_type_origin  = false;  // type_origin
    bool dump_type_process = false;  // type_process
    bool dump_type_final   = false;  // type_final
    bool dump_type_cgimage = false;  // type_cgimage

    void Clamp() { if (dump_img_count > 50) dump_img_count = 50; } // recovered cap
};

// --- DWM capability probe (sub_140077CA0) ------------------------------------
struct DwmCaps { bool composition_enabled = false; bool has_dwm = false; };
inline DwmCaps ProbeDwm() {
    DwmCaps c{};
    if (HMODULE h = LoadLibraryW(L"dwmapi.dll")) {           // dynamic, like the original
        c.has_dwm = true;
        BOOL en = FALSE;
        if (SUCCEEDED(DwmIsCompositionEnabled(&en))) c.composition_enabled = !!en;
        FreeLibrary(h);
    }
    return c;
}

// =============================================================================
//  Backend selection -- WGC (Win10 1903+, composited) preferred, then DXGI
//  desktop-duplication, then GDI / Magnification (window-exclusion) fallbacks.
// =============================================================================
enum class Backend { Wgc, DxgiDuplication, Gdi, Magnification, None };

struct CaptureTarget { HWND hwnd = nullptr; HMONITOR monitor = nullptr; bool excludeSelf = false; };

inline Backend SelectBackend(CaptureMode mode, const CaptureTarget& t, const DwmCaps& dwm) {
    switch (mode) {
        case CaptureMode::Wgc:         return recon::WgcAvailable() ? Backend::Wgc : Backend::Gdi;
        case CaptureMode::PrintWindow: return Backend::Gdi;
        case CaptureMode::Auto: default: break;
    }
    // Auto order (mirrors CptHost preference):
    if (recon::WgcAvailable() && dwm.composition_enabled) return Backend::Wgc;
    if (t.monitor && dwm.composition_enabled)             return Backend::DxgiDuplication;
    if (t.excludeSelf)                                    return Backend::Magnification; // hide own window
    return Backend::Gdi;                                                                 // PrintWindow/BitBlt
}

// =============================================================================
//  CaptureHost -- bring-up mirrors sub_140021D14: create the worker thread and
//  its init event, then wait up to 10s for the pipeline to become ready.
// =============================================================================
class CaptureHost {
public:
    static constexpr DWORD kInitTimeoutMs = 10000; // 0x2710

    bool Start(const CaptureTarget& target, CaptureMode mode = CaptureMode::Auto) {
        target_ = target;
        dwm_    = ProbeDwm();
        backend_= SelectBackend(mode, target, dwm_);
        if (backend_ == Backend::None) return false;

        initEvent_ = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!initEvent_) return false;
        thread_ = CreateThread(nullptr, 0, &CaptureHost::ThreadEntry, this, 0, nullptr);
        if (!thread_) return false;
        // block until the capturer signals readiness or the 10s budget elapses
        return WaitForSingleObject(initEvent_, kInitTimeoutMs) == WAIT_OBJECT_0;
    }

    void Stop() {
        stop_ = true;
        if (thread_) { WaitForSingleObject(thread_, kInitTimeoutMs); CloseHandle(thread_); thread_ = nullptr; }
        if (initEvent_) { CloseHandle(initEvent_); initEvent_ = nullptr; }
    }
    ~CaptureHost() { Stop(); }

    Backend backend() const { return backend_; }

private:
    static DWORD WINAPI ThreadEntry(LPVOID p) { return static_cast<CaptureHost*>(p)->ThreadMain(); }

    DWORD ThreadMain() {
        recon::D3DContext gpu;
        bool ready = false;
        if (backend_ == Backend::Wgc && gpu.Create()) {
            wgc_ = std::make_unique<recon::WgcCapturer>(gpu);
            ready = target_.monitor ? wgc_->StartForMonitor(target_.monitor)
                                    : wgc_->StartForWindow(target_.hwnd);
            if (ready) wgc_->SetCursorCaptureEnabled(true);
        } else if (backend_ == Backend::Gdi || backend_ == Backend::Magnification) {
            ready = (target_.hwnd != nullptr);   // PrintWindowCapturer used per-frame
        } else if (backend_ == Backend::DxgiDuplication) {
            ready = gpu.Create();                // IDXGIOutputDuplication path (add as needed)
        }
        SetEvent(initEvent_);                    // signal init done (ready or not)
        // ... frame loop would run here until stop_ ...
        return ready ? 0u : 1u;
    }

    CaptureTarget target_{};
    DwmCaps       dwm_{};
    Backend       backend_ = Backend::None;
    HANDLE        thread_ = nullptr, initEvent_ = nullptr;
    volatile bool stop_ = false;
    std::unique_ptr<recon::WgcCapturer> wgc_;
};

} // namespace recon::cpt
