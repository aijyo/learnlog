// =============================================================================
//  demo_algo.cpp -- exercises the REAL algorithm classes (portable):
//    XorFec (erasure recovery), AdaptiveJitterBuffer, RateController (AIMD),
//    RsFec (Reed-Solomon GF(2^8)/0x11D erasure code == nydus share FEC).
// =============================================================================
#include <cstdio>
#include <vector>
#include "recon/algo/fec_group.hpp"
#include "recon/algo/jitter_buffer.hpp"
#include "recon/algo/rate_controller.hpp"
#include "recon/algo/rs_fec.hpp"

using namespace recon::algo;

int main() {
    // --- A) XOR erasure FEC -------------------------------------------------
    printf("== A) XOR FEC : K=8 media, M=3 parity ==\n");
    std::vector<XorFec::Packet> media;
    for (int i = 0; i < 8; ++i) media.push_back(XorFec::Packet(16, (uint8_t)(i + 1)));  // pkt i filled with i+1
    auto parity = XorFec::Encode(media, 3);
    std::vector<XorFec::Packet> recvd = media;
    std::vector<bool> present(8, true);
    for (int d : {2, 4}) { recvd[d].clear(); present[d] = false; }   // lose pkt 2 (grp2) & 4 (grp1)
    int rec = XorFec::Recover(recvd, present, parity, 16);
    printf("   lost {2,4} -> recovered %d;  pkt2[0]=%d (want 3)  pkt4[0]=%d (want 5)\n",
           rec, recvd[2].empty() ? -1 : recvd[2][0], recvd[4].empty() ? -1 : recvd[4][0]);

    // --- B) adaptive jitter buffer -----------------------------------------
    printf("== B) adaptive jitter buffer : 20ms frames, jittered arrivals, seq3 lost ==\n");
    AdaptiveJitterBuffer jb(20, 40, 400);
    uint32_t recv_ms[] = { 0, 25, 38, 70, 80, 110, 118, 160 };
    for (int i = 0; i < 8; ++i) {
        if (i == 3) continue;                                        // packet 3 never arrives
        jb.Push((uint16_t)i, (uint32_t)(i * 20), recv_ms[i], std::vector<uint8_t>(4, (uint8_t)i));
    }
    auto st = jb.stats();
    printf("   jitter=%.1fms  target_delay=%ums  buffered=%zu\n", st.jitter_ms, st.target_delay_ms, jb.depth());
    int played = 0, concealed = 0;
    for (int i = 0; i < 8; ++i) { if (jb.Pop()) ++played; else ++concealed; }
    printf("   played=%d  concealed(incl loss)=%d\n", played, concealed);

    // --- C) AIMD rate controller -------------------------------------------
    printf("== C) AIMD rate controller : loss series -> rate/tier ==\n");
    RateController rc;
    for (float loss : {0.00f, 0.00f, 0.15f, 0.22f, 0.00f, 0.00f, 0.00f, 0.00f}) {
        rc.OnFeedback(loss, 50);
        printf("   loss=%2.0f%%  ->  rate=%7u bps  bw_level=%d\n", loss * 100.0f, rc.rate_bps(), rc.bw_level());
    }

    // --- D) Reed-Solomon FEC (GF(2^8)/0x11D) == nydus share FEC -------------
    printf("== D) RS FEC : GF(2^8) poly 0x11D, K=6 data + R=3 parity, erase 3 ==\n");
    {
        const int K = 6, R = 3, LEN = 20;
        RsFec rs(K, R);
        // K data shards, each a distinct recognizable pattern.
        std::vector<std::vector<uint8_t>> data(K, std::vector<uint8_t>(LEN));
        for (int j = 0; j < K; ++j)
            for (int b = 0; b < LEN; ++b) data[j][b] = (uint8_t)(0x10 * (j + 1) + b);
        auto parity = rs.Encode(data);

        // Assemble N=K+R shards, then erase 3 (two data + one parity).
        std::vector<std::vector<uint8_t>> shards = data;
        shards.insert(shards.end(), parity.begin(), parity.end());
        std::vector<char> present(K + R, 1);
        for (int e : {1, 4, K + 0}) { shards[e].assign(LEN, 0); present[e] = 0; }  // lose d1,d4,p0
        printf("   erased shards {1,4,%d(parity)} ; present=%d/%d\n", K, K + R - 1, K + R);

        bool ok = rs.Decode(shards, present);
        bool match = ok;
        for (int j = 0; j < K && match; ++j)
            if (shards[j] != data[j]) match = false;
        printf("   decode ok=%d  data fully recovered=%d  d1[0]=%d(want %d)  d4[0]=%d(want %d)\n",
               ok, match, shards[1][0], 0x20, shards[4][0], 0x50);

        // Sanity: with only K-1 present it must refuse.
        std::vector<char> tooFew(K + R, 0);
        for (int i = 0; i < K - 1; ++i) tooFew[i] = 1;
        std::vector<std::vector<uint8_t>> s2 = shards;
        printf("   with only K-1=%d present -> Decode returns %d (expect 0)\n",
               K - 1, rs.Decode(s2, tooFew));
    }

    printf("\n(algo demo complete)\n");
    return 0;
}
