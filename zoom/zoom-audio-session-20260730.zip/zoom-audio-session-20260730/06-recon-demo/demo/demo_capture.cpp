// =============================================================================
//  demo_capture.cpp (Windows) -- captures the whole screen while EXCLUDING this
//  process's own windows, via the class-based capture subsystem. Demonstrates
//  the Magnification window-exclusion backend (recon::capture::MagnifierCapturer)
//  with a DXGI/GDI fallback chain, then writes a PNG.
// =============================================================================
#include <windows.h>
#include <cstdio>
#include "recon/capture/capture_selector.hpp"
#include "recon/png_writer.hpp"

int main(int argc, char** argv) {
    using namespace recon::capture;
    setvbuf(stdout, nullptr, _IONBF, 0);   // unbuffered so progress shows immediately

    CaptureHost host;
    // Exclude our own console + the current foreground window from the capture
    // (this is the "hide the sharer's own window" use case) -> forces Magnifier.
    if (HWND self = GetConsoleWindow()) host.ExcludeWindow(self);
    if (HWND fg = GetForegroundWindow()) host.ExcludeWindow(fg);

    RECT screen = VirtualScreenRect();
    printf("capturing virtual screen [%ld,%ld -> %ld,%ld], excluding own/foreground windows...\n",
           screen.left, screen.top, screen.right, screen.bottom);

    auto f = host.CaptureOnce(screen, Backend::Auto);
    if (!f || !f->ok()) { printf("capture failed on all backends\n"); return 1; }

    const char* out = (argc > 1) ? argv[1] : "capture.png";
    bool ok = recon::write_png_bgra(out, f->pixels.data(), f->width, f->height, f->pitch, true);
    printf("backend=%s  %dx%d  saved '%s' (%s)\n",
           ToString(host.last_backend()), f->width, f->height, out, ok ? "ok" : "write failed");
    return ok ? 0 : 2;
}
