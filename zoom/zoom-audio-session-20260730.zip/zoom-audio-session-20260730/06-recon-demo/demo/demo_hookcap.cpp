// =============================================================================
//  demo_hookcap.cpp (Windows) -- end-to-end demo of the REAL Zoom capture
//  mechanism (in-process, no foreign injection needed):
//    1. a "target app" makes a D3D11 device + swapchain and renders a frame
//    2. PresentHook patches IDXGISwapChain::Present (== nydus Nydus::SafePresent)
//    3. on Present the hook copies the back-buffer into a keyed-mutex shared texture
//    4. a SEPARATE device (== the Zoom host) OpenSharedResource()'s the handle and
//       reads the pixels -> PNG
//  This exercises the exact inject-less core: Present-hook + shared DX surface.
// =============================================================================
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <cstdio>
#include "recon/capture/present_hook.hpp"
#include "recon/capture/shared_surface.hpp"
#include "recon/png_writer.hpp"

using Microsoft::WRL::ComPtr;

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);

    // ---- "target app": device + swapchain on a hidden window --------------
    WNDCLASSW wc{};
    wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"ReconHookCap";
    RegisterClassW(&wc);
    HWND hwnd = CreateWindowW(wc.lpszClassName, L"", WS_OVERLAPPEDWINDOW,
                              0, 0, 320, 240, nullptr, nullptr, wc.hInstance, nullptr);

    DXGI_SWAP_CHAIN_DESC scd{};
    scd.BufferCount = 2;
    scd.BufferDesc.Width = 320; scd.BufferDesc.Height = 240;
    scd.BufferDesc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    scd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    scd.OutputWindow = hwnd; scd.SampleDesc.Count = 1; scd.Windowed = TRUE;

    ComPtr<ID3D11Device> dev; ComPtr<ID3D11DeviceContext> ctx; ComPtr<IDXGISwapChain> sc;
    if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
                                             nullptr, 0, D3D11_SDK_VERSION, &scd,
                                             sc.GetAddressOf(), dev.GetAddressOf(), nullptr, ctx.GetAddressOf()))) {
        printf("D3D11 device/swapchain creation failed\n"); return 1;
    }

    // ---- install the Present hook (== Nydus::SafePresent) -----------------
    if (!recon::capture::PresentHook::Instance().Install(sc.Get())) { printf("hook install failed\n"); return 2; }

    // ---- render a solid color, then Present (triggers the hook) -----------
    ComPtr<ID3D11Texture2D> bb; sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)bb.GetAddressOf());
    ComPtr<ID3D11RenderTargetView> rtv; dev->CreateRenderTargetView(bb.Get(), nullptr, rtv.GetAddressOf());
    const float color[4] = { 0.15f, 0.45f, 0.85f, 1.0f };
    ctx->ClearRenderTargetView(rtv.Get(), color);
    sc->Present(0, 0);

    HANDLE shared = recon::capture::PresentHook::Instance().shared_handle();
    printf("hook published=%d shared-handle=%p\n", recon::capture::PresentHook::Instance().published(), shared);
    if (!shared) { printf("hook did not publish a shared surface\n"); return 3; }

    // ---- "Zoom host": a SEPARATE device opens the shared handle & reads it -
    ComPtr<ID3D11Device> rdev; ComPtr<ID3D11DeviceContext> rctx;
    D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
                      D3D11_SDK_VERSION, rdev.GetAddressOf(), nullptr, rctx.GetAddressOf());
    recon::capture::SharedSurfaceReader reader;
    if (!reader.Open(rdev.Get(), rctx.Get(), shared)) { printf("OpenSharedResource failed\n"); return 4; }

    int w, h, pitch;
    auto px = reader.Read(w, h, pitch);
    if (!px) { printf("read shared surface failed\n"); return 5; }

    const char* out = (argc > 1) ? argv[1] : "hookcap.png";
    bool ok = recon::write_png_bgra(out, px->data(), w, h, pitch, true);
    printf("Present-hook -> shared-surface -> host read OK: %dx%d  saved '%s' (%s)\n",
           w, h, out, ok ? "ok" : "write failed");

    recon::capture::PresentHook::Instance().Uninstall();
    return ok ? 0 : 6;
}
