// =============================================================================
//  demo_av1parse.cpp -- offline AV1 bitstream inspector (Step-1, no external deps).
//  Parses an .ivf/.obu file (or runs --selftest) and reports container, OBU
//  structure, resolution, and frame types using recon/codec/av1_bitstream.hpp.
//
//  This is the offline-verifiable half of the AV1 decode path.  Pixel decode of
//  real Zoom AV1 is done by the dav1d adapter (av1_dav1d_decoder.hpp) when the
//  project is built with -DRECON_WITH_CODECS=ON (fetches dav1d; needs meson+nasm).
// =============================================================================
#include <cstdio>
#include <cstdint>
#include <vector>
#include <string>
#include <fstream>
#include "recon/codec/av1_bitstream.hpp"
#if defined(RECON_WITH_DAV1D)
#include "recon/codec/av1_dav1d_decoder.hpp"
#endif

using namespace recon::codec::av1;

static SequenceHeader g_seq;

static void DumpObus(const uint8_t* p, size_t n, const char* tag) {
    std::vector<Obu> obus;
    if (!ParseObuStream(p, n, obus)) { printf("   [%s] not a low-overhead OBU stream (has_size=0?)\n", tag); return; }
    for (auto& o : obus) {
        printf("   [%s] OBU %-20s tid=%d sid=%d payload=%zuB\n",
               tag, ObuName(o.type), o.temporal_id, o.spatial_id, o.payload_len);
        if (o.type == ObuType::SequenceHeader) {
            g_seq = ParseSequenceHeader(p + o.payload_off, o.payload_len);
            if (g_seq.ok)
                printf("            -> seq_profile=%d  %ux%u  reduced_still=%d\n",
                       g_seq.seq_profile, g_seq.max_width, g_seq.max_height, g_seq.reduced_still_picture);
        } else if (o.type == ObuType::Frame || o.type == ObuType::FrameHeader) {
            FrameType ft = ClassifyFrame(p + o.payload_off, o.payload_len, g_seq);
            printf("            -> frame_type=%s\n", FrameTypeName(ft));
        }
    }
}

static int SelfTest() {
    printf("== AV1 parser self-test (hand-crafted spec bytes) ==\n");
    // Low-overhead OBU stream: TEMPORAL_DELIMITER + SEQUENCE_HEADER for 320x240,
    // seq_profile 0, reduced_still_picture=1 (bytes computed by hand per AV1 5.5.1).
    const uint8_t stream[] = {
        0x12, 0x00,                                     // TD OBU (type=2, has_size), size=0
        0x0A, 0x06, 0x18, 0x21, 0xE7, 0xFD, 0xE0, 0x02  // SEQ OBU (type=1), size=6, payload
    };
    std::vector<Obu> obus;
    bool ok = ParseObuStream(stream, sizeof(stream), obus);
    int fails = 0;
    auto check = [&](const char* what, bool cond){ printf("   %-42s %s\n", what, cond?"PASS":"FAIL"); if(!cond)++fails; };
    check("parse OBU stream", ok);
    check("OBU count == 2", obus.size() == 2);
    if (obus.size() == 2) {
        check("OBU[0] == TEMPORAL_DELIMITER", obus[0].type == ObuType::TemporalDelimiter);
        check("OBU[1] == SEQUENCE_HEADER",    obus[1].type == ObuType::SequenceHeader);
        SequenceHeader s = ParseSequenceHeader(stream + obus[1].payload_off, obus[1].payload_len);
        check("seq parsed ok",   s.ok);
        check("seq_profile == 0", s.seq_profile == 0);
        check("width == 320",     s.max_width == 320);
        check("height == 240",    s.max_height == 240);
    }
    // IVF header round-trip
    uint8_t ivf[32] = {0};
    ivf[0]='D';ivf[1]='K';ivf[2]='I';ivf[3]='F'; ivf[6]=32; ivf[8]='A';ivf[9]='V';ivf[10]='0';ivf[11]='1';
    ivf[12]=(320&0xFF); ivf[13]=(320>>8); ivf[14]=(240&0xFF); ivf[15]=(240>>8);
    IvfHeader h = ParseIvfHeader(ivf, sizeof(ivf));
    check("IVF DKIF/AV01 320x240", h.ok && std::string(h.fourcc)=="AV01" && h.width==320 && h.height==240);
    printf("   -> %d failure(s)\n", fails);
    return fails ? 1 : 0;
}

int main(int argc, char** argv) {
    if (argc < 2 || std::string(argv[1]) == "--selftest") return SelfTest();

    std::ifstream f(argv[1], std::ios::binary);
    if (!f) { printf("cannot open %s\n", argv[1]); return 2; }
    std::vector<uint8_t> buf((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    printf("== AV1 inspect: %s (%zu bytes) ==\n", argv[1], buf.size());

    IvfHeader h = ParseIvfHeader(buf.data(), buf.size());
    if (h.ok) {
        printf("   IVF container: %s %ux%u frames=%u\n", h.fourcc, h.width, h.height, h.frames);
        size_t off = 32; int fi = 0;
        while (off + 12 <= buf.size()) {
            uint32_t sz = rd32(&buf[off]); off += 12;                 // frame size + 8B timestamp
            if (off + sz > buf.size()) break;
            printf("   -- frame %d (%u bytes) --\n", fi++, sz);
            DumpObus(buf.data() + off, sz, "ivf");
            off += sz;
        }
    } else {
        DumpObus(buf.data(), buf.size(), "obu");   // raw low-overhead OBU stream
    }

#if defined(RECON_WITH_DAV1D)
    {
        printf("== dav1d decode (real AV1 pixel decode) ==\n");
        Dav1dDecoder dec;
        std::vector<uint8_t> nv12(64u * 1024 * 1024);
        int decoded = 0, fw = 0, fh = 0;
        auto feed = [&](const uint8_t* p, size_t n) {
            int r = dec.Decode(p, n, nv12.data(), nv12.size());
            if (r > 0) { if (!decoded) { fw = dec.width(); fh = dec.height(); } ++decoded; }
        };
        if (h.ok) {
            size_t off = 32;
            while (off + 12 <= buf.size()) { uint32_t sz = rd32(&buf[off]); off += 12;
                if (off + sz > buf.size()) break; feed(buf.data() + off, sz); off += sz; }
        } else { feed(buf.data(), buf.size()); }
        printf("   libdav1d decoded %d picture(s); first = %dx%d  -> %s\n",
               decoded, fw, fh, (decoded > 0 ? "PASS" : "FAIL"));
        return decoded > 0 ? 0 : 1;
    }
#endif
    return 0;
}
