// =============================================================================
//  demo_d3d9cap.cpp (Windows) -- validates the D3D9 surface LockRect readback
//  (the mechanism confirmed in nydus.dll: Nydus::SafeLockRect/SafeUnlockRect).
//  Uses a controlled render target (a solid color, no screen content) so it
//  exercises CreateOffscreenPlainSurface -> GetRenderTargetData -> LockRect ->
//  copy -> UnlockRect and writes the result to PNG.
//
//  (D3d9SurfaceReader::ReadFrontBuffer() does the same LockRect readback on the
//   real desktop front buffer; not used here to avoid capturing screen content.)
// =============================================================================
#include <windows.h>
#include <d3d9.h>
#include <wrl/client.h>
#include <cstdio>
#include "recon/capture/d3d9_surface_reader.hpp"
#include "recon/png_writer.hpp"

using Microsoft::WRL::ComPtr;

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IONBF, 0);

    recon::capture::D3d9SurfaceReader reader;
    if (!reader.Init()) { printf("Direct3DCreate9Ex / CreateDeviceEx failed\n"); return 1; }

    ComPtr<IDirect3DSurface9> rt;
    if (FAILED(reader.device()->CreateRenderTarget(256, 144, D3DFMT_A8R8G8B8,
                                                   D3DMULTISAMPLE_NONE, 0, FALSE,
                                                   rt.GetAddressOf(), nullptr))) {
        printf("CreateRenderTarget failed\n"); return 2;
    }
    reader.device()->ColorFill(rt.Get(), nullptr, D3DCOLOR_XRGB(40, 120, 220));

    int w, h, pitch;
    auto px = reader.ReadRenderTarget(rt.Get(), w, h, pitch);   // GetRenderTargetData + LockRect
    if (!px) { printf("D3D9 LockRect readback failed\n"); return 3; }

    const char* out = (argc > 1) ? argv[1] : "d3d9cap.png";
    bool ok = recon::write_png_bgra(out, px->data(), w, h, pitch, true);
    printf("D3D9 surface LockRect readback OK: %dx%d -> %s (%s)\n", w, h, out, ok ? "ok" : "write failed");
    return ok ? 0 : 4;
}
