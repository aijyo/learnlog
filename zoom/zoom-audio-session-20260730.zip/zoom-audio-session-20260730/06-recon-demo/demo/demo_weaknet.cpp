// =============================================================================
//  demo_weaknet.cpp -- exercises the portable clean-room reconstructions:
//    A) mcm    ITU-T G.107 MOS + bandwidth distribution + NW warning
//    B) zlt    SVC key-picture request dispatcher + validation
//    C) viper  Opus / AI-codec(121) / SNAC switching + SNAC->Opus recovery gate
//    D) asproxy "asp" control handshake + type-53 QoS network-info (per-channel bw_level)
//    E) zmesh  eCDN meeting-state machine + super-node
//  All logic here is driven through the reconstructed headers with small mocks.
// =============================================================================
#include <cstdio>
#include <string>
#include <algorithm>
#include "recon/weaknet_reference.hpp"
#include "recon/mcm_media_channel.hpp"
#include "recon/zlt_svc_encoder.hpp"
#include "recon/viper_audio_engine.hpp"
#include "recon/asproxy_share_qos.hpp"
#include "recon/zmesh_agent.hpp"
#include "recon/viperex_runtime.hpp"

using namespace recon;

// ---- zlt mock encoder backend ----------------------------------------------
struct MockZltBackend : zlt::ISvcEncoderBackend {
    int ct;
    explicit MockZltBackend(int c) : ct(c) {}
    int  ApplyConfig(const zlt::EncodeConfig& c) override {
        printf("      [zlt.be] ApplyConfig: %zu spatial layers @ %.0ffps\n", c.spatial.size(), c.input_frame_rate); return 0; }
    void ForceIdr(int s, int n) override        { printf("      [zlt.be] ForceIdr spatial=%d num=%d\n", s, n); }
    void RequestKeyPicture(int s, int t) override{ printf("      [zlt.be] RequestKeyPicture spatial=%d tid=%d\n", s, t); }
    void DuplicatePFrame(int s) override         { printf("      [zlt.be] DuplicateP spatial=%d\n", s); }
    void SkipNextFrame(int s) override           { printf("      [zlt.be] SkipNextFrame spatial=%d\n", s); }
    void SetBitrateTarget(uint32_t bps,int m) override { printf("      [zlt.be] SetBitrateTarget bps=%u mode=%d\n", bps, m); }
    int  codec_type() const override             { return ct; }
};
static const char* RS(zlt::ReqStatus s){ using S=zlt::ReqStatus; switch(s){
    case S::Ok:return "Ok"; case S::SpatialOutOfRange:return "SpatialOOR";
    case S::TemporalOutOfRange:return "TemporalOOR"; case S::Unsupported:return "Unsupported";
    case S::BadArgument:return "BadArg"; case S::NotInitialized:return "NotInit"; default:return "LayerOOR/?"; } }

// ---- viper mocks ------------------------------------------------------------
struct MockCodecEnum : viper::ICodecEnumerator {
    int Count() const override { return 2; }
    int IdAt(int i) const override { return i==0 ? 113 : 121; }
};
struct MockMainCodec : viper::IMainCodecQuery {
    int id = 113;
    bool GetMainSendCodec(int& o) override { o = id; return true; }
    void SetExtraEncodeEnabled(bool on) override { printf("      [viper.main] SetExtraEncodeEnabled(%d)\n", on); }
};
struct MockAcm : viper::IAudioCodingModule {
    bool Init() override { return true; }
    bool RegisterSendCodec(int id) override { printf("      [viper.acm] RegisterSendCodec(%d)\n", id); return true; }
};
struct MockRtp : viper::IRtpRtcpModule {
    bool Init() override { return true; }
    void SetSending(bool on) override { printf("      [viper.rtp] SetSending(%d)\n", on); }
};
static const char* ACE(viper::AiCodecError e){ using E=viper::AiCodecError; switch(e){
    case E::Ok:return "Ok"; case E::FailGetMainCodec:return "FailGetMainCodec";
    case E::CannotEnable:return "CannotEnable(main not 113/116)"; case E::AiCodecNotFound:return "AiCodecNotFound";
    default:return "err"; } }

// ---- asproxy mocks (corrected: XML "asp" control protocol + type-53 QoS) -----
static const char* StateName(asproxy::SessionState s){ using S=asproxy::SessionState; switch(s){
    case S::Idle:return "Idle"; case S::Negotiating:return "Negotiating";
    case S::Authenticating:return "Authenticating(3)"; case S::Connected:return "Connected(4)";
    default:return "?"; } }
struct MockSink : asproxy::IDispatchSink {
    void OnStateChanged(asproxy::SessionState s) override {
        printf("      [asproxy.sink] state -> %s\n", StateName(s)); }
    void OnWelcome(const asproxy::WelcomeInfo& w) override {
        printf("      [asproxy.sink] welcome: relay %s:%u bind='%s' asSsrc=%u aSsrc=%u\n",
               w.data_ip.c_str(), w.data_port, w.bind_token.c_str(), w.asdata_ssrc, w.adata_ssrc); }
    void OnQosNetworkInfo(const asproxy::QosNetworkInfoPdu& p) override {
        printf("      [asproxy.sink] QoS network-info PDU type=%u :\n", p.kPduType);
        for (uint8_t i = 0; i < p.channels.size(); ++i) {
            const auto& c = p.channels[i];
            if (!c.active) continue;
            const char* key = asproxy::BwLevelKey(asproxy::Channel(i));
            printf("          ch%u %-14s bw_level=%u\n", i, key ? key : "(unkeyed)", c.bw_level);
        }
    }
};
struct MockProxy : asproxy::IASProxy {
    asproxy::IDispatchSink* sink=nullptr;
    asproxy::SessionState st=asproxy::SessionState::Idle;
    bool share_audio=true;
    void set_state(asproxy::SessionState s){ st=s; if(sink) sink->OnStateChanged(s); }
    void SetDispatchSink(asproxy::IDispatchSink* s) override { sink=s; }
    int  OnControlMessage(const char* xml, size_t) override {
        printf("      [asproxy] dispatch cmd='%s'\n", xml);
        switch (asproxy::ParseAspCommand(xml)) {
            case asproxy::AspCommand::Authenticate:
            case asproxy::AspCommand::Reauthenticate: set_state(asproxy::SessionState::Authenticating); break;
            case asproxy::AspCommand::Welcome:        /* handled via ConnectDataChannel */ break;
            default: break;
        }
        return 0;
    }
    int  SendNegotiate(const asproxy::NegotiateInfo& n) override {
        printf("      [asproxy] negotiate: cpu=%d freqx100=%d asProfile=%u codec=%s shareAudio=%d client=%s\n",
               n.cpu_num, n.cpu_freq_x100, n.as_profile, n.audio_codec.c_str(), n.share_audio, n.client_ver.c_str());
        share_audio = n.share_audio; set_state(asproxy::SessionState::Negotiating); return 0;
    }
    int  Authenticate() override   { set_state(asproxy::SessionState::Authenticating); return 0; }
    int  Reauthenticate() override { set_state(asproxy::SessionState::Authenticating); return 0; }
    asproxy::SessionState state() const override { return st; }
    bool ConnectDataChannel(const asproxy::WelcomeInfo& w) override {
        printf("      [asproxy] open data channel -> %s:%u (mediaType=%u ver=%u alive=%ums timeout=%ums)\n",
               w.data_ip.c_str(), w.data_port, asproxy::DataChannelParams::kMediaType,
               asproxy::DataChannelParams::kSocketVersion, asproxy::DataChannelParams::kAliveTimeMs,
               asproxy::DataChannelParams::kConnectTimeoutMs);
        if (sink) sink->OnWelcome(w);
        set_state(asproxy::SessionState::Connected);
        return true;
    }
    void ReportQosNetworkInfo(const asproxy::QosNetworkInfoPdu& p) override { if(sink) sink->OnQosNetworkInfo(p); }
    bool ShareAudioEnabled() const override { return share_audio; }
};

int main() {
    // ---- A) mcm --------------------------------------------------------------
    printf("== A) mcm : ITU-T G.107 MOS vs network delay (base R=93.2) ==\n");
    for (uint32_t d : {0u,100u,300u,600u,1000u,2000u,3500u}) {
        int r; float mos = mcm::EstimateMos(93.2f, d, &r);
        printf("   delay=%5u ms   R=%5.1f   MOS=%.2f\n", d, r/10.0f, mos);
    }
    mcm::MediaChannelManager::Deps deps;
    deps.now_ms       = []{ return 100000u; };
    deps.baseRfactor  = [](const mcm::AudioQosMetrics& m){ return 93.2f - float(m.cur_packets_loss_rate)*0.5f; };
    deps.reportQos    = [](uint32_t ssrc, const mcm::AudioQosMetrics& m){
        printf("   [mcm.qos] ssrc=%u MOS=%.2f R=%d loss=%u jitter=%ums delay=%ums fec%%=%u\n",
               ssrc, m.cur_mos_score, m.cur_score, m.cur_packets_loss_rate, m.cur_jitter_ms,
               m.abs_net_delay_ms, m.cur_fec_packets_ratio); };
    deps.emitNwWarning= [](const std::string& s){ printf("   [mcm.nw] %s\n", s.c_str()); };
    mcm::MediaChannelManager mgr(deps);
    { mcm::StreamConfig a; a.ssrc=1; a.up_bw_level=mcm::BwLevel::L4; mgr.ApplyStreamConfig(a); }  // audio
    { mcm::StreamConfig v; v.ssrc=2; v.up_bw_level=mcm::BwLevel::L2; mgr.ApplyStreamConfig(v); }  // video
    printf("   -- bandwidth distribute (2 Mbps) --\n");
    for (auto& b : mgr.Distribute(2000000u))
        printf("   [mcm.bw] ssrc=%u level=%d -> %u bps\n", b.stream_id, int(b.level), b.assigned_bps);
    { mcm::AudioQosMetrics m; m.abs_net_delay_ms=350; m.cur_packets_loss_rate=6; m.cur_jitter_ms=40; m.cur_fec_packets_ratio=12;
      mgr.OnAudioStats(2, m, /*force*/true); }
    mgr.warning().Update(true,  {30,0}, 12345); printf("   [mcm.nw] %s\n", mgr.warning().FormatTelemetry().c_str());
    mgr.warning().Update(false, {30,0}, 12345); printf("   [mcm.nw] %s\n", mgr.warning().FormatTelemetry().c_str());

    // ---- B) zlt --------------------------------------------------------------
    printf("\n== B) zlt : SVC key-picture request dispatcher (codec_type=4, max 3x3) ==\n");
    MockZltBackend be(4);
    zlt::SvcEncoderControl ctl(&be);
    ctl.SetMaxLayers(4, 3, 3);
    { zlt::EncodeConfig cfg; cfg.input_frame_rate=30; cfg.actual_frame_rate=30; cfg.spatial.resize(2);
      cfg.spatial[0].width=640;  cfg.spatial[0].height=360;  cfg.spatial[0].bitrate=300000;  cfg.spatial[0].temporal_layer_num=2;
      cfg.spatial[1].width=1280; cfg.spatial[1].height=720;  cfg.spatial[1].bitrate=1200000; cfg.spatial[1].ltr=true; cfg.spatial[1].temporal_layer_num=3;
      ctl.SetEncodeConfig(cfg); }
    auto fire=[&](const char* n, zlt::RequestType t, zlt::RequestArgs a){ printf("   -> %-20s : %s\n", n, RS(ctl.Request(t,a))); };
    { zlt::RequestArgs a; a.spatial_index=0;                          fire("NewAttendee I-pic", zlt::RequestType::NewAttendeeIPic, a); }
    { zlt::RequestArgs a; a.spatial_index=1; a.temporal_id=1; a.last_received_pic_id=42; fire("KeyPicture(loss)", zlt::RequestType::KeyPicture, a); }
    { zlt::RequestArgs a; a.spatial_index=0; a.request_number=5;      fire("Idr", zlt::RequestType::Idr, a); }
    { zlt::RequestArgs a; a.spatial_index=1;                          fire("DuplicateP", zlt::RequestType::DuplicateP, a); }
    { zlt::RequestArgs a; a.spatial_index=0;                          fire("FrameSkip", zlt::RequestType::FrameSkip, a); }
    { zlt::RequestArgs a; a.spatial_index=1;                          fire("SubscribeChange", zlt::RequestType::SubscribeChange, a); }
    { zlt::RequestArgs a; a.bitrate_target=2;                         fire("BitrateTarget", zlt::RequestType::BitrateTarget, a); }
    { zlt::RequestArgs a; a.spatial_index=9;                          fire("KeyPicture(OOB)", zlt::RequestType::KeyPicture, a); }

    // ---- C) viper ------------------------------------------------------------
    printf("\n== C) viper : Opus / AI-codec(121) / SNAC switching ==\n");
    MockCodecEnum ce; MockMainCodec mc;
    viper::EngineDeps vd;
    vd.codecs=&ce; vd.mainCodec=&mc; vd.neteq=nullptr; vd.snac=nullptr;
    vd.makeAcm=[]{ return static_cast<viper::IAudioCodingModule*>(new MockAcm()); };
    vd.makeRtp=[]{ return static_cast<viper::IRtpRtcpModule*>(new MockRtp()); };
    vd.publish=[](int ev, uint32_t p){ printf("      [viper.bus] publish event=%d params=0x%X\n", ev, p); };
    vd.log=[](const std::string& s){ printf("      [viper.log] %s\n", s.c_str()); };
    viper::AudioWeakNetEngine eng(vd);
    printf("   EnableExtraAiCodec (main=113): %s\n", ACE(eng.EnableExtraAiCodec(true)));
    mc.id = 100;
    printf("   EnableExtraAiCodec (main=100): %s\n", ACE(eng.EnableExtraAiCodec(true)));
    eng.OnExtraAiCodecControlEvent(viper::ctrl::kCtrlEnc, 0x123); printf("   ai_encoding=%d\n", eng.ai_encoding());
    eng.OnExtraAiCodecControlEvent(0, 0x124);                     printf("   ai_encoding=%d\n", eng.ai_encoding());
    eng.EnableExtraSnacDecoding(true, 0x4);
    printf("   snac_status=%d  snac_over_tcp=%d\n", int(eng.snac_status()), eng.snac_over_tcp());
    { weaknet::OpusPacketSpan span; span.min_seq=1000; span.max_seq=1100; span.min_ts=0; span.max_ts=48000u*3; span.packet_count=90;
      printf("   AcceptSnacTcpToOpus(tierIII, 101 expected/90 recv, 3s): %d\n",
             eng.AcceptSnacTcpToOpus(span, 2500, weaknet::RecoveryTier::III)); }
    printf("   SetFECStatus(true) -> %d  (RED unsupported by design)\n", eng.SetFECStatus(true));

    // ---- D) asproxy : "asp" control protocol + type-53 QoS network-info -------
    printf("\n== D) asproxy : app-share \"asp\" handshake + type-53 QoS network-info ==\n");
    MockProxy px; MockSink sk; px.SetDispatchSink(&sk);
    // 1) negotiate (advertise device info + capabilities), 0x180006D84
    { asproxy::NegotiateInfo n; n.cpu_num=8; n.cpu_freq_x100=320; n.as_profile=3;
      n.audio_codec="opus"; n.share_audio=true; n.client_ver="7.1.0.41345"; n.ext_ver=1;
      px.SendNegotiate(n); }
    // 2) authenticate  -> state 3
    px.Authenticate();
    // 3) server "welcome": relay endpoint + bind token -> open data channel -> state 4
    { asproxy::WelcomeInfo w; w.data_ip="10.20.30.40"; w.data_port=8801;
      w.bind_token="bind-xyz"; w.asdata_ssrc=0xA5; w.adata_ssrc=0xA6; w.as_profile=3;
      px.ConnectDataChannel(w); }
    printf("   session state = %s, shareAudio=%d\n", StateName(px.state()), px.ShareAudioEnabled());
    // 4) uplink QoS: type-53 network-info PDU with per-channel bw_level (audio/ds/video)
    { asproxy::QosNetworkInfoPdu p;
      p.channels[(int)asproxy::Channel::Audio]       = { true, 4, 0, 0, 0 };
      p.channels[(int)asproxy::Channel::DesktopShare]= { true, 2, 0, 0, 0 };  // congested share
      p.channels[(int)asproxy::Channel::Video]       = { true, 3, 0, 0, 0 };
      px.ReportQosNetworkInfo(p); }

    // ---- E) zmesh ------------------------------------------------------------
    printf("\n== E) zMeshNetAgent : eCDN meeting-state machine ==\n");
    zmesh::MeshCallbacks cb;
    cb.trace          = [](const std::string& s){ printf("   %s\n", s.c_str()); };
    cb.onMeetingState = [](zmesh::MeshMeetingState s){ printf("   [mesh] entered state %d\n", int(s)); };
    uint64_t clock = 1000; auto now = [&]{ return clock; };
    zmesh::MeshMeetingStateMachine sm(cb);
    sm.Transition(zmesh::MeshMeetingState::Init,       now); clock += 5000;
    sm.Transition(zmesh::MeshMeetingState::Connecting, now); clock += 2000;
    sm.Transition(zmesh::MeshMeetingState::Active,     now); clock += 60000;
    sm.Transition(zmesh::MeshMeetingState::Erasing,    now);
    { zmesh::SuperNodeInfo sn; sn.node_id="peerA"; sn.address="10.0.0.5:8801"; sn.max_load=20; sn.cur_load=3;
      printf("   [mesh] super-node %s @ %s load %u/%u\n", sn.node_id.c_str(), sn.address.c_str(), sn.cur_load, sn.max_load); }

    // ---- F) decision chain: mcm QoS -> (server policy) -> viper control word --
    printf("\n== F) decision chain : mcm QoS -> (server-side policy) -> viper ctrl-word 0x4 ==\n");
    printf("   (policy is illustrative; real decision is server-side. viper only executes.)\n");
    struct Scn { const char* name; viper::AiSwitchInputs in; };
    Scn scns[] = {
        {"good     ", {4.3f, 0.005f, 15,  30, 5, 4, true}},
        {"mild-loss", {4.0f, 0.040f, 25,  60, 4, 3, true}},
        {"bad      ", {3.3f, 0.140f, 60, 140, 2, 2, true}},
        {"severe   ", {2.5f, 0.350f, 180,320, 1, 1, true}},
    };
    for (auto& s : scns) {
        viper::CodecChoice choice = viper::ReferenceSwitchPolicy(s.in);
        printf("   [%s] MOS=%.1f loss=%2.0f%% net=%d bw=%d  =>  %s\n",
               s.name, s.in.mos, s.in.loss_rate*100.0f, s.in.net_score, s.in.bw_level, viper::ToString(choice));
        switch (choice) {
            case viper::CodecChoice::AiCodec:     eng.OnExtraAiCodecControlEvent(viper::ctrl::kCtrlEnc, 0x200); break;
            case viper::CodecChoice::SnacOverTcp: eng.EnableExtraSnacDecoding(true, 0x4); break;
            default:                              eng.OnExtraAiCodecControlEvent(0, 0); break;
        }
    }

    // ---- G) viperex : Companion-Mic ML runtime (control surface recovered) ---
    printf("\n== G) viperex : OpenVINO Companion-Mic engine (weights opaque; control recovered) ==\n");
    printf("   version=%s  models(PE 'BIN' res): %ls / %ls  (OpenVINO IR, XOR 0x%02X)\n",
           viperex::kVersion,
           viperex::ModelResourceCodec::kEmbeddingModel, viperex::ModelResourceCodec::kOsdModel,
           viperex::ModelResourceCodec::kXorKey);
    {
        // round-trip the REAL embedded-model container format (8B LE xml-len + xml|bin, ^0xA7)
        std::vector<uint8_t> xml = { '<','n','e','t','/','>' };            // stand-in IR .xml
        std::vector<uint8_t> bin = { 0xDE, 0xAD, 0xBE, 0xEF, 0x00, 0x11 }; // stand-in IR .bin
        auto blob = viperex::ModelResourceCodec::Encode(xml, bin);
        std::vector<uint8_t> dx, db;
        bool ok = viperex::ModelResourceCodec::Decode(blob.data(), blob.size(), dx, db);
        printf("   model-container codec: blob=%zuB decode ok=%d xml=%zuB bin=%zuB roundtrip=%d\n",
               blob.size(), ok, dx.size(), db.size(), (ok && dx == xml && db == bin));
    }
    printf("   schedule: WINMM timeSetEvent(periodic 0x21) ; worker _beginthreadex 1MB stack, prio map:\n");
    for (int p = 1; p <= 5; ++p)
        printf("             prio %d -> Win32 %d\n", p, viperex::ToWin32ThreadPriority(viperex::WorkerPriority(p)));
    printf("   pipeline: %d Hz mono ; chunk %d smp (%.1fs) -> CAM++ window %d smp (3s) ; active if picknet_sm>%.0f\n",
           viperex::PipelineConstants::kSampleRate, viperex::PipelineConstants::kChunkSamples,
           viperex::PipelineConstants::kChunkSeconds, viperex::PipelineConstants::kCampWindow,
           viperex::PipelineConstants::kActiveThresh);

    printf("\n(demo complete)\n");
    return 0;
}
