# Zoom 音频栈 —— 会话产出备份(2026-07-30)· v2

本包是一次会话产出的**代码 + 文档**,外加与之直接对应的可运行复刻实现。
**不含任何 Zoom 二进制、不含任何提取的模型权重。**

> **v2 修正**:v1 的 `04-code/cpp/` 只放了算法核心三个文件,**编不出来** ——
> 缺 `main.cpp`(CLI 入口)、实时路径、C API、`CMakeLists.txt`、`build.ps1`。
> 本版补齐,并加入 `06-recon-demo/`。

---

## ⚠ 先看这个:可对外 / 内部,分开放了

| 目录 | 能不能外发 | 为什么 |
|---|---|---|
| `01-shareable/` | **可以** | 已逐词清洗,不含模块名、函数地址、方法论痕迹 |
| `02-internal-docs/` `03-notes/` `05-scripts/` `06-recon-demo/` | **不要** | 含逆向过程、地址、类名、方法论 |
| `04-code/` | 看情况 | 架构复刻代码本身可给同事,但注释里写了它是怎么读出来的 |

**别把 `02`–`06` 当成 `01` 的补充材料一起发。** 这个划分就是为此存在的。

---

## 目录

```
01-shareable/        2 份可对外文档
02-internal-docs/    7 份内部文档 + 2 份跨项目记录(xproj-*)
03-notes/            NOTES.md(逐条实证)+ CONTEXT.md(领域语言)
04-code/
  zoom_nets/         七个模型的 PyTorch 重建 + recovered.py(事实库)
  train.py nn_a1.py README.md
  cpp/               ★ 完整可构建的自研抑制器(CMake + CLI + 实时 + C API)
05-scripts/
  viperex/           分析脚本(纯 Python 读 PE / IDA 驱动)
  eval/              评估脚本
06-recon-demo/       ★ clean-room 复刻实现 + 可跑 demo(前几次会话,另一个项目)
```

### `04-code/cpp/` —— 自研经典抑制器,这是能跑的那个

| 文件 | 作用 |
|---|---|
| `ns_core.hpp` | 算法核心(STFT / 特征 / 判决 / 增益 / HMM) |
| `nsx_config.hpp` | 参数与机制表 |
| `main.cpp` | **CLI 入口(nsx.exe)**,含 `--selftest` |
| `live.cpp` `nsx_live*.hpp` | 实时路径(miniaudio 采集/回放) |
| `nsx_capi.cpp/.h` | C API,给外部集成用 |
| `lab.cpp` | 实验入口,本轮加的档位/特征/自适应地板开关都在这 |
| `eval.hpp` `metrics.hpp` `wav.hpp` | 评估、指标(STOI/ESTOI 等)、wav I/O |
| `CMakeLists.txt` `build.ps1` | 构建;vcpkg `x64-windows-static` + `/MT`,目标是只依赖系统 DLL |

### `06-recon-demo/` —— 与 §10–§14 直接对应的可运行复刻

**这部分不是本次会话产出的**,来自同一课题的前几次会话(另一个项目目录)。
放进来是因为它是文档里那些环节的**可跑实现**:

| 文件 | 对应文档章节 |
|---|---|
| `recon/algo/jitter_buffer.hpp` | §12 抖动缓冲(RFC-3550 同族参考实现) |
| `recon/algo/rs_fec.hpp` `algo/fec_group.hpp` | §10 抗丢包(Reed-Solomon GF(256) / 分组) |
| `recon/algo/rate_controller.hpp` | §10/§15 码率与冗余自适应 |
| `recon/viper_audio_engine.hpp` | 音频引擎骨架 |
| `recon/viperex_runtime.hpp` | 神经插件运行时 |
| `recon/weaknet_reference.hpp` | 弱网综合参考 |
| `recon/codec/opus_decoder.hpp` | Opus 解码接入 |
| `demo/demo_weaknet.cpp` `demo_algo.cpp` `demo_opus.cpp` … | 可跑 demo |

---

## 这次会话的主要结果

### 七个模型的可信度分级(核心产物)

| 代号 | 模型 | 参数 | 等级 | 本轮变化 |
|---|---|---|---|---|
| A | 降噪掩码网 | 203 K | 中高 | ↑ 运算语义:量化矩阵乘 + Q31 重量化 + **共享查表激活** |
| B | SNAC 神经编解码 | 2.39 M | 高 | ↑ 描述符表**尺寸字段**解出 67/71 层;**码流参数全读出** |
| C | SED 事件检测 | 13 K | 最高 | — (唯一训到真实指标:留出集 98.4%) |
| D | CAM++ 声纹 | **902 K** | 最高 | ↑ 增长率三条独立路径 + init **14 个 push 计数全中**;FCM stride 位置读出 |
| E | OSD 重叠语音 | **227 K** | 最高 | ↑ **连头都读出**(4×128→2,段级) |
| F | 神经 AEC | 472 K | 中 | ↑ **U-Net,5 条 LIFO 跳连**,层数 19 两路对上 |
| G | 个性化 VAD | **0** | 已定案 | **它没有自己的网络** —— CamppCalculator 之上的决策层 |

### 关键技术发现

- **STFT 前端是非对称低延迟窗**:`sqrt(Hann(705))` 上升半段 352 ++ `sqrt(Hann(321))` 下降半段 160 = 512。
  **前瞻 10 ms 而非对称窗的 16 ms**。可跑验证 `05-scripts/viperex/verify_window.py`:
  `分析窗 × 合成窗 ≡ Hann(321)`,误差 **5.55e-17**
- **降噪网的激活是查表不是公式**,八个 kernel 共享一张表
- **降噪网有 uint8 与 int16 两个量化变体**(同一算子,只换输出级)⇒ CPU 自适应降级
- **全二进制 7 张 ISA 调度表**,`lea func`+`mov [rip+slot]` 配对扫描一次找出;
  三个安装器被反编译器误标为 CRT 函数
- **SNAC 码流**:10 bit/码字 × 2 码字 = **20 bit/帧 = 1 kbps**(线上 2 kbps,每帧重复一次)
- **抖动缓冲是标准 WebRTC NetEQ**,只经 `SetNetEQPlayoutMode` / `GetJitterStatistics` 接入
- **抗丢包决策在服务器**,客户端只计量上报;冗余能力来自定制 Opus 分支
- **CAM++ 帧数是 298 不是 299**,由此反推帧长 480(30 ms)而非 320

---

## 怎么跑

```bash
# PyTorch 侧
cd 04-code && python train.py info      # 七个模型:参数量 / 前向输出 / 训练需要什么数据
python train.py sed                     # 唯一现有数据能训的
python ../05-scripts/viperex/verify_window.py    # STFT 窗对代数校验,断言式

# C++ 侧(自研抑制器)
cd 04-code/cpp && ./build.ps1           # vcpkg x64-windows-static + /MT
./nsx.exe --selftest                    # 自检
```

`05-scripts/viperex/` 分两类:**纯 Python 直读 PE**(`find_installers.py`、`snac_consts.py`、
`fcm_geom.py` 等,不需要 IDA)与 **IDA 驱动**(`ida_*.py`,需 `idat64.exe` + 已分析 `.i64`)。
**脚本里的二进制路径是硬编码的,换机器要改。**

---

## 明确排除的

| 项 | 原因 |
|---|---|
| `model_*.pt`(4 个,约 13 MB) | 权重是数据不是代码,且大文件不入包。SED 那个是我们自训的,要时重训 |
| Zoom 的任何二进制 / `.i64` | 不再分发 |
| **任何提取的 Zoom 模型权重** | **纪律红线**:架构可复刻,权重不提取、不再分发 |
| `voice/denoise/ui/`(C# WPF) | 源码不在树里(仅构建残留),无可打包内容 |
| `samples/` `lab_out/` `out/` `build/` | 测试音频与产物 |

---

## 诚实的未完成项

1. **降噪网的逐槽宽度** —— 运算语义读出了,哪一行表对应哪个槽没读
2. **AEC 的逐层宽度** —— 拓扑全读出,宽度在构造链里
3. **3 张未归属的调度表**(35 / 19 / 13 槽)
4. **§14 混音渲染** —— wiki 标 `[推断]`,全文唯一一个,**没有任何对应确认**
5. **滤波器组弯折** —— 80 带读出,mel 与否没读
6. **自研抑制器还没用上非对称窗** —— 仍是对称 sqrt-Hann + hop 256,
   本轮读出的「用窗形买 6 ms」一点没落地。这是唯一「读出来了也真能落地」的一项

### 三条值得记的教训

- **派生量继承了假设的不确定性,却继承不到假设的标记。**
  本轮两次:「40 bit/帧」= 自选码本 × 自选级数;「299 帧」= 自选帧长算出来的,
  **而且进了断言** —— 错的断言比没有断言更糟,它给人「已验证」的错觉。
- **把新发现当成对旧发现的否证。** uint8 vs int16、512 vs 792 都是**两个都对**,
  只是来自不同变体 / 不同 artifact。判据:**冲突的两个读法各自来自哪个地址?**
- **动手前先查跨项目的已有记录。** 本轮从零重推了一条早已记录在
  `02-internal-docs/xproj-TECHNICAL_DETAILS.md` 里的管线 —— 那两份 `xproj-*` 就是为此放进来的。
