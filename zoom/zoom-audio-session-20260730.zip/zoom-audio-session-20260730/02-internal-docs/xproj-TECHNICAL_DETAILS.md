# Zoom Media Stack — Technical Details (reverse-engineered)

Consolidated, subsystem-organized technical reference for Zoom Workplace's media stack
(`%APPDATA%\Zoom\bin`), recovered by static reverse engineering. This is the single deep-dive
that pulls together every recovered constant / formula / PDU layout / state machine / function
anchor. For the analysis narrative see `zoom_weaknet_capture_analysis.html`; for the codec
reconstruction plan see `CODEC_RECONSTRUCTION_PLAN.md`; runnable clean-room code is under `recon/`.

## Method & evidence convention

- Tooling: portable **IDA Pro 7.5** headless (`idat64 -A`) + **Hex-Rays**, IDAPython3; RTTI/vftable
  walking (`ida_rtti_vtable.py`), EA-range dumps (`ida_range.py`), string/import-xref (`ida_decomp.py`).
- Every claim carries an **evidence tag**:
  - `[body]` — read from the decompiled function body (strongest).
  - `[str]` — anchored on a literal string / log / source-path in the binary.
  - `[rtti]` — a C++ type exists (RTTI/vftable) but its member bodies were **not** decompiled.
  - `[imp]` — inferred from imported Win32/CRT APIs.
- Addresses are the module's default image base (`0x180000000` for DLLs; `0x140000000` for exes).
- **IP note:** everything below is *facts recovered by analysis* + *original clean-room reimplementations*
  of public/standard techniques. No Zoom proprietary source is reproduced. Neural model **weights**
  are not recoverable and are Zoom IP.

## Fidelity tiers (how "1:1" each item is)

- **T1** — mechanism verified from bodies **and** reimplemented + run (same behavior).
- **T2** — mechanism/protocol/constants verified from bodies, modeled as interface/skeleton (needs
  server/peer/OS/HW to run end-to-end).
- **T3** — not reconstructable (trained weights, or a full codec kernel / byte-exact encoder).

---

# 1. Module map (media-relevant)

| Module | Role | Key symbols / evidence |
|---|---|---|
| `viper.dll` | Audio engine (Opus/AI-codec/SNAC switching, NetEQ, FEC/PLC) | `[body]` `sub_1800CE540`, `sub_1800594C0`, `sub_1800D1BE0` |
| `viperex.dll` | "Companion Mic" ML feature engine (OpenVINO: CAM++/Picknet-OSD/lipsync) | `[body]` `viperex_init`, `[str]` `openvino_c.dll`, CAM++ |
| `zlt.dll` | Video SVC encode control + keyframe dispatcher + RAISR/denoise | `[body]` `sub_18005A690`, `sub_180008370` |
| `zbt.dll` | AV1 codec (proprietary; screen-content core) | `[body]` `Av1EncInterfaceCreate`, `ns_av1::zbtCScEncoderCore` |
| `mcm.dll` | Session control / QoS coordination (G.107 MOS, bandwidth distribution) | `[body]` `sub_1801642D0`, `[str]` `app_uplink_net_score_t` |
| `nydus.dll` | Application-share media engine (capture readback, GPU render, RS-FEC) | `[body]` `sub_1801D0F88`, `sub_180005C44` |
| `asproxy.dll` | Application-share proxy ("asp" control protocol + data channel + QoS) | `[body]` `sub_1800057E8`, `sub_180013B98` |
| `tp.dll` | Secure transport (ssb::socket_ctx_t: TLS, pinning, keepalive) | `[body]` socket_ctx_t accessors |
| `zMeshNetAgent.dll` | eCDN mesh / super-node | `[str]` `ECDNSwitchSuperNode` |
| `Cpt*` (Host/Control/Service/Share/UwpCapture) | Screen/app capture family | `[body]`/`[str]` per §2 |

---

# 2. Capture (Cpt* family + nydus readback)

There are **two distinct capture families** — do not conflate them.

## 2.1 Process/IPC model
`CptHost.exe` (capture host) + `CptControl.exe` + `CptService.exe` + `CptShare.dll` (injected) +
`CptUwpCapture.dll` (WGC). Host orchestrates backend selection and owns the shared surface.

## 2.2 App/video capture — nydus AS engine (the PRIMARY path) `[body]`
Hooks the *target application's* Direct3D and reads its surface.

- **D3D11 apps:** hook `IDXGISwapChain::Present` (nydus `Nydus::SafePresent`, `sub_180164E84`,
  `draw_d3d11.cpp:90`; swap-chain create wrapper `Nydus::SafeCreateSwapChain` `sub_18016503C`),
  copy the back-buffer into a **keyed-mutex shared D3D11 texture** (`CD3d11SharedHandleHelper`), the
  host `OpenSharedResource`s it. Reconstructed: `recon/capture/{present_hook,shared_surface}.hpp`
  (in-process demo verified 320×240).
- **D3D9 apps:** `IDirect3DSurface9::LockRect` readback:
  - readback driver `sub_1801D0F88` `[body]`: `SafeLockRect` → **row-copy by `Pitch`** (`sub_1800B0F30`)
    → `SafeUnlockRect` → push to sink (`sub_1801CF53C`).
  - `Nydus::SafeLockRect` = `sub_1801CF340` (vtbl **+152** = LockRect, `vasimulator.cpp:117`) /
    `sub_180179A88` (`draw_d3d9.cpp:125`); `Nydus::SafeUnlockRect` = `sub_1801CF3D8` /
    `sub_180179B2C` (vtbl **+160**). Four sibling callers (`sub_18017B1CC/2B0/370`, `sub_18017C420`)
    all memcpy `rows × bytes` by the locked `Pitch`; one passes lock flags `0x2000`.
  - adapters enumerated via `Nydus::SafeDirect3DCreate9` (`sub_1800A4B9C`, `systeminfo.cpp:538`;
    enumerator `sub_1800A4C34`, formats `"%u.%u.%u.%u"`).
  - Reconstructed: `recon/capture/d3d9_surface_reader.hpp` (verified 256×144).
- nydus config loader `sub_18004296C` `[str]`: `"video capture method"` (`tj`/`ms`/`ds`/`mf`),
  format white/black lists, `"mipi hdmi share keyword pair"`, `forcenydusstd*` camera presets.
- entry: `GetAPISet` (`sub_180007BC0`, `Nydus::CContent`/`Veneer::CVeneer` vtables),
  `GetMethod` (`sub_180007CB0`: `CreateSettingsObject`/`DestroySettingsObject`).

## 2.3 WGC path — CptUwpCapture.dll `[body]`
Windows.Graphics.Capture: `GraphicsCaptureItem` / `Direct3D11CaptureFramePool` /
`GraphicsCaptureSession`, `CreateDirect3D11DeviceFromDXGIDevice`; device created HW → falls back to
WARP; BGRA frame pool; `IsCursorCaptureEnabled` for cursor control.

**Frame path (body-verified)**: `cpt_uwp_capture::capture_item_imp` ctor `sub_180007320` builds a **ring
buffer + critical section** and registers a `TypedEventHandler<Direct3D11CaptureFramePool, IInspectable>`
(**FrameArrived**, gated by `UniversalApiContract v10`); frames enqueue on arrival. `CptUwp_Item_GetNextFrame`
→ `sub_180007238` **dequeues under the CS** (per-pixel CopyResource in `capture_frame_imp`). I.e.
**event-driven ring-buffer** acquisition. (`recon/wgc_capturer.hpp`.)

## 2.4 Magnifier screen-exclusion — CptHost.exe `[body]`
Capture the screen while *hiding* chosen windows (sharer's own toolbar). **CORRECTION: there are TWO
parallel capture branches**, selected by `sub_140037DD8(ctx, useDx9)`'s 2nd arg — the DX9 branch exists
**precisely to bypass `MagSetImageScalingCallback`, which crashes on some machines** (same purpose as the
external "read the WC_MAGNIFIER internal D3D9 surface" technique). An earlier draft called this
"callback-only / not a D3D read" — that was wrong.

- **Common**: `sub_1400378E8` creates a layered "mag host" top-level window + a `WC_MAGNIFIER` child
  (class "Magnifier", title "cpt mag control window"); `MagSetWindowFilterList(MW_FILTERMODE_EXCLUDE)`
  hides windows; `SetWindowLongPtrW(hMag, GWLP_USERDATA, ctx)`.
- **Path A · callback** (`useDx9==0`): register `MagSetImageScalingCallback(sub_140038040)`; the callback
  recovers the instance via `GetAncestor(GA_ROOT)`+`GWLP_USERDATA` then `memcpy`s the OS-filtered frame
  (`sub_140037218`, stride-copy into ctx+128). **This is the path that faults.**
- **Path B · DX9 direct surface read** (`useDx9!=0`): `sub_140062ACC` creates a **private D3D9Ex device on
  the mag window** via `Direct3DCreate9Ex` + `CreateDeviceEx` (vtbl **+160**), stored at `ctx+208`; each
  frame `SendMessageW(hMagHost, 0x500, rect)` (`sub_1400370D8`) drives the mag window-proc to **read the
  D3D9 surface directly** — no callback.
- **Readback primitive = same family as nydus**: `GetRenderTargetData → CreateOffscreenPlainSurface(
  D3DPOOL_SYSTEMMEM) → LockRect → copy by Pitch` (see §2.2; nydus `sub_1801D0F88` / `Nydus::SafeLockRect` /
  `SafeGetRenderTargetData`). x64 vtbl offsets ≈ 2× the x86 doc values (GetRenderTargetData +256 /
  GetFrontBufferData +264 / CreateOffscreenPlainSurface +288).
- Reconstructed: `recon/capture/magnifier_capturer.hpp` (callback path SEH-guarded + fallback).

## 2.5 PrintWindow fallback + transparent-edge auto-crop `[body]`
Per-window `PrintWindow` (`sub_180002C60`), bounds `4132/-15360`, transparent-edge crop (≤100/18 px),
retry ×20. (`recon/printwindow_capturer.hpp`.)

## 2.6 CptShare.dll — remote-control input + clipboard (`[body]`; CORRECTION, not "capture injection")
**Correction:** an earlier draft said CptShare "injects the capture DLL into the target via
SetWindowsHookEx" — reading the body proves that wrong. CptShare is the screen-share **remote-control
input + shared clipboard**, not injection. Capture backends (WGC/DXGI/Magnifier/PrintWindow/Present-hook)
all run **in-process in CptHost**, not injected into 3rd-party processes.

`sub_180028620` is a command handler dispatching on message codes 1124–1131:
- **1125/1126**: install/remove `SetWindowsHookExW(13 = WH_KEYBOARD_LL, sub_1800284F0, hCptShare, 0)` —
  global low-level keyboard hook (stored @+24).
- **1127/1128**: install/remove `SetWindowsHookExW(14 = WH_MOUSE_LL, fn, hCptShare, 0)` — global
  low-level mouse hook (@+32).
- **1129/1130**: clipboard monitor — modern (build ≥60) `AddClipboardFormatListener` /
  `RemoveClipboardFormatListener` (via GetProcAddress); legacy `SetClipboardViewer` / `ChangeClipboardChain`.
  Version-gated by `sub_1800374D4`.
- **1124**: DestroyWindow + PostQuitMessage; **1131**: data handler `sub_1800288E0`.

These are **global hooks (no injection required)** for input relay / remote control + clipboard sync.

**Fidelity:** app-capture (Present-hook + shared surface / D3D9 LockRect) = **T1** (verified + runnable
demos); Magnifier/DXGI/GDI fallbacks = **T1** mechanism, SEH-guarded.

---

# 3. Codecs

## 3.1 AV1 — zbt.dll `[body]`
- Exports: `Av1EncInterfaceCreate` (`0x18009C920`), `Av1DecInterfaceCreate` (`0x18009C680`),
  `Av1EncInterfaceDestroy` (`0x18009C7F0`), `Av1{Enc,Dec}SpecialFeature` (`0x18009CA80`/`0x18009C820`),
  `Av1CreateWinHwDecSpecificCodec` (`0x18009CD10` → `zltCWinHwDecSpecificCodecAV1`).
- **Screen-content core selected by `(mode & 0xF) == 2`** → `ns_av1::zbtCScEncoderCore` /
  `zbtCScDecoderCore` (else the normal cores). Enc object ≈`0x488F0`..`0x48900` bytes.
- `SpecialFeature` is an **integer feature-id switch** (not a bitmask): enc base `0x850001`
  (id+2 → `zbtCObuHdrWriter` packetizer), dec base `0x880001` (id+1 → `zbtCObuHdrParser`); sub-objects
  wrap `ns_base::zltCPacketizedUnit` / `zbtCOpenBsUnitsHeader`.
- Full SW **OBU parser**: seq header (`sub_1801CFA10`), frame header (`sub_1801D0AA0`), tile group,
  metadata incl. **ITU-T T.35** + HDR (CLL/mastering-display); AV1 `set_frame_refs` sign-bias over 8
  ref slots; multithreaded tile decode (SRW locks + condition variables). Errors funneled through
  `sub_18009C520`; diagnostics `"Error parsing sequence/frame header / OBU data"`,
  `"Overrun in OBU bit buffer"`, `"Malformed ITU-T T.35 metadata message format"`.
- **Fingerprint:** binary string scan → **zero** `AOMedia`/`aom`/`SVT`/`dav1d`/`libaom` hits ⇒ zbt is a
  **Zoom-proprietary** AV1 codec (symbols stripped, no OSS attribution).
- Reconstruction: `recon/zbt_av1_codec.hpp` (interfaces) + `recon/codec/av1_bitstream.hpp` (runnable
  OBU/seq-header parser) + `recon/codec/av1_dav1d_decoder.hpp` (**dav1d decode, T1: decoded a real
  800×800 keyframe**).

## 3.2 Opus — viper.dll `[str]`/`[body]`
- Build string `1.3.1-fixed-extrafec-maxlbrr-multifec-dred`; fingerprint `opus`×28 / `1.3.1`×4 /
  `SILK`×3, no `libopus`/`Xiph` attribution ⇒ Opus-1.3.1-derived.
- Codec ids: main `113`/`114`/`116`, AI-codec `121` (see §4). `[CODEC] mode =` reconfig
  (`sub_180074920`, mode 9/10 → param table id 113/114).
- Reconstruction: decode interop via `recon/codec/opus_decoder.hpp` (**libopus 1.5.2, T1: decoded a
  real Opus packet + PLC**).

## 3.3 Neural audio codec (SNAC / AI-codec 121) `[str]`/`[rtti]`
`webrtc::ISnacEncoder/ISnacDecoder`, `SnacInferenceEncoderAVX` (AVX inference), `extra_aicodec_event_t`.
**T3** — trained weights, not recoverable.

## 3.4 Royalty / licensing (for decode reconstruction)
AV1 = royalty-free (AOMedia); Opus = royalty-free (IETF/Xiph). Reference libs are permissive:
dav1d (BSD-2), libaom (BSD-2 + AOM patent), libopus (BSD-3). No H.264/HEVC patent-pool exposure.
See `CODEC_RECONSTRUCTION_PLAN.md`.

---

# 4. Weak-network — audio (viper.dll)

## 4.1 AI-codec (121) enable gate `[body]` `sub_1800CE540(engine, enable, errSink)`
AI-codec 121 does not replace the main codec — it **overlays a parallel ACM + RtpRtcp pair**
(`engine+47504` AudioCodingModule / `engine+47496` RtpRtcpModule) on the main send path. Enable flow
(verified; each guard → fixed error code):

| step | logic | fail code |
|---|---|---|
| get main SendCodec | main codec vtbl+64 → `v52[0]` | −301 "failed to get main SendCodec" |
| **gate** | **`v52[0]==113 ‖ ==116`** (only these two main codecs may overlay) | −302 "can not enable aicodec, main SendCodec:…" |
| find 121 | `sub_1800EC690` count + `sub_1800EC310(i,&id)` until `id==121` | −303 enum / −304 "failed to find aicodec(121)" |
| build ACM | key `(rate<<16)|(ch==−1?99:ch)` (rate=+128, ch=+132); `sub_1800EC430(key)`+vtbl init; register `sub_1800CF050(…,payload 14,…)` | −305 create / −306 init |
| build RtpRtcp | `sub_180212330(key,1)`; vtbl+240 init, +720, two payload maps (vtbl+312 main/RED, +320) | −307 create / −308 init |
| enable | RtpRtcp vtbl+400(1) | — |

**Disable path** (`enable==0`): remap current mode `+47464` (`0→1/1→2/2→3/3→4`), reconfigure via `+46896`
vtbl+176 with config block `Block={3,4}`, set `+52384=15`/`+47464=3`; RtpRtcp vtbl+400(0)+584 flush;
finally `memset(+50624, 0, 508)`.

## 4.2 Control word — bit `0x4` (kCtrlEnc) `[body]` `sub_1800594C0(engine, msg)`
The control word is a **10-bit field** (`& 0x3FF`) at `engine+628160` (high bits preserved:
`new | (old & ~0x3FF)`, new = `*(msg+16)&0x3FF`). Core is **bit `0x4`**:
- **set** → `+628244=1` (extra AI/SNAC encode ON), controller `+424` vtbl+1184(1); lock + register (`+628248=1`).
- **clear** → `+628244=0`, vtbl+1184(0); format 4-char stream tag `"{%.*s|%2ld}"` (id from `+92`).
- **value change** (`old≠new`) → build 6-field payload `{msg+0,+4,+8, ctrlword, +24,+32}` → **event 44** via dispatcher `+614808`.
- always emit telemetry `[ExtraAiCodecEvent_kCtrlEnc]` (with `msg+24`).

This is the **execution point** of the server switch: the control word is populated by the §6.4 `0x50`
dispatch (mask `&0xFFFFFC00|0x200` — the low 10 bits are this `0x3FF`, `0x200`=bit9 set-marker).

## 4.3 SNAC enable / decode state machine `[body]` `Channel::EnableExtraSnacDecoding` (`sub_1800C39E0`)
The decode side is an **atomic state machine**, state word `engine+51152`: **0=kDisable / 1=kReady**
(2 also treated as active). Logged `[snac-tcp.feat] Channel::EnableExtraSnacDecoding(enable: N)`;
transitions `ExtraSnacCodecStatus, change: X -> Y`:
```
lock(engine+51168);
if (!enable) {
  if (state∈{1,2}) { log("… -> kDisable"); sub_1800CF050(engine,0,0,state,payloadType,0); new=0; } // deregister codec
  else            { engine+51160 = ctrlword; return; }                    // already disabled
} else {
  if (state!=0)   { engine+51160 = ctrlword; return; }                    // already enabled
  log("kDisable -> kReady"); sub_1800CF050(engine,0,1,state,payloadType,0); new=1;               // register codec
}
_InterlockedExchange(engine+51152, new); engine+51160 = ctrlword; notify(engine+51176);
engine+52392 = (ctrlword & 4) ? 1 : 0;  recvModule(engine+144).vtbl+544( ctrlword&4 );  // same bit 0x4 → recv-side decode
unlock;
```
i.e. **register/deregister via `sub_1800CF050(…, enable, …, payloadType)`, atomic state swap, control word
stored at `+51160`**; the **same bit 0x4** as §4.2 (send side) also drives the **receive side** extra
decode (recv module vtbl+544) — send/recv coupled by one control-word bit. Related low-bitrate TCP
fallback `snac_lowbandwidth_tcp` / `kDisable_LowBitrateOn` (see §4.4).

## 4.4 SNAC-TCP → Opus reliable fallback `[body]` `sub_1800D1BE0` / `sub_1800D2A60`
When UDP stalls ≥2 s, reassemble Opus from the reliable TCP channel. Hard-coded thresholds:
```
if (now - last_snac_tcp_ts < 2000)               fail("recv_no_snac_tcp_pack");   // need ≥2s UDP outage
ts_range = (max_ts - min_ts)/48 + 20;            // 48 = 48kHz/ms, +20 = one frame
if (ts_range < 2500)                             fail("check_opus_has_enough_valid_data");
loss = (float)(expected - actual) / expected;    // expected=seq span, actual=pkts
if (loss > THRESH)                               fail("check_opus_loss_rate");
// tier II accepts loss ≤ 0.5 ; tier III accepts loss ≤ 0.2 (lookback 2s = ts-96000)
```

## 4.5 FEC / PLC / jitter `[str]`
Custom Opus in-band FEC (LBRR) + **multi-layer FEC** (`total_decoded_3rd_4th_5th_fec_packets`),
**DRED** neural PLC (`{[DRED-OPUS]}`, `Audio_Enable_OPUS_DRED_Codec`), **NetEQ** adaptive jitter
(`SetNetEQPlayoutMode`, `GetJitterStatistics`). `SetFECStatus` returns `-1`/`8003` (RED not supported
by design). Freeze detection `CoreAudioFreeze`.

**Fidelity:** switching logic + constants = **T2** (verified; `recon/viper_audio_engine.hpp` executes
the decision in the demo). Opus/SNAC codec bodies themselves = T2/T3.

---

# 5. Weak-network — video (zlt.dll)

## 5.1 SVC encode config `[body]` `zltCEncodeConfig::SetEncodeCfg` (`sub_18005A690`)
Input `a2` is a layered config. Header: `nInputFrameRate`(f32 +0), `nActualFrameRate`(f32 +4),
`nConnectMode`(u16 +8), `nSourceLevel`(u64 +16), `nPreprocLevel`(+24), **`nSpatialLayerNum`(+28)**;
`+32` → **spatial-layer array**, each **96 bytes** (verified `v8 += 96`):

| off | field | off | field | off | field |
|---|---|---|---|---|---|
| +0 | `Width` | +28 | `nTemporalLayerNum`(u8) | +64 | `nRaType`(u8) |
| +4 | `Height` | +32 | →per-temporal frame-rate array | +68 | `nRaFixQp` |
| +8 | `nFrameRate`(f32) | +40 | `nBitrate` | +72 | `nRefFrameNum`(u8) |
| +12 | `nCodecMode`(u16) | +44 | `nFixQp` | +76 | `bSingleRefFlag` |
| +14 | `nProfileIdx`(u8) | +48 | `nLayerQosLevel` | +80 | `bLtrFlag` |
| +15 | `nLevelIdx`(u8) | +52 | `nLayerComplexityLevel` | +84 | `nSliceBytes` |
| +24 | `nToolsControlFlag` | +56 | `nEntropyCodingMode` | +88/+92 | `nSliceNum`/`nThreadNum` |

Each spatial layer also carries a **per-temporal frame-rate array** (layer `+32` ptr, length = layer `+28`).
`dBitrateFactor = (i32)cfg[35956] × 2⁻¹⁰` (fixed-point /1024). On apply:
- **Structure-mode unpack**: `cfg+136`(u16) split into nibbles → `cfg+216/220/222/212`; low nibble = mode,
  **mode==3 special-case → mode rewritten to 2 and `cfg+212=1`**.
- **Per-layer reference-buffer count**: read layer `+13` flag → `cfg+34648[i] = (flag==1) ? 8 : 16`.
- **Per-layer tool bits**: `nToolsControlFlag` (layer `+24`) bits 0..5 → 6 per-layer booleans at `cfg+34820[i·6..]`.
- **Change detection**: new layer array (stride 96) diffed vs current `cfg+160`; mismatch sets **reconfig-pending
  bit `cfg+41640`** (error if already set) — this bit doubles as the **double-buffer bank** for §5.2 slots.
- codec mode `(cfg+56)−4 ≤ 1` (modes 4/5) also sets `cfg+35224=3`; apply via `sub_180058E90`(validate)→
  `sub_180062730`/`sub_180063690`(push to encoder core); if `cfg+4852` and state `cfg+222`∈{5,6}, also apply
  secondary config `cfg+4864` (simulcast/dual).

## 5.2 Key-picture / reference request dispatcher `[body]` `SetKeyPictureRequest` (`sub_180008370`)
Preamble: `a3` null → err; `cfg+444` not ready → err. Core is a **request-slot array**:
`slot = cfg + 41644 + 52·(spatial + 5·bank)`, **52 bytes each**, `bank` = reconfig bit `cfg+41640` (0/1,
**double-buffered across reconfig**, 5 spatial slots per bank). Bounds checked against **per-codec-mode
capability tables**: spatial `< byte_1803F8700[mode]`, temporal `< byte_1803F863C[mode+20]`. Each request
writes a pending flag + params into its slot; the encode loop consumes them next frame. Slot fields:

| slot off | field | writer |
|---|---|---|
| +0 / +4(u64) / +8(u16) | new-attendee key pending / referenced sent-I-pic id / TId | case 3 |
| +12 / +16(u64) / +20 / +24(u16) | P-ref-change pending / last-received pic id / min pic id / TId | case 2 |
| +28 / +36 | **IDR pending** / IDR request-number (dedup) | case 4·20·(2/3 coalesce) |
| +40 | subscribe-change key pending | case 20 |
| +44 | **redundant-P pending** | case 5 |
| +48 | **frame-skip pending** | case 24 |

| case | request | verified logic (not just purpose) |
|---|---|---|
| 1 | `SetEncodeCfg` | → §5.1 |
| 2 | `SetKeyPictureRequest` | Loss recovery. Guard: single-ref (`+136==1`) && `+222≠2`→reject. IDR already pending→coalesce; layer in active/subscribe lists (`+34236`/`+34516`)→convert to subscribe (set `+28`); else set `+12`, store `nLastReceivedPicId`(`+16`)/`nTemporalId`(`+24`); **repeats take newest** (wrap compare `(u16)(old−new−1)≤0x7FFF`) and clamp min picId (`+20`). Semantics: make the next P **reference a known-good earlier frame** instead of the lost one — LTR-style recovery, no full IDR. |
| 3 | `SetNewAttendeeKeyPictureRequest` | Late joiner. Guard single-ref→reject. In-layer: in active list→fall back to real IDR (`+28`); else set `+0`, store `nUsedIPicId`(`+4`); layer out of range && `nSpatial==0&&layer==0`→IDR else reject. Semantics: **reference the most recent sent I-frame** to serve the newcomer without forcing an IDR on everyone. |
| 4 | `SetIdrPictureRequest` | Set **IDR pending(`+28`)=1**, `+36 = max(cur, iRequestNumber)`. Semantics: **true keyframe**; request-number dedups repeats (emitting an IDR ≥ that number marks it served). |
| 5 | `SetPDuplicatePictureRequest` | IDR pending→coalesce; **else if no P-ref pending (`+12==0`)→set redundant-P pending(`+44`)=1**. Semantics: **redundant P-frame** — an extra P that does not advance the reference chain so one lost packet doesn't break it; skipped if a keyframe is already coming. |
| 20 | `SetSubscribeChangeKeyPictureRequest` | Guard single-ref. IDR pending→coalesce; layer in `+34236`→set IDR(`+28`); in `+34516`→`+28`; else set subscribe-change pending(`+40`). Semantics: when a receiver **switches subscribed spatial layer**, request the minimal keyframe for it. |
| 24 | `SetFrameSkipRequest` | Only `(mode−4)≤1` (modes 4/5); no IDR pending→set **frame-skip pending(`+48`)=1**. Semantics: **drop this layer's next frame** under congestion. |
| 25 | layer mask | gated `(mode−2)≤1`, value ≤0x30 and even → write `cfg+324/+352`. |
| 31 | run-mode switch | `mode=*(u64)a3`→`cfg+144` (state==5 also `cfg+4880`); `mode<4` && (`mode≠2` or `cfg+224`)→`sub_180063D90(mode)` (simulcast/SVC/single; mode 2 needs a capability bit). |
| 33 | layered bitrate array | `cfg+268`=type(≤2), `cfg+272`=DWORD, copy 16B+4B into `cfg+276..292`; guard "if `a3[1]==0` then `a3[2..6]` all 0". |

## 5.3 Video enhancement `[str]`
RAISR super-res (`zltCScreenRAISR`, `ScreenRaisrx2`; nydus `CDrawFunc_D3d11_Raisr`), temporal denoise
(`zltCTemporalDenoise`, `CVideoEDNetDenoise_AOM`), motion-adaptive quant (`zltCTextureMotionAdaptQuant`).

**Fidelity:** dispatcher + config = **T2** (`recon/zlt_svc_encoder.hpp`, all cases + layer validation).

---

# 6. Weak-network — session control (mcm.dll)

## 6.1 G.107 E-model MOS `[body]` `sub_1801642D0`
Per-user MOS from absolute network delay:
```
R = clamp(baseR - Id(delay), 0, 93.2)            // Id via delay breakpoints 100/500/1000/2000/3500 ms
MOS = 1 + 0.035*R + R*(R-60)*(100-R)*7e-6        // standard ITU-T G.107 R→MOS
```
Reported (qos cmd `301`) with `cur_packets_loss_rate / cur_fec_packets_ratio / cur_plc_packets_ratio /
avg_iat_ms / cur_jitter_ms / abs_net_delay_ms`. This MOS is the core switching input.

## 6.2 Bandwidth distribution `[str]`
**Corrected understanding**: in mcm, `bandwidth_distribute_info` is **not a client-side allocation
function — it is a reported/telemetry structure** (the string appears only in logs/PDU fields; no local
compute function references it). This matches §12 — the split of bandwidth across audio/video/share is
**server-decided (MMR/RWG), client-executed/reported**; there is no independent client-side allocator.
Real client-side rate adaptation lives in: per-stream encoder target bitrate (zlt `SetKeyPictureRequest`
case 31 run-mode / `dBitrateFactor`, see §5) and the net_score/bw_level reports (§6.3) that drive
server-side re-allocation.

## 6.3 Uplink network-score PDU `[body]` — **type 85** (parse `sub_1800188B0`)
`app_uplink_net_score_t` is a per-stream uplink-quality descriptor. Parsing (body, see §6.4) writes each
per-stream struct in a **fixed field order**:

| field | slot | semantics |
|---|---|---|
| `mc_up_net_score` | fld[10] | **0–5** composite uplink score (0=worst … 5=best), the core switching input |
| `mc_up_bw_level` | fld[11] | **bw tier 1/2/−1** (−1=unknown/invalid), coarse uplink bandwidth level |
| `c_rcd_flg` / `anno_version` / `as_ctrl_id` | same struct | recording flag / annotation version / app-share control id |

Each descriptor is stored in a red-black tree by **SSRC** (`this+73872`, **key = `ssrc >> 10`** — merges
sub-streams of one source); entries built only for stream types ∈ `{1,3,5,11,20,21,52}`. Accompanying
metering: multi-layer FEC `total_decoded_3rd_4th_5th_fec_packets` / `cur_fec_packets_ratio`, jitter
`jitter buffer level` / `cur_jitter_ms`. These are the **raw signals reported to the server for
switching/re-allocation** (§12 decision chain; client reports, server decides).

## 6.4 Network warning + command dispatch `[body]`/`[str]`
`MCM_NW_WARNING` (on/off hysteresis). Command dispatcher `sub_18007CFA0` routes server messages by
type: `0x11`, `0x31` (MIC-MODE), `0x50` (per-stream encode-feature bitmap), `0x27` (interpreting).
Telemetry only: `EXTRA_AICODEC_EVENT`/`_STATUS_CODE` (monitor_info PDU type 79).

**Fidelity:** MOS math + distribution + hysteresis = **T1** math (`recon/mcm_media_channel.hpp`, runnable).

---

# 7. Application-share transport (asproxy.dll) — CORRECTED

> **Correction (verified from bodies):** asproxy is **not** a NACK/FEC/congestion engine — the function
> bodies contain no such logic. It is an XML **"asp" control-protocol** client + an `ssb` async-socket
> data channel, reporting QoS as a **type-53 network-info PDU**. (RTTI type names like
> `congestion_control_t`/`nack_t` may exist as types, but the data-plane mechanism recovered from bodies
> is the below.) Earlier drafts over-indexed on the RTTI names; this section supersedes them.

## 7.1 Control dispatch `[body]` `sub_1800057E8`
Parse `<protocol name="asp" ver cmd=…>` (tinyxml2), switch on `cmd`:
`negotiate` → `sub_180005EB4`; `authenticate`/`reauthenticate` → state `3`; `welcome` → `sub_18000623C`;
`monitor`/`message`/`bye`. Session states recovered (word @ +1072): authenticating = **3**, connected = **4**.

## 7.2 negotiate `[body]` `sub_180006D84`
Advertises device info: `cpu num`, `cpu freqx100`, `hw info type`, `as profile`, `audio codec`,
`share audio`, `client ver` (`7.1.0.41345`), `ext ver`.

## 7.3 welcome / bind-token / data channel `[body]` `sub_18000623C`
Parses `data ip`, `data port`, `bind token`, `asdata ssrc`, `adata ssrc`, `as profile`, `srn rsln`;
opens `ssb::socket_ctx_t::new_instance(ip, port, media_type=8, …)`, `set_version(3)`,
`set_alive_time(0x927C0 = 600000 ms)`; async connect timeout `5000 ms`; state → 4.

## 7.4 QoS network-info PDU `[body]` `sub_180013B98` — **type 53**
`qos_network_info_pdu_t` (`v26 = 53`); iterates **8 media channels** (channel 7 gated on flag @ +2404);
sets a per-channel variant keyed by index: **1 = `bw_level_audio`, 2 = `bw_level_ds` (desktop share),
3 = `bw_level_video`**. Per-channel fields packed from slot offsets +52 (active)/+266/+267/+272/+288.

**Fidelity:** protocol + state machine + PDU = **T2** (`recon/asproxy_share_qos.hpp`; demo simulates the
handshake + type-53 report).

---

# 8. Transport (tp.dll) — ssb::socket_ctx_t

## 8.1 Verified secure-endpoint config `[body]` (offsets)
| accessor | offset | meaning |
|---|---|---|
| `set_sec_version(u8)` | +336 | security version |
| `set_ssl_hostname_verify(bool)` | +296 | verify hostname |
| `set_ssl_verify_mode(int)` | +72 | 0/1/3 |
| `set_ssl_verify_method(bool)` | +73 | writes 1, or **3** (peer + fail-if-no-cert) when true |
| `set/get_cert_info(string)` | +304 | cert info |
| `set/get_cert_fingerprint(string)` | +416 | **certificate pin** |
| `set/get_cert_public_key(string)` | +448 | **SPKI public-key pin** |
| `set_traffic_id(char*)` | +376 | telemetry tag, **≤200 chars** (returns 2 if longer) |
| `set/get_media_type(u8)` | +408 | media type tag |
| `set_ws_alive(u32,u32)` | +90/+91 | WebSocket keepalive interval/timeout |
| `get_error_code()` | +75 | last error |

## 8.2 Link-measurement classes `[body]` (RTTI→vtable walk, recovered)
**Correction**: the earlier "RTTI-only, maybe no logic" note was wrong. Walking the `??_7*@@6B@` vtables
confirms all three are **timer-driven sliding-window ring-buffer estimators** sharing one pattern:
**accumulate between ticks → on timer push one sample into a fixed-capacity ring (cap @ `obj+8`) → evict
oldest → reset accumulator**.

| class / vtable | core method | verified mechanism |
|---|---|---|
| `bandwidth_t` @0x1801389C0 | `sub_18004F720` | samples every ≥**1000ms** (`ticks_drv_t::now − last ≥ 0x3E8`); maintains **two** rings (`+16/+32` lists, `+24/+40` counts). sample = **accumulator ÷ 1000 = per-second rate** (`v<1000 ? (v!=0) : v/1000`, min-1-if-nonzero); accumulators `+56/+60`, paired timestamps `+48/+52`; evicts head beyond `+8` cap. |
| `throughput_t` @0x180138A58 | `sub_1800517C0` | single accumulator `+144` pushed to ring `+152` (count `+160`) per tick, then reset. |
| `jitter_t` @0x180139290 | `sub_180051720` | accumulator `+172` + pending bit `+176`; when set, allocate 0x18 node with the value → splice into doubly-linked list `+144` → clear pending. I.e. a **per-sample jitter time series**. |
| `dns_provider_t` @0x180137FC8 | `async_resolve` | **async DNS resolver** (`timer_sink_it` + observer: `async_resolve(socket_ctx_t*, observer_it*)`/`async_resolve_i`/`dns_resolve_msg`/`dns_observer_t`), singleton. |

`ssb::net_adaptors_t` (IPHLPAPI `NotifyAddrChange`) does network-change detection. Note: tp only produces
**raw link-sample series**; the finished decision metrics (`cur_jitter_ms`/`avg_iat_ms`) are computed/reported
mcm-side (§6.1 G.107, §6.4).

**Fidelity:** socket_ctx_t config + the three estimator structures = **T2** (`recon/tp_transport.hpp`).

---

# 9. Application-share media FEC (nydus.dll) — Reed–Solomon

## 9.1 GF(2⁸) field `[body]` `sub_180005C44`
Systematic **Reed–Solomon over GF(2⁸)**. Exp/log tables built by mul-by-2 with reduction; the
**primitive polynomial** is read from an 8-char ASCII bitstring `"10111000"` @ `0x1801F4F28` →
reduction `0x1D` → **poly `0x11D` = x⁸+x⁴+x³+x²+1** (standard RS poly, NOT AES 0x11B). 256×256 multiply
table `Block`; inverse table @ `word_1802C2CF0`.

## 9.2 Erasure solve `[body]` `sub_180005F34`
GF polynomial arithmetic over `Block` (`v31[i+1] ^= Block[256*c + v31[i+2]]`); recovered symbols written
back strided by the group width (systematic layout).

## 9.3 Grouping / classes `[body]`/`[rtti]`
Hierarchy: `FecRtpPacketGroupBase` ← `Nydus::ClientFecRtpPacketGroup`; `IFecBufferManage` (vtable
`0x1801F4EF0`, 4 pure virtuals + scalar-deleting dtor); `PacketFecProcessBase` ←
`Nydus::ClientRtpPacketProcess` (ctor `sub_180002614`, holds `Nydus::ClientDataRtpPacketList` /
`DataRtpPacketListBase` media+fec RTP lists). Group map keyed by size/seq, CriticalSection-guarded
(insert `sub_180005D3C`, teardown `sub_180005DFC`).

**Fidelity:** **T1** — runnable `recon/algo/rs_fec.hpp` (GF256/0x11D, systematic Cauchy + Gauss-Jordan
erasure decode; `demo_algo` §D: K=6+R=3, erase 3 → full recover, refuse at K−1).

---

# 10. viperex.dll — "Companion Mic" ML feature engine

## 10.1 Identity `[str]`
OpenVINO-based: **CAM++ speaker embedding**, **Picknet/OSD** active-speaker, **lipsync**. PE layout:
`.text` 2.2 MB (normal code) + `.rdata` 43 MB / `.data` 18 MB / `.rsrc` (entropy ~7.3–7.5 = trained
**model weights**). `[AUDIO-CHUNKS] … (CAM++, Timeline, Picknet, Picknet_Smoothed)`,
`[CAMPP] ExtractEmbedding FAILED on 3s window`, `lipsync_model_calculator.cpp`.

## 10.2 Control surface `[body]` (recovered; weights are T3)
| element | anchor | detail |
|---|---|---|
| init | `viperex_init` `0x1800141F0` | stores 2 host cfg ptrs (+288/+296), returns API vtable `off_182B15000` |
| version | `viperex_version` `0x180014230` | `strcpy "7.1.0.41345"` |
| OpenVINO bind | `sub_180179AF0` | `SetDllDirectoryW` → `LoadLibraryW("openvino_c.dll")` → ~19× `GetProcAddress` |
| model load | `sub_180171020` | PE `"BIN"` resources `embedding_model_xml_bin`/`osd_model_xml_bin`; container = **8-byte LE xml-length header + xml‖bin, every byte XOR `0xA7`** |
| worker | `sub_180014C60` | `_beginthreadex` (1 MB stack) + priority map `{1:-1, 2:0, 3:1, 4:2, 5:15}` |
| tick | `sub_180014820` | WINMM `timeSetEvent` (periodic flags `0x21`), `timeKillEvent` on restart |
| pipeline | `sub_18010AF30` → `sub_18010B6A0` | 16 kHz mono; 1.5 s chunk (24000 smp) EMA-smooths Picknet (threshold-selected α); accumulate 3 s (48000 smp) → CAM++ under mutex; timeline (meeting_time += 1.5 s) |

**Fidelity:** control/scheduling/model-container = **T1** (runnable `ModelResourceCodec` in
`recon/viperex_runtime.hpp`, round-tripped in `demo_weaknet` §G); neural weights = **T3**.

---

# 11. eCDN / mesh (zMeshNetAgent.dll) `[body]`
**LAN multicast mesh (body-verified)**: `GetMeshNetworkInterface` singleton (0x720 object); config apply
`sub_18001FA50` (reads config ids 586–590 from a red-black tree): **`EnableMeshNetworking`**(590),
**multicast IP:port**(586/587, `m_strMulticastIp`/`m_usMulticastPort`), **listen port range**(588,
`m_nListenStartPort–EndPort`), **`EnableGuestMesh` GPO**(589: NotConfigure/Disable/Enable). Super-node
switching is server-pushed (§15.4 Cmmlib messages 10140/10150), client-executed. Meeting state machine
(Init/Connecting/Active/Erasing) has a separate transition function. (`recon/zmesh_agent.hpp`.)

---

# 12. Decision chain — who decides (server-driven)

Switching decisions (AI-codec / SNAC / keyframe / super-node) are made **server-side**
(MMR/RWG + account Feature Toggle). The client only **reports metrics** and **executes commands**:

```
client → server : mcm QoS (G.107 MOS / loss / jitter / FEC·PLC ratio / net_score 0-5 / bw_level 1-4)
server          : MMR/RWG + Feature Toggle decide
server → client : control msg → mcm dispatch (0x11 / 0x31 MIC-MODE / 0x50 per-stream feature bitmap / 0x27)
                → per-stream control word ; bit 0x4 (kCtrlEnc) flips AI/SNAC encode in viper
```
Input = `net_score/bw_level/MOS`; dispatcher = mcm `sub_18007CFA0`; execution = viper
`OnExtraAiCodecControlEvent` (bit `0x4`). Almost everything is gated by server Feature Toggle
(`IFeatureToggleProvider` / `mc_features` / `QueryFeatureToggle`).

---

# 13. Self-developed optimizations (own / std / mixed)

| Area | Optimization | Type | Evidence |
|---|---|---|---|
| Audio | SNAC neural codec (AVX) | own | `SnacInferenceEncoderAVX` |
| Audio | Custom Opus + DRED neural PLC | own | build string; `{[DRED-OPUS]}` |
| Audio | Multi-layer FEC (3/4/5) | own | `total_decoded_3rd_4th_5th_fec_packets` |
| Audio | SNAC-TCP reliable fallback | own | `snac-tcp-to-opus-II/III` |
| Audio | Neural bandwidth-extension | own | `dense_if_upsampler_1/2_scale` |
| Audio | Speaker embedding | own | `viper::SharedSpeakerEmbExtractor` |
| Audio | AI background denoise | own | `AUDIO-SUPPRESS-BGNOISE` |
| Audio | NetEQ jitter buffer | std | WebRTC `SetNetEQPlayoutMode` |
| Video | Self SVC + rich keyframe/dupP/skip requests | own | `SetPDuplicatePictureRequest`/`SetFrameSkipRequest` |
| Video | RAISR super-res | own* | `CDrawFunc_D3d11_Raisr`, `zltCScreenRAISR` |
| Video | Neural temporal denoise (EDNet) | own | `CVideoEDNetDenoise_AOM` |
| Video | Motion-adaptive quant | own | `zltCTextureMotionAdaptQuant` |
| Video | DirectML/ONNX GPU inference | mixed | `ONNX_DIRECTML` |
| Transport | Uplink net-score PDU | own | `app_uplink_net_score_t` |
| Transport | eCDN + super-node | own | `ECDNSwitchSuperNode` |
| Transport | HTTP failover + probe | own | `HttpFailoverRecoveryController` |
| Transport | Alt-Svc switching | own | `AlternativeServiceMgr` |
| Transport | P2P direct | own | SIP `switchtop2p` |
| Transport | GCC/BWE/NACK/RTX | mixed | viperex `.text` (fragment) |

\* RAISR is Intel's algorithm; Zoom integrates a GPU/screen-content implementation.

---

# 14. EA anchor index (quick lookup)

| Module | EA | what |
|---|---|---|
| viper | `sub_1800CE540` | AI-codec 121 enable gate (main 113/116) |
| viper | `sub_1800594C0` | control word bit 0x4 → republish event 44 |
| viper | `sub_1800D1BE0`/`sub_1800D2A60` | SNAC-TCP→Opus fallback thresholds |
| viper | `sub_180074920` | `[CODEC] mode=` reconfig |
| zlt | `sub_18005A690` | SVC SetEncodeCfg (96-byte layer struct) |
| zlt | `sub_180008370` | SetKeyPictureRequest dispatcher |
| mcm | `sub_1801642D0` | G.107 MOS |
| mcm | `sub_18007CFA0` | server-command dispatcher |
| asproxy | `sub_1800057E8` | "asp" cmd dispatch |
| asproxy | `sub_180006D84` | negotiate |
| asproxy | `sub_18000623C` | welcome / bind-token / data channel |
| asproxy | `sub_180013B98` | type-53 QoS network-info PDU |
| tp | socket_ctx_t accessors | TLS/pinning/keepalive config |
| nydus | `sub_1801D0F88` | D3D9 LockRect readback |
| nydus | `sub_180005C44`/`sub_180005F34` | RS GF(2⁸)/0x11D tables / erasure solve |
| nydus | `sub_180164E84` / `sub_1801CF340` | SafePresent / SafeLockRect |
| zbt | `0x18009C920`/`0x18009C680` | Av1 Enc/Dec InterfaceCreate |
| zbt | `sub_1801CFA10`/`sub_1801D0AA0` | AV1 seq / frame header parse |
| viperex | `0x1800141F0` / `sub_180171020` | init / model-resource loader (XOR 0xA7) |
| viperex | `sub_18010AF30`/`sub_18010B6A0` | Picknet EMA + CAM++ 3s window |
| CptHost | `sub_1400378E8`/`sub_140038040` | Magnifier host + scaling callback |
| nydus | `sub_18004296C` | capture config loader |

---

# 15. Transport optimizations — logic detail (from decompiled bodies)

The actual *logic* behind the transport rows of §13 (not just evidence strings), verified from
function bodies. Fidelity **T2**. Config field names are taken from the binary's own log format strings.

## 15.1 HTTP endpoint failover / failback `[body]` `zMsgAppCommon.dll · HttpFailoverRecoveryController`
An anti-flap failover/failback state machine with exponential backoff + success threshold + head-to-head
confirmation + hard timeout. Primary ("first") domain + backup; on failure switch to backup and record
`m_switchToBackupAtMs`, then periodically probe the primary:
- **probe schedule / cooldown** (`sub_180039CA4` ContinueProbingOrReArmCooldown): **exponential backoff** —
  `_backoffLevel` indexes a backoff-interval array, next probe = now + array[level]; when
  `m_probeAttemptsThisCycle ≥ _maxProbeAttemptsPerCycle` → **re-arm cooldown** (next = now +
  `_secondSideCooldownMs`), reset counters.
- **probe result / failback climb** (`sub_180039E98` OnProbeResult): success → `++_successCount`; if
  `< _successThreshold` keep climbing, at threshold → **propose failback** (`_failbackRequirePkConfirmation`);
  failure → `++m_cycleFailCount`, `_successCount=0`, back off.
- **PK head-to-head** (`sub_180038F20` HandlePkResult): `willSwitch = otherWins > currentWins &&
  otherWins ≥ _pkDecisiveWins`.
- **hard force-reset** (`sub_1800399A0` TryForceResetToFirstDomain): on backup longer than `_forceResetMs`
  → unconditionally return to primary.
- **failback rejected** (`sub_180039B90` AbortFailbackProposal): sink rejects → `_successCount=0` + back off.

Config fields: `_pkDecisiveWins · _forceResetMs · _maxProbeAttemptsPerCycle · _secondSideCooldownMs ·
_successThreshold · _failbackRequirePkConfirmation`; state: `_successCount · _backoffLevel ·
m_cycleFailCount · m_probeAttemptsThisCycle · m_switchToBackupAtMs`.

## 15.2 Alt-Svc alternative-service switching `[body]` `zNet.dll · zNet::AlternativeServiceMgr`
RFC 7838: server returns `Alt-Svc: h3=":443"; ma=86400` → client caches (host → alt protocol/endpoint).
- `ParseMaxAge` (`sub_1800DCA70`): locate `ma=`, read following digits → maxAge seconds.
- `AddOneEntry` (`sub_1800DCF30`): `expiry_ms = MM_Now()_ms + 1000*maxAge`, store per host.
- `HasValidAltsvcCache` (`sub_1800DD350`): `now ≥ expiry` → **lazy-delete + false**; else true → use h2/h3.
- `OnNetworkStateChanged` (`sub_1800DCC10`): on network change, marshal to `main.thread.runner` and re-eval.
- `CSBCUrlRequest::EnableALTSVC / RemoveALTSVC`: per-request toggle.

## 15.3 P2P direct switching `[body]` `zSIPSDK.dll · switchtop2p`
`sub_18040B7C0` parses a **SIP INFO** message (content-type `application/json`) and keyword-classifies the body:
- body contains `"switchtop2p"` **and** crypto keys → tag `###sip info(switchtop2p)###` → **switch media to P2P**
  (peer sends the P2P endpoint + crypto material over the signaling channel).
- contains `"pwd"` → `###sip info(meeting)###`.
So P2P is **signaling-triggered** (peer/server pushes switchtop2p + keys), not a local heuristic.

## 15.4 eCDN super-node switching `[body]` `Cmmlib.dll · SaaSBee module bus`
Super-node ops are **server-pushed module-bus messages**, client executes — **no client-side selection
algorithm** (confirms §12 decision chain):
- `CSBMBMessage_ECDNSwitchSuperNode` — id **10140**, `com.zoom.app.cdnSwitchSuperNode`.
- `CSBMBMessage_ECDNSetBackupSuperNodeInfo` — id **10150**, `com.zoom.app.cdnSetBackupSuperNodeInfo` (carries `data`).

---

# 16. Video optimizations — logic detail

## 16.1 Perceptual adaptive-QP suite `[body]` `zlt.dll · ns_avc`
Not one "motion-adaptive quant" but a **family of per-criterion QP modules** (each an RTTI class):
`zltCBackgroundAdaptQuant`, `zltCRoiAdaptQuant`, `zltCTextureMotionAdaptQuant`, `zltCComAdaptQuant`,
`zltCScStaticAdaptQuant`. Core primitive (`sub_1800E7680`/`sub_1800E7740`): map each block's perceptual
metric through a **6-threshold step function** → a QP offset level (≈ −2..+3); the more thresholds
exceeded, the coarser the QP:
```
level = (val >= thr[0]) - 3 + 1;
if (val <  thr[1]) level = (val >= thr[0]) - 3;
if (val >= thr[2]) ++level;  if (val >= thr[3]) ++level;
if (val >= thr[4]) ++level;  if (val >= thr[5]) ++level;
qp_delta_map[blk] = level;                 // write per-block QP offset + accumulate mean
```
**TextureMotion** (process `sub_1800E7A00`, vtable `0x180502738`): two metrics each with its own 6-threshold
bank — texture (spatial variance, thr@+136) + motion (reference-frame diff, thr@+120) → `delta =
textureLevel + motionLevel`. So **busy + moving blocks (distortion masked) get coarser QP to save bits;
flat/static/ROI/text get finer QP**. Thresholds are tunable config arrays. **T2** (logic recovered).

## 16.2 RAISR super-resolution `[body]`/`[rtti]` `zlt.dll(ns_vpp/ns_glt/ns_gct) · nydus.dll`
Hashed filter-bank super-res (Intel RAISR: classify each patch by **gradient bucket** → apply that
bucket's pre-learned linear filter → 2× upscale). Variants: CPU `zltCScreenRAISR`/`zltCRaisr` (ns_vpp),
D3D11 GPU `gltD3D11ScreenRaisr`/`gltD3D11Raisr` (ns_glt), GPU `CGPUScreenRaisr`/`CGPURaisr` (ns_gct),
each in **Screen (screen-content)** and normal flavors; nydus `CDrawFunc_D3d11_Raisr`. Structure **T2**;
**filter-bank coefficients = learned data (T3)**.

## 16.3 Denoise family `[body]` `zlt.dll(ns_vpp) · nydus.dll`
Tiered: classic **`zltCIIRDenoise`** (recursive temporal IIR — non-neural; `sub_1802A5260` measured EWMA
`new = 0.37·in + 0.63·prev`, α=0.37, param cmd 0x70004) + `zltCTemporalDenoise` /
`zltCDenoise` + `zltCDenoiseASM` (SSE/AVX SIMD); plus neural **EDNet** (`nydus::CVideoEDNetDenoise_AOM`).
i.e. lightweight IIR/temporal always-on + neural EDNet on demand (server toggle). IIR/SIMD **T2**;
EDNet weights **T3**.

# 17. Audio optimizations — logic detail

## 17.1 Multi-layer FEC (3/4/5) — mcm-side metering `[body]` `mcm.dll`
**mcm does NOT run the FEC codec — it only *meters and reports* how much each FEC layer recovered** (key
clarification; the earlier `[str]` tag undersold mcm's half, which is body-verifiable).

- **Aggregate count** (`sub_1801650E0`): `total_decoded_3rd_4th_5th_fec_packets` = packets recovered by the
  **3rd/4th/5th cascaded FEC layers** — the *deeper/stronger* tiers (packets the lighter FEC missed and the
  heavy FEC recovered). Counting it measures "how deep a FEC this stream needed."
- **Per-user QoS JSON report** (`sub_1801642D0`, computes MOS + serializes `Json::Value`, verified field
  order): `user_index_id` · **`cur_mos_score`** (G.107 MOS) · **`cur_score`** (net_score) ·
  `recv_packet_since_last` · `cur_packets_loss_rate` · `max_packets_lost_once` ·
  `continuou_packets_lost_ratio` (burst) · **`cur_fec_packets_ratio`** (FEC recovery frac) ·
  **`cur_plc_packets_ratio`** · `avg_iat_ms`/`max_iat_ms` · `cur_jitter_ms` · `abs_net_delay_ms`.
- **Flow**: FEC-recovery frac + PLC + loss/burst/jitter → `cur_mos_score`/`cur_score` → reported to server →
  server decides whether to deepen the FEC level / switch codec (§12).

**Boundary**: the real 3/4/5-layer **cascaded FEC (de)coding DSP** lives in `viper`'s custom Opus fork (build
string `…extrafec-maxlbrr-multifec-dred`) — a libopus-derived **codec kernel (K)**, not re-read; `DRED`
neural PLC = weights (W). **T2** (mcm metering is runnable-reconstructable; FEC/DRED kernels = K/W boundary).

## 17.2 AI background-denoise gating `[body]` `mcm.dll · sub_18015A0B0`
The gate lives in mcm's **audio-feature command handler** (`switch(cmd)`, cmd = ASCII code).
**`'!'` (0x21) = AUDIO-SUPPRESS-BGNOISE** (body-verified):
```
word = support ? (payload | 0x80000000) : (payload & 0x7FFFFFFF);  // stored a1+5648, top bit = support
denoise_mode = word >> 16;                        // high 16 bits = mode
enable = support_denoise(a1+296) && (denoise_mode==0 || denoise_mode==3);
if (state@a1+1688 != -1 && changed)               // only on change
    engine.dispatch(cmd 48, &enable);             // controller vtbl+88 pushes denoise on/off
log("AUDIO-SUPPRESS-BGNOISE, %self_id, %support_denoise, %denoise_mode");
```
i.e. **enable = support && mode∈{0,3}**, pushed as **engine command 48** on change. Same handler also does
personalized voice: `'='`(0x3D)=PSE toggle (`a1+10029`), `'?'`(0x3F)/`'F'`(0x46)=speaker-embedding
enroll/apply (config keys `zoom.audio.{manual,auto}.speakerEmb`, post msg 123). Gate = **T2**; neural
denoise/embedding kernels = weights **T3** (downstream in viper/viperex).

## 17.3 NetEQ adaptive jitter `[str]` `viper.dll`
`SetNetEQPlayoutMode` / `GetJitterStatistics` — WebRTC **NetEQ** standard adaptive jitter buffer (adjusts
playout delay by measured jitter + accelerate/decelerate/PLC). Runnable same-family reconstruction:
`recon/algo/jitter_buffer.hpp` (RFC-3550). Standard component, **T1** (generic impl).

> Neural boundary (recap): RAISR filter banks, EDNet/AI-denoise, SNAC/DRED, neural bandwidth-extension =
> **learned parameters (T3)** — we have structure + gates + scheduling, not the coefficients/weights.

---

# 18. Weak-network A/V optimization — principles & playbook

Chapters 1–17 are the reverse-engineering record of *what Zoom does*; this chapter **re-organizes it by
problem into transferable principles** — each entry gives technique → **why it works** → **cost/trade-off**
→ takeaway → honest boundary.

**Honest premise first.** Weak-net optimization has two layers: **① low-level mechanism + tuning** (how the
encoder/FEC/jitter-buffer works, what the thresholds are) lives **in the client binaries — learnable**;
**② high-level orchestration policy** (at what loss to raise FEC a level, how to split bandwidth across
audio/video/share, when to trigger a keyframe) lives on the **server (MMR/RWG) — these DLLs don't have it**
(see §12). Everything of type ② below is marked "⚠ decision is server-side".

## 18.0 Mental model: metric → lever → who decides
Every weak-net optimization is a control loop. See where each stage lives and what you can learn:

| stage | what | where | learnable here |
|---|---|---|---|
| **metric** | per-stream loss/RTT/jitter/IAT → compressed to **G.107 MOS** + **net_score(0–5)/bw_level** | client mcm/tp | ✅ formula + fields (§6.1/§6.3, §8.2) |
| **decision** | pick levers from metrics: FEC level, layer count, bitrate, switch codec/node | ⚠ **server** | ❌ thresholds/algorithm unavailable (§12) |
| **command** | control word / key-picture request / bitrate target / super-node | server→client | ✅ command formats (§4.2, §5.2, §15) |
| **execution** | encoder/rx modules actually pull the lever | client | ✅ mechanism + low-level tuning (this chapter) |

**First lesson:** large-scale RTC is usually "**client measures + executes, server decides**" — the upside is
global optimality (the server sees everyone), the cost is limited edge autonomy + signaling dependence. The
transferable *intuition* is mostly in **lever design + metric design**; the decision policy is a separate
discipline (and each vendor's moat).

## 18.1 Packet loss — the redundancy vs reference-trick trade-off
| technique | mechanism | why it works | cost/trade-off | regime |
|---|---|---|---|---|
| In-band FEC (Opus LBRR) | §4.5 | forward redundancy, recovered on the spot — **zero retransmit RTT** | constant bitrate overhead (even when no loss) | low–mid loss, low latency |
| **Multi-layer FEC (3/4/5)** | §17.1/§6.3 | progressively stronger redundancy — **strength follows loss level** | bitrate rises fast with level | mid–high loss |
| **LTR reference recovery** (case 2) | §5.2 | next P references a **known-good earlier frame**, skips the lost one, **no IDR** | needs long-term-reference buffer; older ref → slight quality drop | single-point loss, save bitrate |
| **Redundant P** (case 5) | §5.2 | extra P that **doesn't advance the reference chain** → one lost packet doesn't break it | extra frame's bitrate/CPU | protect a key layer |
| Force IDR (case 4) | §5.2 | fully resets decode state, always recovers | **keyframe is the most expensive**, taxes everyone's bandwidth | severe error / last resort |
| DRED neural PLC | §4.5 | generative model "imagines" the lost audio packets | neural weights (not reproducible) + CPU | high audio loss |

**Takeaway:** four weapons in rising cost order — **FEC** (forward, constant overhead, zero latency) →
**reference tricks** (LTR/redundant-P, cheap on bitrate but single-point only) → **retransmit** (on-demand
but adds RTT; Zoom audio uses SNAC-TCP §4.4) → **keyframe** (most expensive, resets everything). Core
intuition: **use the cheapest tool that covers the current loss level**; multi-layer FEC engineers exactly
that — don't pick one blanket redundancy rate. ⚠ "which loss → which level" threshold is server-side.

## 18.2 Congestion / insufficient bandwidth — layering & the degradation order
| technique | mechanism | why it works | cost/trade-off |
|---|---|---|---|
| **SVC spatial/temporal layering** | §5.1 | **encode once, adapt everywhere**: receiver/server takes a subset per its bandwidth, no re-encode per peer | encode complexity + layering overhead |
| **Frame-skip request** (case 24, modes 4/5) | §5.2 | drop one layer's frame on demand = **instant frame-rate cut**, resolution/quality untouched | smoothness drops |
| Bitrate factor / run-mode switch (case 31) | §5.1/§5.2 | scale target bitrate / switch simulcast↔SVC↔single | mode switch has a transient |

**Takeaway:** SVC's whole value is "**encode once, heterogeneous adapt**" — in multiparty calls each peer's
bandwidth differs, so layering beats re-encoding per route. Degradation has a **conventional order**:
**frame-rate (skip/temporal) → resolution (spatial) → quality (QP)**, because the eye is most sensitive to
stutter, then resolution. ⚠ which layers / bitrate target are server-pushed.

## 18.3 Jitter — the direct latency-vs-smoothness knob
| technique | mechanism | why it works | cost/trade-off |
|---|---|---|---|
| **NetEQ adaptive jitter buffer** | §17.3 | dynamically adjusts playout delay with accelerate/decelerate/PLC | **latency ↔ stutter** direct trade: bigger buffer = smoother but more lag |
| jitter_t time-series + IAT/jitter_ms metric | §8.2/§6.1 | quantify jitter by inter-arrival variance, feed the buffer controller | — |

**Takeaway:** the jitter buffer is the classic "latency-for-smoothness" knob in RTC audio; a **dynamic**
buffer (auto-sized by measured jitter) beats a fixed one. Separating metric (tp's sliding-window ring
estimators) from execution (NetEQ) is a reusable decoupling.

## 18.4 Bandwidth adaptation — compress network state into one comparable scalar
| technique | mechanism | why it works | cost/trade-off |
|---|---|---|---|
| **net_score(0–5)/bw_level + G.107 MOS** | §6.1/§6.3 | compress loss/delay/jitter/FEC/PLC into **one composite score** as controller input | scalarizing loses info, but is stabler/comparable/easy to hysteresis |
| Server re-allocation (`bandwidth_distribute` report) | §6.2/§12 | global view splits total bandwidth across audio/video/share | ⚠ decision centralized on the server |

**Takeaway:** rather than feed a controller raw metrics, **fuse them into one health score** (MOS/net_score)
first — G.107's E-model is a mature way to map delay/loss to MOS, naturally suited to switching thresholds
with hysteresis (avoids flapping). ⚠ this section is almost entirely server-side: the client only
"scores + reports + executes." To learn the *allocation algorithm* itself, static RE of these binaries won't
give it — you'd need server-behavior/packet observation.

## 18.5 Late-join / perceptual coding / screen content — spend bits where the eye values them
| technique | mechanism | why it works | cost/trade-off |
|---|---|---|---|
| **New-attendee reference to old I-frame** (case 3) | §5.2 | late joiner references the most recent **already-sent** I-frame, no forced IDR taxing everyone | must keep an I-frame referenceable; fall back to real IDR only if needed |
| **Perceptual adaptive QP** (background/ROI/texture-motion/screen-static) | §16.1 | spend bits on eye-sensitive regions (face/text/static), coarse QP where distortion is masked (busy/motion) | needs content analysis (variance/motion/ROI) |
| RAISR super-res / IIR+EDNet denoise | §16.2/§16.3 | transmit low-bitrate + **reconstruct on the edge**; denoise also eases encoding | neural weights not reproducible (structure/idea is); costs compute |

**Takeaway:** two transferable motifs — **perceptual coding** (bits aren't split evenly but by "value to the
eye": more to faces/text, less to background texture) and **trade compute for bandwidth** (super-res/denoise
turn "send high quality" into "send low quality + fix locally"). The late-join trick is the general idea of
"serve new demand from existing resources — don't let newcomers penalize existing users."

## 18.6 Quick reference: symptom → first lever
| symptom | first | then | last |
|---|---|---|---|
| mild-mid loss | in-band FEC / redundant P | LTR reference recovery | raise FEC level |
| heavy loss | multi-layer FEC + DRED (audio) | LTR / redundant P | force IDR |
| bandwidth drop | frame-skip (cut fps) | drop spatial layer / bitrate factor | single-stream / switch codec |
| high jitter | grow NetEQ buffer | — | (latency for smoothness) |
| bitrate tight but need clarity | perceptual QP (bits to face/text) | edge super-res/denoise | SVC layered adapt |

**Closing (honest):** this chapter's "why / cost / takeaway" is the **engineering-principle layer —
transferable, usable for your own build**; but the specific **trigger thresholds and global bandwidth
allocation = server policy**, not in the client binaries — this doc labels that rather than inventing it. In
short: **this doc teaches you "what levers exist, how each is wired, why it's designed that way, what it
costs" — enough to learn the mechanisms and intuition of weak-net A/V optimization; it does not (and cannot,
from the client) teach Zoom's exact scheduling-threshold table.**

---

# 19. Video receive → render pipeline (nydus wall renderer) `[body]`

How a decoded video frame goes from "CPU frame off the network (I420)" all the way to "rendered into the
window". **Key correction**: the real video renderer is `nydus.dll`'s **D3D11 "wall" renderer** (the gallery
tile grid) — **not** `zRenderEngine` (which is a separate Skia/Lottie/SVG **UI graphics** engine, unrelated
to video frames).

```
// full downlink chain (body-verified to the static-RE floor)
network → tp recv
  → nydus RTP depacketize / FEC (SSRC grouping + RS-GF(2^8)/0x11D erasure + reorder)
  → zbt decode → I420 CPU frame (sw) / NV12 GPU texture (hw MFT/DXVA)
  → Nydus::CConvert2I420 normalize → CVideoProcess + zltIEventCallBack
  → nydus wall renderer: CWallRenderer(GPU/D3D11) or CMemoryWallRenderer(CPU sw)
       · I420 3 planes → D3D11 textures
       · draw chain Upsample → Dcc → Raisr (shaders: YUV→RGB + scale + super-res)
       · composite tiles → BGRA backbuffer (DXGI_FORMAT 87)
  → SafeCreateSwapChain + SafePresent (IDXGISwapChain::Present)
       · DXGI_ERROR_DEVICE_REMOVED/RESET(0x887A0005) device-lost recovery
  → window
```

## 19.1 RTP depacketize + FEC `[body]` `nydus.dll`
Received media is grouped by **SSRC**, Reed–Solomon erasure-recovered, and reordered inside `nydus`
(see §9): `Nydus::ClientRtpPacketProcess` (ctor `sub_180002614`) holds `ClientDataRtpPacketList`/
`DataRtpPacketListBase` media+parity RTP lists; group map keyed by size/seq under a critical section; RS
field `sub_180005C44` (0x11D), erasure solve `sub_180005F34`.

## 19.2 Decode → I420 normalize `[body]` `zbt` · `Nydus::CConvert2I420`
The recovered bitstream is decoded: AV1 via `zbt` (HW-capable, §3.1). SW decode yields **I420** (planar
YUV420 8-bit) CPU frames; HW decode (MFT/DXVA) may yield NV12 GPU textures. **`Nydus::CConvert2I420`**
(RTTI class, vtable `0x18022B738`) normalizes non-I420 input to I420; the frame is handed to the renderer
via **`Nydus::CVideoProcess`** + `zltIEventCallBack` (codec event callback; object ctor `sub_18009AEDC`
wires both the `CVideoProcess::CzltIEventCallBack` and `CConvert2I420` vtables).

## 19.3 Wall renderer: GPU / CPU backends `[body]`/`[rtti]`
| renderer | vtable | role |
|---|---|---|
| **`Nydus::CWallRenderer`** (GPU/D3D11) | main iface `0x180240780` (17 slots) | HW-accelerated primary path |
| **`Nydus::CMemoryWallRenderer`** (CPU sw) | main iface `0x18022EB08` (17 slots) | no-GPU / remote-desktop fallback |

"Wall" = the gallery grid of participant videos; the renderer manages each tile. On resolution change the
iface method `sub_1801B68A0` compares current w/h (`this+320/324`) vs the new frame; if changed it tears
down and rebuilds textures/pipeline (`sub_1801B9AB0` unbind → reconfigure → `sub_1801B9A2C` rebind), storing
the new size at `this+312`. Commands post through an internal red-black tree + critical section (e.g.
`SetASRaisrEnabled` toggling super-res: `sub_180119AF0` / `sub_1801B38F0`).

## 19.4 D3D11 draw chain + backbuffer `[body]`
GPU draw uploads the I420 3 planes into D3D11 textures, then runs a **draw-function chain** (ctor
`sub_1801670E0` wires three sub-objects, each with its own vtable):
```
CDrawFunc_D3d11_Upsample (this+0,   scaling)
  → CDrawFunc_D3d11_Dcc  (this+24,  color/contrast)
  → CDrawFunc_D3d11_Raisr(this+136, RAISR super-res, §16.2)
```
Pixel shaders do **YUV→RGB + scale + super-res**, compositing tiles into the **backbuffer**. The render core
`sub_180175764` (builds render target / swapchain) shows the backbuffer as **BGRA (`DXGI_FORMAT 87` =
`B8G8R8A8_UNORM`)**. Optional `Nydus::CD3d11SharedHandleHelper` (keyed-mutex shared texture, vtable
`0x18023AC50`, device@+24 / shared texture@+40, opens shared resource via device vtbl+224) shares frames
cross-device/process (§2.3).

## 19.5 Present to window `[body]` `Nydus::SafePresent`
The swapchain is created by `Nydus::SafeCreateSwapChain` (`sub_18016503C`); each frame goes through present
path `sub_180172D20` → **`Nydus::SafePresent`** (`sub_180164E84`, `IDXGISwapChain::Present` wrapper). With
**device-lost recovery**:
```
ret = SafePresent(swapchain@this+144, 1, 1, &flag);
if (ret == 0x887A0005 /*DXGI_ERROR_DEVICE_REMOVED*/ || ret == 0x887A0007 /*RESET*/)
    device(this+160)->vtbl+312();   // trigger device/swapchain rebuild
```

## 19.6 The static-RE floor `[boundary]`
The pipeline **structure is fully body-verified** (wall renderer + I420 normalize + Upsample/Dcc/RAISR draw
chain + BGRA backbuffer + SafePresent + device-lost recovery). But the "last inch" hits a floor:

| want | actual form | statically readable? |
|---|---|---|
| I420 → texture upload | `ID3D11DeviceContext` COM `vtbl+offset` calls (no symbols in decompile) | only by tedious per-offset mapping, not illuminating |
| YUV → RGB | **compiled HLSL shader blob** (bytecode in the resource section) | ❌ not decompilable to source |
| exact texture format (NV12 / R8×3) | runtime texture desc | only determined dynamically |

To get the exact texture formats + shaders you need **dynamic frame capture (RenderDoc / PIX)** attached to a
live meeting — beyond static binary analysis.

**Fidelity:** receive→render **pipeline structure = T2** (modules/classes/EA anchors all body-verified); GPU
texture upload + YUV→RGB shader = **static-RE floor (COM indirection + shader blob)** — not an unreachable
tier, but requires dynamic means.

---

*Reconstructions live in `recon/`; demos in `demo/` (8 targets; `RECON_WITH_CODECS`/`RECON_WITH_OPUS`
gate real dav1d/libopus decode). See `CODEC_RECONSTRUCTION_PLAN.md` for codec details,
`ARCHITECTURE.html` for the end-to-end architecture, and
`zoom_weaknet_capture_analysis.html` for the narrative report.*
