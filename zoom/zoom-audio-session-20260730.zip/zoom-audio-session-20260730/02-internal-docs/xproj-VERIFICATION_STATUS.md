# Verification status — every claim graded to "magnifier granularity"

Bar (per user): every technical claim must be **read from the decompiled function body and actually
understood** — not string/RTTI inference, not "same family as X", not guessing. This file grades every
claim honestly and is the work queue to close the gaps.

Legend:
- ✅ **BODY** — the actual function body was read + understood (the bar).
- ◑ **PARTIAL** — structure/mechanism read, but a specific sub-detail is still inference (named exactly).
- ⛔ **BOUNDARY** — cannot reach "code body" and why: (W) trained neural **weights** = not code, only the
  inference harness is code; (K) full third-party **DSP kernel** (libaom/libopus-derived, 10⁴ functions) —
  we verify the wrapper/control, not re-read every routine.

Only ✅ counts as meeting the bar. ◑ and the (W)/(K) parts of ⛔ are the honest gaps.

---

## Capture
| Claim | Status | Anchor | Gap to close |
|---|---|---|---|
| D3D9 surface readback (LockRect→copy) | ✅ BODY | `nydus sub_1801D0F88`, `SafeLockRect sub_1801CF340` | — |
| Magnifier: two-branch + version gate + WndProc detour + 0x500 drive | ✅ BODY | `CptHost sub_140037DD8/62C88/36E50/36CE8`, `GetClassInfoW "Magnifier"`, `sub_140076F94` | — |
| Magnifier: exact vtbl calls inside the read fn | ◑ PARTIAL | traced: `0x500`→`sub_140036CE8`→`ctx+336`; detour handler = `*(global+56)`, installed in the DX9 singleton `sub_140037B90` init | decompile the DX9 singleton init to get `global+56` handler / `ctx+336` body; confirm GetRenderTargetData/LockRect |
| D3D11 Present-hook wrapper | ✅ BODY | `nydus SafePresent sub_180164E84` | — |
| D3D11 shared keyed-mutex texture (`CD3d11SharedHandleHelper`) | ✅ BODY | `nydus CD3d11SharedHandleHelper` two vtables; device@+24, shared texture@+40, opens shared resource via device vtbl+224; refcounted | — (matches SharedSurfaceReader/Writer; AcquireSync/ReleaseSync in sub_180177D80) |
| WGC frame path | ✅ BODY | `cpt_uwp_capture::capture_item_imp` ctor `sub_180007320`: ring buffer + CS, registers `TypedEventHandler<Direct3D11CaptureFramePool,IInspectable>` (FrameArrived), API-contract-gated (UniversalApiContract v10); `GetNextFrame`=`sub_180007238` dequeues from the ring buffer under CS | — (per-pixel CopyResource is in capture_frame_imp; acquisition mechanism fully traced) |
| PrintWindow + transparent-edge crop | ✅ BODY | `sub_180002C60`: GetWindowPlacement→visible-bit→DWM rect, reject `<-15360`/`>4132`, DC-pool(4)+`PrintWindow(PW_RENDERFULLCONTENT)`, edge-scan `(px+0x1000000)&0xFEFFFFFF` with ≤100 cap + ≤18px threshold, D3D11 tex fmt 87(BGRA), retry ≤20 | — |
| CptShare = remote-control input hooks + clipboard (NOT capture injection) | ✅ BODY *(corrected)* | `CptShare sub_180028620` (WH_KEYBOARD_LL 13 / WH_MOUSE_LL 14 / clipboard, codes 1124-1131) | — (earlier "injects capture DLL" claim was wrong; capture runs in-process in CptHost) |

## Codecs
| Claim | Status | Anchor | Gap |
|---|---|---|---|
| AV1 create + SC core `(mode&0xF)==2` + SpecialFeature ids | ✅ BODY | `zbt 0x18009C920/0x18009C820` | — |
| AV1 OBU seq/frame-header parse | ✅ BODY | `zbt sub_1801CFA10/sub_1801D0AA0` | — |
| AV1 entropy/transform/tile DSP kernel | ⛔ BOUNDARY (K) | — | not re-read (libaom-scale); wrapper verified |
| Opus switching (ids 113/116/121) | ✅ BODY | `viper sub_1800CE540` | — |
| Opus SILK/CELT DSP kernel | ⛔ BOUNDARY (K) | — | libopus-derived |
| SNAC neural codec | ⛔ BOUNDARY (W) | `webrtc::ISnacEncoder` | weights; harness only |

## Weak-net audio (viper)
| Claim | Status | Anchor | Gap |
|---|---|---|---|
| AI-codec 121 enable gate | ✅ BODY | `sub_1800CE540` | — |
| control-word bit 0x4 (kCtrlEnc) | ✅ BODY | `sub_1800594C0` | — |
| SNAC-TCP→Opus fallback thresholds | ✅ BODY | `sub_1800D1BE0/sub_1800D2A60` | — |
| multi-layer FEC (3/4/5) — **mcm metering** | ✅ BODY | `mcm sub_1801650E0` (aggregates `total_decoded_3rd_4th_5th_fec_packets`), `sub_1801642D0` (per-user QoS JSON: `cur_mos_score`/`cur_score`/`cur_packets_loss_rate`/`continuou_packets_lost_ratio`/**`cur_fec_packets_ratio`**/`cur_plc_packets_ratio`/`avg_iat_ms`/`cur_jitter_ms`/`abs_net_delay_ms`) → server decides | — (mcm meters + reports; does not run FEC) |
| multi-layer FEC (3/4/5) **encode/decode DSP** | ⛔ BOUNDARY (K) | build string `…-extrafec-maxlbrr-multifec-dred` | inside viper's custom Opus (libopus fork) codec kernel; DRED PLC = W |
| DRED neural PLC | ⛔ BOUNDARY (W) | build string | weights |
| NetEQ jitter | ⛔ BOUNDARY (K) | `SetNetEQPlayoutMode` | WebRTC-standard component |
| AI background denoise (gate) | ✅ BODY | mcm `sub_18015A0B0` case `'!'`(0x21): `enable = support_denoise(a1+296) && (denoise_mode∈{0,3})`, denoise_mode = payload>>16; on change → engine cmd 48 via ctrl vtbl+88; same handler does PSE(`'='`)+speaker-emb enroll/apply(`'?'`/`'F'`, `zoom.audio.{manual,auto}.speakerEmb`) | — (neural suppression kernel downstream = ⛔W) |

## Weak-net video (zlt) + optimizations
| Claim | Status | Anchor | Gap |
|---|---|---|---|
| SVC SetEncodeCfg (96-byte layer struct) | ✅ BODY | `sub_18005A690` | — |
| SetKeyPictureRequest dispatcher (all cases) | ✅ BODY | `sub_180008370` | — |
| Adaptive-QP 6-threshold step + TextureMotion combine | ✅ BODY | `sub_1800E7A00/sub_1800E7680/sub_1800E7740` | — |
| IIR temporal denoise (`zltCIIRDenoise`) | ✅ BODY | `sub_1802A5260`: EWMA `new = 0.37*input + 0.63*prev` (α=0.37), param cmd 0x70004 | — (classic recursive temporal filter, non-neural) |
| RAISR apply (variants) | ✅ BODY (structure) / ⛔W (coeffs) | `zltCScreenRAISR` vtable methods `sub_1801B2890`… (CPU/GPU/screen variants) | apply/gate code body-read; **filter-bank coefficients = trained data (W)** |
| EDNet temporal denoise | ⛔ BOUNDARY (W) | `CVideoEDNetDenoise_AOM` | weights |

## Session control / transport / share
| Claim | Status | Anchor | Gap |
|---|---|---|---|
| G.107 MOS formula + breakpoints | ✅ BODY | `mcm sub_1801642D0` | — |
| mcm command dispatch (0x11/0x31/0x50/0x27) | ✅ BODY | `sub_18007CFA0` switch: 0x11 mic-flag / 0x31 MIC-MODE telemetry / 0x50 → 12-channel feature map @this+15440 / 0x27 interpretation | — |
| net_score/bw_level per-stream apply | ✅ BODY | `sub_1800188B0`: `mc_up_net_score`→fld[10](0-5), `mc_up_bw_level`→fld[11](1/2/-1), `c_rcd_flg`/`anno_version`/`as_ctrl_id`; stream-type∈{1,3,5,11,20,21,52}; SSRC→RB-tree @a1+73872 (key ssrc>>10) | — (build/send side is the mirror; field semantics confirmed) |
| asproxy "asp" protocol + type-53 QoS + data channel | ✅ BODY | `sub_1800057E8/06D84/0623C/013B98` | — |
| tp socket_ctx_t config (TLS/pin/keepalive) | ✅ BODY | socket_ctx_t accessors | — |
| tp DNS / jitter / bandwidth / throughput | ✅ BODY *(formula read)* | vtable walk: all three = **timer-driven sliding-window ring estimators** (accumulate→tick→push sample to capped ring @+8→evict oldest). `bandwidth_t sub_18004F720` samples every ≥1000ms, 2 rings, sample=**accumulator÷1000 = per-sec rate** (min-1-if-nonzero); `throughput_t sub_1800517C0` flushes acc@+144 per tick; `jitter_t sub_180051720` appends acc@+172 to time-series list@+144. `dns_provider_t` = async resolver singleton. tp emits raw sample series; reported `cur_jitter_ms`/`avg_iat_ms` computed mcm-side (§6) | — |
| nydus RS-FEC (GF256/0x11D) tables + erasure solve | ✅ BODY | `sub_180005C44/sub_180005F34` | — |
| viperex control (init/OpenVINO/model-loader/thread/timer/pipeline) | ✅ BODY | `0x1800141F0/sub_180171020/…` | — |
| viperex neural models (CAM++/Picknet/lipsync) | ⛔ BOUNDARY (W) | OpenVINO IR | weights |
| HTTP failover/failback state machine | ✅ BODY | `zMsgAppCommon sub_180038F20/39188/399A0/39CA4/39E98/39B90` | — |
| Alt-Svc cache (ma= / expiry / net-change) | ✅ BODY | `zNet AlternativeServiceMgr::*` | — |
| P2P switch (SIP INFO keyword) | ✅ BODY | `zSIPSDK sub_18040B7C0` | — |
| eCDN super-node messages (10140/10150) | ✅ BODY | `Cmmlib CSBMBMessage_ECDN*` | — |
| eCDN mesh config + interface | ✅ BODY | `GetMeshNetworkInterface` singleton (0x720 obj); `sub_18001FA50` applies mesh cfg ids 586-590: `EnableMeshNetworking`(590), multicast IP:port(586/587), listen port range(588), `EnableGuestMesh` GPO(589); super-node = server msgs (§15.4, Cmmlib 10140/10150) | residual: the meeting Init/Connecting/Active/Erasing transition graph is a separate fn (states from earlier reconstruction) |

---

## Work queue — DONE except one honest ◑
- [x] CptShare (corrected) · mcm dispatch · mcm net_score · D3D11 shared surface · tp DNS/link classes
      · IIR denoise (α=0.37) · RAISR apply (structure) · PrintWindow crop · WGC frame path · eCDN mesh config
- [⛔] multi-layer FEC → codec-kernel boundary (Opus fork)
- [◑] **Magnifier `ctx+336` readback body** — the ONLY remaining ◑. Mechanism fully body-traced
      (version-gate → wndproc detour → D3D9Ex device → 0x500 → `sub_140036CE8` → `ctx+336`); the exact
      GetRenderTargetData/LockRect sequence sits behind `global+56` fn-ptr indirection (= nydus SafeLockRect
      family). Needs a dynamic hook or deeper RTTI-vtable dig to reach byte-level; left honest.
- residual (not gating): eCDN meeting Init/Connecting/Active/Erasing transition-graph fn; WGC per-pixel
  CopyResource in capture_frame_imp — both mechanisms verified, exact fns one read away.

## Hard boundaries (won't reach code-body, by nature)
- **(W) trained weights**: SNAC, DRED, CAM++, Picknet/OSD, RAISR filter-banks, EDNet. Body-level applies
  only to the *inference harness* (done: viperex §10). The learned function is float data, not code.
- **(K) third-party DSP kernels**: AV1 (libaom-derived) and Opus (SILK/CELT) internal coding routines —
  tens of thousands of functions; we body-verify Zoom's wrapper/control and the bitstream parse, and use
  the reference libs for decode (see CODEC_RECONSTRUCTION_PLAN.md), rather than re-reading every routine.
