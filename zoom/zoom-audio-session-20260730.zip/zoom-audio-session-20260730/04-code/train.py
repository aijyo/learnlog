"""Training for both recovered models. One data pipeline, two models, one metric harness.

    python train.py denoise --epochs 40
    python train.py snac    --epochs 40
    python train.py info                      # shapes, param counts, provenance, int8 report
    python train.py infer  --model M.pt --kind denoise --in noisy.wav --out clean.wav

FRAMING is identical to ns_core.hpp -- 16 kHz, 512-point FFT, hop 256, 257 bins -- so anything this
writes can be scored in the existing harness (nsxlab --clean, scripts/eval/*.py) against the DSP.

DATA. Reads samples/clean and samples/noise, mixes on the fly at a random SNR, and holds out one
speaker plus the two transient noise classes the DSP fails on (Typing, Munching) so a win cannot come
from having memorised the test noise. With only ~80 s of speech locally this WILL overfit; that is a
data problem, not a code problem, and NOTES.md 19.21 measures exactly how much headroom is being left
on the table (oracle mask: 52.6 dB gap/speech modulation vs the DSP's 9.4 dB).
"""
import argparse
import math
import os
import random
import struct
import sys
import wave

import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from zoom_nets import DenoiseNet, Snac, recovered as R           # noqa: E402
from zoom_nets import quant                                       # noqa: E402
from zoom_nets.sed import SedNet, FilterBank, SED_IN              # noqa: E402

D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR, NFFT, HOP, BINS = 16000, 512, 256, 257

CLEAN_TRAIN = ["clnsp379", "clnsp512", "clnsp518", "clnsp553"]
CLEAN_TEST = ["clnsp1068"]
NOISE_TRAIN = ["AirConditioner_1", "VacuumCleaner_1", "Babble_1", "ShuttingDoor_1",
               "Neighbor_1", "AirportAnnouncements_1"]
NOISE_TEST = ["Typing_1", "Munching_1"]
_WIN = torch.hann_window(NFFT)


# ------------------------------------------------------------------ io / data
def read_wav(p):
    w = wave.open(p, "rb")
    n, sw, sr = w.getnframes(), w.getsampwidth(), w.getframerate()
    raw = w.readframes(n)
    w.close()
    assert sw == 2 and sr == SR, "need 16-bit %d Hz mono, got %d-bit %d Hz" % (SR, sw * 8, sr)
    return torch.tensor(struct.unpack("<%dh" % n, raw), dtype=torch.float32) / 32768.0


def write_wav(p, x):
    pcm = (torch.clamp(x, -1, 1) * 32767).to(torch.int16).tolist()
    w = wave.open(p, "wb")
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes(struct.pack("<%dh" % len(pcm), *pcm))
    w.close()


def load(names, sub):
    return [read_wav(os.path.join(D, "samples", sub, n + ".wav")) for n in names]


def mix_at_snr(speech, noise, snr_db, rng):
    """Same convention as eval.hpp: RMS over the whole of each signal, noise tiled then scaled."""
    n = speech.numel()
    if noise.numel() < n:
        noise = noise.repeat(int(math.ceil(n / noise.numel())))
    off = rng.randrange(0, max(1, noise.numel() - n + 1))
    nz = noise[off:off + n].clone()
    s_rms = speech.pow(2).mean().sqrt().clamp_min(1e-9)
    n_rms = nz.pow(2).mean().sqrt().clamp_min(1e-9)
    nz *= (s_rms / (10 ** (snr_db / 20.0))) / n_rms
    return speech + nz


def stft(x):
    return torch.stft(x, NFFT, HOP, window=_WIN, center=True, return_complex=True)


def istft(X, length):
    return torch.istft(X, NFFT, HOP, window=_WIN, center=True, length=length)


def logp(mag):
    return torch.log(mag.pow(2).clamp_min(1e-10))


def comp_l1(a, b, p=0.3):
    """L1 on power-law-compressed magnitudes. p=0.3 keeps the loudest bins from owning the gradient."""
    return (a.clamp_min(1e-8).pow(p) - b.clamp_min(1e-8).pow(p)).abs().mean()


def batches(clean, noise, rng, seg_s, snr_lo, snr_hi, n):
    seg = int(seg_s * SR)
    for _ in range(n):
        sp = clean[rng.randrange(len(clean))]
        if sp.numel() > seg:
            o = rng.randrange(0, sp.numel() - seg)
            sp = sp[o:o + seg]
        noisy = mix_at_snr(sp, noise[rng.randrange(len(noise))], rng.uniform(snr_lo, snr_hi), rng)
        yield noisy, sp


# ------------------------------------------------------------------ denoise
def run_denoise(m, noisy):
    X = stft(noisy)
    mag = X.abs()
    mask, aux = m(logp(mag).transpose(0, 1).unsqueeze(0))
    mask = mask.squeeze(0).transpose(0, 1)
    return X, mag, mask, aux


def train_denoise(a):
    rng, _ = random.Random(1234), torch.manual_seed(1234)
    ctr, ntr = load(CLEAN_TRAIN, "clean"), load(NOISE_TRAIN, "noise")
    cte, nte = load(CLEAN_TEST, "clean"), load(NOISE_TEST, "noise")
    m = DenoiseNet(skips=not a.no_skips, aux_heads=not a.no_aux, mask_max=a.mask_max)
    print("DenoiseNet: %d params" % m.param_count())
    for k, v in m.provenance().items():
        print("  %-10s %s" % (k, "; ".join(v)))
    print("train %d speech / %d noise;  HELD OUT: %s x %s"
          % (len(ctr), len(ntr), ",".join(CLEAN_TEST), ",".join(NOISE_TEST)))
    opt = torch.optim.Adam(m.parameters(), lr=a.lr)
    sch = torch.optim.lr_scheduler.StepLR(opt, max(1, a.epochs // 3), 0.5)
    best = float("inf")
    for ep in range(1, a.epochs + 1):
        m.train()
        tot = nb = 0
        for noisy, sp in batches(ctr, ntr, rng, a.seg, a.snr_lo, a.snr_hi, a.steps):
            X, mag, mask, _ = run_denoise(m, noisy)
            loss = comp_l1(mag * mask, stft(sp).abs())
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
            opt.step()
            tot += float(loss.detach()); nb += 1
        sch.step()
        m.eval()
        with torch.no_grad():
            vr = random.Random(7); vl = vn = 0
            for sp in cte:
                for nz in nte:
                    noisy = mix_at_snr(sp, nz, 5.0, vr)
                    X, mag, mask, _ = run_denoise(m, noisy)
                    vl += float(comp_l1(mag * mask, stft(sp).abs())); vn += 1
        v = vl / max(vn, 1)
        tag = ""
        if v < best:
            best = v
            torch.save({"kind": "denoise", "state": m.state_dict(),
                        "cfg": dict(skips=not a.no_skips, aux=not a.no_aux,
                                    mask_max=a.mask_max)}, a.out)
            tag = "  <- saved"
        print("epoch %3d  train %.5f  valid %.5f%s" % (ep, tot / max(nb, 1), v, tag))
    print("best %.5f -> %s" % (best, a.out))


# ------------------------------------------------------------------ snac
def train_snac(a):
    rng, _ = random.Random(1234), torch.manual_seed(1234)
    ctr = load(CLEAN_TRAIN, "clean")
    cte = load(CLEAN_TEST, "clean")
    m = Snac(dim=BINS, width=a.width, latent=a.latent, code_dim=a.code_dim,
             codebook=a.codebook, n_stages=a.stages)
    print("Snac: %d params, %.1f bits/frame at %d stages"
          % (m.param_count(), m.bits_per_frame(), a.stages))
    for k, v in m.provenance().items():
        print("  %-10s %s" % (k, "; ".join(v)))
    print("NOTE: a codec is trained on CLEAN speech -- it reconstructs, it does not denoise.")
    opt = torch.optim.Adam(m.parameters(), lr=a.lr)
    sch = torch.optim.lr_scheduler.StepLR(opt, max(1, a.epochs // 3), 0.5)
    best = float("inf")
    seg = int(a.seg * SR)
    for ep in range(1, a.epochs + 1):
        m.train()
        tot = nb = 0
        for _ in range(a.steps):
            sp = ctr[rng.randrange(len(ctr))]
            if sp.numel() > seg:
                o = rng.randrange(0, sp.numel() - seg)
                sp = sp[o:o + seg]
            mag = stft(sp).abs()
            x = logp(mag).transpose(0, 1).unsqueeze(0)
            y, codes, commit = m(x)
            # reconstruct in the log-power domain, plus the RVQ commitment term
            loss = F.l1_loss(y, x) + a.commit * commit
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
            opt.step()
            tot += float(loss.detach()); nb += 1
        sch.step()
        m.eval()
        with torch.no_grad():
            vl = vn = 0
            for sp in cte:
                x = logp(stft(sp).abs()).transpose(0, 1).unsqueeze(0)
                y, _, c = m(x)
                vl += float(F.l1_loss(y, x)); vn += 1
        v = vl / max(vn, 1)
        tag = ""
        if v < best:
            best = v
            torch.save({"kind": "snac", "state": m.state_dict(),
                        "cfg": dict(width=a.width, latent=a.latent, code_dim=a.code_dim,
                                    codebook=a.codebook, stages=a.stages)}, a.out)
            tag = "  <- saved"
        print("epoch %3d  train %.5f  valid %.5f%s" % (ep, tot / max(nb, 1), v, tag))
    print("best %.5f -> %s" % (best, a.out))


# ------------------------------------------------------------------ sed
# 10 classes, matching the recovered 10 output channels. Eight are the noise recordings we have, plus
# speech and silence -- a real sound-event task on the data actually present, not a stand-in.
SED_CLASSES = ["silence", "speech",
               "AirConditioner_1", "VacuumCleaner_1", "Babble_1", "ShuttingDoor_1",
               "Typing_1", "Munching_1", "Neighbor_1", "AirportAnnouncements_1"]
# held out per class family so the test set is genuinely unseen material, not another crop of the same
SED_NOISE_TEST_CROP = 0.25          # last quarter of every noise file is test-only
SED_CLEAN_TEST = CLEAN_TEST


def sed_window(x, fb, rng=None, want=SED_IN[0]):
    """One 100-frame x 40-band log-filterbank window, mean-normalised per window.

    Per-window mean removal is what lets a fixed input quantiser work across recording levels -- and
    Zoom's input IS quantised with a single (scale, zero_point), so something upstream must be
    normalising. Marked as ours: the normalisation itself was not read.
    """
    need = (want + 1) * HOP
    if x.numel() < need:
        x = x.repeat(int(math.ceil(need / max(x.numel(), 1))))
    off = (rng.randrange(0, x.numel() - need + 1) // HOP) * HOP if rng else 0
    m = stft(x[off:off + need]).abs()
    f = fb(m)                                   # (T, 40)
    f = f[:want] if f.shape[0] >= want else F.pad(f, (0, 0, 0, want - f.shape[0]))
    return f - f.mean()


def train_sed(a):
    rng, _ = random.Random(1234), torch.manual_seed(1234)
    fb = FilterBank(SR, NFFT, SED_IN[1])
    clean_tr, clean_te = load(CLEAN_TRAIN, "clean"), load(SED_CLEAN_TEST, "clean")
    noise = {n: read_wav(os.path.join(D, "samples", "noise", n + ".wav"))
             for n in SED_CLASSES[2:]}
    m = SedNet(n_classes=len(SED_CLASSES), pool=a.pool, quant=a.qat)
    print("SedNet: %d params, %d classes" % (m.param_count(), len(SED_CLASSES)))
    print("shape check against the recovered dimensions:")
    if not m.check_shapes():
        print("  !! shapes diverge from the binary -- stop and fix before training")
        return
    for k, v in m.provenance().items():
        print("  %-9s %s" % (k, "; ".join(v)))
    print("classes: " + ", ".join(SED_CLASSES))
    print("split: last %d%% of every noise file and speaker %s are TEST-ONLY"
          % (int(SED_NOISE_TEST_CROP * 100), ",".join(SED_CLEAN_TEST)))

    def sample(train=True):
        c = rng.randrange(len(SED_CLASSES))
        if c == 0:                                          # silence: low-level noise floor only
            x = torch.randn((SED_IN[0] + 1) * HOP) * 1e-4
        elif c == 1:
            src = clean_tr if train else clean_te
            x = src[rng.randrange(len(src))]
        else:
            w = noise[SED_CLASSES[c]]
            cut = int(w.numel() * (1 - SED_NOISE_TEST_CROP))
            x = w[:cut] if train else w[cut:]
        return sed_window(x, fb, rng), c

    opt = torch.optim.Adam(m.parameters(), lr=a.lr)
    sch = torch.optim.lr_scheduler.StepLR(opt, max(1, a.epochs // 3), 0.5)
    best = 0.0
    for ep in range(1, a.epochs + 1):
        m.train()
        tot = nb = 0
        for _ in range(a.steps):
            xs, ys = zip(*[sample(True) for _ in range(a.batch)])
            x = torch.stack(xs)
            y = torch.tensor(ys)
            logits, _ = m(x)
            loss = F.cross_entropy(logits, y)
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(), 5.0)
            opt.step()
            tot += float(loss.detach()); nb += 1
        sch.step()
        m.eval()
        with torch.no_grad():
            hit = n = 0
            per = [[0, 0] for _ in SED_CLASSES]
            for _ in range(a.eval_batches):
                xs, ys = zip(*[sample(False) for _ in range(a.batch)])
                p = m(torch.stack(xs))[0].argmax(-1)
                for pi, yi in zip(p.tolist(), ys):
                    per[yi][1] += 1
                    if pi == yi:
                        hit += 1; per[yi][0] += 1
                    n += 1
        acc = hit / max(n, 1)
        tag = ""
        if acc > best:
            best = acc
            torch.save({"kind": "sed", "state": m.state_dict(), "classes": SED_CLASSES,
                        "cfg": dict(pool=a.pool, qat=a.qat)}, a.out)
            tag = "  <- saved"
        print("epoch %3d  loss %.4f  held-out acc %.3f%s" % (ep, tot / max(nb, 1), acc, tag))
    print("best held-out accuracy %.3f -> %s" % (best, a.out))
    print("per-class (last epoch):")
    for cn, (h, t) in zip(SED_CLASSES, per):
        print("  %-24s %3d/%-3d  %.2f" % (cn, h, t, h / max(t, 1)))


# ------------------------------------------------------------------ info / infer
def info(a):
    from zoom_nets import CamppNet, OsdNet, AecNet
    from zoom_nets.aec_pvad import PvadDecision
    from zoom_nets.campp import n_frames, CAMPP_EMBED
    print("=" * 78)
    print("framing: %d Hz, FFT %d, hop %d, %d bins   (Zoom's hop is %d; ours matches ns_core.hpp)"
          % (SR, NFFT, HOP, BINS, R.HOP_ZOOM))
    print(R.LAYER_FIELD_NOTE)
    print()
    x = torch.randn(1, 100, BINS)
    mel = torch.randn(2, n_frames(), 80)

    # (name, model, forward, what data training it needs, trainable on samples/ as-is?)
    rows = []
    d = DenoiseNet()
    with torch.no_grad():
        mk, aux = d(x)
    rows.append(("DenoiseNet 降噪", d, "mask %s + %d aux heads" % (tuple(mk.shape), len(aux or [])),
                 "成对的 (干净, 带噪) 语音", "数据不足,会过拟合"))
    s = Snac()
    with torch.no_grad():
        y, codes, _ = s(x)
    rows.append(("Snac 编解码", s, "%s, %d 路码流 (%.0f bit/帧)"
                 % (tuple(y.shape), len(codes), s.bits_per_frame()),
                 "大量干净语音", "数据远远不足"))
    e = SedNet()
    with torch.no_grad():
        lg, _ = e(torch.randn(2, 100, 40))
    rows.append(("SedNet 事件检测", e, "logits %s" % (tuple(lg.shape),),
                 "带事件标签的音频", "可以 -- 见 train.py sed"))
    c = CamppNet()
    with torch.no_grad():
        emb = c(mel)
    rows.append(("CamppNet 声纹", c, "embedding %s" % (tuple(emb.shape),),
                 "数百至数千个说话人", "不行,samples 只有 5 个说话人"))
    o = OsdNet()
    with torch.no_grad():
        ov = o(mel)
    rows.append(("OsdNet 重叠语音", o, "段级概率 %s" % (tuple(ov.shape),),
                 "标注了重叠区间的多人音频", "不行,无重叠标签"))
    ae = AecNet()
    with torch.no_grad():
        am = ae(x, x)
    rows.append(("AecNet 神经AEC", ae, "mask %s" % (tuple(am.shape),),
                 "(麦克风, 远端参考, 干净) 三元组", "不行,无参考信号录音"))
    # PVAD is not a network -- it is a decision layer over CamppNet. Its constants are read; the
    # only trainable part of the personalised-VAD path is the speaker embedder itself.
    pv = PvadDecision()
    pv.enroll(torch.randn(1, CAMPP_EMBED))
    rows.append(("PvadDecision 个性化VAD", pv,
                 "段级判决 (3 s 窗 / 1.5 s 步进)",
                 "只需注册语音 -- 无网络可训", "不适用 -- 它没有网络,训 CamppNet 即可"))

    print("%-20s %10s  %-34s %s" % ("模型", "参数量", "前向输出", "训练需要的数据"))
    print("-" * 118)
    for name, m, out, need, feasible in rows:
        print("%-20s %10d  %-34s %s" % (name, m.param_count(), out, need))
    print()
    print("%-20s %s" % ("模型", "现有 samples/ 下能否训练"))
    print("-" * 70)
    for name, _, _, _, feasible in rows:
        print("%-20s %s" % (name, feasible))
    print()
    print("CAM++ 窗口 = (48000 - 320) / 160 + 1 = %d 帧 (3 秒 @16 kHz),与二进制一致" % n_frames())

    print("\nHMM classifiers recovered (not part of these nets -- they live in ns_core.hpp):")
    for name in ("ratio_domain", "db_domain"):
        h = R.HMM[name]
        print("  %-13s means %-16s sds %-14s range %-16s ladder %s"
              % (name, h["means"], h["sds"], h["range"], h["level_ladder"]))
    print("  " + R.HMM_LADDER_NOTE)
    print("\ncapture-chain per-frame state (from Zoom's own CSV header):")
    print("  " + ", ".join("%s:%s" % (n, t) for n, t in R.CAPTURE_TELEMETRY))
    print("  " + R.CAPTURE_NOTE)
    if a.quant:
        print("\n--- int8 export report: DenoiseNet ---")
        quant.print_export_report(d)
        print("\n--- int8 export report: Snac ---")
        quant.print_export_report(s, float_layers=("dense1",))


def infer(a):
    ck = torch.load(a.model, map_location="cpu", weights_only=True)
    x = read_wav(a.inp)
    with torch.no_grad():
        if ck["kind"] == "denoise":
            m = DenoiseNet(skips=ck["cfg"]["skips"], aux_heads=ck["cfg"]["aux"],
                           mask_max=ck["cfg"]["mask_max"])
            m.load_state_dict(ck["state"]); m.eval()
            X, mag, mask, _ = run_denoise(m, x)
            y = istft(X * mask, x.numel())
        else:
            m = Snac(dim=BINS, **{k: v for k, v in ck["cfg"].items()
                                  if k in ("width", "latent", "code_dim", "codebook")},
                     n_stages=ck["cfg"]["stages"])
            m.load_state_dict(ck["state"]); m.eval()
            X = stft(x)
            lp, _, _ = m(logp(X.abs()).transpose(0, 1).unsqueeze(0))
            mag = torch.exp(0.5 * lp.squeeze(0).transpose(0, 1))
            y = istft(mag * torch.exp(1j * X.angle()), x.numel())
    write_wav(a.out, y)
    print("wrote %s (%.2f s)" % (a.out, y.numel() / SR))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    here = os.path.dirname(os.path.abspath(__file__))

    def common(p, default_out):
        p.add_argument("--epochs", type=int, default=40)
        p.add_argument("--steps", type=int, default=60)
        p.add_argument("--seg", type=float, default=4.0)
        p.add_argument("--lr", type=float, default=2e-3)
        p.add_argument("--snr-lo", type=float, default=0.0)
        p.add_argument("--snr-hi", type=float, default=15.0)
        p.add_argument("--out", default=os.path.join(here, default_out))

    d = sub.add_parser("denoise"); common(d, "model_denoise.pt")
    d.add_argument("--no-skips", action="store_true")
    d.add_argument("--no-aux", action="store_true")
    d.add_argument("--mask-max", type=float, default=1.0)

    s = sub.add_parser("snac"); common(s, "model_snac.pt")
    s.add_argument("--width", type=int, default=128)
    s.add_argument("--latent", type=int, default=64)
    s.add_argument("--code-dim", type=int, default=8)
    s.add_argument("--codebook", type=int, default=1024)
    s.add_argument("--stages", type=int, default=4)
    s.add_argument("--commit", type=float, default=0.25)

    e = sub.add_parser("sed")
    e.add_argument("--epochs", type=int, default=30)
    e.add_argument("--steps", type=int, default=40)
    e.add_argument("--batch", type=int, default=16)
    e.add_argument("--eval-batches", type=int, default=12)
    e.add_argument("--lr", type=float, default=3e-3)
    e.add_argument("--pool", choices=["avg", "flat"], default="avg")
    e.add_argument("--qat", action="store_true", help="fake-quantise the input (uint8 affine)")
    e.add_argument("--out", default=os.path.join(here, "model_sed.pt"))

    i = sub.add_parser("info"); i.add_argument("--quant", action="store_true")
    f = sub.add_parser("infer")
    f.add_argument("--model", required=True)
    f.add_argument("--kind", choices=["denoise", "snac"], default="denoise")
    f.add_argument("--in", dest="inp", required=True)
    f.add_argument("--out", required=True)

    a = ap.parse_args()
    {"denoise": train_denoise, "snac": train_snac, "sed": train_sed,
     "info": info, "infer": infer}[a.cmd](a)


if __name__ == "__main__":
    main()
