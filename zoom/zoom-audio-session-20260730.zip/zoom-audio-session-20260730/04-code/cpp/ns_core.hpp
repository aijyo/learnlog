// ns_core.hpp — clean-room multi-feature single-channel noise suppressor.
//
// Design provenance: the FEATURE SET is what we recovered from Zoom viper.dll's release
// telemetry format strings (see ../../../zoom-bin-analysis/AUDIO_DEEP_DIVE.html §5):
//
//   noiseProb, prob(a:b), snrProb, ncVoiceProb   -> multi-feature speech probability
//   flatness(x4)                                 -> spectral flatness over 4 bands
//   harmonicity                                  -> harmonic/voicing feature
//   SNR, estimatedNoiseMu2                       -> posterior SNR + recursive noise power estimate
//   bVoiceDecision                               -> VAD decision
//   noiseLevel(x4), noiseCount, NoiseChanged     -> per-band noise tracking + scene-change detect
//   gain, AdaptiveGain                           -> final spectral gain
//
// The ALGORITHM is the classic published speech-enhancement stack (Ephraim-Malah decision-directed
// a-priori SNR, LRT speech-presence probability, MCRA-style SPP-weighted noise tracking, Wiener
// gain) implemented from the literature. No vendor code is reproduced: recovered facts are the
// feature list and the 0..5 aggressiveness-level structure, both of which are facts, not expression.
//
// Zero external dependencies (own radix-2 FFT) so it links into a static standalone exe.

#pragma once
#include <vector>
#include <complex>
#include <cmath>
#include <algorithm>
#include <cstddef>

namespace nsx {

// ---------------------------------------------------------------- FFT
// Iterative in-place radix-2 Cooley-Tukey. n must be a power of two.
class Fft {
public:
    explicit Fft(int n) : n_(n), rev_(n), tw_(n / 2) {
        int bits = 0;
        while ((1 << bits) < n) ++bits;
        for (int i = 0; i < n; ++i) {
            int r = 0;
            for (int b = 0; b < bits; ++b)
                if (i & (1 << b)) r |= 1 << (bits - 1 - b);
            rev_[i] = r;
        }
        for (int i = 0; i < n / 2; ++i) {
            double a = -2.0 * kPi * i / n;
            tw_[i] = std::complex<float>((float)std::cos(a), (float)std::sin(a));
        }
    }

    void forward(std::vector<std::complex<float>>& x) const { run(x, false); }
    void inverse(std::vector<std::complex<float>>& x) const {
        run(x, true);
        const float s = 1.0f / (float)n_;
        for (auto& v : x) v *= s;
    }

    static constexpr double kPi = 3.14159265358979323846;

private:
    void run(std::vector<std::complex<float>>& x, bool inv) const {
        for (int i = 0; i < n_; ++i)
            if (i < rev_[i]) std::swap(x[i], x[rev_[i]]);
        for (int len = 2; len <= n_; len <<= 1) {
            const int half = len >> 1, step = n_ / len;
            for (int i = 0; i < n_; i += len) {
                for (int j = 0; j < half; ++j) {
                    std::complex<float> w = tw_[j * step];
                    if (inv) w = std::conj(w);
                    const std::complex<float> u = x[i + j];
                    const std::complex<float> v = x[i + j + half] * w;
                    x[i + j] = u + v;
                    x[i + j + half] = u - v;
                }
            }
        }
    }
    int n_;
    std::vector<int> rev_;
    std::vector<std::complex<float>> tw_;
};

// ---------------------------------------------------------------- sound events
// Mirrors the architectural role of Zoom's SED submodule (id 3), whose result is pulled by
// GetSEDInfoForDenoise() to steer the suppressor. Zoom's classifier itself is a boundary
// (not reachable statically); this is our own rule-based classifier filling the same slot.
enum class Event { Silence, Speech, Music, StationaryNoise, Transient };

inline const char* event_name(Event e) {
    switch (e) {
        case Event::Silence:         return "silence";
        case Event::Speech:          return "speech";
        case Event::Music:           return "music";
        case Event::StationaryNoise: return "noise";
        case Event::Transient:       return "transient";
    }
    return "?";
}

struct SedInfo {
    Event event = Event::Silence;
    float p_speech = 0.f, p_music = 0.f, p_noise = 0.f, p_transient = 0.f;
    bool  music_protection = false;   // <- MusicProtection
    float pitch_hz = 0.f;
    float pitch_stability = 0.f;      // 1 = rock-steady F0 (music), 0 = varying (speech)
    float modulation = 0.f;           // syllabic-rate envelope depth: high = speech
    float flux = 0.f;                 // spectral flux: spikes on transients
};

// ---------------------------------------------------------------- adaptive threshold
// Zoom's recovered detector derives each feature's decision threshold from a 1000-bin HISTOGRAM of
// that feature, not from a running mean. The difference is not cosmetic:
//
//   running mean  : threshold == the feature's own average. On any stationary input the feature
//                   converges to its average, so (feature - threshold) -> 0 and the mapped
//                   probability sits at 0.5 forever. MEASURED on our first implementation:
//                   pure noise P = 0.519, pure speech P = 0.568 -- essentially no discrimination,
//                   which capped suppression at ~5 dB (NOTES.md 9).
//   histogram     : distribution-aware. On a speech+noise mixture the feature is BIMODAL, and a
//                   threshold placed between the two modes separates them. Just as importantly,
//                   a histogram reveals when a feature is NOT bimodal, i.e. carries no information
//                   this scene -- then it can be dropped from the fusion instead of voting 0.5.
//
// Bin layout follows the recovered 1000-bin size; the per-feature range is ours (Zoom's bin widths
// are calibrated to its own feature scaling, which we do not have -- see the note at the tanh map).
// 1000-bin feature histogram, matching Zoom sub_1801DD530 exactly.
//
// Accumulate (flag 0 in the binary) runs every frame: idx = feature / binSize, and a value outside
// [0, binSize*1000) is DROPPED, not clamped. Extract (flag 1) runs once per window and then clears.
//
// The parameter block feeding this was recovered wholesale: sub_1801DD530 reads it from a2+1124..1200,
// and sub_1801E45C0 (the initialiser) writes exactly that range as a1[6485..6504] -- a2 == a1+24816,
// so a2+1124 == a1+25940 == a1[6485]. All twenty values decode to WebRTC NS's published
// NSParaExtract defaults, value for value, which identifies the detector rather than just resembling
// it: binSize 0.1/0.05/0.1, factors 1.2/0.9, thresPosSpecFlat 0.6, peak spacing 0.1/0.2, peak weight
// 0.5/0.5, thresFluctLrt 0.05, and the six min/max threshold bounds.
class FeatureHistogram {
public:
    static constexpr int kBins = 1000;          // [Zoom: 1000-bin histogram]

    void configure(float bin_size) {
        bin_ = std::max(bin_size, 1e-6f);
        h_.assign(kBins, 0);
        n_ = 0;
    }

    // Out-of-range is dropped. That is deliberate in the original and it matters: a feature that
    // spends most of its time past the top bin simply stops contributing, which is one of the ways
    // "this feature is uninformative" gets expressed.
    void add(float v) {
        if (h_.empty() || v < 0.f || v >= bin_ * (float)kBins) return;
        h_[(size_t)(int)(v / bin_)] += 1;
        ++n_;
    }

    int   count() const { return n_; }
    float bin_size() const { return bin_; }
    void  clear() { std::fill(h_.begin(), h_.end(), 0); n_ = 0; }

    float centre(int b) const { return ((float)b + 0.5f) * bin_; }

    // ---- LRT path: the fluctuation measure, then a threshold from the low part's mean ----
    // v42 = E[x^2] - E[x] * mean(x | x <= low_bound).  Small => the feature barely moves => the LRT
    // carries no speech/noise information this window.
    float fluctuation(float low_bound, int window, float& mean_low) const {
        double sum = 0.0, sumsq = 0.0, low_sum = 0.0;
        long   low_n = 0;
        for (int b = 0; b < kBins; ++b) {
            const long c = h_[(size_t)b];
            if (!c) continue;
            const float ctr = centre(b);
            if (low_bound >= ctr) { low_n += c; low_sum += (double)c * ctr; }
            sum   += (double)c * ctr;
            sumsq += (double)c * ctr * ctr;
        }
        mean_low = low_n > 0 ? (float)(low_sum / (double)low_n) : 0.f;
        const double N = (double)std::max(window, 1);
        return (float)(sumsq / N - (sum / N) * (double)mean_low);
    }

    // ---- flatness / spectral-difference path: two-peak search ----
    // Tracks the tallest and second-tallest bins. If their centres are CLOSE (< spacing) and the
    // runner-up is tall enough (> peak_weight * tallest), the two are merged: counts add and the
    // threshold becomes their midpoint. Reports the resulting count so the caller can apply the
    // minimum-count test.
    void two_peaks(float spacing, float peak_weight, float& thr, long& peak_count) const {
        long c1 = 0, c2 = 0;
        float p1 = 0.f, p2 = 0.f;
        for (int b = 0; b < kBins; ++b) {
            const long c = h_[(size_t)b];
            const float ctr = centre(b);
            if (c > c1)      { c2 = c1; p2 = p1; c1 = c; p1 = ctr; }
            else if (c > c2) { c2 = c;  p2 = ctr; }
        }
        thr = p1;
        peak_count = c1;
        if (spacing > std::fabs(p2 - p1) && (float)c2 > (float)c1 * peak_weight) {
            peak_count = c1 + c2;
            thr = (p1 + p2) * 0.5f;
        }
    }

private:
    float bin_ = 0.1f;
    std::vector<long> h_;
    int n_ = 0;
};

// ------------------------------------------------------------- two-state HMM
// A two-state Gaussian HMM over one scalar feature: state 0 = noise, state 1 = speech.
//
// Recovered from viperex.dll's denoise module (NOTES.md 19.15). Its config function installs TWO of
// these, and the initialiser sub_1800DC1F0 makes the structure unambiguous:
//
//     this[0]=N=2; this[4]=M=1;
//     for (i<N) this[16+4i] = 1.0f/N;              // uniform initial prior
//     this[24..28] = this[32..36] = means[2];      // means stored TWICE: current + init
//     this[60] = sd[0]*sd[0]; this[64] = sd[1]*sd[1];   // squared on the way in => sd, not variance
//     if (a10) { this[84..96] = {0.99, 0.01, 0.01, 0.99}; this[100..108] = 0.5; }
//
// Why this is worth having over the tanh-vs-threshold map we shipped: the tanh is memoryless, so a
// single noisy frame swings the vote by its full range. The Markov step with 0.99 self-transition
// makes a state change need sustained evidence, which is exactly the behaviour missing on transient
// noise (NOTES.md 13/15: 0.12-1.75 dB on blowing/keyboard). The "means stored twice" detail is why
// they adapt at runtime rather than being fixed thresholds.
//
// The MEANS here are ours, not Zoom's. Zoom's ({25,45} in a ratio domain, {-44,-25} dB) are
// calibrated to its own feature scaling -- the same trap that made its tanh widths 4/8 collapse our
// detector (see the note at tanh_feature). What transfers is the STRUCTURE and one scale-free
// ratio: Zoom's sd is ~0.5x the inter-state gap (12 vs 20, 10 vs 19). So callers pass means read off
// our own measured feature distributions and sd defaults to half the gap.
class GaussianHmm2 {
public:
    // lo/hi clamp the feature the way Zoom's a9[] range does ({12,72} and {-55,-15}).
    void configure(float mu_noise, float mu_speech, float lo, float hi,
                   float sd_scale = 0.5f, float adapt = 0.002f, float self_trans = 0.99f) {
        mu_[0] = mu_init_[0] = mu_noise;
        mu_[1] = mu_init_[1] = mu_speech;
        const float gap = std::fabs(mu_speech - mu_noise);
        sd_[0] = sd_[1] = std::max(gap * sd_scale, 1e-6f);
        lo_ = std::min(lo, hi);
        hi_ = std::max(lo, hi);
        adapt_ = std::clamp(adapt, 0.f, 0.5f);
        a_stay_ = std::clamp(self_trans, 0.5f, 0.99999f);
        reset();
    }

    void reset() {
        post_[0] = post_[1] = 0.5f;         // Zoom: this[100..108] = 0.5
        mu_[0] = mu_init_[0];
        mu_[1] = mu_init_[1];
        primed_ = false;
    }

    // One forward step. Returns P(speech | observations up to now).
    float update(float feature) {
        const float f = std::clamp(feature, lo_, hi_);
        // Gaussian likelihood per state. The normalising 1/(sd*sqrt(2pi)) is kept because the two
        // states may end up with different sd once they adapt, and then it no longer cancels.
        float lik[2];
        for (int s = 0; s < 2; ++s) {
            const float z = (f - mu_[s]) / sd_[s];
            lik[s] = std::exp(-0.5f * z * z) / sd_[s];
        }
        // Markov prediction: pred_s = sum_j post_j * A[j][s], A = [[p,1-p],[1-p,p]]
        const float sw = 1.f - a_stay_;
        const float pred0 = post_[0] * a_stay_ + post_[1] * sw;
        const float pred1 = post_[1] * a_stay_ + post_[0] * sw;
        // Aggressiveness bias, as log-odds against the speech state. Shifting the decision point is
        // how Zoom's four-entry per-level table acts; expressing it as prior odds keeps the tracked
        // means untouched, so raising the level cannot drag the adaptation with it.
        float n0 = pred0 * lik[0];
        float n1 = pred1 * lik[1] * std::exp(-bias_);
        const float z = n0 + n1;
        if (z > 1e-30f) { post_[0] = n0 / z; post_[1] = n1 / z; }
        // else: likelihoods underflowed (feature far from both means) -- hold the previous posterior
        // rather than resetting to 0.5, which would erase the temporal evidence we just paid for.

        // Adaptive means, posterior-weighted. This is what the duplicated current/init pair implies:
        // the current mean tracks, the init copy stays as the cold-start value for reset().
        if (adapt_ > 0.f) {
            if (!primed_) { primed_ = true; }
            for (int s = 0; s < 2; ++s) mu_[s] += adapt_ * post_[s] * (f - mu_[s]);
            // Keep the states ordered and separated, else both collapse onto the dominant class and
            // the classifier stops discriminating -- the same failure the SelfAdaptive tanh had.
            const float gap = std::fabs(mu_init_[1] - mu_init_[0]);
            const float min_gap = 0.25f * gap;
            if (mu_init_[1] >= mu_init_[0]) {
                if (mu_[1] - mu_[0] < min_gap) {
                    const float mid = 0.5f * (mu_[0] + mu_[1]);
                    mu_[0] = mid - 0.5f * min_gap;
                    mu_[1] = mid + 0.5f * min_gap;
                }
            } else if (mu_[0] - mu_[1] < min_gap) {
                const float mid = 0.5f * (mu_[0] + mu_[1]);
                mu_[1] = mid - 0.5f * min_gap;
                mu_[0] = mid + 0.5f * min_gap;
            }
        }
        return post_[1];
    }

    // Shift the decision point without touching the tracked means. This is where the aggressiveness
    // ladder acts in Zoom: sub_1800DC150 installs a FOUR-entry table per classifier
    // ({24,30,36,42} and {-48,-44,-40,-36} dB) -- one entry per UI level. Note where it lands:
    // on the CLASSIFIER's threshold, not on the gain floor, which is where our own level knob acted.
    void set_bias(float db_or_units) { bias_ = db_or_units; }

    float mu_noise()  const { return mu_[0]; }
    float mu_speech() const { return mu_[1]; }
    float posterior() const { return post_[1]; }

private:
    float mu_[2]      = {0.f, 1.f};
    float mu_init_[2] = {0.f, 1.f};
    float sd_[2]      = {0.5f, 0.5f};
    float post_[2]    = {0.5f, 0.5f};
    float lo_ = -1e30f, hi_ = 1e30f;
    float adapt_  = 0.002f;
    float a_stay_ = 0.99f;      // Zoom: 0.99 self-transition
    float bias_   = 0.f;
    bool  primed_ = false;
};

// How each feature's decision threshold is obtained. Selectable so the four can be A/B'd on the
// same audio -- the first of them is the one that measured badly, kept for reproducibility of
// NOTES.md's earlier numbers.
enum class ThreshMode {
    SelfAdaptive,   // threshold = EMA of the feature itself. OURS, refuted: collapses to P=0.5.
    Absolute,       // fixed thresholds + tanh(width*(f - thr)) applied directly  [Zoom/WebRTC form]
    Histogram,      // Absolute, refined per window by the 1000-bin histogram     [Zoom, recovered]
    Hmm             // two-state Gaussian HMM per feature      [Zoom viperex, NOTES.md 19.15]
};

// ---------------------------------------------------------------- telemetry
// Mirrors the quantities Zoom's release build logs, so our behaviour is inspectable the same way.
struct Telemetry {
    float speech_prob = 0.f;   // fused P(speech) for the frame          <- prob
    float snr_prob    = 0.f;   // LRT/SNR-derived probability            <- snrProb
    float flat_prob   = 0.f;   // spectral-flatness-derived probability  <- noiseProb (inverted)
    float diff_prob   = 0.f;   // spectral-template-difference prob      <- diff
    float spec_diff   = 0.f;   // raw normalised template residual       <- diff
    // The three RAW feature values and the thresholds actually in force. Without these the absolute
    // thresholds can only be guessed; with them they can be read off the measured distributions.
    float lrt_avg     = 0.f;   // frame-mean log-likelihood ratio         <- a2[145] in E3380
    float flat_avg    = 0.f;   // 4-band mean spectral flatness
    float thr_lrt     = 0.f;
    float thr_flat    = 0.f;
    float thr_diff    = 0.f;
    // Runtime fusion weights (Zoom a2[8..10]). Exposed because "which feature is actually voting"
    // is not inferable from the votes alone -- an uninformative feature gets weight 0, not a
    // neutral vote, so the same P can come from very different mixtures.
    float w_lrt       = 1.f;
    float w_flat      = 0.f;
    float w_diff      = 0.f;
    float xi_flatness = 1.f;   // flatness of the (1+xi)^2 spectrum      <- Zoom DBD10
    float harmonicity = 0.f;   // 0..1 voicing strength                  <- harmonicity
    float snr_db      = 0.f;   // frame a-posteriori SNR (dB)            <- SNR
    float gain        = 1.f;   // mean applied spectral gain             <- gain
    float makeup      = 1.f;   // post-gain level normalisation factor   <- Zoom E56E0 v61
    float flatness[4] = {0, 0, 0, 0};   //                               <- flatness(x4)
    // Mean estimated noise POWER per band, in dB. NOT dBFS: noise_[] holds unnormalised FFT power,
    // so these values routinely exceed 0 dB (measured range on real input: -15 .. +25). They are
    // only meaningful relative to each other -- across bands, and over time within one run.
    float noise_level[4] = {0, 0, 0, 0}; // per-band noise power (dB, rel) <- noiseLevel(x4)
    bool  voice       = false; //                                        <- bVoiceDecision
    int   noise_changed = 0;   // 1 on the frame a shift is declared     <- NoiseChanged
    long  noise_count = 0;     // # of noise-scene changes so far        <- noiseCount
    SedInfo sed;               //                                        <- GetSEDInfoForDenoise()
};

// ---------------------------------------------------------------- SED
// Rule-based acoustic-event classifier. It occupies the same architectural slot as Zoom's SED:
// classify WHAT the sound is, so the suppressor can decide HOW HARD to act. The discriminating
// idea is that speech, music and stationary noise differ in *time structure*, not just spectrum:
//
//   stationary noise : flat spectrum, low flux, no pitch, no envelope modulation
//   speech           : pitch present but drifting, deep syllabic gaps (2-8 Hz modulation)
//   music            : pitch present and STABLE, sustained (shallow modulation)
//   transient        : sudden broadband flux spike
//
// NOTE: this is a hand-designed classifier, not a learned model. Zoom's SED may well be learned;
// we could not reach it (see AUDIO_DEEP_DIVE.html §8.1/§8.2). Same role, different mechanism.
class SoundEventDetector {
public:
    explicit SoundEventDetector(int sample_rate) : sr_(sample_rate) {}

    // Called once per analysis frame with features already computed by the suppressor.
    SedInfo update(float frame_energy_db, float harmonicity, float pitch_hz,
                   float flatness_avg, const std::vector<float>& mag, float hop_seconds) {
        // ---- spectral flux (onset / transient cue) ----
        float flux = 0.f;
        if (prev_mag_.size() == mag.size()) {
            float num = 0.f, den = 1e-12f;
            for (size_t k = 0; k < mag.size(); ++k) {
                const float d = mag[k] - prev_mag_[k];
                if (d > 0.f) num += d;
                den += mag[k];
            }
            flux = num / den;
        }
        prev_mag_ = mag;

        // ---- envelope history for syllabic modulation ----
        const int win = std::max(8, (int)std::lround(1.0f / std::max(hop_seconds, 1e-4f))); // ~1 s
        eng_hist_.push_back(frame_energy_db);
        if ((int)eng_hist_.size() > win) eng_hist_.erase(eng_hist_.begin());

        float modulation = 0.f;
        if ((int)eng_hist_.size() >= win / 2) {
            float mn = 1e9f, mx = -1e9f, mean = 0.f;
            for (float e : eng_hist_) { mn = std::min(mn, e); mx = std::max(mx, e); mean += e; }
            mean /= (float)eng_hist_.size();
            // depth of the envelope in dB, normalised: speech has deep word gaps
            modulation = std::clamp((mx - mn) / 25.f, 0.f, 1.f);
        }

        // ---- pitch stability over ~0.5 s ----
        if (pitch_hz > 0.f) {
            pitch_hist_.push_back(pitch_hz);
            if ((int)pitch_hist_.size() > win / 2) pitch_hist_.erase(pitch_hist_.begin());
        }
        float stability = 0.f;
        if (pitch_hist_.size() >= 6) {
            double m = 0.0;
            for (float p : pitch_hist_) m += std::log(std::max(p, 1e-3f));
            m /= pitch_hist_.size();
            double v = 0.0;
            for (float p : pitch_hist_) {
                const double d = std::log(std::max(p, 1e-3f)) - m;
                v += d * d;
            }
            v = std::sqrt(v / pitch_hist_.size());       // std of log-F0 (semitone-ish)
            stability = (float)std::clamp(1.0 - v / 0.25, 0.0, 1.0);
        }

        SedInfo s;
        s.pitch_hz = pitch_hz;
        s.pitch_stability = stability;
        s.modulation = modulation;
        s.flux = flux;

        // ---- soft scores ----
        const bool silent = frame_energy_db < silence_db_;
        s.p_transient = std::clamp((flux - 0.35f) * 4.0f, 0.f, 1.f);
        s.p_music  = std::clamp(harmonicity * 1.2f, 0.f, 1.f)
                   * stability
                   * std::clamp(1.2f - modulation * 1.6f, 0.f, 1.f);
        s.p_speech = std::clamp(harmonicity * 1.6f, 0.f, 1.f)
                   * std::clamp(modulation * 1.4f, 0.f, 1.f)
                   * std::clamp(1.1f - stability * 0.8f, 0.f, 1.f);
        s.p_noise  = std::clamp(flatness_avg * 1.3f, 0.f, 1.f)
                   * std::clamp(1.0f - harmonicity * 2.0f, 0.f, 1.f)
                   * std::clamp(1.0f - flux * 1.5f, 0.f, 1.f);

        // ---- decision with hysteresis (avoid flapping between events) ----
        Event cand;
        if (silent)                                       cand = Event::Silence;
        else if (s.p_transient > 0.5f)                    cand = Event::Transient;
        else if (s.p_music > s.p_speech && s.p_music > 0.25f)  cand = Event::Music;
        else if (s.p_speech > 0.20f)                      cand = Event::Speech;
        else                                              cand = Event::StationaryNoise;

        if (cand == cur_) {
            run_ = std::min(run_ + 1, 100);
        } else if (++cand_run_ >= (cand == Event::Transient ? 1 : 6)) {
            cur_ = cand; run_ = 0; cand_run_ = 0;
        }
        if (cand == cur_) cand_run_ = 0;
        s.event = cur_;

        // MusicProtection latches on once music is confidently held, and releases slowly.
        if (cur_ == Event::Music && run_ > 8) music_hold_ = 60;
        else if (music_hold_ > 0) --music_hold_;
        s.music_protection = music_hold_ > 0;
        return s;
    }

    void set_silence_threshold_db(float db) { silence_db_ = db; }

private:
    int sr_;
    float silence_db_ = -65.f;
    std::vector<float> prev_mag_, eng_hist_, pitch_hist_;
    Event cur_ = Event::Silence;
    int run_ = 0, cand_run_ = 0, music_hold_ = 0;
};

// ---------------------------------------------------------------- suppressor
class NoiseSuppressor {
public:
    // level: 0..5 aggressiveness, mirroring the 6 internal NS levels recovered from
    // viper's SetNsStatus mode table (ns->vtbl+216(level), level in 0..5).
    NoiseSuppressor(int sample_rate, int level = 2, int fft_size = 512)
        : sr_(sample_rate), n_(fft_size), hop_(fft_size / 2), bins_(fft_size / 2 + 1),
          fft_(fft_size),
          win_(fft_size),
          noise_(bins_, 0.f), prev_gain_(bins_, 1.f), prev_gamma_(bins_, 1.f),
          spec_(fft_size), tmpl_(bins_, 0.f), lrt_(bins_, 0.f), sed_(sample_rate),
          gain_(bins_, 1.f), gsmooth_(bins_, 1.f), gt_(bins_, 1.f) {
        set_level(level);
        spp_.assign((size_t)bins_, 0.f);
        noise_slow_.assign((size_t)bins_, 0.f);
        // Histogram ranges. The bin COUNT (1000) is Zoom's recovered value; the ranges are ours,
        // chosen to cover what these features actually reach on real audio:
        //   Lambda      : the frame-mean LRT. Sits near 0.3 on stationary noise, tens on speech.
        //   flatness    : geometric/arithmetic spectral-mean ratio, bounded [0,1] by construction.
        //   spec-diff   : normalised template residual, ~0 on the learned noise, O(1) on speech.
        hist_lrt_.configure(kBinSizeLrt);     // range [0, 100)
        hist_flat_.configure(kBinSizeFlat);   // range [0, 50)
        hist_diff_.configure(kBinSizeDiff);   // range [0, 100)
        // sqrt-Hann: analysis*synthesis = Hann, which is COLA at 50% overlap.
        for (int i = 0; i < n_; ++i) {
            const double h = 0.5 - 0.5 * std::cos(2.0 * Fft::kPi * i / n_);
            win_[i] = (float)std::sqrt(h);

        // Full-scale reference for the per-bin dBFS floor: the bin power an amplitude-1.0
        // sinusoid parked on a bin centre produces through THIS window. Lets us express the
        // suppression floor as an absolute dBFS level the way Zoom DB830 does.
        {
            double ws = 0.0;
            for (int i = 0; i < n_; ++i) ws += win_[i];
            fs_bin_pow_ = (float)std::max((ws * 0.5) * (ws * 0.5), 1e-20);
        }
        }
        // 4 analysis bands (matches the 4 flatness / 4 noiseLevel telemetry slots)
        const float edges_hz[5] = {0.f, 500.f, 1500.f, 4000.f, 1e9f};
        for (int b = 0; b < 4; ++b) {
            band_lo_[b] = hz_to_bin(edges_hz[b]);
            band_hi_[b] = std::min(bins_ - 1, hz_to_bin(edges_hz[b + 1]));
            if (band_hi_[b] <= band_lo_[b]) band_hi_[b] = std::min(bins_ - 1, band_lo_[b] + 1);
        }
    }

    // Aggressiveness. Higher level = lower gain floor + stronger over-subtraction.
    void set_level(int level) {
        level_ = std::clamp(level, 0, 5);
        // Gain floors, re-derived from REAL data (NOTES.md 5.8). The old ladder
        // {-6,-9,-12,-15,-18,-21} was set by intuition; on real speech its deep floors crushed
        // the weak fricatives/consonants that carry intelligibility. Sweeping the level-2 floor:
        //   floor   dSTOI    dESTOI   dLSD
        //   -9 dB  -0.0082  +0.0051  -1.75
        //   -6 dB  -0.0046  +0.0046  -1.60   <- chosen: halves the STOI damage, keeps ESTOI/LSD
        //   -3 dB  -0.0008  +0.0010  -0.90   <- dSTOI looks great but the denoiser stopped working
        // NOTE: only LEVEL 2 was measured. The other rungs are shifted to keep a monotonic ladder
        // around that anchor and are NOT individually evidence-backed yet.
        // Ladder extended after measuring FREQUENCY SELECTIVITY rather than STOI. The old table
        // topped out at -15 dB, and the per-band attenuation there is nearly flat -- on
        // AirConditioner @5 dB the spread across seven bands was only 4.4 dB, i.e. every band lost
        // the same amount. That is a volume control, not a denoiser, and it is exactly what a
        // listener reports as "still hear the hum, everything just got quieter".
        //
        // Spread across bands (0-125 Hz .. 4-8 kHz), gaps only, AirConditioner @5 dB:
        //   floor  -6 dB -> 0.5 dB spread   (flat: pure level cut)
        //   floor -15 dB -> 4.4 dB
        //   floor -25 dB -> 11.5 dB         (selective: low bands lose 23.6, top band 12.3)
        //   floor -35 dB -> 14.9 dB
        //   floor -45 dB -> 16.2 dB         (saturating)
        //
        // The old table was re-derived in NOTES.md 5.8 by maximising STOI on one sample, and STOI
        // rewards leaving the signal alone -- which drove the whole ladder into the flat regime.
        // Level 2 stays close to where it was so the conservative default barely moves; the top of
        // the ladder now reaches the regime where suppression is actually selective.
        static const float floor_db[6] = {-4.f, -6.f, -9.f, -14.f, -20.f, -27.f};
        static const float oversub[6]  = {1.00f, 1.10f, 1.25f, 1.40f, 1.60f, 1.80f};
        floor_base_db_ = floor_db[level_];
        oversub_ = oversub[level_];
        apply_floor();
        // The level also moves the HMM detector's decision point, which is where Zoom's ladder acts
        // (four entries per classifier, ~0.25x the inter-state gap per step -> ~1.0 in log-odds for
        // sd = 0.5x gap). Spread over six rungs and centred on level 2 that is 0.6 per step.
        // Inert unless ThreshMode::Hmm is selected.
        set_hmm_level_bias(0.6f * (float)(level_ - 2));
    }

    void apply_floor() { gain_floor_ = std::pow(10.f, (floor_base_db_ + floor_off_db_) / 20.f); }
    int level() const { return level_; }
    // Effective values AFTER set_level()'s table and any explicit override, so a caller can
    // display what is actually in force rather than what it last asked for.
    float floor_db() const { return floor_base_db_ + floor_off_db_; }
    float oversub()  const { return oversub_; }

    // Streaming: push `hop` samples, pop `hop` denoised samples (algorithmic latency = fft_size).
    // Returns false until the first full frame has been buffered.
    bool process_hop(const float* in, float* out) {
        inq_.insert(inq_.end(), in, in + hop_);
        if ((int)inq_.size() < n_) {                 // still filling the first window
            std::fill(out, out + hop_, 0.f);
            return false;
        }
        std::vector<float> frame(n_);
        for (int i = 0; i < n_; ++i) frame[i] = inq_[i] * win_[i];
        process_frame(frame);
        if ((int)ola_.size() < n_) ola_.assign(n_, 0.f);
        for (int i = 0; i < n_; ++i) ola_[i] += frame[i] * win_[i];
        std::copy(ola_.begin(), ola_.begin() + hop_, out);
        ola_.erase(ola_.begin(), ola_.begin() + hop_);
        ola_.resize(n_, 0.f);
        inq_.erase(inq_.begin(), inq_.begin() + hop_);
        return true;
    }
    int hop_size() const { return hop_; }

    // Offline convenience: process a whole buffer, return the denoised signal.
    // Offset-based overlap-add: output sample i corresponds to input sample i, i.e. ZERO net
    // delay. process_hop() is the streaming path and necessarily lags, so any metric computed
    // against a clean reference must use THIS function -- an unaligned comparison makes SI-SDR
    // meaningless (measured: -43 dB from a one-frame shift alone).
    // `tel` optionally collects per-frame telemetry from this same aligned pass.
    std::vector<float> process_all(const std::vector<float>& x, std::vector<Telemetry>* tel = nullptr) {
        std::vector<float> y(x.size(), 0.f);
        std::vector<float> acc(x.size() + n_, 0.f);
        std::vector<float> frame(n_);
        const int frames = (int)((x.size() >= (size_t)n_) ? (x.size() - n_) / hop_ + 1 : 0);
        prob_hist_.clear();
        prob_hist_.reserve(frames > 0 ? frames : 0);
        for (int f = 0; f < frames; ++f) {
            const int off = f * hop_;
            for (int i = 0; i < n_; ++i) frame[i] = x[off + i] * win_[i];
            process_frame(frame);
            prob_hist_.push_back(tm_.speech_prob);
            if (tel) tel->push_back(tm_);
            for (int i = 0; i < n_; ++i) acc[off + i] += frame[i] * win_[i];
        }
        for (size_t i = 0; i < y.size(); ++i) y[i] = acc[i];
        return y;
    }

    const Telemetry& telemetry() const { return tm_; }

    // Power-law (1/f^alpha) noise-floor cold start, as Zoom does it. ON by default; turn off to
    // fall back to a flat running-mean init. See initialise_noise() for the measured trade-off.
    void set_powerlaw_init(bool on) { powerlaw_init_ = on; }

    // Mean |makeup[t] - makeup[t-1]| over the run: how much the raw per-frame
    // makeup scalar jitters. Large values support the temporal-smearing hypothesis.
    float makeup_jitter() const { return mk_jit_n_ ? mk_jit_sum_ / mk_jit_n_ : 0.f; }

    // Speech-probability smoothing coefficient. Zoom uses 0.1; our synthetic-tuned
    // default is 0.3. Lower = smoother gain across frames = less musical noise.
    void set_alpha_p(float a) { alpha_p_ = std::clamp(a, 0.01f, 1.f); }

    // Post-gain level normalisation (Zoom E56E0). Suspected of harming inter-frame continuity
    // because it is a whole-frame scalar: if it jumps between frames it amplitude-modulates the
    // output. Switchable so that can be tested rather than assumed.
    void set_makeup_enabled(bool on) { makeup_on_ = on; }

    // Inter-frame smoothing for the makeup gain. 1.0 = none (raw per-frame scalar, as recovered).
    // Suspicion: an unsmoothed per-frame scalar amplitude-modulates the output, which shows up as
    // better segSNR (level restored) but worse intelligibility (temporal smearing).
    void set_makeup_smoothing(float a) { makeup_alpha_ = std::clamp(a, 0.01f, 1.f); }

    // Absolute dBFS suppression floor, as Zoom DB830 does it. Output bins are not
    // pushed below this level, so the allowed attenuation becomes level-dependent.
    void set_abs_floor(bool on, float dbfs = -65.f) { abs_floor_on_ = on; abs_floor_dbfs_ = dbfs; }

    // Gain smoothing across FREQUENCY: triangular kernel over `taps` bins (odd; 1 = off).
    void set_freq_smoothing(int taps) { freq_taps_ = (taps < 3) ? 1 : (taps | 1); }

    // Gain smoothing across TIME, per bin: 1.0 = off, smaller = smoother.
    void set_time_smoothing(float a) { time_alpha_ = std::clamp(a, 0.05f, 1.f); }

    // Raise/lower the spectral gain floor relative to the level default, in dB. Zoom bounds
    // suppression in the dB domain with a -65 dBFS absolute floor (DB830); we use a plain linear
    // floor, which may crush the weak speech (fricatives/consonants) that carries intelligibility.
    void set_floor_offset_db(float db) { floor_off_db_ = db; apply_floor(); }

    // ---- every remaining recovered parameter, exposed for per-mechanism auditing ----
    enum class GainLaw { Posterior, Wiener };
    void set_gain_law(GainLaw g)      { gain_law_ = g; }          // Wiener is correct; see the loop
    // Threshold source for the three fused features. Absolute/Histogram are the Zoom form; the
    // SelfAdaptive default we shipped first pins every probability at 0.5 (NOTES.md 9).
    void set_thresh_mode(ThreshMode m) { thresh_mode_ = m; if (m == ThreshMode::Hmm) configure_hmm(); }

    // 0 = lrt/flat/diff (what we shipped), 1 = snr_db / xi_flatness(dB) / harmonicity.
    // The measured d-prime table is in configure_hmm; the short version is that the shipped triple
    // are the three WORST separators of the eight features we compute.
    // P-driven adaptive floor: up to extra_db of extra depth, faded in as P falls below knee.
    // OFF by default (extra_db = 0). See the note at its use site for why this, and not DB830's
    // limiter, is the lever the measurements point at.
    void set_adaptive_floor(float extra_db, float knee) {
        afloor_extra_db_ = std::max(0.f, extra_db);
        afloor_knee_     = std::clamp(knee, 0.f, 1.f);
    }
    void set_feature_set(int s) { feature_set_ = (s == 1) ? 1 : 0; }
    int  feature_set() const { return feature_set_; }
    void set_feature_thresholds(float thr_snr, float sc_snr, float thr_xif, float sc_xif,
                                float thr_hrm, float sc_hrm) {
        fthr_snr_ = thr_snr; fsc_snr_ = std::max(sc_snr, 1e-3f);
        fthr_xif_ = thr_xif; fsc_xif_ = std::max(sc_xif, 1e-3f);
        fthr_hrm_ = thr_hrm; fsc_hrm_ = std::max(sc_hrm, 1e-3f);
    }

    // ThreshMode::Hmm knobs. Defaults are Zoom's recovered dynamics (0.99 self-transition,
    // sd = 0.5x gap, adapt 0.002); the state MEANS come from our own measured medians because
    // Zoom's are in its feature units (NOTES.md 19.15).
    void set_hmm_dynamics(float self_trans, float sd_scale, float adapt) {
        hmm_stay_     = std::clamp(self_trans, 0.5f, 0.99999f);
        hmm_sd_scale_ = std::clamp(sd_scale, 0.05f, 4.f);
        hmm_adapt_    = std::clamp(adapt, 0.f, 0.5f);
        if (thresh_mode_ == ThreshMode::Hmm) configure_hmm();
    }
    // Per-level log-odds bias against the speech state. Zoom's ladder is FOUR entries per
    // classifier ({24,30,36,42} and {-48,-44,-40,-36} dB), i.e. ~0.25x the inter-state gap per
    // step, which for sd = 0.5x gap is ~1.0 in log-odds. Spread over our six levels and centred on
    // level 2 that is 0.6 per step. NOTE the difference from our own design: Zoom's level knob
    // moves the DETECTOR's decision point, ours moved the gain floor.
    void set_hmm_level_bias(float b) {
        hmm_level_bias_ = b;
        hmm_lrt_.set_bias(b); hmm_flat_.set_bias(b); hmm_diff_.set_bias(b);
    }
    float hmm_level_bias() const { return hmm_level_bias_; }
    float hmm_mu_noise_lrt()  const { return hmm_lrt_.mu_noise(); }
    float hmm_mu_speech_lrt() const { return hmm_lrt_.mu_speech(); }

    void set_thr_lrt(float v)  { thr_lrt_ = v;  if (!hist_ok_lrt_)  eff_thr_lrt_ = v; }
    void set_thr_flat(float v) { thr_flat_ = v; if (!hist_ok_flat_) eff_thr_flat_ = v; }
    void set_thr_diff(float v) { thr_diff_ = v; if (!hist_ok_diff_) eff_thr_diff_ = v; }
    void set_hist_window(int frames) { hist_window_ = std::max(32, frames); }
    void set_harmonicity(float thr, float scale) {
        thr_harm_ = thr; sc_harm_ = std::max(scale, 1e-3f);
    }
    void set_feature_scales(float lrt, float flat, float diff) {
        sc_lrt_  = std::max(lrt,  1e-3f);
        sc_flat_ = std::max(flat, 1e-3f);
        sc_diff_ = std::max(diff, 1e-3f);
    }
    void set_zoom_noise_update(bool on) { zoom_noise_update_ = on; }
    // alpha_dd derived from the previous gain rather than fixed   [Zoom DB830]
    void set_adaptive_alpha_dd(bool on) { adaptive_alpha_dd_ = on; }
    // gain may rise at most 3x per frame                          [Zoom E16C0]
    void set_attack_limit(bool on) { attack_limit_ = on; }
    // DB830's dB-domain gain limiter: target level + max-attenuation bound + 5 dB pedestal.
    void set_zoom_gain_limit(bool on) { zoom_gain_limit_ = on; }
    // DC360's single-range magnitude flatness vs our 4-band mean.
    void set_dc360_flatness(bool on) { dc360_flatness_ = on; }
    // The speech/noise probability clamps (ours, refuted). Music protection is separate and stays.
    void set_sed_prob_clamp(bool on) { sed_prob_clamp_ = on; }
    // Lower bound of the frame-presence multiplier. 1.0 removes the multiply (Zoom's shape).
    void set_presence_lo(float v) { presence_lo_ = std::clamp(v, 0.f, 1.f); }
    // Number of bands the gain is computed on before being interpolated to bins. 0 = per-bin
    // (ours). Zoom's band count is not recovered; this is the knob to sweep.  [Zoom E16C0]
    void set_gain_bands(int n) { gain_bands_ = std::max(0, n); }
    void set_zoom_target_db(float db) { zoom_target_db_ = db; }
    void set_level_offset_db(float db) { lvl_off_db_ = db; }
    void set_zoom_limit_db(float db) { zoom_limit_db_ = db; }
    // Effective thresholds after any histogram refinement, for telemetry/UI display.
    float eff_thr_lrt()  const { return eff_thr_lrt_; }
    float eff_thr_flat() const { return eff_thr_flat_; }
    float eff_thr_diff() const { return eff_thr_diff_; }
    bool  hist_ok_lrt()  const { return hist_ok_lrt_; }
    bool  hist_ok_flat() const { return hist_ok_flat_; }
    bool  hist_ok_diff() const { return hist_ok_diff_; }
    void set_alpha_dd(float a)        { alpha_dd_  = std::clamp(a, 0.f, 0.999f); }   // [Zoom 0.98]
    void set_alpha_lrt(float a)       { alpha_lrt_ = std::clamp(a, 0.01f, 1.f); }    // [Zoom 0.5]
    void set_oversub(float o)         { oversub_ = std::max(o, 0.1f); }
    void set_floor_db(float db)       { floor_base_db_ = db; floor_off_db_ = 0.f; apply_floor(); }
    void set_sed_steering(bool on)    { sed_steer_ = on; }        // SED -> music protect + freeze
    void set_xiflat_weight(float w)   { w_xiflat_ = std::clamp(w, 0.f, 1.f); }
    float gain_floor() const          { return gain_floor_; }
    int   fft_size() const            { return n_; }
    int   num_bins() const            { return bins_; }

    // Per-frame P(speech), recorded during process_all. Lets a test verify the DISCRIMINATOR
    // (speech vs noise separation), not just the net SNR — a suppressor can improve SNR with a
    // dumb fixed floor while its detector is broken, and that must not pass.
    const std::vector<float>& prob_history() const { return prob_hist_; }

private:
    int hz_to_bin(float hz) const {
        return std::clamp((int)std::lround(hz * n_ / (float)sr_), 0, bins_ - 1);
    }

    // ---- one analysis frame, in place (input windowed, output to be windowed by caller)
    void process_frame(std::vector<float>& frame) {
        for (int i = 0; i < n_; ++i) spec_[i] = std::complex<float>(frame[i], 0.f);
        fft_.forward(spec_);

        std::vector<float> p(bins_);
        for (int k = 0; k < bins_; ++k) {
            const float re = spec_[k].real(), im = spec_[k].imag();
            p[k] = re * re + im * im + 1e-20f;
        }

        // The power-law fit needs the full 50-frame window Zoom uses, not just the 12-frame
        // bootstrap; its own weight fades to zero by then so it does not fight the tracker.
        if (frames_seen_ < kNoiseFitFrames) initialise_noise(p);

        // ---------- features ----------
        float pitch_hz = 0.f;
        const float harm = harmonicity(frame, &pitch_hz);
        // The four per-band values still go to telemetry (Zoom logs flatness(x4) too), but the
        // FUSED feature is the single-range DC360 quantity.
        for (int b = 0; b < 4; ++b)
            tm_.flatness[b] = band_flatness(p, band_lo_[b], band_hi_[b]);
        float flat_avg;
        if (dc360_flatness_) {
            const float f = flatness_dc360(p);
            flat_s_ += kAlphaFeat * (f - flat_s_);        // alpha = 0.3  [Zoom DC360]
            flat_avg = flat_s_;
        } else {
            flat_avg = 0.f;
            for (int b = 0; b < 4; ++b) flat_avg += tm_.flatness[b];
            flat_avg *= 0.25f;
            flat_s_ += kAlphaFeat * (flat_avg - flat_s_);
            flat_avg = flat_s_;
        }

        // magnitude spectrum (SED flux + spectral-template difference both work on magnitudes)
        mag_.resize(bins_);
        for (int k = 0; k < bins_; ++k) mag_[k] = std::sqrt(p[k]);

        // ---- spectral template difference (Zoom telemetry: diff) ----
        // How much does this frame's spectral SHAPE deviate from the tracked noise template?
        // Fit the best scalar gain mu between frame and template, then measure the residual.
        // Noise (any level) fits the template well -> small diff. Speech reshapes it -> large.
        // Zoom smooths both the flatness and the template-difference features with alpha = 0.3
        // (DC360 / DBFF0) before they ever reach the fusion. Un-smoothed features make the
        // probability jittery frame-to-frame; this is cheap and matches the binary.
        float sdiff = spectral_difference(mag_);
        sdiff_s_ += kAlphaFeat * (sdiff - sdiff_s_);
        sdiff = sdiff_s_;
        tm_.spec_diff = sdiff;

        // ---- SED: what KIND of sound is this? ----
        float fe = 0.f;
        for (int i = 0; i < n_; ++i) fe += frame[i] * frame[i];
        const float fe_db = 10.f * std::log10(std::max(fe / n_, 1e-20f));
        tm_.sed = sed_.update(fe_db, harm, pitch_hz, flat_avg, mag_, (float)hop_ / (float)sr_);

        // posterior SNR and decision-directed prior SNR (Ephraim-Malah)
        float lrt_sum = 0.f, sig = 0.f, noi = 0.f;
        std::vector<float> xi(bins_), gamma(bins_);
        for (int k = 0; k < bins_; ++k) {
            const float nk = std::max(noise_[k], 1e-16f);
            // Zoom DB830 clamps BOTH the posterior SNR excess and the resulting a-priori SNR at
            // 100 (fminf(100.0, ...) twice). Without the cap a single loud bin drives xi to a huge
            // value, the gain pins at 1 and the decision-directed memory takes many frames to let
            // go -- which is audible as a smeared attack.
            gamma[k] = std::min(p[k] / nk, 101.f);
            const float dd = prev_gain_[k] * prev_gain_[k] * prev_gamma_[k];
            // Decision-directed smoothing factor. Zoom does NOT use a constant here: DB830 computes
            //     alpha = 0.9 * (xi/(1+xi))^2 + 0.1
            // i.e. it is derived from the PREVIOUS Wiener gain, so a bin that currently looks like
            // noise (xi -> 0, alpha -> 0.1) adapts almost immediately, while a bin carrying speech
            // (xi large, alpha -> 1.0) holds its estimate. A fixed 0.98 gives the slow behaviour
            // everywhere, including on noise -- which is exactly where fast adaptation is wanted.
            float a_dd = alpha_dd_;
            if (adaptive_alpha_dd_) {
                const float gprev = dd / (dd + 1.f);
                a_dd = 0.9f * gprev * gprev + 0.1f;
            }
            xi[k] = std::max(a_dd * dd + (1.f - a_dd) * std::max(gamma[k] - 1.f, 0.f), 1e-6f);
            xi[k] = std::min(xi[k], 100.f);                    // [Zoom DB830: fminf(100.0, ...)]
            // Per-bin log-likelihood ratio, in the exact form recovered from Zoom's E3380:
            //     L = 2xi/(2xi + 1 + eps) * (gamma + 1) - log(1 + 2xi)
            // Note it uses 2*xi, not xi — a deliberate variant of the textbook Ephraim-Malah LRT.
            const float u  = 2.f * xi[k];
            const float lk = (u / (u + 1.f + 1e-4f)) * (gamma[k] + 1.f) - std::log(1.f + u);
            lrt_[k] += alpha_lrt_ * (lk - lrt_[k]);      // recursive smoothing, alpha = 0.5
            lrt_sum += lrt_[k];
            sig += p[k];
            noi += nk;
        }
        const float lrt_avg = lrt_sum / bins_;

        // Flatness of the (1+xi)^2 spectrum — a feature recovered from Zoom DBD10 that we did not
        // have. Computing flatness on the A-PRIORI SNR rather than on the power spectrum is more
        // robust to level changes, because xi is already normalised by the noise floor: a noise
        // frame has roughly uniform xi (flat), a speech frame concentrates it in the formants
        // (peaky). Same geometric/arithmetic-mean form as the power flatness.
        {
            double lsum = 0.0, asum = 0.0;
            for (int k = 0; k < bins_; ++k) {
                const float t = (std::max(0.f, xi[k]) + 1.f) * (std::max(0.f, xi[k]) + 1.f);
                lsum += std::log(t);
                asum += t;
            }
            const float geo = (float)std::exp(lsum / bins_);
            const float ari = (float)(asum / bins_);
            xiflat_ = std::clamp(geo / std::max(ari, 1e-12f), 0.f, 1.f);
        }
        xiflat_s_ += kAlphaFeat * (xiflat_ - xiflat_s_);
        tm_.xi_flatness = xiflat_s_;

        // ---------- feature -> probability fusion ----------
        // Each feature is mapped through a tanh logistic and the three votes are fused. WHERE THE
        // THRESHOLD COMES FROM is the whole ballgame -- see ThreshMode. The EMA centres below are
        // only used by ThreshMode::SelfAdaptive; they are kept updated unconditionally so that
        // switching modes mid-stream cannot produce a cold threshold.
        lrt_ctr_  = 0.995f * lrt_ctr_  + 0.005f * lrt_avg;
        flat_ctr_ = 0.995f * flat_ctr_ + 0.005f * flat_avg;
        diff_ctr_ = 0.995f * diff_ctr_ + 0.005f * sdiff;
        hist_lrt_.add(lrt_avg);
        hist_flat_.add(flat_avg);
        hist_diff_.add(sdiff);
        if (hist_lrt_.count() >= hist_window_) refresh_hist_thresholds();
        // tanh with asymmetric steepness (Zoom E3380). Each feature votes against its own
        // adaptively tracked threshold; "sharp" selects the 8x slope on the already-crossed side.
        //
        // IMPORTANT: Zoom's literal steepness constants (4 / 8) are calibrated to ITS OWN internal
        // feature scaling, which lives in code we have not fully recovered (E3950/DD240). Feeding
        // our differently-scaled features into tanh(x*8) collapses the detector — measured:
        // separation 0.282 -> 0.130, net SNR 15.28 -> 9.32 dB. So we keep Zoom's *shape*
        // (tanh, asymmetric 4/8) but apply it to features normalised to a comparable range.
        float p_snr, p_flat, p_diff;
        // harmonicity: 0.30 was a guess and it is BELOW what pure noise produces (measured median
        // 0.397 on AirConditioner, 0.382 on babble, 0.510 on speech), so this feature was voting
        // ~0.99 "speech" on pure noise and single-handedly holding the fusion near 0.5.
        const float n_harm = (harm - thr_harm_) / sc_harm_;
        const float p_harm = tanh_feature(n_harm, 0.f, n_harm > 0.f);

        if (thresh_mode_ == ThreshMode::Hmm) {
            // Two-state Gaussian HMM per feature (Zoom viperex, NOTES.md 19.15). Replaces the
            // memoryless tanh: the Markov step with 0.99 self-transition means a single deviant
            // frame cannot swing the vote, which is the property the tanh map lacks and the reason
            // transient noise slipped through at 0.12-1.75 dB.
            if (!hmm_ready_) configure_hmm();
            // The three highest-d-prime features, in the domains they separate best in -- see
            // configure_hmm for the measured table and why these replace lrt/flat/diff.
            const float snr_db_now = 10.f * std::log10(std::max(sig / std::max(noi, 1e-20f), 1e-10f));
            const float xif_db     = 10.f * std::log10(std::max(xiflat_s_, 1e-6f));
            p_snr  = hmm_lrt_.update(snr_db_now);
            p_flat = hmm_flat_.update(xif_db);
            p_diff = hmm_diff_.update(harm);
        } else if (thresh_mode_ == ThreshMode::SelfAdaptive) {
            // OURS, REFUTED. The "threshold" is the feature's own running mean, so the argument to
            // tanh is (f - mean(f)) -- which on any stationary input goes to 0 and pins every
            // probability at 0.5. Measured: pure noise P=0.519 vs pure speech P=0.568, and pure
            // stationary noise attenuated by only 5.5 dB. Kept so NOTES.md 5.x-7.x reproduce.
            const float thr_lrt  = std::max(lrt_ctr_, 0.20f);
            const float thr_diff = std::max(diff_ctr_, 0.05f);
            const float n_lrt  = (lrt_avg - thr_lrt) / std::max(std::fabs(thr_lrt), 0.20f);
            const float n_flat = (flat_ctr_ - flat_avg) / std::max(flat_ctr_, 1e-3f);
            const float n_diff = (sdiff - thr_diff) / thr_diff;
            p_snr  = tanh_feature(n_lrt,  0.f, n_lrt  > 0.f);
            p_flat = tanh_feature(n_flat, 0.f, n_flat > 0.f);
            p_diff = tanh_feature(n_diff, 0.f, n_diff > 0.f);
        } else {
            // Zoom/WebRTC-NS form: the feature is compared against an ABSOLUTE threshold and fed
            // straight into tanh(width * (f - thr)). No self-normalisation -- that second division
            // is what destroyed the scale the recovered widths (4 / 8) were calibrated for.
            //
            // Asymmetry: the STEEPER slope is used BELOW the threshold, i.e. in pause regions, so
            // the vote collapses toward 0 quickly once a frame looks like noise. That is the
            // direction that produces suppression; the recovered constants give the two widths but
            // not which side they sit on, so this is inference, marked as such.
            // Each feature is offset by its ABSOLUTE threshold and divided by its own spread
            // before the tanh. Both halves matter and the reason is measured, not stylistic:
            //
            //  * the offset must be absolute. The refuted SelfAdaptive path used the feature's own
            //    running mean, which makes the argument (f - mean(f)) -> 0 on any stationary input.
            //  * the division must stay. Zoom's literal widths (4 / 8) are calibrated to ITS
            //    feature scaling, which we do not have. Ours are far narrower -- measured p10..p90
            //    on real audio: lrt_avg spans ~0.1, flat_avg ~0.06, spec_diff ~0.3 -- so feeding
            //    them raw into tanh(4x) keeps every vote within a hair of 0.5.
            //
            // Thresholds and scales below were READ OFF those distributions (NOTES.md 9.4), not
            // guessed: pure AC noise vs pure speech medians are lrt 0.005/0.085,
            // flat 0.379/0.265 (noise is FLATTER), spec_diff 0.000/0.632.
            if (feature_set_ == 1) {
                // SAME rule (absolute threshold -> tanh with the recovered 4/8 asymmetry), DIFFERENT
                // features: the three with the highest measured d-prime instead of the three with the
                // lowest. Thresholds are the midpoint between the measured noise and speech medians;
                // scales are the pooled sd. See configure_hmm for the table.
                //   snr_db       gap -4.25  speech +8.95  -> thr +2.35  sd 10.06   d' 1.31
                //   xi_flat dB   gap -4.30  speech -10.50 -> thr -7.40  sd  3.99   d' 1.55  (INVERTED)
                //   harmonicity  gap 0.329  speech 0.548  -> thr 0.439  sd  0.177  d' 1.24
                // No histogram refinement here: its bin sizes and bounds are calibrated to the old
                // features' ranges, and re-deriving those would change a second variable at once.
                const float snr_db_now =
                    10.f * std::log10(std::max(sig / std::max(noi, 1e-20f), 1e-10f));
                const float xif_db = 10.f * std::log10(std::max(xiflat_s_, 1e-6f));
                const float n_snr  = (snr_db_now - fthr_snr_) / fsc_snr_;
                const float n_xif  = (fthr_xif_ - xif_db)     / fsc_xif_;   // LOW xi-flatness = speech
                const float n_hrm  = (harm - fthr_hrm_)       / fsc_hrm_;
                p_snr  = tanh_feature(n_snr, 0.f, n_snr < 0.f);
                p_flat = tanh_feature(n_xif, 0.f, n_xif < 0.f);
                p_diff = tanh_feature(n_hrm, 0.f, n_hrm < 0.f);
            } else {
            const float n_lrt  = (lrt_avg - eff_thr_lrt_)  / sc_lrt_;
            const float n_flat = (eff_thr_flat_ - flat_avg) / sc_flat_;   // LOW flatness = speech
            const float n_diff = (sdiff - eff_thr_diff_)   / sc_diff_;
            p_snr  = tanh_feature(n_lrt,  0.f, n_lrt  < 0.f);   // steeper below = pause regions
            p_flat = tanh_feature(n_flat, 0.f, n_flat < 0.f);
            p_diff = tanh_feature(n_diff, 0.f, n_diff < 0.f);
            }
        }
        // 5th feature: low (1+xi)^2 flatness = peaky xi = speech
        xif_ctr_ = 0.995f * xif_ctr_ + 0.005f * xiflat_s_;
        const float n_xif  = (xif_ctr_ - xiflat_s_) / std::max(xif_ctr_, 1e-3f);
        const float p_xif  = tanh_feature(n_xif, 0.f, n_xif > 0.f);
        // 4-way fusion, matching the probability sources Zoom's telemetry exposes
        // The (1+xi)^2 flatness (p_xif) is COMPUTED and exposed in telemetry, but carries zero
        // weight here. Measured on the synthetic bench: giving it 0.17 (taken proportionally from
        // the others) cost 0.95 dB of level-5 net SNR (14.60 -> 13.65) and 0.007 of separation.
        // Most likely because it is derived from xi, so it is strongly correlated with p_snr —
        // adding a correlated feature while diluting the independent ones is a net loss here.
        // Kept available because on real, non-stationary noise the correlation should be weaker.
        const float kWeightXiFlat = w_xiflat_;
        float ps;
        if (thresh_mode_ == ThreshMode::Hmm || feature_set_ == 1) {
            // Equal thirds. Zoom's own fusion is 1/N over three features (sub_1801DD530 writes
            // a2[8..10] = 1/n). For the HMM there is no uninformative-window test to fail; for
            // feature_set 1 the histogram weights would be derived from the OLD features' histograms,
            // which are still being fed but no longer feed the votes -- so they must not be used.
            ps = (p_snr + p_flat + p_diff) * (1.f / 3.f) + kWeightXiFlat * p_xif;
        } else if (thresh_mode_ == ThreshMode::Histogram) {
            // Zoom's fusion is THREE features with EQUAL runtime weights 1/N (sub_1801DD530 writes
            // a2[8..10] = 1/n, ok_flat/n, ok_diff/n). There is no harmonicity term in it at all --
            // E3380 sums exactly three weighted indicators. Our old fixed 0.42/0.18/0.16/0.24 over
            // four features was wrong on both counts.
            ps = w_lrt_ * p_snr + w_flat_ * p_flat + w_diff_ * p_diff + kWeightXiFlat * p_xif;
        } else {
            ps = 0.42f * p_snr + 0.18f * p_flat + 0.16f * p_harm + 0.24f * p_diff
               + kWeightXiFlat * p_xif;
        }
        ps = std::clamp(ps, 0.f, 1.f);
        // SED steers the prior. It is a ~1 s SCENE classifier, so it must BIAS frame-level
        // evidence, not override it: a scene prior cannot switch at word-gap granularity, and
        // clamping hard on "speech" blurs the frame-level speech/noise separation (measured:
        // separation 0.395 -> 0.271 when the speech floor was 0.55). Music is the deliberate
        // exception — falsely suppressing music is the expensive error, so it clamps hard.
        // The three probability clamps below are OURS, not a recovered Zoom mechanism, and they were
        // costing more than they bought. Measured on pure AirConditioner noise -- no speech in the
        // file at all -- SED called 85.7% of frames "speech", so the max(ps, 0.40) branch fired on
        // 55.9% of frames: every one of those had all three feature votes below 0.05 (i.e. all three
        // said "noise") and still ended up with P > 0.35. They compress P into a narrow band, which
        // is the opposite of what the gain chain needs.
        //
        // Removing them is free: pure-noise attenuation 5.65 -> 5.99 dB, and on the babble mixture
        // ESTOI 0.4974 -> 0.4998 and SI-SDR 1.70 -> 2.18 (both better), STOI 0.9092 -> 0.9075.
        //
        // Music protection is the exception and stays: falsely suppressing music is the expensive
        // error, and that clamp fires only when the SED actually says music. Note that SED's other
        // two jobs -- music-mode over-subtraction backoff and freezing the noise estimate on
        // transients -- are untouched by this and remain under sed_steer_.
        if (sed_steer_ && (tm_.sed.event == Event::Music || tm_.sed.music_protection))
            ps = std::max(ps, 0.80f);
        else if (sed_prob_clamp_ && sed_steer_) {
            if (tm_.sed.event == Event::Speech)              ps = std::max(ps, 0.40f);
            else if (tm_.sed.event == Event::StationaryNoise) ps = std::min(ps, 0.45f);
        }
        // Temporal smoothing + clamp, matching Zoom E3380: alpha = 0.1, floor 0.01.
        // The floor matters: it keeps the posterior gain from collapsing to zero on a wrong call.
        speech_prob_ += alpha_p_ * (ps - speech_prob_);
        speech_prob_ = std::clamp(speech_prob_, kPMin, 1.f);
        tm_.diff_prob = p_diff;
        tm_.lrt_avg   = lrt_avg;
        tm_.flat_avg  = flat_avg;
        tm_.thr_lrt   = (thresh_mode_ == ThreshMode::SelfAdaptive) ? std::max(lrt_ctr_, 0.20f) : eff_thr_lrt_;
        tm_.thr_flat  = (thresh_mode_ == ThreshMode::SelfAdaptive) ? flat_ctr_ : eff_thr_flat_;
        tm_.thr_diff  = (thresh_mode_ == ThreshMode::SelfAdaptive) ? std::max(diff_ctr_, 0.05f) : eff_thr_diff_;
        tm_.w_lrt = w_lrt_; tm_.w_flat = w_flat_; tm_.w_diff = w_diff_;

        // ---------- noise tracking (SPP-weighted, MCRA-style) ----------
        const bool voiced = speech_prob_ > 0.5f;
        detect_noise_change(noi / bins_);
        // SED gate: never learn a transient or music into the noise estimate — that is exactly
        // how a keyboard click or a held chord ends up being permanently subtracted as "noise".
        const bool freeze = sed_steer_ && (tm_.sed.event == Event::Transient ||
                            tm_.sed.event == Event::Music || tm_.sed.music_protection);
        const float beta = freeze ? 1.0f : (noise_changed_hold_ > 0 ? kBetaFast : kBetaSlow);
        // Spectral template tracks the noise shape; only update it on confident noise frames.
        if (!freeze && speech_prob_ < 0.35f) update_template(mag_);
        // Per-bin speech-presence probability, in the exact form recovered from Zoom sub_1801E3380:
        //     SPP[k] = 1 / (1 + exp(-Lambda[k]) * (1-P)/(P+1e-4))
        // VERIFIED AGAINST THE BINARY: E3380 writes this array into its state block at float
        // offset 3301 and never touches the spectrum; its caller (sub_1801E3950) reads that same
        // offset -- as `v92[3152]` off a base 596 bytes in, i.e. the identical address -- and uses
        // it ONLY to weight the noise-estimate update below. So this quantity is the noise
        // tracker's input, NOT the spectral gain. (We shipped it as the gain, which is why pure
        // stationary noise was attenuated by 5 dB: an SPP used as a gain cannot fall below P.)
        const float prior_odds = (1.f - speech_prob_) / (speech_prob_ + 1e-4f);
        spp_.resize(bins_);
        for (int k = 0; k < bins_; ++k)
            spp_[k] = 1.f / (1.f + std::exp(-lrt_[k]) * prior_odds);

        for (int k = 0; k < bins_; ++k) {
            const float pk_raw = spp_[k];
            const float pk = std::max(pk_raw, speech_prob_);        // don't adapt into speech
            // Zoom E3950's update, three details our first version did not have:
            //  * the observation is capped at 1.15x the current estimate, so a single loud frame
            //    cannot yank the noise floor up (and then subtract speech as "noise");
            //  * the outer smoothing constant switches 0.9 <-> 0.99 on SPP > 0.2, i.e. it becomes
            //    much more conservative the moment the bin looks like speech;
            //  * bins with SPP < 0.2 additionally feed a slow alpha=0.05 tracker.
            float obs = p[k];
            if (zoom_noise_update_) obs = std::min(obs, noise_[k] * 1.15f);
            const float target = pk * noise_[k] + (1.f - pk) * obs;
            float b = beta;
            if (zoom_noise_update_ && !freeze) b = (pk_raw > 0.2f) ? 0.99f : 0.90f;
            noise_[k] = b * noise_[k] + (1.f - b) * target;
            if (zoom_noise_update_ && pk_raw < 0.2f)
                noise_slow_[k] += (obs - noise_slow_[k]) * 0.05f;
        }
        if (noise_changed_hold_ > 0) --noise_changed_hold_;

        // ---------- gain ----------
        // MusicProtection: back off both the over-subtraction and the floor so tonal, sustained
        // content survives. This is the lever Zoom exposes as "@NS for music-mode" +
        // MusicProtection, and as the separate "原声/音乐家模式" microphone mode.
        const bool protect = sed_steer_ &&
                             (tm_.sed.music_protection || tm_.sed.event == Event::Music);
        const float oversub = protect ? 1.0f : oversub_;
        float gfloor  = protect ? std::max(gain_floor_, 0.71f) : gain_floor_;  // >= -3 dB
        // P-driven floor. Two measured facts make this the right lever, and neither was available
        // until now:
        //   1. The FLOOR is the binding constraint, not the detector. Sweeping level 0..5 (floor -4
        //      .. -27 dB) with the detector held fixed moves gap attenuation 3.40 -> 19.49 dB and
        //      gap-vs-speech modulation 1.50 -> 11.38 dB, while swapping the detector moves either
        //      by <=0.2 dB at every rung. So no detector work can show up until the floor yields.
        //   2. The floor is capped where it is because deep floors crush fricatives -- but that is
        //      only true on SPEECH frames. On a frame the detector is confident is noise there is
        //      nothing to crush.
        // So: keep the level's floor as the speech-frame floor, and allow up to extra_db of
        // additional depth as P falls, fading in only below p_knee so ordinary speech never sees it.
        // Unlike DB830's limiter -- which turned out to be a function of bin level ALONE and so
        // attenuated speech and gaps equally (modulation -0.03 dB) -- this is driven by P, which is
        // exactly what makes it able to be selective.
        if (!protect && afloor_extra_db_ > 0.f && afloor_knee_ > 0.f) {
            const float t = std::clamp((afloor_knee_ - speech_prob_) / afloor_knee_, 0.f, 1.f);
            if (t > 0.f) {
                const float db = (floor_base_db_ + floor_off_db_) - afloor_extra_db_ * t;
                gfloor = std::pow(10.f, db / 20.f);
            }
        }
        // presence_lo is OURS, not recovered, and it is a hard cap on how much the frame-level
        // speech probability can modulate the gain. At 0.35 the factor spans [0.35, 1.0], so a P
        // that swings 0.31 -> 0.51 (measured, gap vs speech frames on AC noise @5 dB) moves the
        // gain by only 20*log10(0.68/0.55) = 1.9 dB. That is the ceiling on audible gating no
        // matter how well the detector works -- and the detector works: p_snr separates speech from
        // gap frames by +0.4456 within the same file.
        //
        // Note also that Zoom does NOT multiply the gain by a presence factor at all: the SPP is
        // spent on the noise tracker, and the gain is xi/(1+xi) with xi coming from the resulting
        // noise estimate. So this multiply is an extra of ours layered on top; presence_lo = 1.0
        // removes it entirely, which is the Zoom-shaped configuration.
        const float presence_lo = protect ? 0.85f : presence_lo_;

        // Gain = the per-bin POSTERIOR speech-presence probability, exactly as recovered from
        // Zoom E3380:   G[k] = 1 / (1 + exp(-L[k]) * (1-P)/(P+1e-4))
        // i.e. the Bayesian posterior P(H1|Y) with prior odds from the frame-level P(speech).
        // Zoom does NOT use a Wiener gain here — it uses the probability itself as the gain.
        // We keep the level-dependent over-subtraction by inflating the prior odds, which is the
        // natural place for it in this formulation (higher level = stronger bias toward absence).
        const float odds = prior_odds * oversub;
        float gsum = 0.f, e_in = 0.f, e_out = 0.f;
        gain_.resize(bins_);
        for (int k = 0; k < bins_; ++k) {
            e_in += p[k];
            // Two gain laws, switchable so the correction can be A/B'd BY EAR:
            //   Wiener   (DEFAULT, and what the binary implies): xi/(oversub+xi) from the
            //     decision-directed a-priori SNR. Goes to 0 as xi -> 0, so the only lower bound
            //     is the explicit floor. The SPP is spent on the noise tracker, per E3950.
            //   Posterior: the SPP used directly as the gain. This is what we shipped first and
            //     it is WRONG -- E3380 stores that array for the noise update, it never multiplies
            //     the spectrum. Kept selectable because it is the thing being corrected: measured
            //     4-9 dB of attenuation on pure noise, versus 13-24 dB for Wiener.
            float g;
            if (gain_law_ == GainLaw::Posterior) {
                g = 1.f / (1.f + std::exp(-lrt_[k]) * odds);
            } else {
                const float xi_os = xi[k] / oversub;
                g = xi_os / (1.f + xi_os);
            }
            // Frame-level presence bias, applied ONCE. (It used to be applied twice on the Wiener
            // path -- inside the branch and again here -- squaring the factor and quietly costing
            // that path most of its suppression.)
            g *= (presence_lo + (1.f - presence_lo) * speech_prob_);
            // Attack rate limit, recovered from Zoom E16C0:
            //     if (g * 0.333 > g_prev) g = g_prev * 3;
            // The gain may at most TRIPLE from one frame to the next. Releasing (getting quieter)
            // is unrestricted; only opening up is slewed. Without it, a gain that snaps 0.05 -> 1.0
            // in one hop puts a click at every word onset.
            if (attack_limit_ && g * 0.333f > prev_gain_[k])
                g = prev_gain_[k] * 3.f;
            // The floor clamp stays in BOTH formulations. Removing it under the limiter (on the
            // theory that the floor was folded into L) was the other half of the mistake above:
            // an unclamped per-bin gain zeroes isolated speech bins, ESTOI 0.4956 -> 0.2256.
            g = std::max(g, gfloor);
            // ---- Zoom DB830's gain LIMITER, applied AFTER the floor clamp ----
            // Order matters and was settled by measurement. Applied BEFORE the clamp, the pedestal
            // (<= 0.316) always sits below the level-2 floor (0.501), so the clamp binds on every
            // bin and the output is uniformly attenuated: noise -6.03 dB, speech -6.00 dB, net SNR
            // gain +0.03 dB -- an attenuator, not a suppressor. After the clamp, the pedestal scales
            // the already-floored gain, so noise (at the floor) and speech (above it) stay apart.
            // Exactly as decompiled:
            //   v12 = 20*log10(binMag) - 90.31          <- 90.309998 == 20*log10(32768), i.e. the
            //                                              int16 full-scale -> dBFS conversion, so
            //                                              v12 is this bin's level in dBFS
            //   v13 = cfgLimit - level                  <- the max attenuation allowed; this is the
            //                                              same role our floor_db table plays
            //   v14 = min(0, (-65 - level) - v12)       <- the attenuation needed to bring this bin
            //                                              DOWN TO the -65 dBFS target (never boost)
            //   L   = min(-5, max(v13, v14))            <- take the gentler of the two limits, then
            //                                              force AT LEAST 5 dB
            //   g   = 10^(L/10) * xi/(1+xi)
            //
            // Two consequences worth stating, because they overturn earlier conclusions of ours:
            //  * the floor is NOT a lower bound on the total gain. It bounds the LIMITER, which then
            //    multiplies the Wiener gain -- so the product can go well below the floor. Our old
            //    `g = max(g, floor)` had the opposite semantics.
            //  * min(-5, ...) attenuates EVERY bin by at least 5 dB, speech included. That is a
            //    5 dB pedestal on the whole output -- which is precisely why Zoom needs the E56E0
            //    makeup gain. We measured makeup as harmful (NOTES.md 5.9) because we had no
            //    pedestal for it to undo. Faithful reproduction needs both or neither.
            if (zoom_gain_limit_) {
                const float bin_db = 10.f * std::log10(std::max(p[k] / fs_bin_pow_, 1e-20f));
                const float need   = std::min(0.f, (zoom_target_db_ - lvl_off_db_) - bin_db);
                // `v13` is NOT our floor table. Substituting it there was wrong and measurably so:
                // it made L collapse to the floor value, multiplied that into the Wiener gain, and
                // (with the clamp removed) attenuated SPEECH by 17 dB -- net SNR gain went NEGATIVE
                // at level 5. Zoom plainly does not do that.
                //
                // Reading it as a configured limit near 0 dB is self-consistent: `need` is always
                // <= 0, so max(v13, need) == v13 ~ 0, and L = min(-5, ~0) = -5. The limiter then
                // contributes exactly a 5 dB pedestal in the common case and only bites harder when
                // v13 is configured lower -- which is what E56E0's makeup gain exists to undo.
                const float limit  = std::max(zoom_limit_db_ - lvl_off_db_, need);
                const float L      = std::min(-5.f, limit);
                g *= std::pow(10.f, L / 10.f);
            }
            g = std::min(g, 1.f);
            // Absolute dBFS suppression floor (Zoom DB830). A fixed LINEAR floor treats every bin
            // the same, which is backwards: it lets a loud noise bin off lightly while still
            // crushing a weak speech bin below audibility. Bounding the OUTPUT at an absolute
            // dBFS level instead makes the allowed attenuation level-dependent -- quiet bins,
            // which is where fricatives and consonants live, are protected automatically.
            if (abs_floor_on_) {
                const float in_dbfs = 10.f * std::log10(std::max(p[k] / fs_bin_pow_, 1e-20f));
                const float allowed = std::max(0.f, in_dbfs - abs_floor_dbfs_);   // dB we may cut
                const float gmin    = std::pow(10.f, -allowed / 20.f);
                g = std::max(g, gmin);
            }
            gain_[k] = std::min(g, 1.f);
        }

        // ---- gain smoothing along FREQUENCY and TIME ----
        // Neighbouring bins can end up with very different gains, which punches narrow holes in
        // the spectrum; that is the classic source of musical noise in any spectral-subtraction
        // family method. Smoothing the gain (not the spectrum) trades a little suppression depth
        // for a smoother residual. Both axes are switchable so each can be measured separately.
        // ---------- band-reduced gain + linear interpolation back to bins ----------
        // Zoom E16C0 does NOT apply a per-bin gain. Its first loop reads, for every output bin, TWO
        // source indices and TWO weights and blends them:
        //     g[bin] = min(0.9999, w_lo * g[idx_lo] + w_hi * g[idx_hi])
        // with the indices at v10[-130]/v10[0] and the weights at v10[130]/v10[260]. That is linear
        // interpolation from a COARSER gain representation onto the bin grid.
        //
        // This is not cosmetic smoothing. The decompiled gain has no lower clamp at all -- the floor
        // bounds the dB limiter, not the product (see the limiter above). A per-bin unfloored gain
        // zeroes isolated speech bins: measured here, removing the clamp cost ESTOI 0.4956 -> 0.2256
        // on babble. Band reduction is what makes an unfloored gain survivable, because a speech bin
        // sitting next to noise bins inherits their band's gain instead of its own near-zero one.
        if (gain_bands_ > 0 && gain_bands_ < bins_) {
            band_g_.assign((size_t)gain_bands_, 0.f);
            band_n_.assign((size_t)gain_bands_, 0.f);
            for (int k = 0; k < bins_; ++k) {
                const int b = std::min(gain_bands_ - 1, k * gain_bands_ / bins_);
                band_g_[(size_t)b] += gain_[k];
                band_n_[(size_t)b] += 1.f;
            }
            for (int b = 0; b < gain_bands_; ++b)
                band_g_[(size_t)b] /= std::max(band_n_[(size_t)b], 1.f);
            // Band centres in bin units, then interpolate.
            const float span = (float)bins_ / (float)gain_bands_;
            for (int k = 0; k < bins_; ++k) {
                const float pos = ((float)k + 0.5f) / span - 0.5f;      // fractional band index
                const int   b0  = std::clamp((int)std::floor(pos), 0, gain_bands_ - 1);
                const int   b1  = std::clamp(b0 + 1, 0, gain_bands_ - 1);
                const float w   = std::clamp(pos - (float)b0, 0.f, 1.f);
                gain_[k] = std::min(0.9999f,                             // [Zoom E16C0: 0.99989998]
                                    (1.f - w) * band_g_[(size_t)b0] + w * band_g_[(size_t)b1]);
            }
        }

        if (freq_taps_ > 1) {
            gsmooth_.assign(bins_, 0.f);
            const int r = freq_taps_ / 2;
            for (int k = 0; k < bins_; ++k) {
                float acc = 0.f, wsum = 0.f;
                for (int d = -r; d <= r; ++d) {
                    const int kk = k + d;
                    if (kk < 0 || kk >= bins_) continue;
                    const float w = (float)(r + 1 - std::abs(d));   // triangular
                    acc += w * gain_[kk]; wsum += w;
                }
                gsmooth_[k] = acc / std::max(wsum, 1e-9f);
            }
            gain_.swap(gsmooth_);
        }
        if (time_alpha_ < 1.f) {
            for (int k = 0; k < bins_; ++k)
                gain_[k] = gt_[k] + time_alpha_ * (gain_[k] - gt_[k]);
        }
        for (int k = 0; k < bins_; ++k) gt_[k] = gain_[k];

        for (int k = 0; k < bins_; ++k) {
            const float g = gain_[k];
            prev_gain_[k] = g;
            prev_gamma_[k] = gamma[k];
            spec_[k] *= g;
            if (k > 0 && k < bins_ - 1) spec_[n_ - k] = std::conj(spec_[k]);
            e_out += p[k] * g * g;
            gsum += g;
        }
        spec_[0] = std::complex<float>(spec_[0].real() * 1.f, 0.f);

        // ---------- post-gain level normalisation ("makeup gain"), from Zoom E56E0 ----------
        // Take the RMS ratio of output to input AFTER spectral suppression, then interpolate two
        // opposite corrections by the speech probability:
        //   r > 0.5 (lightly suppressed => probably speech) -> BOOST, capped so we never exceed
        //            the original level (1/r);
        //   r < 0.5 (heavily suppressed => probably noise)  -> push it down FURTHER.
        // Net effect: a second SNR separation on top of the spectral gain. Not visible from the
        // gain formula alone — only from reading the process function.
        if (makeup_on_ && frames_seen_ > kMakeupWarmup && !protect) {
            const float r = std::sqrt(e_out / (e_in + 1e-12f));
            float boost = 1.f, atten = 1.f;
            if (r > 0.5f) {
                boost = 1.f + (r - 0.5f) * 1.3f;
                if (r * boost > 1.f) boost = 1.f / std::max(r, 1e-6f);
            } else {
                atten = 1.f - (0.5f - std::max(r, gfloor)) * 0.3f;
            }
            const float mk_raw = (1.f - speech_prob_) * atten + speech_prob_ * boost;
            makeup_s_ += makeup_alpha_ * (mk_raw - makeup_s_);
            const float mk = makeup_s_;
            // track how much the RAW makeup jitters frame-to-frame; this is the quantity the
            // "temporal smearing" hypothesis is about.
            if (mk_prev_ > 0.f) {
                mk_jit_sum_ += std::fabs(mk_raw - mk_prev_);
                ++mk_jit_n_;
            }
            mk_prev_ = mk_raw;
            for (int k = 0; k < n_; ++k) spec_[k] *= mk;
            tm_.makeup = mk;
        } else {
            tm_.makeup = 1.f;
        }

        fft_.inverse(spec_);
        for (int i = 0; i < n_; ++i) frame[i] = spec_[i].real();

        // ---------- telemetry ----------
        tm_.speech_prob = speech_prob_;
        tm_.snr_prob = p_snr;
        tm_.flat_prob = p_flat;
        tm_.harmonicity = harm;
        tm_.snr_db = 10.f * std::log10(std::max(sig / std::max(noi, 1e-20f), 1e-10f));
        tm_.gain = gsum / bins_;
        tm_.voice = voiced;
        for (int b = 0; b < 4; ++b) {
            float e = 0.f;
            for (int k = band_lo_[b]; k <= band_hi_[b]; ++k) e += noise_[k];
            e /= std::max(1, band_hi_[b] - band_lo_[b] + 1);
            tm_.noise_level[b] = 10.f * std::log10(std::max(e, 1e-20f));
        }
        ++frames_seen_;
    }

    // Noise-floor cold start, recovered from Zoom E3950.
    // Instead of averaging the first frames flat, fit a POWER LAW to the observed spectrum:
    // least-squares regression of log(P) on log(k) over bins >= kFitLowBin, giving
    //     noise[k] = A / k^alpha        with alpha clamped to [0,1]
    // Rationale: real acoustic noise floors are close to 1/f^alpha, so a two-parameter fit
    // generalises across the whole band from very few frames — far better than a flat mean,
    // which mis-shapes the low end. The fitted estimate is blended in with a weight that decays
    // as frames accumulate, so it dominates at frame 0 and fades out by kNoiseFitFrames.
    // MEASURED TRADE-OFF (synthetic bench): vs a flat running-mean init this costs ~1.1 dB of
    // level-5 net SNR (15.89 -> 14.77) but nearly halves music loss (0.83 -> 0.44 dB). The most
    // likely reason for the SNR cost is that our synthetic noise is white + low-pass rumble, which
    // is NOT a 1/f^alpha floor, so the two-parameter fit mis-models it. Real room noise is much
    // closer to 1/f, where this should win. Left ON (faithful to Zoom) but switchable, because
    // this is exactly the call that cannot be settled without real recordings.
    void initialise_noise(const std::vector<float>& p) {
        const long n = frames_seen_;
        if (!powerlaw_init_) {
            const float w0 = 1.0f / (float)(n + 1);
            for (int k = 0; k < bins_; ++k) noise_[k] = (1.f - w0) * noise_[k] + w0 * p[k];
            return;
        }
        // accumulate regression sums for this frame
        for (int k = kFitLowBin; k < bins_; ++k) {
            const float lp = std::log(std::max(p[k], 1e-20f));
            const float lk = std::log((float)k);
            fit_sx_ += lk; fit_sxx_ += lk * lk; fit_sy_ += lp; fit_sxy_ += lp * lk;
        }
        fit_n_ += (float)(bins_ - kFitLowBin);

        bool fitted_ok = false;
        float A = 0.f, alpha = 0.f;
        const float denom = fit_n_ * fit_sxx_ - fit_sx_ * fit_sx_;
        if (std::fabs(denom) > 1e-6f) {
            // slope of log P vs log k is negative for a decaying floor; Zoom stores its magnitude
            const float slope = (fit_n_ * fit_sxy_ - fit_sx_ * fit_sy_) / denom;
            alpha = std::clamp(-slope, 0.f, 1.f);
            const float intercept = (fit_sy_ - slope * fit_sx_) / fit_n_;
            A = std::exp(intercept);
            fitted_ok = std::isfinite(A) && A > 0.f;
        }

        const float w = 1.0f / (float)(n + 1);          // plain running mean, as before
        for (int k = 0; k < bins_; ++k) {
            const float mean_est = (1.f - w) * noise_[k] + w * p[k];
            if (!fitted_ok) { noise_[k] = mean_est; continue; }
            const float kk  = (float)std::max(k, kFitLowBin);
            const float pw  = A / std::pow(kk, alpha);
            // fitted estimate dominates early, fades out linearly by kNoiseFitFrames
            const float wf = std::clamp(1.f - (float)n / (float)kNoiseFitFrames, 0.f, 1.f);
            noise_[k] = wf * pw + (1.f - wf) * mean_est;
        }
    }

    // NoiseChanged / noiseCount: declare a scene change when the mean noise floor
    // jumps by more than a factor for several consecutive frames.
    void detect_noise_change(float mean_noise) {
        tm_.noise_changed = 0;
        if (frames_seen_ < kInitFrames) { lt_noise_ = mean_noise; return; }
        const float ratio = mean_noise / std::max(lt_noise_, 1e-20f);
        if (ratio > 3.0f || ratio < 0.33f) {
            if (++change_run_ >= 5) {
                tm_.noise_changed = 1;
                ++tm_.noise_count;
                noise_changed_hold_ = 40;   // fast-adapt window
                change_run_ = 0;
            }
        } else {
            change_run_ = 0;
        }
        lt_noise_ = 0.995f * lt_noise_ + 0.005f * mean_noise;
    }

    // Spectral template difference  (Zoom telemetry: diff)
    // Fit the best scalar gain mu minimising ||mag - mu*tmpl||^2, then report the normalised
    // residual. Rationale: stationary noise keeps its spectral SHAPE and only changes level, so a
    // pure level change is absorbed by mu and yields a small residual; speech changes the shape
    // (formants, harmonics) and cannot be fitted by any single gain -> large residual.
    float spectral_difference(const std::vector<float>& mag) const {
        if (!tmpl_ready_) return 0.f;
        double num = 0.0, den = 0.0;
        for (int k = 0; k < bins_; ++k) { num += (double)mag[k] * tmpl_[k]; den += (double)tmpl_[k] * tmpl_[k]; }
        if (den < 1e-20) return 0.f;
        const double mu = num / den;
        double res = 0.0, energy = 0.0;
        for (int k = 0; k < bins_; ++k) {
            const double d = (double)mag[k] - mu * tmpl_[k];
            res += d * d;
            energy += (double)mag[k] * mag[k];
        }
        return (float)std::clamp(res / std::max(energy, 1e-20), 0.0, 1.0);
    }

    void update_template(const std::vector<float>& mag) {
        const float a = tmpl_ready_ ? 0.98f : 0.5f;
        for (int k = 0; k < bins_; ++k) tmpl_[k] = a * tmpl_[k] + (1.f - a) * mag[k];
        if (++tmpl_frames_ > 8) tmpl_ready_ = true;
    }

    // Spectral flatness, transcribed from Zoom sub_1801DC360.
    //
    // ONE contiguous bin range on the MAGNITUDE spectrum -- not a mean of per-band flatnesses, which
    // is what we had. The difference is the whole ballgame: averaging four wide bands washes out the
    // spectral peaks that make speech peaky, and it left our speech flatness (0.66) only 0.09 below
    // our noise flatness (0.75). Zoom's design needs a much bigger gap, because sub_1801DD530 gates
    // the feature on its histogram peak sitting at >= 0.6.
    //
    // The range is [lo, hi) where
    //   lo = 8 at 16 kHz (4 otherwise)  -- the lowest bins are excluded outright
    //   hi = found by walking DOWN from the top, discarding bins until 5% of the TOTAL magnitude
    //        has been trimmed, with a hard stop at lo + 8
    // The arithmetic mean uses the same trimmed sum, so numerator and denominator see identical bins.
    // A non-positive bin inside the range aborts the whole computation and the smoothed feature
    // decays by 30% instead -- that path is in the original and is not an error case we invented.
    float flatness_dc360(const std::vector<float>& p) {
        mag_lin_.resize((size_t)bins_);
        double total = 0.0;
        for (int k = 0; k < bins_; ++k) {
            mag_lin_[(size_t)k] = std::sqrt(std::max((double)p[k], 0.0));
            total += mag_lin_[(size_t)k];
        }
        const int lo = (sr_ == 16000) ? 8 : 4;
        if (bins_ <= lo + 9 || total <= 0.0) return flat_s_;

        double budget = total * 0.05;                     // [Zoom: v8 = total * 0.050000001]
        double kept   = total;
        for (int k = 0; k < lo; ++k) kept -= mag_lin_[(size_t)k];
        kept -= budget;                                    // v14

        int hi = bins_ - 1;
        const int guard = lo + 8;                          // [Zoom: v16 = v11 + 8]
        while (budget > 0.0 && hi > guard) { budget -= mag_lin_[(size_t)hi]; --hi; }
        kept += budget;                                    // v19: the trimmed range's arithmetic sum

        const int n = hi - lo;
        if (n <= 0) return flat_s_;

        double logsum = 0.0;
        for (int k = lo; k < hi; ++k) {
            const double v = mag_lin_[(size_t)k];
            if (v <= 0.0) return flat_s_ * 0.7f;           // [Zoom: prev - prev*0.3]
            logsum += std::log(v);
        }
        const double gm = std::exp(logsum / (double)n);
        const double am = kept / (double)n;
        return (float)std::clamp(gm / std::max(am, 1e-20), 0.0, 1.0);
    }

    // Per-band flatness, kept for the flatness(x4) telemetry slots Zoom's release build also logs.
    // NOT the fused feature any more -- see flatness_dc360 above.
    static float band_flatness(const std::vector<float>& p, int lo, int hi) {
        double logsum = 0.0, sum = 0.0;
        const int n = hi - lo + 1;
        for (int k = lo; k <= hi; ++k) {
            const double mag = std::sqrt(std::max((double)p[k], 1e-20));
            logsum += std::log(mag);
            sum += mag;
        }
        const double gm = std::exp(logsum / n), am = sum / n;
        return (float)std::clamp(gm / std::max(am, 1e-20), 0.0, 1.0);
    }

    // Voicing strength from the normalised autocorrelation peak over a plausible F0 range.
    // Also reports the F0 at the peak, which the SED uses for its pitch-stability test.
    float harmonicity(const std::vector<float>& frame, float* pitch_hz_out = nullptr) const {
        if (pitch_hz_out) *pitch_hz_out = 0.f;
        const int lo = std::max(2, sr_ / 400);   // 400 Hz
        const int hi = std::min(n_ - 1, sr_ / 60); // 60 Hz
        if (hi <= lo) return 0.f;
        double e0 = 0.0;
        for (int i = 0; i < n_; ++i) e0 += (double)frame[i] * frame[i];
        if (e0 < 1e-12) return 0.f;
        float best = 0.f;
        int best_lag = 0;
        for (int lag = lo; lag <= hi; ++lag) {
            double num = 0.0, den = 0.0;
            for (int i = lag; i < n_; ++i) {
                num += (double)frame[i] * frame[i - lag];
                den += (double)frame[i - lag] * frame[i - lag];
            }
            if (den > 1e-12) {
                const float r = (float)(num / std::sqrt(den * e0));
                if (r > best) { best = r; best_lag = lag; }
            }
        }
        if (pitch_hz_out && best_lag > 0 && best > 0.2f) *pitch_hz_out = (float)sr_ / best_lag;
        return std::clamp(best, 0.f, 1.f);
    }

    static float sigmoid(float x) { return 1.f / (1.f + std::exp(-x)); }

    // Feature -> probability mapping, recovered from Zoom's sub_1801E3380.
    // A tanh centred on the threshold, but with an ASYMMETRIC steepness: the side that has already
    // crossed the threshold decides sharply (8), the side that has not is deliberately gentler (4).
    // That asymmetry is a real design choice in the binary — commit fast once evidence points one
    // way, stay conservative before that.
    // Threshold + weight extraction, transcribed from Zoom sub_1801DD530's flag==1 branch.
    // Called once per window, then the histograms are cleared.
    void refresh_hist_thresholds() {
        const int W = hist_window_;

        // --- LRT: informative iff its fluctuation exceeds thresFluctLrt (0.05) ---
        float mean_low = 0.f;
        const float fluct = hist_lrt_.fluctuation(kLrtLowBound, W, mean_low);
        const bool lrt_ok = fluct >= kThresFluctLrt;
        if (lrt_ok) {
            eff_thr_lrt_ = std::clamp(mean_low * kFactor1, kMinLrt, kMaxLrt);
        } else {
            // NOT weight-zeroing. The threshold is driven to its MAXIMUM, which makes
            // tanh(feat - thr) maximally negative, i.e. the LRT votes "noise". The LRT's WEIGHT is
            // never zeroed -- it is the one feature that always counts. Getting this backwards
            // (zeroing the LRT's weight) pushed the whole fusion onto flatness+harmonicity and made
            // P on pure noise go UP from 0.44 to 0.66. See NOTES.md 9.8.
            eff_thr_lrt_ = kMaxLrt;
        }

        // --- flatness: two peaks, then a minimum-count and minimum-centre test ---
        float t = 0.f; long pc = 0;
        hist_flat_.two_peaks(kPeakSpacingFlat, kPeakWeightFlat, t, pc);
        const long min_peak = (long)((float)W * 0.3f);      // [Zoom: (int)(window * 0.3)]
        if (pc < min_peak || t < kMinCentreFlat) {
            hist_ok_flat_ = false;                          // weight 0
        } else {
            hist_ok_flat_ = true;
            eff_thr_flat_ = std::clamp(t * kFactor2, kMinFlat, kMaxFlat);
        }

        // --- spectral difference: same search, and it is ALSO killed when the LRT did not
        //     fluctuate (the binary ANDs the two conditions). ---
        hist_diff_.two_peaks(kPeakSpacingDiff, kPeakWeightDiff, t, pc);
        eff_thr_diff_ = std::clamp(t * kFactor1, kMinDiff, kMaxDiff);
        hist_ok_diff_ = (pc >= min_peak) && lrt_ok;

        // --- weights: EQUAL, 1/N over the informative features, LRT always included ---
        const float n = 1.f + (hist_ok_flat_ ? 1.f : 0.f) + (hist_ok_diff_ ? 1.f : 0.f);
        w_lrt_  = 1.f / n;
        w_flat_ = (hist_ok_flat_ ? 1.f : 0.f) / n;
        w_diff_ = (hist_ok_diff_ ? 1.f : 0.f) / n;
        hist_ok_lrt_ = lrt_ok;

        hist_lrt_.clear(); hist_flat_.clear(); hist_diff_.clear();
    }

    static float tanh_feature(float value, float threshold, bool sharp) {
        return (std::tanh((value - threshold) * (sharp ? 8.f : 4.f)) + 1.f) * 0.5f;
    }

    // Install the three two-state HMMs.
    //
    // WHICH FEATURES, and why not the three the tanh path fuses. Frames were labelled from the CLEAN
    // reference (not from any P we compute) and each feature's gap-vs-speech separation measured as
    // d-prime = |mu_speech - mu_gap| / pooled sd, on clnsp379 + Typing_1 @5 dB, 764 speech / 94 gap
    // frames:
    //
    //   xi_flatness (dB)  gap  -4.30  speech -10.50   d-prime 1.55   <- best, and weight was ZERO
    //   snr_db            gap  -4.25  speech  +8.95   d-prime 1.31   <- not fused at all
    //   harmonicity       gap   0.329 speech   0.548  d-prime 1.24   <- dropped in Histogram mode
    //   spec_diff         gap   0.535 speech   0.734  d-prime 0.59
    //   flat_avg          gap   0.692 speech   0.662  d-prime 0.42   <- 1/3 of the fusion weight
    //   lrt_avg           gap   2.152 speech   6.771  d-prime 0.40   <- 1/3, and "always counts"
    //
    // The three features the fusion actually uses are the three WORST separators; the three best are
    // unweighted or unused. That ordering, not the threshold rule, is why transient noise survived
    // at 0.12-1.75 dB (NOTES.md 13/15). So the HMMs go on the top three.
    //
    // Log domain for the two ratio-like features. lrt_avg is heavy-tailed (median 2.15, p90 31), and
    // a Gaussian state model on a heavy tail is badly conditioned -- xi_flatness gains d-prime
    // 1.18 -> 1.55 purely from the dB transform. This is also why BOTH of Zoom's classifiers work in
    // a log/dB domain rather than on raw ratios.
    //
    // The MEANS are ours, measured as above. Zoom's ({25,45} ratio-domain, {-44,-25} dB) are in its
    // own feature units; its literal tanh widths already cost us a working detector once when
    // transplanted. What IS taken from Zoom: the structure, sd = 0.5x gap, 0.99 self-transition,
    // adaptive means, and the level ladder acting on the decision point.
    void configure_hmm() {
        hmm_lrt_.configure ( -4.25f,   8.95f, -40.f, 25.f, hmm_sd_scale_, hmm_adapt_, hmm_stay_); // snr_db
        hmm_flat_.configure( -4.30f, -10.50f, -20.f,  1.f, hmm_sd_scale_, hmm_adapt_, hmm_stay_); // xi_flat dB
        hmm_diff_.configure(  0.329f,  0.548f,  0.f,  1.f, hmm_sd_scale_, hmm_adapt_, hmm_stay_); // harmonicity
        hmm_lrt_.set_bias(hmm_level_bias_);
        hmm_flat_.set_bias(hmm_level_bias_);
        hmm_diff_.set_bias(hmm_level_bias_);
        hmm_ready_ = true;
    }

    // constants
    static constexpr float kAlphaDDDefault  = 0.98f;  // decision-directed        [Zoom: 0.98]
    static constexpr float kAlphaLrtDefault = 0.5f;   // per-bin LRT smoothing    [Zoom: 0.5]
    // Speech-probability smoothing. Zoom uses 0.1. We raised it to 0.3 because the SYNTHETIC
    // bench showed better speech/noise separation -- but that bench rewards aggressive gating and
    // is now known to be misleading (NOTES.md 5.6). Faster smoothing means the gain fluctuates
    // more between frames, which is the classic cause of musical noise and lost intelligibility.
    // Runtime-settable so it can be A/B'd on REAL data, which is the only bench that counts.
    // Chosen on REAL data (NOTES.md 5.7). Sweep at level 2, 120 runs/variant:
    //   alpha  dSTOI    dESTOI   dSI-SDR  tau
    //   0.30  -0.0222  -0.0053    +0.10    53 ms   <- old default, from the misleading synthetic bench
    //   0.10  -0.0138  +0.0012    +0.09   160 ms   <- Zoom's value; ESTOI turns POSITIVE here
    //   0.05  -0.0101  +0.0046    +0.07   320 ms   <- chosen
    //   0.02  -0.0078  +0.0069    -0.06   800 ms
    //   0.01  -0.0074  +0.0076    -0.13   1.6 s
    // 0.01 scores best on ESTOI but its 1.6 s time constant means P needs over a second to react
    // to speech onset after silence. The eval uses 10 s continuous clips, so it CANNOT see that
    // failure mode — picking the metric optimum here would be over-fitting to a bench blind spot.
    // 0.05 keeps ESTOI clearly positive and SI-SDR non-negative at a defensible 320 ms.
    static constexpr float kAlphaPDefault = 0.05f;
    static constexpr float kPMin     = 0.01f;  // probability clamp             [Zoom: 0.01]
    static constexpr float kBetaSlow = 0.95f;  // noise tracker, steady state
    static constexpr float kBetaFast = 0.75f;  // noise tracker, after a scene change
    static constexpr int   kInitFrames = 12;   // bootstrap frames
    static constexpr float kAlphaFeat = 0.3f;  // flatness / diff smoothing      [Zoom: 0.3]
    static constexpr int   kFitLowBin  = 5;    // power-law fit skips low bins   [Zoom: 5]
    static constexpr int   kNoiseFitFrames = 50; // fitted floor fades out by    [Zoom: 50]
    static constexpr long  kMakeupWarmup = 200; // makeup gain only after warm-up  [Zoom: 200]

    int sr_, n_, hop_, bins_, level_ = 2;
    float gain_floor_ = 0.25f, oversub_ = 1.25f;
    Fft fft_;
    std::vector<float> win_;
    std::vector<float> noise_, prev_gain_, prev_gamma_;
    std::vector<std::complex<float>> spec_;
    std::vector<float> inq_, ola_, prob_hist_, mag_, tmpl_, lrt_;
    SoundEventDetector sed_;
    bool tmpl_ready_ = false;
    int tmpl_frames_ = 0;
    int band_lo_[4] = {0, 0, 0, 0}, band_hi_[4] = {0, 0, 0, 0};
    float speech_prob_ = 0.f, lrt_ctr_ = 0.5f, flat_ctr_ = 0.5f, diff_ctr_ = 0.1f, lt_noise_ = 0.f;
    // Per-bin speech-presence probability (Zoom E3380's output array). Feeds the noise tracker.
    std::vector<float> spp_, noise_slow_;
    ThreshMode thresh_mode_ = ThreshMode::Histogram;
    // Absolute feature thresholds. 0.5 for all three is WebRTC-NS's published default and the
    // scale our Lambda/flatness/spectral-difference features already live on; the histogram
    // refines them per window when it can prove the feature is bimodal.
    // Read off the measured p10/p50/p90 of each feature on pure noise vs pure speech, NOT from
    // WebRTC's published 0.5 defaults -- those are on a different feature scaling and put all three
    // thresholds above everything our features ever produce.
    // The recovered parameter block (a2+1124..1200 == E45C0's a1[6485..6504]). These are WebRTC
    // NS's published NSParaExtract defaults, which is what identifies the detector.
    static constexpr float kLrtLowBound      = 1.0f;    // a2+1136
    static constexpr float kFactor1          = 1.2f;    // a2+1140  (LRT and diff thresholds)
    static constexpr float kFactor2          = 0.9f;    // a2+1144  (flatness threshold)
    static constexpr float kMinCentreFlat    = 0.6f;    // a2+1148
    static constexpr float kPeakSpacingFlat  = 0.1f;    // a2+1152
    static constexpr float kPeakSpacingDiff  = 0.2f;    // a2+1156
    static constexpr float kPeakWeightFlat   = 0.5f;    // a2+1160
    static constexpr float kPeakWeightDiff   = 0.5f;    // a2+1164
    static constexpr float kThresFluctLrt    = 0.05f;   // a2+1168
    static constexpr float kMaxLrt = 1.0f,  kMinLrt  = 0.2f;    // a2+1172 / a2+1176
    static constexpr float kMaxFlat = 0.95f, kMinFlat = 0.1f;   // a2+1180 / a2+1184
    static constexpr float kMaxDiff = 1.0f,  kMinDiff = 0.16f;  // a2+1188 / a2+1192
    static constexpr float kBinSizeLrt = 0.1f, kBinSizeFlat = 0.05f, kBinSizeDiff = 0.1f;
    float w_lrt_ = 1.f, w_flat_ = 0.f, w_diff_ = 0.f;   // runtime fusion weights [Zoom a2[8..10]]
    float thr_lrt_ = 0.05f, thr_flat_ = 0.32f, thr_diff_ = 0.47f;
    float eff_thr_lrt_ = 0.05f, eff_thr_flat_ = 0.32f, eff_thr_diff_ = 0.47f;
    // Per-feature spread, so the recovered tanh widths (4 / 8) land on a comparable scale.
    float sc_lrt_ = 0.10f, sc_flat_ = 0.06f, sc_diff_ = 0.25f;
    // SURPRISE, and left as measured: 0.45/0.15 is what the distributions say (noise p50 0.397,
    // speech p50 0.510) but it measured WORSE end-to-end -- separation 0.1119 -> 0.0646. P feeds
    // the SPP-weighted noise update, which feeds gamma/xi, which feeds Lambda, which feeds p_snr:
    // the features are not independent knobs and tuning one from its own marginal distribution can
    // move another the wrong way. Keeping the value that measured better, not the one that looks
    // principled. Settable so the pair can be re-swept once a subjective A/B exists.
    float thr_harm_ = 0.30f, sc_harm_ = 0.30f;
    bool  hist_ok_lrt_ = false, hist_ok_flat_ = false, hist_ok_diff_ = false;
    int   hist_window_ = 250;          // ~4 s at 62 fps. Zoom's window is not recovered.
    bool  zoom_noise_update_ = true;   // 1.15x rise cap + 0.9/0.99 beta switch + slow tracker
    // Both of these are Zoom's, both verified in the binary, and both DEFAULT OFF because they
    // measured worse or inert HERE. Recording that honestly matters more than fidelity-by-default:
    //  adaptive alpha_dd -- worse. Babble attenuation 5.63 -> 5.15 dB, Munching 4.22 -> 3.46,
    //    Typing-mixture SI-SDR 2.11 -> 0.88. It makes noise bins adapt fast, which in our pipeline
    //    lets the noise estimate chase the noise UP, shrinking gamma-1 and hence the suppression.
    //    Zoom presumably compensates elsewhere (its gain is band-interpolated, ours is per-bin).
    //  attack limit -- inert. Changed not one digit on any of 4 noise types x 3 mixtures: our gain
    //    never triples between frames, because the decision-directed memory already slews it.
    //    Kept because it is real and may bite once the gain structure changes.
    bool  adaptive_alpha_dd_ = false;   // alpha = 0.9*(xi/(1+xi))^2 + 0.1   [Zoom DB830]
    bool  attack_limit_ = true;        // gain rises at most 3x per frame   [Zoom E16C0]
    // DEFAULT OFF, and the reason is itself evidence. Transcribing DC360's single contiguous range
    // (low 8 bins excluded, top 5% of magnitude trimmed) yields flatness 0.5475 / 0.4418 / 0.4716 on
    // AC-noise / babble / speech -- BELOW Zoom's own thresPosSpecFlat gate of 0.6, so sub_1801DD530
    // would declare the feature uninformative on every window and weight it 0. Zoom obviously does
    // not ship a detector whose best feature is permanently disabled, so something in this reading
    // of the range or its normalisation is still wrong (`a2+1120` may not be the full-spectrum sum,
    // or the downward walk may not be a top-energy trim).
    //
    // The 4-band magnitude mean lands at 0.75 / 0.74 / 0.66 -- it passes the gate, and it is where
    // p_flat separates best: 0.0004 on pure noise vs 0.6212 on pure speech (+0.62, the strongest of
    // the three features). Keeping the version that measures better and flagging the discrepancy.
    // 1.0 = the multiply is GONE, which is Zoom's shape. Measured against our old 0.35, on
    // AirConditioner @5 dB: gap-vs-speech gain modulation 0.44 -> 1.19 dB at level 2 and
    // 2.61 -> 4.18 dB at level 5 (i.e. audibly more gating), ESTOI 0.7295 -> 0.7489,
    // SI-SDR 5.45 -> 6.35, STOI 0.9566 -> 0.9547. Better on three of four AND more audible.
    //
    // Pushing it the other way made everything worse (0.15 and 0.05 both lost gain gap, ESTOI and
    // SI-SDR), which is the tell: a frame-level factor multiplies EVERY bin alike, so it attenuates
    // the speech bins along with the noise ones and compresses the very contrast it was meant to
    // create. Zoom spends the speech probability on the noise tracker instead, and that is why.
    float presence_lo_ = 1.0f;
    bool  sed_prob_clamp_ = false;    // ours, refuted -- see the fusion clamp note
    bool  dc360_flatness_ = false;    // single-range magnitude flatness  [Zoom DC360]
    std::vector<double> mag_lin_;
    bool  zoom_gain_limit_ = false;    // DB830's dB-domain limiter (target + bound + 5 dB pedestal)
    // 4 bands. Soft evidence for the count: E45C0 initialises three values via
    //   for (i = 200; i < 800; i += 200) *v11++ = floor(i / 3.0);   ->  66, 133, 200
    // i.e. three edges dividing something into four parts. The array they index is not
    // identified, so treat 4 as indicated-not-proven. Measured trade on babble @5dB:
    //   bands   AC att  Bab att  ESTOI    (0 = per-bin, our old behaviour)
    //     0     27.54   19.70   0.2024
    //     8     24.97   19.52   0.4029
    //     4     21.08   16.85   0.4241   <- chosen
    //     2     14.98   11.91   0.4539
    int   gain_bands_ = 0;            // band-reduced gain then interpolated  [Zoom E16C0]
    std::vector<float> band_g_, band_n_;
    float zoom_target_db_ = -65.f;    // the literal -65.0 in DB830
    float lvl_off_db_ = 0.f;          // `v7`: a level-dependent dB offset applied to both limits
    float zoom_limit_db_ = 0.f;       // `v13`'s base: the configured max-attenuation limit
    FeatureHistogram hist_lrt_, hist_flat_, hist_diff_;
    // ThreshMode::Hmm. One two-state Gaussian HMM per fused feature, replacing the memoryless
    // tanh map. Means are OUR measured medians (noise vs speech) -- see set_hmm_params.
    GaussianHmm2 hmm_lrt_, hmm_flat_, hmm_diff_;
    bool  hmm_ready_   = false;
    // Which three features go into the fusion. 0 = the original lrt/flat/diff triple (d-prime
    // 0.40 / 0.42 / 0.59), 1 = snr_db / xi_flatness(dB) / harmonicity (1.31 / 1.55 / 1.24).
    // Orthogonal to thresh_mode on purpose, so "which features" and "which threshold rule" can be
    // attributed separately -- they were changed together the first time and that told us nothing.
    int   feature_set_ = 0;
    float afloor_extra_db_ = 0.f;    // P-driven extra floor depth, dB (0 = mechanism off)
    float afloor_knee_     = 0.35f;  // P below which the extra depth starts fading in
    // Absolute thresholds (midpoint of the measured noise/speech medians) and scales (pooled sd)
    // for feature_set_ == 1.
    float fthr_snr_ = 2.35f,  fsc_snr_ = 10.06f;
    float fthr_xif_ = -7.40f, fsc_xif_ = 3.99f;
    float fthr_hrm_ = 0.439f, fsc_hrm_ = 0.177f;
    float hmm_adapt_   = 0.002f;   // Zoom's per-kind rates are 0.001 / 0.002 / 0.005
    float hmm_stay_    = 0.99f;    // Zoom: 0.99 self-transition, both classifiers
    float hmm_sd_scale_ = 0.5f;    // Zoom: sd ~= 0.5x inter-state gap (12/20, 10/19)
    float hmm_level_bias_ = 0.f;   // level ladder acts HERE, not on the gain floor
    float flat_s_ = 0.5f, sdiff_s_ = 0.f;   // alpha=0.3 smoothed features (Zoom DC360/DBFF0)
    float xiflat_ = 1.f, xiflat_s_ = 1.f, xif_ctr_ = 1.f;   // (1+xi)^2 flatness (Zoom DBD10)
    int change_run_ = 0, noise_changed_hold_ = 0;
    long frames_seen_ = 0;
    bool powerlaw_init_ = true;   // see initialise_noise(); switchable for real-data A/B
    float alpha_p_ = kAlphaPDefault;   // speech-probability smoothing; A/B-able
    float alpha_dd_ = kAlphaDDDefault, alpha_lrt_ = kAlphaLrtDefault;
    float w_xiflat_ = 0.f;             // (1+xi)^2 flatness fusion weight
    bool  sed_steer_ = true;           // SED -> music protection / noise freeze
    GainLaw gain_law_ = GainLaw::Posterior;
    // Post-gain level normalisation: DEFAULT OFF, decided on real data (NOTES.md 5.9).
    //   variant     dSTOI    dESTOI   dSI-SDR  dsegSNR   dLSD
    //   raw        -0.0046  +0.0046    +0.14    -1.25   -1.60
    //   smoothed   -0.0045  +0.0045    +0.11    -1.31   -1.59   <- smoothing changes nothing
    //   OFF        -0.0037  +0.0050    +0.27    -1.91   -1.76   <- wins 4 of 5
    // segSNR is the only metric that prefers makeup ON, and it is CONFOUNDED BY LEVEL: restoring
    // the level shrinks the waveform amplitude error regardless of whether the content improved.
    // SI-SDR is scale-invariant and reverses the verdict. So we keep the mechanism (it is faithful
    // to Zoom E56E0 and may matter inside a full 3A chain with AGC downstream, which we do not
    // have) but ship it disabled.
    bool  makeup_on_ = false;
    float makeup_alpha_ = 1.f;         // 1.0 = unsmoothed (as recovered)
    float makeup_s_ = 1.f, mk_prev_ = -1.f, mk_jit_sum_ = 0.f;
    long  mk_jit_n_ = 0;
    float floor_base_db_ = -12.f, floor_off_db_ = 0.f;
    // Absolute dBFS suppression floor: implemented, measured, DEFAULT OFF (NOTES.md 5.10).
    //   variant   dSTOI    dESTOI   dSI-SDR   dLSD
    //   off      -0.0037  +0.0050    +0.27   -1.76
    //   -65 dB   -0.0032  +0.0036    +0.24   -1.06   <- binds, and BLOCKS real suppression
    //   -80 dB   -0.0037  +0.0049    +0.27   -1.61   <- barely binds
    //   -95 dB   -0.0037  +0.0050    +0.27   -1.78   <- inert
    // Either it binds and costs ESTOI/LSD, or it does nothing. No useful setting exists here.
    //
    // WHY this is not a refutation of Zoom's design: Zoom DB830 computes
    //     gain = 10^( min(-5, max(a, b)) / 10 )
    // where b contains the -65 dBFS term but ALSO a per-frame level term, and `a` is a second
    // adaptive bound. We implemented ONLY the -65 clause, i.e. a plain absolute bound, and a plain
    // absolute bound is exactly what our data says does not work. Reproducing the full
    // multi-clause expression would need ns[52308/52312/52316], which we did not recover.
    bool  abs_floor_on_ = false;
    float abs_floor_dbfs_ = -65.f;     // [Zoom DB830 clause: -65 dBFS]
    float fs_bin_pow_ = 1.f;           // bin power of a full-scale sine (calibrated)
    int   freq_taps_ = 1;              // gain smoothing across frequency (1 = off)
    float time_alpha_ = 1.f;           // gain smoothing across time (1 = off)
    std::vector<float> gain_, gsmooth_, gt_;
    // running sums for the power-law noise-floor fit (Zoom E3950)
    float fit_sx_ = 0.f, fit_sxx_ = 0.f, fit_sy_ = 0.f, fit_sxy_ = 0.f, fit_n_ = 0.f;
    Telemetry tm_;
};

} // namespace nsx
