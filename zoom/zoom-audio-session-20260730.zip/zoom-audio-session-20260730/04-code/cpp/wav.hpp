// wav.hpp — minimal 16-bit PCM WAV read/write (mono; multi-channel input is downmixed).
#pragma once
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <string>
#include <vector>
#include <algorithm>

namespace nsx {

struct Wav {
    int sample_rate = 16000;
    std::vector<float> samples;   // mono, [-1, 1]
};

inline bool wav_read(const std::string& path, Wav& out, std::string* err = nullptr) {
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) { if (err) *err = "cannot open " + path; return false; }
    char riff[12];
    if (std::fread(riff, 1, 12, f) != 12 || std::memcmp(riff, "RIFF", 4) || std::memcmp(riff + 8, "WAVE", 4)) {
        std::fclose(f); if (err) *err = "not a RIFF/WAVE file"; return false;
    }
    int channels = 1, bits = 16; bool have_fmt = false;
    while (true) {
        char id[4]; uint32_t sz;
        if (std::fread(id, 1, 4, f) != 4 || std::fread(&sz, 4, 1, f) != 1) break;
        if (!std::memcmp(id, "fmt ", 4)) {
            std::vector<uint8_t> b(sz);
            if (std::fread(b.data(), 1, sz, f) != sz) break;
            uint16_t fmt; std::memcpy(&fmt, &b[0], 2);
            std::memcpy(&channels, &b[2], 2); channels &= 0xFFFF;
            uint32_t sr; std::memcpy(&sr, &b[4], 4); out.sample_rate = (int)sr;
            std::memcpy(&bits, &b[14], 2); bits &= 0xFFFF;
            have_fmt = true;
            if (fmt != 1 && fmt != 0xFFFE) { std::fclose(f); if (err) *err = "only PCM supported"; return false; }
        } else if (!std::memcmp(id, "data", 4)) {
            if (!have_fmt || bits != 16) { std::fclose(f); if (err) *err = "only 16-bit PCM supported"; return false; }
            const size_t nsamp = sz / 2;
            std::vector<int16_t> pcm(nsamp);
            if (std::fread(pcm.data(), 2, nsamp, f) != nsamp) { std::fclose(f); if (err) *err = "short data chunk"; return false; }
            const size_t frames = channels > 0 ? nsamp / channels : nsamp;
            out.samples.resize(frames);
            for (size_t i = 0; i < frames; ++i) {
                int acc = 0;
                for (int c = 0; c < channels; ++c) acc += pcm[i * channels + c];
                out.samples[i] = (float)acc / (channels * 32768.0f);
            }
            std::fclose(f);
            return true;
        } else {
            std::fseek(f, (long)(sz + (sz & 1)), SEEK_CUR);
        }
    }
    std::fclose(f);
    if (err) *err = "no data chunk";
    return false;
}

inline bool wav_write(const std::string& path, const Wav& w) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    const uint32_t n = (uint32_t)w.samples.size();
    const uint32_t data_bytes = n * 2;
    const uint32_t riff_sz = 36 + data_bytes;
    const uint16_t ch = 1, bits = 16, fmt = 1, align = 2;
    const uint32_t sr = (uint32_t)w.sample_rate, brate = sr * 2;
    const uint32_t fmt_sz = 16;
    std::fwrite("RIFF", 1, 4, f); std::fwrite(&riff_sz, 4, 1, f); std::fwrite("WAVE", 1, 4, f);
    std::fwrite("fmt ", 1, 4, f); std::fwrite(&fmt_sz, 4, 1, f);
    std::fwrite(&fmt, 2, 1, f); std::fwrite(&ch, 2, 1, f); std::fwrite(&sr, 4, 1, f);
    std::fwrite(&brate, 4, 1, f); std::fwrite(&align, 2, 1, f); std::fwrite(&bits, 2, 1, f);
    std::fwrite("data", 1, 4, f); std::fwrite(&data_bytes, 4, 1, f);
    for (uint32_t i = 0; i < n; ++i) {
        float s = w.samples[i];
        if (s > 1.f) s = 1.f; if (s < -1.f) s = -1.f;
        int16_t v = (int16_t)lrintf(s * 32767.f);
        std::fwrite(&v, 2, 1, f);
    }
    std::fclose(f);
    return true;
}

// ---------------------------------------------------------------- tiny path/dir helpers
// Win32-only directory listing, kept here so the eval harness needs no extra dependency and the
// exe stays a single static binary.
inline std::string base_name(const std::string& p) {
    const size_t s = p.find_last_of("/\\");
    return s == std::string::npos ? p : p.substr(s + 1);
}

inline bool ends_with_ci(const std::string& s, const std::string& suf) {
    if (s.size() < suf.size()) return false;
    for (size_t i = 0; i < suf.size(); ++i) {
        char a = s[s.size() - suf.size() + i], b = suf[i];
        if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
        if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
        if (a != b) return false;
    }
    return true;
}

std::vector<std::string> list_wavs(const std::string& dir);

} // namespace nsx

#ifdef _WIN32
// windows.h defines min/max as macros, which breaks every std::min/std::max in this project.
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
namespace nsx {
inline std::vector<std::string> list_wavs(const std::string& dir) {
    std::vector<std::string> out;
    std::string pat = dir;
    if (!pat.empty() && pat.back() != '\\' && pat.back() != '/') pat += "\\";
    const std::string prefix = pat;
    pat += "*.wav";
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pat.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return out;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
            out.push_back(prefix + fd.cFileName);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
    std::sort(out.begin(), out.end());
    return out;
}
} // namespace nsx
#else
#include <dirent.h>
#include <algorithm>
namespace nsx {
inline std::vector<std::string> list_wavs(const std::string& dir) {
    std::vector<std::string> out;
    DIR* d = opendir(dir.c_str());
    if (!d) return out;
    while (dirent* e = readdir(d))
        if (ends_with_ci(e->d_name, ".wav")) out.push_back(dir + "/" + e->d_name);
    closedir(d);
    std::sort(out.begin(), out.end());
    return out;
}
} // namespace nsx
#endif
