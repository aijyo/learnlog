// metrics.hpp — objective speech-enhancement metrics, self-contained (no external deps).
//
// Implemented here, with the exact definition each one uses, because "PESQ/STOI" without a stated
// variant is not a reproducible number:
//
//   STOI   — Taal et al. 2011, Short-Time Objective Intelligibility. Operates at 10 kHz on
//            15 one-third-octave bands from 150 Hz, 256-sample Hann frames / 50% overlap,
//            30-frame (384 ms) segments, per-band normalise + clip at -15 dB, then the mean
//            correlation coefficient. Inputs are resampled to 10 kHz internally.
//   ESTOI  — Jensen & Taal 2016 (extended). Same front end, but correlates the whole
//            row-normalised band matrix per segment instead of per band. Better for
//            modulated/non-stationary noise, which is exactly our case.
//   SI-SDR — Le Roux et al. 2019, scale-invariant SDR in dB. Immune to overall gain, which
//            matters here because our makeup-gain stage changes level on purpose.
//   segSNR — segmental SNR, 20 ms frames, per-frame clamped to [-10, +35] dB (standard practice)
//            and averaged over frames above a silence floor.
//   LSD    — log-spectral distance in dB, RMS over frames and bins.
//
// PESQ (ITU-T P.862) is deliberately NOT implemented: it is a large, licence-encumbered
// specification and a hand-rolled approximation would produce numbers that look authoritative
// while not being P.862. If a PESQ score is needed, run a certified external tool on the WAVs
// this harness writes out, and report it as such.
#pragma once
#include <vector>
#include <complex>
#include <cmath>
#include <algorithm>
#include <limits>
#include "ns_core.hpp"

namespace nsx {
namespace metrics {

// ---------------------------------------------------------------- resampling
// Windowed-sinc (Blackman, 32 taps/zero-crossing side) rational resampler. Good enough that the
// metric is not measuring the resampler; STOI needs a real 10 kHz signal, not a decimated one.
inline std::vector<float> resample(const std::vector<float>& x, int sr_in, int sr_out) {
    if (sr_in == sr_out || x.empty()) return x;
    const double ratio = (double)sr_out / (double)sr_in;
    const size_t n_out = (size_t)std::floor(x.size() * ratio);
    std::vector<float> y(n_out, 0.f);
    const int half = 32;
    // cutoff at the lower Nyquist, normalised to the INPUT rate
    const double fc = 0.5 * std::min(1.0, ratio);
    for (size_t i = 0; i < n_out; ++i) {
        const double center = (double)i / ratio;
        const long   base   = (long)std::floor(center);
        double acc = 0.0, wsum = 0.0;
        for (int k = -half; k <= half; ++k) {
            const long idx = base + k;
            if (idx < 0 || idx >= (long)x.size()) continue;
            const double d = center - (double)idx;
            // sinc
            const double a = 2.0 * fc * d;
            const double s = (std::fabs(a) < 1e-9) ? 1.0 : std::sin(Fft::kPi * a) / (Fft::kPi * a);
            // Blackman window over the tap span
            const double t = (d + half) / (2.0 * half);
            const double w = (t < 0.0 || t > 1.0) ? 0.0
                           : 0.42 - 0.5 * std::cos(2.0 * Fft::kPi * t) + 0.08 * std::cos(4.0 * Fft::kPi * t);
            acc  += x[(size_t)idx] * s * w;
            wsum += s * w;
        }
        y[i] = (float)(wsum > 1e-12 ? acc / wsum : 0.0);
    }
    return y;
}

// ---------------------------------------------------------------- helpers
inline double energy(const std::vector<float>& x) {
    double e = 0.0;
    for (float v : x) e += (double)v * v;
    return e;
}

// ---------------------------------------------------------------- SI-SDR
// s_target = <x,s>/<s,s> * s ; SI-SDR = 10 log10(|s_target|^2 / |e|^2)
inline double si_sdr(const std::vector<float>& ref, const std::vector<float>& est) {
    const size_t n = std::min(ref.size(), est.size());
    if (n == 0) return -std::numeric_limits<double>::infinity();
    double mr = 0.0, me = 0.0;
    for (size_t i = 0; i < n; ++i) { mr += ref[i]; me += est[i]; }
    mr /= n; me /= n;
    double dot = 0.0, rr = 0.0;
    for (size_t i = 0; i < n; ++i) {
        const double r = ref[i] - mr, e = est[i] - me;
        dot += r * e; rr += r * r;
    }
    if (rr < 1e-20) return -std::numeric_limits<double>::infinity();
    const double a = dot / rr;
    double st = 0.0, err = 0.0;
    for (size_t i = 0; i < n; ++i) {
        const double t = a * (ref[i] - mr);
        const double d = (est[i] - me) - t;
        st += t * t; err += d * d;
    }
    if (err < 1e-20) return 100.0;
    return 10.0 * std::log10(st / err);
}

// ---------------------------------------------------------------- segmental SNR
inline double seg_snr(const std::vector<float>& ref, const std::vector<float>& est, int sr) {
    const int win = std::max(1, sr / 50);            // 20 ms
    const size_t n = std::min(ref.size(), est.size());
    double sum = 0.0; long cnt = 0;
    // silence floor: 40 dB below the loudest frame of the reference
    double peak = 1e-20;
    for (size_t s = 0; s + win <= n; s += win) {
        double e = 0.0;
        for (int i = 0; i < win; ++i) e += (double)ref[s + i] * ref[s + i];
        peak = std::max(peak, e);
    }
    const double floor_e = peak * 1e-4;
    for (size_t s = 0; s + win <= n; s += win) {
        double se = 0.0, ne = 0.0;
        for (int i = 0; i < win; ++i) {
            const double r = ref[s + i], d = (double)est[s + i] - r;
            se += r * r; ne += d * d;
        }
        if (se < floor_e) continue;
        double v = 10.0 * std::log10((se + 1e-20) / (ne + 1e-20));
        sum += std::clamp(v, -10.0, 35.0);
        ++cnt;
    }
    return cnt ? sum / cnt : 0.0;
}

// ---------------------------------------------------------------- log-spectral distance
inline double lsd(const std::vector<float>& ref, const std::vector<float>& est, int /*sr*/) {
    const int n = 512, hop = 256, bins = n / 2 + 1;
    Fft fft(n);
    std::vector<float> win(n);
    for (int i = 0; i < n; ++i) win[i] = 0.5f * (1.f - std::cos(2.f * (float)Fft::kPi * i / (n - 1)));
    const size_t len = std::min(ref.size(), est.size());
    std::vector<std::complex<float>> a(n), b(n);
    double acc = 0.0; long frames = 0;
    for (size_t s = 0; s + n <= len; s += hop) {
        for (int i = 0; i < n; ++i) {
            a[i] = std::complex<float>(ref[s + i] * win[i], 0.f);
            b[i] = std::complex<float>(est[s + i] * win[i], 0.f);
        }
        fft.forward(a); fft.forward(b);
        double d = 0.0;
        for (int k = 0; k < bins; ++k) {
            const double pa = std::norm(a[k]) + 1e-10, pb = std::norm(b[k]) + 1e-10;
            const double diff = 10.0 * std::log10(pa) - 10.0 * std::log10(pb);
            d += diff * diff;
        }
        acc += std::sqrt(d / bins);
        ++frames;
    }
    return frames ? acc / frames : 0.0;
}

// ---------------------------------------------------------------- STOI / ESTOI
// Shared front end: 10 kHz, 256-sample Hann / 128 hop, 15 one-third-octave bands from 150 Hz.
struct StoiFrontEnd {
    static constexpr int kSr = 10000, kN = 512, kFrame = 256, kHop = 128, kBands = 15, kSeg = 30;

    // band energy matrix: bands x frames (sqrt of summed power), and the frame index list kept
    std::vector<std::vector<float>> clean, proc;

    bool build(const std::vector<float>& c_in, const std::vector<float>& p_in, int sr) {
        std::vector<float> c = resample(c_in, sr, kSr);
        std::vector<float> p = resample(p_in, sr, kSr);
        const size_t len = std::min(c.size(), p.size());
        if (len < (size_t)kFrame * 2) return false;
        c.resize(len); p.resize(len);

        // --- remove silent frames (>40 dB below the loudest clean frame) ---
        std::vector<size_t> keep;
        double peak = 1e-20;
        for (size_t s = 0; s + kFrame <= len; s += kHop) {
            double e = 0.0;
            for (int i = 0; i < kFrame; ++i) e += (double)c[s + i] * c[s + i];
            peak = std::max(peak, e);
        }
        const double thr = peak * 1e-4;
        for (size_t s = 0; s + kFrame <= len; s += kHop) {
            double e = 0.0;
            for (int i = 0; i < kFrame; ++i) e += (double)c[s + i] * c[s + i];
            if (e >= thr) keep.push_back(s);
        }
        if (keep.size() < (size_t)kSeg) return false;

        // --- 1/3-octave band edges from 150 Hz ---
        int lo[kBands], hi[kBands];
        for (int b = 0; b < kBands; ++b) {
            const double cf = 150.0 * std::pow(2.0, b / 3.0);
            const double fl = cf / std::pow(2.0, 1.0 / 6.0), fh = cf * std::pow(2.0, 1.0 / 6.0);
            lo[b] = std::max(0, (int)std::round(fl * kN / kSr));
            hi[b] = std::min(kN / 2, (int)std::round(fh * kN / kSr));
            if (hi[b] <= lo[b]) hi[b] = lo[b] + 1;
        }

        Fft fft(kN);
        std::vector<float> w(kFrame);
        for (int i = 0; i < kFrame; ++i)
            w[i] = 0.5f * (1.f - std::cos(2.f * (float)Fft::kPi * (i + 1) / (kFrame + 1)));

        clean.assign(kBands, {}); proc.assign(kBands, {});
        std::vector<std::complex<float>> A(kN), B(kN);
        for (size_t f : keep) {
            std::fill(A.begin(), A.end(), std::complex<float>(0.f, 0.f));
            std::fill(B.begin(), B.end(), std::complex<float>(0.f, 0.f));
            for (int i = 0; i < kFrame; ++i) {
                A[i] = std::complex<float>(c[f + i] * w[i], 0.f);
                B[i] = std::complex<float>(p[f + i] * w[i], 0.f);
            }
            fft.forward(A); fft.forward(B);
            for (int b = 0; b < kBands; ++b) {
                double ea = 0.0, eb = 0.0;
                for (int k = lo[b]; k < hi[b]; ++k) { ea += std::norm(A[k]); eb += std::norm(B[k]); }
                clean[b].push_back((float)std::sqrt(ea));
                proc [b].push_back((float)std::sqrt(eb));
            }
        }
        return clean[0].size() >= (size_t)kSeg;
    }
};

inline double corr(const std::vector<double>& a, const std::vector<double>& b) {
    const size_t n = a.size();
    if (n < 2) return 0.0;
    double ma = 0.0, mb = 0.0;
    for (size_t i = 0; i < n; ++i) { ma += a[i]; mb += b[i]; }
    ma /= n; mb /= n;
    double num = 0.0, da = 0.0, db = 0.0;
    for (size_t i = 0; i < n; ++i) {
        const double x = a[i] - ma, y = b[i] - mb;
        num += x * y; da += x * x; db += y * y;
    }
    const double den = std::sqrt(da * db);
    return den > 1e-20 ? num / den : 0.0;
}

// classic STOI: per band, per segment, with normalisation + clipping
inline double stoi(const std::vector<float>& c_in, const std::vector<float>& p_in, int sr) {
    StoiFrontEnd fe;
    if (!fe.build(c_in, p_in, sr)) return -1.0;
    const int B = StoiFrontEnd::kBands, S = StoiFrontEnd::kSeg;
    const int F = (int)fe.clean[0].size();
    const double beta = std::pow(10.0, -15.0 / 20.0);   // -15 dB clip
    double sum = 0.0; long cnt = 0;
    for (int m = S - 1; m < F; ++m) {
        for (int b = 0; b < B; ++b) {
            std::vector<double> x(S), y(S);
            double ex = 0.0, ey = 0.0;
            for (int i = 0; i < S; ++i) {
                x[i] = fe.clean[b][m - S + 1 + i];
                y[i] = fe.proc [b][m - S + 1 + i];
                ex += x[i] * x[i]; ey += y[i] * y[i];
            }
            const double a = std::sqrt(ex / std::max(ey, 1e-20));
            for (int i = 0; i < S; ++i) {
                const double yn = y[i] * a;
                y[i] = std::min(yn, x[i] * (1.0 + beta));   // normalise then clip
            }
            sum += corr(x, y);
            ++cnt;
        }
    }
    return cnt ? sum / cnt : -1.0;
}

// ESTOI: per segment, row-normalise the whole band matrix then correlate it as one vector.
// Preferred for modulated / non-stationary noise.
inline double estoi(const std::vector<float>& c_in, const std::vector<float>& p_in, int sr) {
    StoiFrontEnd fe;
    if (!fe.build(c_in, p_in, sr)) return -1.0;
    const int B = StoiFrontEnd::kBands, S = StoiFrontEnd::kSeg;
    const int F = (int)fe.clean[0].size();
    double sum = 0.0; long cnt = 0;
    for (int m = S - 1; m < F; ++m) {
        std::vector<double> X(B * S), Y(B * S);
        for (int b = 0; b < B; ++b) {
            std::vector<double> xr(S), yr(S);
            for (int i = 0; i < S; ++i) {
                xr[i] = fe.clean[b][m - S + 1 + i];
                yr[i] = fe.proc [b][m - S + 1 + i];
            }
            auto norm_row = [&](std::vector<double>& r) {
                double mu = 0.0;
                for (double v : r) mu += v;
                mu /= S;
                double sd = 0.0;
                for (double v : r) sd += (v - mu) * (v - mu);
                sd = std::sqrt(sd / S);
                for (double& v : r) v = (v - mu) / std::max(sd, 1e-20);
            };
            norm_row(xr); norm_row(yr);
            for (int i = 0; i < S; ++i) { X[b * S + i] = xr[i]; Y[b * S + i] = yr[i]; }
        }
        // column-normalise, then a single correlation over the whole segment matrix
        for (int i = 0; i < S; ++i) {
            double mx = 0.0, my = 0.0;
            for (int b = 0; b < B; ++b) { mx += X[b * S + i]; my += Y[b * S + i]; }
            mx /= B; my /= B;
            double sx = 0.0, sy = 0.0;
            for (int b = 0; b < B; ++b) {
                sx += (X[b * S + i] - mx) * (X[b * S + i] - mx);
                sy += (Y[b * S + i] - my) * (Y[b * S + i] - my);
            }
            sx = std::sqrt(sx / B); sy = std::sqrt(sy / B);
            for (int b = 0; b < B; ++b) {
                X[b * S + i] = (X[b * S + i] - mx) / std::max(sx, 1e-20);
                Y[b * S + i] = (Y[b * S + i] - my) / std::max(sy, 1e-20);
            }
        }
        sum += corr(X, Y);
        ++cnt;
    }
    return cnt ? sum / cnt : -1.0;
}

}  // namespace metrics
}  // namespace nsx
