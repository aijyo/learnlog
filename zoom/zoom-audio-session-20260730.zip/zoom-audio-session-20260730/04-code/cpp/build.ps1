# build.ps1 -- builds everything in dependency order and runs the tests.
#
# There are two build systems here because there are two languages, and the ORDER matters:
# nsxcore.dll must exist before either managed project can build (both copy it to their output and
# error out if it is missing). Run this instead of remembering that.
#
#   .\build.ps1              build C++ + managed, run all tests
#   .\build.ps1 -SkipTests   build only
#   .\build.ps1 -Run         build, test, then launch the UI

[CmdletBinding()]
param(
    [switch]$SkipTests,
    [switch]$Run,
    [string]$Config = 'Release'
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

function Step($msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }

# A previously launched UI holds nsxcore.dll and nsxui.dll open; MSBuild's copy then fails with
# MSB3027 after ten retries. Close it first rather than making the user decode that error.
Get-Process nsxui -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host "closing running nsxui (PID $($_.Id)) so its DLLs can be replaced"
    Stop-Process -Id $_.Id -Force
}
Start-Sleep -Milliseconds 500

Step "C++ (nsx.exe, nsxlab.exe, nsxcore.dll)"
cmake -S $root -B "$root\build" | Out-Null
cmake --build "$root\build" --config $Config
if ($LASTEXITCODE -ne 0) { throw "C++ build failed" }

Step "managed (nsxui.exe, nsxsmoke.exe)"
dotnet build "$root\ui\NsxUi.csproj"       -c $Config --nologo
if ($LASTEXITCODE -ne 0) { throw "nsxui build failed" }
dotnet build "$root\ui\smoke\Smoke.csproj" -c $Config --nologo
if ($LASTEXITCODE -ne 0) { throw "smoke build failed" }
dotnet build "$root\ui\themecheck\ThemeCheck.csproj" -c $Config --nologo
if ($LASTEXITCODE -ne 0) { throw "themecheck build failed" }

if (-not $SkipTests) {
    Step "tests"
    # selftest          : ungameable DSP invariants
    # lab_list          : the mechanism registry renders
    # interop_smoke     : P/Invoke results equal the CLI's, to 4 decimals
    # ui_theme_contrast : every styled control renders with legible contrast
    ctest --test-dir "$root\build" -C $Config --output-on-failure
    if ($LASTEXITCODE -ne 0) { throw "tests failed" }
}

Step "artifacts"
$items = @(
    "build\$Config\nsx.exe",
    "build\$Config\nsxlab.exe",
    "build\$Config\nsxlive.exe",
    "build\$Config\nsxcore.dll",
    "ui\bin\$Config\net9.0-windows\nsxui.exe"
)
foreach ($i in $items) {
    $p = Join-Path $root $i
    if (Test-Path $p) {
        Write-Host ("  {0,-52} {1,6:N0} KB" -f $i, ((Get-Item $p).Length / 1KB))
    } else {
        Write-Host "  $i  MISSING" -ForegroundColor Red
    }
}

if ($Run) {
    Step "launching UI"
    Start-Process (Join-Path $root "ui\bin\$Config\net9.0-windows\nsxui.exe")
}
