// live.cpp — nsxlive: microphone -> suppressor -> speakers, in real time.
//
// WHY THIS EXISTS
// Every conclusion in NOTES.md so far rests on objective metrics, and those metrics have repeatedly
// disagreed with each other and twice been outright misleading (5.6 the synthetic net-SNR bench,
// 14.3 the pure-noise attenuation figure that was rewarding a plain volume cut). The only judge that
// cannot be gamed is a listener, and the only way to convince a listener is instant A/B: press SPACE
// while talking and hear the suppressor engage and disengage on the same voice, same room, same
// breath. That is what this tool is for.
//
// It also unlocks the one measurement we have never been able to make. With --loopback the capture
// device is the system OUTPUT, so Zoom's own processed microphone stream can be recorded and run
// through scripts/band_selectivity.py -- which is the only honest way to answer "does Zoom's denoiser
// behave like ours".
//
// LATENCY: algorithmic latency is one FFT window (512 samples = 32 ms at 16 kHz) because
// process_hop() cannot emit a hop until the window it belongs to is complete. Device buffering adds
// its own; --period sets it.
//
// FEEDBACK WARNING: microphone into speakers in the same room WILL howl. Use headphones, or run with
// --no-playback and inspect the recording afterwards.
//
// BUILD: part of the nsx CMake project -> nsxlive.exe (static, miniaudio vendored in 3rd/)

#include "ns_core.hpp"
#include "nsx_config.hpp"
#include "wav.hpp"

#define MINIAUDIO_IMPLEMENTATION
#define MA_NO_DECODING
#define MA_NO_ENCODING
#define MA_NO_GENERATION
#define MA_NO_RESOURCE_MANAGER
#define MA_NO_NODE_GRAPH
#include "3rd/miniaudio.h"
#include "nsx_live_ma.hpp"

#include <atomic>
#include <conio.h>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

namespace {

constexpr int kSampleRate = 16000;

struct Live {
    nsx::NoiseSuppressor* ns = nullptr;
    int hop = 256;
    std::deque<float> in, out;
    std::mutex mtx;

    std::atomic<bool> bypass{false};
    std::atomic<int>  level{2};
    std::atomic<bool> level_dirty{false};

    // Level meters, updated from the audio thread and read by the console thread. Peak-decaying so a
    // transient stays visible long enough to see.
    std::atomic<float> peak_in{0.f}, peak_out{0.f};
    // Telemetry snapshot, so the console can show what the detector is deciding right now.
    std::atomic<float> p_speech{0.f}, gain{1.f}, snr_db{0.f};
    std::atomic<int>   sed_event{0};

    // Optional recording. Both streams are kept so the A/B can be repeated offline.
    bool record = false;
    std::vector<float> rec_raw, rec_proc;
    bool playback = true;
};

Live g;

void data_callback(ma_device* dev, void* out_v, const void* in_v, ma_uint32 frames) {
    const float* in = (const float*)in_v;
    float* out = (float*)out_v;
    (void)dev;

    std::lock_guard<std::mutex> lk(g.mtx);

    if (g.level_dirty.exchange(false)) g.ns->set_level(g.level.load());

    float pin = 0.f;
    for (ma_uint32 i = 0; i < frames; ++i) {
        const float v = in ? in[i] : 0.f;
        g.in.push_back(v);
        if (std::fabs(v) > pin) pin = std::fabs(v);
    }
    if (g.record && in) g.rec_raw.insert(g.rec_raw.end(), in, in + frames);

    // Drain whole hops. process_hop returns false until the first window has filled, and its output
    // necessarily lags the input by one window -- that is the algorithmic latency, not a bug.
    std::vector<float> hin((size_t)g.hop), hout((size_t)g.hop);
    while ((int)g.in.size() >= g.hop) {
        for (int i = 0; i < g.hop; ++i) { hin[(size_t)i] = g.in.front(); g.in.pop_front(); }
        const bool ready = g.ns->process_hop(hin.data(), hout.data());
        const bool bypass = g.bypass.load();
        for (int i = 0; i < g.hop; ++i)
            g.out.push_back(bypass ? hin[(size_t)i] : (ready ? hout[(size_t)i] : 0.f));
        if (ready && !bypass) {
            const nsx::Telemetry& t = g.ns->telemetry();
            g.p_speech.store(t.speech_prob);
            g.gain.store(t.gain);
            g.snr_db.store(t.snr_db);
            g.sed_event.store((int)t.sed.event);
        }
    }

    float pout = 0.f;
    for (ma_uint32 i = 0; i < frames; ++i) {
        float v = 0.f;
        if (!g.out.empty()) { v = g.out.front(); g.out.pop_front(); }
        // Record the PROCESSED sample, not what reaches the speakers. Those differ under
        // --no-playback, and taking it from the output buffer meant the safe mode -- the one you use
        // when you are NOT on headphones -- recorded pure silence. Measured: proc RMS -200 dBFS.
        if (g.record) g.rec_proc.push_back(v);
        if (out) out[i] = g.playback ? v : 0.f;
        if (std::fabs(v) > pout) pout = std::fabs(v);
    }

    // Decaying peak hold so the meter is readable at console refresh rates.
    const float dec = 0.85f;
    g.peak_in.store(pin > g.peak_in.load() ? pin : g.peak_in.load() * dec);
    g.peak_out.store(pout > g.peak_out.load() ? pout : g.peak_out.load() * dec);
}

// dB scale, not linear. Normal speech peaks around 0.05-0.2, which on a linear 16-cell bar rounds to
// zero cells -- the meter read empty while the detector was visibly reacting, i.e. the tool looked
// broken exactly when it was working. -60..0 dBFS covers the useful range.
void bar(float v, int width) {
    const float db = 20.f * std::log10(std::max(v, 1e-6f));
    const float frac = std::min(1.f, std::max(0.f, (db + 60.f) / 60.f));
    const int n = (int)(frac * (float)width + 0.5f);
    std::putchar('[');
    for (int i = 0; i < width; ++i) std::putchar(i < n ? '#' : ' ');
    std::putchar(']');
}

int list_devices() {
    ma_context ctx;
    if (ma_context_init(nullptr, 0, nullptr, &ctx) != MA_SUCCESS) {
        std::fprintf(stderr, "ma_context_init failed\n");
        return 1;
    }
    ma_device_info* play = nullptr; ma_uint32 nplay = 0;
    ma_device_info* cap = nullptr;  ma_uint32 ncap = 0;
    ma_context_get_devices(&ctx, &play, &nplay, &cap, &ncap);
    std::printf("capture devices:\n");
    for (ma_uint32 i = 0; i < ncap; ++i)
        std::printf("  [%u] %s%s\n", i, cap[i].name, cap[i].isDefault ? "  (default)" : "");
    std::printf("playback devices:\n");
    for (ma_uint32 i = 0; i < nplay; ++i)
        std::printf("  [%u] %s%s\n", i, play[i].name, play[i].isDefault ? "  (default)" : "");
    ma_context_uninit(&ctx);
    return 0;
}

void usage() {
    std::printf(
        "nsxlive -- microphone -> Zoom-derived suppressor -> speakers, live.\n\n"
        "  --devices           list capture/playback devices and exit\n"
        "  --cap N             capture device index (default: system default)\n"
        "  --play N            playback device index\n"
        "  --loopback          capture the system OUTPUT instead of a microphone. This is how to\n"
        "                      record another application's processed audio (e.g. Zoom's own\n"
        "                      denoised mic stream) for offline measurement.\n"
        "  --no-playback       process but stay silent -- the safe mode when not on headphones\n"
        "  --record FILE.wav   write FILE_raw.wav and FILE_proc.wav on exit, for offline A/B\n"
        "  --level N           0..5 aggressiveness (default 2)\n"
        "  --period N          device period in frames (default 256; lower = less latency)\n"
        "  --seconds N         run N seconds then exit (no keypress; makes it scriptable)\n\n"
        "keys while running:\n"
        "  SPACE   toggle BYPASS -- the whole point: same voice, same room, suppressor on vs off\n"
        "  0-5     set level\n"
        "  q       quit\n\n"
        "FEEDBACK: mic into speakers in one room WILL howl. Use headphones, or --no-playback.\n");
}

}  // namespace

// Offline run of the STREAMING path, for cross-checking it against process_all().
//
// This exists because the live tool reported a per-frame mean gain of 0.36 (-8.9 dB) while the
// recorded file showed only 0.72 dB of attenuation -- two numbers that cannot both be right. The
// live path uses process_hop() and every offline measurement in NOTES.md uses process_all(), so
// without a way to run process_hop() on a file there is no way to tell which one is wrong.
int run_file(const std::string& in_path, const std::string& out_path, const nsx::Cfg& cfg) {
    nsx::Wav w;
    std::string err;
    if (!nsx::wav_read(in_path, w, &err)) {
        std::fprintf(stderr, "read %s: %s\n", in_path.c_str(), err.c_str());
        return 1;
    }
    nsx::NoiseSuppressor ns(w.sample_rate, cfg.level);
    nsx::apply(ns, cfg);
    const int hop = ns.hop_size();

    std::vector<float> out;
    out.reserve(w.samples.size());
    std::vector<float> hin((size_t)hop), hout((size_t)hop);
    size_t i = 0;
    for (; i + (size_t)hop <= w.samples.size(); i += (size_t)hop) {
        std::memcpy(hin.data(), w.samples.data() + i, (size_t)hop * sizeof(float));
        const bool ready = ns.process_hop(hin.data(), hout.data());
        for (int k = 0; k < hop; ++k) out.push_back(ready ? hout[(size_t)k] : 0.f);
    }
    auto rms_db = [](const std::vector<float>& x) {
        double e = 0.0;
        for (float v : x) e += (double)v * v;
        return 10.0 * std::log10(std::max(e / std::max<size_t>(x.size(), 1), 1e-20));
    };
    std::printf("streaming path (process_hop): in %.2f dBFS -> out %.2f dBFS   attenuation %.2f dB\n",
                rms_db(w.samples), rms_db(out), rms_db(w.samples) - rms_db(out));
    if (!out_path.empty()) {
        nsx::Wav o; o.sample_rate = w.sample_rate; o.samples = out;
        nsx::wav_write(out_path, o);
        std::printf("wrote %s\n", out_path.c_str());
    }
    return 0;
}

int main(int argc, char** argv) {
    int cap_idx = -1, play_idx = -1, period = 256;
    double run_secs = 0.0;                // 0 = run until 'q'
    std::string in_file, out_file;         // offline streaming-path run
    bool loopback = false;
    std::string rec_path;
    nsx::Cfg cfg;

    for (int i = 1; i < argc; ++i) {
        const char* a = argv[i];
        auto next = [&](const char* d) { return (i + 1 < argc) ? argv[++i] : d; };
        if (!std::strcmp(a, "--devices")) return list_devices();
        else if (!std::strcmp(a, "--help") || !std::strcmp(a, "-h")) { usage(); return 0; }
        else if (!std::strcmp(a, "--cap"))         cap_idx = std::atoi(next("-1"));
        else if (!std::strcmp(a, "--play"))        play_idx = std::atoi(next("-1"));
        else if (!std::strcmp(a, "--loopback"))    loopback = true;
        else if (!std::strcmp(a, "--no-playback")) g.playback = false;
        else if (!std::strcmp(a, "--record"))      { rec_path = next(""); g.record = true; }
        else if (!std::strcmp(a, "--level"))       cfg.level = std::atoi(next("2"));
        else if (!std::strcmp(a, "--period"))      period = std::atoi(next("256"));
        // Auto-exit makes the tool scriptable, which is what the Zoom measurement needs:
        //   nsxlive --loopback --no-playback --record zoom.wav --seconds 30
        // captures 30 s of whatever Zoom is sending, with no keypress required.
        else if (!std::strcmp(a, "--seconds"))     run_secs = std::atof(next("0"));
        else if (!std::strcmp(a, "--in-file"))     in_file = next("");
        else if (!std::strcmp(a, "--out-file"))    out_file = next("");
        else { std::fprintf(stderr, "unknown option %s\n", a); usage(); return 2; }
    }

    if (!in_file.empty()) return run_file(in_file, out_file, cfg);

    nsx::NoiseSuppressor ns(kSampleRate, cfg.level);
    nsx::apply(ns, cfg);
    g.ns = &ns;
    g.hop = ns.hop_size();
    g.level.store(cfg.level);

    ma_context ctx;
    if (ma_context_init(nullptr, 0, nullptr, &ctx) != MA_SUCCESS) {
        std::fprintf(stderr, "ma_context_init failed\n");
        return 1;
    }
    ma_device_info* play = nullptr; ma_uint32 nplay = 0;
    ma_device_info* capd = nullptr; ma_uint32 ncap = 0;
    ma_context_get_devices(&ctx, &play, &nplay, &capd, &ncap);

    ma_device_config dc = ma_device_config_init(loopback ? ma_device_type_loopback
                                                         : ma_device_type_duplex);
    dc.sampleRate              = kSampleRate;
    dc.capture.format          = ma_format_f32;
    dc.capture.channels        = 1;
    dc.capture.shareMode       = ma_share_mode_shared;
    dc.playback.format         = ma_format_f32;
    dc.playback.channels       = 1;
    dc.periodSizeInFrames      = (ma_uint32)period;
    dc.dataCallback            = data_callback;
    if (cap_idx >= 0 && (ma_uint32)cap_idx < ncap)   dc.capture.pDeviceID  = &capd[cap_idx].id;
    if (play_idx >= 0 && (ma_uint32)play_idx < nplay) dc.playback.pDeviceID = &play[play_idx].id;

    ma_device dev;
    if (ma_device_init(&ctx, &dc, &dev) != MA_SUCCESS) {
        std::fprintf(stderr, "ma_device_init failed. Try --devices, or --loopback for output capture.\n");
        ma_context_uninit(&ctx);
        return 1;
    }
    if (ma_device_start(&dev) != MA_SUCCESS) {
        std::fprintf(stderr, "ma_device_start failed\n");
        ma_device_uninit(&dev);
        ma_context_uninit(&ctx);
        return 1;
    }

    std::printf("nsxlive  %d Hz  hop %d  period %d frames  algorithmic latency %.1f ms\n",
                kSampleRate, g.hop, period, 1000.0 * (double)(g.hop * 2) / kSampleRate);
    std::printf("capture: %s%s   playback: %s\n",
                dev.capture.name, loopback ? "  (LOOPBACK: system output)" : "",
                g.playback ? dev.playback.name : "(muted)");
    if (g.playback && !loopback)
        std::printf("\n  *** headphones, or this will feed back. --no-playback is the safe mode. ***\n");
    std::printf("\nSPACE = bypass on/off    0-5 = level    q = quit\n\n");

    bool running = true;
    double elapsed = 0.0;
    while (running) {
        if (run_secs > 0.0 && elapsed >= run_secs) break;
        elapsed += 0.080;
        while (_kbhit()) {
            const int c = _getch();
            if (c == ' ') g.bypass.store(!g.bypass.load());
            else if (c >= '0' && c <= '5') { g.level.store(c - '0'); g.level_dirty.store(true); }
            else if (c == 'q' || c == 'Q') running = false;
        }
        static const char* kSed[] = {"silence", "speech ", "music  ", "noise  ", "transnt"};
        const int ev = g.sed_event.load();
        const float pi = g.peak_in.load(), po = g.peak_out.load();
        std::printf("\r%s in ", g.bypass.load() ? "BYPASS" : "ACTIVE");
        bar(pi, 14);
        std::printf("%6.1f out ", 20.f * std::log10(std::max(pi, 1e-6f)));
        bar(po, 14);
        // The in/out dB pair IS the answer to "is it doing anything": their difference is the
        // attenuation being applied right now, and toggling BYPASS should visibly change it.
        std::printf("%6.1f dB  L%d P=%.2f g=%.2f snr=%+5.1f %s  ",
                    20.f * std::log10(std::max(po, 1e-6f)),
                    g.level.load(), g.p_speech.load(), g.gain.load(), g.snr_db.load(),
                    kSed[ev >= 0 && ev < 5 ? ev : 0]);
        std::fflush(stdout);
        ma_sleep(80);
    }

    ma_device_stop(&dev);
    ma_device_uninit(&dev);
    ma_context_uninit(&ctx);
    std::printf("\n");

    if (g.record && !rec_path.empty()) {
        std::string base = rec_path;
        const size_t dot = base.rfind('.');
        if (dot != std::string::npos) base = base.substr(0, dot);
        nsx::Wav a; a.sample_rate = kSampleRate; a.samples = g.rec_raw;
        nsx::Wav b; b.sample_rate = kSampleRate; b.samples = g.rec_proc;
        const std::string pa = base + "_raw.wav", pb = base + "_proc.wav";
        std::printf("wrote %s (%.1f s) and %s\n", pa.c_str(),
                    (double)g.rec_raw.size() / kSampleRate, pb.c_str());
        nsx::wav_write(pa, a);
        nsx::wav_write(pb, b);
    }
    return 0;
}
