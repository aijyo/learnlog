﻿#pragma once
// nsx_config.hpp -- the single source of truth for "what knobs exist".
//
// Both consumers include this file:
//   lab.cpp     -> nsxlab.exe  (CLI audit bench: --list / --ablate / --sweep)
//   nsx_capi.cpp -> nsxcore.dll (C ABI consumed by the WPF UI over P/Invoke)
//
// Adding a mechanism means adding ONE row to kMechs below; the CLI table, the ablation
// runner and the UI control list all regenerate from it. Nothing is duplicated in C#.

#include "ns_core.hpp"

namespace nsx {

struct Cfg {
    int   level        = 2;
    float alpha_dd     = 0.98f;    // Zoom 0.98  decision-directed a-priori SNR
    float alpha_lrt    = 0.5f;     // Zoom 0.5   per-bin LRT smoothing
    float alpha_p      = 0.1f;     // Zoom's value (E3380, verified). We measured 0.05 better on
                                   // real data, but fidelity to Zoom is the goal here.
    float floor_db     = -6.f;     // level-2 default after real-data re-derivation
    float oversub      = 1.25f;
    // set_level() picks BOTH floor_db and oversub from its ladder. Applying the two fields
    // above unconditionally afterwards silently undid that, which made `level` a completely
    // dead knob (measured: levels 0..5 produced byte-identical output). They are now applied
    // only when the caller explicitly set them.
    bool  floor_override   = false;
    bool  oversub_override = false;
    bool  powerlaw     = true;     // Zoom: yes  power-law (A/k^alpha) noise-floor cold start
    bool  makeup       = false;    // OFF: it exists to undo the limiter's pedestal, and the
                                   // limiter is off. Measured to change nothing on its own.
                                   // Zoom: yes (E56E0). Was thought REQUIRED because DB830's
                                   // limiter puts a 5 dB pedestal on every bin and makeup is what
                                   // undoes it. Our earlier 'makeup is harmful' measurement was
                                   // taken without that pedestal present.
    float makeup_alpha = 1.f;
    bool  abs_floor    = false;    // Zoom: yes (DB830); measured no benefit standalone (5.10).
    float abs_floor_db = -65.f;
    int   freq_smooth  = 1;        // ours; refuted
    float time_smooth  = 1.f;      // ours; refuted
    bool  sed          = true;     // SED -> music protection + transient noise-freeze
    float xiflat_w     = 0.f;      // Zoom has this feature; weight 0 after measurement
    // false = Wiener xi/(oversub+xi) -- the DEFAULT and what the binary implies. true = use the
    // per-bin SPP as the gain, which is what we shipped first and is confirmed wrong (E3380 stores
    // that array for the noise tracker, it never multiplies the spectrum).
    bool  spp_as_gain  = false;
    // Threshold source: 0 = SelfAdaptive (ours, refuted), 1 = Absolute, 2 = Histogram [Zoom viper],
    // 3 = Hmm (two-state Gaussian HMM per feature) [Zoom viperex, NOTES.md 19.15].
    int   thresh_mode  = 2;
    // Which three features are fused. 0 = lrt/flat/diff (shipped; measured d-prime 0.40/0.42/0.59),
    // 1 = snr_db / xi_flatness(dB) / harmonicity (1.31/1.55/1.24). Orthogonal to thresh_mode.
    int   feature_set  = 0;
    // P-driven adaptive floor: extra depth in dB, faded in as P falls below the knee. 0 = off.
    float afloor_db    = 0.f;
    float afloor_knee  = 0.35f;
    // ThreshMode::Hmm dynamics. Defaults are Zoom's recovered values; the state means live in
    // ns_core::configure_hmm and are OUR measured medians, not Zoom's feature-unit ones.
    float hmm_stay     = 0.99f;    // self-transition, both of Zoom's classifiers
    float hmm_sd_scale = 0.5f;     // sd = 0.5x inter-state gap (Zoom: 12/20 and 10/19)
    float hmm_adapt    = 0.002f;   // Zoom's per-kind rates are 0.001 / 0.002 / 0.005
    float thr_lrt      = 0.05f;   // read off the measured distributions, not WebRTC's 0.5
    float thr_flat     = 0.32f;
    float thr_diff     = 0.47f;
    float sc_lrt       = 0.10f;   // per-feature spread, so tanh width 4/8 lands on our scale
    float sc_flat      = 0.06f;
    float sc_diff      = 0.25f;
    float thr_harm     = 0.30f;   // 0.45 matches the distributions but measured worse; see ns_core
    float sc_harm      = 0.30f;
    int   hist_window  = 250;
    // OFF, and the reason recorded here was WRONG -- corrected in NOTES.md 19.20. It said "cannot be
    // enabled until the detector works". Re-tested with the high-d-prime feature set (d-prime 1.55 vs
    // 0.40): identical numbers for both feature sets, gap attenuation 18.95 dB vs speech 18.98 dB,
    // modulation -0.03 dB. P has ZERO influence on it, because the formula
    // min(-5, max(floorDb, (-65-lvl) - binDb)) is a function of the bin's LEVEL alone. It is a
    // level-targeting AGC, not a suppressor, so it can never be selective no matter how good the
    // detector gets. (STOI even rises to 0.9287 -- the exact artefact NOTES.md 5.6 warns about: the
    // output is just quieter.) For the P-driven equivalent that DOES work, see afloor_db.
    bool  zoom_gain    = false;   // DB830's dB-domain gain limiter: -65 dBFS target + max-atten
                                  // bound + the 5 dB pedestal. THE piece that was missing.
    float zoom_target  = -65.f;   // the literal -65.0 in DB830
    float lvl_off_db   = 0.f;     // `v7`, the level-dependent dB offset
    float zoom_limit   = 0.f;     // `v13` base: configured max attenuation. ~0 => L collapses to -5
    // OFF for the same reason: 4 bands over 129 bins is 32 bins per band, so a band's mean gain is
    // dominated by its noise bins and speech inherits it. It only looked good next to the even
    // worse unclamped per-bin case.
    int   gain_bands   = 0;       // E16C0: gain on N bands, interpolated to bins. 0 = per-bin.
                                  // 4 is indicated by E45C0's 66/133/200 edges; see ns_core.hpp.
    float presence_lo  = 1.0f;    // 1.0 = no P-driven gain multiplier, which is Zoom's shape
                                  // (Zoom's shape: P never multiplies the gain, it drives the
                                  // noise tracker). Lower = P modulates the gain harder.
    bool  sed_clamp    = false;   // OURS: SED clamping P to >=0.40 on "speech" / <=0.45 on "noise".
                                  // Fired on 55.9% of pure-noise frames; removing it improved both
                                  // ESTOI and SI-SDR. Music protection is separate and stays on.
    bool  dc360_flat   = false;   // DC360's single-range flatness. Off: the transcription lands
                                  // below Zoom's own 0.6 gate, so the feature would be permanently
                                  // disabled -- see the note in ns_core.hpp.
    bool  zoom_noise   = true;    // E3950's 1.15x rise cap + 0.9/0.99 beta switch + slow tracker
    bool  adaptive_dd  = false;   // DB830's alpha_dd = 0.9*(xi/(1+xi))^2+0.1. Zoom's. Measured
                                  // worse here -- see the note in ns_core.hpp. Off by default.

    bool  attack_limit = true;    // E16C0: gain may rise at most 3x per frame
};

void apply(nsx::NoiseSuppressor& ns, const Cfg& c) {
    ns.set_level(c.level);                                    // sets the floor+oversub ladder
    if (c.floor_override)   ns.set_floor_db(c.floor_db);      // ...only overridden on request
    if (c.oversub_override) ns.set_oversub(c.oversub);
    ns.set_alpha_dd(c.alpha_dd);
    ns.set_alpha_lrt(c.alpha_lrt);
    ns.set_alpha_p(c.alpha_p);
    ns.set_powerlaw_init(c.powerlaw);
    ns.set_makeup_enabled(c.makeup);
    ns.set_makeup_smoothing(c.makeup_alpha);
    ns.set_abs_floor(c.abs_floor, c.abs_floor_db);
    ns.set_freq_smoothing(c.freq_smooth);
    ns.set_time_smoothing(c.time_smooth);
    ns.set_sed_steering(c.sed);
    ns.set_xiflat_weight(c.xiflat_w);
    ns.set_gain_law(c.spp_as_gain ? nsx::NoiseSuppressor::GainLaw::Posterior
                                  : nsx::NoiseSuppressor::GainLaw::Wiener);
    // Dynamics first: set_thresh_mode(Hmm) installs the HMMs, so the knobs must already be in place.
    ns.set_hmm_dynamics(c.hmm_stay, c.hmm_sd_scale, c.hmm_adapt);
    ns.set_feature_set(c.feature_set);
    ns.set_adaptive_floor(c.afloor_db, c.afloor_knee);
    ns.set_thresh_mode(c.thresh_mode == 0 ? nsx::ThreshMode::SelfAdaptive
                     : c.thresh_mode == 1 ? nsx::ThreshMode::Absolute
                     : c.thresh_mode == 3 ? nsx::ThreshMode::Hmm
                                          : nsx::ThreshMode::Histogram);
    ns.set_thr_lrt(c.thr_lrt);
    ns.set_thr_flat(c.thr_flat);
    ns.set_thr_diff(c.thr_diff);
    ns.set_hist_window(c.hist_window);
    ns.set_feature_scales(c.sc_lrt, c.sc_flat, c.sc_diff);
    ns.set_harmonicity(c.thr_harm, c.sc_harm);
    ns.set_zoom_noise_update(c.zoom_noise);
    ns.set_adaptive_alpha_dd(c.adaptive_dd);
    ns.set_attack_limit(c.attack_limit);
    ns.set_zoom_gain_limit(c.zoom_gain);
    ns.set_dc360_flatness(c.dc360_flat);
    ns.set_sed_prob_clamp(c.sed_clamp);
    ns.set_presence_lo(c.presence_lo);
    ns.set_zoom_target_db(c.zoom_target);
    ns.set_level_offset_db(c.lvl_off_db);
    ns.set_gain_bands(c.gain_bands);
    ns.set_zoom_limit_db(c.zoom_limit);
}

// ---------------------------------------------------------------- mechanism registry
// Drives --list, --ablate and --sweep from one place, so a new mechanism only has to be added here.
struct Mech {
    const char* flag;        // command-line name
    const char* origin;      // where it came from in the binary
    const char* note;        // what it does / what we measured
    // ablation: how to turn this mechanism OFF (or to its opposite) relative to the baseline
    void (*ablate)(Cfg&);
    const char* ablate_label;
};

const Mech kMechs[] = {
  {"gain-law", "E3380 (closed-form gain)",
   "G[k]=1/(1+e^-L*(1-P)/P) -- the gain IS the per-bin posterior speech probability. THE headline finding.",
   [](Cfg& c){ c.spp_as_gain = true; }, "SPP-as-gain (our original, binary-refuted)"},

  {"thresh-mode", "E3380 (1000-bin histogram)",
   "where each feature's decision threshold comes from. Ours used the feature's own running mean, which pins every vote at 0.5.",
   [](Cfg& c){ c.thresh_mode = 0; }, "SelfAdaptive (ours, refuted)"},

  {"adaptive-floor", "ours (measured, from the level sweep)",
   "P-driven floor: keeps the level's floor on speech frames and allows up to afloor_db of extra depth as P falls below the knee. The level sweep showed the FLOOR is the binding constraint (level 0-5 moves gap attenuation 3.40->19.49 dB, the detector moves it <=0.2 dB), so this is where a better detector finally pays off.",
   [](Cfg& c){ c.afloor_db = 24.f; c.feature_set = 1; c.thresh_mode = 1; }, "P-driven floor 24 dB + high-d-prime features"},
  {"feature-set", "ours (measured d-prime)",
   "which three features the fusion uses. Shipped triple lrt/flat/diff separates speech from gaps at d-prime 0.40/0.42/0.59 -- the three WORST of the eight we compute. Set 1 swaps in snr_db / xi_flatness(dB) / harmonicity at 1.31/1.55/1.24.",
   [](Cfg& c){ c.feature_set = 1; c.thresh_mode = 1; }, "high-d-prime features, absolute thresholds"},

  {"hmm-detector", "viperex DC1F0 (2-state Gaussian HMM)",
   "per-feature 2-state HMM (noise/speech) with 0.99 self-transition, sd=0.5x gap and adaptive means, replacing the memoryless tanh-vs-threshold map. Zoom's level ladder acts on THIS decision point, not on the gain floor.",
   [](Cfg& c){ c.thresh_mode = 2; }, "Histogram tanh map (viper's, our previous baseline)"},

  {"gain-bands", "E16C0 (band interp, verified)",
   "gain computed on 4 bands then linearly interpolated to bins. Per-bin gain with no floor zeroes isolated speech bins: ESTOI 0.42 -> 0.20.",
   [](Cfg& c){ c.gain_bands = 0; }, "per-bin gain (ours; ESTOI 0.4241 -> 0.2024)"},

  {"presence-lo", "ours (refuted)",
   "frame-level P multiplying every bin's gain. Removing it (1.0) raised the gap-vs-speech modulation 0.44->1.19 dB and improved ESTOI and SI-SDR.",
   [](Cfg& c){ c.presence_lo = 0.35f; }, "presence multiplier back at 0.35 (ours)"},

  {"sed-clamp", "ours (refuted)",
   "SED clamps P to >=0.40 on 'speech' frames and <=0.45 on 'noise' frames. Fired on 55.9% of PURE-NOISE frames where all three votes were <0.05.",
   [](Cfg& c){ c.sed_clamp = true; }, "SED probability clamps ENABLED"},

  {"dc360-flat", "DC360 (flatness, verified)",
   "single contiguous bin range on magnitude, low 8 bins excluded, top 5% of energy trimmed -- instead of a 4-band mean.",
   [](Cfg& c){ c.dc360_flat = true; }, "DC360 single-range (falls below Zoom's own 0.6 gate)"},

  {"zoom-gain", "DB830 (gain limiter, verified)",
   "dB-domain limiter: min(-5, max(floorDb, (-65 - lvl) - binDb)) multiplying the Wiener gain. Targets -65 dBFS and pedestals every bin 5 dB.",
   [](Cfg& c){ c.zoom_gain = false; }, "no limiter (plain Wiener + floor clamp)"},

  {"adaptive-dd", "DB830 (gain, verified)",
   "alpha_dd derived from the previous Wiener gain instead of fixed. Zoom does this; we measured it worse (Babble 5.63->5.15 dB).",
   [](Cfg& c){ c.adaptive_dd = false; }, "fixed alpha_dd 0.98 (ours; measured better)"},

  {"attack-limit", "E16C0 (gain, verified)",
   "the gain may rise at most 3x per frame; release is unrestricted. Stops onset clicks.",
   [](Cfg& c){ c.attack_limit = false; }, "no attack rate limit"},

  {"zoom-noise", "E3950 (noise update)",
   "1.15x cap on how fast the noise estimate may rise, beta switching 0.9<->0.99 on SPP>0.2, plus a slow alpha=0.05 tracker.",
   [](Cfg& c){ c.zoom_noise = false; }, "plain MCRA update"},

  {"alpha-dd", "E3950",
   "decision-directed a-priori SNR: xi = a*(S_prev/lambda) + (1-a)*max(gamma-1,0). Zoom a=0.98.",
   [](Cfg& c){ c.alpha_dd = 0.f; }, "alpha-dd=0 (no recursion)"},

  {"alpha-lrt", "E3380",
   "per-bin LRT recursive smoothing. Zoom 0.5.",
   [](Cfg& c){ c.alpha_lrt = 1.f; }, "alpha-lrt=1 (no smoothing)"},

  {"alpha-p", "E3380",
   "frame speech-probability smoothing. Zoom 0.1 @100fps; we use 0.05 @62fps after real-data sweep.",
   [](Cfg& c){ c.alpha_p = 0.3f; }, "alpha-p=0.3 (the synthetic-tuned value that was WRONG)"},

  {"powerlaw", "E3950",
   "noise-floor cold start by fitting A/k^alpha (log-log least squares, bins>=5, first 50 frames).",
   [](Cfg& c){ c.powerlaw = false; }, "flat running-mean init instead"},

  {"sed", "SED submodule id 3 (multi SED)",
   "sound-event classification steers the suppressor: music protection + freeze noise update on transients.",
   [](Cfg& c){ c.sed = false; }, "SED steering bypassed"},

  {"makeup", "E56E0",
   "post-gain level normalisation: r=sqrt(Eout/Ein); r>0.5 boost 1+(r-.5)*1.3 capped 1/r; else atten; blend by P.",
   [](Cfg& c){ c.makeup = true; }, "makeup ENABLED (Zoom does this; we measured worse)"},

  {"abs-floor", "DB830",
   "absolute dBFS suppression floor, so allowed attenuation becomes level-dependent. Zoom -65 dBFS.",
   [](Cfg& c){ c.abs_floor = true; }, "abs-floor ENABLED at -65 dBFS"},

  {"floor-db", "SetNsStatus level table",
   "spectral gain floor in dB. Deep floors crush the weak fricatives that carry intelligibility.",
   [](Cfg& c){ c.floor_db = -12.f; c.floor_override = true; }, "floor -12 dB (the old, too-deep value)"},

  {"xiflat", "DBD10",
   "flatness of the (1+xi)^2 spectrum -- flatness on the a-priori SNR, not on the power spectrum.",
   [](Cfg& c){ c.xiflat_w = 0.17f; }, "xiflat weight 0.17 (enabled)"},

  {"freq-smooth", "ours (refuted)",
   "triangular smoothing of the GAIN across frequency.",
   [](Cfg& c){ c.freq_smooth = 5; }, "5-tap frequency smoothing"},

  {"time-smooth", "ours (refuted)",
   "per-bin recursive smoothing of the GAIN across time.",
   [](Cfg& c){ c.time_smooth = 0.4f; }, "time smoothing alpha=0.4"},
};
constexpr int kNumMechs = (int)(sizeof(kMechs) / sizeof(kMechs[0]));

}  // namespace nsx
