﻿// lab.cpp — nsxlab: per-mechanism audit bench for the noise suppressor.
//
// WHY THIS EXISTS
// Every mechanism in ns_core.hpp came from reverse-engineering Zoom's viper.dll (see
// ../../../zoom-bin-analysis/AUDIO_DEEP_DIVE.html). Objective metrics alone have already been shown
// to disagree with each other (NOTES.md 5.13: ESTOI says the suppressor helps, STOI says it hurts),
// so the remaining way to judge these algorithms is to LISTEN to each one's contribution in
// isolation. This tool exists to make that cheap:
//
//   1. every recovered parameter is a command-line flag, so one mechanism can be moved at a time
//   2. --ablate renders one WAV per mechanism (on vs off) so each contribution is audible A/B
//   3. --sweep renders one WAV per parameter value
//   4. --telemetry dumps per-frame features to CSV, so what you HEAR can be tied to what the
//      detector actually computed on that frame
//   5. every render also prints objective metrics when a clean reference is supplied
//
// BUILD: part of the nsx CMake project -> nsxlab.exe (single static exe, no external deps)
//
// USAGE
//   nsxlab --in noisy.wav --out out\base.wav [mechanism flags]
//   nsxlab --in noisy.wav --out-dir out\ --ablate            [--clean clean.wav]
//   nsxlab --in noisy.wav --out-dir out\ --sweep alpha-p=0.01,0.05,0.3
//   nsxlab --in noisy.wav --out out\x.wav --telemetry out\x.csv
//   nsxlab --in clean.wav --mix-noise Babble_1.wav --mix-snr 5 --ablate --out-dir out\
//                                                            (mix + audit in one shot)
//   nsxlab --list                                            (print every mechanism + default)

#include "ns_core.hpp"
#include "nsx_config.hpp"   // Cfg / apply() / kMechs -- shared with nsxcore.dll (the WPF UI)
#include "wav.hpp"
#include "metrics.hpp"
#include "eval.hpp"        // mix_at_snr -- shared, not copied (see the note near its using-decl)
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>

namespace {

// ---------------------------------------------------------------- config
// One struct holding every mechanism recovered from the binary. Defaults match what the project
// ships (i.e. what real-data evaluation selected), NOT what Zoom ships -- the two differ where we
// measured Zoom's choice to be worse for our pipeline, and each difference is noted in --list.
using nsx::Cfg;
using nsx::apply;
using nsx::Mech;
using nsx::kMechs;
using nsx::kNumMechs;

// ---------------------------------------------------------------- render + telemetry
struct Result {
    std::vector<float> out;
    double stoi = -1, estoi = -1, sisdr = 0, segsnr = 0, lsd = 0;
    double out_db = 0, in_db = 0;
};

double rms_db(const std::vector<float>& x) {
    double e = 0.0;
    for (float v : x) e += (double)v * v;
    return 10.0 * std::log10(std::max(e / std::max<size_t>(x.size(), 1), 1e-20));
}

// Renders the whole file, optionally writing a per-frame telemetry CSV. Uses process_hop so the
// telemetry is captured on exactly the frames the suppressor actually decided on.
Result render(const std::vector<float>& in, int sr, const Cfg& cfg, const std::string& csv) {
    nsx::NoiseSuppressor ns(sr, cfg.level);
    apply(ns, cfg);

    // process_all (not process_hop): it is offset-aligned, so metrics against the clean reference
    // are meaningful. Telemetry comes out of the same pass, so what you HEAR and what the CSV says
    // are the same frames.
    std::vector<nsx::Telemetry> tel;
    Result r;
    r.out = ns.process_all(in, csv.empty() ? nullptr : &tel);

    if (!csv.empty()) {
        FILE* f = std::fopen(csv.c_str(), "wb");
        if (f) {
            std::fprintf(f,
                "frame,t_sec,P_speech,p_snr,p_flat,p_diff,spec_diff,xi_flatness,harmonicity,"
                "lrt_avg,flat_avg,thr_lrt,thr_flat,thr_diff,w_lrt,w_flat,w_diff,"
                "snr_db,gain,makeup,voice,noise_changed,noise_count,"
                "sed_event,sed_pitch_hz,sed_stability,sed_modulation,sed_flux,music_protect,"
                "flat0,flat1,flat2,flat3,nl0,nl1,nl2,nl3\n");
            const int hop = ns.hop_size();
            for (size_t i = 0; i < tel.size(); ++i) {
                const nsx::Telemetry& t = tel[i];
                std::fprintf(f,
                    "%zu,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,"
                    "%.4f,%.4f,%.4f,%.4f,%.4f,%.3f,%.3f,%.3f,"
                    "%.2f,%.4f,%.4f,%d,%d,%ld,"
                    "%s,%.1f,%.3f,%.3f,%.4f,%d,"
                    "%.4f,%.4f,%.4f,%.4f,%.2f,%.2f,%.2f,%.2f\n",
                    i, (double)(i * hop) / sr,
                    t.speech_prob, t.snr_prob, t.flat_prob, t.diff_prob, t.spec_diff,
                    t.xi_flatness, t.harmonicity,
                    t.lrt_avg, t.flat_avg, t.thr_lrt, t.thr_flat, t.thr_diff,
                    t.w_lrt, t.w_flat, t.w_diff,
                    t.snr_db, t.gain, t.makeup,
                    t.voice ? 1 : 0, t.noise_changed, t.noise_count,
                    nsx::event_name(t.sed.event), t.sed.pitch_hz, t.sed.pitch_stability,
                    t.sed.modulation, t.sed.flux, t.sed.music_protection ? 1 : 0,
                    t.flatness[0], t.flatness[1], t.flatness[2], t.flatness[3],
                    t.noise_level[0], t.noise_level[1], t.noise_level[2], t.noise_level[3]);
            }
            std::fclose(f);
        }
    }
    r.in_db = rms_db(in);
    r.out_db = rms_db(r.out);
    return r;
}

void score(Result& r, const std::vector<float>& clean, int sr) {
    if (clean.empty()) return;
    r.stoi   = nsx::metrics::stoi (clean, r.out, sr);
    r.estoi  = nsx::metrics::estoi(clean, r.out, sr);
    r.sisdr  = nsx::metrics::si_sdr(clean, r.out);
    r.segsnr = nsx::metrics::seg_snr(clean, r.out, sr);
    r.lsd    = nsx::metrics::lsd(clean, r.out, sr);
}

// Mixing lives in eval.hpp so nsx, nsxlab and nsxcore.dll (the WPF UI) all synthesise the SAME
// mixture. There used to be a byte-identical copy here; that duplicate is exactly what let the DLL
// wrapper drift (it pre-cropped the noise, changing the measured noise RMS and thus the gain).
using nsx::eval::mix_at_snr;

bool save(const std::string& path, const std::vector<float>& x, int sr) {
    nsx::Wav w; w.sample_rate = sr; w.samples = x;
    return nsx::wav_write(path, w);
}

std::string join(const std::string& dir, const std::string& name) {
    if (dir.empty()) return name;
    char last = dir[dir.size() - 1];
    return (last == '\\' || last == '/') ? dir + name : dir + "\\" + name;
}

// ---------------------------------------------------------------- CLI
void print_list() {
    std::printf("nsxlab -- per-mechanism audit bench\n\n");
    std::printf("Every mechanism below was recovered from Zoom viper.dll. Defaults are what THIS\n"
                "project ships (chosen by real-data evaluation), which differs from Zoom where we\n"
                "measured Zoom's choice to be worse for our pipeline -- those rows say so.\n\n");
    std::printf("%-14s %-28s %s\n", "FLAG", "ORIGIN", "WHAT IT DOES");
    std::printf("%s\n", std::string(112, '-').c_str());
    for (const Mech& m : kMechs)
        std::printf("--%-12s %-28s %s\n", m.flag, m.origin, m.note);
    std::printf("\nDefaults: level=2 alpha-dd=0.98 alpha-lrt=0.5 alpha-p=0.05 floor-db=-6\n"
                "          oversub=1.25 powerlaw=on sed=on makeup=off abs-floor=off\n"
                "          freq-smooth=1 time-smooth=1 xiflat=0 gain-law=posterior\n\n");
    std::printf("Modes:\n"
                "  --ablate                 one WAV per mechanism (baseline vs that mechanism moved)\n"
                "  --sweep name=v1,v2,...   one WAV per value of a single parameter\n"
                "  --telemetry file.csv     per-frame features for the single render\n"
                "  --clean ref.wav          also report STOI/ESTOI/SI-SDR/segSNR/LSD\n");
}

void print_score_header() {
    std::printf("\n%-34s %8s %8s %8s %8s %8s %9s\n",
                "render", "STOI", "ESTOI", "SI-SDR", "segSNR", "LSD", "out dB");
    std::printf("%s\n", std::string(96, '-').c_str());
}
void print_score(const char* name, const Result& r, bool have_clean) {
    if (have_clean)
        std::printf("%-34s %8.4f %8.4f %8.2f %8.2f %8.2f %9.2f\n",
                    name, r.stoi, r.estoi, r.sisdr, r.segsnr, r.lsd, r.out_db);
    else
        std::printf("%-34s %8s %8s %8s %8s %8s %9.2f\n",
                    name, "-", "-", "-", "-", "-", r.out_db);
}

bool set_param(Cfg& c, const std::string& k, float v) {
    if (k == "level")        { c.level = (int)v;            return true; }
    if (k == "alpha-dd")     { c.alpha_dd = v;              return true; }
    if (k == "alpha-lrt")    { c.alpha_lrt = v;             return true; }
    if (k == "alpha-p")      { c.alpha_p = v;               return true; }
    if (k == "floor-db")     { c.floor_db = v; c.floor_override = true;     return true; }
    if (k == "oversub")      { c.oversub = v; c.oversub_override = true;   return true; }
    if (k == "abs-floor-db") { c.abs_floor_db = v;          return true; }
    if (k == "freq-smooth")  { c.freq_smooth = (int)v;      return true; }
    if (k == "time-smooth")  { c.time_smooth = v;           return true; }
    if (k == "xiflat")       { c.xiflat_w = v;              return true; }
    if (k == "makeup-alpha") { c.makeup_alpha = v;          return true; }
    if (k == "thresh-mode")  { c.thresh_mode = (int)v;      return true; }
    if (k == "feature-set")  { c.feature_set = (int)v;      return true; }
    if (k == "afloor-db")    { c.afloor_db = v;              return true; }
    if (k == "afloor-knee")  { c.afloor_knee = v;            return true; }
    if (k == "hmm-stay")     { c.hmm_stay = v;              return true; }
    if (k == "hmm-sd")       { c.hmm_sd_scale = v;          return true; }
    if (k == "hmm-adapt")    { c.hmm_adapt = v;             return true; }
    if (k == "thr-lrt")      { c.thr_lrt = v;               return true; }
    if (k == "thr-flat")     { c.thr_flat = v;              return true; }
    if (k == "thr-diff")     { c.thr_diff = v;              return true; }
    if (k == "hist-window")  { c.hist_window = (int)v;      return true; }
    if (k == "zoom-target")  { c.zoom_target = v;           return true; }
    if (k == "lvl-off")      { c.lvl_off_db = v;            return true; }
    if (k == "gain-bands")   { c.gain_bands = (int)v;        return true; }
    if (k == "presence-lo")  { c.presence_lo = v;           return true; }
    if (k == "zoom-limit")   { c.zoom_limit = v;            return true; }
    return false;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 2 || !std::strcmp(argv[1], "--list") || !std::strcmp(argv[1], "-h")) {
        print_list();
        return argc < 2 ? 2 : 0;
    }

    std::string in_path, clean_path, out_path, out_dir, csv_path, sweep, mix_noise;
    float mix_snr = 5.f;
    bool ablate = false;
    Cfg cfg;

    for (int i = 1; i < argc; ++i) {
        const char* a = argv[i];
        auto next = [&](const char* def) -> std::string {
            return (i + 1 < argc) ? argv[++i] : std::string(def);
        };
        if      (!std::strcmp(a, "--in"))        in_path    = next("");
        else if (!std::strcmp(a, "--clean"))     clean_path = next("");
        else if (!std::strcmp(a, "--out"))       out_path   = next("");
        else if (!std::strcmp(a, "--out-dir"))   out_dir    = next("");
        else if (!std::strcmp(a, "--telemetry")) csv_path   = next("");
        else if (!std::strcmp(a, "--sweep"))     sweep      = next("");
        else if (!std::strcmp(a, "--mix-noise")) mix_noise  = next("");
        else if (!std::strcmp(a, "--mix-snr"))   mix_snr    = (float)std::atof(next("5").c_str());
        else if (!std::strcmp(a, "--ablate"))    ablate     = true;
        else if (!std::strcmp(a, "--spp-gain")) cfg.spp_as_gain = true;
        else if (!std::strcmp(a, "--thresh-ema")) cfg.thresh_mode = 0;
        else if (!std::strcmp(a, "--thresh-abs")) cfg.thresh_mode = 1;
        else if (!std::strcmp(a, "--thresh-hist")) cfg.thresh_mode = 2;
        else if (!std::strcmp(a, "--no-zoom-noise")) cfg.zoom_noise = false;
        else if (!std::strcmp(a, "--no-adaptive-dd")) cfg.adaptive_dd = false;
        else if (!std::strcmp(a, "--no-zoom-gain")) cfg.zoom_gain = false;
        else if (!std::strcmp(a, "--zoom-gain")) cfg.zoom_gain = true;
        else if (!std::strcmp(a, "--gain-bands-on")) cfg.gain_bands = 4;
        else if (!std::strcmp(a, "--dc360-flat")) cfg.dc360_flat = true;
        else if (!std::strcmp(a, "--no-makeup")) cfg.makeup = false;
        else if (!std::strcmp(a, "--no-attack-limit")) cfg.attack_limit = false;
        else if (!std::strcmp(a, "--powerlaw"))  cfg.powerlaw = (next("on") == "on");
        else if (!std::strcmp(a, "--sed"))       cfg.sed      = (next("on") == "on");
        else if (!std::strcmp(a, "--makeup"))    cfg.makeup   = (next("on") == "on");
        else if (!std::strcmp(a, "--abs-floor")) cfg.abs_floor= (next("on") == "on");
        else if (a[0] == '-' && a[1] == '-') {
            const std::string key(a + 2);
            const std::string val = next("");
            if (!set_param(cfg, key, (float)std::atof(val.c_str()))) {
                std::fprintf(stderr, "unknown option --%s (try --list)\n", key.c_str());
                return 2;
            }
        }
    }

    if (in_path.empty()) { std::fprintf(stderr, "need --in <wav> (try --list)\n"); return 2; }

    nsx::Wav in; std::string err;
    if (!nsx::wav_read(in_path, in, &err)) { std::fprintf(stderr, "read: %s\n", err.c_str()); return 1; }
    std::vector<float> clean;
    if (!clean_path.empty()) {
        nsx::Wav c;
        if (!nsx::wav_read(clean_path, c, &err)) { std::fprintf(stderr, "clean: %s\n", err.c_str()); return 1; }
        if (c.sample_rate != in.sample_rate)
            c.samples = nsx::metrics::resample(c.samples, c.sample_rate, in.sample_rate);
        clean = c.samples;
    }
    // --mix-noise turns --in into the CLEAN source and synthesises the noisy input from it, so a
    // full real-data audit (with a reference for metrics) needs only two files.
    if (!mix_noise.empty()) {
        nsx::Wav nw;
        if (!nsx::wav_read(mix_noise, nw, &err)) { std::fprintf(stderr, "noise: %s\n", err.c_str()); return 1; }
        if (nw.sample_rate != in.sample_rate)
            nw.samples = nsx::metrics::resample(nw.samples, nw.sample_rate, in.sample_rate);
        if (clean.empty()) clean = in.samples;          // --in IS the clean reference here
        in.samples = mix_at_snr(clean, nw.samples, mix_snr, in.sample_rate);
        std::printf("mixed %s at %.1f dB SNR -> input is now the noisy mixture\n",
                    nsx::base_name(mix_noise).c_str(), mix_snr);
    }
    const bool hc = !clean.empty();
    const int sr = in.sample_rate;
    std::printf("input: %s  %.2f s @ %d Hz  (%.2f dBFS)\n",
                nsx::base_name(in_path).c_str(), (double)in.samples.size() / sr, sr, rms_db(in.samples));
    if (hc) std::printf("clean reference: %s\n",
                        clean_path.empty() ? "(--in itself, captured before mixing)"
                                           : nsx::base_name(clean_path).c_str());

    // ---------------- ablation: one render per mechanism ----------------
    if (ablate) {
        if (out_dir.empty()) { std::fprintf(stderr, "--ablate needs --out-dir\n"); return 2; }
        std::printf("\n=== ablation: baseline vs each mechanism moved (one WAV each) ===\n");
        print_score_header();

        Result base = render(in.samples, sr, cfg, "");
        score(base, clean, sr);
        save(join(out_dir, "00_baseline.wav"), base.out, sr);
        print_score("00_baseline", base, hc);
        // also write the untouched input for A/B reference
        save(join(out_dir, "00_input_noisy.wav"), in.samples, sr);
        if (hc) save(join(out_dir, "00_reference_clean.wav"), clean, sr);

        for (int i = 0; i < kNumMechs; ++i) {
            Cfg v = cfg;
            kMechs[i].ablate(v);
            Result r = render(in.samples, sr, v, "");
            score(r, clean, sr);
            char nm[128];
            std::snprintf(nm, sizeof(nm), "%02d_%s.wav", i + 1, kMechs[i].flag);
            save(join(out_dir, nm), r.out, sr);
            char label[160];
            std::snprintf(label, sizeof(label), "%02d_%s", i + 1, kMechs[i].flag);
            print_score(label, r, hc);
        }
        std::printf("\nWrote %d WAVs to %s\n", kNumMechs + 2, out_dir.c_str());
        std::printf("Listen 00_baseline vs each NN_<mechanism> to hear that mechanism's contribution.\n");
        std::printf("What each ablation changed:\n");
        for (int i = 0; i < kNumMechs; ++i)
            std::printf("  %02d_%-13s %s\n", i + 1, kMechs[i].flag, kMechs[i].ablate_label);
        return 0;
    }

    // ---------------- sweep: one render per value ----------------
    if (!sweep.empty()) {
        if (out_dir.empty()) { std::fprintf(stderr, "--sweep needs --out-dir\n"); return 2; }
        const size_t eq = sweep.find('=');
        if (eq == std::string::npos) { std::fprintf(stderr, "--sweep name=v1,v2,...\n"); return 2; }
        const std::string key = sweep.substr(0, eq);
        std::vector<std::string> vals;
        { size_t p = eq + 1;
          while (p <= sweep.size()) { size_t q = sweep.find(',', p);
              if (q == std::string::npos) q = sweep.size();
              if (q > p) vals.push_back(sweep.substr(p, q - p));
              p = q + 1; } }
        std::printf("\n=== sweep %s over %zu value(s) ===\n", key.c_str(), vals.size());
        print_score_header();
        for (const std::string& vs : vals) {
            Cfg v = cfg;
            if (!set_param(v, key, (float)std::atof(vs.c_str()))) {
                std::fprintf(stderr, "--sweep: %s is not a numeric parameter\n", key.c_str());
                return 2;
            }
            Result r = render(in.samples, sr, v, "");
            score(r, clean, sr);
            char nm[128];
            std::snprintf(nm, sizeof(nm), "%s_%s.wav", key.c_str(), vs.c_str());
            save(join(out_dir, nm), r.out, sr);
            char label[160];
            std::snprintf(label, sizeof(label), "%s=%s", key.c_str(), vs.c_str());
            print_score(label, r, hc);
        }
        std::printf("\nWrote %zu WAVs to %s\n", vals.size(), out_dir.c_str());
        return 0;
    }

    // ---------------- single render ----------------
    if (out_path.empty()) out_path = join(out_dir.empty() ? "." : out_dir, "nsxlab_out.wav");
    Result r = render(in.samples, sr, cfg, csv_path);
    score(r, clean, sr);
    std::printf("\nconfig: level=%d gain=%s alpha-dd=%.3f alpha-lrt=%.2f alpha-p=%.3f floor=%.1f dB\n"
                "        oversub=%.2f powerlaw=%s sed=%s makeup=%s abs-floor=%s(%.0f) "
                "freq=%d time=%.2f xiflat=%.2f\n",
                cfg.level, cfg.spp_as_gain ? "spp-as-gain" : "wiener",
                cfg.alpha_dd, cfg.alpha_lrt, cfg.alpha_p, cfg.floor_db, cfg.oversub,
                cfg.powerlaw ? "on" : "off", cfg.sed ? "on" : "off",
                cfg.makeup ? "on" : "off", cfg.abs_floor ? "on" : "off", cfg.abs_floor_db,
                cfg.freq_smooth, cfg.time_smooth, cfg.xiflat_w);
    print_score_header();
    print_score(nsx::base_name(out_path).c_str(), r, hc);
    if (!save(out_path, r.out, sr)) { std::fprintf(stderr, "write failed: %s\n", out_path.c_str()); return 1; }
    std::printf("\nwrote %s", out_path.c_str());
    if (!csv_path.empty()) std::printf("  +  telemetry %s", csv_path.c_str());
    std::printf("\n");
    return 0;
}
