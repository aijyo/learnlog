// eval.hpp — real-data evaluation harness.
//
// Purpose: every performance number this project has produced so far came from a SYNTHETIC signal
// (white + low-pass rumble noise, synthetic harmonic speech). Two designs recovered from Zoom
// measured WORSE on that bench (power-law noise-floor init: -1.24 dB net SNR; (1+xi)^2 flatness
// feature: -0.95 dB) even though both are well-motivated for real acoustics. The synthetic bench
// cannot arbitrate that. This harness runs the suppressor over REAL recordings and reports
// standard objective metrics, so those calls can finally be settled with evidence.
//
// Data layout expected (see samples/README.md for the licensing rule):
//     <clean_dir>/*.wav   clean speech, mono
//     <noise_dir>/*.wav   noise recordings, mono
// Every clean file is mixed with every noise file at each requested SNR. Mono only; files are
// resampled by the metric layer where a metric requires a fixed rate.
#pragma once
#include <string>
#include <vector>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include "wav.hpp"
#include "ns_core.hpp"
#include "metrics.hpp"

namespace nsx {
namespace eval {

struct Variant {
    std::string name;
    int   level = 2;
    bool  powerlaw_init = true;
    float alpha_p = 0.05f;     // speech-probability smoothing
    bool  makeup = false;      // post-gain level normalisation (default OFF, NOTES 5.9)
    float floor_off_db = 0.f;  // gain-floor offset vs the level default
    float makeup_alpha = 1.f;  // 1.0 = raw per-frame makeup (as recovered)
    bool  abs_floor = false;   // absolute dBFS floor (default OFF, NOTES 5.10)
    float abs_floor_dbfs = -65.f;
    int   freq_taps = 1;       // gain smoothing across frequency (1 = off)
    float time_alpha = 1.f;    // gain smoothing across time (1 = off)
};

struct Row {
    std::string clean, noise, variant;
    float snr_in = 0.f;
    double stoi_noisy = 0, stoi_proc = 0;
    double estoi_noisy = 0, estoi_proc = 0;
    double sisdr_noisy = 0, sisdr_proc = 0;
    double segsnr_noisy = 0, segsnr_proc = 0;
    double lsd_noisy = 0, lsd_proc = 0;
};

// Mix noise into speech at a target SNR measured over the SPEECH-ACTIVE part only (an all-file
// RMS would let long leading silences distort the requested SNR).
inline std::vector<float> mix_at_snr(const std::vector<float>& s, const std::vector<float>& n,
                                     float snr_db, int sr) {
    std::vector<float> out(s.size());
    // speech-active energy: frames within 40 dB of the loudest
    const int win = std::max(1, sr / 50);
    double peak = 1e-20;
    for (size_t i = 0; i + win <= s.size(); i += win) {
        double e = 0.0;
        for (int k = 0; k < win; ++k) e += (double)s[i + k] * s[i + k];
        peak = std::max(peak, e);
    }
    double se = 0.0; long sc = 0;
    for (size_t i = 0; i + win <= s.size(); i += win) {
        double e = 0.0;
        for (int k = 0; k < win; ++k) e += (double)s[i + k] * s[i + k];
        if (e >= peak * 1e-4) { se += e; sc += win; }
    }
    const double s_rms = std::sqrt(se / std::max(1L, sc));
    double ne = 0.0;
    for (size_t i = 0; i < n.size(); ++i) ne += (double)n[i] * n[i];
    const double n_rms = std::sqrt(ne / std::max<size_t>(1, n.size()));
    const double g = (s_rms / std::pow(10.0, snr_db / 20.0)) / std::max(n_rms, 1e-12);
    for (size_t i = 0; i < s.size(); ++i)
        out[i] = s[i] + (float)(n[i % n.size()] * g);   // loop the noise if shorter
    return out;
}

inline Row run_one(const std::vector<float>& clean, const std::vector<float>& noisy,
                   int sr, const Variant& v) {
    NoiseSuppressor ns(sr, v.level);
    ns.set_powerlaw_init(v.powerlaw_init);
    ns.set_alpha_p(v.alpha_p);
    ns.set_makeup_enabled(v.makeup);
    ns.set_floor_offset_db(v.floor_off_db);
    ns.set_makeup_smoothing(v.makeup_alpha);
    ns.set_abs_floor(v.abs_floor, v.abs_floor_dbfs);
    ns.set_freq_smoothing(v.freq_taps);
    ns.set_time_smoothing(v.time_alpha);
    std::vector<float> proc = ns.process_all(noisy);

    Row r;
    r.variant = v.name;
    r.stoi_noisy   = metrics::stoi (clean, noisy, sr);
    r.stoi_proc    = metrics::stoi (clean, proc,  sr);
    r.estoi_noisy  = metrics::estoi(clean, noisy, sr);
    r.estoi_proc   = metrics::estoi(clean, proc,  sr);
    r.sisdr_noisy  = metrics::si_sdr(clean, noisy);
    r.sisdr_proc   = metrics::si_sdr(clean, proc);
    r.segsnr_noisy = metrics::seg_snr(clean, noisy, sr);
    r.segsnr_proc  = metrics::seg_snr(clean, proc,  sr);
    r.lsd_noisy    = metrics::lsd(clean, noisy, sr);
    r.lsd_proc     = metrics::lsd(clean, proc,  sr);
    return r;
}

inline void print_header() {
    std::printf("\n%-16s %-12s %-10s %5s | %13s | %13s | %13s | %13s | %13s\n",
                "clean", "noise", "variant", "SNRin",
                "STOI n->p", "ESTOI n->p", "SI-SDR n->p", "segSNR n->p", "LSD n->p");
    std::printf("%s\n", std::string(140, '-').c_str());
}

inline void print_row(const Row& r) {
    std::printf("%-16s %-12s %-10s %5.1f | %5.3f %5.3f%+.3f | %5.3f %5.3f%+.3f | "
                "%5.1f %5.1f%+.1f | %5.1f %5.1f%+.1f | %5.1f %5.1f%+.1f\n",
        r.clean.substr(0, 16).c_str(), r.noise.substr(0, 12).c_str(), r.variant.c_str(), r.snr_in,
        r.stoi_noisy,  r.stoi_proc,  r.stoi_proc - r.stoi_noisy,
        r.estoi_noisy, r.estoi_proc, r.estoi_proc - r.estoi_noisy,
        r.sisdr_noisy, r.sisdr_proc, r.sisdr_proc - r.sisdr_noisy,
        r.segsnr_noisy, r.segsnr_proc, r.segsnr_proc - r.segsnr_noisy,
        r.lsd_noisy,   r.lsd_proc,   r.lsd_proc - r.lsd_noisy);
}

// Aggregate per variant: mean delta of each metric. This is the table that decides the open calls.
inline void print_summary(const std::vector<Row>& rows, const std::vector<Variant>& variants) {
    std::printf("\n=== mean delta per variant (processed - noisy; LSD lower is better) ===\n");
    std::printf("%-12s %6s | %8s | %8s | %9s | %9s | %8s\n",
                "variant", "n", "dSTOI", "dESTOI", "dSI-SDR", "dsegSNR", "dLSD");
    std::printf("%s\n", std::string(76, '-').c_str());
    for (const auto& v : variants) {
        double a = 0, b = 0, c = 0, d = 0, e = 0; long n = 0;
        for (const auto& r : rows) {
            if (r.variant != v.name) continue;
            if (r.stoi_proc < 0 || r.stoi_noisy < 0) continue;   // front end refused (too short)
            a += r.stoi_proc - r.stoi_noisy;
            b += r.estoi_proc - r.estoi_noisy;
            c += r.sisdr_proc - r.sisdr_noisy;
            d += r.segsnr_proc - r.segsnr_noisy;
            e += r.lsd_proc - r.lsd_noisy;
            ++n;
        }
        if (!n) { std::printf("%-12s %6d | (no usable rows)\n", v.name.c_str(), 0); continue; }
        std::printf("%-12s %6ld | %+8.4f | %+8.4f | %+9.2f | %+9.2f | %+8.2f\n",
                    v.name.c_str(), n, a / n, b / n, c / n, d / n, e / n);
    }
    std::printf("\nSTOI/ESTOI: 0..1, higher better (intelligibility). SI-SDR/segSNR: dB, higher better.\n");
    std::printf("LSD: dB, LOWER better. All metrics computed against the CLEAN reference.\n");
}

}  // namespace eval
}  // namespace nsx
