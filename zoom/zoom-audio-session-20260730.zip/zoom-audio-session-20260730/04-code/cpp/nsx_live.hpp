#pragma once
// nsx_live.hpp -- the real-time engine: capture device -> suppressor -> playback device.
//
// ONE implementation, two consumers:
//   live.cpp     -> nsxlive.exe   (console A/B tool)
//   nsx_capi.cpp -> nsxcore.dll   (driven from the WPF UI over P/Invoke)
// so the thing the UI runs and the thing the CLI runs are the same code. Duplicating it is exactly
// the mistake that let the mixing definition drift between nsxlab and the DLL (NOTES.md 8.2).
//
// miniaudio must already be included WITH MINIAUDIO_IMPLEMENTATION defined by the including TU --
// each final binary needs exactly one such TU, and putting the macro here would break whichever
// consumer included this header twice.

#include "ns_core.hpp"
#include "nsx_config.hpp"

#include <atomic>
#include <cmath>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

namespace nsx {

struct LiveStatus {
    float peak_in = 0.f, peak_out = 0.f;      // linear, decaying peak hold
    float rms_in = 0.f, rms_out = 0.f;        // linear, ~200 ms window -- steadier to read
    Telemetry tel;                            // most recent frame's decision
    long  hops = 0;                           // hops processed since start
    long  underruns = 0;                      // callbacks that found the output queue empty
    int   bypass = 0;
};

// Real-time engine. start() opens the device and runs until stop(); set_config() may be called at
// any time and takes effect on the next hop, which is what lets a UI slider be dragged while
// listening. Everything the audio thread writes for the UI to read goes through std::atomic.
class LiveEngine {
public:
    static constexpr int kSampleRate = 16000;

    LiveEngine() = default;
    ~LiveEngine() { stop(); }

    LiveEngine(const LiveEngine&) = delete;
    LiveEngine& operator=(const LiveEngine&) = delete;

    // cap/play: device indices, or -1 for the system default.
    // loopback: capture the system OUTPUT instead of a microphone (this is how another
    //           application's processed audio gets recorded for measurement).
    // playback: false = process but stay silent, the safe mode when not on headphones.
    bool start(const Cfg& cfg, int cap, int play, bool loopback, bool playback, int period,
               std::string* err = nullptr);
    void stop();
    bool running() const { return running_.load(); }

    void set_config(const Cfg& c) {
        std::lock_guard<std::mutex> lk(cfg_mtx_);
        pending_ = c;
        cfg_dirty_.store(true);
    }
    void set_bypass(bool on) { bypass_.store(on); }
    bool bypass() const { return bypass_.load(); }

    void record_start() {
        std::lock_guard<std::mutex> lk(mtx_);
        rec_raw_.clear();
        rec_proc_.clear();
        record_.store(true);
    }
    // Returns the sample count written, 0 if nothing was captured.
    size_t record_stop(const std::string& base);

    LiveStatus status() const {
        LiveStatus s;
        s.peak_in  = peak_in_.load();
        s.peak_out = peak_out_.load();
        s.rms_in   = rms_in_.load();
        s.rms_out  = rms_out_.load();
        s.hops     = hops_.load();
        s.underruns = underruns_.load();
        s.bypass   = bypass_.load() ? 1 : 0;
        std::lock_guard<std::mutex> lk(tel_mtx_);
        s.tel = tel_;
        return s;
    }

    // Called from the miniaudio callback. Public only because the C callback needs to reach it.
    void on_audio(const float* in, float* out, unsigned frames);

private:
    void* device_ = nullptr;                  // ma_device*, opaque so this header needs no miniaudio
    void* ctx_ = nullptr;                     // ma_context*, must outlive the device
    std::atomic<bool> running_{false};

    NoiseSuppressor* ns_ = nullptr;
    int hop_ = 256;
    std::deque<float> inq_, outq_;
    mutable std::mutex mtx_;

    Cfg cfg_, pending_;
    std::mutex cfg_mtx_;
    std::atomic<bool> cfg_dirty_{false};

    std::atomic<bool> bypass_{false}, playback_{true}, record_{false};
    std::atomic<float> peak_in_{0.f}, peak_out_{0.f}, rms_in_{0.f}, rms_out_{0.f};
    std::atomic<long> hops_{0}, underruns_{0};

    mutable std::mutex tel_mtx_;
    Telemetry tel_;

    std::vector<float> rec_raw_, rec_proc_;
};

inline void LiveEngine::on_audio(const float* in, float* out, unsigned frames) {
    std::lock_guard<std::mutex> lk(mtx_);
    if (!ns_) return;

    if (cfg_dirty_.exchange(false)) {
        std::lock_guard<std::mutex> ck(cfg_mtx_);
        cfg_ = pending_;
        apply(*ns_, cfg_);          // takes effect from the next hop
    }

    double sq_in = 0.0;
    float pin = 0.f;
    for (unsigned i = 0; i < frames; ++i) {
        const float v = in ? in[i] : 0.f;
        inq_.push_back(v);
        const float a = std::fabs(v);
        if (a > pin) pin = a;
        sq_in += (double)v * v;
    }
    if (record_.load() && in) rec_raw_.insert(rec_raw_.end(), in, in + frames);

    // Drain whole hops. process_hop() returns false until the first analysis window has filled and
    // its output lags the input by one window -- that is the algorithmic latency, not a defect.
    const bool byp = bypass_.load();
    std::vector<float> hin((size_t)hop_), hout((size_t)hop_);
    while ((int)inq_.size() >= hop_) {
        for (int i = 0; i < hop_; ++i) { hin[(size_t)i] = inq_.front(); inq_.pop_front(); }
        const bool ready = ns_->process_hop(hin.data(), hout.data());
        for (int i = 0; i < hop_; ++i)
            outq_.push_back(byp ? hin[(size_t)i] : (ready ? hout[(size_t)i] : 0.f));
        if (ready) {
            hops_.fetch_add(1);
            std::lock_guard<std::mutex> tk(tel_mtx_);
            tel_ = ns_->telemetry();
        }
    }

    double sq_out = 0.0;
    float pout = 0.f;
    const bool pb = playback_.load();
    for (unsigned i = 0; i < frames; ++i) {
        float v = 0.f;
        if (!outq_.empty()) { v = outq_.front(); outq_.pop_front(); }
        else if (hops_.load() > 2) underruns_.fetch_add(1);
        // Record the PROCESSED sample, not what reaches the speakers: they differ under
        // playback=false, and taking it from the output buffer made the safe mode record silence.
        if (record_.load()) rec_proc_.push_back(v);
        if (out) out[i] = pb ? v : 0.f;
        const float a = std::fabs(v);
        if (a > pout) pout = a;
        sq_out += (double)v * v;
    }

    // Decaying peak hold, plus a slow RMS. The peak shows transients, the RMS is what the eye can
    // actually compare between input and output -- and their difference IS the current attenuation.
    const float dec = 0.90f;
    peak_in_.store(pin > peak_in_.load() ? pin : peak_in_.load() * dec);
    peak_out_.store(pout > peak_out_.load() ? pout : peak_out_.load() * dec);
    const float a_rms = 0.15f;
    const float ri = (float)std::sqrt(sq_in / (double)(frames ? frames : 1));
    const float ro = (float)std::sqrt(sq_out / (double)(frames ? frames : 1));
    rms_in_.store(rms_in_.load() + a_rms * (ri - rms_in_.load()));
    rms_out_.store(rms_out_.load() + a_rms * (ro - rms_out_.load()));
}

}  // namespace nsx
