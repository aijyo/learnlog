#ifndef NSX_CAPI_H
#define NSX_CAPI_H
// nsx_capi.h -- flat C ABI over the header-only C++ suppressor, so a managed UI can drive it.
//
// Why a C ABI and not C++/CLI: /clr cannot coexist with the static-CRT (/MT) standalone build the
// workspace requires, and a mixed-mode assembly would drag in the VC redistributable. A plain
// __cdecl DLL with POD-only parameters keeps nsxcore.dll dependency-free (KERNEL32 only) and makes
// the managed side a thin P/Invoke shim with no algorithm code of its own.
//
// ABI RULES (violating these silently corrupts memory across the boundary):
//   * every struct here is POD and must stay layout-identical to its C# [StructLayout(Sequential)]
//     mirror in ui/NsxInterop.cs -- field order, field count and field widths all matter;
//   * `bool` is never used -- C++ bool is 1 byte, C# bool marshals as 4 by default. int everywhere;
//   * the DLL never hands ownership of C++ containers out; buffers are caller-allocated, except
//     nsx_wav_read which returns a block that must be released with nsx_free.

#ifdef _WIN32
#  ifdef NSX_BUILD_DLL
#    define NSX_API __declspec(dllexport)
#  else
#    define NSX_API __declspec(dllimport)
#  endif
#else
#  define NSX_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

// ---------------------------------------------------------------- config
// Mirrors nsx::Cfg (nsx_config.hpp) one-for-one, bools widened to int.
typedef struct NsxConfig {
    int   level;             // 0..5   suppression aggressiveness (drives the gain-floor table)
    float alpha_dd;          // 0.98   decision-directed a-priori SNR recursion   [Zoom E3950]
    float alpha_lrt;         // 0.5    per-bin LRT smoothing                      [Zoom E3380]
    float alpha_p;           // 0.05   frame speech-probability smoothing (Zoom ~0.1)
    float floor_db;          // -6     spectral gain floor
    float oversub;           // 1.25   noise over-subtraction factor
    // level picks BOTH of the above from its ladder; they are applied only when the caller says so.
    // Leaving these at 0 makes `level` behave (it used to be a dead knob, silently overridden).
    int   floor_override;    // 0      1 = honour floor_db instead of level's table
    int   oversub_override;  // 0      1 = honour oversub instead of level's table
    int   powerlaw;          // 1      A/k^alpha noise-floor cold start           [Zoom E3950]
    int   makeup;            // 0      post-gain level normalisation              [Zoom E56E0]
    float makeup_alpha;      // 1.0
    int   abs_floor;         // 0      absolute dBFS suppression floor            [Zoom DB830]
    float abs_floor_db;      // -65
    int   freq_smooth;       // 1      gain smoothing taps across frequency (ours, refuted)
    float time_smooth;       // 1.0    gain smoothing across time     (ours, refuted)
    int   sed;               // 1      SED steering: music protect + transient freeze
    float xiflat_w;          // 0.0    weight of the (1+xi)^2 flatness feature    [Zoom DBD10]
    // 0 = Wiener xi/(oversub+xi), the DEFAULT and what the binary implies. 1 = use the per-bin SPP
    // as the gain -- what we shipped first, confirmed wrong: E3380 stores that array for the noise
    // tracker (its caller reads the same offset) and never multiplies the spectrum.
    int   spp_as_gain;       // 0
    int   thresh_mode;       // 2      0 = SelfAdaptive (ours, refuted), 1 = Absolute, 2 = Histogram
    float thr_lrt;           // 0.05   absolute feature thresholds; the histogram refines them
    float thr_flat;          // 0.32
    float thr_diff;          // 0.47
    float sc_lrt;            // 0.10   per-feature spread, so tanh width 4/8 lands on our scale
    float sc_flat;           // 0.06
    float sc_diff;           // 0.25
    float thr_harm;          // 0.30
    float sc_harm;           // 0.30
    int   hist_window;       // 250    frames per histogram window (~4 s at 62 fps)
    int   zoom_noise;        // 1      E3950's rise cap + beta switch + slow tracker
} NsxConfig;

// ---------------------------------------------------------------- per-frame telemetry
// SedInfo is flattened in; sed_event uses nsx::Event ordering (0 silence, 1 speech, 2 music,
// 3 stationary-noise, 4 transient).
typedef struct NsxTelemetry {
    float speech_prob, snr_prob, flat_prob, diff_prob, spec_diff;
    float xi_flatness, harmonicity, snr_db, gain, makeup;
    float flatness[4];
    float noise_level[4];
    int   voice;
    int   noise_changed;
    int   noise_count;
    int   sed_event;
    float sed_pitch_hz, sed_stability, sed_modulation, sed_flux;
    int   sed_music_protect;
} NsxTelemetry;

// ---------------------------------------------------------------- metrics
// stoi/estoi are -1 when no clean reference was supplied.
typedef struct NsxMetrics {
    double stoi, estoi, si_sdr, seg_snr, lsd, in_dbfs, out_dbfs;
} NsxMetrics;

// Values actually in force for a given config (i.e. after level's ladder and any override), so a
// UI can show what the suppressor will really use rather than what the struct happens to hold.
NSX_API float       nsx_effective_floor_db(const NsxConfig* cfg);
NSX_API float       nsx_effective_oversub(const NsxConfig* cfg);
NSX_API void        nsx_default_config(NsxConfig* cfg);
NSX_API const char* nsx_build_info(void);

// Runs the WHOLE buffer through a fresh suppressor using the offset-aligned overlap-add path
// (net zero delay). Metrics computed against a clean reference are only valid on this path --
// the streaming hop path lags by one frame, which alone costs ~45 dB of SI-SDR.
//   out       : caller-allocated, n floats
//   tel/cap   : optional (NULL/0). Returns the frame count produced, even when tel is NULL,
//               so a caller can size its buffer with one dry run.
NSX_API int nsx_process(const NsxConfig* cfg, int sample_rate,
                        const float* in, int n, float* out,
                        NsxTelemetry* tel, int tel_cap);

NSX_API int    nsx_frame_count(int sample_rate, int n);
NSX_API int    nsx_hop_size(int sample_rate);
NSX_API void   nsx_metrics(const float* clean, const float* proc, int n, int sample_rate,
                           NsxMetrics* m);
NSX_API double nsx_dbfs(const float* x, int n);

// ---------------------------------------------------------------- wav + mixing
// nsx_wav_read: on success writes a malloc'd mono float block to *samples (release with nsx_free).
// Returns 1 on success, 0 on failure.
NSX_API int  nsx_wav_read(const char* path, float** samples, int* n, int* sample_rate);
NSX_API int  nsx_wav_write(const char* path, const float* samples, int n, int sample_rate);
NSX_API void nsx_free(float* p);

// Mixes noise into speech at a target SNR measured over SPEECH-ACTIVE frames only (frames within
// 40 dB of the loudest), which is what makes "5 dB SNR" mean the same thing across clips of
// differing pause structure. out is caller-allocated with n_speech floats; noise is tiled/cropped.
NSX_API void nsx_mix_at_snr(const float* speech, int n_speech,
                            const float* noise, int n_noise,
                            float snr_db, int sample_rate, float* out);

// ---------------------------------------------------------------- live microphone path
// The suppressor running on a real capture device, driven from the UI. Same LiveEngine the console
// tool nsxlive.exe uses, so what the UI does and what the CLI does cannot diverge.
//
// nsx_live_set_config may be called while running: it takes effect on the next hop, which is what
// makes dragging a slider audible immediately.
typedef struct NsxLiveStatus {
    float peak_in, peak_out;       // linear, decaying peak hold
    float rms_in, rms_out;         // linear, ~200 ms smoothed. in/out difference == current attenuation
    NsxTelemetry tel;              // most recent frame's decision
    int   hops;                    // hops processed since start
    int   underruns;               // output queue found empty (device period too small)
    int   bypass;
    int   running;
} NsxLiveStatus;

// Device lists for the UI dropdowns. Call nsx_live_refresh_devices() first; the returned strings are
// owned by the DLL and stay valid until the next refresh.
NSX_API void        nsx_live_refresh_devices(void);
NSX_API int         nsx_live_device_count(int playback);
NSX_API const char* nsx_live_device_name(int playback, int index);

// cap/play: device index, or -1 for the system default.
// loopback: capture the system OUTPUT rather than a microphone.
// playback: 0 = process but stay silent (the safe mode when not wearing headphones).
// Returns 1 on success; on failure writes a reason into err (may be NULL) of err_cap bytes.
NSX_API int  nsx_live_start(const NsxConfig* cfg, int cap, int play, int loopback, int playback,
                            int period, char* err, int err_cap);
NSX_API void nsx_live_stop(void);
NSX_API int  nsx_live_running(void);
NSX_API void nsx_live_set_config(const NsxConfig* cfg);
NSX_API void nsx_live_set_bypass(int on);
NSX_API void nsx_live_status(NsxLiveStatus* s);
NSX_API void nsx_live_record_start(void);
// Writes <base>_raw.wav and <base>_proc.wav. Returns the sample count, 0 if nothing was captured.
NSX_API int  nsx_live_record_stop(const char* base_path);

// ---------------------------------------------------------------- mechanism registry
// Generated from nsx::kMechs, so the UI's control list and the CLI's --list table are the same
// data. Returned strings are static; do not free.
NSX_API int         nsx_mech_count(void);
NSX_API const char* nsx_mech_flag(int i);
NSX_API const char* nsx_mech_origin(int i);
NSX_API const char* nsx_mech_note(int i);
NSX_API const char* nsx_mech_ablate_label(int i);
// Applies mechanism i's ablation (the "other side" of the knob) to cfg in place.
NSX_API void        nsx_mech_ablate(int i, NsxConfig* cfg);

#ifdef __cplusplus
}
#endif
#endif  // NSX_CAPI_H
