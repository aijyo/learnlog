#pragma once
// nsx_live_ma.hpp -- the miniaudio half of LiveEngine: device enumeration, open, close.
//
// Split from nsx_live.hpp so that header stays free of miniaudio and can be read without wading
// through a 95k-line dependency. Include this from EXACTLY ONE translation unit per binary, after
// defining MINIAUDIO_IMPLEMENTATION.

#include "nsx_live.hpp"
#include "wav.hpp"

#include <string>
#include <vector>

namespace nsx {

// Device names for a UI's dropdowns. Cached in a static so the returned pointers stay valid for the
// caller -- miniaudio's own ma_device_info array dies with the context.
inline std::vector<std::string>& live_device_cache(bool playback) {
    static std::vector<std::string> caps, plays;
    return playback ? plays : caps;
}

inline void live_refresh_devices() {
    live_device_cache(false).clear();
    live_device_cache(true).clear();
    ma_context ctx;
    if (ma_context_init(nullptr, 0, nullptr, &ctx) != MA_SUCCESS) return;
    ma_device_info* play = nullptr; ma_uint32 nplay = 0;
    ma_device_info* cap = nullptr;  ma_uint32 ncap = 0;
    if (ma_context_get_devices(&ctx, &play, &nplay, &cap, &ncap) == MA_SUCCESS) {
        for (ma_uint32 i = 0; i < ncap; ++i)
            live_device_cache(false).push_back(std::string(cap[i].name) +
                                              (cap[i].isDefault ? "  (default)" : ""));
        for (ma_uint32 i = 0; i < nplay; ++i)
            live_device_cache(true).push_back(std::string(play[i].name) +
                                              (play[i].isDefault ? "  (default)" : ""));
    }
    ma_context_uninit(&ctx);
}

namespace detail {
inline void live_callback(ma_device* dev, void* out, const void* in, ma_uint32 frames) {
    auto* eng = (LiveEngine*)dev->pUserData;
    if (eng) eng->on_audio((const float*)in, (float*)out, (unsigned)frames);
}
}  // namespace detail

inline bool LiveEngine::start(const Cfg& cfg, int cap, int play, bool loopback, bool playback,
                             int period, std::string* err) {
    if (running_.load()) return true;

    {
        std::lock_guard<std::mutex> lk(mtx_);
        delete ns_;
        ns_ = new NoiseSuppressor(kSampleRate, cfg.level);
        apply(*ns_, cfg);
        hop_ = ns_->hop_size();
        inq_.clear();
        outq_.clear();
        rec_raw_.clear();
        rec_proc_.clear();
    }
    cfg_ = pending_ = cfg;
    cfg_dirty_.store(false);
    playback_.store(playback);
    hops_.store(0);
    underruns_.store(0);
    peak_in_.store(0.f); peak_out_.store(0.f);
    rms_in_.store(0.f);  rms_out_.store(0.f);

    ma_context* ctx = new ma_context();
    if (ma_context_init(nullptr, 0, nullptr, ctx) != MA_SUCCESS) {
        delete ctx;
        if (err) *err = "ma_context_init failed";
        return false;
    }
    ma_device_info* pl = nullptr; ma_uint32 npl = 0;
    ma_device_info* cp = nullptr; ma_uint32 ncp = 0;
    ma_context_get_devices(ctx, &pl, &npl, &cp, &ncp);

    ma_device_config dc = ma_device_config_init(loopback ? ma_device_type_loopback
                                                         : ma_device_type_duplex);
    dc.sampleRate         = kSampleRate;
    dc.capture.format     = ma_format_f32;
    dc.capture.channels   = 1;
    dc.capture.shareMode  = ma_share_mode_shared;
    dc.playback.format    = ma_format_f32;
    dc.playback.channels  = 1;
    dc.periodSizeInFrames = (ma_uint32)(period > 0 ? period : 256);
    dc.dataCallback       = detail::live_callback;
    dc.pUserData          = this;
    if (cap >= 0 && (ma_uint32)cap < ncp)  dc.capture.pDeviceID  = &cp[cap].id;
    if (play >= 0 && (ma_uint32)play < npl) dc.playback.pDeviceID = &pl[play].id;

    auto* dev = new ma_device();
    if (ma_device_init(ctx, &dc, dev) != MA_SUCCESS) {
        ma_context_uninit(ctx);
        delete dev; delete ctx;
        if (err) *err = loopback ? "ma_device_init failed (loopback needs a shared-mode output device)"
                                 : "ma_device_init failed -- check the capture/playback selection";
        return false;
    }
    if (ma_device_start(dev) != MA_SUCCESS) {
        ma_device_uninit(dev);
        ma_context_uninit(ctx);
        delete dev; delete ctx;
        if (err) *err = "ma_device_start failed";
        return false;
    }
    // The context must outlive the device; stash it where stop() can find it.
    dev->pUserData = this;
    device_ = dev;
    ctx_ = ctx;
    running_.store(true);
    return true;
}

inline void LiveEngine::stop() {
    if (!device_) return;
    auto* dev = (ma_device*)device_;
    ma_device_stop(dev);
    ma_device_uninit(dev);
    delete dev;
    device_ = nullptr;
    if (ctx_) {
        ma_context_uninit((ma_context*)ctx_);
        delete (ma_context*)ctx_;
        ctx_ = nullptr;
    }
    running_.store(false);
    std::lock_guard<std::mutex> lk(mtx_);
    delete ns_;
    ns_ = nullptr;
}

inline size_t LiveEngine::record_stop(const std::string& base) {
    record_.store(false);
    std::vector<float> raw, proc;
    {
        std::lock_guard<std::mutex> lk(mtx_);
        raw.swap(rec_raw_);
        proc.swap(rec_proc_);
    }
    if (raw.empty()) return 0;
    std::string b = base;
    const size_t dot = b.rfind('.');
    if (dot != std::string::npos) b = b.substr(0, dot);
    Wav a; a.sample_rate = kSampleRate; a.samples = raw;
    Wav p; p.sample_rate = kSampleRate; p.samples = proc;
    wav_write(b + "_raw.wav", a);
    wav_write(b + "_proc.wav", p);
    return raw.size();
}

}  // namespace nsx
