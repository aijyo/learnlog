// nsx_capi.cpp -- implementation of the flat C ABI. Contains no algorithm logic of its own: every
// entry point forwards into ns_core.hpp / metrics.hpp / wav.hpp / nsx_config.hpp. If a number is
// computed here rather than forwarded, that is a bug -- it would mean the UI and the CLI can
// disagree about what the suppressor does.

#define NSX_BUILD_DLL
#include "nsx_capi.h"

#include "ns_core.hpp"
#include "nsx_config.hpp"
#include "metrics.hpp"
#include "wav.hpp"
#include "eval.hpp"

// The live microphone path. miniaudio's implementation lands in THIS translation unit, which is the
// only one in the DLL that needs it -- nsxlive.exe has its own copy for its own binary.
#define MINIAUDIO_IMPLEMENTATION
#define MA_NO_DECODING
#define MA_NO_ENCODING
#define MA_NO_GENERATION
#define MA_NO_RESOURCE_MANAGER
#define MA_NO_NODE_GRAPH
#include "3rd/miniaudio.h"
#include "nsx_live_ma.hpp"

#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace {

// The two structs are deliberately NOT memcpy-compatible (bool vs int), so conversion is explicit.
// A field added to nsx::Cfg without a line here is a silent no-op from the UI's point of view;
// the static_assert below is the tripwire.
static_assert(sizeof(nsx::Cfg) > 0, "nsx::Cfg must be visible");

nsx::Cfg from_c(const NsxConfig* c) {
    nsx::Cfg k;                                  // start from the shipping defaults
    if (!c) return k;
    k.level        = c->level;
    k.alpha_dd     = c->alpha_dd;
    k.alpha_lrt    = c->alpha_lrt;
    k.alpha_p      = c->alpha_p;
    k.floor_db     = c->floor_db;
    k.oversub      = c->oversub;
    k.floor_override   = c->floor_override != 0;
    k.oversub_override = c->oversub_override != 0;
    k.powerlaw     = c->powerlaw != 0;
    k.makeup       = c->makeup != 0;
    k.makeup_alpha = c->makeup_alpha;
    k.abs_floor    = c->abs_floor != 0;
    k.abs_floor_db = c->abs_floor_db;
    k.freq_smooth  = c->freq_smooth;
    k.time_smooth  = c->time_smooth;
    k.sed          = c->sed != 0;
    k.xiflat_w     = c->xiflat_w;
    k.spp_as_gain  = c->spp_as_gain != 0;
    k.thresh_mode  = c->thresh_mode;
    k.thr_lrt      = c->thr_lrt;
    k.thr_flat     = c->thr_flat;
    k.thr_diff     = c->thr_diff;
    k.sc_lrt       = c->sc_lrt;
    k.sc_flat      = c->sc_flat;
    k.sc_diff      = c->sc_diff;
    k.thr_harm     = c->thr_harm;
    k.sc_harm      = c->sc_harm;
    k.hist_window  = c->hist_window;
    k.zoom_noise   = c->zoom_noise != 0;
    return k;
}

void to_c(const nsx::Cfg& k, NsxConfig* c) {
    c->level        = k.level;
    c->alpha_dd     = k.alpha_dd;
    c->alpha_lrt    = k.alpha_lrt;
    c->alpha_p      = k.alpha_p;
    c->floor_db     = k.floor_db;
    c->oversub      = k.oversub;
    c->floor_override   = k.floor_override ? 1 : 0;
    c->oversub_override = k.oversub_override ? 1 : 0;
    c->powerlaw     = k.powerlaw ? 1 : 0;
    c->makeup       = k.makeup ? 1 : 0;
    c->makeup_alpha = k.makeup_alpha;
    c->abs_floor    = k.abs_floor ? 1 : 0;
    c->abs_floor_db = k.abs_floor_db;
    c->freq_smooth  = k.freq_smooth;
    c->time_smooth  = k.time_smooth;
    c->sed          = k.sed ? 1 : 0;
    c->xiflat_w     = k.xiflat_w;
    c->spp_as_gain  = k.spp_as_gain ? 1 : 0;
    c->thresh_mode  = k.thresh_mode;
    c->thr_lrt      = k.thr_lrt;
    c->thr_flat     = k.thr_flat;
    c->thr_diff     = k.thr_diff;
    c->sc_lrt       = k.sc_lrt;
    c->sc_flat      = k.sc_flat;
    c->sc_diff      = k.sc_diff;
    c->thr_harm     = k.thr_harm;
    c->sc_harm      = k.sc_harm;
    c->hist_window  = k.hist_window;
    c->zoom_noise   = k.zoom_noise ? 1 : 0;
}

int event_to_int(nsx::Event e) {
    switch (e) {
        case nsx::Event::Silence:        return 0;
        case nsx::Event::Speech:         return 1;
        case nsx::Event::Music:          return 2;
        case nsx::Event::StationaryNoise:return 3;
        case nsx::Event::Transient:      return 4;
    }
    return 0;
}

void fill_tel(NsxTelemetry* d, const nsx::Telemetry& s) {
    d->speech_prob = s.speech_prob; d->snr_prob = s.snr_prob;   d->flat_prob = s.flat_prob;
    d->diff_prob   = s.diff_prob;   d->spec_diff = s.spec_diff;
    d->xi_flatness = s.xi_flatness; d->harmonicity = s.harmonicity;
    d->snr_db      = s.snr_db;      d->gain = s.gain;           d->makeup = s.makeup;
    for (int b = 0; b < 4; ++b) { d->flatness[b] = s.flatness[b]; d->noise_level[b] = s.noise_level[b]; }
    d->voice          = s.voice ? 1 : 0;
    d->noise_changed  = s.noise_changed;
    d->noise_count    = (int)s.noise_count;
    d->sed_event         = event_to_int(s.sed.event);
    d->sed_pitch_hz      = s.sed.pitch_hz;
    d->sed_stability     = s.sed.pitch_stability;
    d->sed_modulation    = s.sed.modulation;
    d->sed_flux          = s.sed.flux;
    d->sed_music_protect = s.sed.music_protection ? 1 : 0;
}

}  // namespace

// ---------------------------------------------------------------- config / info

extern "C" NSX_API void nsx_default_config(NsxConfig* cfg) {
    if (!cfg) return;
    to_c(nsx::Cfg{}, cfg);
}

extern "C" NSX_API float nsx_effective_floor_db(const NsxConfig* cfg) {
    nsx::NoiseSuppressor ns(16000);
    nsx::apply(ns, from_c(cfg));
    return ns.floor_db();
}

extern "C" NSX_API float nsx_effective_oversub(const NsxConfig* cfg) {
    nsx::NoiseSuppressor ns(16000);
    nsx::apply(ns, from_c(cfg));
    return ns.oversub();
}

extern "C" NSX_API const char* nsx_build_info(void) {
    return "nsxcore " __DATE__ " " __TIME__ " | Zoom viper.dll NS reimplementation";
}

// ---------------------------------------------------------------- processing

extern "C" NSX_API int nsx_hop_size(int sample_rate) {
    nsx::NoiseSuppressor ns(sample_rate <= 0 ? 16000 : sample_rate);
    return ns.hop_size();
}

extern "C" NSX_API int nsx_frame_count(int sample_rate, int n) {
    nsx::NoiseSuppressor ns(sample_rate <= 0 ? 16000 : sample_rate);
    const int hop = ns.hop_size();
    // process_all() advances by hop while a full window still fits; window == 4 * hop here, but we
    // ask the object rather than assume it.
    const int win = hop * 4;
    return (n >= win) ? (n - win) / hop + 1 : 0;
}

extern "C" NSX_API int nsx_process(const NsxConfig* cfg, int sample_rate,
                                   const float* in, int n, float* out,
                                   NsxTelemetry* tel, int tel_cap) {
    if (!in || n <= 0) return 0;
    const int sr = sample_rate <= 0 ? 16000 : sample_rate;

    nsx::NoiseSuppressor ns(sr);
    nsx::apply(ns, from_c(cfg));

    std::vector<float> x(in, in + n);
    std::vector<nsx::Telemetry> t;
    std::vector<float> y = ns.process_all(x, &t);

    if (out) {
        const size_t m = y.size() < (size_t)n ? y.size() : (size_t)n;
        std::memcpy(out, y.data(), m * sizeof(float));
        for (size_t i = m; i < (size_t)n; ++i) out[i] = 0.f;
    }
    if (tel && tel_cap > 0) {
        const int m = (int)t.size() < tel_cap ? (int)t.size() : tel_cap;
        for (int i = 0; i < m; ++i) fill_tel(&tel[i], t[(size_t)i]);
    }
    return (int)t.size();
}

extern "C" NSX_API double nsx_dbfs(const float* x, int n) {
    if (!x || n <= 0) return -120.0;
    std::vector<float> v(x, x + n);
    const double e = nsx::metrics::energy(v) / (double)n;
    return 10.0 * std::log10(e > 1e-20 ? e : 1e-20);
}

extern "C" NSX_API void nsx_metrics(const float* clean, const float* proc, int n,
                                    int sample_rate, NsxMetrics* m) {
    if (!m) return;
    m->stoi = m->estoi = -1.0;
    m->si_sdr = m->seg_snr = m->lsd = 0.0;
    m->in_dbfs = m->out_dbfs = -120.0;
    if (!proc || n <= 0) return;
    const int sr = sample_rate <= 0 ? 16000 : sample_rate;

    std::vector<float> p(proc, proc + n);
    m->out_dbfs = nsx_dbfs(proc, n);
    if (!clean) return;

    std::vector<float> c(clean, clean + n);
    m->in_dbfs  = nsx_dbfs(clean, n);
    m->stoi     = nsx::metrics::stoi(c, p, sr);
    m->estoi    = nsx::metrics::estoi(c, p, sr);
    m->si_sdr   = nsx::metrics::si_sdr(c, p);
    m->seg_snr  = nsx::metrics::seg_snr(c, p, sr);
    m->lsd      = nsx::metrics::lsd(c, p, sr);
}

// ---------------------------------------------------------------- wav + mixing

extern "C" NSX_API int nsx_wav_read(const char* path, float** samples, int* n, int* sample_rate) {
    if (!path || !samples || !n || !sample_rate) return 0;
    nsx::Wav w;
    if (!nsx::wav_read(std::string(path), w)) return 0;
    const size_t cnt = w.samples.size();
    if (cnt == 0) return 0;
    float* blk = (float*)std::malloc(cnt * sizeof(float));
    if (!blk) return 0;
    std::memcpy(blk, w.samples.data(), cnt * sizeof(float));
    *samples = blk;
    *n = (int)cnt;
    *sample_rate = w.sample_rate;
    return 1;
}

extern "C" NSX_API int nsx_wav_write(const char* path, const float* samples, int n, int sample_rate) {
    if (!path || !samples || n <= 0) return 0;
    nsx::Wav w;
    w.sample_rate = sample_rate <= 0 ? 16000 : sample_rate;
    w.samples.assign(samples, samples + n);
    return nsx::wav_write(std::string(path), w) ? 1 : 0;
}

extern "C" NSX_API void nsx_free(float* p) { std::free(p); }

extern "C" NSX_API void nsx_mix_at_snr(const float* speech, int n_speech,
                                       const float* noise, int n_noise,
                                       float snr_db, int sample_rate, float* out) {
    if (!speech || !noise || !out || n_speech <= 0 || n_noise <= 0) return;
    std::vector<float> s(speech, speech + n_speech);
    // Pass the noise through UNCROPPED. mix_at_snr measures the noise RMS over everything it is
    // given and tiles with `i % size` internally, so pre-cropping to the speech length silently
    // changes the gain whenever the noise file is longer than the speech -- which is the normal
    // case (Babble_1 is 61 s, the utterances are ~16 s). Cropping here cost 0.88 dB of added noise
    // and made every metric look better than the CLI's; the smoke test caught it.
    std::vector<float> nz(noise, noise + n_noise);
    std::vector<float> y = nsx::eval::mix_at_snr(s, nz, snr_db, sample_rate <= 0 ? 16000 : sample_rate);
    const size_t m = y.size() < (size_t)n_speech ? y.size() : (size_t)n_speech;
    std::memcpy(out, y.data(), m * sizeof(float));
    for (size_t i = m; i < (size_t)n_speech; ++i) out[i] = 0.f;
}

// ---------------------------------------------------------------- live microphone path
// One process-wide engine. A second concurrent capture would fight over the device anyway, and a
// handle-based API would only invite the UI to leak one.
namespace { nsx::LiveEngine g_live; }

extern "C" NSX_API void nsx_live_refresh_devices(void) { nsx::live_refresh_devices(); }

extern "C" NSX_API int nsx_live_device_count(int playback) {
    return (int)nsx::live_device_cache(playback != 0).size();
}

extern "C" NSX_API const char* nsx_live_device_name(int playback, int index) {
    auto& v = nsx::live_device_cache(playback != 0);
    return (index >= 0 && index < (int)v.size()) ? v[(size_t)index].c_str() : "";
}

extern "C" NSX_API int nsx_live_start(const NsxConfig* cfg, int cap, int play, int loopback,
                                      int playback, int period, char* err, int err_cap) {
    std::string e;
    const bool ok = g_live.start(from_c(cfg), cap, play, loopback != 0, playback != 0, period, &e);
    if (!ok && err && err_cap > 0) {
        std::strncpy(err, e.c_str(), (size_t)err_cap - 1);
        err[err_cap - 1] = '\0';
    }
    return ok ? 1 : 0;
}

extern "C" NSX_API void nsx_live_stop(void) { g_live.stop(); }
extern "C" NSX_API int  nsx_live_running(void) { return g_live.running() ? 1 : 0; }
extern "C" NSX_API void nsx_live_set_bypass(int on) { g_live.set_bypass(on != 0); }

extern "C" NSX_API void nsx_live_set_config(const NsxConfig* cfg) {
    g_live.set_config(from_c(cfg));
}

extern "C" NSX_API void nsx_live_status(NsxLiveStatus* s) {
    if (!s) return;
    const nsx::LiveStatus st = g_live.status();
    s->peak_in  = st.peak_in;  s->peak_out = st.peak_out;
    s->rms_in   = st.rms_in;   s->rms_out  = st.rms_out;
    s->hops     = (int)st.hops;
    s->underruns = (int)st.underruns;
    s->bypass   = st.bypass;
    s->running  = g_live.running() ? 1 : 0;
    fill_tel(&s->tel, st.tel);
}

extern "C" NSX_API void nsx_live_record_start(void) { g_live.record_start(); }

extern "C" NSX_API int nsx_live_record_stop(const char* base_path) {
    return (int)g_live.record_stop(base_path ? std::string(base_path) : std::string("nsx_live"));
}

// ---------------------------------------------------------------- mechanism registry

extern "C" NSX_API int nsx_mech_count(void) { return nsx::kNumMechs; }

extern "C" NSX_API const char* nsx_mech_flag(int i) {
    return (i >= 0 && i < nsx::kNumMechs) ? nsx::kMechs[i].flag : "";
}
extern "C" NSX_API const char* nsx_mech_origin(int i) {
    return (i >= 0 && i < nsx::kNumMechs) ? nsx::kMechs[i].origin : "";
}
extern "C" NSX_API const char* nsx_mech_note(int i) {
    return (i >= 0 && i < nsx::kNumMechs) ? nsx::kMechs[i].note : "";
}
extern "C" NSX_API const char* nsx_mech_ablate_label(int i) {
    return (i >= 0 && i < nsx::kNumMechs) ? nsx::kMechs[i].ablate_label : "";
}

extern "C" NSX_API void nsx_mech_ablate(int i, NsxConfig* cfg) {
    if (!cfg || i < 0 || i >= nsx::kNumMechs) return;
    nsx::Cfg k = from_c(cfg);
    nsx::kMechs[i].ablate(k);
    to_c(k, cfg);
}
