"""The int8 affine + block-sparse scheme SNAC uses, so a trained model can be exported the same way.

Read from the weight table: every int8 tensor carries a `_scale` and a `_subias`, and every
`*_gru*_input` additionally carries a `_weights_idx`. That is affine (not symmetric) per-tensor
quantisation with an explicit zero-point compensation term, plus block sparsity on the GRU input
matrices only.

Why `_subias` rather than a zero-point integer: folding the zero-point into a bias means the inner
loop is a plain int8 dot product with no per-element offset, so it maps onto the integer SIMD paths
(the binary names an AVX encoder). This is a real implementation choice worth copying if you intend to
run the model in C++ rather than in PyTorch.

    W_int8[i,j] = round(W[i,j] / scale)
    subias[i]   = -sum_j W_int8[i,j] * zero_point_of_input          (folded into the layer bias)
    y = (W_int8 @ x_int8) * scale_w * scale_x + bias + subias

Nothing here touches Zoom's weights. These helpers quantise YOUR trained tensors.
"""
import torch


def quantize_affine(w, n_bits=8):
    """Per-tensor affine int8. Returns (int8 tensor, scale, subias-ready row sums)."""
    qmax = 2 ** (n_bits - 1) - 1
    scale = w.abs().amax().clamp_min(1e-12) / qmax
    q = torch.clamp(torch.round(w / scale), -qmax - 1, qmax).to(torch.int8)
    row_sum = q.to(torch.float32).sum(dim=-1)      # for the subias term
    return q, float(scale), row_sum


def dequantize(q, scale):
    return q.to(torch.float32) * scale


def quant_error_db(w, n_bits=8):
    """SNR of the quantisation, in dB. Use it to decide which layers must stay float.

    The original keeps `enc_dense1` and `cond_net_fdense1` in float while everything else is int8 --
    so a per-layer decision, not a blanket one. This function is how you make the same decision for
    your own trained weights instead of copying theirs.
    """
    q, s, _ = quantize_affine(w, n_bits)
    err = (w - dequantize(q, s)).pow(2).mean()
    sig = w.pow(2).mean()
    return float(10.0 * torch.log10(sig / err.clamp_min(1e-20)))


def block_sparse_mask(w, density=0.25, block=16):
    """Block-sparse mask over a 2-D weight matrix, matching the `_weights_idx` layout.

    Block granularity is what makes sparsity pay off in a SIMD kernel: an unstructured mask saves
    multiplies but not memory traffic or branches, whereas skipping whole blocks skips whole loads.
    """
    import torch.nn.functional as F
    o, i = w.shape
    bo, bi = max(1, o // block), max(1, i // block)
    pooled = F.adaptive_avg_pool2d(w.abs().unsqueeze(0).unsqueeze(0), (bo, bi))[0, 0]
    k = max(1, int(density * pooled.numel()))
    thr = pooled.flatten().topk(k).values.min()
    m = (pooled >= thr).float()
    return F.interpolate(m.unsqueeze(0).unsqueeze(0), size=(o, i), mode="nearest")[0, 0]


def export_report(model, float_layers=()):
    """Per-parameter int8 SNR, so you can see which layers would need to stay float."""
    rows = []
    for name, p in model.named_parameters():
        if p.dim() < 2:
            continue
        keep = any(f in name for f in float_layers)
        rows.append((name, tuple(p.shape), p.numel(), quant_error_db(p.detach()), keep))
    rows.sort(key=lambda r: r[3])
    return rows


def print_export_report(model, float_layers=("dense1",)):
    rows = export_report(model, float_layers)
    tot = sum(r[2] for r in rows)
    print("%-52s %-18s %10s %9s %s" % ("parameter", "shape", "count", "int8 SNR", "keep float?"))
    print("-" * 104)
    for name, shape, n, snr, keep in rows:
        print("%-52s %-18s %10d %8.1f dB %s" % (name[:52], str(shape), n, snr,
                                                "YES" if keep else ""))
    print("-" * 104)
    print("total 2-D params: %d  (%.2f MB float32, %.2f MB int8)"
          % (tot, tot * 4 / 1048576, tot / 1048576))
