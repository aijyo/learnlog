"""Model C -- SED, Zoom's sound event detector, rebuilt in PyTorch.

This is the best-recovered of the three models: every dimension was read from the binary AND
cross-checked against an independently-read constant. The lever was `viper::SedModelCalculate_C` --
a scalar reference implementation sitting beside `_SSE2` and `_AVX2`. The C variant is the same
algorithm without the vectorisation, so it is the readable one: 535 bytes against 5267 and 4707.

THE ARCHITECTURE, ALL READ (viperex.dll, sub_18015B8F0 and its four callees):

    input   100 x 40                          uint8 affine quantised (scale, zero_point)
    L1  Conv2d( 1 -> 25, k=3x5, s=(1,2))  ->  98 x 18
    L2  Conv2d(25 -> 20, k=3x5, s=(1,1))  ->  96 x 14
    L3  Conv2d(20 -> 10, k=5x5, s=(2,2))  ->  46 x  5
    dequantise -> 10 x 46 x 5 = 2300 floats

  requantisation after every conv:  q = clamp((bias_i64 + mult_q31 * acc) >> 31 >> shift, 0, 255)
  the clamp at 0 IS the ReLU -- there is no separate activation.

EVERY NUMBER CROSS-CHECKS against a constant read somewhere else, which is why this one is trustworthy
in a way the denoise net's shape tables were not:

    98 x 18 = 1764   <- L2's input-channel stride  (v14 += 1764)
    96 x 14 = 1344   <- L3's input-channel stride  (v14 += 1344)
    25 x 15 x 2 = 750    <- L2's per-output-channel weight stride (a4 += 750) => 15 = 3x5 kernel
    20 x 25 x 2 = 1000   <- L3's per-output-channel weight stride (a4 += 1000) => 25 = 5x5 kernel
    46 x 28 = 1288   <- L3's row loop bound, 28 = 14 cols x 2 bytes
    10 x 230 = 2300  <- the dequantiser's element count, and 230 = 46 x 5
    100 x 40 = 4000  <- the quantiser's loop, 1000 iterations x 4 unrolled

WHAT THE 40 AND THE 100 MEAN: 40 is the feature dimension (a 40-band filterbank is the usual choice at
16 kHz) and 100 frames at Zoom's 10 ms hop is ONE SECOND. That matches the independently-established
fact that SED is a ~1 s scene classifier which runs asynchronously, off the audio callback -- it cannot
switch at word-gap granularity and was never meant to.

WHAT IS OURS:
  * the classifier head. The recovered code stops at 2300 dequantised floats; how those become event
    classes is in the processor's vt[11] / the smoothing stages, not yet read. The head here is a
    pooled linear layer, marked as ours.
  * the exact filterbank (mel vs linear-band, cutoffs). 40 bands is read from the layout; the
    warping is not.
  * class count and class identities. 10 output channels is read; that they ARE the classes is an
    inference, and a natural one.

NOT INCLUDED: Zoom's trained weights.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# read from the binary -- (in_ch, out_ch, kernel, stride)
SED_CONV = [(1, 25, (3, 5), (1, 2)),
            (25, 20, (3, 5), (1, 1)),
            (20, 10, (5, 5), (2, 2))]
SED_IN = (100, 40)          # frames x bands; 100 frames x 10 ms = 1 s
SED_OUT_MAP = (10, 46, 5)   # = 2300, matching the dequantiser's element count


class QuantStub(nn.Module):
    """The uint8 affine quantiser Zoom applies to the input, kept as a module so it can be exported.

    Read from sub_18015B8F0:
        q = zero_point + round_half_away_from_zero(x / scale)
        q = clamp(q, 0, 255)
    Note the rounding: `(v < 0) ? v - 0.5 : v + 0.5` then truncate, i.e. round-half-AWAY-from-zero,
    not banker's rounding. It matters if you ever compare against a reference implementation.

    Training runs in float (`enabled=False`); switch it on for quantisation-aware fine-tuning.
    """

    def __init__(self, scale=1.0, zero_point=0, enabled=False):
        super().__init__()
        self.register_buffer("scale", torch.tensor(float(scale)))
        self.register_buffer("zp", torch.tensor(float(zero_point)))
        self.enabled = enabled

    def forward(self, x):
        if not self.enabled:
            return x
        q = x / self.scale.clamp_min(1e-12)
        q = torch.where(q < 0, q - 0.5, q + 0.5).trunc() + self.zp
        q = q.clamp(0, 255)
        return (q - self.zp) * self.scale        # fake-quant: quantise then dequantise


class SedNet(nn.Module):
    """Zoom's SED CNN: three convolutions over a 100 x 40 filterbank map, ReLU by clamping.

    Args:
        n_classes: size of the classifier head. 10 matches the recovered output-channel count; the
                   head itself is OURS (see module docstring).
        pool:      'avg' pools the 46x5 map per channel (what a 1 s scene classifier wants),
                   'flat' keeps all 2300 values (higher capacity, needs more data).
        quant:     enable fake-quantisation of the input, for QAT.
    """

    def __init__(self, n_classes=10, pool="avg", quant=False, in_shape=SED_IN):
        super().__init__()
        self.in_shape = in_shape
        self.pool = pool
        self.qin = QuantStub(enabled=quant)
        self.convs = nn.ModuleList()
        for cin, cout, k, s in SED_CONV:
            self.convs.append(nn.Conv2d(cin, cout, k, stride=s))
        # Zoom requantises to uint8 after every conv, so activations are non-negative and bounded.
        # In float training the clamp lower bound is the ReLU; the upper bound only matters under QAT.
        self.head = nn.Linear(SED_OUT_MAP[0] if pool == "avg"
                              else SED_OUT_MAP[0] * SED_OUT_MAP[1] * SED_OUT_MAP[2], n_classes)

    def features(self, x):
        """x: (B, 100, 40) -> (B, 10, 46, 5). Shapes are asserted against the recovered map."""
        h = self.qin(x).unsqueeze(1)                     # (B, 1, 100, 40)
        for conv in self.convs:
            h = F.relu(conv(h))                          # ReLU == the clamp at 0
        return h

    def forward(self, x):
        h = self.features(x)
        if self.pool == "avg":
            z = h.mean((2, 3))                           # per-channel over the 46x5 map
        else:
            z = h.flatten(1)
        return self.head(z), h

    def check_shapes(self, verbose=True):
        """Assert the layer outputs match the sizes read from the binary. Cheap regression test."""
        with torch.no_grad():
            h = torch.zeros(1, 1, *self.in_shape)
            got = []
            for conv in self.convs:
                h = conv(h)
                got.append(tuple(h.shape[1:]))
        want = [(25, 98, 18), (20, 96, 14), (10, 46, 5)]
        ok = got == want
        if verbose:
            for i, (g, w) in enumerate(zip(got, want)):
                print("  L%d  got %-14s want %-14s %s" % (i + 1, g, w, "OK" if g == w else "MISMATCH"))
            print("  flat %d (recovered dequantiser count: 2300) %s"
                  % (got[-1][0] * got[-1][1] * got[-1][2],
                     "OK" if got[-1][0] * got[-1][1] * got[-1][2] == 2300 else "MISMATCH"))
        return ok

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    @staticmethod
    def provenance():
        return {
            "read": ["100x40 input (1 s at Zoom's 10 ms hop, 40 bands)",
                     "three convs: 1->25 k3x5 s(1,2), 25->20 k3x5 s(1,1), 20->10 k5x5 s(2,2)",
                     "uint8 affine input quantisation with round-half-away-from-zero",
                     "Q31 requantisation (bias + mult*acc)>>31>>shift, clamp [0,255] = ReLU",
                     "output map 10x46x5 = 2300, matching the dequantiser's element count",
                     "every dimension cross-checked against an independently-read constant"],
            "ours": ["the classifier head (recovered code stops at the 2300 dequantised floats)",
                     "filterbank warping (40 bands is read; mel-vs-linear is not)",
                     "that the 10 channels ARE the event classes"],
            "excluded": ["Zoom's trained weights"],
        }


# ---------------------------------------------------------------- front end
class FilterBank(nn.Module):
    """40-band log filterbank over a 512-point FFT, to feed the 100 x 40 map.

    The band COUNT is read (40, from the input layout). The warping is not -- mel is used here because
    it is the standard choice at 16 kHz and because the recovered feature list elsewhere in the chain
    ("harmonicity", "flatness x4") is consistent with a perceptually-warped band split. Marked as ours.
    """

    def __init__(self, sr=16000, n_fft=512, n_bands=40, fmin=20.0, fmax=None):
        super().__init__()
        fmax = fmax or sr / 2
        n_bins = n_fft // 2 + 1

        def hz2mel(f):
            import math
            return 2595.0 * math.log10(1.0 + f / 700.0)

        def mel2hz(m):
            return 700.0 * (10.0 ** (m / 2595.0) - 1.0)

        lo, hi = hz2mel(fmin), hz2mel(fmax)
        pts = [mel2hz(lo + (hi - lo) * i / (n_bands + 1)) for i in range(n_bands + 2)]
        bins = [int(round(p * (n_fft) / sr)) for p in pts]
        fb = torch.zeros(n_bands, n_bins)
        for b in range(n_bands):
            l, c, r = bins[b], bins[b + 1], bins[b + 2]
            c = max(c, l + 1)
            r = max(r, c + 1)
            for k in range(l, min(c, n_bins)):
                fb[b, k] = (k - l) / max(c - l, 1)
            for k in range(c, min(r, n_bins)):
                fb[b, k] = (r - k) / max(r - c, 1)
        self.register_buffer("fb", fb)

    def forward(self, mag):                   # mag: (B, n_bins, T) or (n_bins, T)
        single = mag.dim() == 2
        if single:
            mag = mag.unsqueeze(0)
        e = torch.einsum("bkt,mk->bmt", mag.pow(2), self.fb)
        out = torch.log(e.clamp_min(1e-10)).transpose(1, 2)      # (B, T, n_bands)
        return out.squeeze(0) if single else out
