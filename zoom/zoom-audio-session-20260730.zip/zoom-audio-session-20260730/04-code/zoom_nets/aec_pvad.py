﻿"""Model F/G -- the neural AEC and the personalised VAD, in PyTorch.

These two are recovered LESS completely than SED or CAM++, and the code says so per item. Read them as
"the right shape of thing, with the dimensions marked as ours" rather than as ports.

=============================================================================
F · Neural AEC  (AecNnModel / AecQ16NnGeneralModelImpl / AecQ16NnMusicModelImpl / ECNNProcessor)
=============================================================================
WHAT IS READ -- the topology is now settled: it is a symmetric U-Net.

  * TWO models, ONE architecture. `AecQ16NnGeneralModelImpl` and `AecQ16NnMusicModelImpl` have vtable
    slot sizes 1176 / 755 / 2359 and 1176 / 755 / 2346, and they SHARE slot 1 (the same function
    address). Same code, two weight sets -- a general one and a music one.
  * `Q16` in both names, i.e. INT16 quantisation (not the uint8 SED uses).
  * The forward is 33 indirect calls through a 30-slot ISA dispatch table at 0x183C387B0..0x183C38898.
    Every slot is 0xFFFFFFFFFFFFFFFF in the file and bound at load time, which is why no static scan
    finds them. Three installers fill the table, and IDA mislabelled all three as CRT helpers:
        _cfltcvt_init_18  installs 30 SCALAR kernels     <- the readable reference set
        _cfltcvt_init_19  overwrites 25 with AVX         (selected when flags & 0x20)
        _cfltcvt_init_20  overwrites 25 with SSE         (selected when flags & 4)
    So `_18` plays exactly the role a `_C` class suffix does elsewhere in this binary.
  * FIVE slots have NO SIMD version at all (0x183C38878/80/88/90/98) -- including the skip-merge, which
    is the binary's own statement that merging is not the hot path.
  * THE SKIP TOPOLOGY, read from the buffer arguments. The encoder writes a1+456, 464, 472, 480, 488;
    the decoder's merge calls consume them in exact reverse order:
        step 16 <- a1+488     step 19 <- a1+480     step 22 <- a1+472
        step 25 <- a1+464     step 28 <- a1+456
    Five skips, LIFO. That is a U-Net, not the straight-line chain this file previously described.
  * The decoder is perfectly regular: SIX stages of {conv, second op, skip-merge}, the last one with no
    merge (5 merges for 6 stages). `sub_180120230`, the 13-argument merge kernel, is called 5 times.
  * LAYER COUNT CROSS-CHECK: 7 encoder + 6 x 2 decoder = 19 weight-bearing layers, which is exactly
    the 19 counted independently from the destructor's buffer-free list (this+248..this+392 step 8).
    Two unrelated readings agreeing on 19 is what makes the count trustworthy.
  * ELEVEN recurrent states, all int16, each filled from a LEARNED constant read out of the weight
    blob (`*v12++ = v10` with `_WORD*`, value from `**(_WORD **)(**(_QWORD **)(a1 + 256) + 24)`).
    Learned initial states are a recurring trick in this engine -- SNAC's `dec_gru_init` does the same.
  * A separate `EchoDetectionProcessThread` exists, i.e. echo DETECTION is a distinct module from
    cancellation, and it runs on both send and receive sides.

WHAT IS OURS: every layer's WIDTH and kernel size, the input representation, and the loss. The widths
are read at runtime from the layer descriptor objects (`*(int *)(*(_QWORD *)(a1 + 80) + 4)`), so the
literals are in the constructor chain, not in the init or the forward. That is the one remaining read.

WHY A NEURAL AEC AT ALL, and what it is for: a linear adaptive filter models the echo path well until
the path is non-linear (small loudspeakers clipping) or non-stationary (someone moves the laptop).
Residual echo after the linear stage is what a network is good at removing, and it is why this sits
AFTER a conventional AEC rather than replacing it. The music model exists because the general model is
trained to treat sustained tonal content as echo-like, which is exactly wrong for music.

WHY A U-NET HERE: echo suppression needs both a wide receptive field (the echo tail is long) and exact
spectral detail (so speech is not blurred). Downsampling buys the first, and the skip connections give
the decoder back the fine detail the encoder threw away. Without the skips a mask estimator at this
depth would smear formants.

=============================================================================
G · Personalised VAD  (IPVADProcessor / viper::PVADProcessor)
=============================================================================
WHAT IS READ: it exists as its own processor with 8 vtable slots (348 / 457 / 976 / 364 / 252 / 88 /
187 / 52 bytes), and the name says personalised -- i.e. speaker-conditioned. It sits alongside the
speaker-embedding extractor, and the audio-chunk telemetry line in the same module prints a CAM++
score next to a "picknet" score, so an enrollment embedding is available to it at runtime.
CORRECTION: the string "picknet" does NOT occur anywhere in viperex.dll -- a full byte scan finds
zero hits, and the only PVAD-related RTTI is IPVADProcessor / PVADProcessor@viper@@. So that lead
came from a different module and cannot be followed here. PVADProcessor::vt[2] (sub_180109C10) is
a SCHEDULER, not a forward pass -- mutexes, a 40 ms gate, a 1.5 s cadence accumulator -- so this
model's network is genuinely not located yet. This file stays the lowest-confidence of the seven.

WHAT IS OURS: the entire architecture. Only the concept and the interface shape are recovered.

WHY IT MATTERS: a plain VAD says "someone is speaking". In a shared office that is the wrong question --
you want "is the ENROLLED speaker speaking", so that a colleague two desks away is treated as noise.
That is the difference between a VAD and a personalised VAD, and it is why it needs an embedding.

NOT INCLUDED: Zoom's trained weights. The PVAD path consumes a speaker embedding, so the ethics note
in voice/CLAUDE.md applies: enroll only your own voice or one you have explicit consent for.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .campp import CAMPP_EMBED


# =========================================================================== AEC
class GatedConvBlock(nn.Module):
    """Gated conv over time with a residual path -- a reasonable stand-in for one link of the chain.

    The chain in the binary is strictly sequential with ping-pong buffers, so each block must map
    (B, C, T) -> (B, C, T) with no skip crossing block boundaries. That constraint IS read; the block's
    internals are ours.
    """

    def __init__(self, ch, k=3, dilation=1):
        super().__init__()
        p = dilation * (k - 1) // 2
        self.value = nn.Conv1d(ch, ch, k, padding=p, dilation=dilation)
        self.gate = nn.Conv1d(ch, ch, k, padding=p, dilation=dilation)
        self.norm = nn.GroupNorm(1, ch)

    def forward(self, x):
        h = self.value(x) * torch.sigmoid(self.gate(x))
        return F.relu(self.norm(h)) + x


class AecNet(nn.Module):
    """Residual-echo suppressor as a U-Net: (mic, far-end reference) -> mask for the mic.

    Two inputs is not a design choice -- an echo canceller cannot work without the reference (the
    information simply is not in the mic signal alone), which is why the interface has to be this shape.

    READ: 7 encoder layers, 6 decoder stages, 5 skip connections consumed in LIFO order, 19
    weight-bearing layers, INT16 weights, 11 recurrent states with learned initial values.
    OURS: the widths (they are set by the constructor chain, which is the one read still outstanding),
    the kernel sizes, the input representation and the loss.

    Args:
        variant: 'general' or 'music'. The binary ships two weight sets over one architecture; this
                 flag only records which checkpoint you mean, it does not change the graph.
    """

    N_LAYERS_READ = 19          # 7 encoder + 6 x 2 decoder; also the destructor's buffer count
    N_SKIPS_READ = 5            # merge calls, consuming a1+488, 480, 472, 464, 456 in that order
    N_DECODER_STAGES_READ = 6
    N_ENCODER_LAYERS_READ = 7
    N_RECURRENT_STATES_READ = 11
    QUANT_READ = "int16 (Q16)"

    def __init__(self, bins=257, ch=64, variant="general", recurrent=True):
        super().__init__()
        assert variant in ("general", "music")
        self.variant = variant
        self.bins = bins
        # mic and reference are encoded separately then fused -- keeping them apart until after the
        # first projection lets the network learn the delay/level relationship rather than assuming it
        self.enc_mic = nn.Conv1d(bins, ch, 1)
        self.enc_ref = nn.Conv1d(bins, ch, 1)
        self.fuse = nn.Conv1d(2 * ch, ch, 1)

        # encoder: 7 layers, the last 5 of which publish a skip. Widths are OURS.
        self.enc = nn.ModuleList([GatedConvBlock(ch, 3, 2 ** (i % 4))
                                  for i in range(self.N_ENCODER_LAYERS_READ)])
        # a learned initial state per recurrent unit -- read as a learned int16 constant per state
        self.rnn = nn.GRU(ch, ch, batch_first=True) if recurrent else None
        if recurrent:
            self.h0 = nn.Parameter(torch.zeros(1, 1, ch))     # the "learned initial state" trick

        # decoder: 6 stages of {conv, second op, merge}; the last stage has no merge
        self.dec_a = nn.ModuleList([GatedConvBlock(ch, 3, 1)
                                    for _ in range(self.N_DECODER_STAGES_READ)])
        self.dec_b = nn.ModuleList([nn.Conv1d(ch, ch, 1)
                                    for _ in range(self.N_DECODER_STAGES_READ)])
        self.merge = nn.ModuleList([nn.Conv1d(2 * ch, ch, 1)
                                    for _ in range(self.N_SKIPS_READ)])
        self.head = nn.Conv1d(ch, bins, 1)

    def forward(self, mic_mag, ref_mag):
        """mic_mag / ref_mag: (B, T, bins) log-power -> mask (B, T, bins) in [0, 1]."""
        m = self.enc_mic(mic_mag.transpose(1, 2))
        r = self.enc_ref(ref_mag.transpose(1, 2))
        h = self.fuse(torch.cat([m, r], 1))

        skips = []
        for i, b in enumerate(self.enc):
            h = b(h)
            if i >= self.N_ENCODER_LAYERS_READ - self.N_SKIPS_READ:
                skips.append(h)                       # the last 5 encoder outputs are the skips

        if self.rnn is not None:
            h0 = self.h0.expand(1, h.shape[0], -1).contiguous()
            y, _ = self.rnn(h.transpose(1, 2), h0)
            h = y.transpose(1, 2)

        for i in range(self.N_DECODER_STAGES_READ):
            h = self.dec_b[i](self.dec_a[i](h))
            if i < self.N_SKIPS_READ:                  # LIFO: last encoder output merged first
                h = self.merge[i](torch.cat([h, skips[-1 - i]], 1))
        return torch.sigmoid(self.head(h)).transpose(1, 2)

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    def check_topology(self):
        """Assert the counts against the binary. Raises on mismatch."""
        assert len(self.enc) == 7 and len(self.dec_a) == 6 and len(self.merge) == 5
        assert len(self.enc) + 2 * len(self.dec_a) == self.N_LAYERS_READ == 19
        return True

    @staticmethod
    def provenance():
        return {
            "confidence": "MEDIUM -- topology fully read, widths still ours (was LOW)",
            "read": ["two models over ONE architecture (general / music), sharing vtable slot 1",
                     "INT16 (Q16) quantisation",
                     "33 indirect calls through a 30-slot ISA dispatch table, all slots bound at "
                     "load time (0xFFFFFFFFFFFFFFFF in the file)",
                     "the three installers _cfltcvt_init_18/19/20 are IDA-mislabelled ISA selectors; "
                     "_18 installs the 30 SCALAR kernels and is the readable reference set",
                     "five slots have no SIMD version at all, including the skip-merge",
                     "U-NET: encoder writes a1+456,464,472,480,488 and the decoder merges them in "
                     "exact reverse order at steps 16,19,22,25,28 -- 5 skips, LIFO",
                     "6 decoder stages of {conv, second op, merge}; the last has no merge",
                     "19 weight-bearing layers = 7 encoder + 6x2 decoder, matching the destructor's "
                     "independent buffer count of 19",
                     "11 int16 recurrent states, each initialised from a LEARNED constant in the "
                     "weight blob (same trick as SNAC's dec_gru_init)",
                     "echo DETECTION is a separate module from cancellation, on both send and receive"],
            "ours": ["every layer width", "the kernel sizes", "the input representation", "the loss",
                     "the mic+reference fusion scheme"],
            "excluded": ["Zoom's trained weights"],
            "still_to_read": ["the constructor chain that sets layer[+4]/layer[+8] -- the widths are "
                              "read from the layer descriptor objects at runtime, so the literals are "
                              "neither in the init nor in the forward"],
            "corrected": ["previously described as a straight-line 19-layer chain; it is a U-Net with "
                          "5 skip connections"],
        }


# =========================================================================== PVAD
# PVAD HAS NO NETWORK OF ITS OWN. This was the last open question of the seven, and the answer is that
# the question was wrong. Read out of viperex.dll:
#
#   PVADProcessor::vt[0] (sub_180108D20) allocates ONE 0x48-byte object -- 72 bytes, far too small to
#   be a model -- and two 0x200 = 512-element buffers. That object's lazy init (sub_180110E60) then
#   picks an ISA variant and constructs it:
#         (mask & 0x10) -> sub_18018B3B0     whose first .data lea is CamppCalculator_AVX::vftable
#         (mask & 1)    -> sub_180185A30                          CamppCalculator_SSE2::vftable
#         else          -> sub_18017E470                          CamppCalculator_C::vftable
#   and allocates 0xBB80 = 48000 and 0x5D20 = 24000 element buffers. 48000 is exactly CAM++'s window.
#
# So PVAD = the CAM++ speaker embedding plus scheduling and a decision rule. That also explains why
# PVADProcessor::vt[2] read as a scheduler rather than a forward pass: it IS one.
#
# READ constants (all literal):
#   vt[3] (sub_18010ADC0) -- the feed path:
#       accumulates int16 samples until 24000  = 1.5 s @ 16 kHz  -> then runs one evaluation
#       stores one float per frame, capped at 150, and 24000 / 160 hop = 150 exactly
#       sums those 150 floats before evaluating  -> a frame-level VAD score gates the comparison
#       memmove of 0xBB80 bytes = 24000 int16 out of the ring
#   so: a 3 s embedding window advanced 1.5 s at a time = 50% overlap
#   vt[1] (sub_18010B8E0) -- enrollment:
#       copies the caller's vector into a1+2768, one of the two 0x200 = 512-element buffers
#       sets a flag at a1+2761, reads a threshold double at a1+3024 under its own mutex,
#       and pushes a 0x1C-byte record onto a ring buffer
#
# The 512-element enrollment buffer is an INDEPENDENT confirmation of CAM++'s embedding width, from a
# different code path than the one that gave {280, 512, k1}. Two unrelated reads agreeing on 512 is
# why campp.CAMPP_EMBED is not a guess.
#
# STILL OURS: the exact decision rule. Cosine similarity is the standard comparison for L2-normalised
# speaker embeddings and the code does read a single threshold double, but the binary does not show the
# arithmetic, and the hysteresis below is a reasonable-behaviour choice, not a recovered one.


class PvadDecision(nn.Module):
    """Personalised VAD as it actually works: CAM++ embedding vs enrollment, on a sliding window.

    This is deliberately NOT a trainable network -- there is nothing to train. The only learned
    component is the speaker embedding model, which is `campp.CamppNet`. Everything here is the
    scheduling and thresholding that sits on top, with the read constants as defaults.

    Why it is built this way rather than as a conditioned VAD: an embedding comparison needs enough
    audio to be stable (3 s), but a VAD has to answer often. Recomputing a 3 s embedding every 1.5 s
    and holding the verdict between updates buys stability at the cost of 1.5 s of reaction latency --
    which is acceptable because the decision being made is "is this the enrolled person", and that
    does not change mid-sentence.
    """

    WINDOW_SAMPLES = 48000      # 3 s @ 16 kHz -- CAM++'s window, read as 0xBB80
    ADVANCE_SAMPLES = 24000     # 1.5 s -- read as the literal 24000 in vt[3]
    FRAMES_PER_ADVANCE = 150    # read as the literal 150; 24000 / 160 hop = 150
    HOP = 160

    def __init__(self, embedder=None, threshold=0.55, vad_gate=0.30,
                 on_frames=2, off_frames=5):
        super().__init__()
        self.embedder = embedder            # a campp.CamppNet; None = supply embeddings directly
        self.threshold = threshold          # OURS -- the code reads one threshold double
        self.vad_gate = vad_gate            # OURS -- gate on the mean of the 150 frame scores
        self.on_frames, self.off_frames = on_frames, off_frames   # OURS -- hysteresis
        self.register_buffer("enrolled", torch.zeros(0), persistent=False)
        self._on = 0
        self._off = 0
        self._state = False

    def enroll(self, embedding):
        """Store the enrollment embedding. The binary keeps 512 floats for exactly this."""
        e = F.normalize(embedding.detach().reshape(-1), dim=-1)
        self.enrolled = e
        return e.numel()

    def score(self, embedding):
        """Cosine similarity against the enrollment. OURS: the comparison is not shown in the code."""
        if self.enrolled.numel() == 0:
            raise RuntimeError("no enrollment embedding -- call enroll() first")
        e = F.normalize(embedding.reshape(embedding.shape[0], -1), dim=-1)
        return e @ self.enrolled

    def step(self, similarity, frame_vad_scores=None):
        """One evaluation, i.e. one 1.5 s advance. Returns the latched decision.

        frame_vad_scores: the per-frame floats vt[3] accumulates (up to 150). Their mean gates the
        comparison, which is what the code's summation loop is for -- comparing embeddings on a window
        that is mostly silence produces a meaningless similarity.
        """
        if frame_vad_scores is not None and len(frame_vad_scores) > 0:
            speechy = float(torch.as_tensor(frame_vad_scores).float().mean())
            if speechy < self.vad_gate:
                self._on = 0
                return self._state                      # not enough speech -- hold
        if float(similarity) >= self.threshold:
            self._on, self._off = self._on + 1, 0
            if self._on >= self.on_frames:
                self._state = True
        else:
            self._off, self._on = self._off + 1, 0
            if self._off >= self.off_frames:
                self._state = False
        return self._state

    def reset(self):
        self._on = self._off = 0
        self._state = False

    def forward(self, audio, frame_vad_scores=None):
        """audio: (T,) 16 kHz mono. Yields one decision per 1.5 s advance.

        Requires an `embedder` and a filterbank front end; without them, use score()/step() directly
        with embeddings you computed elsewhere.
        """
        if self.embedder is None:
            raise RuntimeError("no embedder -- pass a campp.CamppNet, or use score()/step()")
        out = []
        n = audio.shape[-1]
        for end in range(self.WINDOW_SAMPLES, n + 1, self.ADVANCE_SAMPLES):
            win = audio[..., end - self.WINDOW_SAMPLES:end]
            out.append(self.step(self.score(self.embedder(win)), frame_vad_scores))
        return out

    def param_count(self):
        return sum(p.numel() for p in self.parameters())     # 0 -- there is nothing to train

    @staticmethod
    def provenance():
        return {
            "confidence": "the STRUCTURE is now settled -- there is no network. Constants read; the "
                          "comparison arithmetic is ours.",
            "read": ["PVADProcessor allocates ONE 0x48-byte object and no model class",
                     "that object constructs a CamppCalculator (_C / _SSE2 / _AVX by ISA mask); the "
                     "scalar branch sub_18017E470's first .data lea IS CamppCalculator_C::vftable",
                     "buffers 0xBB80 = 48000 (CAM++'s 3 s window) and 0x5D20 = 24000",
                     "vt[3]: accumulate to 24000 samples = 1.5 s, then evaluate -> 50% window overlap",
                     "vt[3]: one float per frame capped at 150, and 24000/160 = 150 exactly; their "
                     "sum gates the evaluation",
                     "vt[1]: enrollment copied into a 0x200 = 512-element buffer -- an INDEPENDENT "
                     "confirmation of CAM++'s 512-wide embedding",
                     "vt[1]: a single threshold double at a1+3024, read under its own mutex",
                     "vt[2] is a scheduler (mutexes, 40 ms gate, 1.5 s cadence), not a forward pass"],
            "ours": ["cosine similarity as the comparison (standard for L2-normalised embeddings, and "
                     "a single threshold is consistent, but the arithmetic is not shown)",
                     "the hysteresis counters and the VAD gate value"],
            "excluded": ["Zoom's trained weights -- and note the only trained part here is CamppNet"],
            "corrected": ["the previous FiLM-conditioned PvadNet was invented wholesale; PVAD has no "
                          "network of its own",
                          "'picknet' does not occur anywhere in viperex.dll -- that lead was dead"],
        }


# Kept as an alias so older callers do not break, but it is not a network any more.
PvadNet = PvadDecision
