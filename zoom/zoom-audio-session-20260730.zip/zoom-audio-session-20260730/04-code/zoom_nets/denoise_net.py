﻿"""Model A -- the viperex denoise network, rebuilt in PyTorch from the recovered architecture.

CONFIDENCE: MEDIUM-HIGH (was MEDIUM). The connecting OPERATION is now read -- a quantised dense
matmul with a Q31 requantise and a shared table-lookup activation (see provenance() and
recovered.DENOISE_QUANT_IDIOM). Only the per-slot widths remain unread. An earlier version of
this docstring over-claimed it. Read the audit below before trusting any dimension here.

WHAT IS READ (the numbers are literally in the tables):
  * 257 bins in, 1 x 257 mask out
  * two ladders, layer by layer in table order:
        widths    257 -> 128 -> 64 -> 32 -> 16 -> 8 -> (8->4) -> 1
                    1 ->   4 ->  8 -> 16 -> 32 -> 64 -> 128 -> 258 -> 257
        cols[2]     8     16    32    64    64    64            128
                   64     64    32    32    32    16     8     8     1
  * the layer-type PARTITION from cols[4..7]: three repeating signatures (5,2,1,2) / (1,1,0,0) /
    (3,1,1,1) that split the tables into groups
  * three auxiliary classifier heads, read line by line: conv -> ReLU -> 16x10 frame history -> conv
    -> ReLU -> 10-tap moving mean and UNBIASED variance (/9) -> every 10th frame: dense -> sigmoid

WHAT IS *NOT* ESTABLISHED -- and this is the audit result that downgraded this model:
  * WHAT OPERATION connects consecutive width entries. Testing the conv output-size formula with
    pad = cols[6] fails on 13 of 14 tables, and the pad that WOULD be required varies per row
    (0, 3, 4, 5). So cols[4..7] are probably not (kernel, stride, pad, dilation) acting on cols[0].
  * the ladder is EXACT halving of an odd 257 (257 -> 128, then powers of two). A padded strided
    convolution does not produce exact halving of an odd length; pooling or fixed decimation does.
  * which axis the widths live on. The 200 ms ring buffers rule out TIME as a six-times-strided axis
    (that would need >=128 frames of context and the buffers hold ~20), but ruling out time does not
    prove the widths are frequency rather than, say, flat buffer extents.
  * an earlier note cross-checked this against malloc(4 * a2[1][1] * a2[1][2]) = 4*128*8. That product
    is explained equally well by the other field reading, so it never discriminated between them.
    Contrast SED (eleven independent constants, all consistent) and CAM++ (groups == channels, which
    is arithmetically impossible under the alternative) -- those are real cross-checks.

CONSEQUENCE FOR THIS CODE: the implementation is SHAPE-faithful and OPERATION-inferred. Each stage is
built as a conv and then `F.interpolate` forces the width to the tabulated value. That is honest about
what is known: the widths are real, the resampling that achieves them is ours.

ALSO INFERRED:
  * the missing 8->4 (encoder) and 4->8 (decoder) transitions -- mirror images of each other, so
    treated as one missed table pair.
  * skip connections. Not in the tables; the slot[k]/slot[k+10] pairing in the two loop clusters of
    the main forward is what a forward/transposed pair looks like. Switchable via skips=False.
  * frame-synchronous operation (the time axis untouched). Consistent with the 200 ms buffers and the
    5-frame crossfade, but not stated by the tables.

NOT INCLUDED: Zoom's trained weights.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from . import recovered as R


class AuxHead(nn.Module):
    """One of the three auxiliary classifier heads (sub_1800E1CB0 / E21F0 / E27C0), read line by line.

    Emits ONE probability every `stride` frames, not one per frame -- 100 ms at Zoom's hop, i.e. a
    short-term event decision rather than a per-frame gate. The temporal feature is a moving mean plus
    an UNBIASED variance (divided by n-1); the /9 is deliberate in the original, not a rounding.
    """

    def __init__(self, in_ch, width=R.AUX_HEAD_WIDTH, hist=R.AUX_HEAD_HISTORY,
                 stride=R.AUX_HEAD_STRIDE):
        super().__init__()
        self.hist, self.stride = hist, stride
        self.l1 = nn.Conv1d(in_ch, width, 3, padding=1)          # kernel slot 17
        self.l2 = nn.Conv1d(width, width, hist)                  # slot 18, over the history window
        self.out = nn.Linear(width * 2, 1)                       # slot 17 with K==1 => dense

    def forward(self, x):                                        # x: (B, C, T)
        h = torch.relu(self.l1(x))
        h = torch.relu(self.l2(F.pad(h, (self.hist - 1, 0))))
        m = F.avg_pool1d(F.pad(h, (self.hist - 1, 0)), self.hist, 1)
        sq = F.avg_pool1d(F.pad(h * h, (self.hist - 1, 0)), self.hist, 1)
        var = (sq - m * m).clamp_min(0) * (self.hist / max(self.hist - 1, 1))    # the /9
        p = torch.sigmoid(self.out(torch.cat([m, var], 1).transpose(1, 2)))
        return p.squeeze(-1)                                     # (B, T)


def _norm(ch):
    """GroupNorm over channels. Safe at T==1, which GroupNorm's batch check is not."""
    return nn.GroupNorm(1, ch) if ch > 1 else nn.Identity()


class DenoiseNet(nn.Module):
    """Frequency-axis conv encoder-decoder producing a 257-bin mask, frame-synchronous.

    Input  (B, T, 257) log-power  ->  treated as (B*T, 1, 257): each frame is one 1-D signal over
    frequency. Output (B, T, 257) mask in [0, mask_max].

    Args:
        skips:     concatenative skips between matching encoder/decoder stages (INFERRED)
        aux_heads: build the three recovered heads; their per-frame probabilities are returned so they
                   can carry an auxiliary loss. They do not gate the mask.
        mask_max:  1.0 = suppression only. >1 lets the model restore level, which Zoom does elsewhere
                   in the chain (extraGain / AdaptiveGain in the capture telemetry).
    """

    # (freq_in, freq_out, ch_out, kernel, stride)  -- rows 1..7 of LAYER_TABLES, plus the inferred 8->4
    ENC = [(257, 128, 8, 5, 2), (128, 64, 16, 5, 2), (64, 32, 32, 5, 2),
           (32, 16, 64, 5, 2), (16, 8, 64, 5, 2), (8, 8, 64, 1, 1),
           (8, 4, 64, 1, 1),                                     # INFERRED, mirror of 4->8
           (4, 1, 128, 5, 4)]
    # (freq_in, freq_out, ch_out, kernel) -- rows 10..21, plus the inferred 4->8
    DEC = [(1, 4, 64, 3), (4, 8, 64, 1),                          # 4->8 INFERRED
           (8, 8, 64, 1), (8, 16, 32, 3), (16, 16, 32, 1), (16, 32, 32, 3), (32, 32, 32, 1),
           (32, 64, 16, 3), (64, 64, 32, 1), (64, 128, 16, 3), (128, 128, 8, 1),
           (128, 258, 8, 3), (258, 257, 1, 1)]

    def __init__(self, skips=True, aux_heads=True, mask_max=1.0):
        super().__init__()
        self.skips = skips
        self.mask_max = float(mask_max)

        self.enc, self.enc_n, self.enc_len = nn.ModuleList(), nn.ModuleList(), []
        cin = 1
        for fin, fout, ch, k, s in self.ENC:
            self.enc.append(nn.Conv1d(cin, ch, k, stride=s, padding=k // 2))
            self.enc_n.append(_norm(ch))
            self.enc_len.append((fin, fout, ch))
            cin = ch

        # bottleneck: rows 8 and 9, both kernel 1
        self.bott = nn.Sequential(nn.Conv1d(cin, cin, 1), nn.GELU(), nn.Conv1d(cin, cin, 1))

        self.dec, self.dec_n, self.dec_len = nn.ModuleList(), nn.ModuleList(), []
        # Encoder channel counts keyed by output frequency length, for skip matching. The bottleneck's
        # own length is excluded: the decoder's first layer already consumes the bottleneck directly,
        # so concatenating it to itself would double-count. Built here and used verbatim in forward()
        # so the two cannot disagree -- they did, and that is what the channel-count crash was.
        bott_len = self.enc_len[-1][1]
        self.skip_ch = {fout: ch for _, fout, ch in self.enc_len if fout != bott_len}
        for fin, fout, ch, k in self.DEC:
            extra = self.skip_ch.get(fin, 0) if skips else 0
            self.dec.append(nn.Conv1d(cin + extra, ch, k, padding=k // 2))
            self.dec_n.append(_norm(ch))
            self.dec_len.append((fin, fout, ch))
            cin = ch

        self.heads = nn.ModuleList([AuxHead(self.ENC[1][2]) for _ in range(3)]) if aux_heads else None

    def forward(self, logp):
        B, T, Fb = logp.shape
        x = logp.reshape(B * T, 1, Fb)                            # each frame is a 1-D freq signal
        skips = {}
        h = x
        for conv, norm, (fin, fout, ch) in zip(self.enc, self.enc_n, self.enc_len):
            h = F.gelu(norm(conv(h)))
            if h.shape[-1] != fout:                               # stride arithmetic vs the table
                h = F.interpolate(h, size=fout, mode="linear", align_corners=False)
            skips[fout] = h

        aux = None
        if self.heads is not None:
            # first 16-channel encoder stage, pooled over frequency -> (B, C, T) for the heads
            a = skips[self.ENC[1][1]].mean(-1).reshape(B, T, -1).transpose(1, 2)
            aux = [hd(a) for hd in self.heads]

        h = self.bott(h) + h

        last = len(self.dec) - 1
        for i, (conv, norm, (fin, fout, ch)) in enumerate(zip(self.dec, self.dec_n, self.dec_len)):
            if h.shape[-1] != fin:
                h = F.interpolate(h, size=fin, mode="linear", align_corners=False)
            if self.skips and fin in self.skip_ch and fin in skips:
                h = torch.cat([h, skips[fin]], 1)
            h = conv(h)
            if i != last:
                h = F.gelu(norm(h))
            if h.shape[-1] != fout:
                h = F.interpolate(h, size=fout, mode="linear", align_corners=False)

        mask = torch.sigmoid(h).reshape(B, T, Fb) * self.mask_max
        return mask, aux

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    @staticmethod
    def provenance():
        return {
            "confidence": ["MEDIUM-HIGH -- the operator semantics and the precision boundary are "
                           "now read; only the per-slot widths are not. Was MEDIUM."],
            "read": ["257-bin in / 1x257 mask out",
                     "both width ladders, layer by layer in table order",
                     "the layer-type partition from cols[4..7]",
                     "three aux heads incl. the /9 unbiased variance and 100 ms output rate",
                     "the full 40-slot SCALAR kernel map (was 23, and slot 22 was wrong -- the "
                     "function recorded there is slot 29); see recovered.KERNEL_SLOTS_SCALAR",
                     "which of the three ISA installers is scalar (1800FB5A0), read from the "
                     "caller's branch structure -- so the kernel read earlier was the right variant",
                     "THE CONNECTING OPERATION: a quantised dense matmul. 2-way-unrolled int16 dot "
                     "product with weights stored output-major and two inputs interleaved, then "
                     "acc = (int)((uint64)(mult_q31*acc + bias_i64) >> 31) >> shift, plus a "
                     "zero-point, clamped with a low bound of -4095 in ALL eight kernels read",
                     "THE ACTIVATION IS A TABLE LOOKUP: out = *(int16*)(lut + 2*y + 8206), and the "
                     "byte offset 8206 = 2*4103 is IDENTICAL in all eight kernels -- one shared "
                     "activation LUT for the whole network. There is no closed-form activation, "
                     "which is why none was ever found",
                     "int16 storage throughout the network core -- NOT the uint8 scheme this file "
                     "previously attributed to it",
                     "the precision boundary: sub_1800C9030 (slots 31-36, SIX copies of one FLOAT "
                     "function) is used at stages 2-4 and 9-11, symmetrically around the int16 "
                     "stages 5-8. So the pipeline is float pre -> int16 net -> float post, and those "
                     "six identical slots ARE the quantisation boundary",
                     "slot 11 (sub_1800EBE60) is the same function in the scalar and AVX installers, "
                     "i.e. the binary says it is not worth vectorising"],
            "not_established": ["the per-slot in/out widths -- which table row belongs to which slot",
                                "which axis the widths live on (time is ruled out, frequency is not "
                                "proven)",
                                "the clamp HIGH bound was read directly only in slot 3 (4096); the "
                                "other seven kernels' high bound was not re-read"],
            "resolved_since_audit": ["the audit's open question was 'what OPERATION connects "
                                     "consecutive width entries'. It is a MATMUL, which is exactly "
                                     "why the conv output-size formula failed on 13/14 tables and why "
                                     "the ladder is an exact halving of an odd 257: successive "
                                     "projections, not strided convolutions",
                                     "the malloc(4*128*8) 'cross-check' is still non-discriminating, "
                                     "but it no longer matters -- the operation is read directly"],
            "inferred": ["missing 8->4 / 4->8 mirror pair", "skip connections",
                         "the resampling that achieves the tabulated widths",
                         "frame-synchronous (time axis untouched)"],
            "excluded": ["Zoom's trained weights"],
        }
