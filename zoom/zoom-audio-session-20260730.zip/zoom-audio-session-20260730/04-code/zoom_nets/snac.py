"""Model B -- SNAC, Zoom's neural speech codec, rebuilt in PyTorch from the recovered architecture.

ATTRIBUTION. SNAC is Zoom's own. The evidence is RTTI (`MultiResolutionRVQ`, `VectorQuantize`,
`CosineSimCodebook`, `SnacInferenceEncoderAVX`, `webrtc::SnacEncoder`) plus the `SNAC_*` configuration
constants. The LAYER NAMES on their own (enc_gru*, dec_glu*, cond_net_pembed, ...) are shared across
the whole LPCNet-descended family and are NOT sufficient to attribute lineage -- calling them Opus
DRED+FARGAN on name similarity was a mistake, corrected in NOTES.md 19.22. Nothing here claims a
lineage; it reproduces the structure that was read.

WHAT IS FAITHFUL (read):
  * encoder  : 5 convs + dense + zdense + 5 GRUs
  * quantizer: multi-resolution residual VQ, cosine-similarity codebooks
  * cond net : pembed + fdense1 + fconv1 + fdense2
  * decoder  : dense + 5 GLUs + 5 GRUs + 5 convs + output, with dec_gru_init / dec_hidden_init
               (learned initial recurrent state, not zeros)
  * resample : dense_downsampler, dense_if_upsampler_1/2, dense_final_upsampler
  * gains    : gdense1, gdense2
  * int8 affine quantisation with per-tensor _scale and _subias; block-sparse GRU input matrices
    marked by _weights_idx
  * the assert `DecoderLayer::forward: input time must equal num_quantizers`, which is why the decoder
    consumes one time step per quantiser stage

DIMENSIONS ARE NOW READ, not assumed. An earlier version of this docstring said "the binary gives layer
names and kinds, not dimensions" -- that was wrong, and it was wrong because I had not looked. The
descriptor table stores each parameter's SIZE, and the sizes determine the widths:

      bias size / 4                  = output width          (one float per output)
      weights size / out / itemsize  = input width           (1 byte int8, 4 bytes float)

67 of 71 layers solve exactly. The four that do not are the sparse GRU inputs, where weight bytes are
less than out x in BY CONSTRUCTION -- so even those failures are informative: they identify exactly
which matrices carry `_weights_idx`. Full table in recovered.SNAC_DIMS.

    encoder    dense1 40->64 (float) | GRU hidden 64 | conv out 96 | zdense -> LATENT 24
               GRU input widths 64, 224, 384, 544, 704 -- growing by 160 per stage,
               and 160 = previous GRU out 64 + conv out 96, i.e. DENSELY CONNECTED
    gain path  gdense1 864->128, gdense2 128->24        (a second 24-d output)
    decoder    dense1 23->96 (float) | GLU 96->96 | GRU hidden 96 | conv out 32
               dec_output 736->80 -- 80 samples is 5 ms at 16 kHz, i.e. a SUBFRAME
               dec_gru_init 128->480, and 480 = 5 x 96: one layer produces the initial state
               for all five decoder GRUs at once
    cond net   pembed 224->12 | fdense1 32->64 (float) | fconv1 192->128 | fdense2 128->320
    sig net    fwc0_conv 328->192 | GRU hiddens 160, 128, 128
               sig_dense_out 128->40 | gain_dense_out 192->4
    resample   downsampler 288->64 | if_upsampler_1 88->64 | if_upsampler_2 64->64

BITSTREAM PARAMETERS -- NOW READ (2026-07-30). The engine prints its own config, and the seven
labelled fields are backed by two static profiles that turn out to be IDENTICAL:

    payload type            121        (matches the "AI codec 121" id used by the control plane)
    frame                   20 ms      (NUM_20MS_PER_FRM = 1)
    bits per code           10         => codebook of 1024 entries (2^10)
    codes per frame         2          <- NOT four or five stages; two
    codebook pool           12         available codebooks, of which each frame picks 2
    send frequency          50 /s      (consistent with the 20 ms frame: 1000/20)
    repeat times            1          => every frame is transmitted TWICE

    bits/frame = 10 * 2 = 20      bytes/frame = ceil(20/8) = 3
    rate       = 20 bit / 20 ms   = 1 kbps        on the wire (with the repeat) = 2 kbps

The formula is the engine's own: it computes `bits = codebook_size * codes_per_frame` and
`bytes = (bits + 7) / 8`, which is what establishes that CODEBOOK_SIZE is a BIT WIDTH, not an entry
count. The repeat schedule is likewise the engine's: `send_freq * (repeat_time + 1) - 1` packet slots.

CORRECTION: an earlier version of this file, and the model table in train/README.md, said
"40 bit/frame @ 4 stages". That number was never read -- it was log2(codebook=1024) x n_stages=4, i.e.
the product of TWO of this file's own defaults. The codebook guess (1024) happened to be right; the
stage count was wrong (2, not 4), so the bitrate was wrong by exactly 2x.

STILL OURS: kernel sizes (the table gives widths, not receptive fields) and the per-stage strides.

NOT INCLUDED: Zoom's trained weights or codebooks.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------------------------------------------------------------- bitstream, read from the engine
SNAC_PAYLOAD_TYPE = 121          # also the control-plane id for the "AI codec" tier
SNAC_FRAME_MS = 20               # NUM_20MS_PER_FRM = 1
SNAC_CODE_BITS = 10              # bits per code
SNAC_CODEBOOK_ENTRIES = 1 << SNAC_CODE_BITS      # = 1024
SNAC_CODES_PER_FRAME = 2         # <- two, not four
SNAC_CODEBOOK_POOL = 12          # codebooks available; each frame picks SNAC_CODES_PER_FRAME of them
SNAC_SEND_FREQ = 50              # frames/s
SNAC_REPEAT_TIMES = 1            # => each frame sent twice

SNAC_BITS_PER_FRAME = SNAC_CODE_BITS * SNAC_CODES_PER_FRAME          # 20
SNAC_BYTES_PER_FRAME = (SNAC_BITS_PER_FRAME + 7) // 8                # 3
SNAC_BITRATE_BPS = SNAC_BITS_PER_FRAME * SNAC_SEND_FREQ              # 1000
SNAC_WIRE_BITRATE_BPS = SNAC_BITRATE_BPS * (SNAC_REPEAT_TIMES + 1)   # 2000
SNAC_PACKET_SLOTS = SNAC_SEND_FREQ * (SNAC_REPEAT_TIMES + 1) - 1     # 99, the engine's own formula


# --------------------------------------------------------------------------- quantiser
class CosineSimCodebook(nn.Module):
    """Codebook lookup by cosine similarity rather than Euclidean distance (RTTI: CosineSimCodebook).

    Why it matters: with L2-normalised codes and inputs the assignment depends on direction only, so
    the codebook stops competing with the encoder over signal level. That makes level a separate
    (cheap) channel -- which is consistent with SNAC carrying explicit gain layers (gdense1/gdense2).
    """

    def __init__(self, dim, size, decay=0.99, eps=1e-5):
        super().__init__()
        self.size = size
        self.decay = decay
        self.eps = eps
        emb = F.normalize(torch.randn(size, dim), dim=-1)
        self.register_buffer("embed", emb)
        self.register_buffer("cluster_size", torch.zeros(size))
        self.register_buffer("embed_avg", emb.clone())

    def forward(self, z):                      # z: (B, T, D)
        zn = F.normalize(z, dim=-1)
        sim = zn @ F.normalize(self.embed, dim=-1).t()        # cosine similarity
        idx = sim.argmax(-1)
        q = F.normalize(self.embed, dim=-1)[idx]
        if self.training:
            with torch.no_grad():
                oh = F.one_hot(idx, self.size).type(zn.dtype)     # (B,T,size)
                n = oh.sum((0, 1))
                s = oh.transpose(1, 2).reshape(self.size, -1) @ zn.reshape(-1, zn.shape[-1]) \
                    if False else torch.einsum("btk,btd->kd", oh, zn)
                self.cluster_size.mul_(self.decay).add_(n, alpha=1 - self.decay)
                self.embed_avg.mul_(self.decay).add_(s, alpha=1 - self.decay)
                denom = self.cluster_size.clamp_min(self.eps).unsqueeze(-1)
                self.embed.copy_(F.normalize(self.embed_avg / denom, dim=-1))
        # straight-through: gradients flow to the encoder, commitment loss keeps it near the codes
        q_st = zn + (q - zn).detach()
        commit = F.mse_loss(zn, q.detach())
        return q_st, idx, commit


class VectorQuantize(nn.Module):
    """One RVQ stage: project in, quantise, project out (RTTI: VectorQuantize, with project_in/out)."""

    def __init__(self, dim, code_dim, size):
        super().__init__()
        self.project_in = nn.Linear(dim, code_dim)
        self.project_out = nn.Linear(code_dim, dim)
        self.codebook = CosineSimCodebook(code_dim, size)

    def forward(self, x):
        z = self.project_in(x)
        q, idx, commit = self.codebook(z)
        return self.project_out(q), idx, commit


class MultiResolutionRVQ(nn.Module):
    """Residual VQ across stages, each stage optionally at its own temporal resolution.

    "Multi-resolution" is read from the class name; the per-stage strides are OURS. The design intent
    is legible from the rest of the codec though: coarse stages carry long-term structure, fine stages
    add detail, and the bitstream can be TRUNCATED to fewer stages for graceful degradation -- which
    is what SNAC_MAX_CODEBOOK_NUM plus per-frame code counts imply.
    """

    def __init__(self, dim, code_dim=8, size=1024, n_stages=SNAC_CODES_PER_FRAME,
                 strides=None):
        super().__init__()
        self.strides = strides or [1] * n_stages          # OURS
        self.stages = nn.ModuleList(
            [VectorQuantize(dim, code_dim, size) for _ in range(n_stages)])

    def forward(self, x, n_active=None):       # x: (B, T, D)
        n = n_active or len(self.stages)
        residual = x
        out = torch.zeros_like(x)
        codes, commits = [], []
        for i, (vq, s) in enumerate(zip(self.stages, self.strides)):
            if i >= n:
                break
            r = residual
            if s > 1:                                     # coarse stage: pool, quantise, expand
                r = F.avg_pool1d(r.transpose(1, 2), s, s).transpose(1, 2)
            q, idx, c = vq(r)
            if s > 1:
                q = F.interpolate(q.transpose(1, 2), size=x.shape[1],
                                  mode="nearest").transpose(1, 2)
            out = out + q
            residual = residual - q
            codes.append(idx)
            commits.append(c)
        return out, codes, torch.stack(commits).mean()


# --------------------------------------------------------------------------- blocks
class GLU1d(nn.Module):
    """dec_glu* -- gated linear unit along time. Halves nothing; gate and value share the input."""

    def __init__(self, ch, k=3):
        super().__init__()
        self.value = nn.Conv1d(ch, ch, k, padding=k // 2)
        self.gate = nn.Conv1d(ch, ch, k, padding=k // 2)

    def forward(self, x):
        return self.value(x) * torch.sigmoid(self.gate(x))


class SparseGRU(nn.Module):
    """A GRU whose INPUT matrix is block-sparse.

    Read: every `*_gru*_input` tensor carries a `_weights_idx` index table while the matching
    `*_gru*_recurrent` does not. So the sparsity is on the input projection only. Training here is
    dense; `prune_input(density)` applies a block mask so the sparsity pattern can be learned and then
    frozen, which is what makes the int8 block-sparse kernels usable at inference.
    """

    def __init__(self, in_dim, hid, block=16):
        super().__init__()
        self.gru = nn.GRU(in_dim, hid, batch_first=True)
        self.block = block
        self.register_buffer("in_mask", torch.ones(3 * hid, in_dim))

    def prune_input(self, density=0.25):
        w = self.gru.weight_ih_l0.detach().abs()
        o, i = w.shape
        bo = max(1, o // self.block)
        bi = max(1, i // self.block)
        pooled = F.adaptive_avg_pool2d(w.unsqueeze(0).unsqueeze(0), (bo, bi))[0, 0]
        k = max(1, int(density * pooled.numel()))
        thr = pooled.flatten().topk(k).values.min()
        m = (pooled >= thr).float()
        self.in_mask.copy_(F.interpolate(m.unsqueeze(0).unsqueeze(0), size=(o, i),
                                         mode="nearest")[0, 0])

    def forward(self, x, h=None):
        self.gru.weight_ih_l0.data.mul_(self.in_mask)
        return self.gru(x, h)


# --------------------------------------------------------------------------- codec
class SnacEncoder(nn.Module):
    """enc_conv1..5 -> enc_dense1 -> enc_zdense -> enc_gru1..5. Widths are OURS."""

    def __init__(self, in_dim=257, width=128, latent=64, n_gru=5):
        super().__init__()
        self.convs = nn.ModuleList([
            nn.Conv1d(in_dim if i == 0 else width, width, 5, stride=2 if i < 2 else 1, padding=2)
            for i in range(5)])
        self.dense1 = nn.Linear(width, width)          # float in the original (not int8)
        self.grus = nn.ModuleList([SparseGRU(width, width) for _ in range(n_gru)])
        self.zdense = nn.Linear(width, latent)

    def forward(self, x):                      # x: (B, T, in_dim)
        h = x.transpose(1, 2)
        for c in self.convs:
            h = F.gelu(c(h))
        h = h.transpose(1, 2)
        h = F.gelu(self.dense1(h))
        for g in self.grus:
            y, _ = g(h)
            h = h + y                          # residual: 5 stacked GRUs need it to train
        return self.zdense(h)


class CondNet(nn.Module):
    """cond_net_pembed + fdense1 + fconv1 + fdense2 -> the decoder's conditioning signal.

    `pembed` is a learned embedding table. The binary has one weak `(PITCH)` hit near it, so pitch is
    a plausible but UNCONFIRMED reading -- it is exposed as a generic integer side-channel here.
    """

    def __init__(self, latent=64, width=128, n_embed=256, embed_dim=32):
        super().__init__()
        self.pembed = nn.Embedding(n_embed, embed_dim)
        self.fdense1 = nn.Linear(latent + embed_dim, width)      # float in the original
        self.fconv1 = nn.Conv1d(width, width, 3, padding=1)
        self.fdense2 = nn.Linear(width, width)

    def forward(self, z, side=None):
        if side is None:
            side = torch.zeros(z.shape[0], z.shape[1], dtype=torch.long, device=z.device)
        h = torch.cat([z, self.pembed(side)], dim=-1)
        h = F.gelu(self.fdense1(h))
        h = F.gelu(self.fconv1(h.transpose(1, 2))).transpose(1, 2)
        return self.fdense2(h)


class SnacDecoder(nn.Module):
    """dec_dense1 -> dec_glu1..5 -> dec_gru1..5 (learned init state) -> dec_conv1..5 -> dec_output.

    `dec_gru_init` / `dec_hidden_init` are read as LEARNED initial recurrent state -- a real detail:
    a codec decoder is restarted on every packet boundary, and starting from a learned state instead
    of zeros removes the transient that would otherwise be audible at each restart.
    """

    def __init__(self, cond=128, width=128, out_dim=257, n_gru=5, up=4):
        super().__init__()
        self.dense1 = nn.Linear(cond, width)
        self.glus = nn.ModuleList([GLU1d(width) for _ in range(5)])
        self.grus = nn.ModuleList([SparseGRU(width, width) for _ in range(n_gru)])
        self.h0 = nn.Parameter(torch.zeros(n_gru, 1, width))     # dec_gru_init / dec_hidden_init
        self.convs = nn.ModuleList([nn.Conv1d(width, width, 3, padding=1) for _ in range(5)])
        self.up = up
        self.out = nn.Conv1d(width, out_dim, 1)                  # dec_output
        self.gdense1 = nn.Linear(width, 1)                       # gdense1/gdense2: explicit gain path
        self.gdense2 = nn.Linear(width, 1)

    def forward(self, c):
        h = F.gelu(self.dense1(c))
        x = h.transpose(1, 2)
        for g in self.glus:
            x = x + g(x)
        h = x.transpose(1, 2)
        for i, g in enumerate(self.grus):
            y, _ = g(h, self.h0[i:i + 1].expand(-1, h.shape[0], -1).contiguous())
            h = h + y
        gain = torch.sigmoid(self.gdense2(F.gelu(self.gdense1(h).expand_as(h[..., :1]) * 0 + h)))
        x = h.transpose(1, 2)
        for c_ in self.convs:
            x = F.gelu(c_(x))
        if self.up > 1:
            x = F.interpolate(x, scale_factor=self.up, mode="linear", align_corners=False)
        y = self.out(x).transpose(1, 2)
        g = F.interpolate(gain.transpose(1, 2), size=y.shape[1],
                          mode="linear", align_corners=False).transpose(1, 2)
        return y * (0.5 + g)          # explicit gain path, mirroring gdense1/gdense2


class Resamplers(nn.Module):
    """dense_downsampler / dense_if_upsampler_1/2 / dense_final_upsampler -- LEARNED resampling.

    Worth noting as a design choice: the codec does not use a fixed polyphase filter, it learns the
    rate conversion. That costs parameters but lets the network shape the aliasing it can tolerate.
    """

    def __init__(self, width=128, factor=2):
        super().__init__()
        self.down = nn.Conv1d(width, width, 2 * factor, stride=factor, padding=factor // 2)
        self.up1 = nn.ConvTranspose1d(width, width, 2 * factor, stride=factor, padding=factor // 2)
        self.up2 = nn.ConvTranspose1d(width, width, 2 * factor, stride=factor, padding=factor // 2)
        self.final = nn.ConvTranspose1d(width, width, 2 * factor, stride=factor, padding=factor // 2)


class Snac(nn.Module):
    """Full codec: encoder -> multi-resolution RVQ -> cond net -> decoder.

    Operates on log-magnitude spectra (B, T, 257) by default so it can be trained and evaluated with
    the same framing as ns_core.hpp and the denoise net. `n_active` truncates the quantiser stages at
    inference, which is the graceful-degradation path the recovered config constants imply.
    """

    def __init__(self, dim=257, width=128, latent=64, code_dim=8,
                 codebook=SNAC_CODEBOOK_ENTRIES, n_stages=SNAC_CODES_PER_FRAME):
        super().__init__()
        self.encoder = SnacEncoder(dim, width, latent)
        self.rvq = MultiResolutionRVQ(latent, code_dim, codebook, n_stages,
                                      strides=[4, 2, 1, 1][:n_stages])     # OURS
        self.cond = CondNet(latent, width)
        self.decoder = SnacDecoder(width, width, dim, up=4)
        self.n_stages = n_stages

    def forward(self, x, side=None, n_active=None):
        z = self.encoder(x)
        q, codes, commit = self.rvq(z, n_active)
        c = self.cond(q, side)
        y = self.decoder(c)
        if y.shape[1] != x.shape[1]:
            y = F.interpolate(y.transpose(1, 2), size=x.shape[1],
                              mode="linear", align_corners=False).transpose(1, 2)
        return y, codes, commit

    @classmethod
    def from_recovered(cls, dim=257, n_stages=SNAC_CODES_PER_FRAME,
                       codebook=SNAC_CODEBOOK_ENTRIES):
        """Build with the widths read out of the descriptor table (recovered.SNAC_DIMS).

        Encoder GRU hidden 64, decoder GRU hidden 96, latent 24 -- all read. Kernel sizes, codebook
        size and stage count are still ours, because the table gives widths and not receptive fields.
        """
        from . import recovered as R
        d = R.SNAC_DERIVED
        m = cls(dim=dim, width=d["dec_gru_hidden"], latent=d["latent_dim"],
                code_dim=8, codebook=codebook, n_stages=n_stages)
        m.encoder = SnacEncoder(dim, d["enc_gru_hidden"], d["latent_dim"])
        m.cond = CondNet(d["latent_dim"], d["dec_gru_hidden"])
        m.decoder = SnacDecoder(d["dec_gru_hidden"], d["dec_gru_hidden"], dim, up=4)
        m.rvq = MultiResolutionRVQ(d["latent_dim"], 8, codebook, n_stages,
                                   strides=[4, 2, 1, 1][:n_stages])
        m.recovered_widths = True
        return m

    def bits_per_frame(self):
        import math
        return self.n_stages * math.log2(self.rvq.stages[0].codebook.size)

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    @staticmethod
    def provenance():
        return {"faithful": ["layer inventory and kinds", "cosine-similarity codebook",
                             "multi-resolution residual VQ", "learned decoder init state",
                             "learned resamplers", "explicit gain layers",
                             "block-sparse GRU input matrices", "int8 affine quant scheme"],
                "ours": ["all widths / kernel sizes / codebook size / number of stages",
                         "per-stage strides", "frame geometry"],
                "excluded": ["Zoom's trained weights and codebooks"]}
