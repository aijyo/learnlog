"""Model D/E -- CAM++ speaker embedding and the OSD (overlapped-speech) variant, in PyTorch.

CONFIDENCE: HIGH. Every structural number below is READ out of viperex.dll, and most of them are
confirmed two or three independent ways. An earlier version of this file marked the D-TDNN depth,
growth rate, CAM bottleneck, embedding dimension and the whole OSD head as "ours / published
defaults". All five of those are now read. The reason they were missing was not that the binary
withholds them -- it was that the scalar reference implementations had not been read yet.

HOW IT WAS READ (the route matters, because it generalises):
  1. RTTI gives seven classes:  DTDNN_CAMDense{,_C,_SSE2,_AVX} and DTDNN_CAMDense_OSD{,_C,_SSE2}.
     The `_C` variants are scalar reference code -- 1550 and 1835 bytes, both trivially readable.
  2. DTDNN_CAMDense_C::vt[0] (sub_180205B20) is the whole backbone as a straight-line sequence of
     stage calls with LITERAL arguments: sub_180203970(this, 12, 128, ..), (this, 24, 112, ..),
     (this, 16, 152, ..).  That is num_layers = [12, 24, 16] and the three block input widths.
  3. Every scratch buffer is resized to `bytes_per_frame * n_frames`, so the widths fall out:
     128, 224, 112, 304, 152, 280, 140 floats/frame. Differencing gives growth = (224-128)/12
     = (304-112)/24 = (280-152)/16 = 8, three times over.
  4. The stage config structs are static 6-int records {in, out, kernel, stride, pad, dilation}.
     Reading them gives the kernels and dilations that buffer sizes cannot show.
  5. The 30 KB init (sub_1801FC100) is 1066 push_backs into the object's 29 weight-view vectors.
     Counting pushes per vector validates the whole reading at once: block b contributes
     {1 bottleneck weight, 1 cfg, 8 BN weights, 2 BN cfgs, 5 CAM weights, 3 CAM cfgs} per layer, so
     the counts must be 12/12/96/24/60/36, 24/24/192/48/120/72, 16/16/128/32/80/48.
     All fourteen match exactly. Fourteen independent counts do not agree by accident.

READ -- CAM++ backbone:
    filterbank                80 bands, 3 s window = 48000 samples, hop 160 -> 298 frames
                              298 is READ (the FCM stores it; the other packaging takes 298 too).
                              The formula in the code is (48000 - frame) / hop + 1, which pins the
                              frame length at 480 = 30 ms. An earlier version of this file said
                              "frame 320 -> 299 frames" -- the 320 was an assumption and it is
                              inconsistent with the stored 298.
    FCM out                   320 floats/frame = 10 bands x 32 ch  (malloc(1280 * n_frames))
    stem TDNN                 {320, 128, k5, s2, p2}   <- stride 2, so the backbone runs at HALF
                              frame rate; the code stores both lengths: n and (n-1)/2+1
    block 1                   12 layers, in 128 -> 224      kernel 3, dilation 1
    transition 1              {224, 112, k1}                (halves)
    block 2                   24 layers, in 112 -> 304      kernel 3, dilation 2
    transition 2              {304, 152, k1}
    block 3                   16 layers, in 152 -> 280      kernel 3, dilation 2
    transition 3              {280, 140, k1}
    final BN + ReLU           140
    stats pooling             140 -> 280   (mean + std; buffer 0x460 = 280 floats, NOT per-frame)
    embedding                 {280, 512, k1}                <- 512. See the note below: 792 is
                                                               NOT a wrong reading, it is a
                                                               DIFFERENT artifact's output
    growth rate               8      bottleneck width 32
  Note both are 4x smaller than published CAM++ (growth 32, bn 128). Zoom scaled the whole thing down.

READ -- the D-TDNN layer (sub_180204260) and CAM (sub_180204550):
    x (C ch) -> BN+ReLU -> Conv1x1 C->32 -> BN+ReLU
             -> CAM:  main    = Conv1d(32 -> 8, k=3, dilation=d, padding=d)
                      context = segment_mean(100 frames) + utterance global mean, over the 32-ch input
                      mask    = sigmoid( Linear(16->8)( ReLU( Linear(32->16)(context) ) ) )
                      out     = main * mask
             -> concat(x, out) -> (C+8) ch
  The 100-frame segment length is the literal `v20 == 100 * (v20 / 100)`. The per-layer weight and
  config strides (`+5` and `+3` per layer) match {conv_w, lin1_w, lin1_b, lin2_w, lin2_b} and
  {conv_cfg, lin1_cfg, lin2_cfg} exactly, which is what confirms the CAM shape.

READ -- OSD (DTDNN_CAMDense_OSD, the width-12 sibling):
    FCM out      120 floats/frame = 10 x 12
    stem         {120, 128, k5, s2, p2}       <- same stem shape as CAM++, narrower input
    blocks       [6, 8] layers, growth 6      (128+6*6 = 164; 82+8*6 = 130, both read as configs)
    transitions  {164, 82}, {130, 65}
    head         four 1x1 convs at width 128 ending in {128, 2}  -> TWO classes
    pooling      buffer 0x410 = 2 x 130 floats, and the head buffers are a constant 0x200 = 128
                 floats rather than K * n_frames -- so the head runs on a POOLED vector. OSD is a
                 segment-level 2-class decision, not the per-frame posterior assumed before.

STILL OURS (small, and named honestly):
  * the FCM's tensor-to-convolution mapping. The STRUCTURE and every STRIDE are now read from the
    template arguments (see the FCM class docstring), and so is the frame count of 298. What is not
    reconciled is which of the 72 weight tensors belongs to which convolution: the ladder shows CxC
    entries but the templates report groups == channels everywhere in the res blocks.
  * the filterbank warping (80 bands is read, mel-vs-linear is not).
  * OSD head wiring past "four 1x1 convs at 128 -> 2" (which of 130/65 feeds it is ambiguous).

NOT INCLUDED: Zoom's trained weights. Speaker embedding models are identity-bearing -- see the ethics
note in voice/CLAUDE.md. Train on voices you own or have explicit consent for; do not use this to
impersonate anyone or to defeat voiceprint authentication.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------------------------------------------------------------- read from the binary
CAMPP_WINDOW_SAMPLES = 48000        # 3 s @ 16 kHz
CAMPP_FRAMES = 298                  # READ -- the FCM stores 298 as its frame count, and the same
#   model's other packaging takes [1,1,80,298]. Two independent sources.
CAMPP_HOP = 160                     # 10 ms
CAMPP_FRAME = 480                   # DERIVED, not read: 480 is the only frame length for which
#   (48000 - frame) / 160 + 1 == 298. An earlier version of this file had 320 (20 ms), which yields
#   299 -- that was an assumption and it is inconsistent with the 298 the binary actually stores.
#   30 ms / 10 ms is also the more usual analysis framing for a speaker model than 20 ms / 10 ms.
CAMPP_BANDS = 80                    # filterbank bands (frequency axis of the FCM input)
CAMPP_FCM_CH = 32                   # FCM channel count
CAMPP_FCM_FREQ_OUT = 10             # frequency after the FCM -> 10 * 32 = 320 flat
CAMPP_STEM = (128, 5, 2, 2)         # {out, kernel, stride, padding}
CAMPP_BLOCKS = (12, 24, 16)         # num_layers per dense block
CAMPP_DILATION = (1, 2, 2)          # per-block dilation of the CAM main conv
CAMPP_GROWTH = 8                    # channels added per dense layer
CAMPP_BN = 32                       # bottleneck width inside a dense layer
CAMPP_CAM_SEG = 100                 # CAM segment length, in frames
CAMPP_EMBED = 512                   # embedding dimension -- viperex's internal CAM++.
#   Do NOT reconcile this with the 792 that appears in the older notes and in
#   learnlog/zoom-audio-denoise-weaknet.html: that is a DIFFERENT artifact, an OpenVINO-packaged
#   model in the same client whose output really is [1,792,1,1]. Two models, two widths, both
#   correctly read. 512 here is confirmed twice independently: the config struct {280,512,k1} in
#   the backbone, and PVAD's 0x200 = 512-element enrollment buffer, which is a completely
#   separate code path.

OSD_FCM_CH = 12                     # the OSD variant's channel count -> 10 * 12 = 120 flat
OSD_BLOCKS = (6, 8)
OSD_GROWTH = 6
OSD_HEAD = 128                      # head width
OSD_CLASSES = 2                     # {not overlapped, overlapped}

# the FCM weight ladder, read from the blob pointer array (32-ch: 0x1837DDE60, 12-ch: 0x1837E1380).
# True marks a block that carries a depthwise 3x3; False is pointwise-only (a transition).
FCM_BLOCK_HAS_DW = (True, True, False, True, True, True, True, False, True, True, True)
FCM_PARAMS_32CH = 15468             # measured span of the width-32 blob array, in floats
FCM_PARAMS_12CH = 3168              # ditto for width 12


def n_frames(window=CAMPP_WINDOW_SAMPLES, frame=CAMPP_FRAME, hop=CAMPP_HOP):
    """The formula in the binary: (window - frame) / hop + 1.

    With the read frame count of 298 and hop 160 this gives back 298 only for frame = 480.
    Kept as a function so the relationship stays visible rather than hard-coded.
    """
    return (window - frame) // hop + 1


def n_frames_half(n=None):
    """The backbone rate. The stem has stride 2, and the code stores (n-1)/2 + 1 alongside n."""
    n = n_frames() if n is None else n
    return (n - 1) // 2 + 1


# ---------------------------------------------------------------- FCM
class BasicResBlockSc(nn.Module):
    """An FCM residual block, depthwise, over the (frequency, time) plane.

    READ from the template arguments. The stride-2 instances carry TWO convolutions:

        main      depthwise k3, stride (2, 1)      -- halves the frequency axis
        shortcut  depthwise k1, stride (2, 1)      -- subsamples the shortcut to match

    and the stride-1 instances are a separate template with an IDENTITY shortcut. That is exactly why
    the binary has two block templates instead of one with a flag: a strided block cannot add its input
    back unchanged, so it needs a projected shortcut, and paying for that projection when stride is 1
    would be waste.

    Note both convolutions are DEPTHWISE (groups == channels), including the shortcut -- so the
    shortcut is a per-channel strided subsample, not a channel mixer.
    """

    def __init__(self, ch, stride=1):
        super().__init__()
        self.stride = stride
        self.conv = nn.Conv2d(ch, ch, 3, stride=(stride, 1), padding=1, groups=ch, bias=False)
        self.bn1 = nn.BatchNorm2d(ch)
        self.pw = nn.Conv2d(ch, ch, 1)
        self.bn2 = nn.BatchNorm2d(ch)
        # Sc = shortcut projection, present only when the frequency axis is strided
        self.short = (nn.Conv2d(ch, ch, 1, stride=(stride, 1), groups=ch, bias=False)
                      if stride != 1 else None)

    def forward(self, x):
        h = F.relu(self.bn1(self.conv(x)))
        h = self.bn2(self.pw(h))
        s = x if self.short is None else self.short(x)
        return F.relu(h + s)


class FCM(nn.Module):
    """Front-end Convolution Module -- the structure is now READ, including where the strides sit.

    The constructor assigns vtables whose template arguments spell out the geometry, so the block
    order and every stride is explicit rather than inferred:

        Conv2d(1 -> 1,  k3, s1)                       stem, single channel
        Conv2d(1 -> 32, k1, s1)                       pointwise lift to 32
        BatchNorm(32)                                 at frequency 80
        BasicResBlockSc(32, stride 2)   freq 80 -> 40   <-- stride #1
        BasicResBlock  (32, stride 1)   freq 40 -> 40
        BasicResBlockSc(32, stride 2)   freq 40 -> 20   <-- stride #2
        BasicResBlock  (32, stride 1)   freq 20 -> 20
        Conv2d(32 -> 32, k3, s2, depthwise)  freq 20 -> 10   <-- stride #3
        Conv2d(32 -> 32, k1)
        BatchNorm(32)                                 at frequency 10
        flatten -> 10 x 32 = 320 per frame

    The `Sc` in the block name is a SHORTCUT PROJECTION: those blocks carry two convolutions, a
    depthwise k3 stride-2 main path and a depthwise k1 stride-2 shortcut, because a strided block
    cannot use an identity shortcut. The non-Sc blocks are stride 1 and do use identity. That is why
    the two exist as separate template instantiations.

    WHAT IS STILL NOT RECONCILED: the exact mapping between these convolutions and the 72-tensor
    weight ladder. The ladder shows per-block entries of 9C (a depthwise 3x3) and CxC, but the
    templates here report groups == channels on every res-block convolution, so the CxC entries do not
    line up with a plain pointwise. Structure and strides are read; the tensor-to-convolution
    assignment is not.
    """

    def __init__(self, ch=CAMPP_FCM_CH, bands=CAMPP_BANDS):
        super().__init__()
        self.stem_dw = nn.Conv2d(1, 1, 3, padding=1, bias=False)
        self.stem_pw = nn.Conv2d(1, ch, 1)
        self.stem_bn = nn.BatchNorm2d(ch)
        self.res1 = BasicResBlockSc(ch, stride=2)      # freq 80 -> 40   READ
        self.res2 = BasicResBlockSc(ch, stride=1)      # freq 40 -> 40   READ (identity shortcut)
        self.res3 = BasicResBlockSc(ch, stride=2)      # freq 40 -> 20   READ
        self.res4 = BasicResBlockSc(ch, stride=1)      # freq 20 -> 20   READ
        self.tail_dw = nn.Conv2d(ch, ch, 3, stride=(2, 1), padding=1, groups=ch, bias=False)
        self.tail_pw = nn.Conv2d(ch, ch, 1)            # freq 20 -> 10   READ
        self.out_bn = nn.BatchNorm2d(ch)
        self.out_dim = CAMPP_FCM_FREQ_OUT * ch

    def forward(self, x):                              # (B, 1, bands, T)
        h = self.stem_bn(self.stem_pw(self.stem_dw(x)))
        h = self.res4(self.res3(self.res2(self.res1(h))))
        h = self.out_bn(self.tail_pw(self.tail_dw(h)))
        h = F.relu(h)
        if h.shape[2] != CAMPP_FCM_FREQ_OUT:
            h = F.adaptive_avg_pool2d(h, (CAMPP_FCM_FREQ_OUT, h.shape[3]))
        B, C, Fq, T = h.shape
        return h.reshape(B, C * Fq, T)                 # (B, 10*C, T)


# ---------------------------------------------------------------- CAM
class CAM(nn.Module):
    """Context-Aware Masking, as read from sub_180204550.

    context = per-channel mean over 100-frame segments, PLUS the per-channel mean over the whole
    utterance. Two scales, added -- not one global mean, which is what the previous version had.

    Why two scales: the segment mean tracks "what is going on right now" (a passage of speech, a burst
    of noise) while the utterance mean carries the recording's overall character. A mask built from
    both can suppress a locally-unhelpful frame without losing the global reference.

    The mask is generated at the OUTPUT width (growth) through a 32 -> 16 -> 8 bottleneck and
    multiplies the main branch, which is the dilated conv's output.
    """

    def __init__(self, bn=CAMPP_BN, growth=CAMPP_GROWTH, seg=CAMPP_CAM_SEG):
        super().__init__()
        self.seg = seg
        self.fc1 = nn.Conv1d(bn, bn // 2, 1)
        self.fc2 = nn.Conv1d(bn // 2, growth, 1)

    def context(self, x):                                          # (B, bn, T)
        T = x.shape[-1]
        g = x.mean(-1, keepdim=True)                               # utterance mean
        if self.seg >= T:
            return g.expand_as(x) + g.expand_as(x) * 0 + g.expand_as(x) * 0 + g.expand_as(x)
        pad = (-T) % self.seg
        xp = F.pad(x, (0, pad), mode="replicate") if pad else x
        s = xp.unfold(-1, self.seg, self.seg).mean(-1)              # (B, bn, n_seg)
        s = s.repeat_interleave(self.seg, dim=-1)[..., :T]          # broadcast back over frames
        return s + g

    def forward(self, main, bottleneck):
        """main: (B, growth, T) the dilated conv output.  bottleneck: (B, bn, T) its input."""
        m = torch.sigmoid(self.fc2(F.relu(self.fc1(self.context(bottleneck)))))
        return main * m


class DTDNNLayer(nn.Module):
    """One dense layer: BN-ReLU-Conv1x1 -> BN-ReLU-Conv_k -> CAM, output CONCATENATED.

    Pre-activation ordering (BN and ReLU BEFORE each conv) is read, not assumed -- the transition
    calls BN+act (sub_180204B20) and only then the 1x1 conv (sub_1802052E0), and the dense layer does
    the same twice.
    """

    def __init__(self, in_dim, bn=CAMPP_BN, growth=CAMPP_GROWTH, dilation=1, seg=CAMPP_CAM_SEG):
        super().__init__()
        self.bn1 = nn.BatchNorm1d(in_dim)
        self.reduce = nn.Conv1d(in_dim, bn, 1)
        self.bn2 = nn.BatchNorm1d(bn)
        self.conv = nn.Conv1d(bn, growth, 3, dilation=dilation, padding=dilation)
        self.cam = CAM(bn, growth, seg)

    def forward(self, x):
        h = self.reduce(F.relu(self.bn1(x)))
        h = F.relu(self.bn2(h))
        return torch.cat([x, self.cam(self.conv(h), h)], dim=1)


class DTDNNBlock(nn.Module):
    def __init__(self, in_dim, n_layers, bn=CAMPP_BN, growth=CAMPP_GROWTH, dilation=1,
                 seg=CAMPP_CAM_SEG):
        super().__init__()
        d = in_dim
        layers = []
        for _ in range(n_layers):
            layers.append(DTDNNLayer(d, bn, growth, dilation, seg))
            d += growth
        self.layers = nn.ModuleList(layers)
        self.out_dim = d

    def forward(self, x):
        for l in self.layers:
            x = l(x)
        return x


class TransitLayer(nn.Module):
    """BN-ReLU-Conv1x1, halving the width. Read as {224,112,1,1,0,1} / {304,152,..} / {280,140,..}."""

    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.bn = nn.BatchNorm1d(in_dim)
        self.conv = nn.Conv1d(in_dim, out_dim, 1)
        self.out_dim = out_dim

    def forward(self, x):
        return self.conv(F.relu(self.bn(x)))


class StatsPool(nn.Module):
    """Mean + standard deviation over time.

    Std matters as much as mean: two speakers can share an average spectrum and differ in how much
    they move around it. Read: the pooled buffer is 0x460 = 280 floats = 2 x 140, and unlike every
    other buffer in the forward it is NOT multiplied by the frame count.
    """

    def forward(self, x):
        m = x.mean(-1)
        s = x.var(-1, unbiased=False).clamp_min(1e-8).sqrt()
        return torch.cat([m, s], dim=-1)


# ---------------------------------------------------------------- the two models
class _DTDNNBackbone(nn.Module):
    """The shared body. CAM++ and OSD differ only in width, depth, growth and head."""

    def __init__(self, ch, blocks, growth, dilations, bn=CAMPP_BN, seg=CAMPP_CAM_SEG,
                 bands=CAMPP_BANDS):
        super().__init__()
        self.fcm = FCM(ch, bands)
        out, k, s, p = CAMPP_STEM
        self.stem = nn.Conv1d(self.fcm.out_dim, out, k, stride=s, padding=p)
        d = out
        self.blocks = nn.ModuleList()
        self.transits = nn.ModuleList()
        self.widths = [d]
        for i, n in enumerate(blocks):
            b = DTDNNBlock(d, n, bn, growth, dilations[i], seg)
            t = TransitLayer(b.out_dim, b.out_dim // 2)
            self.blocks.append(b)
            self.transits.append(t)
            self.widths += [b.out_dim, t.out_dim]
            d = t.out_dim
        self.out_dim = d
        self.out_bn = nn.BatchNorm1d(d)

    def forward(self, x):                                          # x: (B, T, bands)
        h = self.stem(self.fcm(x.transpose(1, 2).unsqueeze(1)))    # stride 2 -> half frame rate
        for b, t in zip(self.blocks, self.transits):
            h = t(b(h))
        return F.relu(self.out_bn(h))


class CamppNet(nn.Module):
    """CAM++ speaker embedding: 80-band input over a 3 s window -> a 512-dim embedding.

    Every dimension is read. Verify with `CamppNet().check_shapes()`, which asserts the widths
    against the buffer sizes taken out of the binary.
    """

    def __init__(self, embed=CAMPP_EMBED, ch=CAMPP_FCM_CH, bands=CAMPP_BANDS,
                 blocks=CAMPP_BLOCKS, growth=CAMPP_GROWTH, bn=CAMPP_BN,
                 dilations=CAMPP_DILATION, seg=CAMPP_CAM_SEG):
        super().__init__()
        self.body = _DTDNNBackbone(ch, blocks, growth, dilations, bn, seg, bands)
        self.pool = StatsPool()
        self.embed = nn.Conv1d(2 * self.body.out_dim, embed, 1)     # {280, 512, k1}
        self.embed_bn = nn.BatchNorm1d(embed)

    def forward(self, x, l2_normalise=True):
        """x: (B, T, bands) log-filterbank -> (B, embed)."""
        h = self.pool(self.body(x)).unsqueeze(-1)                   # (B, 280, 1)
        e = self.embed_bn(self.embed(h).squeeze(-1))
        return F.normalize(e, dim=-1) if l2_normalise else e

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    def check_shapes(self):
        """Assert the widths against the buffer sizes read from the binary. Raises on mismatch."""
        want = [128, 224, 112, 304, 152, 280, 140]
        got = self.body.widths
        assert got == want, "backbone widths %s != binary's %s" % (got, want)
        assert self.body.fcm.out_dim == 320, "FCM flat width %d != 320" % self.body.fcm.out_dim
        assert 2 * self.body.out_dim == 280, "pooled width != 280 (buffer 0x460)"
        assert n_frames() == CAMPP_FRAMES == 298
        assert n_frames_half() == 149
        return True

    @staticmethod
    def provenance():
        return {
            "confidence": "HIGH -- structure read, most numbers confirmed 2-3 independent ways",
            "read": ["48000-sample window, frame 320, hop 160 -> 299 frames ((w-f)/h+1, literal)",
                     "FCM flat width 320 = 10 x 32 (malloc(1280 * n_frames))",
                     "stem {320,128,k5,s2,p2} -> backbone at half frame rate, (n-1)/2+1 stored",
                     "num_layers [12,24,16] (literal args to the block calls)",
                     "growth 8 -- from buffer diffs, from `v16 + 8` in code, and from the config "
                     "structs' in-width ladder 128,136,144,...",
                     "bottleneck 32 (buffer n<<7 = 32 floats/frame)",
                     "kernel 3, dilation [1,2,2] (config structs {32,8,3,1,1,1} / {32,8,3,1,2,2})",
                     "transitions halve: {224,112},{304,152},{280,140}, all k1",
                     "CAM = seg_mean(100 frames) + global mean -> 32->16->8 -> sigmoid -> multiply",
                     "stats pooling 140 -> 280 (buffer 0x460, not per-frame)",
                     "embedding {280,512,k1} -- 512",
                     "pre-activation BN-ReLU-Conv ordering",
                     "14 push_back counts in the init all match the per-layer weight/config budget",
                     "THE FCM STRIDE PLACEMENT: template arguments give the block order and "
                     "every stride -- 80->40 and 40->20 in shortcut-projection res blocks, "
                     "20->10 in a standalone depthwise conv. Was previously ours.",
                     "frame count 298 (the FCM stores it; the other packaging takes 298 too)"],
            "ours": ["filterbank warping (80 bands read, mel-vs-linear not)",
                     "the mapping between the FCM convolutions and the 72-tensor weight ladder"],
            "excluded": ["Zoom's trained weights"],
            "corrected": ["frame count 299 -> 298, and the frame length that implies: 320 -> 480. "
                          "299 came from ASSUMING a 320-sample frame; 298 is what the FCM stores, "
                          "and the model's other packaging takes 298 as well.",
                          "embedding: this model is 512. The earlier 792 was not a misread -- it is the "
                          "real output of the OpenVINO-packaged model found elsewhere in the "
                          "client ([1,1,80,298] -> [1,792,1,1]). The mistake was CONFLATING TWO "
                          "DIFFERENT ARTIFACTS, not misreading a number. Both values stand, for "
                          "their own model.",
                          "growth 32 -> 8", "bottleneck 128 -> 32",
                          "param count ~7.9M -> ~0.9M (the 7.9M was published CAM++, not this)"],
        }


class OsdNet(nn.Module):
    """Overlapped-speech detection: DTDNN_CAMDense_OSD, the width-12 sibling.

    Why OSD exists at all: diarisation assigns one speaker per segment, so overlapped speech is where
    it silently fails. Detecting overlap lets the system split the segment or mark it uncertain.

    Read: FCM at 12 channels -> 120 flat, the same {*,128,k5,s2,p2} stem, blocks [6,8] with growth 6,
    transitions {164,82} and {130,65}, and a head of four 1x1 convs at width 128 ending in 2 classes.
    The head's buffers are constants rather than K * n_frames, so it consumes a POOLED vector -- this
    is a segment-level decision, not a per-frame posterior.
    """

    def __init__(self, ch=OSD_FCM_CH, bands=CAMPP_BANDS, blocks=OSD_BLOCKS, growth=OSD_GROWTH,
                 hidden=OSD_HEAD, classes=OSD_CLASSES):
        super().__init__()
        self.body = _DTDNNBackbone(ch, blocks, growth, (1, 2), CAMPP_BN, CAMPP_CAM_SEG, bands)
        self.pool = StatsPool()
        d = 2 * self.body.out_dim
        self.head = nn.Sequential(nn.Linear(d, hidden), nn.ReLU(),
                                  nn.Linear(hidden, hidden), nn.ReLU(),
                                  nn.Linear(hidden, hidden), nn.ReLU(),
                                  nn.Linear(hidden, classes))

    def forward(self, x, logits=False):
        """x: (B, T, bands) -> (B, 2) logits, or (B,) probability of overlap."""
        z = self.head(self.pool(self.body(x)))
        return z if logits else z.softmax(-1)[:, 1]

    def param_count(self):
        return sum(p.numel() for p in self.parameters())

    def check_shapes(self):
        want = [128, 164, 82, 130, 65]
        got = self.body.widths
        assert got == want, "OSD widths %s != binary's %s" % (got, want)
        assert self.body.fcm.out_dim == 120, "OSD FCM flat width %d != 120" % self.body.fcm.out_dim
        return True

    @staticmethod
    def provenance():
        return {
            "confidence": "HIGH -- was LOW; the head is now read, not invented",
            "read": ["FCM at 12 ch -> 120 flat (= the stem's read input width)",
                     "stem {120,128,k5,s2,p2}",
                     "blocks [6,8] (push counts 6/6/48/12/30/18 and 8/8/64/16/40/24; literal 6)",
                     "growth 6 (128+6*6=164 and 82+8*6=130, both read as config structs)",
                     "transitions {164,82,k1} and {130,65,k1}",
                     "head: four 1x1 convs at 128 ending in {128,2} -> 2 classes",
                     "head operates on a pooled vector (buffers 0x410 = 2x130 and 0x200 = 128 are "
                     "constants, not K * n_frames)"],
            "ours": ["which of 130 / 65 feeds the head (the two readings are not distinguishable)",
                     "the FCM stride placement, shared with CamppNet"],
            "excluded": ["Zoom's trained weights"],
            "corrected": ["the head was previously invented outright; it is 4x128 -> 2",
                          "output was previously per-frame; it is segment-level"],
        }


# --------------------------------------------------------------------------- diarisation
def cosine_affinity(embeds, prune=0.9):
    """Cosine affinity with row-wise pruning -- the usual pre-step before spectral clustering."""
    e = F.normalize(embeds, dim=-1)
    a = (e @ e.t()).clamp(-1, 1)
    if prune and prune < 1.0:
        k = max(1, int(prune * a.shape[-1]))
        thr = a.topk(k, dim=-1).values[:, -1:].expand_as(a)
        a = torch.where(a >= thr, a, torch.zeros_like(a))
        a = 0.5 * (a + a.t())
    return a.clamp_min(0)


def spectral_cluster(embeds, n_speakers=None, max_speakers=8):
    """Spectral clustering over speaker embeddings, with the eigengap heuristic for the count.

    This is the counterpart of the recovered SpectralCluster / EigenDecomposition classes -- and note
    that those two exist ONLY in a scalar variant (their SIMD siblings are stubs), which is the
    binary's own way of saying this is not a hot path. It is classic linear algebra, not a network,
    so it is reproduced directly rather than trained.

    CAVEAT, and it is a real deployment one: the eigengap heuristic for `n_speakers` is unreliable when
    there are few segments or when embeddings are weakly separated -- it will happily report 7 speakers
    for 3. Pass `n_speakers` explicitly when the count is known, and in production prefer a threshold on
    the affinity matrix or an external speaker count over trusting the gap.
    """
    a = cosine_affinity(embeds)
    d = a.sum(-1).clamp_min(1e-8)
    lap = torch.eye(a.shape[0]) - (a / d.sqrt().unsqueeze(1) / d.sqrt().unsqueeze(0))
    vals, vecs = torch.linalg.eigh(lap)
    if n_speakers is None:
        gaps = vals[1:max_speakers + 1] - vals[:max_speakers]
        n_speakers = int(torch.argmax(gaps).item()) + 1
    x = F.normalize(vecs[:, :n_speakers], dim=-1)
    # k-means++ style init then Lloyd iterations -- small n, so plain loops are fine
    idx = [int(torch.randint(0, x.shape[0], (1,)).item())]
    for _ in range(n_speakers - 1):
        d2 = torch.stack([((x - x[i]) ** 2).sum(-1) for i in idx]).min(0).values
        idx.append(int(torch.argmax(d2).item()))
    c = x[idx].clone()
    for _ in range(50):
        assign = ((x.unsqueeze(1) - c.unsqueeze(0)) ** 2).sum(-1).argmin(-1)
        for k in range(n_speakers):
            m = assign == k
            if m.any():
                c[k] = x[m].mean(0)
    return assign, n_speakers
