"""A1: prove the training + evaluation loop end-to-end. One question, one answer.

THE QUESTION
  Can a trained 257-bin mask estimator beat the DSP's 0.12-1.75 dB attenuation on TRANSIENT noise,
  measured in the same harness the DSP is measured in?

Everything else about phase A depends on that answer, so nothing else is attempted here. In
particular this is NOT the architecture recovered from viperex.dll: the 21 shape tables' field
semantics are not yet self-consistent (a2[1] fits pad=1, a2[2] needs pad=2), and guessing them is the
exact mistake that cost this session three wrong conclusions. What IS taken from the recovered design:
  * 257-bin in, 257-bin out (512-point FFT half-spectrum) -- same as ours and same as Zoom's
  * an explicit temporal element (Zoom keeps a 10-frame history per channel and computes moving
    mean/variance over it; a GRU is the reliable version of the same idea)
  * bounded mask output, applied to the noisy magnitude with the noisy phase kept
Batch E (reading slot[18]/slot[19]/slot[0]) is what unlocks a faithful port; that is A3.

WHY THE SPLIT IS WHAT IT IS
  Only 79.7 s of clean speech is available locally (the 2.33 GB MS-SNSD download was deleted after
  the 13 evaluation files were extracted). That is far too little for a production model, and this
  script does not pretend otherwise. It is enough to answer the question above IF the test noise is
  genuinely unseen -- so Typing_1 and Munching_1, the two transient classes the DSP fails on, are
  held out of training entirely, along with one speaker.

FRAMING
  16 kHz, 512-point FFT, hop 256, 257 bins -- identical to ns_core.hpp, so the WAVs this writes are
  directly comparable in the existing metric harness.

USAGE
  python nn_a1.py train  [--epochs 40] [--out model_a1.pt]
  python nn_a1.py infer  --model model_a1.pt --in noisy.wav --out clean.wav
  python nn_a1.py eval   --model model_a1.pt          (DSP vs NN on the held-out set)
"""
import argparse
import math
import os
import random
import struct
import sys
import wave

import torch
import torch.nn as nn

D = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 16000
NFFT = 512
HOP = 256
BINS = NFFT // 2 + 1          # 257 -- same as ns_core.hpp and same as Zoom's tables

# Strict split. The two noise classes the DSP fails on are TEST-ONLY, so a win here cannot come from
# having memorised them.
CLEAN_TRAIN = ["clnsp379", "clnsp512", "clnsp518", "clnsp553"]
CLEAN_TEST = ["clnsp1068"]
NOISE_TRAIN = ["AirConditioner_1", "VacuumCleaner_1", "Babble_1", "ShuttingDoor_1",
               "Neighbor_1", "AirportAnnouncements_1"]
NOISE_TEST = ["Typing_1", "Munching_1"]


# ---------------------------------------------------------------- wav io
def read_wav(path):
    w = wave.open(path, "rb")
    n, sw, sr = w.getnframes(), w.getsampwidth(), w.getframerate()
    raw = w.readframes(n)
    w.close()
    assert sw == 2, "expected 16-bit PCM, got sampwidth %d" % sw
    assert sr == SR, "expected %d Hz, got %d" % (SR, sr)
    x = torch.tensor(struct.unpack("<%dh" % n, raw), dtype=torch.float32) / 32768.0
    return x


def write_wav(path, x):
    y = torch.clamp(x, -1.0, 1.0)
    pcm = (y * 32767.0).to(torch.int16).tolist()
    w = wave.open(path, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(SR)
    w.writeframes(struct.pack("<%dh" % len(pcm), *pcm))
    w.close()


def load_set(clean_names, noise_names):
    clean = [read_wav(os.path.join(D, "samples", "clean", n + ".wav")) for n in clean_names]
    noise = [read_wav(os.path.join(D, "samples", "noise", n + ".wav")) for n in noise_names]
    return clean, noise


# ---------------------------------------------------------------- mixing
def mix_at_snr(speech, noise, snr_db, rng):
    """Tile/crop the noise to the speech length, then scale it to the requested SNR.

    RMS is measured over the whole of each signal, matching eval.hpp's mix_at_snr -- the DSP numbers
    this is compared against were produced with that convention, and a different one would shift the
    SNR and invalidate the comparison.
    """
    n = speech.numel()
    if noise.numel() < n:
        reps = int(math.ceil(n / noise.numel()))
        noise = noise.repeat(reps)
    off = rng.randrange(0, max(1, noise.numel() - n + 1))
    nz = noise[off:off + n].clone()
    s_rms = speech.pow(2).mean().sqrt().clamp_min(1e-9)
    n_rms = nz.pow(2).mean().sqrt().clamp_min(1e-9)
    target = s_rms / (10.0 ** (snr_db / 20.0))
    nz *= (target / n_rms)
    return speech + nz, nz


# ---------------------------------------------------------------- stft
_WIN = torch.hann_window(NFFT)


def stft(x):
    return torch.stft(x, NFFT, HOP, window=_WIN, center=True, return_complex=True)


def istft(X, length):
    return torch.istft(X, NFFT, HOP, window=_WIN, center=True, length=length)


# ---------------------------------------------------------------- model
class MaskNet(nn.Module):
    """257 -> 257 bounded mask, with one recurrent layer carrying the temporal context.

    Deliberately small (~165k params): it has to train on CPU from 64 s of speech, and a real-time
    denoiser is small by construction anyway -- Zoom's runs on CPU with hand-written SIMD kernels.
    Input is log-power, which is what makes a fixed-threshold-free model trainable on this little
    data: the network sees a level-normalised spectrum rather than raw magnitudes.
    """

    def __init__(self, hidden=128):
        super().__init__()
        self.enc = nn.Linear(BINS, hidden)
        self.gru = nn.GRU(hidden, hidden, num_layers=1, batch_first=True)
        self.dec = nn.Linear(hidden, BINS)

    def forward(self, logp):          # logp: (B, T, BINS)
        h = torch.relu(self.enc(logp))
        h, _ = self.gru(h)
        return torch.sigmoid(self.dec(h))


def features(mag):
    """Log-power features, floored so silence does not dominate the gradient."""
    return torch.log(mag.pow(2).clamp_min(1e-10))


def enhance(model, noisy):
    """noisy: (N,) time domain -> (N,) enhanced. Mask on magnitude, noisy phase kept."""
    X = stft(noisy)                                  # (BINS, T) complex
    mag = X.abs()
    mask = model(features(mag).transpose(0, 1).unsqueeze(0)).squeeze(0).transpose(0, 1)
    return istft(X * mask, noisy.numel())


# ---------------------------------------------------------------- training
def compressed_l1(est_mag, ref_mag, p=0.3):
    """L1 on power-law-compressed magnitudes.

    Compression is what stops the loss being dominated by the few loudest bins; p=0.3 is the usual
    choice for speech enhancement and matters more here than usual because the training set is tiny.
    """
    return (est_mag.clamp_min(1e-8).pow(p) - ref_mag.clamp_min(1e-8).pow(p)).abs().mean()


def train(args):
    rng = random.Random(1234)
    torch.manual_seed(1234)
    clean, noise = load_set(CLEAN_TRAIN, NOISE_TRAIN)
    vclean, vnoise = load_set(CLEAN_TEST, NOISE_TEST)
    print("train: %d speech (%.1f s), %d noise" % (
        len(clean), sum(c.numel() for c in clean) / SR, len(noise)))
    print("valid: %d speech (%.1f s), %d noise  [%s HELD OUT]" % (
        len(vclean), sum(c.numel() for c in vclean) / SR, len(vnoise), ", ".join(NOISE_TEST)))

    model = MaskNet(args.hidden)
    nparam = sum(p.numel() for p in model.parameters())
    print("model: %d params" % nparam)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    sched = torch.optim.lr_scheduler.StepLR(opt, step_size=max(1, args.epochs // 3), gamma=0.5)

    SEG = 4 * SR                                      # 4 s crops
    best = float("inf")
    for ep in range(1, args.epochs + 1):
        model.train()
        tot, nb = 0.0, 0
        for _ in range(args.steps):
            sp = clean[rng.randrange(len(clean))]
            if sp.numel() > SEG:
                o = rng.randrange(0, sp.numel() - SEG)
                sp = sp[o:o + SEG]
            nz = noise[rng.randrange(len(noise))]
            snr = rng.uniform(args.snr_lo, args.snr_hi)
            noisy, _ = mix_at_snr(sp, nz, snr, rng)
            Xn, Xs = stft(noisy), stft(sp)
            mag_n, mag_s = Xn.abs(), Xs.abs()
            mask = model(features(mag_n).transpose(0, 1).unsqueeze(0)).squeeze(0).transpose(0, 1)
            loss = compressed_l1(mag_n * mask, mag_s)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            tot += float(loss)
            nb += 1
        sched.step()

        # validation on HELD-OUT speaker x HELD-OUT noise, fixed SNR and fixed offsets
        model.eval()
        vrng = random.Random(7)
        with torch.no_grad():
            vl, vn = 0.0, 0
            for sp in vclean:
                for nz in vnoise:
                    noisy, _ = mix_at_snr(sp, nz, 5.0, vrng)
                    Xn, Xs = stft(noisy), stft(sp)
                    mask = model(features(Xn.abs()).transpose(0, 1).unsqueeze(0)).squeeze(0).transpose(0, 1)
                    vl += float(compressed_l1(Xn.abs() * mask, Xs.abs()))
                    vn += 1
        v = vl / max(vn, 1)
        flag = ""
        if v < best:
            best = v
            torch.save({"state": model.state_dict(), "hidden": args.hidden}, args.out)
            flag = "  <- saved"
        print("epoch %3d  train %.5f  valid %.5f%s" % (ep, tot / max(nb, 1), v, flag))
    print("best valid %.5f -> %s" % (best, args.out))


def load_model(path):
    ck = torch.load(path, map_location="cpu", weights_only=True)
    m = MaskNet(ck.get("hidden", 128))
    m.load_state_dict(ck["state"])
    m.eval()
    return m


def infer(args):
    m = load_model(args.model)
    x = read_wav(args.inp)
    with torch.no_grad():
        y = enhance(m, x)
    write_wav(args.out, y)
    print("wrote %s (%.2f s)" % (args.out, y.numel() / SR))


# ---------------------------------------------------------------- evaluation
def frame_db(x, a, b):
    seg = x[a:b]
    if seg.numel() == 0:
        return -120.0
    r = float(seg.pow(2).mean().sqrt())
    return 20.0 * math.log10(max(r, 1e-9))


def gap_speech_split(clean):
    """Label frames from the CLEAN reference -- ground truth, not the model's opinion."""
    nfr = clean.numel() // HOP
    lv = [frame_db(clean, i * HOP, (i + 1) * HOP) for i in range(nfr)]
    pk = max(lv)
    sp = [i for i, v in enumerate(lv) if v >= pk - 25]
    gp = [i for i, v in enumerate(lv) if v <= pk - 45]
    return sp, gp, nfr


def evaluate(args):
    """DSP vs NN on the held-out speaker x held-out transient noise, same metric as NOTES 19.20."""
    import subprocess
    LAB = os.path.join(D, "build", "Release", "nsxlab.exe")
    OUT = os.path.join(D, "out", "nn")
    os.makedirs(OUT, exist_ok=True)
    m = load_model(args.model)
    rng = random.Random(7)

    print("%-12s %-16s %-16s %9s %11s %11s" % (
        "clean", "noise", "system", "att_gap", "att_speech", "modulation"))
    print("-" * 80)
    for cn in CLEAN_TEST:
        cp = os.path.join(D, "samples", "clean", cn + ".wav")
        clean = read_wav(cp)
        sp, gp, nfr = gap_speech_split(clean)
        for nn_ in NOISE_TEST:
            npth = os.path.join(D, "samples", "noise", nn_ + ".wav")
            noise = read_wav(npth)
            noisy, _ = mix_at_snr(clean, noise, 5.0, random.Random(7))
            noisy_p = os.path.join(OUT, "noisy.wav")
            write_wav(noisy_p, noisy)
            b_sp = sum(frame_db(noisy, i * HOP, (i + 1) * HOP) for i in sp) / len(sp)
            b_gp = sum(frame_db(noisy, i * HOP, (i + 1) * HOP) for i in gp) / len(gp)

            runs = []
            # DSP baseline and the best DSP config found in NOTES 19.20
            for label, flags in (("DSP level2", ["--level", "2"]),
                                 ("DSP best19.20", ["--level", "2", "--afloor-db", "24",
                                                    "--feature-set", "1", "--thresh-mode", "1"])):
                o = os.path.join(OUT, "d.wav")
                subprocess.run([LAB, "--in", noisy_p, "--out", o] + flags, capture_output=True)
                runs.append((label, read_wav(o)))
            with torch.no_grad():
                runs.append(("NN a1", enhance(m, noisy)))
                # ORACLE: the ideal amplitude mask, computed FROM the clean reference. Not a system --
                # it is the ceiling this architecture can express, and the control that separates
                # "the model is undertrained" from "the mask path is broken". If the oracle does not
                # dominate every row below, the bug is in the code, not in the training.
                Xn, Xs = stft(noisy), stft(clean[:noisy.numel()])
                T = min(Xn.shape[1], Xs.shape[1])
                om = (Xs[:, :T].abs() / Xn[:, :T].abs().clamp_min(1e-9)).clamp(0.0, 1.0)
                runs.append(("ORACLE mask", istft(Xn[:, :T] * om, noisy.numel())))

            for label, y in runs:
                mfr = min(nfr, y.numel() // HOP)
                ys = sum(frame_db(y, i * HOP, (i + 1) * HOP) for i in sp if i < mfr) / \
                     max(1, sum(1 for i in sp if i < mfr))
                yg = sum(frame_db(y, i * HOP, (i + 1) * HOP) for i in gp if i < mfr) / \
                     max(1, sum(1 for i in gp if i < mfr))
                print("%-12s %-16s %-16s %9.2f %11.2f %11.2f" % (
                    cn, nn_, label, b_gp - yg, b_sp - ys, (b_gp - yg) - (b_sp - ys)))
            print()


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("train")
    t.add_argument("--epochs", type=int, default=40)
    t.add_argument("--steps", type=int, default=60)
    t.add_argument("--hidden", type=int, default=128)
    t.add_argument("--lr", type=float, default=2e-3)
    t.add_argument("--snr-lo", type=float, default=0.0)
    t.add_argument("--snr-hi", type=float, default=15.0)
    t.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "model_a1.pt"))
    i = sub.add_parser("infer")
    i.add_argument("--model", required=True)
    i.add_argument("--in", dest="inp", required=True)
    i.add_argument("--out", required=True)
    e = sub.add_parser("eval")
    e.add_argument("--model", required=True)
    a = ap.parse_args()
    if a.cmd == "train":
        train(a)
    elif a.cmd == "infer":
        infer(a)
    else:
        evaluate(a)


if __name__ == "__main__":
    main()
