# ida_stages.py -- the six D-TDNN stage operators, plus the FCM.
#
# sub_180205B20 gives the ladder; these give the operations inside each rung:
#   sub_180203970  D-TDNN dense block (num_layers, in_ch, in, out, 6 weight views)
#   sub_1802064C0  transition (1x1 conv, halves channels)
#   sub_180206350  stem TDNN (320->128, k5 s2 p2)
#   sub_180204B20  CAM -- context-aware masking
#   sub_180206130  statistics pooling (140 -> 280)
#   sub_180205750  embedding (280 -> 512)
# Plus the FCM: its ctor sub_18017DFF0 was read, so add whatever its vt[1] forward is,
# and the OSD counterparts for a width-12 cross-check.
import json

import idautils
import idc
import ida_funcs
import ida_hexrays
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'stages.json'

FUNCS = [(0x180203970, "D-TDNN dense block"),
         (0x1802064C0, "transition 1x1"),
         (0x180206350, "stem TDNN 320->128 k5s2p2"),
         (0x180204B20, "CAM context-aware masking"),
         (0x180206130, "statistics pooling 140->280"),
         (0x180205750, "embedding 280->512"),
         (0x180001B90, "weight-view loader (24-byte descriptor)"),
         (0x180014280, "buffer resize/zero"),
         (0x18017EBE0, "DTDNN_CAMDense vt[1]"),
         (0x1802134C0, "DTDNN_CAMDense_OSD_C vt[0] -- width-12 cross-check")]

res = {"funcs": [], "log": []}
seen = set()
for ea, why in FUNCS:
    f = ida_funcs.get_func(ea)
    if not f:
        res["log"].append("no function at %X" % ea)
        continue
    if f.start_ea in seen:
        continue
    seen.add(f.start_ea)
    try:
        c = ida_hexrays.decompile(f.start_ea)
        ps = str(c) if c else "(decompile failed)"
    except Exception as e:
        ps = "(exc %s)" % e
    res["funcs"].append({"ea": "%X" % f.start_ea, "size": f.size(), "why": why,
                         "name": ida_name.demangle_name(idc.get_func_name(f.start_ea), 0)
                                 or idc.get_func_name(f.start_ea),
                         "pseudocode": ps[:60000]})

res["count"] = len(res["funcs"])
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(res, fh, indent=1)
idc.qexit(0)
