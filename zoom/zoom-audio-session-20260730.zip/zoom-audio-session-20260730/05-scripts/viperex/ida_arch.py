# Reconstruct each neural model's architecture from TorchCpp template parameters.
#
# IDA demangles the layer vtables with their template args intact, e.g.
#   TorchCpp::Conv2dTd<float,80,80,1,1,3,1,1,1,1,0,1>
#   TorchCpp::Layer2dTd<float,80,10,1,32>
# Those numbers ARE the layer shapes. Grouping them tells apart the model kinds without reading a
# single line of pseudocode:
#   denoiser   -> in/out dims tied to spectrum bins (64/80/161/257), output same width as input
#   classifier -> narrows to a small class count
#   embedder   -> ends at 192 / 512 / 792
#
# Also records, for each layer vtable, which function installs it -> which model owns which layers.
import collections
import json
import idc
import idautils
import ida_funcs
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'arch.json'
idc.auto_wait()

rows = []
for ea, raw in idautils.Names():
    dem = idc.demangle_name(raw, idc.get_inf_attr(idc.INF_SHORT_DN)) or raw
    if 'TorchCpp' not in dem and 'Nn' not in dem and 'Campp' not in dem \
       and 'DTDNN' not in dem and 'SedModel' not in dem:
        continue
    if 'vftable' not in dem:
        continue
    owners = []
    for xr in idautils.DataRefsTo(ea):
        f = ida_funcs.get_func(xr)
        if f:
            owners.append(hex(f.start_ea))
    rows.append({'ea': hex(ea), 'name': dem, 'owners': sorted(set(owners))[:6]})

# group by owner function -> that function builds one model, so its layer list is that model's arch
by_owner = collections.defaultdict(list)
for r in rows:
    for o in r['owners']:
        by_owner[o].append(r['name'])

# and a plain inventory of distinct layer shapes
shapes = collections.Counter()
for r in rows:
    n = r['name'].replace("const ", "").replace("::`vftable'", "")
    shapes[n] += 1

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump({'n': len(rows),
               'by_owner': {k: sorted(set(v)) for k, v in
                            sorted(by_owner.items(), key=lambda kv: -len(kv[1]))[:24]},
               'shapes': shapes.most_common(400)}, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
