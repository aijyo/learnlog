"""Extract every TorchCpp conv/block template instantiation from the binary.

The FCM's constructor assigns vtables whose mangled names carry the full template argument list, so the
convolution geometry (frequency in/out, channels in/out, kernel, stride, padding, groups) is written out
in plain text. That settles where the stride-2 steps sit -- the one thing the weight ladder could not say.

Field order, established by the two entries whose effect is unambiguous:
    Conv2dTd<float, F_in, F_out, C_in, C_out, K, stride, ?, pad, ?, ?, groups>
  * <float,20,10,32,32,3,2,1,1,1,0,32>  -> 20/2 = 10, and groups == channels (depthwise)
  * <float,10,10,32,32,1,1,1,0,1,0,1>   -> stride 1 leaves the axis alone
"""
import re
from collections import OrderedDict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()

pat = re.compile(rb"TorchCpp::([A-Za-z0-9_]+)<float,([0-9,]+)>")
seen = OrderedDict()
for m in re.finditer(rb"[ -~]{12,200}", d):
    s = m.group(0)
    for mm in pat.finditer(s):
        name = mm.group(1).decode()
        args = [int(x) for x in mm.group(2).split(b",") if x]
        seen.setdefault((name, tuple(args)), 0)
        seen[(name, tuple(args))] += 1

print("distinct TorchCpp template instantiations: %d\n" % len(seen))

conv, other = [], []
for (name, args), n in seen.items():
    (conv if name.startswith("Conv2dTd") else other).append((name, args, n))

print("=" * 104)
print("Conv2dTd<float, F_in, F_out, C_in, C_out, K, stride, ?, pad, ?, ?, groups>")
print("=" * 104)
print("%-8s %-8s %-8s %-8s %-4s %-7s %-4s %-8s %s"
      % ("F_in", "F_out", "C_in", "C_out", "K", "stride", "grp", "depthwise", "note"))
print("-" * 104)
for name, a, n in sorted(conv, key=lambda t: (-t[1][0], t[1][1])):
    if len(a) < 12:
        print("  (unexpected arity %d) %s<%s>" % (len(a), name, a))
        continue
    fin, fout, cin, cout, k, st = a[0], a[1], a[2], a[3], a[4], a[5]
    grp = a[11]
    dw = "YES" if grp == cout and grp > 1 else "-"
    note = []
    if st > 1:
        note.append("<== STRIDE %d,  %d -> %d" % (st, fin, fout))
    if fin != fout and st == 1:
        note.append("freq changes without stride?")
    if cin != cout:
        note.append("ch %d -> %d" % (cin, cout))
    print("%-8d %-8d %-8d %-8d %-4d %-7d %-4d %-8s %s"
          % (fin, fout, cin, cout, k, st, grp, dw, "  ".join(note)))

print()
print("=" * 104)
print("其他模板(块 / 归一化 / FCM 本体)")
print("=" * 104)
for name, a, n in sorted(other, key=lambda t: t[0]):
    print("  %-34s %s" % (name, list(a)))

print()
print("=" * 104)
print("频率轴的下采样链 —— 把 stride>1 的按频率顺序排出来")
print("=" * 104)
chain = sorted([(a[0], a[1], a[4], a[5], a[11]) for _, a, _ in conv if len(a) >= 12 and a[5] > 1],
               key=lambda t: -t[0])
for fin, fout, k, st, grp in chain:
    print("   %3d -> %-3d   k=%d stride=%d groups=%d%s" % (fin, fout, k, st, grp,
                                                           "  (depthwise)" if grp > 1 else ""))
tot = 1
for fin, fout, *_ in chain:
    tot *= fin / float(fout) if fout else 1
print("   总下采样倍数 %.0f  (80 -> %.0f)" % (tot, 80 / tot if tot else 0))
