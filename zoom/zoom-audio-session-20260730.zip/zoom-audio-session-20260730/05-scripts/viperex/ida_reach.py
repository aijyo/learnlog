# Does the denoise path ever run a neural forward pass?
#
# Direct weight refs from code are always zero here: the blobs are reached through a descriptor
# struct, not by address. So test reachability instead.
#
#   S = functions transitively reachable from the denoise thread body (sub_18000B530)
#   N = the neural side: functions referencing the nnet_data layer-name table / layer-name strings,
#       plus functions referencing any TorchCpp RTTI vtable
#
# If S and N are disjoint, the denoise module never touches the neural engines -- and viperex's
# 38 MB of weights belong to something else (AEC/SED/PVAD/speaker), which is the honest conclusion.
import json
import idc
import idautils
import ida_funcs
import ida_bytes
import ida_name
import ida_segment

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'reach.json'
idc.auto_wait()


def reachable(roots, max_depth=7, cap=6000):
    seen, frontier, depth_of = set(), list(roots), {}
    for r in roots:
        depth_of[r] = 0
    while frontier and len(seen) < cap:
        ea = frontier.pop()
        if ea in seen:
            continue
        seen.add(ea)
        d = depth_of.get(ea, 0)
        if d >= max_depth:
            continue
        f = ida_funcs.get_func(ea)
        if not f:
            continue
        for ia in idautils.FuncItems(f.start_ea):
            for cr in idautils.CodeRefsFrom(ia, 0):
                g = ida_funcs.get_func(cr)
                if g and g.start_ea not in seen:
                    depth_of.setdefault(g.start_ea, d + 1)
                    frontier.append(g.start_ea)
            # virtual dispatch through .rdata vtables: follow one level of vtable contents
            for xr in idautils.DataRefsFrom(ia):
                if 0x18021F000 <= xr < 0x182B15000:
                    for k in range(12):
                        q = ida_bytes.get_qword(xr + 8 * k)
                        if not q:
                            break
                        g = ida_funcs.get_func(q)
                        if g and g.start_ea == q and g.start_ea not in seen:
                            depth_of.setdefault(g.start_ea, d + 1)
                            frontier.append(g.start_ea)
    return seen


# ---- S: denoise side -------------------------------------------------------
S = reachable([0x18000B530, 0x18000A0F0, 0x180001030, 0x180001CD0])

# ---- N: neural side -------------------------------------------------------
# a) anything referencing the nnet_data layer-name table
neural_roots = set()
for xr in idautils.DataRefsTo(0x180221980):
    f = ida_funcs.get_func(xr)
    if f:
        neural_roots.add(f.start_ea)

# b) anything referencing a layer-name string
lo, hi = 0x1804CA700, 0x1804CB000
for ea in range(lo, hi, 4):
    for xr in idautils.DataRefsTo(ea):
        f = ida_funcs.get_func(xr)
        if f:
            neural_roots.add(f.start_ea)

# c) TorchCpp / model RTTI vtables -> their owners
TORCH = []
for ea, name in idautils.Names():
    dem = idc.demangle_name(name, idc.get_inf_attr(idc.INF_SHORT_DN)) or name
    if 'TorchCpp' in dem or 'Conv2dTd' in dem or 'BatchNorm2dTd' in dem \
       or 'AecNnModel' in dem or 'AecQ16Nn' in dem or 'SedModelCalculate' in dem \
       or 'CamppCalculator' in dem or 'DTDNN' in dem:
        TORCH.append((hex(ea), dem[:100]))
        f = ida_funcs.get_func(ea)
        if f:
            neural_roots.add(f.start_ea)
        for xr in idautils.DataRefsTo(ea):
            g = ida_funcs.get_func(xr)
            if g:
                neural_roots.add(g.start_ea)

N = reachable(list(neural_roots), max_depth=4, cap=6000) if neural_roots else set()

inter = S & N
res = {
    'denoise_reachable': len(S),
    'neural_roots': len(neural_roots),
    'neural_reachable': len(N),
    'intersection': len(inter),
    'intersection_sample': [ida_name.get_ea_name(x) or hex(x) for x in sorted(inter)[:40]],
    'torch_symbols_found': TORCH[:40],
    'n_torch_symbols': len(TORCH),
}
with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(res, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
