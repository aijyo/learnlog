"""Build AEC's operator sequence: slot -> kernel (from the installers) x call order (from the forward).

The widths are not readable without the ctor chain, but the OPERATOR SEQUENCE and the SKIP TOPOLOGY
are, and those are the architecture. Signature arity groups slots into families, and the forward's
buffer arguments show which buffer feeds which -- including the two calls that reach back to an
earlier encoder buffer, i.e. skip connections.
"""
import json
import re
from collections import OrderedDict, defaultdict

D = (r"C:\Users\NCCTEC~1\AppData\Local\Temp\claude\D--code-work-research"
     r"\d6fecc69-579f-40d8-a174-02301f47d2c5\scratchpad")

k = json.load(open(D + r"\aeckern.json", encoding="utf-8"))
a = json.load(open(D + r"\aecpvad.json", encoding="utf-8"))

# ---- 1. slot -> kernel, per ISA, plus the signature arity ----
ASG = re.compile(r"(qword_[0-9A-F]{6,})\s*=\s*\(__int64 \(__fastcall \*\)\(([^)]*)\)\)\s*&?(\w+)")
inst = {}
for i in k["installers"]:
    m = OrderedDict()
    for slot, sig, fn in ASG.findall(i["pseudocode"]):
        m[slot] = (fn, len([t for t in sig.split(",") if t.strip()]))
    inst[i["name"]] = m
    print("%s: %d slots" % (i["name"], len(m)))

scal = inst["_cfltcvt_init_18"]
avx = inst.get("_cfltcvt_init_19", {})
sse = inst.get("_cfltcvt_init_20", {})

print("\nslots set by scalar: %d   by AVX: %d   by SSE: %d" % (len(scal), len(avx), len(sse)))
only_scalar = [s for s in scal if s not in avx and s not in sse]
print("set ONLY by the scalar installer (no SIMD version exists): %s"
      % (" ".join(only_scalar) or "(none)"))
shared = [s for s in avx if s in sse and avx[s][0] == sse[s][0]]
print("same kernel in AVX and SSE (not ISA-specialised): %s"
      % (" ".join("%s=%s" % (s, avx[s][0]) for s in shared) or "(none)"))

# ---- 2. call order + buffer flow, from the General forward ----
fwd = {x["ea"]: x for x in a["funcs"]}["180115D50"]["pseudocode"]
CALL = re.compile(r"(qword_[0-9A-F]{6,})\(([^;]*?)\);", re.S)
BUF = re.compile(r"a1 \+ (\d+)")

print("\n%-4s %-18s %-14s %-5s %s" % ("#", "slot", "kernel", "args", "a1+ offsets referenced"))
print("-" * 104)
seq = []
prod = {}                      # buffer offset -> which step last wrote it
for n, m in enumerate(CALL.finditer(fwd), 1):
    slot, args = m.group(1), m.group(2)
    offs = [int(x) for x in BUF.findall(args)]
    fn, arity = scal.get(slot, ("?", 0))
    seq.append((slot, fn, offs))
    # heuristic: the first two a1+ offsets are (in, out) for these kernels
    tag = ""
    if len(offs) >= 2:
        src, dst = offs[0], offs[1]
        if src in prod and prod[src] < n - 1:
            tag = "   <== SKIP from step %d (buffer a1+%d)" % (prod[src], src)
        prod[dst] = n
    print("%-4d %-18s %-14s %-5d %s%s"
          % (n, slot, fn, arity, " ".join(str(o) for o in offs[:6]), tag))

# ---- 3. families by arity ----
fam = defaultdict(list)
for slot, (fn, ar) in scal.items():
    fam[ar].append(slot)
print("\nslot families by signature arity (same arity == same operator kind):")
for ar in sorted(fam):
    print("   %2d args: %2d slots   %s" % (ar, len(fam[ar]), " ".join(fam[ar])))

out = {"scalar": {s: v[0] for s, v in scal.items()},
       "arity": {s: v[1] for s, v in scal.items()},
       "avx": {s: v[0] for s, v in avx.items()},
       "sse": {s: v[0] for s, v in sse.items()},
       "call_order": [{"slot": s, "kernel": f, "a1_offsets": o} for s, f, o in seq],
       "only_scalar": only_scalar, "shared_simd": shared}
json.dump(out, open(D + r"\aec_ops.json", "w", encoding="utf-8"), indent=1)
print("\nwrote aec_ops.json")
