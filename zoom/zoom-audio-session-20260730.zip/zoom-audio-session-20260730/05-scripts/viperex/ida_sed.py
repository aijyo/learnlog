# Locate SED: the processors, the model calculators, and their vtables.
#
# SED has been the one piece never reached -- prior work got the interfaces, the three quality tiers
# and five live instances, but never the classification algorithm. The lever is `SedModelCalculate_C`:
# a scalar reference implementation sitting next to _SSE2 and _AVX2. The C variant is the same
# algorithm without the vectorisation, so it is the readable one.
#
# Dumps every SED-ish vtable with its slots (function + size), plus which functions install them.
import json
import idc
import idautils
import ida_funcs
import ida_bytes
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'sed.json'
idc.auto_wait()

WANT = ("Sed", "SED", "SoundEvent")

vt = []
for ea, raw in idautils.Names():
    dem = idc.demangle_name(raw, idc.get_inf_attr(idc.INF_SHORT_DN)) or raw
    if not any(w in dem for w in WANT):
        continue
    if "vftable" not in dem and "vtable" not in dem:
        continue
    owners = []
    for xr in idautils.DataRefsTo(ea):
        f = ida_funcs.get_func(xr)
        if f:
            owners.append(hex(f.start_ea))
    slots = []
    for i in range(24):
        q = ida_bytes.get_qword(ea + 8 * i)
        g = ida_funcs.get_func(q) if q else None
        if not g or g.start_ea != q:
            break
        slots.append({"slot": i, "fn": hex(q),
                      "name": ida_name.get_ea_name(q) or "",
                      "size": g.end_ea - g.start_ea})
    vt.append({"ea": hex(ea), "name": dem, "owners": sorted(set(owners)),
               "n_slots": len(slots), "slots": slots})

# every function whose name or referenced strings mention SED
funcs = []
for fea in idautils.Functions():
    f = ida_funcs.get_func(fea)
    if not f:
        continue
    nm = ida_name.get_ea_name(fea) or ""
    dem = idc.demangle_name(nm, idc.get_inf_attr(idc.INF_SHORT_DN)) or nm
    hit = any(w in dem for w in WANT)
    strs = []
    if not hit:
        for ea in idautils.FuncItems(fea):
            for xr in idautils.DataRefsFrom(ea):
                s = ida_bytes.get_strlit_contents(xr, -1, 0)
                if s and any(w.encode() in s for w in WANT):
                    strs.append(s.decode("utf-8", "replace")[:90])
                    hit = True
    if hit:
        funcs.append({"ea": hex(fea), "name": dem[:110],
                      "size": f.end_ea - f.start_ea, "strings": strs[:6]})

with open(OUT, "w", encoding="utf-8") as fh:
    json.dump({"vtables": sorted(vt, key=lambda r: r["name"]),
               "funcs": sorted(funcs, key=lambda r: -r["size"])[:60]}, fh, indent=1,
              ensure_ascii=False)
idc.qexit(0)
