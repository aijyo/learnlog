# Fingerprint a function without reading 30 KB of pseudocode: callees, float constants, data refs.
#
# The question is narrow -- is this classic DSP or a neural forward pass? Those two look completely
# different at this level:
#   classic DSP  -> calls sqrtf/expf/logf/atan/cos, many small float literals (thresholds, alphas)
#   NN forward   -> references large .rdata weight blobs, calls a handful of big kernels repeatedly,
#                   few literals
# So list callees with sizes+call counts, and bucket referenced data by size.
#
# Usage: idat64 -A "-Sida_fingerprint.py <out.json> ea1,ea2,..." viperex.dll.i64
import json
import struct
import idc
import idautils
import ida_funcs
import ida_bytes
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'fp.json'
EAS = [int(x, 16) for x in (idc.ARGV[2].split(',') if len(idc.ARGV) > 2 else [])]
idc.auto_wait()

RDATA_LO, RDATA_HI = 0x18021F000, 0x182B15000


def nm(ea):
    n = ida_name.get_ea_name(ea)
    return n if n else hex(ea)


res = {}
for fe in EAS:
    f = ida_funcs.get_func(fe)
    if not f:
        res[hex(fe)] = {'missing': True}
        continue
    callees = {}
    drefs = {}
    floats = {}
    ninsn = 0
    for ea in idautils.FuncItems(f.start_ea):
        ninsn += 1
        for cr in idautils.CodeRefsFrom(ea, 0):
            g = ida_funcs.get_func(cr)
            if g and g.start_ea != f.start_ea:
                k = nm(g.start_ea)
                if k not in callees:
                    callees[k] = {'ea': hex(g.start_ea), 'size': g.end_ea - g.start_ea, 'calls': 0}
                callees[k]['calls'] += 1
        for xr in idautils.DataRefsFrom(ea):
            if RDATA_LO <= xr < 0x183C3A000:
                # how big is the contiguous non-zero float run starting here?
                raw = ida_bytes.get_bytes(xr, 16)
                fv = None
                if raw and len(raw) >= 4:
                    try:
                        fv = struct.unpack_from('<f', raw, 0)[0]
                    except Exception:
                        fv = None
                s = ida_bytes.get_strlit_contents(xr, -1, 0)
                key = hex(xr)
                drefs[key] = {'float0': fv if (fv is not None and -1e30 < fv < 1e30) else None,
                              'str': s.decode('utf-8', 'replace') if s and len(s) < 90 else None}
                if fv is not None and -1e6 < fv < 1e6 and fv != 0:
                    floats[key] = round(fv, 8)
    res[hex(fe)] = {
        'name': nm(f.start_ea), 'size': f.end_ea - f.start_ea, 'insns': ninsn,
        'callees': sorted(callees.items(), key=lambda kv: -kv[1]['size'])[:24],
        'n_drefs': len(drefs),
        'sample_floats': sorted(floats.items())[:40],
        'strings': sorted({v['str'] for v in drefs.values() if v['str']})[:20],
    }

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(res, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
