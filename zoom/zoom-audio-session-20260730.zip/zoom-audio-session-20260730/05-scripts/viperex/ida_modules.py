# Name each of viperex's 14 plugin-level modules, and dump the denoise module's full interface.
#
# CreateProcessor(kind 0..19) hands viper.dll one of 14 module types, all unnamed. But each ctor
# installs a vtable, and the functions in that vtable reference log strings ("[CAMPP] ...") that name
# the module. Naming them is the prerequisite for answering the real question: does the classic
# denoiser CONSUME the neural detectors' output, or are they independent siblings?
#
# Also dumps every slot of the denoise module's vtable with each slot's strings + arg-ish size, since
# a "set SED result" / "set VAD" style setter is exactly where the wiring would show up.
import collections
import json
import idc
import idautils
import ida_funcs
import ida_bytes
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'modules.json'
idc.auto_wait()

RLO, RHI = 0x18021F000, 0x183C3A000

# kind -> ctor, read off CreateProcessor (sub_180013D90)
KINDS = {
    0: 0x180008E90, 1: 0x18000DD40, 4: 0x18000F610, 5: 0x1801583C0,
    6: 0x180158170, 8: 0x180158280, 10: 0x180168F00, 11: 0x180110F50,
    12: 0x180156CE0, 16: 0x180107DB0, 18: 0x180135E60, 19: 0x1800090F0,
}


def strings_in(fe, depth=1, _seen=None):
    """Strings referenced by fe, optionally following one level of callees."""
    if _seen is None:
        _seen = set()
    out = []
    f = ida_funcs.get_func(fe)
    if not f or f.start_ea in _seen:
        return out
    _seen.add(f.start_ea)
    for ea in idautils.FuncItems(f.start_ea):
        for xr in idautils.DataRefsFrom(ea):
            s = ida_bytes.get_strlit_contents(xr, -1, 0)
            if s and 4 < len(s) < 130:
                t = s.decode('utf-8', 'replace')
                if any(c.isalpha() for c in t):
                    out.append(t)
        if depth > 0:
            for cr in idautils.CodeRefsFrom(ea, 0):
                g = ida_funcs.get_func(cr)
                if g and g.start_ea != f.start_ea and (g.end_ea - g.start_ea) < 9000:
                    out.extend(strings_in(g.start_ea, depth - 1, _seen))
    return out


def vtable_of(fe):
    f = ida_funcs.get_func(fe)
    if not f:
        return None
    for ea in list(idautils.FuncItems(f.start_ea))[:80]:
        for xr in idautils.DataRefsFrom(ea):
            if RLO <= xr < RHI:
                q = ida_bytes.get_qword(xr)
                if q and ida_funcs.get_func(q):
                    return xr
    return None


res = {}
for kind, ce in sorted(KINDS.items()):
    vt = vtable_of(ce)
    slots = []
    if vt:
        for i in range(20):
            q = ida_bytes.get_qword(vt + 8 * i)
            g = ida_funcs.get_func(q) if q else None
            if not g or g.start_ea != q:
                break
            slots.append({'slot': i, 'fn': hex(q), 'size': g.end_ea - g.start_ea,
                          'name': ida_name.get_ea_name(q) or ''})
    st = sorted(set(strings_in(ce, depth=2)))
    # also gather strings from the slot functions (that is where log lines live)
    for s in slots[:12]:
        st.extend(strings_in(int(s['fn'], 16), depth=1))
    res['kind%d' % kind] = {
        'ctor': hex(ce), 'vtable': hex(vt) if vt else None,
        'n_slots': len(slots), 'slots': slots,
        'strings': sorted(set(st))[:26],
        'has_denoise_thread': any('Denoise' in x for x in st),
    }

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(res, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
