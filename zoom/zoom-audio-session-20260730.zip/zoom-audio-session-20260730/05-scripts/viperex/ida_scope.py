# How big is the job? Measure the classic denoiser before promising to reverse it.
#
# Transitive closure from the model's 8 vtable slots plus the module's own 13, restricted to real
# code (excluding CRT/libm), gives the actual function count and byte count that would have to be
# understood. That number decides whether "fully reverse it" is a week or a quarter.
#
# Also buckets by size, because in practice a handful of big DSP loops carry the algorithm and the
# long tail is accessors.
import collections
import json
import idc
import idautils
import ida_funcs
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'scope.json'
idc.auto_wait()

SKIP = ('memcpy', 'memset', 'memmove', 'malloc', 'free', 'sqrt', 'pow', 'exp', 'log', 'sin', 'cos',
        'atan', 'alloca', 'security_check', 'errno', 'invalid_parameter', 'Mtx_', 'Cnd_',
        'std::', 'operator', 'purecall', 'cfltcvt', 'ftol', 'Xlen', 'Xlength', 'cancel_current')


def skip(nm):
    return any(s in nm for s in SKIP)


def closure(roots, max_depth=9, cap=4000):
    seen, stack = {}, [(r, 0) for r in roots]
    while stack:
        ea, d = stack.pop()
        f = ida_funcs.get_func(ea)
        if not f:
            continue
        s = f.start_ea
        if s in seen or len(seen) >= cap:
            continue
        nm = ida_name.get_ea_name(s) or hex(s)
        if skip(nm):
            continue
        seen[s] = {'name': nm, 'size': f.end_ea - f.start_ea, 'depth': d}
        if d >= max_depth:
            continue
        for ia in idautils.FuncItems(s):
            for cr in idautils.CodeRefsFrom(ia, 0):
                g = ida_funcs.get_func(cr)
                if g and g.start_ea not in seen:
                    stack.append((g.start_ea, d + 1))
    return seen


# roots: the module's 13 vtable slots + the kind 0xA/B/C/E model's 8 slots + the STFT front end
MODULE_VT = 0x1804CC460
MODEL_VT = 0x182AF7028
import ida_bytes
roots = []
for i in range(13):
    q = ida_bytes.get_qword(MODULE_VT + 8 * i)
    if q and ida_funcs.get_func(q):
        roots.append(q)
for i in range(8):
    q = ida_bytes.get_qword(MODEL_VT + 8 * i)
    if q and ida_funcs.get_func(q):
        roots.append(q)
roots += [0x180001CD0, 0x18000B530, 0x1800041D0, 0x1800035C0, 0x18000BD40]

fs = closure(roots)
tot = sum(v['size'] for v in fs.values())
buckets = collections.Counter()
for v in fs.values():
    s = v['size']
    b = '>4KB' if s > 4096 else '2-4KB' if s > 2048 else '1-2KB' if s > 1024 else \
        '256B-1KB' if s > 256 else '<256B'
    buckets[b] += 1

big = sorted(fs.items(), key=lambda kv: -kv[1]['size'])[:26]

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump({'n_funcs': len(fs), 'total_bytes': tot,
               'buckets': dict(buckets),
               'biggest': [{'ea': hex(k), 'name': v['name'], 'size': v['size'], 'depth': v['depth']}
                           for k, v in big],
               'bytes_in_top10': sum(v['size'] for _, v in big[:10])}, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
