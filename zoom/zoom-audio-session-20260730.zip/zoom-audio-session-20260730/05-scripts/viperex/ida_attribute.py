# ida_attribute.py -- attribute the 5 unowned dispatch tables via the call graph.
#
# Each table's scalar installer is called from an ISA-selection site. Walk UP from that site's
# containing function until a function is reached that sits in a named RTTI vtable -- that names the
# owner. Also decompile each scalar installer (to get every slot -> kernel for all five tables at once)
# and one kernel per table (to establish whether it uses the same int16 / Q31 / LUT idiom as the
# denoise net).
import json
import re

import idautils
import idc
import ida_bytes
import ida_funcs
import ida_hexrays
import ida_name
import ida_segment

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'attrib.json'

TABLES = [
    (0x183C36E90, "39", 0x1800D0A80, 0x1800BBB3F),
    (0x183C35F70, "35", 0x1800B1180, 0x180091D09),
    (0x183C35150, "19", 0x180051580, 0x180045506),
    (0x183C35EE0, "13", 0x180083210, 0x1800800CF),
    (0x183C35DF0, "10", 0x18006ECD0, 0x18006625F),
    (0x183C37450, "40", 0x1800FB5A0, 0x1800E6C7B),   # denoise, as the control
    (0x183C387B0, "30", 0x180120080, 0x180116FCD),   # AEC, as the control
]

res = {"tables": [], "installers": [], "kernels": [], "log": []}


def demang(n):
    return ida_name.demangle_name(n, 0) or n or "?"


# ---- build func_ea -> [vtable class names] so a function can be identified as a method ----
vt_owner = {}
for nm, ea in list(idautils.Names()):
    m = re.match(r"\?\?_7(.+?)@@6B@?$", ea)
    if not m:
        continue
    cls = m.group(1)
    for i in range(64):
        p = ida_bytes.get_qword(nm + 8 * i)
        f = ida_funcs.get_func(p) if p else None
        if not f or f.start_ea != p:
            break
        vt_owner.setdefault(p, []).append("%s::vt[%d]" % (cls, i))
res["log"].append("vtable-slot functions indexed: %d" % len(vt_owner))


def climb(ea, depth=5):
    """Walk up callers until a vtable method is found. Returns the trail."""
    f = ida_funcs.get_func(ea)
    if not f:
        return ["(no func at %X)" % ea]
    trail, cur, seen = [], f.start_ea, set()
    for _ in range(depth):
        if cur in seen:
            break
        seen.add(cur)
        nm = demang(idc.get_func_name(cur))
        own = vt_owner.get(cur)
        trail.append("%s%s" % (nm, ("  <== " + ", ".join(own)) if own else ""))
        if own:
            break
        callers = [x.frm for x in idautils.CodeRefsTo(cur, 0)]
        nxt = None
        for c in callers:
            cf = ida_funcs.get_func(c)
            if cf and cf.start_ea != cur:
                nxt = cf.start_ea
                break
        if nxt is None:
            break
        cur = nxt
    return trail


ASG = re.compile(r"(qword_[0-9A-F]{6,})\s*=\s*(?:\([^)]*\))?\s*&?(sub_[0-9A-F]{6,})")

for tab, n, inst, site in TABLES:
    entry = {"table": "%X" % tab, "slots": n, "installer": "%X" % inst, "isa_site": "%X" % site}
    entry["climb"] = climb(site)
    # decompile the installer -> slot map
    f = ida_funcs.get_func(inst)
    kmap = {}
    if f:
        try:
            ps = str(ida_hexrays.decompile(f.start_ea))
        except Exception as e:
            ps = "(exc %s)" % e
        for slot, fn in ASG.findall(ps):
            sv = int(slot.replace("qword_", ""), 16)
            kmap[(sv - tab) // 8] = fn
        res["installers"].append({"table": "%X" % tab, "ea": "%X" % f.start_ea,
                                  "pseudocode": ps[:20000]})
    entry["kernels"] = {str(k): v for k, v in sorted(kmap.items())}
    res["tables"].append(entry)
    # sample two kernels per table for the idiom test
    for k in sorted(kmap)[:2]:
        ea = idc.get_name_ea_simple(kmap[k])
        kf = ida_funcs.get_func(ea) if ea != idc.BADADDR else None
        if not kf:
            continue
        try:
            kp = str(ida_hexrays.decompile(kf.start_ea))
        except Exception as e:
            kp = "(exc %s)" % e
        res["kernels"].append({"table": "%X" % tab, "slot": k, "name": kmap[k],
                               "size": kf.size(), "pseudocode": kp[:14000]})

res["count"] = len(res["tables"])
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(res, fh, indent=1)
idc.qexit(0)
