"""Every RTTI class in viperex.dll, unfiltered and grouped.

Twice now a regex filter has hidden the thing I was looking for (the NN engine itself was missed for
days because the earlier scan only ran on viper.dll). So: print all of them, grouped by top-level
scope, and let me read the list rather than trusting a pattern.
"""
import collections
import re

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()

names = set()
for m in re.finditer(rb"\.\?AV[\x20-\x7e]{3,240}?@@", d):
    names.add(m.group(0).decode("latin1"))

def pretty(n):
    parts = [p for p in n[4:-2].split("@") if p]
    return "::".join(reversed(parts)) if len(parts) > 1 else n[4:-2]

# Collapse the TorchCpp kernel template explosion into one count per template name.
groups = collections.defaultdict(list)
tmpl = collections.Counter()
for n in names:
    p = pretty(n)
    if p.startswith("TorchCpp") or "?$" in p:
        m = re.search(r"\?\$([A-Za-z0-9_]+)", p)
        tmpl[m.group(1) if m else p] += 1
        continue
    top = p.split("::")[0] if "::" in p else "(global)"
    groups[top].append(p)

print("total RTTI descriptors: %d" % len(names))
print("\n=== TorchCpp layer templates (instantiation counts) ===")
for k, v in sorted(tmpl.items(), key=lambda x: -x[1]):
    print("  %-42s x%d" % (k, v))

print("\n=== non-template classes, by scope ===")
for top in sorted(groups):
    print("\n[%s]  (%d)" % (top, len(groups[top])))
    for p in sorted(groups[top]):
        print("    " + p[:130])
