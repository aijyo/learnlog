# ida_dtdnn.py -- read DTDNN_CAMDense end to end, plus the AEC init.
#
# Seven RTTI classes: DTDNN_CAMDense{,_C,_SSE2,_AVX} and DTDNN_CAMDense_OSD{,_C,_SSE2}.
# The _C variants are the scalar reference implementations -- readable. Dump every vtable with
# per-slot sizes so the small outer-structure slots can be told from the hot kernels, then
# decompile the init (sub_1801FC100, 30 KB -- where the layer ladder is built) and the _C forwards.
import json

import idaapi
import idautils
import idc
import ida_bytes
import ida_funcs
import ida_hexrays
import ida_name
import ida_segment

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'dtdnn.json'

CLASSES = ["DTDNN_CAMDense", "DTDNN_CAMDense_C", "DTDNN_CAMDense_SSE2", "DTDNN_CAMDense_AVX",
           "DTDNN_CAMDense_OSD", "DTDNN_CAMDense_OSD_C", "DTDNN_CAMDense_OSD_SSE2"]

FUNCS = [(0x1801FC100, "DTDNN init -- the layer ladder"),
         (0x18020DDB0, "OSD net init"),
         (0x18017DFF0, "CAM++ a1+8 ctor (0xB30)"),
         (0x180199410, "OSD a1+8 ctor (0xB30)"),
         (0x1801FB040, "DTDNN_CAMDense ctor (0x378)"),
         (0x1801BBC00, "feature extractor ctor (0x17850)"),
         (0x1801BBEF0, "feature extractor configure"),
         (0x180116FC0, "AEC init vt0 -- per-layer dims")]

log = []
res = {"vtables": {}, "funcs": []}


def say(m):
    log.append(str(m))


def demang(n):
    return ida_name.demangle_name(n, 0) or n


def find_vtable(cls):
    """Locate `??_7<cls>@@6B@` or, failing that, the vtable via the RTTI type descriptor."""
    for pref in ("??_7%s@@6B@" % cls, "%s::`vftable'" % cls):
        ea = idc.get_name_ea_simple(pref)
        if ea != idc.BADADDR:
            return ea
    td = idc.get_name_ea_simple("??_R0?AV%s@@@8" % cls)
    if td == idc.BADADDR:
        return None
    for x in idautils.XrefsTo(td, 0):          # -> col descriptor
        for y in idautils.XrefsTo(x.frm - 0, 0):
            pass
    return None


def dump_vt(ea, limit=64):
    slots = []
    for i in range(limit):
        p = ida_bytes.get_qword(ea + 8 * i)
        f = ida_funcs.get_func(p) if p else None
        if not f or f.start_ea != p:
            break
        slots.append({"i": i, "ea": "%X" % p, "size": f.size(),
                      "name": demang(idc.get_func_name(p))})
    return slots


for cls in CLASSES:
    ea = find_vtable(cls)
    if ea is None:
        say("no vtable found for %s" % cls)
        continue
    slots = dump_vt(ea)
    res["vtables"][cls] = {"vt": "%X" % ea, "slots": slots}
    say("%s vtable @%X, %d slots" % (cls, ea, len(slots)))
    # the _C forward is worth decompiling: add every slot > 300 bytes
    if cls.endswith("_C"):
        for s in slots:
            if s["size"] > 300:
                FUNCS.append((int(s["ea"], 16), "%s vt[%d]" % (cls, s["i"])))


seen = set()
for ea, why in FUNCS:
    f = ida_funcs.get_func(ea)
    if not f or f.start_ea in seen:
        continue
    seen.add(f.start_ea)
    try:
        c = ida_hexrays.decompile(f.start_ea)
        ps = str(c) if c else "(decompile failed)"
    except Exception as e:
        ps = "(exc %s)" % e
    res["funcs"].append({"ea": "%X" % f.start_ea, "size": f.size(), "why": why,
                         "name": demang(idc.get_func_name(f.start_ea)),
                         "pseudocode": ps[:120000]})

res["log"] = log
res["count"] = len(res["funcs"])
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(res, fh, indent=1)
idc.qexit(0)
