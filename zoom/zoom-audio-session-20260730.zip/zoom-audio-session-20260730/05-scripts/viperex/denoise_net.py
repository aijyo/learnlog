"""Reconstruct the architecture of Zoom's neural denoiser from viperex.dll's layer-name table.

The weight blobs carry their layer names as plain strings in the Xiph nnet_data convention
(<layer>_weights_int8 / _bias / _scale / _subias / _weights_idx). Those names, in address order,
ARE the network definition: which layers exist, how they are grouped (enc_/dec_), and which are
sparse. This is the model my reimplementation was missing entirely.
"""
import collections
import re

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()

# nnet_data-style parameter names, kept in file order so layer order is preserved.
PAT = re.compile(rb"[a-z][a-z0-9_]{2,48}_(weights_int8|weights_idx|weights|bias|subias|scale|"
                 rb"weights_float|diag)\x00")
found = []
for m in PAT.finditer(d):
    found.append((m.start(), m.group(0)[:-1].decode("latin1")))

print("nnet_data-style parameter names: %d" % len(found))

# Group by layer stem.
layers = collections.OrderedDict()
for off, nm in found:
    stem = re.sub(r"_(weights_int8|weights_idx|weights_float|weights|bias|subias|scale|diag)$", "", nm)
    layers.setdefault(stem, {"off": off, "parts": []})
    layers[stem]["parts"].append(nm.rsplit(stem + "_", 1)[-1])

print("distinct layers: %d\n" % len(layers))
print("%-34s %-10s %s" % ("layer", "at", "parameters"))
for stem, info in layers.items():
    print("%-34s 0x%-8X %s" % (stem, info["off"], " ".join(sorted(set(info["parts"])))))

# Any other model families in the same convention (aec/sed/campp) -- to separate the denoiser's
# layers from the other models' layers.
print("\n=== grouped by prefix family ===")
fam = collections.Counter()
for stem in layers:
    m = re.match(r"([a-z]+?\d*)_", stem)
    fam[m.group(1) if m else stem] += 1
for k, v in fam.most_common():
    print("  %-16s %d layers" % (k, v))

print("\n=== other Xiph/nnet markers ===")
for probe in (b"nnet", b"NNET", b"rnnoise", b"RNNoise", b"lpcnet", b"LPCNet", b"opus",
              b"sparse", b"Sparse", b"MAX_NEURONS", b"ACTIVATION", b"TANH", b"SIGMOID",
              b"compute_gru", b"compute_dense", b"IRM", b"irm", b"band", b"Band", b"erb", b"ERB"):
    n = d.count(probe)
    if n:
        print("  %-14s x%d" % (probe.decode(), n))

print("\n=== strings around 'IRM' and 'Denoise' ===")
for probe in (b"IRM", b"Denoise", b"denoise"):
    for m in re.finditer(re.escape(probe), d):
        lo = max(0, m.start() - 90)
        seg = d[lo:m.start() + 110]
        # widen to the enclosing printable run
        parts = re.findall(rb"[\x20-\x7e]{5,200}", seg)
        for t in parts:
            s = t.decode("latin1")
            if probe.decode() in s:
                print("  " + s[:170])
