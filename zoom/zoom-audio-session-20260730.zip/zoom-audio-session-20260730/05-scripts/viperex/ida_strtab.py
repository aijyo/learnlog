# Dump the plugin's capability-name table (off_180221980), returned by entry sub_1800140D0.
#
# CreateProcessor(kind, out) dispatches on kind 0..19 with no symbols. If this table is the parallel
# name array, it labels every neural module viper.dll can ask for -- which is the whole point: it says
# in Zoom's own words which of these is the denoiser.
import json
import idc
import ida_bytes

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'strtab.json'
EA = int(idc.ARGV[2], 16) if len(idc.ARGV) > 2 else 0x180221980
N = int(idc.ARGV[3]) if len(idc.ARGV) > 3 else 40
idc.auto_wait()

rows = []
for i in range(N):
    a = EA + 8 * i
    p = ida_bytes.get_qword(a)
    s = None
    if p and ida_bytes.is_loaded(p):
        raw = ida_bytes.get_strlit_contents(p, -1, 0)
        if raw is None:
            raw = ida_bytes.get_bytes(p, 64) or b''
            raw = raw.split(b'\x00')[0]
        try:
            s = raw.decode('utf-8', 'replace')
        except Exception:
            s = repr(raw)
    rows.append({'idx': i, 'at': hex(a), 'ptr': hex(p), 'str': s})

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(rows, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
