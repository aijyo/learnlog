# ida_owners.py -- close the remaining gaps in one run.
#
# Targets, in the order they matter:
#   1. who consumes the three blob pointer arrays (attribution: which model owns which ladder)
#   2. who touches the two 72-tensor blob regions (arrays 1 & 2 have no lea; find via blob xrefs)
#   3. sub_18019E950  -- CamppOsdCalculator_C vt[2], the OSD head
#   4. sub_180116FC0  -- AEC init vt[0], sets per-layer dims at this[560..648]
#   5. every function that data-refs the CAM++ configure tables
#
# Output: one JSON with {ea, name, why, pseudocode} plus an xref census.
import json
import os

import idaapi
import idautils
import idc
import ida_funcs
import ida_hexrays
import ida_bytes
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'owners.json'

ARRAYS = [0x1837DDE60, 0x1837E1380, 0x182B166B0, 0x1837DE1C0, 0x1837DE0A0]
BLOB_RANGES = [(0x1837CEC30, 0x1837DE000, "array1_blobs_w32"),
               (0x1837E1380, 0x1837E4400, "array2_blobs_w12")]
EAS = [(0x18002D4EB, "array3 consumer A"),
       (0x18003476B, "array3 consumer B"),
       (0x18003D63B, "array3 consumer C"),
       (0x18019E950, "OSD head (CamppOsdCalculator_C vt2)"),
       (0x180116FC0, "AEC init vt0 -- per-layer dims"),
       (0x1800FB240, "denoise slot[18]"),
       (0x18006FAB0, "denoise slot[19]"),
       (0x1800D1050, "denoise slot[0]")]

log = []


def say(m):
    log.append(str(m))


def fname(ea):
    f = ida_funcs.get_func(ea)
    if not f:
        return None, None
    n = idc.get_func_name(f.start_ea)
    d = ida_name.demangle_name(n, 0) or n
    return f.start_ea, d


def decomp(ea, limit=26000):
    try:
        f = ida_funcs.get_func(ea)
        if not f:
            return "(no function at %X)" % ea
        c = ida_hexrays.decompile(f.start_ea)
        return str(c)[:limit] if c else "(decompile failed)"
    except Exception as e:
        return "(exc %s)" % e


results = []
seen = set()


def add(ea, why):
    st, nm = fname(ea)
    if st is None:
        say("no function contains %X" % ea)
        return
    if st in seen:
        for r in results:
            if r['ea'] == '%X' % st:
                r['why'] += " | " + why
        return
    seen.add(st)
    results.append({'ea': '%X' % st, 'name': nm, 'why': why,
                    'size': ida_funcs.get_func(st).size(),
                    'pseudocode': decomp(st)})


# ---- 1+5: direct xrefs to the arrays / config tables ----
census = {}
for a in ARRAYS:
    refs = [x.frm for x in idautils.XrefsTo(a, 0)]
    census['%X' % a] = ['%X' % r for r in refs]
    say("xrefs to %X: %s" % (a, ' '.join('%X' % r for r in refs) or '(none)'))
    for r in refs:
        add(r, "refs array %X" % a)

# ---- 2: anything touching the blob regions ----
for lo, hi, tag in BLOB_RANGES:
    hits = {}
    ea = lo
    while ea < hi:
        for x in idautils.XrefsTo(ea, 0):
            st, nm = fname(x.frm)
            if st:
                hits.setdefault(st, [nm, 0])
                hits[st][1] += 1
        nxt = ida_bytes.next_head(ea, hi)
        ea = nxt if nxt > ea else ea + 8
    say("%s: %d functions touch it" % (tag, len(hits)))
    census[tag] = [{'ea': '%X' % k, 'name': v[0], 'hits': v[1]} for k, v in
                   sorted(hits.items(), key=lambda kv: -kv[1][1])]
    for k, v in sorted(hits.items(), key=lambda kv: -kv[1][1])[:4]:
        add(k, "%s (%d refs)" % (tag, v[1]))

# ---- 3+4: explicit targets ----
for ea, why in EAS:
    add(ea, why)

with open(OUT, 'w', encoding='utf-8') as f:
    json.dump({'count': len(results), 'census': census, 'log': log,
               'funcs': results}, f, indent=1)

idc.qexit(0)
