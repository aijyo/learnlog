"""Find EVERY ISA dispatch-table installer in viperex.dll, with no IDA at all.

The AEC discovery was: 30 function-pointer slots, all -1 in the file, filled at load time by three
functions IDA had mislabelled as CRT helpers. That pattern is mechanical in x64:

    48 8D 05 <rel32>     lea  rax, <function>
    48 89 05 <rel32>     mov  [rip+<slot>], rax

So slide over .text looking for that pair. Group the hits by proximity and each cluster IS an
installer; the slots it writes are one dispatch table, and the functions are the kernel set. Doing this
for the whole binary finds the denoise net's table (40 slots, of which only 23 were ever mapped) and
any other table nobody has looked at.
"""
import struct
from collections import defaultdict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()
S = {s[0]: s for s in SECS}
TEXT = S[".text"]


def sec_of(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return nm
    return None


# ---- collect (site, slot_va, func_va) triples ----
hits = []
lo, hi = TEXT[3], min(TEXT[3] + TEXT[2], len(d) - 16)
i = lo
while i + 14 <= hi:
    # lea rax/rcx/... , [rip+rel32]   -> REX.W 8D /r with mod=00 rm=101
    if d[i] in (0x48, 0x4C) and d[i + 1] == 0x8D and (d[i + 2] & 0xC7) == 0x05:
        nxt = TEXT[1] + (i + 7 - TEXT[3])
        fva = nxt + struct.unpack_from("<i", d, i + 3)[0]
        # look ahead a few bytes for mov [rip+rel32], reg  (REX.W 89 /r mod=00 rm=101)
        for k in (7, 8, 9, 10, 11, 12, 13, 14):
            j = i + k
            if j + 7 > hi:
                break
            if d[j] in (0x48, 0x4C) and d[j + 1] == 0x89 and (d[j + 2] & 0xC7) == 0x05:
                nxt2 = TEXT[1] + (j + 7 - TEXT[3])
                sva = nxt2 + struct.unpack_from("<i", d, j + 3)[0]
                if sec_of(fva) == ".text" and sec_of(sva) in (".data", ".rdata"):
                    hits.append((TEXT[1] + (i - TEXT[3]), sva, fva))
                break
        i += 7
        continue
    i += 1

print("lea-func / mov-slot pairs found in .text: %d" % len(hits))

# ---- cluster by site proximity: consecutive hits < 64 bytes apart are one installer ----
hits.sort()
clusters, cur = [], []
for h in hits:
    if cur and h[0] - cur[-1][0] > 96:
        clusters.append(cur)
        cur = []
    cur.append(h)
if cur:
    clusters.append(cur)

big = [c for c in clusters if len(c) >= 8]
print("clusters with >= 8 assignments (dispatch-table installers): %d\n" % len(big))

print("%-14s %-8s %-16s %s" % ("installer @", "#slots", "slot VA range", "slot stride / notes"))
print("-" * 100)
tables = defaultdict(list)
for c in sorted(big, key=lambda c: -len(c)):
    slots = sorted({h[1] for h in c})
    stride = min(b - a for a, b in zip(slots, slots[1:])) if len(slots) > 1 else 0
    span = "%X..%X" % (slots[0], slots[-1])
    contiguous = all(b - a == 8 for a, b in zip(slots, slots[1:]))
    print("%-14X %-8d %-16s %s"
          % (c[0][0], len(slots), span,
             ("stride %d, %s" % (stride, "contiguous" if contiguous else "gapped"))))
    tables[(slots[0], slots[-1])].append((c[0][0], len(slots), c))

# ---- group installers that write the SAME table -> the ISA triplets ----
print()
print("=" * 100)
print("tables written by MORE THAN ONE installer == ISA variant sets (scalar / SSE / AVX)")
print("=" * 100)
byrange = defaultdict(list)
for c in big:
    slots = sorted({h[1] for h in c})
    byrange[(slots[0], slots[-1], len(slots))].append(c)
# also merge ranges that overlap
seen = set()
for key in sorted(byrange, key=lambda k: -k[2]):
    lo_, hi_, n = key
    if (lo_, hi_) in seen:
        continue
    group = []
    for k2, cs in byrange.items():
        if not (k2[1] < lo_ or k2[0] > hi_):
            group += cs
    seen.add((lo_, hi_))
    if len(group) < 2:
        continue
    print("\n### table %X..%X  (%d slots)  written by %d installers" % (lo_, hi_, n, len(group)))
    for c in sorted(group, key=lambda c: c[0][0]):
        slots = sorted({h[1] for h in c})
        print("    installer @%X  writes %d slots  first kernel %X"
              % (c[0][0], len(slots), c[0][2]))
