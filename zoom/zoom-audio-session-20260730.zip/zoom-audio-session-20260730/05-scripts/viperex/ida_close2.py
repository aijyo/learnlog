# ida_close2.py -- same as ida_close.py but with the traceback written to the output file, so a
# failure is diagnosable instead of silent.
import json
import traceback

import idc

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'close.json'
res = {"funcs": [], "dispatch": {}, "log": []}


def dump(extra=None):
    if extra:
        res["error"] = extra
    res["count"] = len(res["funcs"])
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=1)


try:
    import idautils
    import ida_bytes
    import ida_funcs
    import ida_hexrays
    import ida_name

    def demang(n):
        return ida_name.demangle_name(n, 0) or n or "?"

    FUNCS = [(0x180110A50, "PVAD: the 0x48-byte object's ctor"),
             (0x180110E60, "PVAD: no-arg availability check"),
             (0x180110B10, "PVAD: its dtor -- shows what it owns"),
             (0x18010B8E0, "PVADProcessor vt[1]"),
             (0x18010ADC0, "PVADProcessor vt[3]"),
             (0x180115A50, "AEC: vt[1] shared by General and Music")]

    LO, HI = 0x183C387B0, 0x183C388A0
    sel = {}
    va = LO
    while va < HI:
        writers = []
        try:
            for x in idautils.XrefsTo(va, 0):
                f = ida_funcs.get_func(x.frm)
                nm = demang(idc.get_func_name(f.start_ea)) if f else "?"
                writers.append({"from": "%X" % x.frm, "in": nm})
                sel[nm] = sel.get(nm, 0) + 1
        except Exception as e:
            res["log"].append("xref %X: %s" % (va, e))
        cur = ida_bytes.get_qword(va)
        tgt = ida_funcs.get_func(cur)
        res["dispatch"]["%X" % va] = {
            "current": "%X" % cur,
            "current_name": demang(idc.get_func_name(tgt.start_ea)) if tgt else None,
            "current_size": tgt.size() if tgt else None,
            "writers": writers[:6]}
        va += 8

    res["log"].append("dispatch writers: %s" % sorted(sel.items(), key=lambda kv: -kv[1])[:8])
    for nm, cnt in sorted(sel.items(), key=lambda kv: -kv[1])[:2]:
        ea = idc.get_name_ea_simple(nm)
        if ea != idc.BADADDR:
            FUNCS.append((ea, "AEC ISA selector (writes %d slots)" % cnt))

    seen = set()
    for ea, why in FUNCS:
        f = ida_funcs.get_func(ea)
        if not f or f.start_ea in seen:
            res["log"].append("skip %X (%s)" % (ea, "dup" if f else "no func"))
            continue
        seen.add(f.start_ea)
        try:
            c = ida_hexrays.decompile(f.start_ea)
            ps = str(c) if c else "(decompile failed)"
        except Exception as e:
            ps = "(exc %s)" % e
        res["funcs"].append({"ea": "%X" % f.start_ea, "size": f.size(), "why": why,
                             "name": demang(idc.get_func_name(f.start_ea)),
                             "pseudocode": ps[:70000]})
    dump()
except Exception:
    dump(traceback.format_exc())

idc.qexit(0)
