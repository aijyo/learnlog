# Structure of the remaining neural models: CAM++ / OSD / PVAD / AEC-NN / companion mic.
#
# The SED lesson applies directly: each of these ships a `_C` scalar reference next to `_SSE2`/`_AVX2`,
# and a vtable slot that is SHARED between the SIMD variants is the outer structure, not the hot
# kernel. So dump every relevant vtable with its slots and sizes, and note which slots coincide across
# variants -- that alone says where the algorithm is before reading a single line.
#
# Also dumps the TorchCpp layer templates grouped by the function that installs them, because the
# template parameters ARE the layer shapes.
import collections
import json
import idc
import idautils
import ida_funcs
import ida_bytes
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'models.json'
idc.auto_wait()

FAMILIES = {
    "campp": r"Campp|CAMPP",
    "dtdnn": r"DTDNN",
    "pvad": r"PVAD|PVad",
    "aec": r"Aec|AecNn|AecQ16|ECNN",
    "spk": r"SpeakerEmb|SpeakerDiar|SpectralCluster|EigenDecomp",
    "compmic": r"CompanionMic",
    "torch": r"TorchCpp",
}

import re
vt = collections.defaultdict(list)
torch_by_owner = collections.defaultdict(list)

for ea, raw in idautils.Names():
    dem = idc.demangle_name(raw, idc.get_inf_attr(idc.INF_SHORT_DN)) or raw
    if "vftable" not in dem:
        continue
    fam = None
    for k, pat in FAMILIES.items():
        if re.search(pat, dem):
            fam = k
            break
    if fam is None:
        continue
    owners = []
    for xr in idautils.DataRefsTo(ea):
        f = ida_funcs.get_func(xr)
        if f:
            owners.append(hex(f.start_ea))
    owners = sorted(set(owners))
    clean = dem.replace("const ", "").replace("::`vftable'", "")
    if fam == "torch":
        for o in owners:
            torch_by_owner[o].append(clean)
        continue
    slots = []
    for i in range(20):
        q = ida_bytes.get_qword(ea + 8 * i)
        g = ida_funcs.get_func(q) if q else None
        if not g or g.start_ea != q:
            break
        slots.append((i, hex(q), g.end_ea - g.start_ea))
    vt[fam].append({"ea": hex(ea), "name": clean, "owners": owners,
                    "slots": [{"slot": s, "fn": f, "size": z} for s, f, z in slots]})

out = {"vtables": {k: sorted(v, key=lambda r: r["name"]) for k, v in vt.items()},
       "torch_by_owner": {k: sorted(set(v)) for k, v in
                          sorted(torch_by_owner.items(), key=lambda kv: -len(kv[1]))[:30]}}

# which slots are shared between _C / _SSE2 / _AVX variants of the same base name?
shared = {}
byname = {}
for fam, lst in vt.items():
    for r in lst:
        byname[r["name"]] = r
for name, r in byname.items():
    base = re.sub(r"_(C|SSE2|SSE41|AVX|AVX2)$", "", name)
    if base == name:
        continue
    sibs = [o for n, o in byname.items() if re.sub(r"_(C|SSE2|SSE41|AVX|AVX2)$", "", n) == base]
    if len(sibs) < 2:
        continue
    n_slots = min(len(s["slots"]) for s in sibs)
    same, diff = [], []
    for i in range(n_slots):
        fns = {s["slots"][i]["fn"] for s in sibs}
        (same if len(fns) == 1 else diff).append(i)
    shared[base] = {"variants": [s["name"] for s in sibs],
                    "identical_slots": same, "specialised_slots": diff,
                    "sizes": {s["name"]: [x["size"] for x in s["slots"][:n_slots]] for s in sibs}}
out["variant_analysis"] = shared

with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
