# Does the denoise processing actually call through the ISA kernel dispatch table?
#
# cfltcvt_init_16/15/17 install ~30 kernel pointers at 0x183C37450.. . A shape spec plus an installer
# is not proof of execution -- the processing code must READ those slots and call indirectly. So:
# find every function that references the dispatch-table range, and check whether the denoise
# processing chain is among them.
#
# This is the same indirection that made two earlier conclusions wrong (weights reached via a
# descriptor table; kernels reached via a pointer table). Testing it directly this time.
import json
import idc
import idautils
import ida_funcs
import ida_name
import ida_bytes

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'kerncall.json'
idc.auto_wait()

TAB_LO, TAB_HI = 0x183C37440, 0x183C37600
DENOISE = {0x1800E4340, 0x1800E61D0, 0x1800E74C0, 0x1800E4250, 0x1800E6C30, 0x1800E2F00,
           0x1800BBEE0, 0x180014E80, 0x1800E0910, 0x1800E27C0, 0x1800E21F0, 0x1800E1CB0,
           0x18000B530, 0x180001CD0, 0x18008E370, 0x1800E7BA0, 0x1800E8BC0}

refs = {}
for ea in range(TAB_LO, TAB_HI, 8):
    for xr in idautils.DataRefsTo(ea):
        f = ida_funcs.get_func(xr)
        if not f:
            continue
        k = f.start_ea
        refs.setdefault(k, {'name': ida_name.get_ea_name(k) or hex(k),
                            'size': f.end_ea - f.start_ea, 'slots': []})
        refs[k]['slots'].append(hex(ea))

# which of the denoise chain reference it, directly?
direct = {hex(k): v for k, v in refs.items() if k in DENOISE}

# and one level out: callees of the denoise chain that reference it
one_hop = {}
for d in DENOISE:
    f = ida_funcs.get_func(d)
    if not f:
        continue
    for ia in idautils.FuncItems(f.start_ea):
        for cr in idautils.CodeRefsFrom(ia, 0):
            g = ida_funcs.get_func(cr)
            if g and g.start_ea in refs:
                one_hop.setdefault(hex(g.start_ea), {
                    'name': refs[g.start_ea]['name'],
                    'size': refs[g.start_ea]['size'],
                    'slots': sorted(set(refs[g.start_ea]['slots']))[:8],
                    'called_by': []})
                one_hop[hex(g.start_ea)]['called_by'].append(hex(f.start_ea))

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump({'n_referencing_funcs': len(refs),
               'denoise_direct': direct,
               'denoise_one_hop': one_hop,
               'all_referencing': [{'ea': hex(k), 'name': v['name'], 'size': v['size'],
                                    'n_slots': len(set(v['slots']))}
                                   for k, v in sorted(refs.items(),
                                                      key=lambda kv: -len(set(kv[1]['slots'])))][:24]},
              fh, indent=1, ensure_ascii=False)
idc.qexit(0)
