# What are the two collaborator objects the denoise module injects into its model?
#
# SetAlgorithm passes {this[1248], this[1256]} into the model for kinds 6/7/9/13/15/16 only, and
# this[1256] is refcounted at +8 (a shared_ptr control block). If either is a neural detector, that is
# the coupling between viperex's NN stack and the classic denoiser -- the whole question.
#
# Approach: find every instruction in the module's functions that WRITES to [reg+1248] / [reg+1256],
# and report the enclosing function plus the decompiled line, so the setter shows itself.
import json
import idc
import idautils
import ida_funcs
import ida_name
import ida_hexrays

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'field.json'
idc.auto_wait()

TARGET_OFFS = (1248, 1256, 1240)
# the denoise module's code cluster
LO, HI = 0x180008000, 0x180016000

hits = []
for fea in idautils.Functions(LO, HI):
    f = ida_funcs.get_func(fea)
    if not f:
        continue
    for ea in idautils.FuncItems(f.start_ea):
        d = idc.GetDisasm(ea)
        for off in TARGET_OFFS:
            # MSVC emits both decimal-ish and hex forms; check hex since IDA prints hex
            for form in ('%Xh' % off, '%X' % off):
                if form in d and ('mov' in d or 'lea' in d):
                    hits.append({'func': ida_name.get_ea_name(f.start_ea) or hex(f.start_ea),
                                 'func_ea': hex(f.start_ea), 'ea': hex(ea), 'off': off,
                                 'disasm': d})
                    break

# decompile the small functions that write these fields, to read the setter signature
seen = {}
for h in hits:
    fe = int(h['func_ea'], 16)
    if fe in seen:
        continue
    f = ida_funcs.get_func(fe)
    if f and (f.end_ea - f.start_ea) < 2600:
        try:
            cf = ida_hexrays.decompile(fe)
            seen[fe] = str(cf) if cf else None
        except Exception:
            seen[fe] = None

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump({'hits': hits[:80],
               'decomp': {hex(k): v for k, v in seen.items() if v}}, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
