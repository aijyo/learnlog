"""Widen the blob-array scan to .rdata, and attribute each array by hunting its address everywhere.

Two things the previous pass got wrong:
  - it only looked for arrays LOCATED IN .data; an array can live in .rdata just as well
  - it only looked for `lea reg,[rip+disp32]`; an array reached through a containing struct has no
    direct lea, so the address has to be hunted as raw bytes first, then the container xref'd
"""
import re
import struct
from collections import defaultdict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()
S = {s[0]: s for s in SECS}
TEXT = S[".text"]


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


def sec_of(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return nm
    return None


def va_of(o):
    for nm, v, sz, raw in SECS:
        if raw <= o < raw + sz:
            return v + (o - raw)
    return None


# lea xref map
xref = defaultdict(list)
tlo, thi = TEXT[3], min(TEXT[3] + TEXT[2], len(d) - 8)
i = tlo
while i + 7 <= thi:
    if d[i] in (0x48, 0x4C) and d[i + 1] == 0x8D and (d[i + 2] & 0xC7) == 0x05:
        nxt = TEXT[1] + (i + 7 - TEXT[3])
        xref[nxt + struct.unpack_from("<i", d, i + 3)[0]].append(nxt - 7)
        i += 7
        continue
    i += 1

# arrays anywhere in .rdata/.data
arrays = []
for secname in (".rdata", ".data"):
    nm, sva, ssz, sraw = S[secname]
    lo, hi = sraw, min(sraw + ssz, len(d) - 8)
    o = lo
    while o + 8 <= hi:
        p = struct.unpack_from("<Q", d, o)[0]
        if p < 0x180000000 or sec_of(p) not in (".data", ".rdata"):
            o += 8
            continue
        ptrs, j = [], o
        while j + 8 <= hi:
            q = struct.unpack_from("<Q", d, j)[0]
            if q < 0x180000000 or sec_of(q) not in (".data", ".rdata"):
                break
            ptrs.append(q)
            j += 8
        if len(ptrs) >= 10 and len(set(ptrs)) >= 8:
            arrays.append((va_of(o), secname, ptrs))
            o = j
        else:
            o += 8

print("blob pointer arrays (>=10 distinct-ish entries) in .rdata + .data: %d\n" % len(arrays))


def ladder(ptrs):
    su = sorted(set(ptrs))
    sizes = []
    for p in ptrs:
        nxt = min([q for q in su if q > p], default=None)
        sizes.append(((nxt - p) // 4) if nxt else 0)
    comp, run = [], None
    for s in sizes:
        if run and run[0] == s:
            run[1] += 1
        else:
            if run:
                comp.append(run)
            run = [s, 1]
    if run:
        comp.append(run)
    return sizes, " ".join("%d%s" % (s, ("x%d" % n) if n > 1 else "") for s, n in comp)


print("%-14s %-8s %-7s %-11s %s" % ("array VA", "section", "#ptrs", "~params", "attribution"))
print("-" * 126)
for va, sec, ptrs in sorted(arrays, key=lambda a: -len(a[2])):
    su = sorted(set(ptrs))
    span = (su[-1] - su[0]) // 4
    sizes, lad = ladder(ptrs)
    # hunt the array's own address as raw bytes -> containers
    key = struct.pack("<Q", va)
    conts = [va_of(m.start()) for m in re.finditer(re.escape(key), d)]
    conts = [c for c in conts if c and c != va]
    direct = xref.get(va, [])
    cxr = []
    for c in conts[:6]:
        cxr += ["%X(via %X)" % (a, c) for a in xref.get(c, [])[:2]]
    att = (" ".join("%X" % a for a in direct[:3]) or "") + (" " + " ".join(cxr[:4]) if cxr else "")
    print("%-14X %-8s %-7d %-11d %s" % (va, sec, len(ptrs), span, att.strip() or "(none)"))
    print("%s   %s" % (" " * 14, lad[:110]))
