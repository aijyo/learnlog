# ida_aec_kernels.py -- name AEC's operators by reading the scalar kernel installer.
#
# The AEC forward is a chain of indirect calls through qword_183C387B0..183C38898 (30 slots, all
# 0xFFFFFFFFFFFFFFFF statically -- bound at runtime). Three functions write them, and IDA mislabelled
# them as CRT helpers: _cfltcvt_init_18 / _19 / _20. sub_180116FC0 calls _18 unconditionally, then _19
# when (flags & 0x20) and _20 when (flags & 4) -- i.e. _18 installs the SCALAR set and the other two
# overwrite with AVX / SSE. So _18 is the readable reference, exactly like a `_C` class.
#
# Read _18, extract `slot = kernel` pairs, then decompile each distinct scalar kernel small enough to
# be a single operator so the ops can be named.
import json
import re

import idautils
import idc
import ida_funcs
import ida_hexrays
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'aeckern.json'
res = {"installers": [], "kernels": [], "log": []}


def demang(n):
    return ida_name.demangle_name(n, 0) or n or "?"


for nm in ("_cfltcvt_init_18", "cfltcvt_init_18", "_cfltcvt_init_19", "_cfltcvt_init_20"):
    ea = idc.get_name_ea_simple(nm)
    if ea == idc.BADADDR:
        res["log"].append("no symbol %s" % nm)
        continue
    f = ida_funcs.get_func(ea)
    if not f:
        res["log"].append("%s at %X has no function" % (nm, ea))
        continue
    try:
        ps = str(ida_hexrays.decompile(f.start_ea))
    except Exception as e:
        ps = "(exc %s)" % e
    res["installers"].append({"name": nm, "ea": "%X" % f.start_ea, "size": f.size(),
                              "pseudocode": ps[:40000]})
    res["log"].append("%s @%X, %d bytes" % (nm, f.start_ea, f.size()))

# the scalar installer's assignments name every operator
scal = next((i for i in res["installers"] if i["name"].endswith("_18")), None)
if scal:
    pairs = re.findall(r"(qword_[0-9A-F]{6,})\s*=\s*(?:\([^)]*\))?\s*&?(sub_[0-9A-F]{6,}|[A-Za-z_]\w*)",
                       scal["pseudocode"])
    res["pairs"] = [{"slot": a, "kernel": b} for a, b in pairs]
    res["log"].append("scalar installer sets %d slots" % len(pairs))
    seen = set()
    for _, k in pairs:
        ea = idc.get_name_ea_simple(k)
        if ea == idc.BADADDR:
            continue
        f = ida_funcs.get_func(ea)
        if not f or f.start_ea in seen:
            continue
        seen.add(f.start_ea)
        try:
            ps = str(ida_hexrays.decompile(f.start_ea))
        except Exception as e:
            ps = "(exc %s)" % e
        res["kernels"].append({"ea": "%X" % f.start_ea, "size": f.size(), "name": demang(k),
                               "pseudocode": ps[:16000]})

res["count"] = len(res["kernels"])
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(res, fh, indent=1)
idc.qexit(0)
