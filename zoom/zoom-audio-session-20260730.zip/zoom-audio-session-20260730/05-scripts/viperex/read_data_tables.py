"""Read the config tables and hunt the picknet lead -- direct PE reads, no IDA.

Three questions:
  1. picknet: does the string exist, and what symbols cluster around it?  (PVAD's network)
  2. off_1837DE1C0 (6 elem) / off_1837DE1C8 (36 elem): CAM++ configure() args -> D-TDNN depth/growth
  3. any other small int tables near the CAM++ ctor that look like a layer ladder
"""
import re
import struct

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


def va_of(o):
    for nm, v, sz, raw in SECS:
        if raw <= o < raw + sz:
            return v + (o - raw), nm
    return None, "?"


print("=" * 100)
print("1. picknet -- PVAD's network?")
print("=" * 100)
for pat in (b"picknet", b"PickNet", b"pick_net", b"PICKNET"):
    for m in re.finditer(re.escape(pat), d):
        va, sec = va_of(m.start())
        # widen to the surrounding C string
        s = max(0, m.start() - 90)
        e = d.find(b"\0", m.start(), m.start() + 200)
        ctx = d[s:e if e > 0 else m.start() + 60]
        ctx = re.sub(rb"[^\x20-\x7e]+", b" | ", ctx).decode("latin1").strip()
        print("  %-12X %-8s %s" % (va or 0, sec, ctx[:150]))

print()
print("   RTTI classes containing 'ick' or 'VAD' or 'Vad':")
for m in re.finditer(rb"\.\?AV[A-Za-z0-9_@\?\$]{3,140}@@", d):
    s = m.group(0).decode("latin1")
    if re.search(r"[Pp]ick|VAD|Vad|vad", s):
        va, sec = va_of(m.start())
        print("      %-12X %s" % (va or 0, s))

print()
print("=" * 100)
print("2. CAM++ configure() tables")
print("=" * 100)
for tab, n, label in ((0x1837DE1C0, 6, "off_1837DE1C0"), (0x1837DE1C8, 36, "off_1837DE1C8"),
                      (0x1837DE1C0, 48, "off_1837DE1C0 (extended read)")):
    o = off(tab)
    if o is None:
        print("  %s: not in a mapped section" % label)
        continue
    print("\n  --- %s  @%X  raw %X ---" % (label, tab, o))
    q = list(struct.unpack_from("<%dQ" % n, d, o))
    i32 = list(struct.unpack_from("<%dI" % (2 * n), d, o))
    print("     as u64: %s" % " ".join(("%d" % v if v < 1 << 20 else "%#x" % v) for v in q))
    print("     as u32: %s" % " ".join(str(v) if v < 1 << 20 else "%#x" % v for v in i32))
    f32 = struct.unpack_from("<%df" % (2 * n), d, o)
    if any(1e-6 < abs(v) < 1e6 for v in f32):
        print("     as f32: %s" % " ".join("%.4g" % v for v in f32))
    # pointers?
    ptrs = [v for v in q if off(v) is not None and v > 0x180000000]
    if ptrs:
        print("     pointer entries -> targets:")
        for v in q:
            po = off(v)
            if po is None or v < 0x180000000:
                continue
            tva, tsec = va_of(po)
            head = struct.unpack_from("<8I", d, po)
            e = d.find(b"\0", po, po + 60)
            s = d[po:e] if 0 < e else b""
            asc = s.decode("latin1") if re.match(rb"[\x20-\x7e]{3,}\Z", s) else ""
            print("        %#x (%s) u32[8]=%s %s" % (v, tsec, list(head), ("str=%r" % asc) if asc else ""))

print()
print("=" * 100
      )
print("3. int ladders in .rdata near the CAM++ region (look for growth-rate / depth vectors)")
print("=" * 100)
# scan a window around the two tables for short runs of small ints -- typical config vectors
lo, hi = off(0x1837DE000), off(0x1837DE600)
o = lo
while o + 4 <= hi:
    vals = struct.unpack_from("<32I", d, o) if o + 128 <= hi else ()
    run = []
    for v in vals:
        if 1 <= v <= 512:
            run.append(v)
        else:
            break
    if len(run) >= 4:
        va, _ = va_of(o)
        print("  %-12X  %s" % (va, run))
        o += 4 * len(run)
    else:
        o += 4
