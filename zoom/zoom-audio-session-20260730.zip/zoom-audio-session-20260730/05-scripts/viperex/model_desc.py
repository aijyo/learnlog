"""off_1837DE1C0 is a MODEL DESCRIPTOR: {const void** blobs, const int* dims, float inline[]}.

SNAC's names came with sizes. Here there are no names -- but if the blobs are laid out consecutively,
then consecutive pointer DIFFERENCES are the blob byte counts, and that is the same information:

    blob_bytes / 4 = float count = out * in   (or out, for a bias/BN vector)

So: enumerate every such descriptor in .data, follow its blob array, and print the size ladder.
Then match the ladder against the dims array to label which blob is which layer.
"""
import re
import struct
from collections import OrderedDict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()
DATA = next(s for s in SECS if s[0] == ".data")


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


def sec_of(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return nm
    return None


def ptr_run(va, limit=4096):
    """Follow an array of pointers-into-.data; stop at the first non-pointer."""
    out, o = [], off(va)
    if o is None:
        return out
    for i in range(limit):
        if o + 8 > len(d):
            break
        p = struct.unpack_from("<Q", d, o + 8 * i)[0]
        if p < 0x180000000 or sec_of(p) is None:
            break
        out.append(p)
    return out


def int_run(va, limit=256):
    out, o = [], off(va)
    if o is None:
        return out
    for i in range(limit):
        v = struct.unpack_from("<I", d, o + 4 * i)[0]
        if not (1 <= v <= 1 << 17):
            break
        out.append(v)
    return out


print("=" * 108)
print("A. the two descriptors seen so far, read out fully")
print("=" * 108)
for desc in (0x1837DE1C0, 0x1837E1380):
    o = off(desc)
    blobs_p, dims_p = struct.unpack_from("<QQ", d, o)
    print("\n### descriptor @%X   blobs->%X   dims->%X" % (desc, blobs_p, dims_p))
    dims = int_run(dims_p)
    print("    dims[%d] = %s" % (len(dims), dims))
    blobs = ptr_run(blobs_p)
    print("    blob pointers: %d" % len(blobs))
    if not blobs:
        continue
    su = sorted(set(blobs))
    print("    %-4s %-14s %-11s %-11s  %s" % ("#", "VA", "bytes", "floats", "factorisations of float count"))
    for i, p in enumerate(blobs):
        nxt = min([q for q in su if q > p], default=None)
        nb = (nxt - p) if nxt else 0
        nf = nb // 4
        fac = ""
        if nf:
            fs = [(a, nf // a) for a in dims if a and nf % a == 0 and nf // a <= 4096]
            fac = ", ".join("%d x %d" % t for t in fs[:6]) or "-"
        print("    %-4d %-14X %-11d %-11d  %s" % (i, p, nb, nf, fac))

print()
print("=" * 108)
print("B. every descriptor of this shape in .data  (ptr,ptr where 2nd target is an int ladder)")
print("=" * 108)
lo, hi = DATA[3], min(DATA[3] + DATA[2], len(d) - 16)
found = []
o = lo
while o + 16 <= hi:
    a, b = struct.unpack_from("<QQ", d, o)
    if (a > 0x180000000 and b > 0x180000000 and sec_of(a) and sec_of(b)):
        dims = int_run(b, 64)
        blobs = ptr_run(a, 2048)
        if len(dims) >= 4 and len(blobs) >= 4 and all(v <= 8192 for v in dims):
            va = DATA[1] + (o - DATA[3])
            found.append((va, a, b, dims, blobs))
            o += 16
            continue
    o += 8

print("descriptors found: %d\n" % len(found))
print("%-14s %-8s %-8s  %s" % ("VA", "#blobs", "#dims", "dims"))
print("-" * 108)
for va, a, b, dims, blobs in found:
    print("%-14X %-8d %-8d  %s" % (va, len(blobs), len(dims), dims[:22]))

# total float payload per descriptor -> parameter count, which identifies the model
print()
print("%-14s %-10s %-14s  %s" % ("VA", "#blobs", "span bytes", "~params (span/4)"))
print("-" * 108)
for va, a, b, dims, blobs in found:
    su = sorted(set(blobs))
    span = su[-1] - su[0] if len(su) > 1 else 0
    print("%-14X %-10d %-14d  %d" % (va, len(blobs), span, span // 4))
