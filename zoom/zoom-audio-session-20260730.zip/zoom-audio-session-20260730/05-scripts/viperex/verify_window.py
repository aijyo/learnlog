"""Reconstruct Zoom's STFT analysis/synthesis window pair and check it is self-consistent.

This is the feedback loop for the batch-B reading. If either half-Hann period or index offset were
misread, the window would be discontinuous at the 352-sample joint. Continuity + the peak landing
exactly on the joint + both periods being exactly 2*len+1 is what makes the reading trustworthy.

Run:  python verify_window.py
"""
import math

FRAME, HOP = 512, 160
RISE_LEN, RISE_PERIOD = 352, 705          # sqrt(hann) rising half
FALL_LEN, FALL_PERIOD, FALL_FROM = 160, 321, 160   # sqrt(hann) falling half
SYN_OFFSET, SYN_LEN, SYN_PERIOD = 192, 320, 321


def hann(i, period):
    return 0.5 - 0.5 * math.cos(i * 2.0 * math.pi / period)


def analysis():
    w = []
    for i in range(RISE_LEN):
        w.append(math.sqrt(hann(i, RISE_PERIOD)))
    for k in range(FALL_LEN):
        w.append(math.sqrt(hann(FALL_FROM + k, FALL_PERIOD)))
    return w


def synthesis(ana):
    s = [0.0] * FRAME
    for k in range(SYN_LEN):
        i = SYN_OFFSET + k
        s[i] = hann(k, SYN_PERIOD) / ana[i] if ana[i] > 1e-9 else 0.0
    return s


def main():
    w = analysis()
    assert len(w) == FRAME, len(w)
    assert RISE_PERIOD == 2 * RISE_LEN + 1 and FALL_PERIOD == 2 * FALL_LEN + 1

    joint = RISE_LEN
    print("length            %d  (= %d + %d)" % (len(w), RISE_LEN, FALL_LEN))
    print("periods           %d = 2*%d+1 and %d = 2*%d+1"
          % (RISE_PERIOD, RISE_LEN, FALL_PERIOD, FALL_LEN))
    print("w[0] w[%d] w[%d] w[%d]   %.6f %.6f %.6f %.6f"
          % (joint - 1, joint, FRAME - 1, w[0], w[joint - 1], w[joint], w[FRAME - 1]))
    print("joint discontinuity |w[%d]-w[%d]| = %.2e" % (joint, joint - 1, abs(w[joint] - w[joint - 1])))
    print("argmax            %d  (joint is %d)" % (max(range(FRAME), key=lambda i: w[i]), joint))
    assert abs(w[joint] - w[joint - 1]) < 1e-4, "DISCONTINUOUS -- a period or offset is misread"
    assert max(range(FRAME), key=lambda i: w[i]) == joint

    # the OLA sum of the squared window, over frame/hop + 1 terms
    terms = FRAME // HOP + 1
    ola = [sum(w[n + k * HOP] ** 2 for k in range(terms) if n + k * HOP < FRAME)
           for n in range(HOP)]
    print("OLA terms         %d  (frame/hop + 1)" % terms)
    print("OLA sum over hop  min %.4f  max %.4f  spread %.1f%%"
          % (min(ola), max(ola), 100.0 * (max(ola) - min(ola)) / max(ola)))

    s = synthesis(w)
    prod = [w[i] * s[i] for i in range(FRAME)]
    nz = [i for i, v in enumerate(s) if v != 0.0]
    print("synthesis nonzero  %d..%d  (%d samples)" % (nz[0], nz[-1], len(nz)))
    print("ana*syn over that range == hann(%d)?  max err %.2e"
          % (SYN_PERIOD, max(abs(prod[SYN_OFFSET + k] - hann(k, SYN_PERIOD))
                             for k in range(SYN_LEN))))
    print()
    print("look-ahead        %d samples = %.1f ms   (symmetric %d window would cost %.1f ms)"
          % (FALL_LEN, FALL_LEN / 16.0, FRAME, (FRAME // 2) / 16.0))
    print("ALL CHECKS PASS")


if __name__ == "__main__":
    main()
