"""Parse sub_1801FC100's push_back sequence into per-vector lists, then read the config structs.

The forward (sub_180205B20 -> sub_180203970 -> sub_180204260 -> sub_180204550) says exactly which
object offset holds what:

  block b views:  +240/+264 bottleneck {weight, config}   1 per layer
                  +288/+312 BN         {weights, configs} 2 configs per layer
                  +336/+360 CAM        {weights, configs} 5 weights, 3 configs per layer
  (block 2 -> +384..+504, block 3 -> +528..+648)
  transitions +672/+696, +720/+744, +768/+792 ; final CAM +816 ; embedding +840/+864 ; stem +192/+216

So: counts validate the reading (block1 CAM configs must be 3x12 = 36), and the pointed-to structs
give the kernel size / stride / dilation that the buffer sizes cannot reveal.
"""
import json
import re
import struct
from collections import OrderedDict

PE = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(PE, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


j = json.load(open(r"C:\Users\NCCTEC~1\AppData\Local\Temp\claude\D--code-work-research"
                   r"\d6fecc69-579f-40d8-a174-02301f47d2c5\scratchpad\dtdnn.json", encoding="utf-8"))
p = {x["ea"]: x for x in j["funcs"]}["1801FC100"]["pseudocode"]

# --- parse: track the active vector base, collect pushed symbol addresses in order ---
vec = OrderedDict()
cur = None
BASE = re.compile(r"=\s*(?:a1|v\d+)\s*\+\s*(\d+)\s*;")
SYM = re.compile(r"\b(?:qword|off|dword|byte|unk|xmmword)_([0-9A-F]{6,})\b")
for line in p.split("\n"):
    m = BASE.search(line)
    if m:
        q = int(m.group(1))
        # `a1` is _QWORD*, so `a1 + N` is byte offset 8N; `vN + k` stays in the same vector
        if re.search(r"=\s*a1\s*\+", line):
            cur = 8 * q
            vec.setdefault(cur, [])
        continue
    if cur is None:
        continue
    got = SYM.findall(line)
    if not got:
        continue
    a = int(got[0], 16)
    if not vec[cur] or vec[cur][-1] != a:
        vec[cur].append(a)

ROLE = {192: "stem weights", 216: "stem configs",
        240: "b1 bottleneck w", 264: "b1 bottleneck cfg", 288: "b1 BN w", 312: "b1 BN cfg",
        336: "b1 CAM w", 360: "b1 CAM cfg",
        384: "b2 bottleneck w", 408: "b2 bottleneck cfg", 432: "b2 BN w", 456: "b2 BN cfg",
        480: "b2 CAM w", 504: "b2 CAM cfg",
        528: "b3 bottleneck w", 552: "b3 bottleneck cfg", 576: "b3 BN w", 600: "b3 BN cfg",
        624: "b3 CAM w", 648: "b3 CAM cfg",
        672: "trans1 w", 696: "trans1 cfg", 720: "trans2 w", 744: "trans2 cfg",
        768: "trans3 w", 792: "trans3 cfg", 816: "final BN", 840: "embed w", 864: "embed cfg"}
EXPECT = {240: 12, 264: 12, 312: 24, 336: 60, 360: 36,
          384: 24, 408: 24, 456: 48, 480: 120, 504: 72,
          528: 16, 552: 16, 600: 32, 624: 80, 648: 48}

print("%-8s %-20s %-7s %-7s %s" % ("offset", "role", "count", "expect", "verdict"))
print("-" * 78)
for o in sorted(vec):
    n = len(vec[o])
    e = EXPECT.get(o)
    verdict = "" if e is None else ("OK" if n == e else "MISMATCH")
    print("%-8d %-20s %-7d %-7s %s" % (o, ROLE.get(o, "?"), n, e if e else "-", verdict))

print()
print("=" * 88)
print("config structs -- 8 ints at each address (the kernel / stride / dilation live here)")
print("=" * 88)
for o in (216, 360, 504, 648, 264, 408, 552, 312):
    if o not in vec or not vec[o]:
        continue
    print("\n--- offset %d (%s), first 9 of %d ---" % (o, ROLE.get(o, "?"), len(vec[o])))
    for a in vec[o][:9]:
        fo = off(a)
        if fo is None:
            print("   %X  (unmapped)" % a)
            continue
        print("   %X  %s" % (a, list(struct.unpack_from("<8i", d, fo))))
