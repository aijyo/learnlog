"""Scan the whole PE for weight-descriptor tables, not just SNAC's.

SNAC's table at off_180221980 cracked because each entry is {const char* name, type|size, void* data}
and the SIZES determine layer widths. If the other engines use the same layout, the same two lines of
arithmetic recover their dimensions too -- with no IDA run at all.

Strategy: slide a 24-byte window over .rdata/.data, and accept a run as a table when >= 8 consecutive
entries all have (a) a name pointer into a section, (b) a C identifier at that address, and (c) a data
pointer into a section or NULL. Then report each run with its name prefixes so I can tell which engine
it belongs to.
"""
import re
import struct
from collections import Counter, OrderedDict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()
print("sections: " + ", ".join("%s@%X(+%X)" % (n, v, s) for n, v, s, r in SECS))


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


IDENT = re.compile(rb"[A-Za-z_][A-Za-z0-9_]{2,79}\Z")


def ident_at(va):
    o = off(va)
    if o is None:
        return None
    e = d.find(b"\0", o, o + 80)
    if e < 0:
        return None
    s = d[o:e]
    return s.decode("latin1") if IDENT.match(s) else None


# ---- slide over every 8-aligned position in .rdata and .data ----
runs = []
for secname, sva, ssz, sraw in SECS:
    if secname not in (".rdata", ".data"):
        continue
    lo, hi = sraw, min(sraw + ssz, len(d))
    i = lo
    while i + 24 <= hi:
        nm = ident_at(struct.unpack_from("<Q", d, i)[0]) if i + 8 <= hi else None
        if nm is None:
            i += 8
            continue
        # candidate start -- walk forward
        j, ents = i, []
        while j + 24 <= hi:
            npt, packed, dat = struct.unpack_from("<QQQ", d, j)
            n2 = ident_at(npt)
            if n2 is None:
                break
            if dat and off(dat) is None:
                break
            ents.append((n2, packed & 0xFFFFFFFF, (packed >> 32) & 0xFFFFFFFF, dat))
            j += 24
        if len(ents) >= 8:
            va = sva + (i - sraw)
            runs.append((va, secname, ents))
            i = j
        else:
            i += 8

print("\ndescriptor-table runs found: %d\n" % len(runs))
print("%-16s %-8s %-6s  %s" % ("VA", "section", "count", "name prefixes (top 6)"))
print("-" * 110)
for va, sec, ents in sorted(runs, key=lambda r: -len(r[2])):
    pre = Counter()
    for n, t, s, dat in ents:
        pre[re.split(r"[_0-9]", n)[0] or n[:6]] += 1
    top = ", ".join("%s x%d" % (k, v) for k, v in pre.most_common(6))
    print("%-16X %-8s %-6d  %s" % (va, sec, len(ents), top[:88]))

# ---- solve dimensions for every run that looks like weights ----
SUF = r"_(weights_int8|weights_idx|weights_float|weights|bias|subias|scale|diag|mean|var|beta|gamma)$"
print("\n\n================ dimension solve, per table ================")
for va, sec, ents in sorted(runs, key=lambda r: -len(r[2])):
    layers = OrderedDict()
    for n, t, s, dat in ents:
        m = re.search(SUF, n)
        if not m:
            continue
        layers.setdefault(n[:m.start()], {})[m.group(1)] = s
    if not layers:
        continue
    solved = 0
    lines = []
    for stem, p in layers.items():
        ow = next((p[k] // 4 for k in ("bias", "scale", "subias", "beta", "mean") if k in p), None)
        wk = next((k for k in ("weights_int8", "weights_float", "weights") if k in p), None)
        iw = None
        if ow and wk:
            n_el = p[wk] // (1 if wk == "weights_int8" else 4)
            if n_el % ow == 0:
                iw = n_el // ow
        if ow and iw:
            solved += 1
        lines.append("    %-30s out %-7s in %-9s  %s" % (stem, ow or "?", iw or "?", (wk or "-").replace("weights_", "")))
    print("\n--- table @%X (%s)  layers %d  solved %d ---" % (va, sec, len(layers), solved))
    for L in lines:
        print(L)
