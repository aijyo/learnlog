"""Find EVERY weight-blob pointer array in .data, and attribute each to a model via .text xrefs.

Every TorchCpp model must have an array of pointers to its tensors -- that is how the forward pass
reaches them. Consecutive pointer differences give per-tensor byte sizes, so each array yields a full
layer ladder with no IDA run. Attribution comes from which .text address does
`lea reg, [rip+disp32]` onto the array.
"""
import re
import struct
from collections import Counter, defaultdict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()
S = {s[0]: s for s in SECS}
TEXT, DATA, RDATA = S[".text"], S[".data"], S[".rdata"]


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


def sec_of(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return nm
    return None


# ---------- 1. blob pointer arrays ----------
lo, hi = DATA[3], min(DATA[3] + DATA[2], len(d) - 8)
arrays, o = [], lo
while o + 8 <= hi:
    p = struct.unpack_from("<Q", d, o)[0]
    if p < 0x180000000 or sec_of(p) not in (".data", ".rdata"):
        o += 8
        continue
    ptrs, j = [], o
    while j + 8 <= hi:
        q = struct.unpack_from("<Q", d, j)[0]
        if q < 0x180000000 or sec_of(q) not in (".data", ".rdata"):
            break
        ptrs.append(q)
        j += 8
    if len(ptrs) >= 10:
        arrays.append((DATA[1] + (o - DATA[3]), ptrs))
        o = j
    else:
        o += 8

# ---------- 2. .text -> data VA xrefs, via lea reg,[rip+disp32] ----------
xref = defaultdict(list)
tlo, thi = TEXT[3], min(TEXT[3] + TEXT[2], len(d) - 8)
i = tlo
while i + 7 <= thi:
    if d[i] in (0x48, 0x4C) and d[i + 1] == 0x8D and (d[i + 2] & 0xC7) == 0x05:
        disp = struct.unpack_from("<i", d, i + 3)[0]
        nxt = TEXT[1] + (i + 7 - TEXT[3])
        xref[nxt + disp].append(nxt - 7)
        i += 7
        continue
    i += 1

print("blob pointer arrays (>=10 entries) in .data: %d" % len(arrays))
print("lea-materialised data VAs: %d\n" % len(xref))

print("%-14s %-7s %-11s %-11s  %-28s %s" % ("array VA", "#ptrs", "span B", "~params", "size ladder (floats)", "xrefs"))
print("-" * 132)
for va, ptrs in sorted(arrays, key=lambda a: -len(a[1])):
    su = sorted(set(ptrs))
    if len(su) < 3:
        continue
    sizes = []
    for p in ptrs:
        nxt = min([q for q in su if q > p], default=None)
        sizes.append(((nxt - p) // 4) if nxt else 0)
    span = su[-1] - su[0]
    # compress the ladder for display
    comp, run = [], None
    for s in sizes:
        if run and run[0] == s:
            run[1] += 1
        else:
            if run:
                comp.append(run)
            run = [s, 1]
    if run:
        comp.append(run)
    lad = " ".join("%d%s" % (s, ("x%d" % n) if n > 1 else "") for s, n in comp)
    xr = xref.get(va, [])
    print("%-14X %-7d %-11d %-11d  %-28s %s"
          % (va, len(ptrs), span, span // 4, lad[:28],
             " ".join("%X" % a for a in xr[:4]) or "(none)"))
    if len(lad) > 28:
        print("%s   ladder: %s" % (" " * 14, lad))

# ---------- 3. what references the one known descriptor ----------
print()
print("=" * 100)
print("xrefs to the descriptor 1837DE1C0 and its two arrays")
print("=" * 100)
for t in (0x1837DE1C0, 0x1837DDE60, 0x1837DE0A0, 0x1837E1380):
    print("  %-12X <- %s" % (t, " ".join("%X" % a for a in xref.get(t, [])) or "(no lea)"))
