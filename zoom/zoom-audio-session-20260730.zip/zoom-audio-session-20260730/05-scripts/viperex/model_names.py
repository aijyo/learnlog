"""Which models do viperex.dll's 42.8 MB of weights belong to -- and is one of them a denoiser?

The RTTI list named AEC / SED / PVAD / speaker models and no NS model, but RTTI only covers classes
with virtual functions, so absence there is weak evidence. Strings are the second witness: a loader,
a config parser, or a log line usually names the model and its layers.

Two questions, both falsifiable:
  1. Is there any string naming a noise-suppression / denoise / enhancement model? (If yes, my
     "no neural NS" reading is wrong again.)
  2. How much of .rdata is float-weight-shaped, i.e. how big is the neural budget really?
"""
import re
import struct

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()
BASE = 0x180000000
RD_VA, RD_OFF, RD_SZ = 0x18021F000, 0x21D800, 0x28F5400

print("=== strings: model / task names ===")
PROBES = [
    b"noise", b"Noise", b"NOISE", b"denoise", b"Denoise", b"DeNoise", b"suppress", b"Suppress",
    b"enhance", b"Enhance", b"speech_enh", b"SpeechEnh", b"mask", b"Mask", b"irm", b"IRM",
    b"aec", b"Aec", b"AEC", b"echo", b"Echo", b"sed", b"Sed", b"SED", b"pvad", b"PVad", b"PVAD",
    b"campp", b"Campp", b"CAMPP", b"diariz", b"Diariz", b"emb", b"Emb",
    b"encoder", b"Encoder", b"decoder", b"Decoder", b"gru", b"GRU", b"lstm", b"LSTM",
    b"conv", b"Conv", b"BatchNorm", b"relu", b"ReLU", b"sigmoid", b"Sigmoid", b"softmax",
    b"model", b"Model", b"weight", b"Weight", b"q16", b"Q16", b"quant", b"Quant",
]
for p in sorted(set(PROBES)):
    n = d.count(p)
    if n:
        print("  %-14s x%d" % (p.decode(), n))

print("\n=== distinct printable strings mentioning the task words ===")
WORD = re.compile(rb"(noise|denois|suppress|enhanc|mask|aec|echo|sed|pvad|vad|campp|diariz|"
                  rb"encoder|decoder|gru|lstm|model|q16|quant)", re.I)
seen = set()
for m in re.finditer(rb"[\x20-\x7e]{6,160}", d):
    s = m.group(0)
    if WORD.search(s):
        t = s.decode("latin1").strip()
        # drop mangled C++ names and obvious machine-code noise
        if t.startswith(".?A") or "@@" in t:
            continue
        if sum(c.isalpha() or c in " _./-:" for c in t) < len(t) * 0.75:
            continue
        seen.add(t)
for t in sorted(seen)[:70]:
    print("  " + t[:150])

print("\n=== how much of .rdata looks like float32 weights? ===")
# Weight-shaped: a run of float32 where every value is finite and |v| < 16, and the run is long.
rd = d[RD_OFF:RD_OFF + RD_SZ]
n = len(rd) // 4
vals = struct.unpack_from("<%df" % n, rd, 0)
good = 0
run = 0
runs = []
for v in vals:
    ok = (v == v) and abs(v) < 16.0 and (v == 0.0 or abs(v) > 1e-12)
    if ok:
        run += 1
    else:
        if run >= 256:
            runs.append(run)
            good += run
        run = 0
if run >= 256:
    runs.append(run)
    good += run
print("  .rdata            %.1f MB" % (RD_SZ / 1048576))
print("  float-shaped runs %d  covering %.1f MB (%.0f%% of .rdata)"
      % (len(runs), good * 4 / 1048576, 100.0 * good * 4 / RD_SZ))
runs.sort(reverse=True)
print("  largest runs (float count): " + ", ".join(str(r) for r in runs[:12]))
