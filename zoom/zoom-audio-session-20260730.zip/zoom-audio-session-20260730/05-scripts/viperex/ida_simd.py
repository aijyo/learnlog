# Does the denoise path actually execute a conv net? Measure SIMD/FMA density.
#
# A 257->257 U-Net spec exists in .rdata, but a spec is not execution. Conv kernels have an
# unmistakable signature at the instruction level: tight loops dominated by packed multiply-add
# (vfmadd*, mulps/addps, vmulps/vaddps) with high density per instruction. Scalar DSP does not.
#
# So: for the denoise call graph, rank functions by packed-FMA density. If nothing scores, the net
# spec is dead config and the processing really is scalar DSP.
import collections
import json
import idc
import idautils
import ida_funcs
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'simd.json'
idc.auto_wait()

FMA = ('vfmadd', 'vfmsub', 'vfnmadd')
PACKED = ('mulps', 'addps', 'subps', 'mulpd', 'addpd', 'vmulps', 'vaddps', 'vsubps',
          'vmulpd', 'vaddpd', 'dpps', 'vdpps', 'haddps', 'vhaddps', 'pmaddwd', 'vpmaddwd',
          'pmulld', 'vpmulld', 'pmaddubsw', 'vpmaddubsw')
SCALAR = ('mulss', 'addss', 'subss', 'divss', 'sqrtss', 'vmulss', 'vaddss')

CANDIDATES = [0x1800E4340, 0x1800BBEE0, 0x180014E80, 0x1800E61D0, 0x1800E74C0, 0x1800E0910,
              0x1800E27C0, 0x1800E21F0, 0x1800E1CB0, 0x180001CD0, 0x1800041D0, 0x1800035C0,
              0x180006720, 0x180005DD0, 0x1800045B0, 0x180015D40, 0x18008E370, 0x180007CD0,
              0x1800056F0, 0x1800E2F00, 0x1800E7BA0, 0x1800E8BC0]


def prof(fe):
    f = ida_funcs.get_func(fe)
    if not f:
        return None
    c = collections.Counter()
    n = 0
    for ea in idautils.FuncItems(f.start_ea):
        m = idc.print_insn_mnem(ea).lower()
        if not m:
            continue
        n += 1
        if any(m.startswith(p) for p in FMA):
            c['fma'] += 1
        elif m in PACKED or any(m.startswith(p) for p in PACKED):
            c['packed'] += 1
        elif m in SCALAR or any(m.startswith(p) for p in SCALAR):
            c['scalar_f'] += 1
    return {'ea': hex(f.start_ea), 'name': ida_name.get_ea_name(f.start_ea) or hex(f.start_ea),
            'size': f.end_ea - f.start_ea, 'insns': n,
            'fma': c['fma'], 'packed': c['packed'], 'scalar_f': c['scalar_f'],
            'vec_pct': round(100.0 * (c['fma'] + c['packed']) / n, 2) if n else 0}


rows = [r for r in (prof(e) for e in CANDIDATES) if r]

# also: scan the WHOLE module for the top FMA-density functions, to find the kernels wherever they are
allrows = []
for fea in idautils.Functions(0x180001000, 0x18021F000):
    r = prof(fea)
    if r and (r['fma'] + r['packed']) >= 12:
        allrows.append(r)
allrows.sort(key=lambda r: -(r['fma'] + r['packed']))

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump({'denoise_path': sorted(rows, key=lambda r: -r['vec_pct']),
               'module_top_kernels': allrows[:30]}, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
