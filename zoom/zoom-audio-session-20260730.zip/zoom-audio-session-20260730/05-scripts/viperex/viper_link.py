"""Is the NS module in viper.dll driven by the neural detectors in viperex.dll?

Hypothesis under test: the suppressor I reimplemented is only the BACK END (Wiener gain + WebRTC-NS
threshold estimator). Its aggressiveness is set by a speech-presence / sound-event probability that a
CNN in viperex.dll computes. If so, viper.dll must reach viperex.dll's detector exports.

Falsifiable: if viper.dll neither imports from viperex.dll nor names it anywhere, the two are separate
worlds and this hypothesis is dead.
"""
import struct

BASE = r"D:\code\work\zoom-bin-analysis\re-work"


def pe(path):
    d = open(path, "rb").read()
    e_lfanew = struct.unpack_from("<I", d, 0x3C)[0]
    assert d[e_lfanew:e_lfanew + 4] == b"PE\0\0", path
    nsec = struct.unpack_from("<H", d, e_lfanew + 6)[0]
    opt_sz = struct.unpack_from("<H", d, e_lfanew + 20)[0]
    opt = e_lfanew + 24
    magic = struct.unpack_from("<H", d, opt)[0]
    ddir = opt + (112 if magic == 0x20B else 96)
    secs = []
    off = opt + opt_sz
    for i in range(nsec):
        b = off + i * 40
        name = d[b:b + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, b + 8)
        secs.append((name, va, vsz, raw, rsz))

    def rva2off(rva):
        for name, va, vsz, raw, rsz in secs:
            if va <= rva < va + max(vsz, rsz):
                return raw + (rva - va)
        return None

    dirs = [struct.unpack_from("<II", d, ddir + 8 * i) for i in range(16)]
    return d, secs, dirs, rva2off


def imports(path):
    d, secs, dirs, r2o = pe(path)
    out = {}
    rva, size = dirs[1]
    if not rva:
        return out
    off = r2o(rva)
    i = 0
    while True:
        ent = off + i * 20
        oft, tds, fwd, namerva, fthunk = struct.unpack_from("<IIIII", d, ent)
        if namerva == 0 and fthunk == 0:
            break
        no = r2o(namerva)
        dll = d[no:d.index(b"\0", no)].decode("latin1")
        funcs = []
        t = r2o(oft or fthunk)
        j = 0
        while t is not None:
            v = struct.unpack_from("<Q", d, t + j * 8)[0]
            if v == 0:
                break
            if not (v >> 63):
                fo = r2o(v & 0x7FFFFFFF)
                if fo is not None:
                    nm = d[fo + 2:d.index(b"\0", fo + 2)].decode("latin1")
                    funcs.append(nm)
            j += 1
        out[dll] = funcs
        i += 1
    return out


def exports(path):
    d, secs, dirs, r2o = pe(path)
    rva, size = dirs[0]
    if not rva:
        return []
    off = r2o(rva)
    nnames = struct.unpack_from("<I", d, off + 24)[0]
    anames = struct.unpack_from("<I", d, off + 32)[0]
    if not anames:
        return []
    t = r2o(anames)
    out = []
    for i in range(nnames):
        nr = struct.unpack_from("<I", d, t + 4 * i)[0]
        no = r2o(nr)
        out.append(d[no:d.index(b"\0", no)].decode("latin1"))
    return out


for mod in ("viper.dll", "viperex.dll"):
    p = BASE + "\\" + mod
    print("=" * 74)
    print(mod)
    ex = exports(p)
    print("  exports: %d" % len(ex))
    for e in ex[:40]:
        print("      " + e[:112])
    im = imports(p)
    print("  imports from %d DLLs:" % len(im))
    for dll, fs in sorted(im.items()):
        mark = "   <<<< CROSS-LINK" if "viper" in dll.lower() else ""
        print("      %-30s %3d%s" % (dll, len(fs), mark))
        if "viper" in dll.lower():
            for f in fs:
                print("            " + f[:112])

# Does either module merely NAME the other (LoadLibrary / delay-load / log text)?
print("=" * 74)
print("cross-references by name:")
for mod in ("viper.dll", "viperex.dll"):
    d = open(BASE + "\\" + mod, "rb").read()
    for probe in (b"viperex", b"viperex.dll", b"viper.dll", b"LoadLibrary"):
        n = d.count(probe)
        if n:
            print("  %-14s contains %-16s x%d" % (mod, probe.decode(), n))
