"""Read SNAC's two config profiles straight out of viper.dll -- this settles the bitrate.

Field map, from the print statements in the config initialiser:
    a1+268 SNAC_PAYLOAD_TYPE       a1+280 SNAC_CODEBOOK_SIZE   (bits per code -- see below)
    a1+272 SNAC_NUM_20MS_PER_FRM   a1+284 SNAC_CODES_PER_FRMS
    a1+276 SNAC_MAX_CODEBOOK_NUM   a1+288 SNAC_SEND_FREQ
                                   a1+292 SNAC_REPEAT_TIME

The initialiser writes them as one 16-byte + one 8-byte + one 4-byte constant, and there are TWO
profiles selected by a flag:

    if (flag) { xmmword_1803B8918 ; qword_1803B8928 ; dword_1803B8930 }
    else      { xmmword_18035C8E4 ; 0x3200000002    ; 1               }

CODEBOOK_SIZE is in BITS, not entries -- the code computes
    bits  = CODEBOOK_SIZE * CODES_PER_FRMS
    bytes = (bits + 7) / 8
so multiplying it by the code count yields a bit budget, which only makes sense if it is a bit width.
"""
import struct

P = r"D:\code\work\zoom-bin-analysis\re-work\viper.dll"
d = open(P, "rb").read()

pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
opt = struct.unpack_from("<H", d, pe + 20)[0]
base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
SECS = []
for i in range(nsec):
    o = pe + 24 + opt + 40 * i
    nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
    vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
    SECS.append((nm, base + va, max(vsz, rsz), raw))


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


print("image base %X, sections: %s" % (base, ", ".join(s[0] for s in SECS)))
print()

FIELDS = ["PAYLOAD_TYPE", "NUM_20MS_PER_FRM", "MAX_CODEBOOK_NUM", "CODEBOOK_SIZE",
          "CODES_PER_FRMS", "SEND_FREQ", "REPEAT_TIME"]

PROFILES = [
    ("profile A (flag set)", 0x1803B8918, 0x1803B8928, 0x1803B8930),
    ("profile B (default / flag clear)", 0x18035C8E4, None, None),
]

results = {}
for label, xva, qva, dva in PROFILES:
    xo = off(xva)
    if xo is None:
        print("%-34s xmmword %X 不在映射段内" % (label, xva))
        continue
    quad = list(struct.unpack_from("<4I", d, xo))          # 268,272,276,280
    if qva is not None:
        qo = off(qva)
        pair = list(struct.unpack_from("<2I", d, qo)) if qo is not None else [None, None]
        do_ = off(dva)
        rep = struct.unpack_from("<I", d, do_)[0] if do_ is not None else None
    else:
        pair = [0x3200000002 & 0xFFFFFFFF, (0x3200000002 >> 32) & 0xFFFFFFFF]   # literals
        rep = 1
    vals = quad + pair + [rep]
    results[label] = vals
    print("=== %s ===" % label)
    for k, v in zip(FIELDS, vals):
        print("    %-18s %s" % ("SNAC_" + k, v))
    # derived
    cb_bits, codes, freq = vals[3], vals[4], vals[5]
    if cb_bits and codes:
        bits = cb_bits * codes
        print("    " + "-" * 52)
        print("    每帧比特   CODEBOOK_SIZE x CODES_PER_FRMS = %d x %d = %d bit" % (cb_bits, codes, bits))
        print("    每帧字节   (bits + 7) / 8 = %d byte" % ((bits + 7) // 8))
        if vals[1]:
            ms = 20 * vals[1]
            print("    帧长       NUM_20MS_PER_FRM = %d  =>  %d ms" % (vals[1], ms))
            print("    码率       %d bit / %d ms = %.0f bit/s = %.2f kbps"
                  % (bits, ms, bits * 1000.0 / ms, bits / ms))
        if freq:
            print("    发送频率   SEND_FREQ = %d /s  =>  %d bit/s = %.2f kbps"
                  % (freq, bits * freq, bits * freq / 1000.0))
        print("    重复调度   SEND_FREQ x (REPEAT_TIME + 1) - 1 = %d x %d - 1 = %d 个包位"
              % (freq, (vals[6] or 0) + 1, freq * ((vals[6] or 0) + 1) - 1))
    print()

print("=" * 70)
print("其他直接读出的量")
print("=" * 70)
for label, vals in results.items():
    n20 = vals[1]
    if n20:
        print("  %-34s malloc(1920 x %d) = %d 字节的输入缓冲" % (label, n20, 1920 * n20))
        print("  %-34s   1920 字节/20ms 单元 = 960 int16 @48kHz,或 480 float @24kHz" % "")
        print("  %-34s malloc(4 x %d) 的码字索引数组,初值 memset 为 -1" % ("", vals[2]))
