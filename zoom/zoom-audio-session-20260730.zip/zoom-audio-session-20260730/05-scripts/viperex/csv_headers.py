"""Zoom's own CSV telemetry headers name the pipeline's internal quantities.

A release build that logs `FrameNumber,micVol,echo,agcMode,...` is telling us the exact per-frame
state of the capture chain -- which stages exist and in what order. That is worth more than reading
three functions, so pull every comma-separated header out of viper.dll and viperex.dll intact.
"""
import re

for mod in ("viper.dll", "viperex.dll"):
    d = open(r"D:\code\work\zoom-bin-analysis\re-work\%s" % mod, "rb").read()
    print("=" * 78)
    print(mod)
    seen = set()
    # a CSV header: >=4 comma-separated identifier-ish tokens, no spaces around commas
    for m in re.finditer(rb"[A-Za-z_][A-Za-z0-9_.%\[\]]{1,40}(,[A-Za-z_][A-Za-z0-9_.%\[\]]{1,40}){3,80}", d):
        s = m.group(0).decode("latin1")
        if s in seen:
            continue
        seen.add(s)
        n = s.count(",") + 1
        print("\n  [%d fields] %s" % (n, s[:1400]))
