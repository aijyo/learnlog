# Which code owns viperex.dll's weight blobs?
#
# The weights are float arrays in .rdata described by {ptr,count} tables. Whoever references those
# addresses is the model that uses them -- that is the shortest path from "38 MB of floats exist" to
# "this specific module is the denoiser". Also walks up one caller level, because weights are usually
# referenced from a ctor/loader that the processing entry calls.
#
# Usage: idat64 -A "-Sida_weight_owner.py <out.json>" viperex.dll.i64
import json
import idc
import idautils
import ida_funcs
import ida_bytes
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'owner.json'
idc.auto_wait()

TARGETS = [0x1804CC880, 0x1804D0080, 0x1804D0880, 0x1805D2880, 0x180DD2C80,
           0x180E13880, 0x182B15000, 0x1804CC700]


def fname(ea):
    f = ida_funcs.get_func(ea)
    if not f:
        return None, None
    nm = ida_name.get_ea_name(f.start_ea) or hex(f.start_ea)
    return hex(f.start_ea), nm


def strings_of(fstart):
    out = []
    f = ida_funcs.get_func(fstart)
    if not f:
        return out
    for ea in idautils.FuncItems(f.start_ea):
        for xr in idautils.DataRefsFrom(ea):
            s = ida_bytes.get_strlit_contents(xr, -1, 0)
            if s and 3 < len(s) < 120:
                out.append(s.decode('utf-8', 'replace'))
    return out[:14]


res = {}
for t in TARGETS:
    refs = []
    for xr in idautils.DataRefsTo(t):
        fs, nm = fname(xr)
        if fs is None:
            refs.append({'from': hex(xr), 'func': None})
            continue
        callers = []
        for c in idautils.CodeRefsTo(int(fs, 16), 0):
            cfs, cnm = fname(c)
            if cfs:
                callers.append(cnm)
        refs.append({'from': hex(xr), 'func': nm, 'func_ea': fs,
                     'strings': strings_of(int(fs, 16)),
                     'callers': sorted(set(callers))[:8]})
    res[hex(t)] = refs

# Second pass: the model-family ctors found via the factory -- what strings and weight refs do they
# have? This names each of the 18 denoise model variants.
FAMILY = [0x18008D230, 0x1800DF9B0, 0x18008B790, 0x18003E0E0, 0x18003E120,
          0x18003E160, 0x1800B7630, 0x1800186B0, 0x180001CD0, 0x18000B530]
fam = {}
for fe in FAMILY:
    f = ida_funcs.get_func(fe)
    if not f:
        fam[hex(fe)] = {'missing': True}
        continue
    dref = []
    for ea in idautils.FuncItems(f.start_ea):
        for xr in idautils.DataRefsFrom(ea):
            if 0x180220000 <= xr < 0x182B15000:
                dref.append(hex(xr))
    fam[hex(fe)] = {'name': ida_name.get_ea_name(f.start_ea),
                    'size': f.end_ea - f.start_ea,
                    'strings': strings_of(fe),
                    'rdata_refs': sorted(set(dref))[:40],
                    'n_rdata_refs': len(set(dref))}

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump({'targets': res, 'family': fam}, fh, indent=1, ensure_ascii=False)

idc.qexit(0)
