# viperex.dll 分析脚本

对应 [`../../NOTES.md`](../../NOTES.md) §19 与
[`learnlog/zoom-neural-audio-plugin-viperex.html`](../../../../learnlog/zoom-neural-audio-plugin-viperex.html)。

目标二进制:`D:\code\work\zoom-bin-analysis\re-work\viperex.dll`(Zoom 7.1.0.41345, 66.6 MB)。
IDA 脚本跑在已建好的 `viperex.dll.i64` 上,单次 1–4 s。

## 环境

```powershell
$env:IDA_EXE    = "D:\solft\IDA Pro 7.5.20.1028 SP3 Portable + All decompilers (Windows)\IDA Pro 7.5.20.1028 SP3 Portable\idat64.exe"
$env:IDA_PYHOME = "C:\Users\CT10266\AppData\Local\Programs\Python\Python39"
```

IDA 脚本统一经 `binary-to-cpp` skill 的 `run_ida.ps1` 启动(它会把带空格的路径转成 8.3 短路径,
否则 `idat64 -S"<script> <args>"` 的空格分割会坏掉):

```powershell
& "$env:USERPROFILE\.claude\skills\binary-to-cpp\scripts\run_ida.ps1" `
    -Idb "D:\code\work\zoom-bin-analysis\re-work\viperex.dll.i64" `
    -Script .\ida_arch.py -Out out\arch.json -ScriptArgs "" -TimeoutSec 900
```

## 纯 Python(不需要 IDA,直接读 PE 字节)

| 脚本 | 回答什么 |
|---|---|
| `viperex_all_rtti.py` | 全部 169 个 RTTI 类,按 scope 分组,`TorchCpp` 模板实例化计数 |
| `viperex_nn.py` | 筛出模型/引擎类名(`AecNnModel`、`SedModelCalculator` …) |
| `weight_check.py` | **权重实证**:段属性 + 非零率 + distinct + BatchNorm 指纹。区分权重与 scratch 缓冲 |
| `model_names.py` | 任务词字符串扫荡 + `.rdata` 里 float32 游程占比(得出 94%) |
| `denoise_net.py` | 从 Xiph `nnet_data` 层名重建网络(认出 Opus DRED + FARGAN) |
| `viper_link.py` | PE 导入/导出表:证明 viper 不静态导入 viperex,是 `LoadLibrary` 插件 |

## IDA 脚本

| 脚本 | 回答什么 |
|---|---|
| `ida_dump_iface.py <out> <hex_ea> [n]` | dump 一张指针表/vtable,每槽解析函数名+大小+引用的字符串 |
| `ida_weight_owner.py` | 谁引用权重块(答案:只有描述符表,代码不直接引用) |
| `ida_strtab.py <out> <hex_ea> [n]` | dump `{name, dims, data}` 三元组表 |
| `ida_fingerprint.py <out> ea1,ea2,…` | **核心判别器**:callee 清单 + libm 调用 + 浮点字面量 + 权重引用数。经典 DSP vs 神经前向 |
| `ida_variants.py` | 18 个降噪变体各自的 vtable 与 slot-2 `process()` |
| `ida_reach.py` | 降噪调用图 ∩ 神经调用图(**结论:太松,不决定性**,见 NOTES §19.12) |
| `ida_arch.py` | **从 `TorchCpp` 模板参数直读架构**(80→40→20→10 纯编码器) |

## 动态(只读)

| 脚本 | 回答什么 |
|---|---|
| `probe_zoom.ps1` | 枚举 Zoom 进程的已加载模块 + 线程描述。证明 viperex 已映射、OpenVINO 未加载 |

> `probe_zoom.ps1` 只做只读观测(`THREAD_QUERY_LIMITED_INFORMATION`),不写内存、不注入。
> 线程名探测是**弱证据**:Zoom 80 个线程只有 2 个走了 `SetThreadDescription`(见 NOTES §19.7)。

## 关键地址速查(Zoom 7.1.0.41345 / viperex.dll,imagebase 0x180000000)

| 地址 | 是什么 |
|---|---|
| `0x1800141F0` | `viperex_init(host, out)` → `*out = &off_182B15000` |
| `0x180014230` | `viperex_version()` → `"7.1.0.41345"` |
| `0x182B15000` | 插件单例(CRT 初始化器 `sub_18021E2F0` 装配),`+0x60` 起是权重描述符 `{ptr,count}` |
| `0x180013D90` | `CreateProcessor(this, kind, out)`,kind 0..19 |
| `0x1800140D0` | 返回 `&off_180221980` = Xiph `nnet_data` 权重表 |
| `0x18000A0F0` | 降噪模块初始化 —— **尾部起 `DenoiseProcessThread`** |
| `0x18000B530` | 降噪线程体(每帧 3 路 ×160 采样) |
| `0x180001030` | 18 变体降噪模型工厂 |
| `0x180001CD0` | DSP 前端 `(obj, 512, 160)` |
| `0x182AF7028` | 模型 vtable(8 槽),槽 2 = `process` |
| `0x1800E4250` | `process(in, out)` 分发器 |
| `0x1800E4340` | **主处理 7821 B —— 下一个逆向目标** |
| `0x1800E6C30` | 配置(整块 dB 阈值/平滑系数常量) |
