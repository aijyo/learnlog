"""Inventory every SIMD-dispatched compute family in viperex.dll via the _C/_SSE2/_AVX suffixes.

The DTDNN_CAMDense win came from noticing that `_C` marks a scalar reference implementation, which is
always the readable one. So: enumerate ALL such families. That is a map of every compute class in the
binary, and it says directly which models still have an unread scalar reference sitting there.

Also hunts the AEC and PVAD vocabulary specifically, since those are the two open models.
"""
import re
from collections import defaultdict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()

names = sorted({m.group(0)[4:-2].decode("latin1")
                for m in re.finditer(rb"\.\?AV[A-Za-z0-9_@\?\$]{3,160}@@", d)})
print("total RTTI classes: %d" % len(names))

SUF = ("_C", "_SSE2", "_SSE", "_AVX", "_AVX2", "_AVX512", "_NEON")
fam = defaultdict(set)
plain = []
for n in names:
    base = n.split("@")[0]
    hit = None
    for s in SUF:
        if base.endswith(s):
            hit = s
            break
    if hit:
        fam[base[: -len(hit)]].add(hit)
    else:
        plain.append(base)

print("\nSIMD families (base name -> which variants exist): %d" % len(fam))
print("%-44s %-30s %s" % ("family", "variants", "has scalar _C?"))
print("-" * 92)
for k in sorted(fam):
    v = fam[k]
    print("%-44s %-30s %s" % (k, " ".join(sorted(v)), "YES" if "_C" in v else "-- no scalar!"))

print("\n\nclasses with NO SIMD suffix (interfaces, processors, plain objects): %d" % len(plain))
KEY = re.compile(r"[Aa]ec|[Ee]cho|PVAD|Pvad|[Pp]ick|[Vv]ad|Denois|[Nn]s[A-Z]|Suppress|Gain|Agc|"
                 r"Beam|Filter|Resid|Linear|Adapt|Delay|Coher")
for n in plain:
    if KEY.search(n):
        print("   " + n)
