"""For each dispatch table, decide WHICH of its three installers is the scalar one.

This matters more than it looks. My existing denoise slot map has slot 1 = sub_1800F4B50, which is the
first kernel of installer 1800FB5A0 -- the MIDDLE of the three. If that installer is a SIMD variant,
then the one denoise kernel I ever read was a vectorised implementation, which would explain why its
field semantics never resolved.

Decide it by measurement, not by address order: count VEX-prefixed (AVX) and legacy-SSE opcodes in each
installer's kernels. The scalar reference has (almost) none.
"""
import struct
from collections import defaultdict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()
TEXT = next(s for s in SECS if s[0] == ".text")


def sec_of(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return nm
    return None


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return raw + (va - v)
    return None


# ---- rebuild the installer -> (slot, kernel) map ----
hits = []
lo, hi = TEXT[3], min(TEXT[3] + TEXT[2], len(d) - 16)
i = lo
while i + 14 <= hi:
    if d[i] in (0x48, 0x4C) and d[i + 1] == 0x8D and (d[i + 2] & 0xC7) == 0x05:
        nxt = TEXT[1] + (i + 7 - TEXT[3])
        fva = nxt + struct.unpack_from("<i", d, i + 3)[0]
        for k in range(7, 15):
            j = i + k
            if j + 7 > hi:
                break
            if d[j] in (0x48, 0x4C) and d[j + 1] == 0x89 and (d[j + 2] & 0xC7) == 0x05:
                nxt2 = TEXT[1] + (j + 7 - TEXT[3])
                sva = nxt2 + struct.unpack_from("<i", d, j + 3)[0]
                if sec_of(fva) == ".text" and sec_of(sva) in (".data", ".rdata"):
                    hits.append((TEXT[1] + (i - TEXT[3]), sva, fva))
                break
        i += 7
        continue
    i += 1

hits.sort()
clusters, cur = [], []
for h in hits:
    if cur and h[0] - cur[-1][0] > 96:
        clusters.append(cur)
        cur = []
    cur.append(h)
if cur:
    clusters.append(cur)
big = [c for c in clusters if len(c) >= 8]

# group installers by the table they write
bytab = defaultdict(list)
for c in big:
    slots = sorted({h[1] for h in c})
    bytab[slots[0]].append(c)


def isa_mix(va, limit=1400):
    """Count VEX (AVX) and legacy-SSE opcode bytes in a code window."""
    o = off(va)
    if o is None:
        return None
    end = min(o + limit, len(d))
    vex = sse = tot = 0
    i = o
    while i < end:
        b = d[i]
        if b in (0xC4, 0xC5):                      # VEX 3-byte / 2-byte -> AVX
            vex += 1
            i += 2
            tot += 1
            continue
        if b in (0x66, 0xF2, 0xF3) and i + 2 < end and d[i + 1] == 0x0F:
            sse += 1
            i += 3
            tot += 1
            continue
        if b == 0x0F and i + 1 < end and d[i + 1] in (
                0x10, 0x11, 0x28, 0x29, 0x51, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5C, 0x5E, 0x5D,
                0x5F, 0x2A, 0x2C, 0x2D, 0x2E, 0x2F, 0xC6, 0x14, 0x15, 0x16, 0x12, 0x13):
            sse += 1
            i += 2
            tot += 1
            continue
        i += 1
        tot += 1
    return vex, sse, tot


print("%-12s %-8s %-13s %-7s %-7s %-8s %s"
      % ("table", "#slots", "installer", "AVX", "SSE", "bytes", "verdict"))
print("-" * 96)
scalar_of = {}
for tab in sorted(bytab):
    grp = sorted(bytab[tab], key=lambda c: c[0][0])
    if len(grp) < 2:
        continue
    rows = []
    for c in grp:
        # sample the 3 largest-address kernels this installer writes, to average out stubs
        ks = sorted({h[2] for h in c})
        agg = [0, 0, 0]
        for k in ks[:4]:
            m = isa_mix(k)
            if m:
                agg = [a + b for a, b in zip(agg, m)]
        rows.append((c[0][0], agg, len(sorted({h[1] for h in c}))))
    best = min(rows, key=lambda r: (r[1][0] * 10 + r[1][1]))
    scalar_of[tab] = best[0]
    for site, (vex, sse, tot), n in rows:
        v = "<== SCALAR" if site == best[0] else ("AVX" if vex > sse else "SSE")
        print("%-12X %-8d %-13X %-7d %-7d %-8d %s" % (tab, n, site, vex, sse, tot, v))
    print()

print("=" * 96)
print("scalar installer per table:")
for t, s in sorted(scalar_of.items()):
    print("   table %X  ->  installer %X" % (t, s))

# ---- the denoise table specifically ----
DEN = 0x183C37450
if DEN in bytab:
    print()
    print("=" * 96)
    print("DENOISE table %X: slot -> kernel, per installer" % DEN)
    print("=" * 96)
    for c in sorted(bytab[DEN], key=lambda c: c[0][0]):
        site = c[0][0]
        m = {h[1]: h[2] for h in c}
        tag = "SCALAR" if site == scalar_of.get(DEN) else "simd"
        print("\n--- installer %X (%s), %d slots ---" % (site, tag, len(m)))
        for sva in sorted(m):
            print("   slot[%2d] @%X  ->  sub_%X" % ((sva - DEN) // 8, sva, m[sva]))
