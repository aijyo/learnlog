"""Find the SNAC inference class family, and with it the scalar reference implementation.

The cross-project notes name `SnacInferenceEncoderAVX` and the interface `webrtc::ISnacEncoder`. If the
same ISA-triplet convention holds as for the CAM++ / denoise families, there is a scalar sibling whose
driver code states the things the descriptor table cannot: number of quantisation stages, codebook size,
per-stage stride, frame geometry, and therefore the bitrate.

Positive control first -- searching binaries with the wrong tool silently returns nothing.
"""
import os
import re

BINS = [r"D:\code\work\zoom-bin-analysis\re-work\viper.dll",
        r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll",
        r"D:\code\work\zoom-bin-analysis\re-work\libcml.dll",
        r"D:\code\work\zoom-bin-analysis\re-work\viper_async_device.dll"]

data = {}
for b in BINS:
    if os.path.exists(b):
        data[os.path.basename(b)] = open(b, "rb").read()

print("=" * 100)
print("阳性对照")
print("=" * 100)
ok = False
for probe in (rb"DTDNN_CAMDense", rb"CamppCalculator"):
    hits = {k: len(re.findall(probe, v)) for k, v in data.items() if re.search(probe, v)}
    print("  %-20s %s" % (probe.decode(), hits or "*** 未命中 ***"))
    if hits:
        ok = True
if not ok:
    raise SystemExit("阳性对照失败,先修工具")
print("  -> 通过\n")

print("=" * 100)
print("SNAC / 声纹 / Opus 相关的 RTTI 类名(全 DLL)")
print("=" * 100)
KEY = re.compile(r"Snac|SNAC|SpeakerEmb|Campp|Picknet|OSD|Opus|Codec|Encoder|Decoder|Quant|Codebook|RVQ")
for name, d in data.items():
    cls = sorted({m.group(1).decode("latin1")
                  for m in re.finditer(rb"\.\?AV([A-Za-z0-9_@\?\$]{3,110})@@", d)})
    hit = [c for c in cls if KEY.search(c)]
    print("\n### %s  (RTTI 类 %d 个,匹配 %d 个)" % (name, len(cls), len(hit)))
    for c in hit:
        print("      " + c)

print()
print("=" * 100)
print("SNAC 相关的裸字符串(非 RTTI)——可能带配置键与日志")
print("=" * 100)
for name, d in data.items():
    found = []
    for m in re.finditer(rb"[ -~]{6,90}", d):
        s = m.group(0)
        if re.search(rb"[Ss]nac|SNAC", s):
            t = s.decode("latin1")
            if t not in found:
                found.append(t)
    if found:
        print("\n### %s (%d 条)" % (name, len(found)))
        for t in found[:40]:
            print("      " + t)
