"""Attribute the 5 unowned dispatch tables by finding each scalar installer's caller.

For the denoise table the ISA-selection site was 1800E6C7B, inside the denoise processor. So: find the
`call rel32` sites for all 21 installers, group them, and the selection site's address tells me which
module owns each table. Then, for extra signal, look for the nearest RTTI class-name string and the
nearest log string before that site.
"""
import re
import struct
from collections import defaultdict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()
TEXT = next(s for s in SECS if s[0] == ".text")


def sec_of(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return nm
    return None


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return raw + (va - v)
    return None


TABLES = {
    0x183C37450: ("40", 0x1800FB5A0, 0x1800F1140, 0x180104DA0, "denoise net (known)"),
    0x183C36E90: ("39", 0x1800D0A80, 0x1800C6B30, 0x1800D9D40, "?"),
    0x183C35F70: ("35", 0x1800B1180, 0x18009B260, 0x1800A81B0, "?"),
    0x183C387B0: ("30", 0x180120080, 0x180127840, 0x180131670, "AEC (known)"),
    0x183C35150: ("19", 0x180051580, 0x1800457D0, 0x180058110, "?"),
    0x183C35EE0: ("13", 0x180083210, 0x180080797, 0x180084DE7, "?"),
    0x183C35DF0: ("10", 0x18006ECD0, 0x180069D30, 0x180072FF0, "?"),
}
WANT = {}
for tab, (n, sc, avx, sse, own) in TABLES.items():
    for ea, tag in ((sc, "scalar"), (avx, "avx"), (sse, "sse")):
        WANT[ea] = (tab, n, tag)

# ---- find call rel32 sites ----
calls = defaultdict(list)
lo, hi = TEXT[3], min(TEXT[3] + TEXT[2], len(d) - 5)
i = lo
while i + 5 <= hi:
    if d[i] == 0xE8:
        nxt = TEXT[1] + (i + 5 - TEXT[3])
        tgt = nxt + struct.unpack_from("<i", d, i + 1)[0]
        if tgt in WANT:
            calls[tgt].append(nxt - 5)
    i += 1

# ---- all RTTI class names with their VAs, to find the nearest one to a site ----
rtti = []
for m in re.finditer(rb"\.\?AV([A-Za-z0-9_@\?\$]{3,120})@@", d):
    va = None
    for nm, v, sz, raw in SECS:
        if raw <= m.start() < raw + sz:
            va = v + (m.start() - raw)
    if va:
        rtti.append((va, m.group(1).decode("latin1")))
rtti.sort()

# ---- readable strings in .rdata, for the nearest-log-string signal ----
strs = []
for m in re.finditer(rb"[ -~]{12,120}\x00", d):
    va = None
    for nm, v, sz, raw in SECS:
        if nm in (".rdata", ".data") and raw <= m.start() < raw + sz:
            va = v + (m.start() - raw)
    if va:
        strs.append((va, m.group(0)[:-1].decode("latin1")))
strs.sort()


def near_strings_referenced_from(site, span=0x1200):
    """Strings lea'd within +/- span bytes of the selection site -- names the owning module."""
    o = off(site)
    out = []
    for j in range(max(0, o - span), min(len(d) - 7, o + span)):
        if d[j] in (0x48, 0x4C) and d[j + 1] == 0x8D and (d[j + 2] & 0xC7) == 0x05:
            nxt = TEXT[1] + (j + 7 - TEXT[3])
            t = nxt + struct.unpack_from("<i", d, j + 3)[0]
            if sec_of(t) in (".rdata", ".data"):
                to = off(t)
                if to is None:
                    continue
                e = d.find(b"\0", to, to + 120)
                if e > to + 8:
                    ss = d[to:e]
                    if re.fullmatch(rb"[ -~]{9,}", ss):
                        out.append(ss.decode("latin1"))
    return out


print("%-12s %-6s %-9s %-13s %s" % ("table", "slots", "installer", "ISA site", "owner"))
print("-" * 108)
sites = {}
for tab in sorted(TABLES, key=lambda t: -int(TABLES[t][0])):
    n, sc, avx, sse, own = TABLES[tab]
    sc_sites = calls.get(sc, [])
    site = sc_sites[0] if sc_sites else None
    sites[tab] = site
    print("%-12X %-6s %-9X %-13s %s"
          % (tab, n, sc, ("%X" % site) if site else "(no direct call)", own))

print()
print("=" * 108)
print("strings referenced near each ISA-selection site -- this names the module")
print("=" * 108)
for tab in sorted(TABLES, key=lambda t: -int(TABLES[t][0])):
    site = sites.get(tab)
    if not site:
        continue
    ss = near_strings_referenced_from(site)
    uniq = []
    for x in ss:
        if x not in uniq:
            uniq.append(x)
    print("\n### table %X (%s slots) site %X  -- %s" % (tab, TABLES[tab][0], site, TABLES[tab][4]))
    for x in uniq[:10]:
        print("      %s" % x[:104])
    if not uniq:
        print("      (no strings nearby)")
