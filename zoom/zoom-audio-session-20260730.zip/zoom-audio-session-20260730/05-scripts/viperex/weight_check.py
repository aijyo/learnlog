"""Are the {float*, count} blobs in viperex.dll real weights, or just scratch buffers?

Decisive test: scratch buffers live in uninitialised data (zeros on disk, or outside the file's raw
range). Weights must be present byte-for-byte in the file. So map each RVA to a file offset, name its
section, and look at the actual float values -- weights are small, mixed-sign, non-repeating.

This matters because it is the difference between "Zoom ships a neural net" and "I found a memset".
The last time I inferred an algorithm from an allocation size (sub_1801C9980's 46 KB) I was wrong.
"""
import struct

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()

e = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, e + 6)[0]
opt_sz = struct.unpack_from("<H", d, e + 20)[0]
opt = e + 24
base = struct.unpack_from("<Q", d, opt + 24)[0]
secs = []
so = opt + opt_sz
for i in range(nsec):
    b = so + i * 40
    nm = d[b:b + 8].rstrip(b"\0").decode("latin1")
    vsz, va, rsz, raw = struct.unpack_from("<IIII", d, b + 8)
    ch = struct.unpack_from("<I", d, b + 36)[0]
    secs.append((nm, va, vsz, raw, rsz, ch))

print("image base 0x%X" % base)
print("%-10s %-12s %-12s %-12s %-12s %s" % ("sect", "VA", "vsize", "rawptr", "rawsize", "flags"))
for nm, va, vsz, raw, rsz, ch in secs:
    print("%-10s 0x%-10X 0x%-10X 0x%-10X 0x%-10X %s%s%s" % (
        nm, base + va, vsz, raw, rsz,
        "R" if ch & 0x40000000 else "-",
        "W" if ch & 0x80000000 else "-",
        " UNINIT" if ch & 0x00000080 else ""))


def locate(va):
    rva = va - base
    for nm, sva, vsz, raw, rsz, ch in secs:
        if sva <= rva < sva + max(vsz, rsz):
            in_raw = rva - sva < rsz
            return nm, (raw + (rva - sva)) if in_raw else None, bool(ch & 0x80)
    return None, None, None


# The {ptr, count} pairs read out of the interface struct.
PAIRS = [(0x1804CC880, 0xE00), (0x1804D0080, 0x200), (0x1804D0880, 0x40000),
         (0x1805D0880, 0x200), (0x1805D1080, 0x200), (0x1805D1880, 0x200),
         (0x1805D2080, 0x200), (0x1805D2880, 0x200000), (0x180DD2880, 0x100),
         (0x180DD2C80, 0x10000), (0x180E12C80, 0x100), (0x180E13080, 0x100),
         (0x180E13480, 0x100), (0x180E13880, 0x700), (0x180E15480, 0x100),
         (0x180E15880, 0x100), (0x180E15C80, 0x100), (0x180E16080, 0x100)]

print("\n%-14s %-9s %-8s %-9s  %s" % ("VA", "count", "sect", "nonzero", "first floats"))
for va, cnt in PAIRS:
    nm, off, uninit = locate(va)
    if off is None:
        print("%-14X %-9d %-8s %-9s  (not in file image)" % (va, cnt, nm, "-"))
        continue
    n = min(cnt, 4096)
    vals = struct.unpack_from("<%df" % n, d, off)
    nz = sum(1 for v in vals if v != 0.0)
    show = " ".join("%+.5f" % v for v in vals[:6])
    print("%-14X %-9d %-8s %5.1f%%    %s" % (va, cnt, nm, 100.0 * nz / n, show))

print("\nsanity: distinct values and range over each blob's first 4096 floats")
for va, cnt in PAIRS[:8]:
    nm, off, uninit = locate(va)
    if off is None:
        continue
    n = min(cnt, 4096)
    vals = struct.unpack_from("<%df" % n, d, off)
    finite = [v for v in vals if -1e30 < v < 1e30]
    if not finite:
        print("  %X  no finite values" % va)
        continue
    print("  %X  distinct=%-6d min=%+.4f max=%+.4f mean=%+.5f" % (
        va, len(set(vals)), min(finite), max(finite), sum(finite) / len(finite)))
