# Is Zoom's neural audio plugin actually running -- or is it just present on disk?
#
# The previous session used "is openvino_c.dll in the module list?" as the observable for "is neural
# inference active?" That probe is blind to viperex.dll's two in-house engines (TorchCpp CNN, Xiph
# nnet sparse-int8), which are statically linked into viperex itself and need no external runtime.
#
# Two independent read-only observables instead:
#   1. loaded modules      -- is viperex.dll mapped at all?
#   2. thread descriptions -- SetThreadDescription names survive; DenoiseProcessThread existing means
#                             the denoise module was constructed and its worker started.
# Read-only: no writes, no injection, no handles beyond QUERY_LIMITED_INFORMATION.

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class TQ {
  [DllImport("kernel32.dll", SetLastError=true)]
  public static extern IntPtr OpenThread(int access, bool inherit, uint tid);
  [DllImport("kernel32.dll", SetLastError=true)]
  public static extern int GetThreadDescription(IntPtr h, out IntPtr desc);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll")] public static extern IntPtr LocalFree(IntPtr p);
  public const int QUERY_LIMITED = 0x0800;
  public static string Name(uint tid) {
    IntPtr h = OpenThread(QUERY_LIMITED, false, tid);
    if (h == IntPtr.Zero) return null;
    try {
      IntPtr p;
      int hr = GetThreadDescription(h, out p);
      if (hr < 0 || p == IntPtr.Zero) return null;
      try { return Marshal.PtrToStringUni(p); } finally { LocalFree(p); }
    } finally { CloseHandle(h); }
  }
}
'@

$procs = Get-Process -Name "Zoom" -ErrorAction SilentlyContinue
foreach ($p in $procs) {
  Write-Output ("==== PID {0}  {1} MB  {2} threads ====" -f $p.Id, [math]::Round($p.WorkingSet64/1MB), $p.Threads.Count)

  $mods = @()
  try { $mods = $p.Modules | ForEach-Object { $_.ModuleName } } catch { Write-Output "  (module list unavailable)" }
  foreach ($probe in @('viper.dll','viperex.dll','libcml.dll','openvino_c.dll','openvino.dll','tbb.dll','tbb12.dll','onnxruntime.dll','DirectML.dll')) {
    $hit = $mods -contains $probe
    Write-Output ("  module {0,-20} {1}" -f $probe, $(if ($hit) { "LOADED" } else { "-" }))
  }

  $named = @{}
  foreach ($t in $p.Threads) {
    $n = $null
    try { $n = [TQ]::Name([uint32]$t.Id) } catch {}
    if ($n) { if (-not $named.ContainsKey($n)) { $named[$n] = 0 }; $named[$n]++ }
  }
  Write-Output ("  named threads: {0} distinct" -f $named.Count)
  foreach ($k in ($named.Keys | Sort-Object)) {
    $mark = ""
    if ($k -match 'Denois|Aec|SED|Sed|VAD|Vad|Campp|Diariz|Emb|Audio|Mic') { $mark = "   <<<<" }
    Write-Output ("      {0,-46} x{1}{2}" -f $k, $named[$k], $mark)
  }
}
