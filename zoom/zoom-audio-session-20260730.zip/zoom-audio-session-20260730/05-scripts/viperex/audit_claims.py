"""Audit my own claims about the recovered architectures, against the numbers rather than memory.

Three claims are checked, each with an explicit pass/fail:
  A. DenoiseNet: "field semantics RESOLVED -- cols[0]->cols[1] is the strided frequency axis".
     Test: does the conv output-size formula hold for every table under that reading, with the
     padding taken from cols[6]? If it needs a different pad per row, the reading is NOT resolved.
  B. SED: the eight cross-check constants.
  C. CAM++: does `groups == channels` actually discriminate between the two field readings, or did I
     talk myself into it the way I did with the malloc?
"""

DEN = {
    1:  (257, 128,   8,   3,  5, 2, 1, 2),
    2:  (128,  64,  16,   8,  5, 2, 1, 2),
    3:  ( 64,  32,  32,  16,  5, 2, 1, 2),
    4:  ( 32,  16,  64,   8,  5, 2, 1, 2),
    5:  ( 16,   8,  64,   1,  5, 2, 1, 2),
    6:  (  8,   8,  64,  64,  1, 1, 0, 0),
    7:  (  4,   1, 128,  64,  5, 4, 1, 2),
    10: (  1,   4,  64, 128,  3, 1, 1, 1),
    12: (  8,  16,  32,  64,  3, 1, 1, 1),
    14: ( 16,  32,  32,  32,  3, 1, 1, 1),
    16: ( 32,  64,  16,  32,  3, 1, 1, 1),
    18: ( 64, 128,  16,  32,  3, 1, 1, 1),
    20: (128, 258,   8,   8,  3, 1, 1, 2),
    21: (258, 257,   1,   4,  1, 1, 1, 1),
}

print("=" * 78)
print("A. DenoiseNet -- is cols[0]->cols[1] a strided conv axis?")
print("   out = (in + 2*pad - dil*(k-1) - 1)/stride + 1")
print()
print("%-5s %-14s %-6s %-6s %-5s %-5s %-6s %-9s %s"
      % ("table", "in->out", "k", "stride", "p6", "d7", "pred", "pad needed", "verdict"))
print("-" * 92)
ok_p6 = fail_p6 = 0
needed = []
for t, c in sorted(DEN.items()):
    fin, fout, k, s, p, d = c[0], c[1], c[4], c[5], c[6], c[7]
    pred = (fin + 2 * p - d * (k - 1) - 1) // s + 1
    # what pad WOULD be needed to land on fout?
    need = None
    for pp in range(0, 9):
        if (fin + 2 * pp - d * (k - 1) - 1) // s + 1 == fout:
            need = pp
            break
    good = pred == fout
    ok_p6 += good
    fail_p6 += (not good)
    needed.append(need)
    print("%-5d %-14s %-6d %-6d %-5d %-5d %-6d %-9s %s"
          % (t, "%d->%d" % (fin, fout), k, s, p, d, pred,
             "n/a" if need is None else str(need), "OK" if good else "MISMATCH"))
print()
print("  with pad = cols[6]:  %d OK / %d MISMATCH" % (ok_p6, fail_p6))
uniq = sorted({n for n in needed if n is not None})
print("  pads that WOULD be needed, per row: %s" % uniq)
print()
if fail_p6 == 0:
    print("  VERDICT: the reading is confirmed by the stride arithmetic.")
elif len(uniq) <= 1:
    print("  VERDICT: one consistent pad explains every row -- reading plausible, cols[6] mis-assigned.")
else:
    print("  VERDICT: NO single pad convention fits. The LADDER is read; the AXIS and the padding")
    print("           convention are NOT confirmed. Calling this 'resolved' was an over-claim.")

print()
print("=" * 78)
print("B. SED -- the eight cross-check constants")
print()
sed = [(1, 25, (3, 5), (1, 2)), (25, 20, (3, 5), (1, 1)), (20, 10, (5, 5), (2, 2))]
shape = (100, 40)
checks = []
h, w = shape
dims = []
for cin, cout, (kh, kw), (sh, sw) in sed:
    h = (h - kh) // sh + 1
    w = (w - kw) // sw + 1
    dims.append((cout, h, w))
checks.append(("L1 out 98x18", dims[0][1:] == (98, 18)))
checks.append(("L2 out 96x14", dims[1][1:] == (96, 14)))
checks.append(("L3 out 46x5", dims[2][1:] == (46, 5)))
checks.append(("1764 == 98*18 (L2 in-ch stride)", 98 * 18 == 1764))
checks.append(("1344 == 96*14 (L3 in-ch stride)", 96 * 14 == 1344))
checks.append(("750  == 25*15*2 (L2 wt stride => 3x5)", 25 * 15 * 2 == 750))
checks.append(("1000 == 20*25*2 (L3 wt stride => 5x5)", 20 * 25 * 2 == 1000))
checks.append(("1288 == 46*(14*2) (L3 row bound)", 46 * 28 == 1288))
checks.append(("2300 == 10*46*5 (dequant count)", 10 * 46 * 5 == 2300))
checks.append(("4000 == 100*40 (quant loop 1000x4)", 100 * 40 == 4000))
checks.append(("9200 == 2300*4 (0x23F0, 3 buffers)", 2300 * 4 == 9200))
for name, good in checks:
    print("  %-42s %s" % (name, "OK" if good else "FAIL"))
print("  => %d/%d" % (sum(1 for _, g in checks if g), len(checks)))

print()
print("=" * 78)
print("C. CAM++ -- does `groups == channels` discriminate the two field readings?")
print()
CAMPP = [
    ("Conv2dTd<80,80,1,32,   1,1,1,0,1,0,1>",  80, 80, 1, 32, 1),
    ("Conv2dTd<80,80,1,1,    3,1,1,1,1,0,1>",  80, 80, 1, 1, 1),
    ("Conv2dTd<80,40,32,32,  1,2,1,0,1,0,32>", 80, 40, 32, 32, 32),
    ("Conv2dTd<40,40,32,32,  3,1,1,1,1,0,32>", 40, 40, 32, 32, 32),
    ("Conv2dTd<20,10,32,32,  3,2,1,1,1,0,32>", 20, 10, 32, 32, 32),
    ("Conv2dTd<10,10,32,32,  1,1,1,0,1,0,1>",  10, 10, 32, 32, 1),
]
print("%-42s %-28s %s" % ("template", "reading A (f_in,f_out,c_in,c_out)", "reading B (c_in,c_out,h,w)"))
print("-" * 104)
a_ok = b_ok = 0
for name, f0, f1, f2, f3, g in CAMPP:
    # A: fields = freq_in, freq_out, ch_in, ch_out  -> groups must divide ch_in and ch_out
    a = (f2 % g == 0) and (f3 % g == 0)
    # B: fields = ch_in, ch_out, h, w              -> groups must divide ch_in and ch_out
    b = (f0 % g == 0) and (f1 % g == 0)
    a_ok += a
    b_ok += b
    print("%-42s %-28s %s" % (name,
                              "groups %d | ch %d,%d  %s" % (g, f2, f3, "ok" if a else "IMPOSSIBLE"),
                              "groups %d | ch %d,%d  %s" % (g, f0, f1, "ok" if b else "IMPOSSIBLE")))
print()
print("  reading A: %d/%d consistent      reading B: %d/%d consistent" % (a_ok, len(CAMPP), b_ok, len(CAMPP)))
if a_ok == len(CAMPP) and b_ok < len(CAMPP):
    print("  VERDICT: groups DOES discriminate. Reading A holds; reading B is arithmetically impossible.")
else:
    print("  VERDICT: groups does NOT discriminate -- both readings survive. Claim must be softened.")
