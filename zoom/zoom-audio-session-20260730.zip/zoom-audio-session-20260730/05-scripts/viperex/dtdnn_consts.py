"""Read the D-TDNN per-stage config constants straight out of .data.

sub_180205B20 (DTDNN_CAMDense_C forward) passes a small config block to each stage:
    stem        &dword_183B61B34, qword_183B61B38
    transition1  byte_183B61B68,  qword_183B61B50
    transition2 &dword_183B61B6C, qword_183B61B70
    transition3  byte_183B61BA0,  qword_183B61B88
    CAM         &dword_183B61BA4
    pooling      byte_183B61BA8
    embedding   &dword_183B61BAC, qword_183B61BB0
These are compile-time constants, so they are readable with no IDA at all.
"""
import struct

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()


def sections():
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    nsec = struct.unpack_from("<H", d, pe + 6)[0]
    opt = struct.unpack_from("<H", d, pe + 20)[0]
    base = struct.unpack_from("<Q", d, pe + 24 + 24)[0]
    out = []
    for i in range(nsec):
        o = pe + 24 + opt + 40 * i
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
        out.append((nm, base + va, max(vsz, rsz), raw))
    return out


SECS = sections()


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


LO, HI = 0x183B61B20, 0x183B61BE0
o = off(LO)
print("=== .data %X .. %X, the DTDNN stage config block ===" % (LO, HI))
print("%-12s %-12s %-14s %-14s %s" % ("VA", "u32", "as i32", "as f32", "note"))
print("-" * 92)
NOTES = {
    0x183B61B34: "stem: sub_180206350 arg",
    0x183B61B38: "stem: qword arg",
    0x183B61B50: "transition1 qword",
    0x183B61B68: "transition1 byte",
    0x183B61B6C: "transition2 dword",
    0x183B61B70: "transition2 qword",
    0x183B61B88: "transition3 qword",
    0x183B61BA0: "transition3 byte",
    0x183B61BA4: "CAM: sub_180204B20 channel count",
    0x183B61BA8: "pooling: sub_180206130 byte",
    0x183B61BAC: "embedding: sub_180205750 dword",
    0x183B61BB0: "embedding: qword",
}
va = LO
while va < HI:
    u = struct.unpack_from("<I", d, off(va))[0]
    f = struct.unpack_from("<f", d, off(va))[0]
    fs = "%.6g" % f if 1e-8 < abs(f) < 1e8 else ""
    print("%-12X %-12d %-14d %-14s %s" % (va, u, struct.unpack_from("<i", d, off(va))[0], fs,
                                          NOTES.get(va, "")))
    va += 4

print()
print("=== the qword args, followed as pointers ===")
for q in (0x183B61B38, 0x183B61B50, 0x183B61B70, 0x183B61B88, 0x183B61BB0):
    p = struct.unpack_from("<Q", d, off(q))[0]
    tgt = off(p) if p > 0x180000000 else None
    if tgt is None:
        print("  %X -> %#x  (not a pointer)" % (q, p))
        continue
    u32 = struct.unpack_from("<12I", d, tgt)
    f32 = struct.unpack_from("<12f", d, tgt)
    print("  %X -> %X" % (q, p))
    print("       u32: %s" % " ".join(str(v) if v < (1 << 20) else "%#x" % v for v in u32))
    print("       f32: %s" % " ".join("%.5g" % v for v in f32))
