# Which of the 18 denoise-model variants is neural, and which is classic DSP?
#
# Each variant ctor assigns a vtable; vtable slot 2 is process(in,out) (established from the thread
# loop). So: for every ctor, find the vtable it installs, take slot 2, and fingerprint it.
#
# Discriminator (from the one variant already read):
#   classic DSP -> many small float literals, calls sqrtf/powf/expf, ZERO refs into the weight region
#   neural      -> refs into the big .rdata weight blobs, few literals, repeated big kernel calls
#
# The weight region is taken as .rdata above the layer-name table, i.e. >= 0x1804CC700, since that is
# where the measured 94%-float span lives.
import json
import struct
import idc
import idautils
import ida_funcs
import ida_bytes
import ida_name
import ida_ua

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'variants.json'
idc.auto_wait()

WLO, WHI = 0x1804CC700, 0x182B15000          # measured weight span in .rdata
RLO, RHI = 0x18021F000, 0x183C3A000          # all of .rdata

CTORS = {
    'kind0': 0x18003E160, 'kind2': 0x18003E120, 'kind5': 0x18003E0E0,
    'kind4': 0x18008D230, 'kind6/7/9/0xD/0xF/0x10': 0x18008B790,
    'kind0xA/0xB/0xC/0xE': 0x1800DF9B0, 'default(3)': 0x1800B7630,
    'kind0x11(null)': 0x1800186B0,
}


def find_vtable(fe):
    """First store of an .rdata pointer into [reg] at function start = the vtable install."""
    f = ida_funcs.get_func(fe)
    if not f:
        return None
    for ea in list(idautils.FuncItems(f.start_ea))[:60]:
        for xr in idautils.DataRefsFrom(ea):
            if RLO <= xr < RHI:
                # a vtable's first qword must point at code
                q = ida_bytes.get_qword(xr)
                if q and ida_funcs.get_func(q):
                    return xr
    return None


def fingerprint(fe):
    f = ida_funcs.get_func(fe)
    if not f:
        return {'missing': True}
    wrefs, floats, callees, libm = [], [], {}, {}
    for ea in idautils.FuncItems(f.start_ea):
        for cr in idautils.CodeRefsFrom(ea, 0):
            g = ida_funcs.get_func(cr)
            if g and g.start_ea != f.start_ea:
                n = ida_name.get_ea_name(g.start_ea) or hex(g.start_ea)
                callees[n] = callees.get(n, 0) + 1
                if n.strip('_') in ('sqrtf', 'powf', 'expf', 'logf', 'exp', 'log', 'sqrt',
                                    'atan', 'cos', 'sin', 'tanhf', 'atanf'):
                    libm[n] = libm.get(n, 0) + 1
        for xr in idautils.DataRefsFrom(ea):
            if WLO <= xr < WHI:
                wrefs.append(hex(xr))
            if RLO <= xr < RHI:
                raw = ida_bytes.get_bytes(xr, 4)
                if raw and len(raw) == 4:
                    v = struct.unpack('<f', raw)[0]
                    if v == v and -1e6 < v < 1e6 and v != 0.0:
                        floats.append(round(v, 6))
    return {'ea': hex(f.start_ea), 'size': f.end_ea - f.start_ea,
            'weight_refs': sorted(set(wrefs))[:12], 'n_weight_refs': len(set(wrefs)),
            'n_float_lits': len(set(floats)), 'floats': sorted(set(floats))[:26],
            'libm': libm,
            'top_callees': sorted(callees.items(), key=lambda kv: -kv[1])[:10]}


res = {}
for label, ce in CTORS.items():
    vt = find_vtable(ce)
    entry = {'ctor': hex(ce), 'vtable': hex(vt) if vt else None}
    if vt:
        slots = []
        for i in range(8):
            q = ida_bytes.get_qword(vt + 8 * i)
            g = ida_funcs.get_func(q) if q else None
            slots.append({'slot': i, 'fn': hex(q) if q else None,
                          'size': (g.end_ea - g.start_ea) if g else 0})
        entry['slots'] = slots
        p = ida_bytes.get_qword(vt + 16)          # slot 2 = process
        if p and ida_funcs.get_func(p):
            entry['process'] = fingerprint(p)
    res[label] = entry

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(res, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
