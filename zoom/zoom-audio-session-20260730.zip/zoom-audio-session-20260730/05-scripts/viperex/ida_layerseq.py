# Extract the layer sequence of the denoise forward pass, in execution order.
#
# The runtime is generic: for each layer it copies a std::vector<void*> of params (sub_180001B90,
# source = this+OFF), then calls an ISA-dispatched kernel (qword_183C374xx) with a weight handle
# (this+WOFF). So walking the instructions in address order and recording, per basic-block-ish
# sequence, the (param_vector_offset, kernel_slot, weight_offset) triples gives the layer table --
# which is what a reimplementation needs.
#
# Done at the instruction level rather than on pseudocode text, because Hex-Rays reorders and the
# execution order is what matters.
import json
import idc
import idautils
import ida_funcs
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'layerseq.json'
idc.auto_wait()

TARGETS = [0x1800E4340, 0x1800E61D0, 0x1800E1CB0, 0x1800E21F0, 0x1800E27C0, 0x1800E0910]
VEC_COPY = 0x180001B90
TAB_LO, TAB_HI = 0x183C37440, 0x183C37600

res = {}
for fe in TARGETS:
    f = ida_funcs.get_func(fe)
    if not f:
        continue
    events = []
    for ea in idautils.FuncItems(f.start_ea):
        mnem = idc.print_insn_mnem(ea).lower()
        # lea rdx, [rcx+OFF]  -> the param-vector source, when followed by the vector copy
        for op in (0, 1, 2):
            t = idc.get_operand_type(ea, op)
            v = idc.get_operand_value(ea, op)
            if t == idc.o_displ and 3000 < v < 9000:
                events.append({'ea': hex(ea), 'kind': 'this_off', 'val': v,
                               'insn': idc.GetDisasm(ea)})
            elif t == idc.o_mem and TAB_LO <= v < TAB_HI:
                events.append({'ea': hex(ea), 'kind': 'kernel_slot', 'val': hex(v),
                               'slot': (v - 0x183C37450) // 8, 'insn': idc.GetDisasm(ea)})
        if mnem == 'call':
            tgt = idc.get_operand_value(ea, 0)
            if tgt == VEC_COPY:
                events.append({'ea': hex(ea), 'kind': 'VEC_COPY', 'val': None})
        if mnem in ('call', 'jmp') and idc.get_operand_type(ea, 0) == idc.o_mem:
            v = idc.get_operand_value(ea, 0)
            if TAB_LO <= v < TAB_HI:
                events.append({'ea': hex(ea), 'kind': 'KERNEL_CALL', 'val': hex(v),
                               'slot': (v - 0x183C37450) // 8})
    res[hex(fe)] = {'name': ida_name.get_ea_name(f.start_ea) or hex(f.start_ea),
                    'size': f.end_ea - f.start_ea,
                    'n_vec_copy': sum(1 for e in events if e['kind'] == 'VEC_COPY'),
                    'n_kernel_call': sum(1 for e in events if e['kind'] == 'KERNEL_CALL'),
                    'events': events}

with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump(res, fh, indent=1, ensure_ascii=False)
idc.qexit(0)
