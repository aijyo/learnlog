# Dump the plugin interface table viperex_init hands back to viper, and each slot's target.
#
# viperex_init does `*a2 = &off_182B15000` -- that pointer IS the contract between the two DLLs.
# Every slot is a factory/entry the host may call, so the table enumerates exactly which neural
# capabilities viper can request. Names come from RTTI-derived function names where IDA has them.
#
# Usage: idat64 -A "-Sida_dump_iface.py <out.json> <hex_ea> [count]" viperex.dll.i64
import json
import idc
import ida_funcs
import ida_bytes
import ida_name
import idautils

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'iface.json'
EA = int(idc.ARGV[2], 16) if len(idc.ARGV) > 2 else 0x182B15000
N = int(idc.ARGV[3]) if len(idc.ARGV) > 3 else 64

idc.auto_wait()

rows = []
for i in range(N):
    a = EA + 8 * i
    v = ida_bytes.get_qword(a)
    if v == 0 or not ida_bytes.is_loaded(v):
        rows.append({'slot': i, 'addr': hex(a), 'value': hex(v), 'name': None, 'note': 'not-code'})
        continue
    f = ida_funcs.get_func(v)
    nm = ida_name.get_ea_name(v) or ''
    dem = idc.demangle_name(nm, idc.get_inf_attr(idc.INF_SHORT_DN)) or nm
    row = {'slot': i, 'addr': hex(a), 'value': hex(v), 'name': dem,
           'is_func': bool(f), 'func_start': hex(f.start_ea) if f else None,
           'size': (f.end_ea - f.start_ea) if f else 0}
    # A factory usually news an object and stores a vtable; capture the strings it references so the
    # slot can be identified even with no symbol.
    strs = []
    if f:
        for ea in idautils.FuncItems(f.start_ea):
            for xr in idautils.DataRefsFrom(ea):
                s = ida_bytes.get_strlit_contents(xr, -1, 0)
                if s:
                    try:
                        t = s.decode('utf-8', 'replace')
                    except Exception:
                        t = repr(s)
                    if 3 < len(t) < 120:
                        strs.append(t)
    row['strings'] = strs[:12]
    rows.append(row)

# Also: which RTTI-named classes have vtables, so the model classes can be located.
with open(OUT, 'w', encoding='utf-8') as fh:
    json.dump({'ea': hex(EA), 'rows': rows}, fh, indent=1, ensure_ascii=False)

idc.qexit(0)
