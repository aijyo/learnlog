"""Find the anchors for the audio stages that are still only string-level.

The end-to-end write-up has BODY-level detail on denoise and STR-level on everything else. To bring
the rest up to the same grade I need the actual functions, so first locate them: RTTI class names plus
the string families that name AEC / AGC / Opus / NetEQ / mixer / resampler code in viper.dll.
"""
import collections
import re

P = r"D:\code\work\zoom-bin-analysis\re-work\viper.dll"
d = open(P, "rb").read()

print("=== RTTI classes by stage ===")
names = set()
for m in re.finditer(rb"\.\?AV[\x20-\x7e]{3,240}?@@", d):
    names.add(m.group(0).decode("latin1"))


def pretty(n):
    parts = [p for p in n[4:-2].split("@") if p]
    return "::".join(reversed(parts)) if len(parts) > 1 else n[4:-2]


STAGES = {
    "AEC": r"Echo|Aec|AEC|Canceller|Delay|Erl|Erle|Suppressor",
    "AGC": r"Agc|AGC|GainControl|Limiter|Compress|Level",
    "codec": r"Opus|Codec|Encoder|Decoder|Snac|Acm|ACM|Payload|Red\b|Fec",
    "neteq": r"NetEq|NetEQ|Jitter|Buffer|Plc|Expand|Merge|Accelerate|Preemptive|TimeStretch|Dtmf",
    "mixer": r"Mixer|Mix|Output|Playout|Render|Resampl|Device",
    "vad": r"Vad|VAD|Cng|Cng|Dtx",
}
by = collections.defaultdict(set)
for n in names:
    p = pretty(n)
    for st, pat in STAGES.items():
        if re.search(pat, p):
            by[st].add(p)
for st in STAGES:
    v = sorted(by[st])
    print("\n[%s]  %d" % (st, len(v)))
    for x in v[:22]:
        print("    " + x[:110])

print("\n=== string families (counts) ===")
FAM = [b"EchoCanceller3", b"AEC3", b"aec3", b"EchoControlMobile", b"aecm", b"Aecm",
       b"AgcManagerDirect", b"AnalogAgc", b"agc2", b"Agc2", b"FixedDigital", b"AdaptiveDigital",
       b"opus_encoder_ctl", b"opus_encode", b"OPUS_SET", b"opus_multistream", b"libopus",
       b"NetEq", b"neteq", b"DecisionLogic", b"BufferLevelFilter", b"DelayManager",
       b"Accelerate", b"PreemptiveExpand", b"Expand", b"Merge", b"ComfortNoise",
       b"OutputMixer", b"AudioMixer", b"AudioFrameOperations", b"PushResampler", b"SincResampler",
       b"AudioProcessingImpl", b"ProcessStream", b"AnalyzeReverseStream",
       b"SetSendCodec", b"SetRecPayloadType", b"SetSendCodecOpus", b"SetBitRate", b"SetPacketSize",
       b"SetVAD", b"SetDtx", b"SetOpusMaxPlaybackRate", b"SetOpusDtx", b"EnableOpusDtx",
       b"SetComplexity", b"SetInBandFec", b"SetPacketLossRate"]
for f in FAM:
    c = d.count(f)
    if c:
        print("  %-28s x%d" % (f.decode(), c))

print("\n=== log/format strings that name parameters ===")
seen = set()
KEY = re.compile(rb"(bitrate|bit_rate|complexity|dtx|DTX|inband|packet_loss|plc|jitter|"
                 rb"target_level|buffer_level|playout|stretch|accelerate|preemptive|"
                 rb"echo|erl|erle|delay_ms|agc|gain_db|target_dbfs)", re.I)
for m in re.finditer(rb"[\x20-\x7e]{10,150}", d):
    s = m.group(0)
    if KEY.search(s):
        t = s.decode("latin1").strip()
        if t.startswith(".?A") or "@@" in t:
            continue
        if sum(ch.isalpha() or ch in " _.%-/[]():=," for ch in t) < len(t) * 0.8:
            continue
        seen.add(t)
for t in sorted(seen)[:60]:
    print("  " + t[:140])
