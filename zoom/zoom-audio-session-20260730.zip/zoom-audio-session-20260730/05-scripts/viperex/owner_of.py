"""Resolve 'which class owns this function' via the MSVC RTTI chain, in pure Python.

The call-graph climb failed for five of the seven init functions because they are reached through
vtables, so they have no code references at all. The MSVC layout gives a direct route instead:

    vtable[-1]  ->  complete object locator (COL)
    COL + 12    ->  type descriptor RVA  ->  ".?AV<class>@@"

So: find the function's address as a qword in .rdata/.data (that is a vtable slot), scan backwards to
the vtable start, read the COL, and print the class. Applied to each dispatch table's ISA-selection
function, this names the owner of every table.
"""
import re
import struct

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()

PE = struct.unpack_from("<I", d, 0x3C)[0]
NSEC = struct.unpack_from("<H", d, PE + 6)[0]
OPT = struct.unpack_from("<H", d, PE + 20)[0]
BASE = struct.unpack_from("<Q", d, PE + 24 + 24)[0]
SECS = []
for i in range(NSEC):
    o = PE + 24 + OPT + 40 * i
    nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
    vsz, va, rsz, raw = struct.unpack_from("<IIII", d, o + 8)
    SECS.append((nm, BASE + va, max(vsz, rsz), raw))


def off(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            o = raw + (va - v)
            return o if 0 <= o < len(d) else None
    return None


def sec_of(va):
    for nm, v, sz, raw in SECS:
        if v <= va < v + sz:
            return nm
    return None


def qword(va):
    o = off(va)
    return struct.unpack_from("<Q", d, o)[0] if o is not None and o + 8 <= len(d) else None


def dword(va):
    o = off(va)
    return struct.unpack_from("<I", d, o)[0] if o is not None and o + 4 <= len(d) else None


def type_name_from_td(td_va):
    o = off(td_va)
    if o is None:
        return None
    e = d.find(b"\0", o + 16, o + 16 + 160)
    if e < 0:
        return None
    s = d[o + 16:e]
    m = re.match(rb"\.\?AV([A-Za-z0-9_@\?\$]+)@@", s)
    return m.group(1).decode("latin1") if m else (s.decode("latin1", "replace") if s else None)


def owner_of(func_va, back=80):
    """Every vtable that contains func_va, with the class name from the COL."""
    key = struct.pack("<Q", func_va)
    out = []
    for m in re.finditer(re.escape(key), d):
        slot_va = None
        for nm, v, sz, raw in SECS:
            if nm in (".rdata", ".data") and raw <= m.start() < raw + sz:
                slot_va = v + (m.start() - raw)
        if slot_va is None:
            continue
        # walk back looking for vtable[-1] == pointer to a COL whose +12 is a type-descriptor RVA
        for k in range(0, back):
            vt = slot_va - 8 * k
            col = qword(vt - 8)
            if col is None or sec_of(col) not in (".rdata", ".data"):
                continue
            sig = dword(col)
            if sig is None or sig > 1:
                continue
            td_rva = dword(col + 12)
            if not td_rva:
                continue
            nm = type_name_from_td(BASE + td_rva)
            if nm and re.match(r"[A-Za-z_]", nm):
                out.append((nm, k, vt))
                break
    return out


TARGETS = [
    ("40 slots -- denoise (control)", 0x183C37450, 0x1800E6C30),
    ("30 slots -- AEC (control)", 0x183C387B0, 0x180116FC0),
    ("39 slots", 0x183C36E90, 0x1800BBB30),
    ("35 slots", 0x183C35F70, 0x180091CE0),
    ("19 slots", 0x183C35150, 0x1800454F0),
    ("13 slots", 0x183C35EE0, 0x1800800C0),
    ("10 slots", 0x183C35DF0, 0x180066250),
]

print("%-32s %-12s %-12s %s" % ("table", "table VA", "init func", "owning class :: vt[slot]"))
print("-" * 108)
for label, tab, fn in TARGETS:
    own = owner_of(fn)
    if own:
        for nm, k, vt in own[:3]:
            print("%-32s %-12X %-12X %s :: vt[%d]   (vtable @%X)" % (label, tab, fn, nm, k, vt))
    else:
        print("%-32s %-12X %-12X (not in any vtable -- trying neighbours)" % (label, tab, fn))
        # the init may be a helper; try functions immediately around it
        for delta in (-0x40, -0x30, -0x20, -0x10, 0x10, 0x20, 0x30, 0x40, 0x50, 0x60):
            o2 = owner_of(fn + delta)
            if o2:
                print("%-32s %-12s %-12X %s :: vt[%d]  (offset %+d)"
                      % ("", "", fn + delta, o2[0][0], o2[0][1], delta))
                break
