"""Extract each denoise kernel's SHAPE from its loop bounds and memset size.

Slot 3 turned out to be a shape-specialised quantised dense matmul: memset(out, 0, 0x400) = 512 int16,
loops 8 x 8 x 64, weights consumed 16 int16 per inner step, requantise (mult*acc + bias) >> 31 >> shift,
clamp to [-4095, 4096], then a table lookup for the activation.

If the 40 slots are shape specialisations of a few ops, then per kernel the tuple
    (memset bytes, loop bounds, weights-per-step, accumulator count, clamp range, LUT offset)
should repeat with different numbers. Extract it mechanically and see.
"""
import json
import re
from collections import Counter, OrderedDict

D = (r"C:\Users\NCCTEC~1\AppData\Local\Temp\claude\D--code-work-research"
     r"\d6fecc69-579f-40d8-a174-02301f47d2c5\scratchpad")
j = json.load(open(D + r"\dk_out.json", encoding="utf-8"))

SLOT = {"1800F4B50": 1, "1800F3050": 2, "1800F3910": 3, "1800F7D60": 13,
        "1800F5570": 37, "1800F3490": 38, "1800F76C0": 39,
        "1800C9030": "31-36", "1800EBE60": 11, "1800E61D0": "post-proc"}

print("%-12s %-8s %-9s %-16s %-8s %-6s %-16s %s"
      % ("kernel", "slot", "memset", "loop bounds", "w/step", "accs", "clamp", "LUT off"))
print("-" * 118)
rows = []
for f in j["funcs"]:
    ea = f["ea"].replace("0x", "").upper()
    p = f["pseudocode"]
    memset = sorted({int(m, 16) for m in re.findall(r"memset\([^,]+,\s*0,\s*0x([0-9A-Fa-f]+)", p)}
                    | {int(m) for m in re.findall(r"memset\([^,]+,\s*0,\s*(\d+)ui64", p)})
    bounds = sorted({int(m) for m in re.findall(r"while \(\s*\w+ [<!]=? (\d+)", p)}
                    | {int(m) for m in re.findall(r"v\d+ = (\d+)i64;", p)})
    wstep = sorted({int(m) for m in re.findall(r"result \+= (\d+)", p)}
                   | {int(m) for m in re.findall(r"\w+ \+= (\d+)i64;\s*$", p, re.M)})
    accs = len(set(re.findall(r"(v\d+) \+= v\d+ \* ", p)))
    clamp = sorted({int(m) for m in re.findall(r"= (-?\d{3,5});", p)})
    lut = sorted({int(m) for m in re.findall(r"\+ (\d{3,6})\)", p)})
    rows.append((ea, SLOT.get(ea, "?"), memset, bounds, wstep, accs, clamp, lut, len(p)))
    print("%-12s %-8s %-9s %-16s %-8s %-6d %-16s %s"
          % (ea, SLOT.get(ea, "?"),
             " ".join("%X" % v for v in memset[:2]) or "-",
             " ".join(str(v) for v in bounds[:5]) or "-",
             " ".join(str(v) for v in wstep[:3]) or "-",
             accs,
             " ".join(str(v) for v in clamp[:2]) or "-",
             " ".join(str(v) for v in lut[:2]) or "-"))

print()
print("=" * 118)
print("what repeats: the requantise + clamp + LUT idiom")
print("=" * 118)
IDIOM = [
    (r">> 31\) >> ", "Q31 requantise: (mult*acc + bias) >> 31 >> shift"),
    (r"-4095", "clamp low  -4095"),
    (r"4096", "clamp high  4096  (symmetric, 2^12 -> 13-bit activation range)"),
    (r"8206", "LUT byte offset 8206 = 2 * 4103  (index centred so 4103 <-> 0)"),
    (r"__int16", "int16 storage"),
    (r"0x400ui64", "512-int16 output buffer"),
]
for pat, what in IDIOM:
    hits = [SLOT.get(f["ea"].replace("0x", "").upper(), "?")
            for f in j["funcs"] if re.search(pat, f["pseudocode"])]
    print("  %-62s in slots: %s" % (what, hits))

# is slot 13 the same code shape as slot 3? (the ladder pairs (3,13),(4,14),(5,15),(6,16))
print()
print("=" * 118)
print("slot 3 vs slot 13 -- the ladder pairs slot i with slot i+10")
print("=" * 118)
f3 = next(f for f in j["funcs"] if f["ea"].upper().endswith("F3910"))
f13 = next(f for f in j["funcs"] if f["ea"].upper().endswith("F7D60"))
for nm, f in (("slot 3 ", f3), ("slot 13", f13)):
    p = f["pseudocode"]
    print("  %s  chars %-6d  memsets %s  '>> 31' %d  '8206' %d  LUT-ish lookups %d"
          % (nm, len(p),
             re.findall(r"memset\([^,]+,\s*0,\s*(0x[0-9A-Fa-f]+|\d+)", p)[:2],
             len(re.findall(r">> 31", p)), p.count("8206"),
             len(re.findall(r"\*\(_WORD \*\)\(a\d \+ 2i64 \* ", p))))
