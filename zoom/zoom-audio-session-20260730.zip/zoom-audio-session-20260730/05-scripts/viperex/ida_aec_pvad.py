# ida_aec_pvad.py -- close F and G.
#
# F: the AEC classes are AecNnModel / AecQ16NnGeneralModelImpl / AecQ16NnMusicModelImpl. There is no
#    _C scalar variant, so the readable route is the vtable plus whatever sets the layer dims.
# G: PVADProcessor has NO model class of its own and its vt[2] is a scheduler. Hypothesis: PVAD is a
#    decision layer over CamppCalculator (cosine similarity + hysteresis), not a network. Test it by
#    dumping the whole vtable and the ctor and seeing which classes it actually instantiates.
import json

import idautils
import idc
import ida_bytes
import ida_funcs
import ida_hexrays
import ida_name

OUT = idc.ARGV[1] if len(idc.ARGV) > 1 else 'aecpvad.json'

CLASSES = ["AecNnModel", "AecQ16NnGeneralModelImpl", "AecQ16NnMusicModelImpl",
           "PVADProcessor@viper", "IPVADProcessor", "CompanionMicFeatureCalculate_C",
           "CamppCalculator_C"]

res = {"vtables": {}, "funcs": [], "log": []}


def say(m):
    res["log"].append(str(m))


def demang(n):
    return ida_name.demangle_name(n, 0) or n


def find_vt(cls):
    for cand in ("??_7%s@@6B@" % cls, "%s::`vftable'" % cls):
        ea = idc.get_name_ea_simple(cand)
        if ea != idc.BADADDR:
            return ea
    td = idc.get_name_ea_simple("??_R0?AV%s@@@8" % cls)
    if td != idc.BADADDR:
        say("%s: type descriptor at %X but no ??_7 symbol" % (cls, td))
    return None


def dump_vt(ea, limit=64):
    out = []
    for i in range(limit):
        p = ida_bytes.get_qword(ea + 8 * i)
        f = ida_funcs.get_func(p) if p else None
        if not f or f.start_ea != p:
            break
        out.append({"i": i, "ea": "%X" % p, "size": f.size(),
                    "name": demang(idc.get_func_name(p))})
    return out


TARGETS = []
for cls in CLASSES:
    ea = find_vt(cls)
    if ea is None:
        say("no vtable for %s" % cls)
        continue
    slots = dump_vt(ea)
    res["vtables"][cls] = {"vt": "%X" % ea, "slots": slots}
    say("%s vtable @%X, %d slots" % (cls, ea, len(slots)))
    for s in slots:
        if s["size"] > 200:
            TARGETS.append((int(s["ea"], 16), "%s vt[%d]" % (cls, s["i"])))

# any function that materialises the vtable address is a constructor
for cls, v in list(res["vtables"].items()):
    vt = int(v["vt"], 16)
    for x in idautils.XrefsTo(vt, 0):
        f = ida_funcs.get_func(x.frm)
        if f and f.size() > 120:
            TARGETS.append((f.start_ea, "%s ctor/xref" % cls))

seen = set()
for ea, why in TARGETS:
    f = ida_funcs.get_func(ea)
    if not f or f.start_ea in seen:
        continue
    seen.add(f.start_ea)
    try:
        c = ida_hexrays.decompile(f.start_ea)
        ps = str(c) if c else "(decompile failed)"
    except Exception as e:
        ps = "(exc %s)" % e
    res["funcs"].append({"ea": "%X" % f.start_ea, "size": f.size(), "why": why,
                         "name": demang(idc.get_func_name(f.start_ea)),
                         "pseudocode": ps[:70000]})

res["count"] = len(res["funcs"])
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(res, fh, indent=1)
idc.qexit(0)
