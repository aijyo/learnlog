"""Recover SNAC's per-layer dimensions from the weight-table entry SIZES.

This is the step I skipped. The table at off_180221980 is triples of {const char* name, type|size,
const void* data}, and the SIZES alone determine the layer widths:

    bias size / 4                 = output width          (bias is one float per output)
    weight size / out / itemsize  = input width
    scale/subias size / 4         = output width           (per-output-channel quantisation)

So no guessing is needed -- the dimensions are in the binary, they just have to be read out of the
descriptor table instead of assumed. Marked ours only where the arithmetic is ambiguous.

Reads the PE directly; no IDA needed.
"""
import re
import struct
from collections import OrderedDict

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()
BASE = 0x180000000
SECS = [(".rdata", 0x18021F000, 0x21D800, 0x28F5400),
        (".data", 0x182B15000, 0x2B12C00, 0x1120200)]


def off(va):
    for nm, v, r, sz in SECS:
        if v <= va < v + sz:
            return r + (va - v)
    return None


TAB = 0x180221980
o = off(TAB)

rows = []
for i in range(4096):
    b = o + 24 * i
    if b + 24 > len(d):
        break
    npt, packed, dat = struct.unpack_from("<QQQ", d, b)
    no = off(npt)
    if no is None:
        break
    end = d.find(b"\0", no, no + 96)
    if end < 0:
        break
    name = d[no:end].decode("latin1")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        break
    typ = packed & 0xFFFFFFFF
    size = (packed >> 32) & 0xFFFFFFFF
    rows.append((name, typ, size, dat))

print("weight-table entries read: %d" % len(rows))
print()

# group by layer stem
SUF = r"_(weights_int8|weights_idx|weights_float|weights|bias|subias|scale|diag)$"
layers = OrderedDict()
for name, typ, size, dat in rows:
    m = re.search(SUF, name)
    if not m:
        continue
    stem = name[:m.start()]
    layers.setdefault(stem, {})[m.group(1)] = (typ, size)

print("%-26s %-10s %-12s %-10s %-8s %s"
      % ("layer", "out", "in", "weights B", "type", "derivation"))
print("-" * 104)
solved = 0
for stem, parts in layers.items():
    out_w = None
    src = ""
    for key in ("bias", "scale", "subias"):
        if key in parts:
            out_w = parts[key][1] // 4
            src = key
            break
    wkey = next((k for k in ("weights_int8", "weights_float", "weights") if k in parts), None)
    wsz = parts[wkey][1] if wkey else None
    in_w = None
    if out_w and wsz:
        item = 1 if wkey == "weights_int8" else 4
        n = wsz // item
        if out_w and n % out_w == 0:
            in_w = n // out_w
    if out_w and in_w:
        solved += 1
    print("%-26s %-10s %-12s %-10s %-8s %s"
          % (stem,
             str(out_w) if out_w else "?",
             str(in_w) if in_w else "?",
             str(wsz) if wsz else "-",
             (wkey or "-").replace("weights_", ""),
             "out from %s; in = %s/%s/%s" % (src, wsz, out_w, 1 if wkey == 'weights_int8' else 4)
             if in_w else "ambiguous"))
print()
print("layers with BOTH dimensions solved: %d / %d" % (solved, len(layers)))

# GRU layers: the gate count is 3, so the true hidden size is out/3 for the input matrix
print()
print("=== GRU layers: hidden size = out/3 (three gates share one matrix) ===")
for stem, parts in layers.items():
    if "gru" not in stem:
        continue
    ow = None
    for key in ("bias", "scale", "subias"):
        if key in parts:
            ow = parts[key][1] // 4
            break
    if ow:
        print("  %-26s out %-6d => hidden %s" % (stem, ow, ow // 3 if ow % 3 == 0 else "%.1f (not /3)" % (ow / 3)))
