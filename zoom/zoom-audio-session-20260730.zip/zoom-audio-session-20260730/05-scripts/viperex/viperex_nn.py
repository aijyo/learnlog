"""Zoom's own inference engine and its models, from viperex.dll RTTI.

This corrects the earlier "no denoise model" conclusion. That check looked for model FILES and for a
third-party runtime (OpenVINO) being loaded. Zoom has neither: it ships a hand-written C++ engine
(`TorchCpp`, with Conv2dTd / _AVX / _SSE2 kernels) and Q16-quantised weights embedded in the DLL, so
both checks came back negative on something that is plainly there.
"""
import re

P = r"D:\code\work\zoom-bin-analysis\re-work\viperex.dll"
d = open(P, "rb").read()

names = set()
for m in re.finditer(rb"\.\?AV[\x20-\x7e]{3,240}?@@", d):
    names.add(m.group(0).decode("latin1"))

def pretty(n):
    core = n[4:-2]
    parts = [p for p in core.split("@") if p]
    return "::".join(reversed(parts)) if len(parts) > 1 else core

# Model / engine classes: names ending in Model/ModelImpl/Net/Layer/Engine, or mentioning Nn.
MODEL = re.compile(r"(Model|ModelImpl|Net|Layer|Engine|Nn[A-Z]|NnModel|Infer)", re.I)
SKIP = re.compile(r"Conv2dTd")          # the kernel template instantiations, already known

print("=== model / engine classes ===")
out = sorted({pretty(n) for n in names if MODEL.search(n) and not SKIP.search(n)})
for n in out:
    print("  " + n[:120])

print("\n=== everything with 'Torch' ===")
for n in sorted({pretty(n) for n in names if "Torch" in n and not SKIP.search(n)}):
    print("  " + n[:120])

print("\n=== plain-text symbol-ish strings naming models ===")
pat = re.compile(rb"[A-Za-z_][A-Za-z0-9_]{5,60}(Nn|NN)[A-Za-z0-9_]{0,40}")
seen = set()
for m in pat.finditer(d):
    s = m.group(0).decode("latin1")
    if s not in seen:
        seen.add(s)
for s in sorted(seen)[:50]:
    print("  " + s)
