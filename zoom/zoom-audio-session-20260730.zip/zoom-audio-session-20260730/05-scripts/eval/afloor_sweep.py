"""Does a P-driven floor buy selective suppression -- and does the better detector pay off there?

The level sweep showed the FLOOR is the binding constraint and the detector is not. So put the floor
under the detector's control: keep the level's floor on speech frames, allow up to afloor_db of extra
depth as P falls below the knee. Two things to check, and they are different questions:

  1. does gap attenuation rise FASTER than speech attenuation (i.e. modulation up, not just level
     down)? DB830's limiter failed exactly here: it moved both equally, modulation -0.03 dB.
  2. does the high-d-prime feature set now beat the shipped one? A confident detector is the
     precondition for an aggressive P-driven floor being safe, so this is where the d-prime work
     should finally show up -- or be refuted.

STOI/ESTOI reported alongside so speech damage cannot hide behind a good modulation number.
"""
import math
import os
import re
import struct
import subprocess
import wave
import collections

D = r"D:\code\work\research\voice\denoise"
LAB = os.path.join(D, "build", "Release", "nsxlab.exe")
OUT = os.path.join(D, "out", "af")
os.makedirs(OUT, exist_ok=True)
HOP = 256


def read_wav(p):
    w = wave.open(p, "rb")
    n = w.getnframes(); raw = w.readframes(n); sr = w.getframerate(); w.close()
    return list(struct.unpack("<%dh" % n, raw)), sr


def fdb(x, a, b):
    seg = x[a:b]
    if not seg:
        return -120.0
    r = math.sqrt(sum(v * v for v in seg) / len(seg)) / 32768.0
    return 20.0 * math.log10(max(r, 1e-9))


CLEANS = ["clnsp379", "clnsp512", "clnsp518"]
NOISES = ["Typing_1", "Munching_1", "AirConditioner_1", "Babble_1"]
FEATS = [("old", ["--thresh-mode", "2", "--feature-set", "0"]),
         ("new", ["--thresh-mode", "1", "--feature-set", "1"])]
AFLOOR = [0, 6, 12, 18, 24]

agg = collections.defaultdict(list)
for cl in CLEANS:
    cp = os.path.join(D, "samples", "clean", cl + ".wav")
    clean, sr = read_wav(cp)
    for nz in NOISES:
        np_ = os.path.join(D, "samples", "noise", nz + ".wav")
        rawp = os.path.join(OUT, "raw.wav")
        subprocess.run([LAB, "--in", cp, "--mix-noise", np_, "--mix-snr", "5",
                        "--floor-db", "0", "--oversub", "0.1", "--out", rawp], capture_output=True)
        base, _ = read_wav(rawp)
        nfr = min(len(base), len(clean)) // HOP
        lv = [fdb(clean, i * HOP, (i + 1) * HOP) for i in range(nfr)]
        pk = max(lv)
        sp = [i for i, v in enumerate(lv) if v >= pk - 25]
        gp = [i for i, v in enumerate(lv) if v <= pk - 45]
        if len(sp) < 20 or len(gp) < 10:
            continue
        b_sp = sum(fdb(base, i * HOP, (i + 1) * HOP) for i in sp) / len(sp)
        b_gp = sum(fdb(base, i * HOP, (i + 1) * HOP) for i in gp) / len(gp)
        for fname, fargs in FEATS:
            for af in AFLOOR:
                o = os.path.join(OUT, "v.wav")
                r = subprocess.run([LAB, "--in", cp, "--mix-noise", np_, "--mix-snr", "5",
                                    "--level", "2", "--afloor-db", str(af)] + fargs +
                                   ["--out", o, "--clean", cp], capture_output=True, text=True)
                m2 = re.search(r"v\.wav\s+([\d.]+)\s+([\d.]+)\s+([-\d.]+)", r.stdout or "")
                stoi = float(m2.group(1)) if m2 else float("nan")
                estoi = float(m2.group(2)) if m2 else float("nan")
                y, _ = read_wav(o)
                m = min(nfr, len(y) // HOP)
                ys = sum(fdb(y, i * HOP, (i + 1) * HOP) for i in sp if i < m) / max(1, sum(1 for i in sp if i < m))
                yg = sum(fdb(y, i * HOP, (i + 1) * HOP) for i in gp if i < m) / max(1, sum(1 for i in gp if i < m))
                agg[(fname, af)].append((b_gp - yg, b_sp - ys, (b_gp - yg) - (b_sp - ys), stoi, estoi))

hdr = "%-6s %-9s %9s %11s %11s %8s %8s" % ("feats", "afloor_db", "att_gap", "att_speech", "modulation", "STOI", "ESTOI")
print(hdr); print("-" * len(hdr))
for fname, _ in FEATS:
    for af in AFLOOR:
        d = agg.get((fname, af))
        if not d:
            continue
        n = len(d)
        print("%-6s %-9d %9.2f %11.2f %11.2f %8.4f %8.4f" % (
            fname, af,
            sum(x[0] for x in d) / n, sum(x[1] for x in d) / n, sum(x[2] for x in d) / n,
            sum(x[3] for x in d) / n, sum(x[4] for x in d) / n))
    print()
