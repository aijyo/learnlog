"""Re-test DB830's gain limiter now that the detector separates.

zoom_gain was implemented, verified against DB830, and left OFF with this reason recorded in the
mechanism table: "it cannot be enabled until the detector works: with P pinned near 0.5 the limiter's
pedestal drives every bin to the floor and the output is uniformly attenuated". That was measured
when the fused features had d-prime 0.40-0.59. The high-d-prime set reaches 1.24-1.55, so the
precondition may now hold -- and unlike the detector itself, this limiter acts on the FLOOR, which the
level sweep just showed is the binding constraint.

Measures gap attenuation, speech attenuation and their difference (modulation), labelled from the
clean reference. A win looks like: gap attenuation up, speech attenuation flat, modulation up.
Also reports STOI/ESTOI so speech damage cannot hide.
"""
import math
import os
import re
import struct
import subprocess
import wave
import collections

D = r"D:\code\work\research\voice\denoise"
LAB = os.path.join(D, "build", "Release", "nsxlab.exe")
OUT = os.path.join(D, "out", "zg")
os.makedirs(OUT, exist_ok=True)
HOP = 256


def read_wav(p):
    w = wave.open(p, "rb")
    n = w.getnframes(); raw = w.readframes(n); sr = w.getframerate(); w.close()
    return list(struct.unpack("<%dh" % n, raw)), sr


def fdb(x, a, b):
    seg = x[a:b]
    if not seg:
        return -120.0
    r = math.sqrt(sum(v * v for v in seg) / len(seg)) / 32768.0
    return 20.0 * math.log10(max(r, 1e-9))


CLEANS = ["clnsp379", "clnsp512", "clnsp518"]
NOISES = ["Typing_1", "Munching_1", "AirConditioner_1", "Babble_1"]
# detector fixed to the high-d-prime set; the variable is the DB830 limiter
CASES = [
    ("old-feat  zg-off", ["--thresh-mode", "2", "--feature-set", "0"]),
    ("old-feat  zg-ON ", ["--thresh-mode", "2", "--feature-set", "0", "--zoom-gain"]),
    ("new-feat  zg-off", ["--thresh-mode", "1", "--feature-set", "1"]),
    ("new-feat  zg-ON ", ["--thresh-mode", "1", "--feature-set", "1", "--zoom-gain"]),
]
LEVELS = ["2", "4"]

agg = collections.defaultdict(list)
for cl in CLEANS:
    cp = os.path.join(D, "samples", "clean", cl + ".wav")
    clean, sr = read_wav(cp)
    for nz in NOISES:
        np_ = os.path.join(D, "samples", "noise", nz + ".wav")
        rawp = os.path.join(OUT, "raw.wav")
        subprocess.run([LAB, "--in", cp, "--mix-noise", np_, "--mix-snr", "5",
                        "--floor-db", "0", "--oversub", "0.1", "--out", rawp], capture_output=True)
        base, _ = read_wav(rawp)
        nfr = min(len(base), len(clean)) // HOP
        lv = [fdb(clean, i * HOP, (i + 1) * HOP) for i in range(nfr)]
        pk = max(lv)
        sp = [i for i, v in enumerate(lv) if v >= pk - 25]
        gp = [i for i, v in enumerate(lv) if v <= pk - 45]
        if len(sp) < 20 or len(gp) < 10:
            continue
        b_sp = sum(fdb(base, i * HOP, (i + 1) * HOP) for i in sp) / len(sp)
        b_gp = sum(fdb(base, i * HOP, (i + 1) * HOP) for i in gp) / len(gp)
        for lvl in LEVELS:
            for cname, cargs in CASES:
                o = os.path.join(OUT, "v.wav")
                r = subprocess.run([LAB, "--in", cp, "--mix-noise", np_, "--mix-snr", "5",
                                    "--level", lvl] + cargs + ["--out", o, "--clean", cp],
                                   capture_output=True, text=True)
                m2 = re.search(r"v\.wav\s+([\d.]+)\s+([\d.]+)\s+([-\d.]+)", r.stdout or "")
                stoi = float(m2.group(1)) if m2 else float("nan")
                estoi = float(m2.group(2)) if m2 else float("nan")
                y, _ = read_wav(o)
                m = min(nfr, len(y) // HOP)
                ys = sum(fdb(y, i * HOP, (i + 1) * HOP) for i in sp if i < m) / max(1, sum(1 for i in sp if i < m))
                yg = sum(fdb(y, i * HOP, (i + 1) * HOP) for i in gp if i < m) / max(1, sum(1 for i in gp if i < m))
                agg[(lvl, cname)].append((b_gp - yg, b_sp - ys, (b_gp - yg) - (b_sp - ys), stoi, estoi))

hdr = "%-6s %-18s %9s %10s %11s %8s %8s" % ("level", "case", "att_gap", "att_speech", "modulation", "STOI", "ESTOI")
print(hdr); print("-" * len(hdr))
for lvl in LEVELS:
    for cname, _ in CASES:
        d = agg.get((lvl, cname))
        if not d:
            continue
        n = len(d)
        print("%-6s %-18s %9.2f %10.2f %11.2f %8.4f %8.4f" % (
            lvl, cname,
            sum(x[0] for x in d) / n, sum(x[1] for x in d) / n, sum(x[2] for x in d) / n,
            sum(x[3] for x in d) / n, sum(x[4] for x in d) / n))
    print()
