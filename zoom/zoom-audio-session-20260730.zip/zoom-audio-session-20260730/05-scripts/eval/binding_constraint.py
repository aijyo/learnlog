"""Which knob is actually binding: the DETECTOR or the gain FLOOR?

Three detector variants all landed at 6.5 dB gap attenuation and 3.3 dB modulation, despite the
feature separation improving from d-prime 0.40 to 1.55. That is the signature of a downstream clamp:
if the floor is what limits how far a gap bin can be pushed, then no detector improvement can show up
in gap attenuation, and the level knob (which sets the floor) should move it a lot.

Falsifiable: sweep level 0..5 with the detector FIXED. If gap attenuation tracks the floor ladder
(-4 .. -27 dB) and modulation grows with it, the floor is binding and the detector work was aimed at
the wrong constraint. If gap attenuation saturates well above the floor, something else binds.
"""
import math
import os
import struct
import subprocess
import wave

D = r"D:\code\work\research\voice\denoise"
LAB = os.path.join(D, "build", "Release", "nsxlab.exe")
OUT = os.path.join(D, "out", "bind")
os.makedirs(OUT, exist_ok=True)
HOP = 256
FLOORS = {0: -4, 1: -6, 2: -9, 3: -14, 4: -20, 5: -27}


def read_wav(p):
    w = wave.open(p, "rb")
    n = w.getnframes()
    raw = w.readframes(n)
    sr = w.getframerate()
    w.close()
    return list(struct.unpack("<%dh" % n, raw)), sr


def fdb(x, a, b):
    seg = x[a:b]
    if not seg:
        return -120.0
    r = math.sqrt(sum(v * v for v in seg) / len(seg)) / 32768.0
    return 20.0 * math.log10(max(r, 1e-9))


CLEANS = ["clnsp379", "clnsp512", "clnsp518"]
NOISES = ["Typing_1", "Munching_1", "AirConditioner_1", "Babble_1"]

# detector variants held fixed while the level sweeps
VAR = [("A_hist_old", ["--thresh-mode", "2", "--feature-set", "0"]),
       ("C_abs_new",  ["--thresh-mode", "1", "--feature-set", "1"])]

print("%-12s %-6s %8s %9s %11s %10s" % ("variant", "level", "floor", "att_gap", "modulation", "spread"))
print("-" * 62)
import collections
agg = collections.defaultdict(list)
for cl in CLEANS:
    cp = os.path.join(D, "samples", "clean", cl + ".wav")
    clean, sr = read_wav(cp)
    for nz in NOISES:
        np_ = os.path.join(D, "samples", "noise", nz + ".wav")
        rawp = os.path.join(OUT, "raw.wav")
        subprocess.run([LAB, "--in", cp, "--mix-noise", np_, "--mix-snr", "5",
                        "--floor-db", "0", "--oversub", "0.1", "--out", rawp],
                       capture_output=True)
        base, _ = read_wav(rawp)
        nfr = min(len(base), len(clean)) // HOP
        lv = [fdb(clean, i * HOP, (i + 1) * HOP) for i in range(nfr)]
        pk = max(lv)
        sp = [i for i, v in enumerate(lv) if v >= pk - 25]
        gp = [i for i, v in enumerate(lv) if v <= pk - 45]
        if len(sp) < 20 or len(gp) < 10:
            continue
        b_sp = sum(fdb(base, i * HOP, (i + 1) * HOP) for i in sp) / len(sp)
        b_gp = sum(fdb(base, i * HOP, (i + 1) * HOP) for i in gp) / len(gp)
        for vname, vargs in VAR:
            for lvl in range(6):
                o = os.path.join(OUT, "v.wav")
                subprocess.run([LAB, "--in", cp, "--mix-noise", np_, "--mix-snr", "5",
                                "--level", str(lvl)] + vargs + ["--out", o],
                               capture_output=True)
                y, _ = read_wav(o)
                m = min(nfr, len(y) // HOP)
                ys = sum(fdb(y, i * HOP, (i + 1) * HOP) for i in sp if i < m) / max(1, sum(1 for i in sp if i < m))
                yg = sum(fdb(y, i * HOP, (i + 1) * HOP) for i in gp if i < m) / max(1, sum(1 for i in gp if i < m))
                agg[(vname, lvl)].append((b_gp - yg, (b_gp - yg) - (b_sp - ys)))

for vname, _ in VAR:
    for lvl in range(6):
        d = agg.get((vname, lvl))
        if not d:
            continue
        n = len(d)
        print("%-12s %-6d %8d %9.2f %11.2f %10s" % (
            vname, lvl, FLOORS[lvl], sum(x[0] for x in d) / n, sum(x[1] for x in d) / n, "-"))
    print()
