"""Does the new feature set actually make the suppressor quieter IN THE GAPS?

The aggregate metrics saturate: STOI sits at 0.918 for every variant, because at 5 dB SNR over a 10 s
clip they are dominated by the speech, not by the residual noise between words. The user's complaint
is about residual noise being audible in the gaps, so measure that directly -- the two quantities
NOTES 14/15 introduced for exactly this reason:

  1. gap-vs-speech GAIN MODULATION: mean output level in gap frames vs in speech frames. A denoiser
     should push the gaps down much further than the speech. A volume control moves both equally.
  2. per-band attenuation SPREAD in the gaps (max - min across bands). High spread = frequency-
     selective removal. Low spread = everything got quieter, which is what "I still hear the hum,
     it just got quieter" sounds like.

Frames are labelled from the CLEAN reference, so the labels are ground truth, not the detector's
opinion. Run: python gap_modulation.py
"""
import math
import os
import struct
import subprocess
import wave

D = r"D:\code\work\research\voice\denoise"
LAB = os.path.join(D, "build", "Release", "nsxlab.exe")
OUT = os.path.join(D, "out", "gapmod")
os.makedirs(OUT, exist_ok=True)

VARIANTS = [
    ("A_hist_old", ["--thresh-mode", "2", "--feature-set", "0"]),
    ("C_abs_new",  ["--thresh-mode", "1", "--feature-set", "1"]),
    ("D_hmm_new",  ["--thresh-mode", "3", "--feature-set", "0"]),
]
NOISES = ["Typing_1", "Munching_1", "ShuttingDoor_1", "Babble_1",
          "AirConditioner_1", "VacuumCleaner_1"]
CLEANS = ["clnsp379", "clnsp512", "clnsp518", "clnsp553", "clnsp1068"]

HOP = 256
BANDS_HZ = [0, 125, 250, 500, 1000, 2000, 4000, 8000]


def read_wav(p):
    w = wave.open(p, "rb")
    n, sw, sr = w.getnframes(), w.getsampwidth(), w.getframerate()
    raw = w.readframes(n)
    w.close()
    return list(struct.unpack("<%dh" % n, raw)), sr


def frame_db(x, i0, i1):
    seg = x[i0:i1]
    if not seg:
        return -120.0
    r = math.sqrt(sum(v * v for v in seg) / len(seg)) / 32768.0
    return 20.0 * math.log10(max(r, 1e-9))


def labels(clean, nfr):
    lv = [frame_db(clean, i * HOP, (i + 1) * HOP) for i in range(nfr)]
    pk = max(lv)
    sp = [i for i, v in enumerate(lv) if v >= pk - 25]
    gp = [i for i, v in enumerate(lv) if v <= pk - 45]
    return sp, gp


def band_energies(x, sr, frames):
    """Per-band mean energy (dB) over the given frame indices, via a Goertzel-free FFT-free
    approach: simple time-domain band split is overkill here, so use a real FFT per frame."""
    import cmath
    N = 512
    nb = len(BANDS_HZ) - 1
    acc = [0.0] * nb
    cnt = 0
    # precompute band bin ranges
    rng = []
    for b in range(nb):
        lo = int(BANDS_HZ[b] * N / sr)
        hi = max(lo + 1, int(BANDS_HZ[b + 1] * N / sr))
        rng.append((lo, min(hi, N // 2)))
    for fi in frames:
        s = fi * HOP
        seg = x[s:s + N]
        if len(seg) < N:
            continue
        # Hann + naive DFT on 512 points is slow in pure python; use numpy if present
        try:
            import numpy as np
            w = np.hanning(N)
            sp = np.fft.rfft(np.asarray(seg, dtype=float) * w)
            p = (sp.real ** 2 + sp.imag ** 2)
        except Exception:
            return None
        for b, (lo, hi) in enumerate(rng):
            acc[b] += float(p[lo:hi].sum()) / max(hi - lo, 1)
        cnt += 1
    if not cnt:
        return None
    return [10.0 * math.log10(max(a / cnt, 1e-20)) for a in acc]


rows = []
for cl in CLEANS:
    cpath = os.path.join(D, "samples", "clean", cl + ".wav")
    clean, sr = read_wav(cpath)
    for nz in NOISES:
        npath = os.path.join(D, "samples", "noise", nz + ".wav")
        # noisy reference (no processing) so attenuation is measured against the real input
        raw_out = os.path.join(OUT, "raw.wav")
        subprocess.run([LAB, "--in", cpath, "--mix-noise", npath, "--mix-snr", "5",
                        "--floor-db", "0", "--oversub", "0.1", "--out", raw_out],
                       capture_output=True)
        base, _ = read_wav(raw_out)
        nfr = min(len(base), len(clean)) // HOP
        sp, gp = labels(clean, nfr)
        if len(sp) < 20 or len(gp) < 10:
            continue
        b_sp = sum(frame_db(base, i * HOP, (i + 1) * HOP) for i in sp) / len(sp)
        b_gp = sum(frame_db(base, i * HOP, (i + 1) * HOP) for i in gp) / len(gp)
        for vname, vargs in VARIANTS:
            o = os.path.join(OUT, "v.wav")
            subprocess.run([LAB, "--in", cpath, "--mix-noise", npath, "--mix-snr", "5"]
                           + vargs + ["--out", o], capture_output=True)
            y, _ = read_wav(o)
            m = min(nfr, len(y) // HOP)
            y_sp = sum(frame_db(y, i * HOP, (i + 1) * HOP) for i in sp if i < m) / \
                   max(1, sum(1 for i in sp if i < m))
            y_gp = sum(frame_db(y, i * HOP, (i + 1) * HOP) for i in gp if i < m) / \
                   max(1, sum(1 for i in gp if i < m))
            att_sp = b_sp - y_sp          # dB removed from speech frames
            att_gp = b_gp - y_gp          # dB removed from gap frames
            be = band_energies(y, sr, [i for i in gp if i < m])
            spread = (max(be) - min(be)) if be else float("nan")
            rows.append((cl, nz, vname, att_gp, att_sp, att_gp - att_sp, spread))

# ---- report -----------------------------------------------------------------
import collections
print("gap attenuation / speech attenuation / MODULATION (gap-speech) / band spread in gaps")
print()
hdr = "%-18s %-12s %9s %9s %11s %10s" % ("noise", "variant", "att_gap", "att_sp", "modulation", "spread")
print(hdr)
print("-" * len(hdr))
by = collections.defaultdict(list)
for cl, nz, v, ag, as_, mod, sprd in rows:
    by[(nz, v)].append((ag, as_, mod, sprd))
for nz in NOISES:
    for vname, _ in VARIANTS:
        d = by.get((nz, vname))
        if not d:
            continue
        n = len(d)
        print("%-18s %-12s %9.2f %9.2f %11.2f %10.2f" % (
            nz, vname,
            sum(x[0] for x in d) / n, sum(x[1] for x in d) / n,
            sum(x[2] for x in d) / n, sum(x[3] for x in d) / n))
    print()
print("=== overall (all noises, all cleans) ===")
for vname, _ in VARIANTS:
    d = [x for k, v in by.items() if k[1] == vname for x in v]
    n = len(d)
    print("%-12s att_gap %6.2f   att_speech %6.2f   MODULATION %6.2f   spread %6.2f   (n=%d)" % (
        vname, sum(x[0] for x in d) / n, sum(x[1] for x in d) / n,
        sum(x[2] for x in d) / n, sum(x[3] for x in d) / n, n))
