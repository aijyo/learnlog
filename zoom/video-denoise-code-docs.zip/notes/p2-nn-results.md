# P2 结果 — 单帧神经网络降噪(训练反馈环 + vs 经典基线)

> 模块 [`../scripts/nn_denoise.py`](../scripts/nn_denoise.py)（DnCNN + 合成数据管线）。
> 实验 [`exp14_nn_overfit.py`](../experiments/exp14_nn_overfit.py)（反馈环证明）、[`exp15_nn_train_vs_classical.py`](../experiments/exp15_nn_train_vs_classical.py)（训练+对照）。
> 复现：`python experiments/exp14_nn_overfit.py` / `exp15_...`。环境:PyTorch 2.8 **CPU**（本机无 CUDA）。日期 2026-07-22。

## P2.1 训练反馈环(先建,铁律)—— ✅ 通过

微型过拟合:8 个 64×64 patch,DnCNN(105k 参数,feat48/depth7,残差学习预测噪声)。
2000 步 loss→5e-5,重建 PSNR **17.9→42.6 dB**。→ 数据管线/损失/反传/指标全链路正确,可放大。

## P2.2 小训练 + vs 经典单帧基线 —— 质量赢、算力(CPU)未达标

训练:512 合成 clean patch + 每 epoch 新采 Poisson-Gaussian 噪声(peak30/read0.03),24 epoch,108s CPU。val-PSNR 17.8→25.8。

**质量(held-out 64 patch):**

| 方法 | PSNR | SSIM |
|------|------|------|
| noisy | 17.60 | 0.347 |
| 经典 bilateral | 22.56 | 0.569 |
| **DnCNN(ours)** | **25.75** | **0.702** |

→ NN 比经典单帧 **+3.2 dB / +0.13 SSIM**,质量明确胜出。

**每帧算力 @480×640(CPU,NN 部署会用 GPU/ONNX):**

| 方法 | ms/帧 |
|------|-------|
| 经典 bilateral | 3.5 |
| DnCNN(ours) | **206.5** |

→ **CPU 上 NN 慢 ~60×(≈5fps,不实时)**。项目铁律"同耗时预算内打赢"——**质量达标,算力(CPU)未达标**。

## 结论

- ✅ 手搓单帧 NN 的**质量优势是真的**(+3.2dB),训练反馈环成立、能泛化。
- ❌ **CPU 推理太慢**,不满足实时;经典 bilateral 便宜得多。
- CPU 是上界:本机无 CUDA,DnCNN 用 numpy/torch-CPU 卷积慢。真实部署需 **GPU/ONNX**(RX550/UHD770 via DirectML EP,衔接 voice 项目 onnxruntime 经验),或更轻的架构。

## 局限(诚实)

- **合成噪声 + 合成 clean patch**,非真实图像/真实噪声;泛化到真实低光需真实数据验证(可用相机片段做自监督或以经典去噪结果为伪 GT)。
- CPU-only 训练,规模小(512 patch/24 epoch);更大数据/更长训练需 GPU 资源(待定)。
- 只比了**单帧** vs 单帧(公平);时域 NN(递归/多帧)是下一步,对照经典时域(守卫)。

## 下一步

- **算力桥(P3 味道)**:DnCNN 导 ONNX → onnxruntime DirectML 在 RX550/UHD770 上测真实 fps;或裁轻网络(feat/depth↓)看"同耗时预算下"是否仍赢 bilateral。
- **真实噪声**:在相机片段上训练/评估(自监督 N2N,或经典去噪当伪 GT)。
- **时域 NN**:单帧网络扩多帧/递归,对照经典守卫/MCTF;须同耗时预算内打赢。
