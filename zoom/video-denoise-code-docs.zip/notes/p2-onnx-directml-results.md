# P2 算力桥 — ONNX + DirectML GPU 实测(负结果)

> 实验 [`../experiments/exp16_onnx_directml_bench.py`](../experiments/exp16_onnx_directml_bench.py)。
> 复现：`python experiments/exp16_onnx_directml_bench.py`。
> 环境:onnxruntime-directml 1.19.2,本机 GPU=Intel UHD770 + AMD RX550。日期 2026-07-22。

## 问题

P2 的 DnCNN 质量赢经典 +3.2dB,但 CPU 206ms/帧不实时。**GPU(DirectML)能不能救回实时?**

## 做了什么

DnCNN(105k)导 ONNX(opset17,动态 H/W),torch↔onnx 数值一致(max|diff|=2e-6 ✅)。
onnxruntime 各 provider × 分辨率跑基准。

## 结果(ms/帧,fps)

| provider | 320×240 | 640×480 | 1280×720 |
|----------|---------|---------|----------|
| CPU | 19.8ms / 50fps | 83.7ms / 12fps | 350ms / 3fps |
| DirectML adapter 0 | 21.6 / 46（**实为 CPU 回退**） | 101.6 / 10 | 378 / 3 |
| DirectML adapter 1（GPU）| 31.7 / 32 | 126.3 / 8 | 375 / 3 |

- **adapter 0 报错**"指定的显示适配器句柄无效"→ **静默回退 CPU**,其数字≈CPU、非真实 GPU 测量。
- **adapter 1 真在 GPU 上跑,但比 CPU 更慢**(640×480:126ms vs 84ms)。
- 实时线 ~30fps(<33ms):**640×480 无一档达标**(CPU 84 / GPU 126ms,差 3–4×);仅 320×240 CPU(~20ms)接近实时。

## 结论(诚实)

**本机 GPU 是死路:DirectML 不但没加速,反而比 CPU 慢。** 原因:GPU 太弱(核显 UHD770 + 低端 RX550 ~1.2TFLOPS)+ DirectML 每次调用的调度/拷贝开销,对这种小卷积网络,GPU 省下的算不抵开销 → 输给多线程 CPU。经典 bilateral 3.5ms 依旧碾压(24×)。

→ **在这台机器上,当前 DnCNN 无法实时(CPU/GPU 都不行)。** GPU 加速这条路,在此硬件上不成立。

## 未试的次要杠杆(预计救不了)

fp16 / IO-binding 可能给 GPU ~2×,但 640×480 仍 >60ms、且仍可能慢于 CPU;换更强 GPU 本机没有。不值得在此硬件上深挖。

## 出路(下一步选择)

1. **更轻的架构**(核心):裁到 3–4 层/16 通道级,测"在 bilateral 同等/可接受耗时预算下,轻量 NN 还赢不赢经典"——这是 NN 路线在本硬件能否成立的关键实验(且 GPU 既然没用,直接在 CPU 上找 speed/quality 前沿)。
2. **降分辨率处理**:320×240 去噪(CPU ~20ms 近实时)再上采,权衡细节损失。
3. **分工收口**:NN 作离线/高质量档,经典(守卫)作实时档。
4. 换更强 GPU(本机无,待定资源)。

推荐先做 1:它直接回答"NN 路线在本机到底能不能实时可用"。
