# Bug: 平滑皮肤区降噪后出现波纹/等高线 — 诊断与修复

> 反馈：demo 里脖子皮肤(平滑低对比度渐变区)降噪后出现跟随等亮度线的波纹。
> 复现/诊断：[`../experiments/exp09_banding_repro.py`](../experiments/exp09_banding_repro.py)；证据图 `samples/banding/`。日期 2026-07-21。

## 反馈环 & 复现

合成"皮肤样"极低对比度弯曲渐变(luma 0.44–0.53)→ 加噪 → 降噪 → 量化到 8-bit → 沿渐变横切测
**等值游程长度(run-length)/电平变化数**(游程长↑、变化少↓ = banding)。

## 判别实验结果

| case | mean-run(px) | #changes |
|------|-------------|----------|
| clean(q8) | **15.24** | **20** |
| noisy(q8) | 1.05 | 303 |
| 纯时域IIR(无bilateral) | 1.11 | 286 |
| motion-adaptive 收敛 | 1.84 | 173 |
| **clean + dither amp=1** | 2.05 | 155 |

**关键观察**：
- **clean 渐变本身在 8-bit 就 banding**(run 15、仅 20 个电平)——低对比度平滑渐变量化必然出等高线,`clean_q8.png` 肉眼可见弯曲波纹 = 就是用户看到的伪影。
- noisy 不 banding(噪声在抖动量化器,run 1.05)。
- **降噪去掉噪声=去掉抖动 → 底层量化 banding 显形**。bilateral 阶梯效应(H1)加剧一点(motion-adaptive 比纯时域 banding 略重),但**根因是 8-bit 量化(H2)**。
- 残余噪声≈1 LSB 时会天然抖动、掩盖 banding;当降噪够狠(高 α / 输入已被相机内降噪压得很干净,残余<1 LSB)时波纹显现——这解释了为何真机上明显、我合成默认参数下不明显。

## 根因

**8-bit 量化等高线断层(banding),在降噪移除"抖动量化器的传感器噪声"后显形**(bilateral 阶梯效应叠加)。非算法逻辑 bug,是显示量化的固有问题被降噪暴露。

## 修复

**输出前加亚-LSB 三角分布(TPDF)抖动**(标准 debanding):±1 LSB,肉眼不可见,但打散硬等高线。
实测:clean banding run 15.24 → 加 dither amp=1 → 2.05,`fix_clean_dither_amp1.png` 肉眼波纹消失且不显噪。

关键实现点:**递归状态必须存未抖动的输出**(否则抖动逐帧累积),只对显示副本加抖动。

## 落地

- C# demo [`DenoiseDemo/DenoiseCore.cs`](../DenoiseDemo/DenoiseCore.cs)：`Denoiser.DitherAmp`(默认 1.0 LSB)+ `ApplyDither`(只作用于返回的显示副本,state 保持干净);UI 加"Debanding dither"勾选(默认开,可关掉看波纹回来=验证修复)。已重编译 EXE。
- Python 侧 debanding 工具见 exp09 的 `q8_dither`(TPDF)。

## 诚实边界

- 我是在**合成**极低对比度渐变上复现并验证修复的,非用户的真实帧。真机残余噪声/相机内处理不同,若 amp=1 不够(仍见波纹),可调 `DitherAmp` 到 2–3,或降 bilateral `SigmaColor`(0.18→~0.08)减阶梯效应。待用户实测确认。
