# exp07 结果 — Zoom 每亮度强度曲线接入降噪器

> 降噪器：`LumaProfileRecursiveDenoiser`（[`../scripts/classical_denoise.py`](../scripts/classical_denoise.py)）——按亮度调制运动阈值。
> 实验：[`../experiments/exp07_zoom_strength_profile.py`](../experiments/exp07_zoom_strength_profile.py)；Zoom 曲线来自 [`../scripts/zoom_noise.py`](../scripts/zoom_noise.py)。
> 复现：`python experiments/exp07_zoom_strength_profile.py`。承接 exp06。日期 2026-07-21。

## 做了什么

把 Zoom 恢复到的每亮度强度曲线接进降噪器：`sigma_motion(像素) = 均值·profile(luma)/mean(profile)`。
三种强度分布**归一化到相同均值**（只比"强度花在哪"的形状，不比总量）：
- **uniform**：常量。
- **noise-matched**：∝ 估计噪声 σ(luma)（真实噪声 shot 形→强度花在高光）。
- **zoom**：∝ Zoom 曲线（阴影加权→强度花在阴影）。

## 结果

**Part A — 合成暗+亮双带场景（C270_MEASURED 噪声，有 GT）：分区 PSNR**

| profile | 阴影 PSNR | 高光 PSNR | 总 PSNR |
|---------|----------|----------|---------|
| uniform | 41.46 | 37.66 | 39.15 |
| noise-matched | 41.45 | 37.66 | 39.15 |
| **zoom** | 40.65 | 36.37 | **38.01** |

**Part B — 真实 C270 clip（无 GT）：分区 flicker（×1e-3）**

| profile | 阴影 flick | 高光 flick | 总 flick |
|---------|-----------|-----------|---------|
| uniform | 1.80 | 0.42 | 1.76 |
| noise-matched | 1.79 | 0.42 | 1.75 |
| **zoom** | 1.83 | 0.71 | **1.79** |
| (noisy 输入) | 8.77 | 2.31 | 8.61 |

## 结论（诚实，含否定结果）

**Zoom 的阴影加权强度在我们的客观指标上更差**——合成上总 PSNR 38.01 vs 39.15（**两区都差**），真实上 flicker 也略差。机理：
- 真实噪声是 **shot 形（高光噪声多、阴影噪声少）**；
- zoom 把强度往**阴影**堆 → 阴影本就噪声少，过度时域平均反而**过平滑/运动滞后**（PSNR 掉），
  同时**高光噪声多却分到更少强度** → 高光残噪多（PSNR/flicker 掉）。两头都吃亏。
- uniform 与 noise-matched 几乎一样（此噪声 σ 跨亮度范围不大 + 真实 clip 几乎全是阴影，重分配≈不重分配）。

**为什么 Zoom 仍这么设计？——感知，不是 SNR**：人眼对**阴影中的噪声/波动更敏感**，阴影 SNR 也更差（即使绝对噪声小），
所以商用产品往阴影使劲是**感知质量**取向；我们的 PSNR/flicker 是 SNR 口径，**奖励不了这个感知收益**。
且 Zoom 的曲线隐含"阴影噪声重"的场景，与我们 C270 实测的 shot 形噪声相反。

**边界**：这是把 Zoom 的强度**思路**移植进**我们的机制**、用**我们的指标**评判的结果，非 Zoom 降噪器的 1:1 复刻；
"在我们框架里更差"≠"Zoom 降噪器更差"。

## 落地建议

- **我们这套按客观指标优化的降噪器**：用 **uniform 或 noise-matched** 强度即可；Zoom 的阴影加权不带来客观收益。
- Zoom 的曲线只在两种情况下才值得用：①评价改用**感知指标**（如加权到阴影的 VMAF/主观）；②噪声本身**阴影主导**（高增益/别的传感器）。
- `zoom_strength01` 与 `LumaProfileRecursiveDenoiser` 已留作可选项，随时可切。

## 局限

- 我们的 flicker/PSNR 是 SNR 口径，未上感知指标——恰是 Zoom 选择的动机盲区。若要公平评判 Zoom 的取向，需引入感知/主观评测。
- 强度移植是近似（Zoom 内部是"活动度除以曲线 + 固定 0.648 混合"的特定结构），非严格等价。
- 真实 clip 几乎全阴影，profile 重分配的区分度低；合成双带场景区分度够，结论一致。
