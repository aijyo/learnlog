# exp08 结果 — 感知(阴影加权)评测下重判 Zoom 强度曲线

> 实验：[`../experiments/exp08_perceptual_metric.py`](../experiments/exp08_perceptual_metric.py)（含 gamma 域噪声 [`../scripts/noise_models.py`](../scripts/noise_models.py) `add_pg_gamma_domain`）。
> 复现：`python experiments/exp08_perceptual_metric.py`。承接 exp07（Zoom 阴影加权在 MSE 下更差）。日期 2026-07-21。

## 做了什么

exp07 用纯 MSE 判 Zoom 输，但人眼按 Weber 定律相对局部亮度判噪声（阴影里同幅噪声更显眼）。
故引入**感知加权指标**：误差 × `w(L)=1/(L+0.05)^γ`，扫 **γ：0(纯MSE) → 1.5(强阴影强调)**。
**诚实前提**：Zoom 曲线(~1/luma) 与 Weber 权重(~1/luma) 同形状，"Zoom 在 Weber 下赢"近乎循环——
故不挑单点，而是扫 γ 看**在何处反超**，并补 Part C 检验"噪声形状"这个真正的自变量。

## 结果

**Part A — shot 形噪声（真实 C270 实测那种）+ 感知指标：**

| γ | uniform | noise-matched | zoom | best |
|---|---------|---------------|------|------|
| 0.0 | 39.15 | 39.15 | 38.01 | uniform |
| 0.5 | 40.52 | 40.52 | 39.81 | noise-matched |
| 1.0 | 41.47 | 41.48 | 41.18 | noise-matched |
| 1.5 | 41.88 | 41.89 | 41.80 | noise-matched |

→ γ 升高，zoom **只缩小差距、从不反超**（-1.14dB→-0.09dB）。真实 clip（Part B）同理，zoom 全程略差。

**Part C — shadow-heavy 噪声（线性域 PG + gamma 编码，σ 随亮度下降，已核验 0.199→0.079）+ 感知指标：**

| γ | uniform | noise-matched | zoom | best |
|---|---------|---------------|------|------|
| 0.0 | 28.92 | 30.10 | 29.86 | noise-matched |
| 0.5 | 27.29 | 28.73 | **29.31** | **zoom** |
| 1.0 | 26.60 | 28.11 | **29.06** | **zoom** |
| 1.5 | 26.34 | 27.85 | **28.96** | **zoom** |

## 结论（完整的 2×2，诚实）

|  | 纯 MSE 指标 | 感知(阴影加权)指标 |
|--|-------------|-------------------|
| **shot 形噪声**（真实 C270） | noise-matched/uniform 胜 | noise-matched 胜（zoom 缩差但不反超） |
| **shadow-heavy 噪声**（gamma 域） | noise-matched 胜（自适应） | **zoom 胜** |

**Zoom 的阴影加权强度曲线只在"噪声本身阴影重 **且** 评价是感知口径"两个条件同时成立时才最优**——单独任一个都不够：
- shot 噪声下即便用感知指标，zoom 也不赢（**你无法降不存在的噪声**：阴影噪声少，再怎么加权也挤不出收益，还饿死了有噪声的高光）；
- shadow-heavy 噪声下若只用 MSE，noise-matched 反而更好（它**自适应**地把强度花到噪声所在，此时正好是阴影，比 Zoom 的**固定** 1/luma 曲线更准）。

**工程落地**：
- **noise-matched（自适应）是 4 个格子里 3 个的稳健赢家**，且它自己测噪声、不需假设——**首选**。
- Zoom 的**固定**阴影曲线是一种**特化**，只在它的目标工况（gamma 域 sRGB 视频 + 人眼观看 = shadow-heavy 噪声 + 感知目标）才划算——**这大概率正是 Zoom 的实际工况，解释了它为何这么设计**。
- 我们的场景（C270 实测 shot 噪声 + 客观指标）不在那个格子里，故不采用 Zoom 曲线；已留 `zoom_strength01` 备用于 shadow-heavy 工况。

## 局限

- 感知指标是简化的 Weber 亮度掩蔽（`1/(L+L0)^γ`），非 VMAF/正式主观实验；结论的方向稳健（跨 γ 一致），但绝对分不等同人眼 MOS。
- gamma 域噪声是理想模型（linear PG + 单一 gamma），真实 ISP 更复杂。
- 未上真正的主观观看实验（人打分）——若要给 Zoom 的取向"终审"，那才是金标准。
