# NOTES — video-denoise

## 状态

- **2026-07-21**：项目初建。目录骨架 + CLAUDE.md（领域纪律）+ CONTEXT.md（初始领域语言与候选架构面，均 `[待核实]`）。
- 当前阶段：**P0 全景对齐**。

## 已对齐

- **目标场景 = 实时视频流**（2026-07-21 用户确认）→ 主线递归类轻量网络，详见 CONTEXT.md §6。
- **本机硬件**（2026-07-21 实测）：Intel UHD 770 + Radeon RX550 4GB，无 CUDA。
  推理走 DirectML；本机只做微型训练实验，长训练资源待定。

## 待对齐问题

1. 噪声类型优先级（低光传感器噪声 vs 压缩噪声 vs 通用合成）——默认低光传感器噪声，待确认。
2. 长训练资源（本机不可行时：公司 GPU 机器？云？）——到 P2 需要时再对齐。

## 当前假设（未验证）

- 合成 Poisson-Gaussian 噪声训练的模型对真实低光摄像头噪声有一定泛化，但需真实序列验证。
- 递归结构在等算力下时域收益优于滑窗（延迟也更优），需 P2 对照实验。

## 已证伪方向

（暂无）

## 2026-07-21 补充：Zoom zlt.dll 逆向（架构地图完成）

- 用 IDA 7.5 无头分析逆向了 Zoom `zlt.dll`（自研视频媒体引擎）。产物在 [`zlt-re/`](zlt-re/)：
  `model/map.json`（全 DLL map：8273 函数/428 类/266 导入）、`model/rtti.json`（关键类继承）、
  [`zlt-re/notes/ARCHITECTURE.md`](zlt-re/notes/ARCHITECTURE.md)（完整架构地图）。
- 逆向定位：**纯理解/净室学习**（不复制代码、不提取权重、不做重分发克隆）。
- **载荷结论**：Zoom 实时视频降噪 = 经典 DSP（空域/时域/IIR递归/双边/导向），非 NN；VPP 是统一插件框架跑在 D3D 计算着色器上。→ 已回写 CONTEXT.md。
- **重建范围待决策**（ARCHITECTURE.md §9）：A 读降噪链函数体并净室重建作经典基线 / B 搭 VPP 插件骨架 / C 暂不重建，先走原 P1。

## 2026-07-21 续：净室重建降噪链 + P1 反馈环打通（选项 A 完成）

- Phase 3 读了 `zltCDenoise`/`zltCIIRDenoise`/`zltCTemporalDenoise`/`zltCRecursiveBF` 的函数体，
  算法确认写入 [`zlt-re/notes/DENOISE_ALGORITHMS.md`](zlt-re/notes/DENOISE_ALGORITHMS.md)（分析笔记，含 EA 锚点+常量作事实，无反编译原文）。
  核心：zltCIIRDenoise = 噪声/运动自适应时空递归滤波（亮度噪声查表 + 定点时域 IIR 混合）。
- 净室实现（原创代码，不复制 Zoom 常量/查表）：
  - [`scripts/classical_denoise.py`](scripts/classical_denoise.py)：空域 bilateral/gaussian、固定 IIR、**运动自适应递归降噪**（zltCIIRDenoise 的净室等价）。
  - [`experiments/exp01_classical_baseline.py`](experiments/exp01_classical_baseline.py)：合成噪声数据 + 评估（PSNR/bgPSNR/fgPSNR/flicker）+ 一键复现。
- **实测结论**（详见 [`notes/exp01-classical-baseline-results.md`](notes/exp01-classical-baseline-results.md)）：运动自适应递归降噪全面胜出——bgPSNR 30.1 + fgPSNR 27.0（无拖影）+ flicker 最低 17.2，总 PSNR 领先次优 +3.2 dB。固定 IIR α=0.92 拖影被量化（fgPSNR 崩到 21.4）。
- **原理收获**：运动阈值须标定到噪声水平（这解释了 zltCIIRDenoise 的亮度噪声查表存在的意义）。

## 2026-07-21 续²：噪声工作包完成（exp02）

- 盲噪声估计 `estimate_nlf`（Poisson-Gaussian NLF，单帧）+ 噪声自适应降噪 `NoiseAdaptiveRecursiveDenoiser`
  （逐像素运动阈值 = `k·σ_noise(亮度)`），见 [`scripts/classical_denoise.py`](scripts/classical_denoise.py)。
- 实验 [`experiments/exp02_noise_adaptive.py`](experiments/exp02_noise_adaptive.py)，结论 [`notes/exp02-noise-adaptive-results.md`](notes/exp02-noise-adaptive-results.md)：
  - 估计器：a/b 分解病态（纹理致 a↔b 折衷），但**总 σ 估准（~15%）且跨档跟踪**——阈值用途够。
  - 噪声自适应阈值**在固定阈值调优点打平、其余档位全胜，重噪(peak=10)大幅领先(bg+2.3/fg+2.2 dB, flicker-25%)且零重调**。
  - 唯一旋钮 `k_motion` 膝点 k≈4–6，默认 5。把"按噪声档位重调绝对阈值"换成"跨档不变的相对旋钮"。
- 落地了 exp01 的原理性发现，印证 zltCIIRDenoise 亮度噪声查表的意义。

## 2026-07-21 续³：噪声工作包收尾（时域估计 + 真实低光实拍）

- **时域帧差噪声估计**（exp03，结论 [`notes/exp03-temporal-noise-est-results.md`](notes/exp03-temporal-noise-est-results.md)）：
  `estimate_nlf_temporal`——静止区帧差内容抵消、Var(d)=2σ²、MAD 抗移动离群。
  低噪(peak=80)决定性摆脱纹理偏差(a 误差 −52%→+1%)；高噪下 errors-in-variables + 截断致两法都退化(非纹理问题)，
  但典型亮度 σ 全程 ~5–20% 内，下游够用。设为首选估计器。
- **真实低光实拍**（Logi C270，结论 [`notes/real-lowlight-results.md`](notes/real-lowlight-results.md)）：
  常光抓拍几乎无噪；改**手动短曝光 `--exposure -8`** 强制低光（中位亮度 0.13）。
  静止区 flicker 降 **69%**，主观暗区颗粒明显减少且保结构。
  **关键教训：真实噪声≠合成 AWGN**——空域/时域 σ 分歧 3×(空域 0.070/时域 0.024)，指示机内 ISP + 空间相关/固定模式残留；阈值以时域为准。
  工具就绪：[`scripts/capture_webcam.py`](scripts/capture_webcam.py)（支持手动曝光/增益）+ [`scripts/denoise_video.py`](scripts/denoise_video.py)（无 GT harness：σ 估计 + 自动静止区 flicker + montage）。

## 2026-07-21 续⁴：相机真实噪声模型（exp05，缩小合成↔真实差距）

- [`scripts/noise_models.py`](scripts/noise_models.py)：`add_realistic_noise_seq`，在 Poisson-Gaussian 上加三成分（默认关→退化为 PG）：
  **空间相关**（机内低通）、**固定模式噪声 FPN**（DSNU 加性 + PRNU 乘性，逐帧不变）、**时域相关**（AR(1)，机内时域降噪）。`C270_LIKE` 预设。
- 实验 [`experiments/exp05_realistic_noise.py`](experiments/exp05_realistic_noise.py)，结论 [`notes/exp05-realistic-noise-results.md`](notes/exp05-realistic-noise-results.md)：
  - **Q1（修正 exp04 猜测）**：真实"空域σ≫时域σ"分歧的主因是**时域相关（机内时域降噪把帧差压低）**，**不是 FPN**（FPN 在此噪声水平几乎不动比值），也不是空间相关（反而压低空域）。合成模型现能复现方向与机理（比值 1.5–1.6，真实 ~3×，未强拟合）。
  - **Q2**：FPN 穿透——无噪输入下纯时域 IIR 残留误差 = 注入 FPN（corr=1.000，RMS 相同）；时变 flicker 去掉 71%。→ 时域降噪去不掉 FPN，需正交的 FPN 标定（暗场/平场）。
- 方法论收获：先前 Q2 用"时域平均误差"指标被残留噪声/瞬态/空域偏置污染，放弃改用干净数学事实演示——诚实迭代。

## 2026-07-21 续⁵：从 Zoom 二进制恢复噪声参数 + 真实数据核验（exp06）

- IDA 从 `zlt.dll` 恢复 `zltCIIRDenoise` 的每亮度常量表 `qword_1805057D0`（.rdata 只读）+ 系数，
  记 [`zlt-re/notes/ZOOM_NOISE_PARAMS.md`](zlt-re/notes/ZOOM_NOISE_PARAMS.md)，拟合式进 [`scripts/zoom_noise.py`](scripts/zoom_noise.py)（3 参数拟合，不含原始表/反编译原文）：
  曲线 `≈117.6/(luma+0.1)+0.22`（~1/luma，阴影加权，luma≥127 置 0）；时域混合 0.648；luma 分支 82。
- **关键核验（exp06，[结果表在 ZOOM_NOISE_PARAMS.md]）**：拿真实 C270 clip 逐亮度测噪声 σ——
  **真实 σ 随亮度上升（Poisson-Gaussian 形），与 Zoom 曲线（阴影加权、下降）方向相反，PG 拟合好 ~5×**。
  → **Zoom 那张表是每亮度降噪强度曲线，不是噪声 σ**；我先前"1/luma=读噪经gamma"的物理解释被真实数据否证。
- **落地**：噪声模型保持 PG 形（真实验证），真实 clip 反标定 PG 参数进 `noise_models.py` 的 `C270_MEASURED`（peak≈476/read≈0.013，注明时域下界/灰度/该曝光）；Zoom 强度曲线归降噪器（`zoom_strength01`，待接入）。
- 方法论：恢复常量是一步，**弄清常量语义要独立证据**（真实噪声形状），不能只凭数值形状脑补物理意义。

## 2026-07-21 续⁶：Zoom 强度曲线接入降噪器（exp07，含否定结果）

- 新增 `LumaProfileRecursiveDenoiser`（[`scripts/classical_denoise.py`](scripts/classical_denoise.py)）：按亮度调制运动阈值；
  三种强度分布归一化到相同均值对比：uniform / noise-matched(∝噪声σ) / zoom(∝Zoom曲线)。
- 实验 [`experiments/exp07_zoom_strength_profile.py`](experiments/exp07_zoom_strength_profile.py)，结论 [`notes/exp07-zoom-strength-profile-results.md`](notes/exp07-zoom-strength-profile-results.md)：
  **Zoom 阴影加权在客观指标上更差**——合成双带场景总 PSNR 38.01 vs uniform 39.15（两区都差），真实 clip flicker 也略差。
  机理：真实噪声 shot 形（高光多），zoom 把强度堆阴影→过平滑低噪阴影 + 高光欠降噪，两头吃亏。
- **诚实解读**：Zoom 阴影加权是**感知取向**（人眼对阴影噪声更敏感），我们的 PSNR/flicker 是 SNR 口径、奖励不了；
  且 Zoom 曲线隐含"阴影噪声重"场景，与 C270 实测 shot 形相反。此为"思路移植进我们机制+我们指标"的结果，非 Zoom 降噪器 1:1。
- **落地**：我们这套客观优化的降噪器用 uniform/noise-matched 即可；Zoom 曲线仅在感知指标或阴影主导噪声时才值得用（已留 `zoom_strength01` 可选）。

## 2026-07-21 续⁷：感知指标下重判 Zoom 曲线（exp08，完整 2×2）

- 引入感知加权指标（Weber 亮度掩蔽 `err×1/(L+0.05)^γ`，扫 γ）+ gamma 域 shadow-heavy 噪声（`add_pg_gamma_domain`）。
  实验 [`experiments/exp08_perceptual_metric.py`](experiments/exp08_perceptual_metric.py)，结论 [`notes/exp08-perceptual-metric-results.md`](notes/exp08-perceptual-metric-results.md)。
- **完整 2×2 结论**：Zoom 阴影加权曲线**仅在"噪声阴影重 且 评价是感知口径"两条件同时成立时最优**：
  - shot 噪声（真实 C270）+ 任意 γ → noise-matched 胜（zoom 缩差不反超，"降不了不存在的噪声"）；
  - shadow-heavy 噪声 + 纯 MSE → noise-matched 胜（自适应比 Zoom 固定曲线更准）；
  - shadow-heavy 噪声 + 感知 γ≥0.5 → **zoom 胜**。
- **落地**：**noise-matched（自适应）是 4 格中 3 格的稳健赢家 → 首选**。Zoom 固定曲线是特化，只在其目标工况
  （gamma 域 sRGB 视频 + 人眼观看 = shadow-heavy + 感知）才划算——大概率正是 Zoom 实际工况，解释其设计。
  我们场景（C270 shot 噪声 + 客观指标）不在那格，故不采用；`zoom_strength01` 留作 shadow-heavy 备用。
- 三步串起来的教训：从二进制拿参数 → 真机核验语义 → 接入并在**多工况×多指标**下判定，才知道一个商用设计"对不对/何时对"。

## 2026-07-21 续⁸：WPF 实时降噪 Demo（可执行 EXE 交付）

- [`DenoiseDemo/`](DenoiseDemo/)：.NET 9 WPF，OpenCvSharp 采集 + 我们降噪器的 C# 移植（`DenoiseCore.cs`，与 `scripts/classical_denoise.py` 一致）。
  实时并排 noisy|denoised，处理 Y 通道保留色度；控件=摄像头/曝光(强制低光)/5 档降噪(Off/Spatial/Motion-adaptive/noise-matched/Zoom)/σ_motion/α_max/在线噪声 σ 读数；可 Load video 跑 `samples/lowlight_exp8.mp4`。
- 交付：自包含 EXE `DenoiseDemo/publish/DenoiseDemo.exe`（含原生 OpenCV 58MB，双击即用）；说明见 [`DenoiseDemo/README.md`](DenoiseDemo/README.md)。
- 验证：build 0 error；`SmokeTest/`（net9 无头控制台）跑通原生 OpenCV + DenoiseCore 全 5 模式(~1–5ms/帧@120×160)。GUI 交由用户实测。

## 2026-07-21 续⁹：修复 demo 波纹/banding bug

- 反馈：平滑皮肤区降噪后出现跟随等亮度线的波纹。诊断 [`notes/banding-bug-diagnosis.md`](notes/banding-bug-diagnosis.md)（复现 exp09）。
- **根因**：8-bit 量化等高线断层(banding)——降噪移除了"抖动量化器的传感器噪声"后底层断层显形（bilateral 阶梯效应叠加）；clean 极低对比度渐变本身在 8-bit 就 banding(run 15/20 电平),肉眼可见即用户的伪影。残余噪声≈1LSB 时天然抖动掩盖,降噪够狠(残余<1LSB)时显现。
- **修复**：输出前加亚-LSB TPDF 抖动(±1LSB,不可见,打散硬等高线;run 15.24→2.05)。C# `Denoiser.DitherAmp`(默认1.0)+ ApplyDither(**只抖动显示副本,递归 state 保持干净**否则累积);UI "Debanding dither" 勾选(默认开,可关看波纹回来=验证)。已重编译 EXE。
- 诚实：在合成极低对比度渐变上复现并验证,非用户真实帧;若 amp=1 不够可调到 2–3 或降 SigmaColor(0.18→0.08)减阶梯。待用户实测确认。

## 2026-07-21 续¹⁰：运动拖影 bug（未能合成复现，加候选修复待实测）

- 反馈：快速晃手指时，denoised 里手指网格状伪影 + 背景留淡拖影(箭头)。dither 开关无关 → 是运动路径问题。
- **机理(已理解，未合成复现)**：递归时域降噪对快速运动拖影——帧差在**平滑运动区内部欠检测运动**(aperture problem)→ α 未降 → 历史串入(网格);高 α 留旧历史(拖影)。
- **诚实**：exp10 两次合成复现都**太弱**、指标(trail-err)也没抓住该伪影(参数调 sigma/blur/alpha 几乎不动 trail-err）——**没建成可靠离线反馈环**。
- **候选修复(标准手段，未验证)**：运动守卫 = 空间膨胀(把运动从边缘扩到平滑内部)+ 时域冷却(运动持续几帧，清拖影)。加入 [`scripts/classical_denoise.py`](scripts/classical_denoise.py)(`motion_dilate`/`motion_decay`，默认关不改旧实验) 与 C# `DenoiseCore`(`MotionDilate=8`/`MotionDecay=0.6` 默认开)+ UI "Motion guard" 勾选。稳态耗时~1.5ms(膨胀是可分离形态学，17ms 是 JIT 预热)。已重编译 EXE(16:39)。
- **真解**：运动补偿(光流)时域滤波，是大改；商用产品(Zoom 等)走这条。

- 用户实测确认运动守卫有效（"效果好了很多，没有明显伪影"），并选定**推进光流运动补偿根治**。

## 2026-07-21 续¹¹：光流运动补偿(MCTF)根治运动拖影

- 先修反馈环：exp10 的 trail 指标对该伪影不敏感；改用 **fg-PSNR(移动物体内部保真度)** 才抓得住（网格伪影=物体与错位历史混合的内部误差）。
- 实现 MCTF [`scripts/classical_denoise.py`](scripts/classical_denoise.py) `MotionCompensatedDenoiser`：Farneback 光流(current→prev)→ remap 把历史对齐到当前 → 残差(遮挡/光流失败)→α → 融合。半分辨率算光流提速。
- 验证 [`experiments/exp11_motion_compensated.py`](experiments/exp11_motion_compensated.py)：移动纹理物体上 **MCTF fg-PSNR 33.08 vs 守卫 30.23（+2.85dB），static-flick 相当**；crop 视觉确认 MCTF 物体更干净、无拖影/网格。这是可测的反馈环 + 结果。
- 落地 demo：C# [`DenoiseDemo/DenoiseCore.cs`](DenoiseDemo/DenoiseCore.cs) `ProcessMCTF`(OpenCvSharp Farneback+Remap，FlowScale=0.5)+ 下拉新增 "Motion-compensated (optical flow)"。已重编译 EXE(16:55)。MCTF 比其他档耗时(光流)，fps 会低些，FlowScale 可调。

## 2026-07-22：MCTF 在低纹理场景反而更差（"水面划痕"）

- 用户实测：MCTF 比守卫更差，箭头处有"手指划过水面"的运动划痕。诊断：Farneback 光流在**大片低纹理区(白天花板)估计错误**→错误 warp 历史→平滑区错 warp 残差仍小、遮挡门拦不住→逐帧累积成漂移划痕。低纹理场景 MCTF 可能不如不依赖光流的守卫。
- **诚实：合成复现失败第 2 次**（exp12 低纹理场景 MCTF 仍略优于守卫，抓不住划痕）——我的合成场景太干净/有结构，抓不住真机"纯白无纹理+快速晃动+真噪声"的光流失效。**离线反馈环建不出，真机才是这俩运动伪影的 loop。**
- 候选修复：MCTF 加**前后向光流一致性门**(fb_check，正反各算一次光流，往返对不上→降权退空域)。Python `MotionCompensatedDenoiser(fb_check=True)` + C# `DenoiseCore.FbCheck`(默认开)。未验证（同上，合成抓不住）。
- 加了 **Record 6s(raw) 按钮**：demo 里录一段原始输入到桌面 `denoise_clip_*.mp4`，用于我在真实数据上复现+验证。已重编译 EXE、刷新桌面副本(9:22)。
- **结论/建议**：**守卫(guard)是稳健默认**（不依赖光流、快、用户已确认有效）；**MCTF 是高上限但脆弱的选项**（纹理运动上更优 exp11 +2.85dB，但featureless场景会划痕）。要根治 MCTF 需真机片段验证 FB 门 + 可能换 DIS 光流。

## 2026-07-22：真实片段验证 → MCTF 在本用例不划算（负结果，已定论）

- 用户录了真实失败片段 `denoise_clip_092846.mp4`（90帧，手指快速晃过白天花板）。**真机反馈环终于建成**（拷入 [`samples/real_motion/`](samples/real_motion/)，实验 [`experiments/exp13_real_motion.py`](experiments/exp13_real_motion.py)）。
- **结果（真实数据）**：低纹理区 streak-proxy（flat 温度std）guard **4.39** < MCTF-nogate **4.79** < 但 MCTF-fbgate **4.75**（FB 门几乎没用）。温度std 热图：两者对手指(合理)一致，featureless 天花板上 MCTF 无优势、略差。→ **复现了用户观察：MCTF 略差、FB 门修不好。**
- **机理定论**：MCTF 需要"可跟踪的运动 + 有纹理"，本片段两者都缺（快速运动模糊的手指 + 纯白天花板）→ 光流不可靠 → 无增益反划痕。合成 exp11 MCTF 赢 +2.85dB 是因为那是有纹理/中速运动——**MCTF 是对的工具用错了场景**。
- **定论/收口**：**守卫(guard=Motion-adaptive recursive)为默认与推荐**（demo 下拉默认就是它，index 2；不依赖光流、快、真机已确认好）。**MCTF 标为实验档**：仅在有纹理+中速运动内容（如人脸视频通话）可能有益，featureless/快速场景不要用。**不再为本用例投入 MCTF**（换 DIS/RAFT 光流是更大投入，仅当目标用例变成纹理/中速运动才值得）。

## 2026-07-22：P2 单帧 NN 降噪(训练反馈环 + vs 经典)—— 质量赢、CPU算力未达标

- 装了 PyTorch 2.8 **CPU**(本机无 CUDA)。模块 [`scripts/nn_denoise.py`](scripts/nn_denoise.py)(DnCNN 105k 残差网 + 合成 Poisson-Gaussian 数据管线)。
- **P2.1 反馈环(铁律先建)✅**：[`exp14`](experiments/exp14_nn_overfit.py) 微型过拟合 8 patch → 2000步 loss 5e-5、重建 17.9→**42.6 dB**，全链路正确。
- **P2.2 训练+对照** [`exp15`](experiments/exp15_nn_train_vs_classical.py)：512 patch/24ep/108s。质量 held-out：DnCNN **25.75dB/0.70** vs bilateral 22.56/0.57(**+3.2dB**,NN 质量赢);
  但每帧算力@480×640 CPU：DnCNN **206ms** vs bilateral 3.5ms(慢60×,≈5fps 不实时)→**质量达标、CPU算力未达标**。
- 结论 [`notes/p2-nn-results.md`](notes/p2-nn-results.md)：NN 质量优势真实,但要实时需 GPU/ONNX(RX550/UHD770 DirectML,衔接 voice onnxruntime 经验)或轻量架构。CPU 是上界。

## 2026-07-22：P2 算力桥 ONNX+DirectML —— 负结果(GPU 死路)

- 装 onnxruntime-directml 1.19.2。DnCNN 导 ONNX(parity 2e-6 ✅)。实验 [`exp16`](experiments/exp16_onnx_directml_bench.py)，结论 [`notes/p2-onnx-directml-results.md`](notes/p2-onnx-directml-results.md)。
- 实测(640×480):CPU 84ms/12fps、DML adapter0 报错回退CPU、**DML adapter1(真GPU)126ms/8fps 比CPU还慢**。实时线33ms 无一达标(仅 320×240 CPU ~20ms 近实时)。
- **结论:本机 GPU 是死路——DirectML 不加速反更慢**(UHD770核显+低端RX550太弱 + DML 调度/拷贝开销 > 小卷积网 GPU 收益)。当前 DnCNN 本机无法实时(CPU/GPU 都不行)。经典 bilateral 3.5ms 仍碾压。

## 2026-07-22：净室重建 zltCIIRDenoise 降噪模块 ✅

- 补全分析:驱动 `sub_1802A52F0`(setup 128×128/16×16/9 + 内核,两强度档=对象字段+2068/+2072)、内核 `sub_1802A6DF0` 完整(9×16 块,LUT+活动度+暗/亮分支 V82+归一化+166/256 IIR)。**诚实:内核疑似产出"时域稳定噪声/细节 level 图"steer平滑/量化,非直接去噪像素——精确语义=static-RE 地板**。详见 [`zlt-re/notes/DENOISE_ALGORITHMS.md`](zlt-re/notes/DENOISE_ALGORITHMS.md) §4.5/4.6。
- 净室模块 [`scripts/zlt_denoise.py`](scripts/zlt_denoise.py)(原创代码,非反编译改名):忠实层 `detail_level`(内核数学净室重实现,exp17 核验分支/曲线/0.648 混合正确)+ 解释层 `ZltVppDenoiser`(用恢复配方 v30→阈值/0.648→时域上限接成去噪器)。
- 验证 [`exp17`](experiments/exp17_zlt_recon.py):合成 PSNR 25.77(>bilateral 24.43),真实 clip flicker 降 64%,无明显伪影;比我方 noise-adaptive 保守(恢复 α_max=0.648<0.95)。
- 边界:去噪像素 vs 强度图 = 静态地板,解释层为诠释;恢复常量属事实。

**步骤1+2 精确化/深逆(2026-07-22,回应"是否一模一样")**:
- 步骤1 精确 LUT:提 256 精确值存 `scripts/zlt_lut.npy`,模块改用精确表。**修正拟合的亮区错误**(精确表 V≥127 硬为0,拟合给~1.1)。每亮度曲线现为精确事实。
- 步骤2 setup/buffer 逆向:`sub_1802A5CB0`=buffer分配(委托 this+2000 管理子对象),非算法;类是薄包装,委托 +2000 子对象。**仍地板**:a2/a4 平面内容语义、v14 标志条件、活动度邻像素内容、输出=去噪像素vs强度图——需动态抓帧或上层 VPP 驱动追。
- **诚实结论**:忠实层(内核数学+精确LUT)=精确恢复;但模块级(活动度输入/去噪接线/输出语义)仍未确认,ZltVppDenoiser 接法仍是诠释。要坐实需动态抓帧逐值比对。

**动态验证方案A完成 → 内核数学 BYTE-EXACT ✅(2026-07-22)**:
- harness [`scripts/zlt_harness.py`](scripts/zlt_harness.py):LoadLibrary 真实 zlt.dll,base+RVA(0x2A6DF0)直调内核,喂自建 9×16 平面+最小 this 桩,读回逐值比对。DLL 哈希=逆向那份。
- **3 组配置(时域开/关/hi-level+flag)全 144/144 逐像素相等,max diff=0 → 内核逐像素数学与真实 zlt 一致(硬证据)**。
- 动态抓到真实 quirk:内核 V≥128 **越界读** LUT(有效表仅 0..127)→ 读相邻指针(≈4e12)→ 亮支 v30 巨负 → v32 地板到 5。即 **zlt 对 V≥128 恒输出 5**。已用哨兵 `zlt_lut.npy[128:]=1e12` 忠实复现(静态零填充没抓到,动态才现形)。
- **更新答案:内核(算法数学)现确认与 Zoom 逐值一致;整模块(a2/a3/a4 平面内容语义 + 输出被当去噪像素vs level图)仍未确认,需方案B挂活进程。ZltVppDenoiser 去噪接线仍是诠释。** 详见 [`zlt-re/notes/DENOISE_ALGORITHMS.md`](zlt-re/notes/DENOISE_ALGORITHMS.md) §4.8。

## 2026-07-22:方案B活hook被反篡改挡 → 静态追踪解决"像素vs level图"

- 方案B(Frida hook 活 Zoom)**被反篡改杀进程**(注入即触发,PID退出);**不 defeat 保护**,放弃活 hook。
- 改**静态消费者追踪**(纯 IDA,零风险),解决关键歧义。结论(详见 [`zlt-re/notes/DENOISE_ALGORITHMS.md`](zlt-re/notes/DENOISE_ALGORITHMS.md) §4.9):
  - 驱动/IIR/config 均 0 静态调用者=虚分派(VPP 框架驱动);
  - obj+568 平面=**固定 144-stride 每块统计图**(值×16 封顶160/200,时域EMA 0.75/0.86),**非帧像素**;
  - zltCIIRDenoise 是更大 VPP 降噪类的**子对象(owner+4168)**:owner 算统计→喂它温度平滑成 level 图→跑内核出稳定 level 图→下游消费。
- **最终结论**:**zltCIIRDenoise 内核输出=时域稳定的每块噪声/细节 LEVEL 图(固定尺寸,非像素),是 steering 子组件不是像素降噪器;"IIRDenoise"指对该图做 IIR 时域平滑。真正抹像素的是别的类(zltCDenoise/RecursiveBF)由此图 steer。**
- 对"一模一样":✅ byte-exact 恢复的内核数学是真的、是这张 level 图生成器的数学;❌ 但它不是像素降噪器,真正的像素降噪模块(另一组类)未重建;⚠️ `ZltVppDenoiser` 是我方把 level-图数学改用成的像素降噪器(能跑但非 zltCIIRDenoise 功能复刻)。

## 2026-07-22:逆 Zoom 像素降噪类族(算法地图 + 导向滤波净室实现)

- 定位内核(map.json region/size)+ 反编译(kernels_decomp.json)。每个类三段式:参数helper + 分块WPP分发器 + SIMD worker 内核。详见 [`zlt-re/notes/PIXEL_DENOISE_FAMILY.md`](zlt-re/notes/PIXEL_DENOISE_FAMILY.md)。
- **算法识别**:zltCRecursiveBF=递归双边(Yang2012,值域曲线+0.79EMA+σ3.5)、zltCGuidedFilter=导向滤波(He2010)、zltCTemporalDenoise=Haar变换域时域(0.3535/0.7071)、zltCDenoise/ASM=空域边缘保持SIMD(tiled+WPP)、zltCGeneralFilter=通用卷积。
- **净室实现** [`scripts/zlt_pixel_denoise.py`](scripts/zlt_pixel_denoise.py):`guided_filter`(He2010,原创)+`GuidedRecursiveDenoiser`(导向空域+运动自适应时域)。验证:合成PSNR18.9→23.1,真实clip flicker降**82%**(最好),无伪影。
- **诚实边界**:算法身份+关键常量已恢复(高置信);实际像素kernel是手写SIMD worker,byte-exact复刻=static-RE地板。实现的是"类所用的标准算法+恢复参数",非SIMD逐字复刻。与zltCIIRDenoise不同(那个做到byte-exact),本族只到算法识别+标准净室实现。
- **完整图景**:zltCIIRDenoise(level图,byte-exact)→steer→本族像素降噪器→去噪帧。

## 2026-07-22:导向滤波抠参数(eps+变体)+ 彩色实现 + 其余类抠参

- **导向滤波逐条读 SIMD div 段**:结构=3×3 协方差矩阵求逆 → **彩色 3 通道导向滤波**(非灰度,变体纠正);eps=对角加的 v33=**25.0**(8-bit)≈(0.02)²;窗口 5×5。
- **#1 实现彩色导向滤波** `color_guided_filter`([scripts/zlt_pixel_denoise.py](scripts/zlt_pixel_denoise.py)):Zoom 变体 + 恢复参数。单独只降 flicker 5%（eps 小=有意"轻"，重降噪靠时域+level 图 steer；这本身是设计洞察）。
- **#2 抠其余四类参数**（consts_family.json，角色多为推断）：RecursiveBF σ=3.5/时域EMA=0.79/断点曲线{0.1..1.0}；TemporalDenoise Haar+阈值{0.4,0.5,1.5,10,50}+微正则5.9e-5；**Denoise/GeneralFilter 无烘焙强度常量→强度被 level 图 steer/config**（架构印证）。详见 [`zlt-re/notes/PIXEL_DENOISE_FAMILY.md`](zlt-re/notes/PIXEL_DENOISE_FAMILY.md)。
- **对"只差 SIMD/循环"**：导向滤波最接近（算法变体+窗口+eps 都恢复，仅剩定点 scale）；其余类恢复了主要常量但角色为推断，Denoise/GeneralFilter 强度非烘焙（靠 steer）→ 本就不是"同一套自带参数"。

## 2026-07-23:demo 测 zlt 降噪 + 加 level 图 steering(去磨皮)

- 加了 demo 档:ZLT guided(导向滤波 5×5+eps=0.02²)、ZLT-IIR recipe(阴影加权+0.648)。
- 用户反馈 ZLT guided "像开了美颜"——导向滤波 eps=0.02² 抹掉皮肤纹理(磨皮原理即此)+ demo 无 steering 全画面均匀施加。
- **改进(更接近 Zoom):给 ZltGuided 加 level 图 steering** —— 在**去噪估计**上测局部细节(Sobel magnitude,region-level),平坦/噪声区用平滑结果、细节区(纹理/边)保留原图(τ=0.03≈噪声级),再运动自适应时域。忠实于"level 图 steer 平滑"架构;确切 steering 公式为我方构造(Zoom 精确接线=RE 地板)。关键:细节从去噪估计算,否则噪声被当细节。ZltGuided 9.4ms/帧仍实时。已重编译+刷新桌面副本。

## 2026-07-24:修 ZLT guided 运动残影(真机片段复现+验证)

- 用户录 `denoise_clip_143109.mp4`(人晃动),报 ZLT guided 出残影。**真机帧复现成功**(samples/zlt_recon/ghost_f079.png):脖子皮肤网格 + 平滑胸口幽灵轨迹 = 运动 ghosting(时域混错位历史,导向滤波洗干净后双影更显)。
- **先证伪 steering 猜测**:合成上三种 steer 结果相同(平滑区 steering 是空操作)→ 不是 steering。
- **真因**:ZltGuided 的 `BlendTemporal` **没用运动守卫**(dilate+cooldown,其他档有)→ 平滑内部欠检测运动(aperture)→ 历史串入。
- **修复+验证**:给 BlendTemporal 加守卫(dilate+env cooldown,复用 MotionDilate/MotionDecay/_env)。真机帧实测运动区 ghost 减半(0.0132→0.0064),montage 确认网格/幽灵消失。已重编译+刷新桌面副本(14:36)。
- 方法论:又一次合成复现不出(先证伪 steering)、真机录像一击命中→修+验。这类平滑渐变/运动伪影,真机是唯一可靠 loop。

## 2026-07-24 续:P2 轻量 NN 找到 speed/quality 前沿(无需任何数据集)

- **动机**:用户"没有轻量 NN 训练数据"。**结论:不需要外部数据集**——P1 合成管线(`make_clean_patches` 干净图块 + `add_pg_noise` 可控 Poisson-Gaussian)免费产出无限 (含噪,干净) 成对样本。exp15 的 105k DnCNN 太慢(199ms/帧 CPU)只是因为**过参数**。
- **exp18 前沿**(同一合成评测集,PSNR@64patch / 速度@480×640 CPU):

  | 变体 | 参数 | eval-PSNR | SSIM | ms/帧 |
  |---|---|---|---|---|
  | 经典 bilateral | – | 22.47 | 0.590 | 2.3 |
  | **tiny** | **745** | **25.04** | 0.697 | **6.3** |
  | small | 4,977 | 25.50 | 0.715 | 23.4 |
  | med | 16,153 | 25.60 | 0.720 | 52.6 |
  | heavy(exp15) | 105,073 | 25.64 | 0.714 | 199.4 |

  → **745 参数的 tiny 网络赢 bilateral +2.6dB,6.3ms/帧(~160fps)轻松实时**;tiny→heavy 只多 0.6dB(**边际递减**,tiny 已吃满大部分收益)。**推翻"NN 在本机太慢"**——过去慢是因为网络过大。
- **exp19/exp20 泛化验证(真机内容,诚实 loop)**:合成训练的 tiny 网络**能泛化到真实人脸/布料**。
  - exp19:真机近净片段上无伪影/无 blotch/无 ghost,细节保留**明显优于 bilateral**(bilateral 磨皮抹纹理,tiny 保纹理)。但该片段本身几乎不含噪(平坦 std 0.0017),不构成强测。
  - exp20(**真内容+可控噪声**,伪GT=真帧):tinyNN **27.49dB / SSIM 0.487**,bilateral 只 23.19 / 0.248,heavy 28.62 / 0.556 → **tiny 赢经典 +4.3dB、~2×SSIM,且仅落后 141× 大的 heavy 1.1dB**。montage:`samples/zlt_recon/realcontent_pg.png`。
- **模型产物**:`models/dncnn_{tiny,small,med,heavy}.pt`(单一噪声档 peak=30/read=0.03 训练)。**局限**:①单噪声档训练,变噪声/近净输入下鲁棒性未定(拟用盲噪声档重训);②纯合成内容训练(真内容泛化已由 exp20 证成,但真噪声分布未标定);③单帧空域,时域稳定性未纳入。
- 实验:[`experiments/exp18_lightweight_nn.py`](experiments/exp18_lightweight_nn.py)(前沿)、[`exp19_tinynn_realclip.py`](experiments/exp19_tinynn_realclip.py)(真机跑)、[`exp20_realcontent_pgnoise.py`](experiments/exp20_realcontent_pgnoise.py)(真内容泛化)。

## 2026-07-24 续²:盲噪声档重训 + ONNX 导出 + WPF demo 接入(可真机测)

- **盲噪声档重训(exp21)**:每图随机 peak∈[12,400] log-uniform + read∈[0.004,0.045](含近净档,避免对干净输入过度平滑),训 `dncnn_tiny_blind`(745p)/`dncnn_small_blind`(4977p)。真机内容多档 PSNR:**噪越重 NN 越赢**——near-clean bilateral 39.4>tiny 37.4(都很好,不磨皮),light(p80)打平,med(p30) tiny 26.7 vs bilat 23.2(+3.5),heavy(p15) tiny 24.0 vs bilat 18.3(+5.6),small 再 +1dB。
- **ONNX 导出**(动态 H/W,opset13):torch↔ORT parity ~1e-6;**onnxruntime CPU @480×640:tiny_blind 6.4ms、small_blind 15.1ms(都实时)**。产物 `models/dncnn_{tiny,small}_blind.{pt,onnx}`。
- **WPF demo 接入**:DenoiseCore.cs 加 `Microsoft.ML.OnnxRuntime`(CPU),新增 `DenoiseMode.TinyNN/SmallNN` = ONNX 跑单帧去噪估计 → 复用 `BlendTemporal`(带运动守卫)做时域稳定(单帧网络在视频上会闪,故加时域)。下拉新增两档;模型 onnx 随发布拷到 `models/`;加载失败优雅回退 bilateral。SmokeTest 加两档头测**真 ONNX 推理端到端通过**。已发布自包含 EXE(含 onnxruntime.dll 11.5MB)刷新桌面 `C:\Users\NCC Technology\Desktop\VideoDenoiseDemo\`(231MB,15:09)。
- ~~让 tiny NN 可用(盲档重训+ONNX+demo 接入)~~(**已完成**)。

## 2026-07-24 续³:用户真机测 NN 档 = 正向

- 用户真机测 TinyNN/SmallNN 档,主观"看上去还可以"(正向确认)。合成训练 → 真机可用这一步落地成立。
- 尚未采集具体失败模式(重噪主观差/伪影/闪烁/延迟感),下一轮若继续可让用户带具体观感录 clip。

## 2026-07-24 续⁴:时域 NN 第一切片 = 时域信息有净收益但 early-fusion 饱和 T=3(exp22)

- **动机**:用户选"做时域 NN(多帧输入)"。当前 demo 是"单帧 NN+经典时域"拼接,要验证真正把时域喂进网络的收益。
- **反馈环纪律奏效**:首次微过拟合用小网(745p)+16 序列只到 28.4dB<阈值→**被拦停**;诊断=阈值设错非管线 bug(loss 在降/重建 11→28dB=管线通,小网记不下)。改**高容量网(feat32/depth5)+4 序列**验管线→42.4dB/loss5.8e-5,**管线确认正确**(GT 索引/通道堆叠/反传)。教训:微过拟合要用够容量的网+少样本验管线,不能拿会饱和的小网设高阈值。
- **等容量对照**(唯一变量=输入帧数;三档取同一 5 帧运动序列的中心 T 帧,GT=中间帧,运动相同;合成运动序列=纹理画布+亚像素平移+逐帧独立 PG 噪声):

  | 变体 | 参数 | 中间帧 PSNR | SSIM | ms/帧@480×640 |
  |---|---|---|---|---|
  | noisy | – | 17.65 | – | – |
  | bilateral | – | 22.87 | 0.544 | – |
  | **T=1 单帧** | 753 | 26.21 | 0.693 | 4.8 |
  | **T=3** | 897 | **27.30** | 0.740 | 4.7 |
  | T=5 | 1041 | 27.20 | 0.738 | 6.5 |

- **结论①:时域信息有真实且近乎免费的净收益**——T=3 比同容量单帧 **+1.10dB/+0.047 SSIM**,参数只多 144(753→897),耗时不增(4.8→4.7ms)。→ 做时域 NN 的价值验证成立。
- **结论②:early-fusion 收益饱和在 T=3,T=5 不增反降(27.20<27.30)且更慢(6.5ms)**。瓶颈不是帧数是**小网隐式对齐能力到顶**(帧越远运动位移越大 early-fusion 硬堆通道对不齐)。→ 突破口=**显式运动补偿对齐后融合,或递归隐状态累积**,而非加帧数。
- 基础设施:[`scripts/nn_temporal.py`](scripts/nn_temporal.py)(运动序列数据 `make_motion_sequences`+逐帧独立/盲噪声+`TemporalDnCNN` early-fusion,T=1 即单帧)、[`experiments/exp22_temporal_ablation.py`](experiments/exp22_temporal_ablation.py)。模型 `models/tdncnn_T{1,3,5}.pt`。
- **待办(纪律要求单独记账)**:时域**稳定性**(warping error,合成运动已知位移可精确算)未测,是下一实验(exp23);递归 vs 滑窗的延迟/内存/质量分开记账未做。

## 下一步
- **推荐:突破 early-fusion 饱和**——A) 显式运动补偿融合(把 MCTF 对齐思想放进网络输入/或学对齐) B) 递归隐状态(逐帧进,复用上一去噪帧做隐状态,最贴合实时流延迟/内存最优)。同时补 exp23 时域一致性(warping error)口径。
- 可选:①真噪声标定训练(相机暗场/自监督 N2N,摆脱纯合成内容假设)②NN 与 ZLT guided 并排对照(都在同 demo)。
- ~~更轻架构找 speed/quality 前沿~~(**已完成**:tiny 745p 赢经典 +4.3dB@6.3ms 实时)。
- 备选:①降分辨率(320×240去噪~20ms 近实时)再上采;②分工收口(NN离线高质量+经典守卫实时);③换更强 GPU(本机无,待定)。
- 后续:真实噪声(相机片段自监督/伪GT)、时域 NN(对照守卫/MCTF)。
- 若 MCTF fps 不够：降 FlowScale / 换更快光流(DIS) / 只在检测到运动时启用。
- 回主线：进 P2 手搓 NN（经典基线 noise-matched + MCTF 作对照基准）；彩色全链路。
- 若要给 Zoom 取向"终审"：上真正的**主观观看实验**（人打分）或 VMAF（简化 Weber 非金标准）。
- 重拍**有真实运动**的低光序列，验证运动自适应防拖影（合成已验证，真实待补）。
- （进 P2）以经典基线（noise-matched 自适应）为对照基准，在真实噪声模型下手搓单帧小网络跑通训练反馈环，再上递归网络；NN 须同耗时预算内打赢经典线。

## 2026-08-07：AttentionLight 独立 C++ 类与 Demo

- 按 `startup.ps1` 指定 `PYTHONHOME=C:\Users\CT10266\AppData\Local\Programs\Python\Python39` 后，无界面启动 IDA 成功，返回码 `0`；全局 Python 不再参与该链路。
- 新增 `attention-light-cpp/`：无第三方依赖的 C++17 `AttentionLight` 类，输入输出为 I420，支持 ROI、流式历史状态和原地处理。
- 已实现：256-bin 统计、ROI 选择、对数 Q8 LUT、`1/32` 曲线 EMA、`77/179` 亮度预稳、7×7 三通道局部回归、16×16 黑白 tile 保护、两套 `110/160→220` 门控、Q8→Q7 亮度写回、2×2 色度补偿、启停渐变。
- 测试先后抓到两次错误预期：①Q8/Q7 尺度不能只由表值猜；②AttentionLight 不保证整帧提亮或主体/背景对比单调增加。回到最终像素函数后确认 `Yout=(Y×gainQ7)>>7`，并恢复色度标量尾段。
- 反馈环：4/4 行为测试通过；补齐 3×3/5×5 照明链后，640×360 标量 Release 约 `22.9 ms/帧`；`/MT` EXE 仅依赖 `KERNEL32.dll`。
- 诚实边界：完整可运行主链已具备，但黑白点统计辅助函数、局部中间平面精确接线和 64 帧渐变尾段仍是等效建模，尚不宣称逐像素一致。

## 2026-08-07：AttentionLight 统计、渐变和第四平面追踪补齐

- 黑白点统计已改成连续非零 run 算法：黑点取最低 run 并限幅 `0..16`；白点忽略 `1/1024` 以内稀疏高光，用 `1.5×` 间隔判定孤立高光，再按顶部 16-bin 密度最多上调 48，最终限幅 `230..255`。
- 几何均值明确排除亮度 0；ROI 有效时白点接线改为 `max(fullWhite, min(255, 2×roiGeom))`。新增孤立 240 高光 + 主体 64 的回归场景，白点稳定为 230。
- 64 帧渐变尾段改为精确基线：`Y=225Y/256`、`U=234U/256+14`、`V=234V/256+11`，再按 `position/64` 混向增强结果；色度先写，保证原地处理一致。
- 四平面类内接线确认：平面 0/1/2 是 7×7 彩色引导，平面 3 是旧目标图并原位接收细化结果；平面 3 不是第四色彩通道。
- 生产链已向上追到 `zltCEncodeConfig → zltCEncPreprocess → VPP wrapper → AttentionLight`。配置层从输入帧附加元数据接收外部图描述，只分配并转交每层 `3328` 工作区，不生成第四平面内容。Deflicker 虽使用相同格式，但调用链不相连，已排除为直接生产者。
- MSVC `/MT` Release 重建成功；7/7 行为场景全部通过。剩余边界收敛为：附加元数据由哪个相邻组件填充，以及不同向量后端的最终舍入。
