# AttentionLight 模型架构

## 1. 总体数据流

```mermaid
flowchart LR
    A["YUV420 输入帧"] --> B["格式、尺寸与工作区校验"]
    M["归一化 ROI 元数据"] --> D["ROI 选择与亮度统计"]
    B --> C["亮度预处理与历史稳定"]
    C --> E["全帧直方图"]
    D --> F["ROI 直方图与几何均值"]
    E --> G["黑点/白点/曝光尺度估计"]
    F --> G
    G --> H["1/32 时域平滑"]
    H --> I["256 项对数增益 LUT"]
    C --> J["3×3 / 5×5 局部照明平面"]
    C --> K["颜色导向通道"]
    J --> L["7×7 彩色导向滤波"]
    K --> L
    I --> N["LUT 与局部权重融合"]
    L --> N
    N --> O["16×16 块级黑/白保护"]
    O --> P["Y 增强 + U/V 补偿"]
    P --> Q["64 帧启停渐变"]
    Q --> R["YUV420 输出帧"]
```

## 2. 分层模型

### 控制层

- 模式配置与旁路；
- 64 帧启停状态机；
- ROI 有效性和场景门控；
- CPU 后端选择。

### 全局曝光层

- 256-bin 全帧直方图；
- ROI 几何均值；
- 黑点、白点、曝光尺度估计；
- 对数域 tone curve；
- Q8 增益限制 `[200,510]`。

### 局部注意力层

- 历史亮度稳定；
- 3×3 与 5×5 低频照明图；
- 7×7 三通道导向线性模型；
- 16×16 tile 黑边/白区保护；
- 两套亮度分段门控。

### 重建层

- Y 增益应用；
- 2×2 对应的 U/V 联动补偿；
- 高光抑制与定点量程转换；
- 原图/增强图渐变融合。

## 3. 每帧状态

```mermaid
stateDiagram-v2
    [*] --> Bypass
    Bypass --> RampIn: "模式由关闭变为开启"
    RampIn --> Active: "transitionPos = 64"
    Active --> RampOut: "模式由开启变为关闭"
    RampOut --> Bypass: "transitionPos = 0"
    Active --> Active: "更新 black/white/key，权重 1/32"
    RampIn --> RampIn: "逐帧混合原图与增强图"
    RampOut --> RampOut: "逐帧混合增强图与原图"
```

## 4. 可实现的净室分解

若后续在本项目中实现同类模块，建议拆成以下原创组件，避免把整个算法写成一个巨型像素循环：

```text
AttentionLightController
├── RoiExposureEstimator
│   ├── normalizeRois()
│   ├── selectLargestRois()
│   └── estimateHistogramStats()
├── LogGainCurve
│   ├── updateBlackWhiteKey(alpha = 1/32)
│   └── buildQ8Lut(min = 200, max = 510)
├── LocalIlluminationModel
│   ├── temporalPrefilter(current = 77/256)
│   ├── box3x3()
│   ├── box5x5()
│   └── colorGuided7x7(eps = 25)
├── TileProtection16x16
└── Yuv420GainReconstructor
    ├── applyLumaGain()
    ├── compensateChroma()
    └── blendTransition(length = 64)
```

第一版功能模型不必复制厂商的内存布局和调度表；只需保持公式、参数、输入输出行为和状态机一致。向量优化应作为独立后端放在行为测试通过之后。

## 5. 与神经网络“注意力”的区别

该架构没有卷积层、权重张量、推理运行时或模型文件。它的注意力来自显式规则：

```text
关注区域元数据
  → 曝光统计偏置
  → 全局 tone curve
  → 局部颜色边缘约束
  → 空间增益场
```

因此更准确的工程定义是：**ROI-aware, edge-preserving, temporally-stabilized local exposure enhancement**。

