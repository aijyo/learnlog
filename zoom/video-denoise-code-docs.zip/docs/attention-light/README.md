# AttentionLight 技术研究

本目录整理 `zltCAttentionLight` 的实现行为、算法结构、精确参数和证据边界。

- [`TECHNICAL_DETAILS.md`](TECHNICAL_DETAILS.md)：类接口、对象状态、公式和参数。
- [`ARCHITECTURE.md`](ARCHITECTURE.md)：端到端数据流与模型架构。
- [`VERIFICATION_STATUS.md`](VERIFICATION_STATUS.md)：逐项证据等级和仍需验证的语义。

研究对象：Zoom `zlt.dll` 7.1.0.41345，SHA-256
`0C3263276833EE13EEE49AC1D0953F6E5A7F8F6C8B7C7EADD093244C6B82E423`。

结论只适用于该版本。文档只记录接口事实、参数、公式和原创结构描述，不包含厂商函数体文本。

