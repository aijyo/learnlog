# DenoiseDemo — 实时视频降噪 WPF Demo

交互式 demo,用于**实测**我们在 video-denoise 里做的经典降噪算法(C# 移植,算法与 `scripts/classical_denoise.py` 一致;空域/高斯用 OpenCV 原生实现,保证与 Python 一致且够快)。

处理**亮度(Y)通道**,保留色度(Cr/Cb)后重组为彩色显示——与我们验证过的 luma 管线一致。

## 直接运行(无需装 .NET)

自包含发布版(含运行时,双击即用):

```
DenoiseDemo\publish\DenoiseDemo.exe
```

> 需要整个 `publish\` 文件夹(含 `OpenCvSharpExtern.dll` 58MB = 原生 OpenCV)。
> 或用较小的框架依赖版(本机已装 .NET 9 桌面运行时):`DenoiseDemo\bin\Release\net9.0-windows\DenoiseDemo.exe`。

## 界面与控件

- **左=NOISY(输入)** / **右=DENOISED(输出)** 并排实时对比。
- **Camera #** + **Start/Stop**:开/关摄像头(默认 0 号 = C270)。
- **Load video…**:改用视频文件跑(可选我们采集的 `samples\lowlight_exp8.mp4`,循环播放)。
- **Manual exposure (force low-light)** + 滑条(-13…-1):**强制短曝光造低光噪声**——不用关灯就能看到真实传感器噪声(和 Python `capture_webcam.py --exposure` 同理)。
- **Denoiser** 下拉(5 档):
  1. `Off` —— 看原始噪声。
  2. `Spatial (bilateral)` —— 单帧边缘保持平滑(会糊细节、无时域增益)。
  3. `Motion-adaptive recursive (uniform)` —— **主力**:静止区重时域平均、运动区退空域防拖影。
  4. `Profile: noise-matched (adaptive)` —— 阈值 ∝ 在线估计的每亮度噪声 σ(强度花在噪声多处)。
  5. `Profile: Zoom strength curve` —— 阈值 ∝ 从 Zoom `zlt.dll` 恢复的每亮度曲线(阴影加权)。
  6. `Motion-compensated (optical flow)` —— **根治运动拖影**:光流把历史帧对齐到当前再融合,运动区也能真降噪、无拖影。比其他档**更耗时**(光流),fps 会低些;合成测试 fg-PSNR 比"守卫"高 ~2.8dB。
- **Strength (σ_motion)**:运动阈值 / 均值强度,越大降得越狠(也越易拖影)。
- **α_max**:时域历史保留上限(越大 SNR 增益越大,运动区越易拖影)。
- **Debanding dither**(默认开):输出前加亚-LSB 抖动,消除平滑区(皮肤)降噪后的等高线波纹。关掉可看波纹回来。
- **Motion guard (anti-ghost)**(默认开):对运动做空间膨胀+时域冷却,抑制快速运动(晃手指)的拖影/网格伪影。关掉可对比。**候选修复,待实测确认**。
- 底部状态栏:**fps / ms每帧 / 在线估计噪声 σ**(阴影 0.2、中灰 0.5 两点)。

## 怎么测(建议流程)

1. 点 **Start**,勾 **Manual exposure**,滑到 `-8` 左右 → 画面变暗、噪声可见。
2. 切 **Off** 看噪声,再切 **Motion-adaptive**:静止时右侧明显更干净;**在镜头前挥手** → 看运动区是否拖影。
3. 把 **α_max** 拉到 0.99:静止更干净但挥手拖影更重 → 直观理解时域降噪的取舍。
4. 对比 **noise-matched** vs **Zoom strength**:本机 C270 是 shot 形噪声(高光噪声多),预期 noise-matched 略优;Zoom 阴影加权在此场景不占优(见 `notes/exp07/exp08`,它只在阴影主导噪声+感知口径下才划算)。
5. **Load video…** 选 `samples\lowlight_exp8.mp4`,在固定低光片段上重复上面对比。

## 从源码构建

```powershell
cd DenoiseDemo
dotnet build -c Release                       # -> bin\Release\net9.0-windows\DenoiseDemo.exe
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -o publish
```

- 依赖:`OpenCvSharp4` + `OpenCvSharp4.runtime.win`(NuGet,直连可还原)。
- `..\SmokeTest\`:无头回归测试(net9 控制台,跑通原生 OpenCV + DenoiseCore 全模式):`cd SmokeTest; dotnet run -c Release`。

## 说明与边界

- 仅降噪 Y 通道(色度直通);彩色链路/YUV 完整降噪是后续项。
- 降噪器为经典 DSP(与 Python 基线一致),**非神经网络**;这是 P2 手搓网络时的对照基准。
- Zoom 曲线为从二进制恢复的**距离拟合式**(事实),仅用于研究对比;详见 `zlt-re/notes/ZOOM_NOISE_PARAMS.md`。
