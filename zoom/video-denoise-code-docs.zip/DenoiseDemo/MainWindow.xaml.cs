using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using OpenCvSharp;
using Window = System.Windows.Window;
using Size = OpenCvSharp.Size;

namespace DenoiseDemo;

public partial class MainWindow : Window
{
    readonly Denoiser _den = new();
    readonly object _lk = new();
    VideoCapture? _cap;
    CancellationTokenSource? _cts;
    Task? _loop;
    bool _isFile;
    double _fps;
    volatile bool _recReq;
    VideoWriter? _rec;
    int _recLeft;
    string _recPath = "";

    public MainWindow()
    {
        InitializeComponent();
        ApplyParams();
    }

    // ---------- controls ----------
    void ApplyParams()
    {
        lock (_lk)
        {
            _den.Mode = (DenoiseMode)Math.Max(0, CmbMode?.SelectedIndex ?? 2);
            _den.SigmaMotion = SldSigma?.Value ?? 0.06;
            _den.AlphaMax = SldAlpha?.Value ?? 0.95;
            _den.DitherAmp = (ChkDither?.IsChecked ?? true) ? 1.0 : 0.0;
            bool guard = ChkGuard?.IsChecked ?? true;
            _den.MotionDilate = guard ? 8 : 0;
            _den.MotionDecay = guard ? 0.6 : 0.0;
        }
        if (LblSigma != null) LblSigma.Text = (SldSigma?.Value ?? 0.06).ToString("0.000");
        if (LblAlpha != null) LblAlpha.Text = (SldAlpha?.Value ?? 0.95).ToString("0.00");
        if (LblExp != null) LblExp.Text = ((int)(SldExp?.Value ?? -8)).ToString();
    }

    void Param_Changed(object sender, RoutedPropertyChangedEventArgs<double> e) => ApplyParams();
    void Chk_Changed(object sender, RoutedEventArgs e) => ApplyParams();

    void CmbMode_Changed(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        lock (_lk) { _den.Mode = (DenoiseMode)Math.Max(0, CmbMode.SelectedIndex); _den.Reset(); }
    }

    void Exp_Changed(object sender, RoutedEventArgs e) => ApplyExposure();
    void Exp_Changed(object sender, RoutedPropertyChangedEventArgs<double> e) => ApplyExposure();

    void ApplyExposure()
    {
        if (LblExp != null && SldExp != null) LblExp.Text = ((int)SldExp.Value).ToString();
        var cap = _cap;
        if (cap == null || _isFile) return;
        try
        {
            if (ChkExp?.IsChecked == true)
            {
                cap.Set(VideoCaptureProperties.AutoExposure, 0.25);       // manual
                cap.Set(VideoCaptureProperties.Exposure, SldExp!.Value);
            }
            else
            {
                cap.Set(VideoCaptureProperties.AutoExposure, 0.75);       // auto
            }
        }
        catch { /* not all drivers honor these */ }
    }

    // ---------- start / stop ----------
    void BtnStart_Click(object sender, RoutedEventArgs e)
    {
        if (_loop is { IsCompleted: false }) return;
        if (!int.TryParse(TxtCam.Text, out int idx)) idx = 0;
        VideoCapture cap;
        try
        {
            cap = new VideoCapture(idx, VideoCaptureAPIs.DSHOW);
            cap.Set(VideoCaptureProperties.FrameWidth, 640);
            cap.Set(VideoCaptureProperties.FrameHeight, 480);
            if (!cap.IsOpened()) { SetStatus($"Cannot open camera #{idx}"); cap.Dispose(); return; }
        }
        catch (Exception ex) { SetStatus("Camera error: " + ex.Message); return; }

        _cap = cap; _isFile = false;
        ApplyExposure();
        StartLoop(delayMs: 0);
    }

    void BtnVideo_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "Video (*.mp4;*.avi;*.mkv)|*.mp4;*.avi;*.mkv|All files|*.*" };
        if (dlg.ShowDialog() != true) return;
        StopLoop();
        var cap = new VideoCapture(dlg.FileName);
        if (!cap.IsOpened()) { SetStatus("Cannot open video: " + dlg.FileName); cap.Dispose(); return; }
        _cap = cap; _isFile = true;
        double vfps = cap.Get(VideoCaptureProperties.Fps);
        StartLoop(delayMs: vfps > 1 ? (int)(1000.0 / vfps) : 33);
    }

    void StartLoop(int delayMs)
    {
        lock (_lk) _den.Reset();
        _cts = new CancellationTokenSource();
        var tok = _cts.Token;
        BtnStart.IsEnabled = false; BtnStop.IsEnabled = true; BtnVideo.IsEnabled = false;
        _loop = Task.Run(() => CaptureLoop(tok, delayMs));
    }

    void BtnRec_Click(object sender, RoutedEventArgs e)
    {
        if (_cap == null) { SetStatus("Start the camera (or Load video) first, then Record."); return; }
        if (_recReq || _rec != null) return;
        string dir = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        _recPath = System.IO.Path.Combine(dir, $"denoise_clip_{DateTime.Now:HHmmss}.mp4");
        _recReq = true;
        BtnRec.IsEnabled = false;
        SetStatus("Recording RAW input ~6s… reproduce the artifact now.");
    }

    void BtnStop_Click(object sender, RoutedEventArgs e) => StopLoop();

    void StopLoop()
    {
        try { _cts?.Cancel(); _loop?.Wait(1000); } catch { }
        if (_rec != null) { try { _rec.Release(); _rec.Dispose(); } catch { } _rec = null; }
        _recReq = false;
        try { Dispatcher.Invoke(() => BtnRec.IsEnabled = true); } catch { }
        _cap?.Dispose(); _cap = null;
        lock (_lk) _den.Reset();
        BtnStart.IsEnabled = true; BtnStop.IsEnabled = false; BtnVideo.IsEnabled = true;
    }

    // ---------- the pipeline ----------
    void CaptureLoop(CancellationToken tok, int delayMs)
    {
        var sw = new Stopwatch();
        using var bgr = new Mat();
        while (!tok.IsCancellationRequested)
        {
            sw.Restart();
            var cap = _cap;
            if (cap == null) break;
            if (!cap.Read(bgr) || bgr.Empty())
            {
                if (_isFile) { cap.Set(VideoCaptureProperties.PosFrames, 0); continue; }  // loop file
                Thread.Sleep(5); continue;
            }

            // record RAW input frames (for offline reproduction of artifacts)
            if (_recReq && _rec == null)
            {
                _rec = new VideoWriter(_recPath, VideoWriter.FourCC('m', 'p', '4', 'v'),
                                       15, new Size(bgr.Width, bgr.Height));
                _recLeft = 90;
            }
            if (_rec != null)
            {
                _rec.Write(bgr);
                if (--_recLeft <= 0)
                {
                    _rec.Release(); _rec.Dispose(); _rec = null; _recReq = false;
                    var p = _recPath;
                    Dispatcher.BeginInvoke(() => { SetStatus($"saved raw clip -> {p}"); BtnRec.IsEnabled = true; });
                }
            }

            // denoise the LUMA channel; keep chroma; recombine for a color view
            using var ycc = new Mat();
            Cv2.CvtColor(bgr, ycc, ColorConversionCodes.BGR2YCrCb);
            Mat[] ch = Cv2.Split(ycc);
            using var yF = new Mat();
            ch[0].ConvertTo(yF, MatType.CV_32FC1, 1.0 / 255.0);

            Mat den;
            double s02, s05;
            lock (_lk)
            {
                den = _den.Process(yF);
                s02 = _den.Nlf.SigmaAt(0.2); s05 = _den.Nlf.SigmaAt(0.5);
            }

            using var y8 = new Mat();
            den.ConvertTo(y8, MatType.CV_8UC1, 255.0);
            using var merged = new Mat();
            Cv2.Merge(new[] { y8, ch[1], ch[2] }, merged);
            using var outBgr = new Mat();
            Cv2.CvtColor(merged, outBgr, ColorConversionCodes.YCrCb2BGR);

            var noisyBs = ToBitmap(bgr);
            var denBs = ToBitmap(outBgr);

            den.Dispose();
            foreach (var c in ch) c.Dispose();

            double ms = sw.Elapsed.TotalMilliseconds;
            _fps = _fps <= 0 ? 1000.0 / Math.Max(ms, 1) : 0.9 * _fps + 0.1 * (1000.0 / Math.Max(ms, 1));

            Dispatcher.BeginInvoke(() =>
            {
                ImgNoisy.Source = noisyBs;
                ImgDenoised.Source = denBs;
                SetStatus($"{_fps:0.0} fps | {ms:0.0} ms/frame | est noise σ  shadow(0.2)={s02:0.004}  mid(0.5)={s05:0.004}"
                          + (_isFile ? "  [video file]" : "  [webcam]"));
            });

            if (delayMs > 0) Thread.Sleep(delayMs);
        }
    }

    static BitmapSource ToBitmap(Mat bgr)
    {
        int w = bgr.Cols, h = bgr.Rows, stride = (int)bgr.Step();
        int len = stride * h;
        var buf = new byte[len];
        Marshal.Copy(bgr.Data, buf, 0, len);
        var bs = BitmapSource.Create(w, h, 96, 96, PixelFormats.Bgr24, null, buf, stride);
        bs.Freeze();
        return bs;
    }

    void SetStatus(string s)
    {
        if (Dispatcher.CheckAccess()) LblStatus.Text = s;
        else Dispatcher.BeginInvoke(() => LblStatus.Text = s);
    }

    protected override void OnClosed(EventArgs e) { StopLoop(); base.OnClosed(e); }
}
