using System.Windows;

namespace DenoiseDemo;

public partial class App : Application
{
}
