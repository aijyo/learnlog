using System.Collections.Generic;
using System.Linq;
using OpenCvSharp;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;

namespace DenoiseDemo;

public enum DenoiseMode
{
    Off,
    Spatial,              // edge-preserving bilateral (single frame)
    MotionUniform,        // motion-adaptive recursive, uniform threshold
    ProfileNoiseMatched,  // per-luma threshold proportional to estimated noise sigma
    ProfileZoom,          // per-luma threshold from Zoom's recovered strength curve
    MotionCompensated,    // optical-flow: align history to current frame, then blend
    ZltGuided,            // clean-room: guided filter (5x5, eps recovered) + temporal
    ZltIirRecipe,         // clean-room: recovered per-luma shadow-weighted strength + 0.648 blend
    TinyNN,               // learned: 745-param blind-noise DnCNN (ONNX, CPU) + temporal
    SmallNN,              // learned: ~5k-param blind-noise DnCNN (ONNX, CPU) + temporal
}

/// <summary>
/// Per-luma denoise-strength curve recovered from Zoom's zlt.dll (zltCIIRDenoise),
/// distilled to a fitted formula (facts): strength8(luma)=A/(luma+B)+C. Shadow-weighted.
/// NOTE (exp06/08): this is a denoise-STRENGTH curve, not a noise sigma; it only helps
/// when noise is shadow-heavy AND quality is judged perceptually.
/// </summary>
public static class ZoomNoise
{
    const double A = 117.579, B = 0.100, C = 0.217;
    public static double Strength01(double v)
    {
        if (v < 0) v = 0; else if (v > 1) v = 1;
        return (A / (v * 255.0 + B) + C) / 255.0;
    }
}

/// <summary>Online per-luma temporal-noise estimate: Var(noise) ~= Var(frame-diff)/2,
/// binned by luma, EMA-smoothed, outlier(motion)-rejected. Fits Var ~= a*luma + b.</summary>
public sealed class NlfEstimator
{
    const int NB = 16;
    readonly double[] _var = new double[NB];
    bool _init;
    float[]? _prev;
    int _w, _h;

    public double A { get; private set; } = 0.0021;
    public double B { get; private set; } = 0.0003;

    public void Reset() { _prev = null; _init = false; System.Array.Clear(_var); }

    public void Update(float[] gray, int w, int h)
    {
        if (_prev != null && _prev.Length == gray.Length)
        {
            var s2 = new double[NB];
            var cnt = new int[NB];
            for (int i = 0; i < gray.Length; i++)
            {
                float d = gray[i] - _prev[i];
                if (d < 0.15f && d > -0.15f)   // reject large diffs (motion) for a noise estimate
                {
                    int b = (int)(System.Math.Clamp(gray[i], 0f, 0.999f) * NB);
                    s2[b] += (double)d * d;
                    cnt[b]++;
                }
            }
            for (int b = 0; b < NB; b++)
                if (cnt[b] > 50)
                {
                    double v = s2[b] / cnt[b] / 2.0;         // Var(noise)=Var(d)/2
                    _var[b] = _init ? 0.9 * _var[b] + 0.1 * v : v;
                }
            _init = true;
            Fit();
        }
        _prev = (float[])gray.Clone();
        _w = w; _h = h;
    }

    void Fit()
    {
        double sx = 0, sy = 0, sxx = 0, sxy = 0; int n = 0;
        for (int b = 0; b < NB; b++)
        {
            if (_var[b] <= 0) continue;
            double x = (b + 0.5) / NB, y = _var[b];
            sx += x; sy += y; sxx += x * x; sxy += x * y; n++;
        }
        if (n >= 2)
        {
            double den = n * sxx - sx * sx;
            if (System.Math.Abs(den) > 1e-9)
            {
                A = (n * sxy - sx * sy) / den;
                B = (sy - A * sx) / n;
            }
        }
        if (B < 1e-5) B = 1e-5;
    }

    public double SigmaAt(double luma) => System.Math.Sqrt(System.Math.Max(A * luma + B, 1e-8));
}

/// <summary>Streaming recursive denoiser (grayscale/luma, values in [0,1]).
/// Mirrors scripts/classical_denoise.py: motion-adaptive temporal blend with a
/// spatial (bilateral) fallback; per-pixel motion threshold either uniform, noise-
/// matched, or from Zoom's per-luma strength curve.</summary>
public sealed class Denoiser
{
    public DenoiseMode Mode = DenoiseMode.MotionUniform;
    public double SigmaMotion = 0.06;   // uniform threshold, or mean threshold for profiles
    public double AlphaMax = 0.95;
    public double DiffBlur = 3.0;
    public double SigmaColor = 0.18;
    public double SigmaSpace = 3.0;
    /// <summary>Sub-LSB triangular dither (in 8-bit units) added to the DISPLAYED output
    /// to stop 8-bit contour banding on smooth gradients (denoising removes the sensor
    /// noise that was dithering the quantizer). 0 disables. ~1.0 is imperceptible.</summary>
    public double DitherAmp = 1.0;
    /// <summary>Anti-ghost motion guard. MotionDilate (px) spreads the motion signal from
    /// moving EDGES into the smooth INTERIOR near them (frame-diff under-detects motion in
    /// smooth moving regions -> aperture problem -> mottling); MotionDecay persists motion a
    /// few frames so a just-vacated pixel stays on the spatial estimate (clears trails).
    /// 0/0 disables.</summary>
    public int MotionDilate = 8;
    public double MotionDecay = 0.6;
    /// <summary>MCTF: occlusion/flow-reliability sigma; flow computed at FlowScale res.</summary>
    public double OccSigma = 0.06;
    public double FlowScale = 0.5;
    /// <summary>MCTF forward-backward flow consistency gate: distrust unreliable flow
    /// (low-texture regions -> garbage flow -> mis-warped history -> "water streak").
    /// Costs a 2nd optical-flow pass. FbcSigma in px.</summary>
    public bool FbCheck = true;
    public double FbcSigma = 1.0;

    public readonly NlfEstimator Nlf = new();
    Mat? _state;   // CV_32FC1
    float[]? _env; // persistent motion envelope (anti-ghost)
    Mat? _prev;    // previous input luma (8U) for optical flow
    Mat? _gx, _gy; // cached coordinate grids for remap

    // ---- learned denoiser (ONNX Runtime, CPU) ----
    InferenceSession? _nn;   // lazily created per selected model
    string? _nnName;         // which .onnx is currently loaded
    string? _nnInput;        // model's input tensor name
    bool _nnFailed;          // load failed once -> fall back to bilateral, don't retry every frame

    public void Reset()
    {
        _state?.Dispose(); _state = null; _env = null;
        _prev?.Dispose(); _prev = null;
        Nlf.Reset();
    }

    Mat Spatial(Mat x)
    {
        var o = new Mat();
        Cv2.BilateralFilter(x, o, 5, SigmaColor, SigmaSpace);
        return o;
    }

    /// <summary>Process one CV_32FC1 luma frame in [0,1]; returns a new CV_32FC1.</summary>
    public Mat Process(Mat grayF)
    {
        grayF.GetArray(out float[] cur);
        Nlf.Update(cur, grayF.Cols, grayF.Rows);   // keep a live noise estimate / readout

        if (Mode == DenoiseMode.Off) return grayF.Clone();
        if (Mode == DenoiseMode.Spatial) { var sp0 = Spatial(grayF); ApplyDither(sp0); return sp0; }
        if (Mode == DenoiseMode.MotionCompensated) return ProcessMCTF(grayF);
        if (Mode == DenoiseMode.ZltGuided) return ProcessZltGuided(grayF);
        if (Mode == DenoiseMode.ZltIirRecipe) return ProcessZltIir(grayF);
        if (Mode is DenoiseMode.TinyNN or DenoiseMode.SmallNN) return ProcessNN(grayF);

        Mat spatial = Spatial(grayF);
        if (_state == null)
        {
            _state = spatial.Clone();       // state stays un-dithered
            ApplyDither(spatial);
            return spatial;
        }

        using var diff = new Mat();
        Cv2.Absdiff(spatial, _state, diff);
        using var motion = new Mat();
        Cv2.GaussianBlur(diff, motion, new Size(0, 0), DiffBlur);
        if (MotionDilate > 0)   // spread motion from edges into smooth interiors
        {
            int k = 2 * MotionDilate + 1;
            using var kern = Cv2.GetStructuringElement(MorphShapes.Rect, new Size(k, k));
            Cv2.Dilate(motion, motion, kern);
        }

        spatial.GetArray(out float[] sp);
        _state.GetArray(out float[] st);
        motion.GetArray(out float[] mo);
        if (MotionDecay > 0)    // persist motion a few frames (clears trails)
        {
            if (_env == null || _env.Length != mo.Length) _env = (float[])mo.Clone();
            else for (int i = 0; i < mo.Length; i++) _env[i] = System.Math.Max(mo[i], (float)(_env[i] * MotionDecay));
            mo = _env;
        }

        bool prof = Mode is DenoiseMode.ProfileNoiseMatched or DenoiseMode.ProfileZoom;
        float[]? profArr = null;
        double meanProf = 1.0;
        if (prof)
        {
            profArr = new float[sp.Length];
            double s = 0;
            for (int i = 0; i < sp.Length; i++)
            {
                double v = Mode == DenoiseMode.ProfileZoom
                    ? ZoomNoise.Strength01(st[i])
                    : Nlf.SigmaAt(st[i]);
                profArr[i] = (float)v; s += v;
            }
            meanProf = s / sp.Length + 1e-8;
        }

        var outp = new float[sp.Length];
        for (int i = 0; i < sp.Length; i++)
        {
            double sigma = prof ? SigmaMotion * profArr![i] / meanProf : SigmaMotion;
            if (sigma < 1e-4) sigma = 1e-4;
            double a = AlphaMax * System.Math.Exp(-(mo[i] * (double)mo[i]) / (2.0 * sigma * sigma));
            outp[i] = (float)(a * st[i] + (1.0 - a) * sp[i]);
        }

        var res = new Mat(grayF.Rows, grayF.Cols, MatType.CV_32FC1);
        res.SetArray(outp);
        _state.Dispose(); _state = res.Clone();   // recursive state must stay un-dithered
        spatial.Dispose();
        ApplyDither(res);                          // dither only the displayed copy
        return res;
    }

    /// <summary>Add triangular-PDF dither of +-DitherAmp LSB in place (debanding).</summary>
    void ApplyDither(Mat f32)
    {
        if (DitherAmp <= 0) return;
        f32.GetArray(out float[] a);
        double amp = DitherAmp / 255.0;
        var r = System.Random.Shared;
        for (int i = 0; i < a.Length; i++)
        {
            double t = (r.NextDouble() - r.NextDouble()) * amp;   // triangular PDF, +-amp
            a[i] = (float)(a[i] + t);
        }
        f32.SetArray(a);
    }

    void EnsureGrid(Size sz)
    {
        if (_gx != null && _gx.Width == sz.Width && _gx.Height == sz.Height) return;
        _gx?.Dispose(); _gy?.Dispose();
        var gx = new float[sz.Width * sz.Height];
        var gy = new float[sz.Width * sz.Height];
        int k = 0;
        for (int y = 0; y < sz.Height; y++)
            for (int x = 0; x < sz.Width; x++) { gx[k] = x; gy[k] = y; k++; }
        _gx = new Mat(sz.Height, sz.Width, MatType.CV_32FC1); _gx.SetArray(gx);
        _gy = new Mat(sz.Height, sz.Width, MatType.CV_32FC1); _gy.SetArray(gy);
    }

    /// <summary>Optical-flow motion-compensated temporal filter (see MotionCompensatedDenoiser
    /// in classical_denoise.py). Aligns the denoised history to the current frame via
    /// Farneback flow, then blends where the aligned history is reliable.</summary>
    Mat ProcessMCTF(Mat grayF)
    {
        Mat spatial = Spatial(grayF);
        var cur8 = new Mat();
        grayF.ConvertTo(cur8, MatType.CV_8UC1, 255.0);
        if (_state == null || _prev == null)
        {
            _state = spatial.Clone();
            _prev?.Dispose(); _prev = cur8;
            ApplyDither(spatial);
            return spatial;
        }

        using Mat flow = ComputeFlow(cur8, _prev, grayF.Size());   // current -> previous
        EnsureGrid(grayF.Size());
        Mat[] fxy = Cv2.Split(flow);         // fxy[0]=dx, fxy[1]=dy
        using var mapx = new Mat(); Cv2.Add(fxy[0], _gx!, mapx);
        using var mapy = new Mat(); Cv2.Add(fxy[1], _gy!, mapy);
        using var aligned = new Mat();
        Cv2.Remap(_state, aligned, mapx, mapy, InterpolationFlags.Linear, BorderTypes.Reflect);
        using var resid = new Mat();
        Cv2.Absdiff(spatial, aligned, resid);
        Cv2.GaussianBlur(resid, resid, new Size(0, 0), 1.5);

        // forward-backward consistency gate: distrust flow whose round trip fails
        float[]? conf = null;
        if (FbCheck)
        {
            using Mat flowB = ComputeFlow(_prev, cur8, grayF.Size());   // previous -> current
            using var fbw = new Mat();
            Cv2.Remap(flowB, fbw, mapx, mapy, InterpolationFlags.Linear, BorderTypes.Reflect);
            Mat[] fw = Cv2.Split(flow);
            Mat[] bw = Cv2.Split(fbw);
            fw[0].GetArray(out float[] fx); fw[1].GetArray(out float[] fy);
            bw[0].GetArray(out float[] bx); bw[1].GetArray(out float[] by);
            conf = new float[fx.Length];
            double cden = 2.0 * FbcSigma * FbcSigma;
            for (int i = 0; i < fx.Length; i++)
            {
                double ex = fx[i] + bx[i], ey = fy[i] + by[i];
                conf[i] = (float)System.Math.Exp(-(ex * ex + ey * ey) / cden);
            }
            foreach (var m in fw) m.Dispose();
            foreach (var m in bw) m.Dispose();
        }

        spatial.GetArray(out float[] sp);
        aligned.GetArray(out float[] al);
        resid.GetArray(out float[] rs);
        double denom = 2.0 * OccSigma * OccSigma;
        var outp = new float[sp.Length];
        for (int i = 0; i < sp.Length; i++)
        {
            double a = AlphaMax * System.Math.Exp(-(rs[i] * (double)rs[i]) / denom);
            if (conf != null) a *= conf[i];
            outp[i] = (float)(a * al[i] + (1.0 - a) * sp[i]);
        }
        var res = new Mat(grayF.Rows, grayF.Cols, MatType.CV_32FC1);
        res.SetArray(outp);

        _state.Dispose(); _state = res.Clone();
        _prev.Dispose(); _prev = cur8;
        foreach (var m in fxy) m.Dispose();
        spatial.Dispose();
        ApplyDither(res);
        return res;
    }

    /// <summary>Farneback optical flow a8 -> b8, computed at FlowScale and upscaled.</summary>
    Mat ComputeFlow(Mat a8, Mat b8, Size full)
    {
        double s = FlowScale <= 0 ? 1.0 : FlowScale;
        if (s == 1.0)
        {
            var f = new Mat();
            Cv2.CalcOpticalFlowFarneback(a8, b8, f, 0.5, 3, 15, 3, 5, 1.2, OpticalFlowFlags.None);
            return f;
        }
        using var asz = new Mat(); using var bsz = new Mat();
        Cv2.Resize(a8, asz, new Size(), s, s);
        Cv2.Resize(b8, bsz, new Size(), s, s);
        using var fs = new Mat();
        Cv2.CalcOpticalFlowFarneback(asz, bsz, fs, 0.5, 3, 15, 3, 5, 1.2, OpticalFlowFlags.None);
        using var fup = new Mat();
        Cv2.Resize(fs, fup, full);
        return fup * (1.0 / s);   // upscale vectors too
    }

    // ---- clean-room reconstructions of zlt.dll pixel denoisers (zlt-re notes) ----
    static Mat Box(Mat m, int r)
    {
        var o = new Mat();
        Cv2.BoxFilter(m, o, MatType.CV_32F, new Size(2 * r + 1, 2 * r + 1), borderType: BorderTypes.Reflect);
        return o;
    }

    /// <summary>Guided filter (He 2010), self-guided grayscale; recovered params
    /// radius=2 (5x5), eps=25/255^2 (from zltCGuidedFilter kernel sub_180295F00).</summary>
    static Mat GuidedFilter(Mat x, int r, float eps)
    {
        using Mat mI = Box(x, r);
        using var xx = new Mat(); Cv2.Multiply(x, x, xx);
        using Mat mII = Box(xx, r);
        x.GetArray(out float[] X); mI.GetArray(out float[] MI); mII.GetArray(out float[] MII);
        var A = new float[X.Length]; var B = new float[X.Length];
        for (int i = 0; i < X.Length; i++)
        {
            double v = MII[i] - (double)MI[i] * MI[i];
            double a = v / (v + eps);
            A[i] = (float)a; B[i] = (float)(MI[i] - a * MI[i]);
        }
        using var aM = new Mat(x.Rows, x.Cols, MatType.CV_32FC1); aM.SetArray(A);
        using var bM = new Mat(x.Rows, x.Cols, MatType.CV_32FC1); bM.SetArray(B);
        using Mat mA = Box(aM, r); using Mat mB = Box(bM, r);
        mA.GetArray(out float[] MA); mB.GetArray(out float[] MB);
        var O = new float[X.Length];
        for (int i = 0; i < X.Length; i++) O[i] = MA[i] * X[i] + MB[i];
        var res = new Mat(x.Rows, x.Cols, MatType.CV_32FC1); res.SetArray(O);
        return res;
    }

    Mat BlendTemporal(Mat grayF, Mat spatial, System.Func<double, double, double> alphaOf)
    {
        if (_state == null) { _state = spatial.Clone(); ApplyDither(spatial); return spatial; }
        using var diff = new Mat(); Cv2.Absdiff(spatial, _state, diff);
        using var motion = new Mat(); Cv2.GaussianBlur(diff, motion, new Size(0, 0), DiffBlur);
        if (MotionDilate > 0)   // anti-ghost guard (same as the main path) — spread motion into smooth interiors
        {
            int k = 2 * MotionDilate + 1;
            using var kern = Cv2.GetStructuringElement(MorphShapes.Rect, new Size(k, k));
            Cv2.Dilate(motion, motion, kern);
        }
        spatial.GetArray(out float[] sp); _state.GetArray(out float[] st); motion.GetArray(out float[] mo);
        if (MotionDecay > 0)    // temporal cooldown: persist motion a few frames (clears trails)
        {
            if (_env == null || _env.Length != mo.Length) _env = (float[])mo.Clone();
            else for (int i = 0; i < mo.Length; i++) _env[i] = System.Math.Max(mo[i], (float)(_env[i] * MotionDecay));
            mo = _env;
        }
        var outp = new float[sp.Length];
        for (int i = 0; i < sp.Length; i++)
        {
            double a = alphaOf(mo[i], st[i]);
            outp[i] = (float)(a * st[i] + (1.0 - a) * sp[i]);
        }
        var res = new Mat(grayF.Rows, grayF.Cols, MatType.CV_32FC1); res.SetArray(outp);
        _state.Dispose(); _state = res.Clone(); spatial.Dispose();
        ApplyDither(res); return res;
    }

    Mat ProcessZltGuided(Mat grayF)
    {
        // 1) guided-filter smooth (recovered 5x5, eps~0.02^2)
        using Mat smoothed = GuidedFilter(grayF, 2, 25f / (255f * 255f));
        // 2) STEERING (level-map analog): detail measured on the DENOISED estimate (so
        //    noise doesn't count as detail); flat/noisy regions -> use smoothed, detailed
        //    regions (skin texture, edges) -> keep original. Avoids uniform "beauty" smooth.
        using var gx = new Mat(); Cv2.Sobel(smoothed, gx, MatType.CV_32F, 1, 0, 3);
        using var gy = new Mat(); Cv2.Sobel(smoothed, gy, MatType.CV_32F, 0, 1, 3);
        using var detail = new Mat(); Cv2.Magnitude(gx, gy, detail);
        Cv2.GaussianBlur(detail, detail, new Size(0, 0), 2.0);       // region-level
        grayF.GetArray(out float[] X); smoothed.GetArray(out float[] S); detail.GetArray(out float[] D);
        const double tau = 0.03, tden = 2.0 * tau * tau;             // detail threshold (~noise level)
        var steered = new float[X.Length];
        for (int i = 0; i < X.Length; i++)
        {
            double w = System.Math.Exp(-(D[i] * (double)D[i]) / tden); // 1 in flats, ->0 on detail
            steered[i] = (float)(w * S[i] + (1.0 - w) * X[i]);
        }
        var stMat = new Mat(grayF.Rows, grayF.Cols, MatType.CV_32FC1); stMat.SetArray(steered);
        // 3) temporal stabilization (motion-adaptive)
        const double amax = 0.9, sm = 0.05, den = 2.0 * sm * sm;
        return BlendTemporal(grayF, stMat, (m, s) => amax * System.Math.Exp(-(m * m) / den));
    }

    Mat ProcessZltIir(Mat grayF)
    {
        Mat spatial = Spatial(grayF);
        const double amax = 166.0 / 256.0, k = 3.0;   // recovered 0.648 temporal blend
        return BlendTemporal(grayF, spatial, (m, s) =>
        {
            double v8 = System.Math.Clamp(s * 255.0, 0, 255);
            double S = 117.579 / (v8 + 0.1) + 0.217;  // recovered per-luma strength (shadow-weighted)
            double sig = System.Math.Max(k * S / 255.0, 1e-4);
            return amax * System.Math.Exp(-(m * m) / (2.0 * sig * sig));
        });
    }

    // ---- learned denoiser: blind-noise DnCNN via ONNX Runtime (CPU) ----
    static string ModelPath(string file) =>
        System.IO.Path.Combine(System.AppContext.BaseDirectory, "models", file);

    void EnsureNn(string file)
    {
        if (_nn != null && _nnName == file) return;
        _nn?.Dispose(); _nn = null; _nnName = null; _nnInput = null;
        var so = new SessionOptions { IntraOpNumThreads = System.Environment.ProcessorCount };
        _nn = new InferenceSession(ModelPath(file), so);
        _nnInput = _nn.InputMetadata.Keys.First();
        _nnName = file;
    }

    /// <summary>Run the learned DnCNN (residual, output = denoised luma) on the whole frame,
    /// then stabilize temporally with the same motion-adaptive guard as the classical modes.
    /// If the model can't be loaded, fall back to bilateral so the demo still runs.</summary>
    Mat ProcessNN(Mat grayF)
    {
        string file = Mode == DenoiseMode.SmallNN ? "dncnn_small_blind.onnx" : "dncnn_tiny_blind.onnx";
        if (_nnFailed) return BlendTemporal(grayF, Spatial(grayF),
                                            (m, s) => 0.9 * System.Math.Exp(-(m * m) / (2.0 * 0.05 * 0.05)));
        try { EnsureNn(file); }
        catch { _nnFailed = true; return ProcessNN(grayF); }

        int h = grayF.Rows, w = grayF.Cols;
        grayF.GetArray(out float[] x);                 // row-major = NCHW for N=C=1
        var input = new DenseTensor<float>(x, new[] { 1, 1, h, w });
        var feed = new List<NamedOnnxValue> { NamedOnnxValue.CreateFromTensor(_nnInput!, input) };
        float[] y;
        using (var results = _nn!.Run(feed))
            y = results.First().AsEnumerable<float>().ToArray();
        for (int i = 0; i < y.Length; i++)             // model can push slightly out of range
        {
            if (y[i] < 0f) y[i] = 0f; else if (y[i] > 1f) y[i] = 1f;
        }
        var nnMat = new Mat(h, w, MatType.CV_32FC1);
        nnMat.SetArray(y);
        // temporal stabilization (learned net is single-frame -> would flicker on video)
        const double amax = 0.9, sm = 0.05, den = 2.0 * sm * sm;
        return BlendTemporal(grayF, nnMat, (m, s) => amax * System.Math.Exp(-(m * m) / den));
    }
}
