"""Approach B (observe-only): live-hook zltCIIRDenoise in a running Zoom to answer
(1) what the a2/a3/a4 planes really contain, and (2) who calls it / consumes output.

Frida Interceptor, READ-ONLY: dumps plane stats+head (in & out), the two this-fields,
and a backtrace (caller offsets in zlt.dll, cross-ref to model/map.json). Captures a
few calls then detaches. Does not modify Zoom's behavior or upload anything.

    python scripts/zlt_frida_hook.py            # auto-find the Zoom PID hosting zlt.dll
"""
from __future__ import annotations
import sys, time, frida

RVA = 0x2A6DF0
N_CAP = 4

JS = r"""
const base = Process.getModuleByName('zlt.dll').base;
const target = base.add(0x2A6DF0);
let count = 0;
const MAX = %d;

function stats(p, n) {
  try {
    const b = new Uint8Array(p.readByteArray(n));
    let mn = 255, mx = 0, s = 0;
    for (let i = 0; i < n; i++) { const v = b[i]; if (v < mn) mn = v; if (v > mx) mx = v; s += v; }
    return { min: mn, max: mx, mean: +(s / n).toFixed(1), head: Array.from(b.slice(0, 24)) };
  } catch (e) { return { err: '' + e }; }
}

Interceptor.attach(target, {
  onEnter(args) {
    if (count >= MAX) return;
    this.a3 = args[2]; this.a4 = args[3];
    let hist = '?', flag = '?';
    try { hist = args[0].add(352).readU64().toString(); flag = args[0].add(2064).readU32(); } catch (e) {}
    let bt = [];
    try {
      bt = Thread.backtrace(this.context, Backtracer.ACCURATE).slice(0, 6).map(a => {
        const m = Process.findModuleByAddress(a);
        return m ? m.name + '+0x' + a.sub(m.base).toString(16) : a.toString();
      });
    } catch (e) {}
    send({ tag: 'enter', n: count, a5: args[4].toInt32(), a6: args[5].toInt32(),
           hist: hist, flag: flag,
           a2: stats(args[1], 256), a3: stats(args[2], 256), a4: stats(args[3], 256), bt: bt });
  },
  onLeave(ret) {
    if (count >= MAX) return;
    send({ tag: 'leave', n: count, a3_out: stats(this.a3, 256), a4_out: stats(this.a4, 256) });
    count++;
    if (count >= MAX) send({ tag: 'done' });
  }
});
send({ tag: 'ready', base: base.toString() });
""" % N_CAP


def find_pid():
    for p in frida.enumerate_processes():
        if p.name.lower().startswith("zoom"):
            try:
                sess = frida.attach(p.pid)
                mods = [m.name.lower() for m in sess.enumerate_modules()]
                sess.detach()
                if "zlt.dll" in mods:
                    return p.pid
            except Exception:
                pass
    return None


def main():
    pid = int(sys.argv[1]) if len(sys.argv) > 1 else find_pid()
    if not pid:
        raise SystemExit("no Zoom process with zlt.dll found (is the meeting running with camera on?)")
    print(f"attaching to PID {pid} (observe-only)...")
    session = frida.attach(pid)
    done = {"v": False}

    def on_message(msg, data):
        if msg["type"] != "send":
            print("  [script error]", msg); return
        p = msg["payload"]
        t = p.get("tag")
        if t == "ready":
            print(f"  hooked zlt.dll @ {p['base']} + 0x{RVA:X}")
        elif t == "enter":
            print(f"\n--- call #{p['n']}  levels a5={p['a5']} a6={p['a6']}  histDepth={p['hist']} flag={p['flag']}")
            for k in ("a2", "a3", "a4"):
                s = p[k]
                print(f"    {k} (in) : min={s.get('min')} max={s.get('max')} mean={s.get('mean')} head={s.get('head')}")
            print(f"    caller backtrace: {p['bt']}")
        elif t == "leave":
            print(f"    a3 (out): min={p['a3_out'].get('min')} max={p['a3_out'].get('max')} mean={p['a3_out'].get('mean')} head={p['a3_out'].get('head')}")
            print(f"    a4 (out): min={p['a4_out'].get('min')} max={p['a4_out'].get('max')} mean={p['a4_out'].get('mean')} head={p['a4_out'].get('head')}")
        elif t == "done":
            done["v"] = True

    script = session.create_script(JS)
    script.on("message", on_message)
    script.load()
    t0 = time.time()
    while not done["v"] and time.time() - t0 < 20:
        time.sleep(0.2)
    session.detach()
    print("\ndetached." + ("" if done["v"] else "  (timeout — kernel may not have been called; is the camera on / denoise active?)"))


if __name__ == "__main__":
    main()
