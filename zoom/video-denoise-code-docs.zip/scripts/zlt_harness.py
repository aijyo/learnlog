"""Dynamic verification (Approach A): call zlt.dll's zltCIIRDenoise kernel directly
and compare its real output, value-by-value, to our recovered formula.

The kernel sub_1802A6DF0 (RVA 0x2A6DF0) allocates nothing: it reads caller-provided
planes a2(activity)/a3(value V, also output)/a4(history), the global LUT, and two
`this` fields (+352 history-depth, +2064 flag). So we LoadLibrary the DLL, hand it
three 9x16 planes + a minimal this-stub, call it, and read the output plane back.
Then we compute the SAME output with our recovered formula and diff.

Isolated harness: if the call crashes (bad args), only this process dies. It does not
modify Zoom, touch the network, or persist anything.

    python scripts/zlt_harness.py <path-to-zlt.dll>
"""
from __future__ import annotations
import os, sys, ctypes
import numpy as np

RVA = 0x2A6DF0
H, W = 9, 16
LUT = np.load(os.path.join(os.path.dirname(__file__), "zlt_lut.npy")).astype(np.float32)


def call_kernel(dll_path, V, ACT, PREV, a5, a6, hist_depth, flag):
    dll = ctypes.WinDLL(dll_path)
    base = dll._handle
    proto = ctypes.CFUNCTYPE(ctypes.c_int64, ctypes.c_void_p, ctypes.c_void_p,
                             ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int)
    fn = proto(base + RVA)

    this_buf = (ctypes.c_ubyte * 4096)()
    ctypes.c_uint64.from_buffer(this_buf, 352).value = hist_depth
    ctypes.c_uint32.from_buffer(this_buf, 2064).value = flag

    a3 = (ctypes.c_ubyte * (H * W)).from_buffer_copy(V.astype(np.uint8).tobytes())   # value/out
    a2 = (ctypes.c_ubyte * (H * W)).from_buffer_copy(ACT.astype(np.uint8).tobytes()) # activity
    a4 = (ctypes.c_ubyte * (H * W)).from_buffer_copy(PREV.astype(np.uint8).tobytes())# history

    fn(ctypes.cast(this_buf, ctypes.c_void_p), ctypes.cast(a2, ctypes.c_void_p),
       ctypes.cast(a3, ctypes.c_void_p), ctypes.cast(a4, ctypes.c_void_p), a5, a6)
    out = np.frombuffer(bytes(a3), np.uint8).reshape(H, W).astype(np.int32)
    return out


def recovered_formula(V, ACT, PREV, a5, a6, hist_depth, flag):
    """Our recovered per-pixel math, in float32 with the kernel's int truncation."""
    f = np.float32
    v10 = f(1.0) if a5 < 18 else (f(0.06 * a5 - 0.08) if a5 <= 28 else f(1.6))
    v12 = f(0.9) if a6 < 25 else (f(0.0018181823 * a6 + 0.85454541) if a6 <= 80 else f(1.0))
    v14 = f(3.4000001) if flag else f(2.4000001)
    v13 = f(2.0) * v10
    v18 = v14 * v10
    v19 = (v18 - v13) / f(96.0)
    v20 = v13 - f(32.0) * v19
    v16 = 166 if hist_depth > 2 else 0
    v17 = 256 - v16

    rows = np.arange(H, dtype=np.float32)[:, None]
    cols = np.arange(W, dtype=np.float32)[None, :]
    dist = np.abs(cols - f(7.5)) + np.abs(rows - f(4.0))
    A = np.minimum((f(1.0) + dist * f(0.013043479)) * ACT.astype(f), f(200.0))
    base = LUT[np.clip(V, 0, 255).astype(np.intp)]

    strv = np.where(A < 32.0, f(2.0) * v10,
                    np.where(A <= 128.0, A * v19 + v20, v18)).astype(f)
    v30_b = ((f(127.0) - V.astype(f)) * f(0.0078740157)) * (base - strv) + strv
    v30_d = np.minimum(f(6.0290999) - (A - f(204.0)) * f(0.000099999997) * (A - f(204.0)), base)
    v30 = np.where(V > 82, v30_b, v30_d).astype(f)

    ratio = (A / (v30 * v12)).astype(np.int32)          # kernel truncates to int
    v32 = np.maximum(ratio, 5)
    out = (v16 * PREV.astype(np.int32) + v17 * v32) >> 8  # integer, arithmetic shift
    return out.astype(np.int32)


def main():
    dll = sys.argv[1] if len(sys.argv) > 1 else \
        r"D:\code\work\research\video-denoise\zlt-re\out\zlt.dll"
    if not os.path.exists(dll):
        raise SystemExit(f"dll not found: {dll}")

    rng = np.random.default_rng(0)
    # test planes exercising both luma branches (V<=82 / >82) and activity ranges
    V = np.clip(np.arange(H)[:, None] * 22 + np.arange(W)[None, :] * 2 + 10, 0, 255).astype(np.int32)
    ACT = np.clip(np.arange(W)[None, :] * 13 + np.arange(H)[:, None] * 3, 0, 200).astype(np.int32)
    ACT = np.broadcast_to(ACT, (H, W)).copy()
    PREV = np.clip(10 + np.arange(W)[None, :] * 6, 0, 255).astype(np.int32)
    PREV = np.broadcast_to(PREV, (H, W)).copy()

    print(f"dll: {dll}")
    for (a5, a6, hd, flag, label) in [(24, 50, 3, 0, "temporal ON (hd=3)"),
                                      (24, 50, 1, 0, "temporal OFF (hd=1)"),
                                      (30, 90, 5, 1, "hi levels + flag=1")]:
        real = call_kernel(dll, V, ACT, PREV, a5, a6, hd, flag)
        mine = recovered_formula(V, ACT, PREV, a5, a6, hd, flag)
        d = np.abs(real - mine)
        exact = int((d == 0).sum())
        print(f"\n[{label}] a5={a5} a6={a6}")
        print(f"  real   [row0]: {real[0].tolist()}")
        print(f"  recov  [row0]: {mine[0].tolist()}")
        print(f"  match: {exact}/{H*W} exact  max|diff|={int(d.max())}  mean|diff|={d.mean():.3f}")
        print(f"  VERDICT: {'BYTE-EXACT ✓' if d.max()==0 else ('near-exact (<=1, float/int rounding)' if d.max()<=1 else 'MISMATCH — recovered formula differs')}")


if __name__ == "__main__":
    main()
