"""Clean-room reconstruction of Zoom zlt.dll's zltCIIRDenoise recipe (ns_vpp).

Reverse-engineered from zlt.dll (IDA): kernel sub_1802A6DF0 + const LUT
qword_1805057D0 + driver sub_1802A52F0. This is ORIGINAL code implementing the
*recovered algorithm* + *recovered factual constants* (curve fit, thresholds,
blend weights, piecewise ramps). It is NOT a transcription of the decompiled code.

Two layers, honestly separated:

  (A) FAITHFUL — `detail_level()` reimplements the kernel's recovered per-pixel math
      exactly (the dark/bright branch at luma 82, the per-luma strength curve, the
      activity normalization, the 166/256 temporal IIR). Facts, verifiable against
      the decompiled formulas.

  (B) INTERPRETED — `ZltVppDenoiser` wires that recipe into a working luma DENOISER
      (per-pixel strength -> motion threshold, 166/256 -> temporal-blend cap, motion
      gating). The exact buffer semantics of the original (whether the kernel emits
      denoised pixels or a strength MAP that steers a separate smoother / adaptive
      quant) are the STATIC-RE FLOOR — not determinable without dynamic capture — so
      this wrapper is our interpretation, marked as such.

Recovered constants (facts): per-luma strength = EXACT 256-value LUT (zlt_lut.npy,
shadow-weighted, hard-0 for V>=127; a fit was replaced with the exact table);
luma split 82; temporal blend 166/256=0.648 (history-depth>2 else 0); activity cap
200; min level 5; 1/127 interp; dark parabola 6.029-1e-4*(A-204)^2; block-center
weight 0.013043478*(|row-4|+|col-7.5|); spatial level a5 ramp <18->1.0 /18-28->
0.06a5-0.08 />28->1.6; temporal level a6 ramp <25->0.9 /25-80->0.001818a6+0.8545
/>80->1.0. See zlt-re/notes/DENOISE_ALGORITHMS.md & ZOOM_NOISE_PARAMS.md.
"""
from __future__ import annotations
import os
import numpy as np
import cv2

# EXACT recovered LUT (qword_1805057D0): 256 floats, index = luma 0..255. This is
# factual calibration data recovered from zlt.dll (.rdata const). NOTE the real table
# is hard-ZERO for V>=127 (a fit misses this); use the exact values.
_A, _B, _C = 117.579, 0.100, 0.217          # fallback fit only (if the data file is missing)
_LUT_PATH = os.path.join(os.path.dirname(__file__), "zlt_lut.npy")
_LUT = np.load(_LUT_PATH).astype(np.float32) if os.path.exists(_LUT_PATH) else None


def luma_strength8(v8: np.ndarray) -> np.ndarray:
    """Recovered per-luma strength S(V), V in [0,255] — EXACT LUT (fit fallback)."""
    v8 = np.asarray(v8, np.float32)
    if _LUT is not None:
        idx = np.clip(np.rint(v8), 0, 255).astype(np.intp)
        return _LUT[idx]
    return _A / (v8 + _B) + _C


def level_ramps(a5: float, a6: float, hi_flag: bool = False):
    """Recovered piecewise-linear level ramps -> (v10 spatial, v12 temporal, v18, v19, v20)."""
    if a5 < 18:      v10 = 1.0
    elif a5 <= 28:   v10 = 0.06 * a5 - 0.08
    else:            v10 = 1.6
    if a6 < 25:      v12 = 0.9
    elif a6 <= 80:   v12 = 0.0018181823 * a6 + 0.85454541
    else:            v12 = 1.0
    v14 = 3.4 if hi_flag else 2.4
    v13 = 2.0 * v10
    v18 = v14 * v10
    v19 = (v18 - v13) / 96.0
    v20 = v13 - 32.0 * v19
    return float(v10), float(v12), float(v18), float(v19), float(v20)


def _block_center_weight(h: int, w: int) -> np.ndarray:
    """Recovered per-pixel weight 0.013043478*(|row-4|+|col-7.5|) tiled over 9x16 blocks."""
    ry = np.abs((np.arange(h) % 9) - 4.0)
    cx = np.abs((np.arange(w) % 16) - 7.5)
    return 0.013043478 * (ry[:, None] + cx[None, :]).astype(np.float32)


def detail_level(v8: np.ndarray, activity: np.ndarray, a5: float, a6: float,
                 prev_level: np.ndarray | None, hist_depth: int) -> np.ndarray:
    """(A) FAITHFUL reimpl of the kernel's per-pixel level computation (vectorized).

    v8       : current value plane, 0..255
    activity : local activity (neighbor magnitude) before cap
    returns  : the temporally-blended per-pixel level map n' (float)."""
    v10, v12, v18, v19, v20 = level_ramps(a5, a6)
    base = luma_strength8(v8)
    h, w = v8.shape
    bpw = _block_center_weight(h, w)
    A = np.minimum((1.0 + bpw) * activity, 200.0)

    # bright branch (V>82): strength interpolated between base and activity-derived str
    strv = np.where(A < 32.0, 2.0 * v10,
                    np.where(A <= 128.0, A * v19 + v20, v18))
    v30_bright = ((127.0 - v8) * (1.0 / 127.0)) * (base - strv) + strv
    # dark branch (V<=82): quadratic in activity, clamped by base
    v30_dark = np.minimum(6.0290999 - 1e-4 * (A - 204.0) ** 2, base)
    v30 = np.where(v8 > 82.0, v30_bright, v30_dark)

    n = np.maximum(A / (v30 * v12), 5.0)
    w_blend = 166.0 if hist_depth > 2 else 0.0
    if prev_level is None or w_blend == 0.0:
        return n
    return (w_blend * prev_level + (256.0 - w_blend) * n) * (1.0 / 256.0)


class ZltVppDenoiser:
    """(B) INTERPRETED denoise module built from the recovered recipe.

    Uses the recovered per-luma strength (v30, dark/bright branch) as the per-pixel
    motion/noise threshold and 166/256 as the temporal-blend cap, motion-gated, over
    an edge-preserving spatial estimate. Streaming (one frame in/out), grayscale [0,1].
    """

    def __init__(self, a5: float = 24.0, a6: float = 50.0,
                 spatial_sigma_color: float = 0.18, spatial_sigma_space: float = 3.0,
                 diff_blur: float = 3.0, k_thresh: float = 3.0):
        self.a5, self.a6 = float(a5), float(a6)
        self.scc, self.scs = float(spatial_sigma_color), float(spatial_sigma_space)
        self.diff_blur = float(diff_blur)
        self.k_thresh = float(k_thresh)
        self.state: np.ndarray | None = None
        self.hist_depth = 0

    def reset(self):
        self.state = None
        self.hist_depth = 0

    def process(self, frame: np.ndarray) -> np.ndarray:
        x = frame.astype(np.float32)
        if x.ndim != 2:
            x = x.mean(axis=2)
        spatial = cv2.bilateralFilter(x, 5, self.scc, self.scs)
        v8 = np.clip(spatial, 0, 1) * 255.0

        # recovered per-luma strength v30 (needs an activity map): local gradient magnitude
        gx = cv2.Sobel(spatial, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(spatial, cv2.CV_32F, 0, 1, ksize=3)
        activity = (np.abs(gx) + np.abs(gy)) * 255.0
        v10, v12, v18, v19, v20 = level_ramps(self.a5, self.a6)
        base = luma_strength8(v8)
        A = np.minimum(activity, 200.0)
        strv = np.where(A < 32.0, 2.0 * v10, np.where(A <= 128.0, A * v19 + v20, v18))
        v30 = np.where(v8 > 82.0,
                       ((127.0 - v8) / 127.0) * (base - strv) + strv,
                       np.minimum(6.0290999 - 1e-4 * (A - 204.0) ** 2, base))
        v30 = np.maximum(v30, 0.1)

        if self.state is None:
            self.state = spatial.copy()
            self.hist_depth = 1
            return spatial.copy()

        # per-pixel motion threshold from recovered strength (shadow-weighted, in [0,1] units)
        sigma = self.k_thresh * (v30 / 255.0)
        motion = cv2.GaussianBlur(np.abs(spatial - self.state), (0, 0), self.diff_blur)
        alpha_cap = 166.0 / 256.0                     # recovered temporal blend
        alpha = alpha_cap * np.exp(-(motion ** 2) / (2.0 * np.maximum(sigma, 1e-4) ** 2))
        out = alpha * self.state + (1.0 - alpha) * spatial
        self.state = out
        self.hist_depth += 1
        return out.copy()
