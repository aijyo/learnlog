"""Clean-room pixel denoisers from Zoom zlt.dll's ns_vpp denoise family.

Static RE (zlt-re/notes/DENOISE_ALGORITHMS.md, kernels_decomp.json) identified the
pixel-smoothing classes and their algorithms. The actual kernels are hand-SIMD worker
routines (byte-exact reconstruction = static-RE floor), but the ALGORITHMS + recovered
parameters are enough to clean-room the standard versions. This module implements the
central one — the GUIDED FILTER (the algorithm zltCGuidedFilter uses; He et al. 2010),
an edge-preserving O(N) denoiser — as ORIGINAL code (standard reference method, not a
transcription of Zoom's SIMD kernel).

Family (identified; see the notes for evidence):
  zltCRecursiveBF   -> recursive bilateral (Yang 2012)      [range-curve + 0.79 temporal EMA, sigma 3.5]
  zltCGuidedFilter  -> guided filter (He 2010)              [box-filter based]      <- implemented here
  zltCTemporalDenoise -> Haar transform-domain temporal     [Haar coeffs 0.3535/0.7071]
  zltCDenoise/ASM   -> spatial edge-preserving (SIMD)        [tiled + WPP worker]
  zltCGeneralFilter -> general convolution

Grayscale/luma, values in [0,1].
"""
from __future__ import annotations
import numpy as np
import cv2


def _box(img: np.ndarray, r: int) -> np.ndarray:
    return cv2.boxFilter(img, -1, (2 * r + 1, 2 * r + 1), normalize=True, borderType=cv2.BORDER_REFLECT)


def guided_filter(img: np.ndarray, radius: int = 2, eps: float = 25.0 / (255.0 ** 2)) -> np.ndarray:
    """Self-guided edge-preserving filter (He et al. 2010). O(N) via box filters.

    RECOVERED from zlt.dll kernel sub_180295F00 (reading the SIMD var+eps/matrix-inverse
    sequence):
      - window 5x5 (radius=2)  [box-mean normalization const 25.0]
      - eps = 25.0 (raw, added to the covariance diagonal v33=xmmword_1805097E0) in the
        8-bit variance domain  ->  ~ 25/255^2 = 3.8e-4 ~ (0.02)^2 in [0,1] terms.
    NOTE: Zoom's actual filter is the 3-CHANNEL (color) guided filter — a 3x3 covariance
    matrix inverse (det+cofactors), not this grayscale self-guided form. This is the
    luma-domain analog with the recovered window+eps; the color variant + exact fixed-
    point scale are the remaining gap (see PIXEL_DENOISE_FAMILY.md)."""
    I = img.astype(np.float32)
    mean_I = _box(I, radius)
    mean_II = _box(I * I, radius)
    var_I = mean_II - mean_I * mean_I
    a = var_I / (var_I + eps)          # self-guided: cov(I,I)=var(I)
    b = mean_I - a * mean_I
    mean_a = _box(a, radius)
    mean_b = _box(b, radius)
    return mean_a * I + mean_b


def color_guided_filter(rgb: np.ndarray, radius: int = 2,
                        eps: float = 25.0 / (255.0 ** 2)) -> np.ndarray:
    """3-channel (color) guided filter — He et al. 2010, the variant Zoom's
    zltCGuidedFilter uses (3x3 covariance-matrix inverse via det+cofactors, matching
    kernel sub_180295F00). Self-guided: guide = the color image, filter each channel.
    Recovered params: radius=2 (5x5), eps=25 (8-bit) ~= (0.02)^2 on [0,1] channels.

    rgb: (H,W,3) float in [0,1]. Returns denoised (H,W,3)."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mr, mg, mb = _box(r, radius), _box(g, radius), _box(b, radius)
    # symmetric covariance matrix of the guide (eps on the diagonal): [[crr,crg,crb],...]
    crr = _box(r * r, radius) - mr * mr + eps
    crg = _box(r * g, radius) - mr * mg
    crb = _box(r * b, radius) - mr * mb
    cgg = _box(g * g, radius) - mg * mg + eps
    cgb = _box(g * b, radius) - mg * mb
    cbb = _box(b * b, radius) - mb * mb + eps
    # inverse via cofactors / determinant (the SIMD kernel's structure)
    A = cgg * cbb - cgb * cgb
    B = crb * cgb - crg * cbb
    C = crg * cgb - crb * cgg
    det = crr * A + crg * B + crb * C
    inv = 1.0 / np.where(np.abs(det) < 1e-12, 1e-12, det)
    iaa, iab, iac = A * inv, B * inv, C * inv
    ibb = (crr * cbb - crb * crb) * inv
    ibc = (crb * crg - crr * cgb) * inv
    icc = (crr * cgg - crg * crg) * inv

    out = np.empty_like(rgb)
    for c, (chan, mc) in enumerate([(r, mr), (g, mg), (b, mb)]):
        cov_r = _box(r * chan, radius) - mr * mc
        cov_g = _box(g * chan, radius) - mg * mc
        cov_b = _box(b * chan, radius) - mb * mc
        a_r = iaa * cov_r + iab * cov_g + iac * cov_b
        a_g = iab * cov_r + ibb * cov_g + ibc * cov_b
        a_b = iac * cov_r + ibc * cov_g + icc * cov_b
        bco = mc - a_r * mr - a_g * mg - a_b * mb
        out[..., c] = _box(a_r, radius) * r + _box(a_g, radius) * g + _box(a_b, radius) * b + _box(bco, radius)
    return np.clip(out, 0.0, 1.0)


class GuidedRecursiveDenoiser:
    """Guided-filter spatial denoise + a simple motion-adaptive temporal recursion,
    mirroring the family's structure (spatial edge-preserving smoother, temporally
    stabilized). Streaming: one frame in/out."""

    def __init__(self, radius: int = 4, eps: float = 0.008, alpha_max: float = 0.9,
                 sigma_motion: float = 0.05, diff_blur: float = 2.0):
        self.radius = int(radius)
        self.eps = float(eps)
        self.alpha_max = float(alpha_max)
        self.sigma_motion = float(sigma_motion)
        self.diff_blur = float(diff_blur)
        self.state: np.ndarray | None = None

    def reset(self):
        self.state = None

    def process(self, frame: np.ndarray) -> np.ndarray:
        x = frame.astype(np.float32)
        if x.ndim != 2:
            x = x.mean(axis=2)
        spatial = guided_filter(x, self.radius, self.eps)
        if self.state is None:
            self.state = spatial.copy()
            return spatial.copy()
        motion = cv2.GaussianBlur(np.abs(spatial - self.state), (0, 0), self.diff_blur)
        alpha = self.alpha_max * np.exp(-(motion ** 2) / (2.0 * self.sigma_motion ** 2))
        out = alpha * self.state + (1.0 - alpha) * spatial
        self.state = out
        return out.copy()
