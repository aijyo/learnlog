"""Clean-room classical video denoisers (video-denoise P1 baseline suite).

Original code. Implements standard, publicly-known algorithms:
  - spatial edge-preserving denoise (bilateral / gaussian)
  - fixed-alpha temporal IIR (recurrent, streaming) -- ablation baseline
  - motion-adaptive recursive temporal denoiser -- the streaming centerpiece

Design rationale (why these three) is documented in
`../zlt-re/notes/DENOISE_ALGORITHMS.md`: they mirror the *algorithm classes*
observed in Zoom's zlt.dll (spatial zltCDenoise, IIR zltCIIRDenoise), but the
implementation, parameters and structure here are our own -- no vendor
constants, LUTs or code are reproduced.

Convention: frames are float32 arrays in [0,1], shape (H,W) or (H,W,C).
"""
from __future__ import annotations
import numpy as np
import cv2


def _as_f32(img: np.ndarray) -> np.ndarray:
    if img.dtype == np.uint8:
        return img.astype(np.float32) / 255.0
    return img.astype(np.float32, copy=False)


def _luma(img: np.ndarray) -> np.ndarray:
    return img if img.ndim == 2 else img.mean(axis=2)


# --------------------------------------------------------------------------
# Blind noise estimation -- Poisson-Gaussian noise level function (NLF)
# --------------------------------------------------------------------------
def estimate_nlf(frame: np.ndarray, patch: int = 7, nbins: int = 24,
                 flat_pct: float = 25.0):
    """Estimate a signal-dependent noise model Var(y) ~= a*intensity + b from ONE
    noisy frame, with no clean reference (blind). Method: over small windows,
    local variance in FLAT patches (bottom `flat_pct`% of local variance per
    intensity bin) approximates the noise variance at that intensity; fit a line
    variance-vs-intensity. This is the estimator analog of zltCIIRDenoise's
    luma-indexed noise LUT -- but derived from the data instead of baked in.

    Returns (a, b) with Var ~= a*I + b on the [0,1] intensity scale.
    """
    y = _luma(_as_f32(frame))
    k = (patch, patch)
    mu = cv2.boxFilter(y, -1, k)
    var = np.maximum(cv2.boxFilter(y * y, -1, k) - mu * mu, 0.0)
    mu_f, var_f = mu.ravel(), var.ravel()

    lo, hi = float(mu_f.min()), float(mu_f.max())
    edges = np.linspace(lo, hi, nbins + 1)
    xs, ys = [], []
    for i in range(nbins):
        sel = (mu_f >= edges[i]) & (mu_f < edges[i + 1])
        if sel.sum() < 64:
            continue
        # flat patches: low local variance = noise-dominated (not texture)
        xs.append(0.5 * (edges[i] + edges[i + 1]))
        ys.append(np.percentile(var_f[sel], flat_pct))
    if len(xs) < 2:
        v = float(np.percentile(var_f, flat_pct))
        return 0.0, max(v, 1e-6)
    xs, ys = np.asarray(xs), np.asarray(ys)
    A = np.vstack([xs, np.ones_like(xs)]).T
    a, b = np.linalg.lstsq(A, ys, rcond=None)[0]
    return float(a), float(max(b, 1e-8))


def estimate_nlf_temporal(frames: np.ndarray, nbins: int = 24, min_count: int = 200):
    """Estimate the noise level function from TEMPORAL frame differences.

    In a static region the frame difference d = y[t]-y[t-1] = noise[t]-noise[t-1]:
    the (identical) scene content CANCELS, leaving pure noise with Var(d)=2*sigma^2.
    So this escapes the texture bias that limits the spatial estimator -- texture
    can't masquerade as noise here because it subtracts out. Moving pixels have a
    large content term in d; they are outliers, rejected per intensity bin with the
    MAD (robust to <50% outliers), which the static background easily satisfies.

    Input: a stack of >=2 consecutive noisy frames (T,H,W[,C]); uses all pairs.
    Returns (a, b) with Var ~= a*I + b.
    """
    f = _as_f32(frames)
    if f.ndim == 4:            # (T,H,W,C) color stack -> per-frame luma
        f = f.mean(axis=3)
    if f.ndim != 3 or f.shape[0] < 2:
        raise ValueError("need a (T,H,W[,C]) stack of >=2 frames")
    d = (f[1:] - f[:-1]).ravel()                     # temporal diffs (raw: Var=2*sigma^2)
    inten = (0.5 * (f[1:] + f[:-1])).ravel()          # midpoint intensity
    # NOTE: at high noise this intensity axis is itself noisy -> binning on a noisy
    # x-axis flattens the fitted slope `a` (errors-in-variables), and [0,1] clipping
    # compresses the NLF tails. Both are noise-level (not texture) effects. Smoothing
    # the binning axis was tried (see exp03 notes): it fixes high-noise slope but
    # over-steepens at low noise, so it is NOT applied by default.
    edges = np.linspace(float(inten.min()), float(inten.max()), nbins + 1)
    xs, ys = [], []
    for i in range(nbins):
        sel = (inten >= edges[i]) & (inten < edges[i + 1])
        if sel.sum() < min_count:
            continue
        dd = d[sel]
        med = np.median(dd)
        mad = 1.4826 * np.median(np.abs(dd - med))    # robust std of d, outlier-proof
        xs.append(0.5 * (edges[i] + edges[i + 1]))
        ys.append((mad * mad) / 2.0)                  # Var(noise) = Var(d)/2
    if len(xs) < 2:
        return 0.0, max(float(np.median(ys)) if ys else 1e-6, 1e-8)
    xs, ys = np.asarray(xs), np.asarray(ys)
    a, b = np.linalg.lstsq(np.vstack([xs, np.ones_like(xs)]).T, ys, rcond=None)[0]
    return float(a), float(max(b, 1e-8))


def noise_sigma_map(intensity: np.ndarray, a: float, b: float) -> np.ndarray:
    """Per-pixel noise std from the NLF and an intensity (luma) map."""
    return np.sqrt(np.maximum(a * intensity + b, 1e-10))


# --------------------------------------------------------------------------
# Spatial (single-frame) edge-preserving denoise
# --------------------------------------------------------------------------
def spatial_bilateral(frame: np.ndarray, d: int = 5,
                      sigma_color: float = 0.18, sigma_space: float = 3.0) -> np.ndarray:
    """Edge-preserving spatial smoothing. This is the spatial component that the
    temporal filters fall back to in moving regions (the zltCDenoise analog)."""
    f = _as_f32(frame)
    return cv2.bilateralFilter(f, d, sigma_color, sigma_space)


def spatial_gaussian(frame: np.ndarray, sigma: float = 1.0) -> np.ndarray:
    f = _as_f32(frame)
    return cv2.GaussianBlur(f, (0, 0), sigma)


# --------------------------------------------------------------------------
# Temporal denoisers (streaming / recurrent: one frame in, one out, keep state)
# --------------------------------------------------------------------------
class FixedTemporalIIR:
    """out_t = a*out_{t-1} + (1-a)*x_t  (per pixel, constant a).

    The simplest recurrent temporal denoiser. Great SNR on static content, but
    GHOSTS on motion (no motion awareness). Included as the ablation that shows
    *why* motion-adaptivity matters."""

    def __init__(self, alpha: float = 0.8):
        self.alpha = float(alpha)
        self.state: np.ndarray | None = None

    def reset(self) -> None:
        self.state = None

    def process(self, frame: np.ndarray) -> np.ndarray:
        x = _as_f32(frame)
        if self.state is None:
            self.state = x.copy()
        else:
            self.state = self.alpha * self.state + (1.0 - self.alpha) * x
        return self.state.copy()


class MotionAdaptiveRecursiveDenoiser:
    """Clean-room analog of zlt.dll's zltCIIRDenoise.

    Per pixel, blend the temporal history with a spatially-cleaned current frame,
    where the blend weight depends on how much that pixel *moved*:

        motion_t   = spatially-smoothed |x_t - state_{t-1}|      (robust to noise)
        alpha_t    = alpha_max * exp(-(motion_t^2) / (2*sigma_m^2))   in [0, alpha_max]
        out_t      = alpha_t * state_{t-1} + (1 - alpha_t) * spatial(x_t)
        state_t    = out_t

    - Static pixels  -> motion~0 -> alpha~alpha_max -> heavy temporal averaging
      (big SNR gain, the whole point of using time).
    - Moving pixels  -> motion large -> alpha~0 -> output = spatial-only estimate
      (no ghosting / trailing).

    The diff is spatially blurred before the alpha mapping so that per-pixel NOISE
    is not mistaken for MOTION (the classic pitfall of naive temporal IIR).
    """

    def __init__(self, alpha_max: float = 0.95, sigma_motion: float = 0.10,
                 diff_blur_sigma: float = 3.0,
                 spatial_sigma_color: float = 0.18, spatial_sigma_space: float = 3.0,
                 motion_dilate: int = 0, motion_decay: float = 0.0):
        self.alpha_max = float(alpha_max)
        self.sigma_motion = float(sigma_motion)
        self.diff_blur_sigma = float(diff_blur_sigma)
        self.scc = float(spatial_sigma_color)
        self.scs = float(spatial_sigma_space)
        # anti-ghost guard (0/0 = off, original behaviour):
        #  motion_dilate: spatial max-spread of the motion map (px), so a moving EDGE
        #    suppresses temporal blending in the smooth INTERIOR near it (aperture problem);
        #  motion_decay: temporal persistence of motion, so a just-vacated pixel stays on
        #    the spatial estimate for a few frames instead of instantly trusting history.
        self.motion_dilate = int(motion_dilate)
        self.motion_decay = float(motion_decay)
        self.state: np.ndarray | None = None
        self.env: np.ndarray | None = None

    def reset(self) -> None:
        self.state = None
        self.env = None

    def _spatial(self, x: np.ndarray) -> np.ndarray:
        return cv2.bilateralFilter(x, 5, self.scc, self.scs)

    def process(self, frame: np.ndarray) -> np.ndarray:
        x = _as_f32(frame)
        spatial = self._spatial(x)
        if self.state is None:
            self.state = spatial.copy()
            return spatial.copy()

        # motion from the DENOISED current estimate vs history (not the noisy input),
        # so per-pixel noise is not read as motion.
        diff = np.abs(spatial - self.state)
        # collapse channels to a single motion magnitude, then blur to reject noise
        motion = diff if diff.ndim == 2 else diff.mean(axis=2)
        motion = cv2.GaussianBlur(motion, (0, 0), self.diff_blur_sigma)
        if self.motion_dilate > 0:      # spread motion from edges into smooth interiors
            k = 2 * self.motion_dilate + 1
            motion = cv2.dilate(motion, np.ones((k, k), np.float32))
        if self.motion_decay > 0:       # persist motion a few frames (clear trails)
            self.env = motion if self.env is None else np.maximum(motion, self.env * self.motion_decay)
            motion = self.env
        # sigma_motion must sit ABOVE the residual noise level and BELOW real object
        # motion, else static-but-noisy pixels get read as moving and lose temporal
        # averaging. (This is why zltCIIRDenoise carries a luma-indexed noise LUT: to
        # calibrate this threshold per pixel to the local noise floor. TODO: make
        # sigma_motion track an estimated per-pixel noise level instead of a constant.)
        alpha = self.alpha_max * np.exp(-(motion ** 2) / (2.0 * self.sigma_motion ** 2))
        if x.ndim == 3:
            alpha = alpha[:, :, None]

        out = alpha * self.state + (1.0 - alpha) * spatial
        self.state = out
        return out.copy()


class NoiseAdaptiveRecursiveDenoiser:
    """MotionAdaptiveRecursiveDenoiser with a NOISE-CALIBRATED motion threshold.

    Instead of a single constant `sigma_motion`, the per-pixel motion threshold is
    set to `k_motion * sigma_noise(pixel)`, where sigma_noise comes from a blind
    Poisson-Gaussian NLF estimate (`estimate_nlf`). So "is this pixel moving?" is
    judged in units of the LOCAL noise level: a 3-sigma jump is motion, anything
    smaller is noise and keeps its temporal averaging -- at every intensity and
    every noise level, without retuning. This is the principled version of the
    luma-noise-LUT trick seen in zlt.dll's zltCIIRDenoise.

    exp01 finding this fixes: a constant sigma_motion is only right for one noise
    level; too small at high noise (noise read as motion -> flicker), too large at
    low noise (motion over-smoothed -> ghosting).
    """

    def __init__(self, k_motion: float = 5.0, alpha_max: float = 0.95,
                 diff_blur_sigma: float = 3.0, nlf: tuple | None = None,
                 spatial_sigma_color: float = 0.18, spatial_sigma_space: float = 3.0):
        self.k_motion = float(k_motion)
        self.alpha_max = float(alpha_max)
        self.diff_blur_sigma = float(diff_blur_sigma)
        self.nlf = nlf                 # (a,b); if None, estimated from the first frame
        self.scc = float(spatial_sigma_color)
        self.scs = float(spatial_sigma_space)
        self.state: np.ndarray | None = None

    def reset(self) -> None:
        self.state = None

    def _spatial(self, x):
        return cv2.bilateralFilter(x, 5, self.scc, self.scs)

    def process(self, frame: np.ndarray) -> np.ndarray:
        x = _as_f32(frame)
        if self.nlf is None:
            self.nlf = estimate_nlf(x)          # blind estimate, once
        spatial = self._spatial(x)
        if self.state is None:
            self.state = spatial.copy()
            return spatial.copy()

        diff = np.abs(spatial - self.state)
        motion = diff if diff.ndim == 2 else diff.mean(axis=2)
        motion = cv2.GaussianBlur(motion, (0, 0), self.diff_blur_sigma)

        a, b = self.nlf
        # threshold per pixel = k * local noise sigma, from the (denoised) intensity.
        # diff_blur averages ~ (2*pi*sigma^2) pixels, shrinking the noise in `motion`
        # by ~1/sqrt(that); fold that into the effective threshold.
        eff = 1.0 / (2.5066 * self.diff_blur_sigma)          # ~1/sqrt(2*pi*sigma^2)
        sig = noise_sigma_map(_luma(self.state), a, b) * eff
        sigma_motion = np.maximum(self.k_motion * sig, 1e-4)
        alpha = self.alpha_max * np.exp(-(motion ** 2) / (2.0 * sigma_motion ** 2))
        if x.ndim == 3:
            alpha = alpha[:, :, None]

        out = alpha * self.state + (1.0 - alpha) * spatial
        self.state = out
        return out.copy()


class LumaProfileRecursiveDenoiser:
    """Motion-adaptive recursive denoiser whose per-pixel motion threshold follows a
    per-luma STRENGTH PROFILE. Lets us A/B *where* denoising strength is spent:

        sigma_motion(pixel) = sigma_mean * profile(luma) / mean(profile(luma))

    The profile is mean-normalized over the frame, so all profiles spend the SAME
    average strength -- only the luma DISTRIBUTION differs. Larger sigma_motion =>
    stronger temporal averaging at that luma.

    profile_fn(luma01 array) -> positive relative-strength array. Build it as:
      - uniform:       lambda L: np.ones_like(L)
      - noise-matched: lambda L: noise_sigma_map(L, a, b)         (spend where noise is)
      - zoom:          lambda L: zoom_strength01(L)               (Zoom's shadow-weighting)
    """

    def __init__(self, profile_fn, sigma_mean: float = 0.06, alpha_max: float = 0.95,
                 diff_blur_sigma: float = 3.0,
                 spatial_sigma_color: float = 0.18, spatial_sigma_space: float = 3.0):
        self.profile_fn = profile_fn
        self.sigma_mean = float(sigma_mean)
        self.alpha_max = float(alpha_max)
        self.diff_blur_sigma = float(diff_blur_sigma)
        self.scc = float(spatial_sigma_color)
        self.scs = float(spatial_sigma_space)
        self.state: np.ndarray | None = None

    def reset(self) -> None:
        self.state = None

    def _spatial(self, x):
        return cv2.bilateralFilter(x, 5, self.scc, self.scs)

    def process(self, frame: np.ndarray) -> np.ndarray:
        x = _as_f32(frame)
        spatial = self._spatial(x)
        if self.state is None:
            self.state = spatial.copy()
            return spatial.copy()

        diff = np.abs(spatial - self.state)
        motion = diff if diff.ndim == 2 else diff.mean(axis=2)
        motion = cv2.GaussianBlur(motion, (0, 0), self.diff_blur_sigma)

        luma = _luma(self.state)
        prof = np.asarray(self.profile_fn(luma), dtype=np.float32)
        prof = prof / (prof.mean() + 1e-8)              # mean-normalize: equal avg strength
        sigma_motion = np.maximum(self.sigma_mean * prof, 1e-4)
        alpha = self.alpha_max * np.exp(-(motion ** 2) / (2.0 * sigma_motion ** 2))
        if x.ndim == 3:
            alpha = alpha[:, :, None]

        out = alpha * self.state + (1.0 - alpha) * spatial
        self.state = out
        return out.copy()


class MotionCompensatedDenoiser:
    """Optical-flow motion-compensated temporal filter (the root fix for ghosting).

    Instead of just *suppressing* temporal blending where motion is (the guard), this
    ALIGNS the denoised history to the current frame with optical flow, then blends:

        flow        = Farneback(current -> previous)              # backward flow
        state_align = remap(state, grid + flow)                    # warp history to now
        resid       = |spatial(current) - state_align|             # flow-reliability
        alpha       = alpha_max * exp(-resid^2 / (2*occ_sigma^2))  # low where flow failed
        out         = alpha*state_align + (1-alpha)*spatial

    So moving content gets REAL temporal averaging (history follows the motion) with no
    ghost, and occlusions/flow-failures fall back to the spatial estimate. `flow_scale`
    computes flow at reduced resolution for speed.
    """

    def __init__(self, alpha_max: float = 0.9, occ_sigma: float = 0.06,
                 spatial_sigma_color: float = 0.18, spatial_sigma_space: float = 3.0,
                 flow_scale: float = 0.5, resid_blur: float = 1.5,
                 fb_check: bool = False, fbc_sigma: float = 1.0):
        self.alpha_max = float(alpha_max)
        self.occ_sigma = float(occ_sigma)
        self.scc = float(spatial_sigma_color)
        self.scs = float(spatial_sigma_space)
        self.flow_scale = float(flow_scale)
        self.resid_blur = float(resid_blur)
        # forward-backward flow consistency gate: reject unreliable flow (low-texture
        # regions produce garbage flow -> mis-warped history -> "water streak" drift).
        self.fb_check = bool(fb_check)
        self.fbc_sigma = float(fbc_sigma)   # px; round-trip error above this -> distrust
        self.state: np.ndarray | None = None
        self.prev: np.ndarray | None = None   # previous input luma (uint8) for flow

    def reset(self) -> None:
        self.state = None
        self.prev = None

    def _spatial(self, x):
        return cv2.bilateralFilter(x, 5, self.scc, self.scs)

    def _flow(self, cur8, prev8):
        s = self.flow_scale
        if s != 1.0:
            c = cv2.resize(cur8, (0, 0), fx=s, fy=s)
            p = cv2.resize(prev8, (0, 0), fx=s, fy=s)
        else:
            c, p = cur8, prev8
        f = cv2.calcOpticalFlowFarneback(c, p, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        if s != 1.0:
            f = cv2.resize(f, (cur8.shape[1], cur8.shape[0])) / s   # upscale flow + vectors
        return f

    def process(self, frame: np.ndarray) -> np.ndarray:
        x = _as_f32(frame)
        if x.ndim != 2:
            x = _luma(x)
        spatial = self._spatial(x)
        cur8 = (np.clip(x, 0, 1) * 255).astype(np.uint8)
        if self.state is None:
            self.state = spatial.copy()
            self.prev = cur8
            return spatial.copy()

        flow = self._flow(cur8, self.prev)               # current -> previous
        h, w = x.shape
        gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
        mapx, mapy = gx + flow[..., 0], gy + flow[..., 1]
        state_align = cv2.remap(self.state, mapx, mapy,
                                cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        resid = np.abs(spatial - state_align)
        resid = cv2.GaussianBlur(resid, (0, 0), self.resid_blur)
        alpha = self.alpha_max * np.exp(-(resid ** 2) / (2.0 * self.occ_sigma ** 2))

        if self.fb_check:
            # backward flow (prev -> current), sampled at where forward flow points;
            # for reliable flow the round trip returns to origin: f + b(p+f) ~= 0.
            flow_b = self._flow(self.prev, cur8)
            fb = cv2.remap(flow_b, mapx, mapy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
            fb_err2 = (flow[..., 0] + fb[..., 0]) ** 2 + (flow[..., 1] + fb[..., 1]) ** 2
            conf = np.exp(-fb_err2 / (2.0 * self.fbc_sigma ** 2))   # 1=reliable, 0=garbage
            alpha = alpha * conf                                    # distrust bad flow -> spatial

        out = alpha * state_align + (1.0 - alpha) * spatial
        self.state = out
        self.prev = cur8
        return out.copy()


def run_stream(denoiser, frames: np.ndarray) -> np.ndarray:
    """Run a stateful denoiser over a (T,H,W[,C]) stack; returns same-shape output."""
    if hasattr(denoiser, "reset"):
        denoiser.reset()
    out = np.empty_like(_as_f32(frames))
    for t in range(frames.shape[0]):
        out[t] = denoiser.process(frames[t])
    return out


def run_spatial(fn, frames: np.ndarray, **kw) -> np.ndarray:
    """Apply a per-frame spatial function independently to each frame."""
    f = _as_f32(frames)
    out = np.empty_like(f)
    for t in range(f.shape[0]):
        out[t] = fn(f[t], **kw)
    return out
