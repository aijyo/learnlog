"""Capture a short clip from the local webcam (for real low-light denoise tests).

Turns the camera ON, grabs N frames at the requested resolution, writes an .mp4.
Intended for capturing a genuine low-light sensor-noise sequence: dim the room
first so shot/read noise is actually visible.

    python scripts/capture_webcam.py [--cam 0] [--frames 90] [--fps 15]
                                     [--width 640] [--height 480]
                                     [--out samples/lowlight_capture.mp4]

Nothing is uploaded; the file stays local (samples/ is .gitignored).
"""
from __future__ import annotations
import os, sys, argparse
import cv2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cam", type=int, default=0)
    ap.add_argument("--frames", type=int, default=90)
    ap.add_argument("--fps", type=int, default=15)
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--warmup", type=int, default=10, help="frames to discard for AE/AGC settle")
    ap.add_argument("--exposure", type=float, default=None,
                    help="manual exposure (DSHOW log2 seconds, e.g. -8 = 1/256s). "
                         "Low value = short exposure = dark + noisy = forced low-light. "
                         "Omit for auto-exposure.")
    ap.add_argument("--gain", type=float, default=None, help="manual sensor gain (optional)")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..",
                                                  "samples", "lowlight_capture.mp4"))
    a = ap.parse_args()
    os.makedirs(os.path.dirname(a.out), exist_ok=True)

    cap = cv2.VideoCapture(a.cam, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, a.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, a.height)
    if a.exposure is not None:
        cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)   # DSHOW: 0.25 = manual exposure
        cap.set(cv2.CAP_PROP_EXPOSURE, a.exposure)
        print(f"manual exposure set to {a.exposure} (auto-exposure off)")
    if a.gain is not None:
        cap.set(cv2.CAP_PROP_GAIN, a.gain)
    if not cap.isOpened():
        raise SystemExit(f"cannot open camera index {a.cam}")
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    print(f"camera {a.cam} open @ {w}x{h}; warming up {a.warmup} frames...")
    for _ in range(a.warmup):
        cap.read()

    vw = cv2.VideoWriter(a.out, cv2.VideoWriter_fourcc(*"mp4v"), a.fps, (w, h))
    n = 0
    while n < a.frames:
        ok, fr = cap.read()
        if not ok:
            break
        vw.write(fr)
        n += 1
    vw.release()
    cap.release()
    print(f"captured {n} frames -> {a.out}")


if __name__ == "__main__":
    main()
