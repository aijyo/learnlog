"""Noise parameters recovered from Zoom's zlt.dll (zltCIIRDenoise), as FACTS.

Reverse-engineered from the const table `qword_1805057D0` (.rdata, read-only) and
the surrounding kernel sub_1802A6DF0 in zlt.dll via IDA. Recovered constants
(lookup curve, thresholds, blend weights) are factual data, not copyrightable
expression; only a compact FITTED form of the curve is kept here (not the raw
256-entry table). Analysis: ../zlt-re/notes/DENOISE_ALGORITHMS.md and
../zlt-re/notes/ZOOM_NOISE_PARAMS.md.

The LUT is Zoom's per-luma curve used to normalize local activity inside the
denoiser. Shape recovered from the binary:
  - very high in deep shadow (~316 @luma0, ~95 @luma1), ~1/luma decay,
  - fitted:  curve8(luma) ~= 117.6/(luma+0.1) + 0.22   (8-bit units, luma 1..126;
    RMSE 0.15, median rel-err 5.6%),
  - the raw table is hard-zeroed for luma >= 127 (Zoom routes bright pixels through
    an activity branch instead).

IMPORTANT (empirically corrected in exp06): this shadow-weighted 1/luma shape is
NOT the shape of real sensor noise. On the real C270 low-light clip, measured
per-luma noise sigma INCREASES with luma (shot/Poisson-Gaussian shaped) -- the
OPPOSITE of this curve. So the LUT is a per-luma denoise-STRENGTH / aggressiveness
curve (Zoom smooths shadows harder, a perceptual/SNR design choice), NOT a
measurement of noise sigma(luma). Use it as a denoiser strength curve; do NOT use
it as a noise-generator sigma. For the noise MODEL, Poisson-Gaussian (sigma rising
with luma) is the real-data-validated shape. See ../zlt-re/notes/ZOOM_NOISE_PARAMS.md.
"""
from __future__ import annotations
import numpy as np

# --- fitted LUT parameters (8-bit activity scale) ---
_A, _B, _C = 117.579, 0.100, 0.217

# --- other recovered coefficients (facts) ---
LUMA_SPLIT = 82           # dark/bright branch threshold (0x52)
TEMPORAL_BLEND = 166 / 256  # history weight ~=0.648 when frame-depth > 2 (else 0, pure spatial)
ACTIVITY_CAP = 200.0
# a5 (spatial strength) ramp: <18 ->1.0 ; 18..28 -> 0.06*a5-0.08 ; >28 ->1.6
# a6 (temporal strength) ramp: <25 ->0.9 ; 25..80 -> 0.001818*a6+0.8545 ; >80 ->1.0


def zoom_strength8(luma8: np.ndarray) -> np.ndarray:
    """Zoom's per-luma denoise-strength curve on the 8-bit scale (luma in [0,255]).
    NB: strength/normalization curve, not a noise sigma (see module docstring)."""
    luma8 = np.asarray(luma8, dtype=np.float64)
    return _A / (luma8 + _B) + _C


def zoom_strength01(v: np.ndarray) -> np.ndarray:
    """Same curve for frames in [0,1]."""
    return zoom_strength8(np.clip(np.asarray(v, dtype=np.float64), 0, 1) * 255.0) / 255.0
