"""Synthetic noise models for video-denoise, from ideal to camera-realistic.

exp04 (real C270 footage) showed real noise is NOT the textbook per-pixel
Poisson-Gaussian: the spatial vs temporal sigma estimates diverged ~3x. Real
sensor+ISP noise adds three things a pure AWGN/PG model misses:

  1. spatial correlation  -- in-camera demosaic/denoise blurs noise across pixels
  2. fixed-pattern noise   -- DSNU (additive) + PRNU (gain) that are CONSTANT over
                              time (per-pixel, baked into the sensor)
  3. temporal correlation  -- in-camera temporal denoise makes frame t's noise
                              partly a copy of frame t-1's (AR(1) in time)

Each has a distinct estimator signature (validated in exp05):
  - fixed-pattern  -> inflates the SPATIAL estimate (cancels in temporal diff)
  - spatial-corr   -> deflates the SPATIAL estimate (neighbors correlated)
  - temporal-corr  -> deflates the TEMPORAL estimate (diff sees (1-rho) of it)

All operate on a whole (T,H,W) clean sequence in [0,1]; fixed-pattern maps are
drawn ONCE and shared across frames (that is what makes them "fixed").
"""
from __future__ import annotations
import numpy as np
import cv2


def add_poisson_gaussian_seq(clean: np.ndarray, rng, peak: float = 40.0,
                             read_sigma: float = 0.02) -> np.ndarray:
    """Ideal per-pixel Poisson-Gaussian (the exp01 baseline model), sequence form.
    Var(y) = clean/peak + read_sigma^2, independent per pixel and per frame."""
    return add_realistic_noise_seq(clean, rng, peak, read_sigma,
                                   spatial_corr=0.0, dsnu=0.0, prnu=0.0,
                                   temporal_rho=0.0)


def add_realistic_noise_seq(clean: np.ndarray, rng, peak: float = 40.0,
                            read_sigma: float = 0.02, spatial_corr: float = 0.0,
                            dsnu: float = 0.0, prnu: float = 0.0,
                            temporal_rho: float = 0.0, return_fpn: bool = False):
    """Camera-realistic noise. Components off by default -> reduces to Poisson-Gaussian.

    spatial_corr : gaussian sigma (px) low-passing the temporal noise (0 = white).
    dsnu         : additive fixed-pattern std (constant over time).
    prnu         : multiplicative fixed-pattern (gain) std (constant over time).
    temporal_rho : AR(1) coefficient coupling consecutive frames' noise in [0,1).
    return_fpn   : also return (dsnu_map, prnu_map) for ground-truth FPN analysis.
    """
    clean = clean.astype(np.float32)
    T, H, W = clean.shape
    dsnu_map = rng.normal(0.0, dsnu, (H, W)).astype(np.float32) if dsnu > 0 else None
    prnu_map = (1.0 + rng.normal(0.0, prnu, (H, W)).astype(np.float32)) if prnu > 0 else None

    out = np.empty_like(clean)
    prev = None
    for t in range(T):
        c = clean[t]
        shot = rng.poisson(np.clip(c, 0, 1) * peak).astype(np.float32) / peak - c  # var=c/peak
        read = rng.normal(0.0, read_sigma, (H, W)).astype(np.float32)
        tn = shot + read                                    # zero-mean temporal noise
        if spatial_corr > 0:
            s0 = tn.std()
            tn = cv2.GaussianBlur(tn, (0, 0), spatial_corr)
            tn *= s0 / (tn.std() + 1e-8)                    # preserve marginal variance
        if temporal_rho > 0 and prev is not None:
            tn = temporal_rho * prev + np.sqrt(1.0 - temporal_rho ** 2) * tn
        prev = tn

        y = c.copy()
        if prnu_map is not None:
            y = prnu_map * y
        if dsnu_map is not None:
            y = y + dsnu_map
        out[t] = np.clip(y + tn, 0.0, 1.0)
    if return_fpn:
        d = dsnu_map if dsnu_map is not None else np.zeros((H, W), np.float32)
        p = prnu_map if prnu_map is not None else np.ones((H, W), np.float32)
        return out, (d, p)
    return out


def add_pg_gamma_domain(clean_srgb: np.ndarray, rng, peak: float = 40.0,
                        read_sigma_lin: float = 0.05, gamma: float = 2.2) -> np.ndarray:
    """Poisson-Gaussian noise generated in the LINEAR domain, then gamma-encoded to
    sRGB. Because gamma has a steep slope near black, a (linear) read-noise floor is
    amplified into the shadows: the resulting sRGB-domain noise sigma DECREASES with
    luma (shadow-heavy) -- the opposite of add_realistic_noise_seq's shot-weighted
    (increasing) profile. This is the regime Zoom's shadow-weighted curve targets;
    use it to test WHEN shadow-weighted denoising strength is the right choice.
    """
    clean_srgb = np.clip(clean_srgb.astype(np.float32), 0, 1)
    lin = clean_srgb ** gamma
    out = np.empty_like(clean_srgb)
    for t in range(lin.shape[0]):
        c = lin[t]
        shot = rng.poisson(np.clip(c, 0, 1) * peak).astype(np.float32) / peak - c
        read = rng.normal(0.0, read_sigma_lin, c.shape).astype(np.float32)
        noisy_lin = np.clip(c + shot + read, 1e-6, 1.0)
        out[t] = np.clip(noisy_lin ** (1.0 / gamma), 0.0, 1.0)
    return out


# realistic default that roughly matches the C270 low-light signature
C270_LIKE = dict(peak=40.0, read_sigma=0.02, spatial_corr=0.8,
                 dsnu=0.010, prnu=0.012, temporal_rho=0.55)

# empirically MEASURED noise level on the real C270 low-light clip (exp06):
# a per-luma temporal-noise fit  Var ~= 0.0021*luma + 0.00018  (sigma RISES with
# luma -> shot/Poisson-Gaussian shaped, confirming the PG shape over Zoom's
# shadow-weighted denoise-strength curve). Mapped to this model's params:
#   peak = 1/a ~= 476,  read_sigma = sqrt(b) ~= 0.013.
# Caveats: TEMPORAL estimate (in-camera temporal denoise makes it a lower bound),
# grayscale, this specific short-exposure clip. Use as a real-grounded starting
# point, not a universal constant.
C270_MEASURED = dict(peak=476.0, read_sigma=0.013, spatial_corr=0.8,
                     dsnu=0.010, prnu=0.012, temporal_rho=0.55)
