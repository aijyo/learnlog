"""Real-footage denoise harness (no ground truth).

Runs the classical denoise stack on an arbitrary video and reports what we CAN
measure without a clean reference:
  - blind noise estimate (spatial vs temporal NLF)  -> "is sigma reasonable?"
  - flicker reduction on an AUTO-detected low-motion region (input vs output)
  - a side-by-side montage (noisy | denoised) + optional output video, for the
    subjective look that PSNR can't give us here.

Usage:
    python scripts/denoise_video.py <input_video> [--frames 60] [--gray]
                                    [--out <dir>] [--k 5.0] [--write-video]

No GT means no PSNR/SSIM -- by design. The honest signals on real footage are:
sigma-estimate sanity, static-region flicker drop, and eyeballing the montage.
"""
from __future__ import annotations
import os, sys, argparse
import numpy as np
import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
from classical_denoise import (  # noqa: E402
    estimate_nlf, estimate_nlf_temporal, noise_sigma_map,
    NoiseAdaptiveRecursiveDenoiser, run_stream,
)


def load_video(path, max_frames=60, gray=True):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise SystemExit(f"cannot open video: {path}")
    frames = []
    while len(frames) < max_frames:
        ok, fr = cap.read()
        if not ok:
            break
        if gray:
            fr = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
        frames.append(fr.astype(np.float32) / 255.0)
    cap.release()
    if len(frames) < 2:
        raise SystemExit("need >=2 frames")
    return np.asarray(frames)


def auto_static_mask(frames, blur_sigma=2.0, keep_pct=40.0):
    """Low-motion pixels: temporal std of the spatially-blurred (noise-suppressed)
    sequence is small where nothing moves. Returns a bool (H,W) mask."""
    bl = np.stack([cv2.GaussianBlur(f, (0, 0), blur_sigma) for f in frames])
    motion = bl.std(axis=0)
    thr = np.percentile(motion, keep_pct)
    return motion <= thr


def flicker(seq, mask):
    return float(seq.std(axis=0)[mask].mean())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--frames", type=int, default=60)
    ap.add_argument("--out", default=None)
    ap.add_argument("--k", type=float, default=5.0)
    ap.add_argument("--write-video", action="store_true")
    a = ap.parse_args()

    out_dir = a.out or os.path.join(os.path.dirname(__file__), "..", "samples",
                                    "denoise_out")
    os.makedirs(out_dir, exist_ok=True)

    frames = load_video(a.input, a.frames, gray=True)
    T, H, W = frames.shape
    print(f"loaded {T} frames {W}x{H} (gray) from {os.path.basename(a.input)}")

    # --- blind noise estimate: spatial vs temporal ---
    a_s, b_s = estimate_nlf(frames[T // 2])
    a_v, b_v = estimate_nlf_temporal(frames)
    mid = float(np.median(frames))
    print("\nblind noise estimate  (Var = a*I + b;  sigma at median intensity "
          f"I={mid:.2f})")
    print(f"  spatial : a={a_s:.4f} b={b_s:.5f}  sigma={np.sqrt(max(a_s*mid+b_s,1e-9)):.4f}")
    print(f"  temporal: a={a_v:.4f} b={b_v:.5f}  sigma={np.sqrt(max(a_v*mid+b_v,1e-9)):.4f}")
    print("  (temporal escapes texture bias; on real footage treat it as the ref.)")

    # --- denoise with the noise-adaptive recursive filter (temporal NLF) ---
    den = NoiseAdaptiveRecursiveDenoiser(k_motion=a.k, nlf=(a_v, b_v))
    out = run_stream(den, frames)

    # --- flicker on auto-detected static region ---
    mask = auto_static_mask(frames)
    fin, fout = flicker(frames, mask), flicker(out, mask)
    print(f"\nstatic region = {mask.mean()*100:.0f}% of frame (auto, low-motion)")
    print(f"flicker (temporal std on static px):  input {fin*1e3:.2f}e-3  ->  "
          f"output {fout*1e3:.2f}e-3   ({(1-fout/fin)*100:.0f}% reduction)")

    # --- subjective artifacts: montage + optional video ---
    idxs = np.linspace(0, T - 1, min(4, T)).astype(int)
    rows = []
    for i in idxs:
        pair = np.hstack([frames[i], out[i]])
        rows.append((np.clip(pair, 0, 1) * 255).astype(np.uint8))
    montage = np.vstack(rows)
    mpath = os.path.join(out_dir, "montage_noisy_left_denoised_right.png")
    cv2.imwrite(mpath, montage)
    print(f"\nmontage (noisy | denoised, {len(idxs)} frames) -> {mpath}")

    if a.write_video:
        vp = os.path.join(out_dir, "denoised.mp4")
        vw = cv2.VideoWriter(vp, cv2.VideoWriter_fourcc(*"mp4v"), 15, (W, H), False)
        for i in range(T):
            vw.write((np.clip(out[i], 0, 1) * 255).astype(np.uint8))
        vw.release()
        print(f"denoised video -> {vp}")


if __name__ == "__main__":
    main()
