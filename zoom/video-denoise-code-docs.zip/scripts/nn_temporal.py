"""Temporal (multi-frame) denoising network + synthetic MOTION-sequence data.

Single-frame denoising can't exploit the redundancy between video frames. A temporal
net takes T consecutive noisy frames and outputs the denoised MIDDLE frame, so it can
average out noise across frames (implicitly aligning motion). To learn anything from
the temporal axis the training data must have inter-frame correlation, i.e. real
motion — so we render clean textured canvases and slide a crop window across them with
a random velocity, then add INDEPENDENT Poisson-Gaussian noise per frame.

Design for a clean ablation: the same architecture is used for every T (including T=1,
which reproduces the single-frame DnCNN). The ONLY difference between the single-frame
baseline and the temporal nets is the first conv's input-channel count, so any quality
gain is attributable to temporal information, not extra capacity.
"""
from __future__ import annotations
import numpy as np
import cv2
import torch
import torch.nn as nn

from nn_denoise import make_clean_patches   # reuse the multi-scale texture generator


def make_motion_sequences(n, T, size, rng, max_speed=1.5, accel=0.3):
    """Return (n, T, size, size) clean sequences with smooth sub-pixel motion.
    The middle frame (index T//2) is the reference the temporal net reconstructs."""
    margin = int(np.ceil(max_speed * T + abs(accel) * T * T)) + 4
    big = size + 2 * margin
    canv = make_clean_patches(n, big, rng)          # (n, big, big) clean textures in [0,1]
    seqs = np.empty((n, T, size, size), np.float32)
    mid = (T - 1) / 2.0
    for i in range(n):
        vx, vy = rng.uniform(-max_speed, max_speed, 2)
        ax, ay = rng.uniform(-accel, accel, 2)
        ox, oy = rng.uniform(-2, 2, 2)              # small offset so window isn't perfectly centered
        for t in range(T):
            s = t - mid
            dx = margin + ox + vx * s + 0.5 * ax * s * s
            dy = margin + oy + vy * s + 0.5 * ay * s * s
            M = np.float32([[1, 0, -dx], [0, 1, -dy]])
            seqs[i, t] = cv2.warpAffine(canv[i], M, (size, size),
                                        flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    return seqs


def add_pg_noise_seq(clean_seq, rng, peak=30.0, read=0.03):
    """Independent Poisson-Gaussian noise per frame (temporal noise is uncorrelated)."""
    out = np.empty_like(clean_seq)
    for i in range(clean_seq.shape[0]):
        for t in range(clean_seq.shape[1]):
            c = np.clip(clean_seq[i, t], 0, 1)
            out[i, t] = np.clip(rng.poisson(c * peak) / peak + rng.normal(0, read, c.shape), 0, 1)
    return out.astype(np.float32)


def add_pg_noise_seq_blind(clean_seq, rng, peak_lo=12.0, peak_hi=400.0, read_lo=0.004, read_hi=0.045):
    """Per-sequence random noise level (blind), same level across the T frames of a clip."""
    out = np.empty_like(clean_seq)
    for i in range(clean_seq.shape[0]):
        peak = float(np.exp(rng.uniform(np.log(peak_lo), np.log(peak_hi))))
        read = float(rng.uniform(read_lo, read_hi))
        for t in range(clean_seq.shape[1]):
            c = np.clip(clean_seq[i, t], 0, 1)
            out[i, t] = np.clip(rng.poisson(c * peak) / peak + rng.normal(0, read, c.shape), 0, 1)
    return out.astype(np.float32)


class TemporalDnCNN(nn.Module):
    """Early-fusion temporal DnCNN: T frames stacked on the channel axis -> denoised
    middle frame via residual learning (mid_frame - predicted_noise). T=1 == single-frame."""

    def __init__(self, t_in=3, feat=8, depth=3, use_bn=True):
        super().__init__()
        self.t_in = t_in
        layers = [nn.Conv2d(t_in, feat, 3, padding=1), nn.ReLU(inplace=True)]
        for _ in range(depth - 2):
            layers.append(nn.Conv2d(feat, feat, 3, padding=1))
            if use_bn:
                layers.append(nn.BatchNorm2d(feat))
            layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv2d(feat, 1, 3, padding=1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):                 # x: (N, T, H, W)
        mid = x[:, self.t_in // 2: self.t_in // 2 + 1]     # reference = middle frame
        return mid - self.net(x)

    def n_params(self):
        return sum(p.numel() for p in self.parameters())


def to_tensor_seq(seq):                   # (N, T, H, W) float -> torch tensor
    return torch.from_numpy(np.ascontiguousarray(seq)).float()
