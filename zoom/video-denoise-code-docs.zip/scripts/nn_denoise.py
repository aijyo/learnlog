"""P2 — single-frame neural denoiser (DnCNN-style) + synthetic data pipeline.

Discipline (CLAUDE.md): before any real training, prove the TRAINING FEEDBACK LOOP
with a micro-overfit (tiny batch -> loss ~0). This module holds the reusable pieces;
exp14 runs the overfit sanity check, exp15 does small training + baseline comparison.

Grayscale (luma), values in [0,1] — matches the classical baseline & demo.
"""
from __future__ import annotations
import numpy as np
import cv2
import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# data: synthetic clean patches + controllable Poisson-Gaussian noise
# ---------------------------------------------------------------------------
def make_clean_patches(n: int, size: int, rng: np.random.Generator) -> np.ndarray:
    """Rich-ish synthetic clean grayscale patches (multi-scale texture + a few
    shapes/edges) so the net learns real denoising, not a trivial constant.
    Returns (n, size, size) float32 in [0,1]. GT is free & controllable."""
    out = np.empty((n, size, size), np.float32)
    for i in range(n):
        img = np.zeros((size, size), np.float32)
        for scale, amp in [(1.0, 0.5), (3.0, 0.8), (7.0, 1.0)]:
            img += amp * cv2.GaussianBlur(rng.standard_normal((size, size)).astype(np.float32),
                                          (0, 0), scale)
        # a few edges/shapes for structure to preserve
        for _ in range(rng.integers(1, 4)):
            x, y = rng.integers(0, size, 2)
            w, h = rng.integers(size // 6, size // 2, 2)
            img[y:y + h, x:x + w] += rng.uniform(-1.0, 1.0)
        img = (img - img.min()) / (np.ptp(img) + 1e-6)
        out[i] = 0.08 + 0.86 * img
    return out


def add_pg_noise(clean: np.ndarray, rng: np.random.Generator,
                 peak: float = 40.0, read_sigma: float = 0.02) -> np.ndarray:
    """Independent Poisson-Gaussian noise per image (no FPN/temporal — single-frame).
    Var(y) = clean/peak + read_sigma^2."""
    c = np.clip(clean, 0, 1)
    shot = rng.poisson(c * peak).astype(np.float32) / peak
    read = rng.normal(0.0, read_sigma, clean.shape).astype(np.float32)
    return np.clip(shot + read, 0.0, 1.0)


def to_tensor(arr: np.ndarray) -> torch.Tensor:
    """(N,H,W) or (H,W) float32 -> (N,1,H,W) tensor."""
    if arr.ndim == 2:
        arr = arr[None]
    return torch.from_numpy(np.ascontiguousarray(arr[:, None])).float()


def to_numpy(t: torch.Tensor) -> np.ndarray:
    """(N,1,H,W) -> (N,H,W)."""
    return t.detach().clamp(0, 1).cpu().numpy()[:, 0]


# ---------------------------------------------------------------------------
# model: DnCNN (residual learning — predict the noise, subtract it)
# ---------------------------------------------------------------------------
class DnCNN(nn.Module):
    def __init__(self, ch: int = 1, feat: int = 48, depth: int = 7, use_bn: bool = True):
        super().__init__()
        layers = [nn.Conv2d(ch, feat, 3, padding=1), nn.ReLU(inplace=True)]
        for _ in range(depth - 2):
            layers.append(nn.Conv2d(feat, feat, 3, padding=1, bias=not use_bn))
            if use_bn:
                layers.append(nn.BatchNorm2d(feat))
            layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv2d(feat, ch, 3, padding=1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return x - self.net(x)          # residual: input minus predicted noise

    def n_params(self):
        return sum(p.numel() for p in self.parameters())


def psnr_t(a: torch.Tensor, b: torch.Tensor) -> float:
    mse = torch.mean((a.clamp(0, 1) - b.clamp(0, 1)) ** 2).item()
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)
