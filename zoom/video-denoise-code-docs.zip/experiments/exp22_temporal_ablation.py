"""exp22 - does feeding TEMPORAL frames into the net beat single-frame at equal capacity?

Discipline: (1) build the training feedback loop first (micro-overfit a multi-frame
batch to ~0 loss -> the T-frame pipeline is wired right), then (2) one variable only:
same architecture, input T=1 (single-frame baseline) vs T=3 vs T=5. All three take the
CENTER T frames of the SAME 5-frame motion clip, so the GT (middle frame) and the motion
are identical across variants — any PSNR/SSIM gain is attributable to temporal info, not
capacity. Reports middle-frame PSNR/SSIM + params + ms/frame@480x640, with bilateral as
the classical anchor.

    python experiments/exp22_temporal_ablation.py
"""
from __future__ import annotations
import os, sys, time
import numpy as np
import cv2
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_temporal import (make_motion_sequences, add_pg_noise_seq, TemporalDnCNN,  # noqa: E402
                         to_tensor_seq)
from classical_denoise import spatial_bilateral  # noqa: E402

SEED, PEAK, READ, SIZE = 20260724, 30.0, 0.03, 64
NTR, NVAL, EPOCHS, BS, LR = 512, 96, 24, 32, 2e-3
TCLIP = 5                       # render 5-frame clips; take center T frames per variant
FEAT, DEPTH = 8, 3


def psnr(a, b):
    m = float(np.mean((np.clip(a, 0, 1) - np.clip(b, 0, 1)) ** 2))
    return 99.0 if m < 1e-12 else 10.0 * np.log10(1.0 / m)


def ssim(a, b):
    C1, C2 = 0.01 ** 2, 0.03 ** 2
    ma = cv2.GaussianBlur(a, (11, 11), 1.5); mb = cv2.GaussianBlur(b, (11, 11), 1.5)
    va = cv2.GaussianBlur(a * a, (11, 11), 1.5) - ma * ma
    vb = cv2.GaussianBlur(b * b, (11, 11), 1.5) - mb * mb
    vab = cv2.GaussianBlur(a * b, (11, 11), 1.5) - ma * mb
    s = ((2 * ma * mb + C1) * (2 * vab + C2)) / ((ma * ma + mb * mb + C1) * (va + vb + C2) + 1e-12)
    return float(s.mean())


def center(seq5, t_in):
    s = (TCLIP - t_in) // 2
    return seq5[:, s:s + t_in]


def micro_overfit():
    # Validate the T-frame PIPELINE (GT indexing, channel stacking, backprop), not the
    # tiny net's capacity: use a high-capacity net on FEW clips -> must reach near-0 loss.
    rng = np.random.default_rng(0)
    clean = make_motion_sequences(4, TCLIP, SIZE, rng)
    noisy = add_pg_noise_seq(clean, rng, PEAK, READ)
    x = to_tensor_seq(center(noisy, 3))
    gt = to_tensor_seq(clean[:, TCLIP // 2:TCLIP // 2 + 1])
    torch.manual_seed(0)
    net = TemporalDnCNN(3, feat=32, depth=5); opt = torch.optim.Adam(net.parameters(), lr=3e-3)
    lossf = torch.nn.MSELoss()
    p0 = psnr(net(x).detach().numpy(), gt.numpy())
    for _ in range(2500):
        opt.zero_grad(); loss = lossf(net(x), gt); loss.backward(); opt.step()
    p1 = psnr(net(x).detach().numpy(), gt.numpy())
    print(f"[feedback loop] micro-overfit 4 clips (T=3, feat32/depth5): PSNR {p0:.1f} -> {p1:.1f} dB, loss {loss.item():.2e}")
    return p1 > 38.0


def train(t_in, clean_tr, gt_tr, xcva, gtva, rng, dev):
    torch.manual_seed(SEED)
    net = TemporalDnCNN(t_in, FEAT, DEPTH, use_bn=True).to(dev)
    opt = torch.optim.Adam(net.parameters(), lr=LR)
    lossf = torch.nn.MSELoss()
    t0 = time.time()
    for ep in range(EPOCHS):
        net.train()
        noisy5 = add_pg_noise_seq(clean_tr, rng, PEAK, READ)
        x = to_tensor_seq(center(noisy5, t_in)).to(dev)
        idx = rng.permutation(NTR)
        for i in range(0, NTR, BS):
            b = idx[i:i + BS]
            opt.zero_grad(); lossf(net(x[b]), gt_tr[b].to(dev)).backward(); opt.step()
    return net, time.time() - t0


def ms_per_frame(net, t_in, dev):
    ft = torch.rand(1, t_in, 480, 640).to(dev)
    net.eval()
    with torch.no_grad():
        for _ in range(2): net(ft)
        t = time.time()
        for _ in range(5): net(ft)
    return (time.time() - t) * 1000 / 5


def main():
    dev = "cpu"
    torch.set_num_threads(os.cpu_count() or 4)
    if not micro_overfit():
        print("micro-overfit did not converge — pipeline suspect, stopping."); return

    rng = np.random.default_rng(SEED)
    clean_tr = make_motion_sequences(NTR, TCLIP, SIZE, rng)
    gt_tr = to_tensor_seq(clean_tr[:, TCLIP // 2:TCLIP // 2 + 1])
    clean_va = make_motion_sequences(NVAL, TCLIP, SIZE, rng)
    noisy_va5 = add_pg_noise_seq(clean_va, rng, PEAK, READ)
    gt_va = clean_va[:, TCLIP // 2]                       # (N, H, W)

    # classical anchor: bilateral on the noisy middle frame
    mid_noisy = noisy_va5[:, TCLIP // 2]
    bil = np.stack([spatial_bilateral(mid_noisy[i]) for i in range(NVAL)])
    bq = np.mean([psnr(bil[i], gt_va[i]) for i in range(NVAL)])
    bs = np.mean([ssim(bil[i], gt_va[i]) for i in range(NVAL)])
    nq = np.mean([psnr(mid_noisy[i], gt_va[i]) for i in range(NVAL)])

    print(f"\ndevice={dev}  motion clips, PG(peak={PEAK},read={READ}), middle-frame recon")
    print(f"{'variant':<14}{'params':>8}{'PSNR':>8}{'SSIM':>8}{'ms/frame':>10}")
    print("-" * 48)
    print(f"{'noisy(in)':<14}{'-':>8}{nq:>8.2f}{'-':>8}{'-':>10}")
    print(f"{'bilateral':<14}{'-':>8}{bq:>8.2f}{bs:>8.3f}{'-':>10}")

    gtva_t = to_tensor_seq(gt_va[:, None])
    results = {}
    for t_in in (1, 3, 5):
        xcva = to_tensor_seq(center(noisy_va5, t_in))
        net, secs = train(t_in, clean_tr, gt_tr, xcva, gtva_t, np.random.default_rng(SEED + 1), dev)
        net.eval()
        with torch.no_grad():
            out = net(xcva.to(dev)).clamp(0, 1).cpu().numpy()[:, 0]
        q = np.mean([psnr(out[i], gt_va[i]) for i in range(NVAL)])
        sm = np.mean([ssim(out[i], gt_va[i]) for i in range(NVAL)])
        ms = ms_per_frame(net, t_in, dev)
        tag = f"T={t_in}" + (" (single)" if t_in == 1 else "")
        print(f"{tag:<14}{net.n_params():>8,}{q:>8.2f}{sm:>8.3f}{ms:>10.1f}  ({secs:.0f}s)")
        results[t_in] = q
        torch.save(net.state_dict(), os.path.join(os.path.dirname(__file__), "..", "models", f"tdncnn_T{t_in}.pt"))

    print("-" * 48)
    g3 = results[3] - results[1]; g5 = results[5] - results[1]
    print(f"temporal gain over single-frame: T=3 {g3:+.2f} dB, T=5 {g5:+.2f} dB (same capacity)")
    print("note: this measures per-frame QUALITY gain; temporal STABILITY (warping error) is a separate exp.")


if __name__ == "__main__":
    main()
