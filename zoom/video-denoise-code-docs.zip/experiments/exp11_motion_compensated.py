"""exp11 - optical-flow motion compensation vs the guard, measured properly.

exp10's trail metric was blind to the real ghost. The ghost-sensitive metric is
fg-PSNR: fidelity INSIDE the moving object (ghosting = object blended with
misaligned history -> mottling -> fg-PSNR drops). Ground truth known (synthetic).

Compare on a TEXTURED moving object over static bg:
  - noisy (input)
  - guard   : motion-adaptive + anti-ghost guard (falls to spatial on motion -> noisy object)
  - MCTF    : motion-compensated (aligns history to the object -> real temporal denoise, no ghost)

    python experiments/exp11_motion_compensated.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from noise_models import add_realistic_noise_seq, C270_MEASURED  # noqa: E402
from classical_denoise import (  # noqa: E402
    MotionAdaptiveRecursiveDenoiser, MotionCompensatedDenoiser, run_stream,
)

H, W, T = 220, 340, 40
DX, DY = 7, 2            # px/frame — moderate (flow-trackable) motion
OW, OH = 90, 120
OUT = os.path.join(os.path.dirname(__file__), "..", "samples", "mctf")
os.makedirs(OUT, exist_ok=True)


def tex(h, w, lo, hi, rng, s):
    n = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), s)
    n = (n - n.min()) / (np.ptp(n) + 1e-6)
    return lo + (hi - lo) * n


def scene(rng):
    bg = tex(H, W, 0.60, 0.82, rng, s=4.0)                  # static bright bg
    obj = tex(OH, OW, 0.30, 0.62, rng, s=1.5)               # TEXTURED object (fg-PSNR meaningful)
    frames = np.empty((T, H, W), np.float32)
    fg = np.zeros((T, H, W), bool)
    for t in range(T):
        f = bg.copy()
        x0, y0 = 12 + DX * t, 40 + DY * t
        if x0 + OW <= W and y0 + OH <= H:
            f[y0:y0 + OH, x0:x0 + OW] = obj
            fg[t, y0:y0 + OH, x0:x0 + OW] = True
        frames[t] = np.clip(f, 0, 1)
    never = ~fg.any(axis=0)
    return frames, fg, never


def psnr_mask(out, clean, mask3d):
    e = out[mask3d] - clean[mask3d]
    mse = float(np.mean(e ** 2))
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)


def main():
    rng = np.random.default_rng(7)
    clean, fg, never = scene(rng)
    noisy = add_realistic_noise_seq(clean, rng, **C270_MEASURED)

    methods = {
        "noisy (input)": lambda: noisy,
        "guard (motion-adaptive+guard)": lambda: run_stream(
            MotionAdaptiveRecursiveDenoiser(alpha_max=0.95, sigma_motion=0.06,
                                            motion_dilate=8, motion_decay=0.6), noisy),
        "MCTF (optical-flow)": lambda: run_stream(
            MotionCompensatedDenoiser(alpha_max=0.9, occ_sigma=0.06, flow_scale=0.5), noisy),
    }
    print(f"textured object moving {DX},{DY} px/frame over static bg")
    print(f"{'method':<32}{'fg-PSNR(obj)':>13}{'static-flick':>14}")
    print("  (fg-PSNR: object fidelity, ghost drops it ↑=better; flick: bg denoise ↓=better)")
    print("-" * 60)
    outs = {}
    for name, fn in methods.items():
        out = fn()
        outs[name] = out
        fgp = psnr_mask(out, clean, fg)
        flick = float(out[:, never].std(axis=0).mean())
        print(f"{name:<32}{fgp:>13.2f}{flick*1e3:>12.2f}e-3")
    print("-" * 60)

    # crop at a mid frame: clean | guard | MCTF (object region)
    t = T // 2
    def u8(x): return np.clip(x * 255 + 0.5, 0, 255).astype(np.uint8)
    row = np.hstack([u8(clean[t]), u8(outs["guard (motion-adaptive+guard)"][t]),
                     u8(outs["MCTF (optical-flow)"][t])])
    cv2.imwrite(os.path.join(OUT, "clean_guard_mctf.png"),
                cv2.resize(row, (row.shape[1] * 2, row.shape[0] * 2), interpolation=cv2.INTER_NEAREST))
    print(f"crop (clean | guard | MCTF) -> {os.path.join(OUT, 'clean_guard_mctf.png')}")
    print("expect MCTF fg-PSNR > guard (it temporally denoises the moving object by")
    print("aligning history, instead of falling back to a noisier spatial-only estimate).")


if __name__ == "__main__":
    main()
