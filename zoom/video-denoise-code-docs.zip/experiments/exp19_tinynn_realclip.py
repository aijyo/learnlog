"""exp19 - does the SYNTHETIC-trained tiny NN generalize to REAL webcam footage?

The reliable feedback loop in this project has always been the user's real clips, not
synthetic repro. exp18 found a 745-param net beats bilateral on synthetic eval at 6.3ms
CPU. Here we run it on a real low-light clip and eyeball generalization + measure noise
reduction on a flat region (no GT, so use spatial std in a hand-picked flat patch and
temporal std on a near-static region as proxies).

    python experiments/exp19_tinynn_realclip.py <clip.mp4>
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2   # import + fully consume the video BEFORE torch (avoids ffmpeg/OpenMP clash)

CLIP = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\NCC Technology\Desktop\denoise_clip_143109.mp4"
OUT = os.path.join(os.path.dirname(__file__), "..", "samples", "zlt_recon")
os.makedirs(OUT, exist_ok=True)

cap = cv2.VideoCapture(CLIP)
frames = []
while len(frames) < 120:
    ok, f = cap.read()
    if not ok:
        break
    frames.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0)
cap.release()
frames = np.array(frames)
print(f"read {len(frames)} frames, shape {frames.shape[1:]}")

import torch  # noqa: E402
torch.set_num_threads(1)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_denoise import DnCNN, to_tensor  # noqa: E402
from classical_denoise import spatial_bilateral  # noqa: E402

net = DnCNN(feat=8, depth=3, use_bn=True)
net.load_state_dict(torch.load(os.path.join(os.path.dirname(__file__), "..", "models", "dncnn_tiny.pt"),
                               map_location="cpu"))
net.eval()

out = np.empty_like(frames)
with torch.no_grad():
    for i in range(len(frames)):
        out[i] = net(to_tensor(frames[i:i + 1])).clamp(0, 1).numpy()[0, 0]

# bilateral reference on same frames
bil = np.stack([spatial_bilateral(frames[i]) for i in range(len(frames))])

u8 = lambda z: (np.clip(z, 0, 1) * 255).astype(np.uint8)
for t in [10, min(79, len(frames) - 1)]:
    trip = np.hstack([u8(frames[t]), u8(bil[t]), u8(out[t])])
    trip = cv2.resize(trip, None, fx=1.3, fy=1.3, interpolation=cv2.INTER_NEAREST)
    cv2.putText(trip, "noisy | bilateral | tinyNN", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, 255, 1)
    cv2.imwrite(os.path.join(OUT, f"tinynn_f{t}.png"), trip)

H, W = frames.shape[1:]
# flat patch (cheek/wall) — pick a low-gradient region automatically from frame 10
g = frames[10]
gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3); gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
grad = cv2.boxFilter(np.abs(gx) + np.abs(gy), -1, (17, 17))
y0, x0 = np.unravel_index(np.argmin(grad[20:H - 20, 20:W - 20]), grad[20:H - 20, 20:W - 20].shape)
y0 += 20; x0 += 20
sl = (slice(y0 - 8, y0 + 8), slice(x0 - 8, x0 + 8))


def spatial_std(seq):
    return float(np.mean([seq[i][sl].std() for i in range(len(seq))]))


# temporal std over a near-static window (first 20 frames assumed low-motion at clip start)
def temporal_std(seq):
    return float(seq[:20].std(axis=0).mean())


print(f"flat patch @({y0},{x0})  16x16")
print(f"{'metric':<18}{'noisy':>10}{'bilateral':>12}{'tinyNN':>10}")
print(f"{'spatial std':<18}{spatial_std(frames):>10.4f}{spatial_std(bil):>12.4f}{spatial_std(out):>10.4f}")
print(f"{'temporal std':<18}{temporal_std(frames):>10.4f}{temporal_std(bil):>12.4f}{temporal_std(out):>10.4f}")
print(f"montages -> samples/zlt_recon/tinynn_f10.png, tinynn_f{min(79, len(frames)-1)}.png")
