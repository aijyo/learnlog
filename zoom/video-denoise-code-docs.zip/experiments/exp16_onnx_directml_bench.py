"""exp16 - export DnCNN to ONNX and benchmark on the GPU (DirectML) vs CPU.

Answers the load-bearing question from P2: the NN wins on quality but was 206ms on
CPU (~5fps). Can it hit real-time on THIS box's GPU (UHD770 / RX550) via ONNX Runtime
+ DirectML? Exports the trained model, checks numerical parity vs PyTorch, then times
each provider/resolution.

    python experiments/exp16_onnx_directml_bench.py
"""
from __future__ import annotations
import os, sys, time
import numpy as np
import torch
import onnxruntime as ort

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_denoise import DnCNN  # noqa: E402

MODELS = os.path.join(os.path.dirname(__file__), "..", "models")
ONNX_PATH = os.path.join(MODELS, "dncnn_pg.onnx")
RES = [(240, 320), (480, 640), (720, 1280)]     # (H,W)


def export():
    net = DnCNN(feat=48, depth=7, use_bn=True)
    net.load_state_dict(torch.load(os.path.join(MODELS, "dncnn_pg.pt"), map_location="cpu"))
    net.eval()
    dummy = torch.zeros(1, 1, 480, 640)
    torch.onnx.export(
        net, dummy, ONNX_PATH, opset_version=17,
        input_names=["input"], output_names=["output"],
        dynamic_axes={"input": {0: "b", 2: "h", 3: "w"}, "output": {0: "b", 2: "h", 3: "w"}})
    print(f"exported -> {ONNX_PATH}  ({os.path.getsize(ONNX_PATH)/1024:.0f} KB)")
    return net


def parity(net):
    x = np.random.RandomState(0).rand(1, 1, 128, 128).astype(np.float32)
    with torch.no_grad():
        ty = net(torch.from_numpy(x)).numpy()
    sess = ort.InferenceSession(ONNX_PATH, providers=["CPUExecutionProvider"])
    oy = sess.run(None, {"input": x})[0]
    d = float(np.max(np.abs(ty - oy)))
    print(f"parity torch vs onnx(CPU): max|diff| = {d:.2e}  ({'OK' if d < 1e-4 else 'MISMATCH'})")


def make_session(provider):
    so = ort.SessionOptions()
    so.enable_mem_pattern = False                      # recommended for DML
    so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    return ort.InferenceSession(ONNX_PATH, sess_options=so, providers=[provider])


def bench(provider, label):
    try:
        sess = make_session(provider)
    except Exception as e:
        print(f"  {label:<26} unavailable: {str(e)[:60]}")
        return
    print(f"  {label:<26}", end="", flush=True)
    for (h, w) in RES:
        x = np.random.rand(1, 1, h, w).astype(np.float32)
        for _ in range(5):                              # warmup (DML compiles shaders)
            sess.run(None, {"input": x})
        n = 20
        t = time.time()
        for _ in range(n):
            sess.run(None, {"input": x})
        ms = (time.time() - t) * 1000 / n
        print(f"  {w}x{h}: {ms:6.1f}ms/{1000/ms:4.0f}fps", end="")
    print()


def main():
    net = export()
    parity(net)
    print(f"\nbenchmark (ort {ort.__version__}); resolutions {['%dx%d'%(w,h) for h,w in RES]}:")
    bench("CPUExecutionProvider", "CPU")
    bench(("DmlExecutionProvider", {"device_id": 0}), "DirectML adapter 0")
    bench(("DmlExecutionProvider", {"device_id": 1}), "DirectML adapter 1")
    print("\nreal-time bar ~30fps (<33ms). Compare to classical bilateral ~3.5ms/frame.")


if __name__ == "__main__":
    main()
