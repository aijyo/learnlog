"""exp15 - small NN training + head-to-head vs the classical single-frame baseline.

Feedback loop proven (exp14). Now train the DnCNN on a small synthetic dataset and
compare, on a held-out eval set, against the classical single-frame denoiser
(bilateral). Report BOTH quality (PSNR/SSIM) AND per-frame compute — the NN only
"wins" if it beats the classical line within a comparable time budget (CLAUDE.md).

CPU-only here (no CUDA on this box); NN per-frame time is an upper bound — real
deployment would use the GPU via DirectML/ONNX.

    python experiments/exp15_nn_train_vs_classical.py
"""
from __future__ import annotations
import os, sys, time
import numpy as np
import cv2
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_denoise import (  # noqa: E402
    make_clean_patches, add_pg_noise, to_tensor, to_numpy, DnCNN, psnr_t,
)
from classical_denoise import spatial_bilateral  # noqa: E402

SEED = 20260722
PEAK, READ = 30.0, 0.03
NTR, NVAL, SIZE = 512, 64, 64
EPOCHS, BS, LR = 24, 32, 1e-3
MODELS = os.path.join(os.path.dirname(__file__), "..", "models")
os.makedirs(MODELS, exist_ok=True)


def psnr(a, b):
    mse = float(np.mean((np.clip(a, 0, 1) - np.clip(b, 0, 1)) ** 2))
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)


def ssim(a, b):
    C1, C2 = 0.01 ** 2, 0.03 ** 2
    a, b = a.astype(np.float32), b.astype(np.float32)
    ma = cv2.GaussianBlur(a, (11, 11), 1.5); mb = cv2.GaussianBlur(b, (11, 11), 1.5)
    va = cv2.GaussianBlur(a * a, (11, 11), 1.5) - ma * ma
    vb = cv2.GaussianBlur(b * b, (11, 11), 1.5) - mb * mb
    vab = cv2.GaussianBlur(a * b, (11, 11), 1.5) - ma * mb
    s = ((2 * ma * mb + C1) * (2 * vab + C2)) / ((ma * ma + mb * mb + C1) * (va + vb + C2) + 1e-12)
    return float(s.mean())


def main():
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    torch.set_num_threads(os.cpu_count() or 4)

    clean_tr = make_clean_patches(NTR, SIZE, rng)
    clean_va = make_clean_patches(NVAL, SIZE, rng)
    noisy_va = add_pg_noise(clean_va, rng, PEAK, READ)
    xcva, xnva = to_tensor(clean_va).to(dev), to_tensor(noisy_va).to(dev)

    net = DnCNN(feat=48, depth=7, use_bn=True).to(dev)
    opt = torch.optim.Adam(net.parameters(), lr=LR)
    lossf = torch.nn.MSELoss()
    print(f"device={dev} params={net.n_params():,} train={NTR} val={NVAL} "
          f"noise=PG(peak={PEAK},read={READ})")
    print(f"val noisy PSNR = {psnr(noisy_va, clean_va):.2f} dB")

    t0 = time.time()
    for ep in range(1, EPOCHS + 1):
        net.train()
        idx = rng.permutation(NTR)
        # fresh noise each epoch (augmentation) on the fixed clean patches
        noisy_tr = add_pg_noise(clean_tr, rng, PEAK, READ)
        for i in range(0, NTR, BS):
            b = idx[i:i + BS]
            xc = to_tensor(clean_tr[b]).to(dev)
            xn = to_tensor(noisy_tr[b]).to(dev)
            opt.zero_grad(); loss = lossf(net(xn), xc); loss.backward(); opt.step()
        if ep % 4 == 0 or ep == 1:
            net.eval()
            with torch.no_grad():
                vp = psnr_t(net(xnva), xcva)
            print(f"  epoch {ep:>2}  val-PSNR {vp:.2f} dB")
    print(f"trained in {time.time()-t0:.0f}s")
    torch.save(net.state_dict(), os.path.join(MODELS, "dncnn_pg.pt"))

    # ---- head-to-head on a fresh held-out eval set ----
    clean_ev = make_clean_patches(64, SIZE, rng)
    noisy_ev = add_pg_noise(clean_ev, rng, PEAK, READ)
    net.eval()
    with torch.no_grad():
        nn_out = to_numpy(net(to_tensor(noisy_ev).to(dev)))
    bil = np.stack([spatial_bilateral(noisy_ev[i]) for i in range(len(noisy_ev))])

    def agg(fn, out):
        return np.mean([fn(out[i], clean_ev[i]) for i in range(len(out))])

    print("\nquality on held-out eval (64 patches):")
    print(f"{'method':<20}{'PSNR':>8}{'SSIM':>9}")
    print("-" * 37)
    for name, out in [("noisy", noisy_ev), ("classical bilateral", bil), ("DnCNN (ours)", nn_out)]:
        print(f"{name:<20}{agg(psnr, out):>8.2f}{agg(ssim, out):>9.4f}")

    # ---- per-frame compute at 480x640 (the budget test) ----
    frame = np.clip(add_pg_noise(0.5 + 0.2 * cv2.GaussianBlur(
        rng.standard_normal((480, 640)).astype(np.float32), (0, 0), 3.0), rng, PEAK, READ), 0, 1)
    ft = to_tensor(frame).to(dev)
    for _ in range(2):  # warmup
        with torch.no_grad(): net(ft)
    t = time.time()
    with torch.no_grad():
        for _ in range(5): net(ft)
    nn_ms = (time.time() - t) * 1000 / 5
    t = time.time()
    for _ in range(5): spatial_bilateral(frame)
    bil_ms = (time.time() - t) * 1000 / 5
    print("\nper-frame compute @ 480x640 (CPU; NN would use GPU/ONNX in deploy):")
    print(f"  classical bilateral : {bil_ms:6.1f} ms")
    print(f"  DnCNN (ours)        : {nn_ms:6.1f} ms")
    print("\nverdict: NN must beat classical on PSNR/SSIM AND be affordable per-frame.")


if __name__ == "__main__":
    main()
