"""exp14 - TRAINING FEEDBACK LOOP proof: micro-overfit (CLAUDE.md discipline).

Before any real training, prove the whole loop (data pipeline, model, loss, backprop,
metrics) is wired correctly by OVERFITTING a tiny fixed batch: train loss must fall
to ~0 and the reconstruction PSNR must shoot up. If it can't overfit 8 patches, the
loop is broken — fix that before scaling.

    python experiments/exp14_nn_overfit.py
"""
from __future__ import annotations
import os, sys, time
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_denoise import (  # noqa: E402
    make_clean_patches, add_pg_noise, to_tensor, DnCNN, psnr_t,
)

SEED = 20260722
N, SIZE = 8, 64          # tiny fixed batch
STEPS = 2000


def main():
    torch.manual_seed(SEED)
    rng = np.random.default_rng(SEED)
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    clean = make_clean_patches(N, SIZE, rng)
    noisy = add_pg_noise(clean, rng, peak=30.0, read_sigma=0.03)   # heavy-ish noise
    xc, xn = to_tensor(clean).to(dev), to_tensor(noisy).to(dev)

    net = DnCNN(feat=48, depth=7, use_bn=True).to(dev).train()
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    lossf = torch.nn.MSELoss()

    print(f"device={dev}  params={net.n_params():,}  batch={N}x{SIZE}x{SIZE}")
    print(f"input noisy PSNR = {psnr_t(xn, xc):.2f} dB")
    print(f"{'step':>6}{'train-loss':>14}{'recon-PSNR':>12}")
    print("-" * 34)
    t0 = time.time()
    for step in range(STEPS + 1):
        opt.zero_grad()
        out = net(xn)
        loss = lossf(out, xc)
        loss.backward()
        opt.step()
        if step % 50 == 0:
            print(f"{step:>6}{loss.item():>14.6e}{psnr_t(out, xc):>12.2f}")
    secs = time.time() - t0

    final = psnr_t(net(xn), xc)
    print("-" * 34)
    print(f"{STEPS} steps in {secs:.1f}s on {dev}")
    ok = final > 40.0
    print(f"OVERFIT {'PASS' if ok else 'FAIL'}: recon PSNR {final:.1f} dB "
          f"(input {psnr_t(xn, xc):.1f} dB) -> loop {'is wired correctly' if ok else 'BROKEN, fix before scaling'}")


if __name__ == "__main__":
    main()
