"""exp21 - train a BLIND-noise tiny net (robust across noise levels) + export ONNX.

exp18's models trained at a single noise level (peak=30). A live webcam feed varies
from near-clean to heavy low-light noise, so we retrain BLIND: random noise level per
image, including a near-clean band so the net learns to leave clean input alone instead
of over-smoothing. Then export ONNX (dynamic H/W) and bench ONNX Runtime CPU — the path
to running it inside the WPF demo.

    python experiments/exp21_blind_train_onnx.py
"""
from __future__ import annotations
import os, sys, time
import numpy as np
import cv2
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_denoise import make_clean_patches, to_tensor, DnCNN, psnr_t  # noqa: E402
from classical_denoise import spatial_bilateral  # noqa: E402

SEED = 20260724
NTR, SIZE, EPOCHS, BS, LR = 1536, 64, 26, 32, 1e-3
MODELS = os.path.join(os.path.dirname(__file__), "..", "models")
os.makedirs(MODELS, exist_ok=True)
# blind noise band: peak (higher=cleaner) from very-clean down to heavy low-light
PEAK_LO, PEAK_HI, READ_LO, READ_HI = 12.0, 400.0, 0.004, 0.045


def add_blind_noise(clean, rng):
    """Per-image Poisson-Gaussian with a random level, log-uniform in peak."""
    out = np.empty_like(clean)
    for i in range(len(clean)):
        peak = float(np.exp(rng.uniform(np.log(PEAK_LO), np.log(PEAK_HI))))
        read = float(rng.uniform(READ_LO, READ_HI))
        c = np.clip(clean[i], 0, 1)
        shot = rng.poisson(c * peak) / peak
        out[i] = np.clip(shot + rng.normal(0, read, c.shape), 0, 1).astype(np.float32)
    return out


def add_pg_fixed(clean, rng, peak, read):
    out = np.empty_like(clean)
    for i in range(len(clean)):
        c = np.clip(clean[i], 0, 1)
        out[i] = np.clip(rng.poisson(c * peak) / peak + rng.normal(0, read, c.shape), 0, 1).astype(np.float32)
    return out


def train(feat, depth, clean_tr, rng, dev):
    torch.manual_seed(SEED)
    net = DnCNN(feat=feat, depth=depth, use_bn=True).to(dev)
    opt = torch.optim.Adam(net.parameters(), lr=LR)
    lossf = torch.nn.MSELoss()
    t0 = time.time()
    for ep in range(EPOCHS):
        net.train()
        idx = rng.permutation(NTR)
        noisy = add_blind_noise(clean_tr, rng)
        for i in range(0, NTR, BS):
            b = idx[i:i + BS]
            opt.zero_grad()
            lossf(net(to_tensor(noisy[b]).to(dev)), to_tensor(clean_tr[b]).to(dev)).backward()
            opt.step()
    return net, time.time() - t0


def psnr(a, b):
    m = float(np.mean((np.clip(a, 0, 1) - np.clip(b, 0, 1)) ** 2))
    return 99.0 if m < 1e-12 else 10.0 * np.log10(1.0 / m)


def load_real_gt(n=16):
    clip = r"C:\Users\NCC Technology\Desktop\denoise_clip_143109.mp4"
    cap = cv2.VideoCapture(clip); fr = []
    while len(fr) < n * 3:
        ok, f = cap.read()
        if not ok:
            break
        fr.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0)
    cap.release()
    return np.array(fr[::3][:n]) if fr else None


def main():
    dev = "cpu"
    torch.set_num_threads(os.cpu_count() or 4)
    rng = np.random.default_rng(SEED)
    clean_tr = make_clean_patches(NTR, SIZE, rng)

    variants = {}
    for name, feat, depth in [("tiny_blind", 8, 3), ("small_blind", 16, 4)]:
        net, secs = train(feat, depth, clean_tr, np.random.default_rng(SEED + 1), dev)
        net.eval()
        torch.save(net.state_dict(), os.path.join(MODELS, f"dncnn_{name}.pt"))
        variants[name] = (net, feat, depth)
        print(f"trained {name}: {net.n_params():,} params, {secs:.0f}s")

    # eval on REAL content across noise levels (incl. near-clean)
    gt = load_real_gt()
    ev_rng = np.random.default_rng(11)
    print(f"\nREAL content, PSNR vs pseudo-GT at several noise levels:")
    print(f"{'level':<14}{'noisy':>8}{'bilat':>8}{'tiny_b':>8}{'small_b':>9}")
    for tag, peak, read in [("near-clean", 500, 0.006), ("light p=80", 80, 0.02),
                            ("med p=30", 30, 0.03), ("heavy p=15", 15, 0.04)]:
        noisy = add_pg_fixed(gt, ev_rng, peak, read)
        bil = np.stack([spatial_bilateral(noisy[i]) for i in range(len(gt))])
        row = f"{tag:<14}{np.mean([psnr(noisy[i],gt[i]) for i in range(len(gt))]):>8.2f}" \
              f"{np.mean([psnr(bil[i],gt[i]) for i in range(len(gt))]):>8.2f}"
        for name in ("tiny_blind", "small_blind"):
            net = variants[name][0]
            with torch.no_grad():
                out = np.stack([net(to_tensor(noisy[i:i+1])).clamp(0,1).numpy()[0,0] for i in range(len(gt))])
            row += f"{np.mean([psnr(out[i],gt[i]) for i in range(len(gt))]):>{8 if name=='tiny_blind' else 9}.2f}"
        print(row)

    # export ONNX (dynamic H/W) + bench onnxruntime CPU
    print()
    for name in ("tiny_blind", "small_blind"):
        net = variants[name][0]
        dummy = torch.rand(1, 1, 64, 64)
        onnx_path = os.path.join(MODELS, f"dncnn_{name}.onnx")
        torch.onnx.export(net, dummy, onnx_path, input_names=["x"], output_names=["y"],
                          dynamic_axes={"x": {2: "h", 3: "w"}, "y": {2: "h", 3: "w"}}, opset_version=13)
        try:
            import onnxruntime as ort
            so = ort.SessionOptions(); so.intra_op_num_threads = os.cpu_count() or 4
            sess = ort.InferenceSession(onnx_path, so, providers=["CPUExecutionProvider"])
            fr = np.random.rand(1, 1, 480, 640).astype(np.float32)
            for _ in range(2): sess.run(None, {"x": fr})
            t = time.time()
            for _ in range(10): sess.run(None, {"x": fr})
            ms = (time.time() - t) * 1000 / 10
            # parity with torch
            with torch.no_grad():
                tp = net(torch.from_numpy(fr)).numpy()
            op = sess.run(None, {"x": fr})[0]
            print(f"{name}: ONNX ok, CPU {ms:.1f} ms/frame @480x640, parity max|d|={np.abs(tp-op).max():.2e}")
        except Exception as e:
            print(f"{name}: ONNX exported to {onnx_path} (onnxruntime bench skipped: {e})")


if __name__ == "__main__":
    main()
