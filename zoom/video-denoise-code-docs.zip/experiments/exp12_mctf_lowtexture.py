"""exp12 - MCTF's failure on LOW-TEXTURE scenes ("water streak") and the fix.

Report: MCTF looked WORSE than the guard on a mostly-white ceiling, with a moving
"water streak". Cause: optical flow is garbage in low-texture regions -> history is
mis-warped -> in a smooth region the mis-warp still matches (low residual) so the
occlusion gate trusts it -> warp drift accumulates into a streak.

Reproduce on a SMOOTH bg + moving object; the streak shows as high static-flick on
the never-touched bg (it should be near 0). Test the forward-backward consistency
gate (fb_check), which distrusts unreliable flow -> falls back to spatial.

    python experiments/exp12_mctf_lowtexture.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from noise_models import add_realistic_noise_seq, C270_MEASURED  # noqa: E402
from classical_denoise import (  # noqa: E402
    MotionAdaptiveRecursiveDenoiser, MotionCompensatedDenoiser, run_stream,
)

H, W, T = 220, 340, 40
DX, DY = 7, 2
OW, OH = 90, 120
OUT = os.path.join(os.path.dirname(__file__), "..", "samples", "mctf")
os.makedirs(OUT, exist_ok=True)


def tex(h, w, lo, hi, rng, s):
    n = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), s)
    n = (n - n.min()) / (np.ptp(n) + 1e-6)
    return lo + (hi - lo) * n


def scene(rng):
    bg = tex(H, W, 0.70, 0.80, rng, s=14.0)             # VERY smooth ceiling-like bg
    obj = tex(OH, OW, 0.30, 0.62, rng, s=1.5)           # textured moving object
    frames = np.empty((T, H, W), np.float32)
    fg = np.zeros((T, H, W), bool)
    for t in range(T):
        f = bg.copy()
        x0, y0 = 12 + DX * t, 40 + DY * t
        if x0 + OW <= W and y0 + OH <= H:
            f[y0:y0 + OH, x0:x0 + OW] = obj
            fg[t, y0:y0 + OH, x0:x0 + OW] = True
        frames[t] = np.clip(f, 0, 1)
    return frames, fg, ~fg.any(axis=0)


def psnr_mask(out, clean, m3):
    e = out[m3] - clean[m3]; mse = float(np.mean(e ** 2))
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)


def main():
    rng = np.random.default_rng(7)
    clean, fg, never = scene(rng)
    noisy = add_realistic_noise_seq(clean, rng, **C270_MEASURED)

    methods = {
        "guard": lambda: run_stream(MotionAdaptiveRecursiveDenoiser(
            alpha_max=0.95, sigma_motion=0.06, motion_dilate=8, motion_decay=0.6), noisy),
        "MCTF (no gate)": lambda: run_stream(
            MotionCompensatedDenoiser(alpha_max=0.9, occ_sigma=0.06, flow_scale=0.5), noisy),
        "MCTF + FB-consistency gate": lambda: run_stream(
            MotionCompensatedDenoiser(alpha_max=0.9, occ_sigma=0.06, flow_scale=0.5,
                                      fb_check=True, fbc_sigma=1.0), noisy),
    }
    print("SMOOTH (ceiling-like) bg + textured moving object")
    print(f"{'method':<30}{'fg-PSNR(obj)':>13}{'static-flick':>14}  (bg streak: flick↑=bad)")
    print("-" * 62)
    outs = {}
    for name, fn in methods.items():
        out = fn(); outs[name] = out
        print(f"{name:<30}{psnr_mask(out, clean, fg):>13.2f}"
              f"{float(out[:, never].std(axis=0).mean())*1e3:>12.2f}e-3")
    # also the bg streak vs clean (bias), not just temporal std:
    print("-" * 62)
    for name, out in outs.items():
        bias = float(np.sqrt(np.mean((out[:, never] - clean[:, never]) ** 2)))
        print(f"  {name:<34} bg-RMSE-vs-clean = {bias*1e3:.2f}e-3")

    t = T // 2
    def u8(x): return np.clip(x * 255 + 0.5, 0, 255).astype(np.uint8)
    row = np.hstack([u8(clean[t]), u8(outs["MCTF (no gate)"][t]),
                     u8(outs["MCTF + FB-consistency gate"][t])])
    cv2.imwrite(os.path.join(OUT, "lowtex_clean_mctf_gated.png"),
                cv2.resize(row, (row.shape[1] * 2, row.shape[0] * 2), interpolation=cv2.INTER_NEAREST))
    print(f"\ncrop (clean | MCTF-no-gate | MCTF-gated) -> samples/mctf/lowtex_clean_mctf_gated.png")


if __name__ == "__main__":
    main()
