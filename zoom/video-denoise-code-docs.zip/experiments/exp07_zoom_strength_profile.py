"""exp07 - wire Zoom's per-luma denoise-STRENGTH curve into the denoiser.

exp06 showed Zoom's LUT is a per-luma strength profile (shadow-weighted), while
real noise is shot-weighted (more noise in highlights). So there are two rival
ideas for WHERE to spend a fixed budget of denoising strength:
  - noise-matched: spend it where the noise is (highlights)  -- SNR-optimal
  - zoom:          spend it in the shadows                    -- Zoom's perceptual choice
This A/Bs uniform vs noise-matched vs zoom profiles, all mean-normalized to the
SAME average strength, so only the luma distribution differs.

    python experiments/exp07_zoom_strength_profile.py

Part A: synthetic (C270_MEASURED noise, has GT) -> shadow/highlight PSNR.
Part B: real C270 clip (no GT) -> shadow/highlight flicker + montage.
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))

from exp01_classical_baseline import make_clean_sequence, SEED  # noqa: E402
from noise_models import add_realistic_noise_seq, C270_MEASURED  # noqa: E402
from classical_denoise import (  # noqa: E402
    LumaProfileRecursiveDenoiser, estimate_nlf_temporal, noise_sigma_map, run_stream,
)
from zoom_noise import zoom_strength01  # noqa: E402

SIGMA_MEAN = 0.07


def profiles(nlf):
    a, b = nlf
    return {
        "uniform": lambda L: np.ones_like(L),
        "noise-matched": lambda L: noise_sigma_map(L, a, b),   # spend where noise is (highlights)
        "zoom-strength": lambda L: zoom_strength01(L),          # spend in shadows (Zoom)
    }


def psnr_region(out, clean, mask):
    e = out[:, mask] - clean[:, mask]
    mse = float(np.mean(e ** 2))
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)


def _dark_bright_scene(rng, H=240, W=320, T=40):
    """Dedicated scene with a genuine DARK band (top) and BRIGHT band (bottom), both
    static & textured, so shadow/highlight PSNR is actually testable (the shared
    make_clean_sequence has no real shadows). Small moving square keeps it a video."""
    def tex(h, w, lo, hi):
        n = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), 3.0)
        n = (n - n.min()) / (np.ptp(n) + 1e-6)
        return lo + (hi - lo) * n
    bg = np.vstack([tex(H // 2, W, 0.05, 0.18),      # dark band
                    tex(H - H // 2, W, 0.42, 0.68)])  # bright band
    frames = np.empty((T, H, W), np.float32)
    for t in range(T):
        f = bg.copy()
        sx = 30 + 5 * t
        f[H // 2 - 20:H // 2 + 20, sx:sx + 30] = 0.55  # square crossing the boundary
        frames[t] = np.clip(f, 0, 1)
    return frames


def part_A_synth():
    print("Part A  synthetic dark+bright scene (C270_MEASURED noise, GT): PSNR by luma region")
    rng = np.random.default_rng(SEED)
    clean = _dark_bright_scene(rng)
    r = np.random.default_rng(SEED + 7)
    noisy = add_realistic_noise_seq(clean, r, **C270_MEASURED)
    nlf = estimate_nlf_temporal(noisy)

    meanL = clean.mean(axis=0)
    shadow = meanL < 0.25
    high = meanL > 0.45
    print(f"    regions: shadow(luma<0.25)={shadow.mean()*100:.0f}%  "
          f"highlight(luma>0.45)={high.mean()*100:.0f}%  (noise is heavier in highlights)")
    print(f"{'profile':<16}{'shadow PSNR':>13}{'highlight PSNR':>16}{'overall PSNR':>14}")
    print("-" * 59)
    for name, fn in profiles(nlf).items():
        out = run_stream(LumaProfileRecursiveDenoiser(fn, sigma_mean=SIGMA_MEAN), noisy)
        ps = psnr_region(out, clean, shadow)
        ph = psnr_region(out, clean, high)
        po = np.mean([psnr_region(out, clean, np.ones_like(shadow))])
        print(f"{name:<16}{ps:>13.2f}{ph:>16.2f}{po:>14.2f}")
    print("-" * 59)
    print("expect: noise-matched wins HIGHLIGHTS (noise lives there); zoom wins SHADOWS")
    print("(strength spent there). Overall PSNR favors matching noise -- but shadow gain")
    print("is where the eye is most sensitive, which PSNR under-weights.\n")


def part_B_real(clip):
    print("Part B  real C270 clip (no GT): flicker by luma region + montage")
    cap = cv2.VideoCapture(clip)
    fr = []
    while len(fr) < 90:
        ok, f = cap.read()
        if not ok:
            break
        fr.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0)
    cap.release()
    frames = np.asarray(fr)
    nlf = estimate_nlf_temporal(frames)

    meanL = frames.mean(axis=0)
    # low-motion mask (static) via blurred temporal std
    bl = np.stack([cv2.GaussianBlur(f, (0, 0), 2.0) for f in frames])
    static = bl.std(axis=0) <= np.percentile(bl.std(axis=0), 40)
    shadow = static & (meanL < 0.15)
    high = static & (meanL > 0.30)

    def flick(seq, mask):
        return float(seq.std(axis=0)[mask].mean())

    print(f"    static shadow(luma<0.15)={shadow.mean()*100:.0f}%  "
          f"static highlight(luma>0.30)={high.mean()*100:.0f}%")
    print(f"{'profile':<16}{'shadow flick':>14}{'highlight flick':>17}{'overall flick':>15}")
    print("-" * 62)
    outs = {}
    for name, fn in profiles(nlf).items():
        out = run_stream(LumaProfileRecursiveDenoiser(fn, sigma_mean=SIGMA_MEAN), frames)
        outs[name] = out
        fs = flick(out, shadow) if shadow.any() else float("nan")
        fh = flick(out, high) if high.any() else float("nan")
        fo = flick(out, static)
        print(f"{name:<16}{fs*1e3:>11.2f}e-3{fh*1e3:>14.2f}e-3{fo*1e3:>12.2f}e-3")
    fs = flick(frames, shadow); fh = flick(frames, high); fo = flick(frames, static)
    print(f"{'(noisy input)':<16}{fs*1e3:>11.2f}e-3{fh*1e3:>14.2f}e-3{fo*1e3:>12.2f}e-3")
    print("-" * 62)

    # montage: noisy | uniform | zoom (a few frames)
    out_dir = os.path.join(os.path.dirname(__file__), "..", "samples", "denoise_out_profiles")
    os.makedirs(out_dir, exist_ok=True)
    idxs = np.linspace(0, len(frames) - 1, 3).astype(int)
    rows = []
    for i in idxs:
        row = np.hstack([frames[i], outs["uniform"][i], outs["zoom-strength"][i]])
        rows.append((np.clip(row, 0, 1) * 255).astype(np.uint8))
    cv2.imwrite(os.path.join(out_dir, "noisy_uniform_zoom.png"), np.vstack(rows))
    print(f"montage (noisy | uniform | zoom-strength) -> {out_dir}\\noisy_uniform_zoom.png")


def main():
    part_A_synth()
    clip = os.path.join(os.path.dirname(__file__), "..", "samples", "lowlight_exp8.mp4")
    if os.path.exists(clip):
        part_B_real(clip)
    else:
        print("(real clip not found; skipping Part B)")


if __name__ == "__main__":
    main()
