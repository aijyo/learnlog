"""exp02 - blind noise estimation + noise-adaptive motion threshold.

Two questions:
  Q1 (estimator): does estimate_nlf() recover the true Poisson-Gaussian noise
     level function from noisy frames alone? (We know the truth: for our synth
     noise, Var = clean/peak + read_sigma^2, so a_true=1/peak, b_true=read^2.)
  Q2 (denoiser): the exp01 finding was that a CONSTANT sigma_motion is only right
     for one noise level. Does calibrating the motion threshold to the estimated
     per-pixel noise (NoiseAdaptiveRecursiveDenoiser) stay good ACROSS noise
     levels where the fixed-threshold version degrades?

    python experiments/exp02_noise_adaptive.py

Reuses exp01's synthetic scene + metrics (single source of truth).
"""
from __future__ import annotations
import os, sys
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))

from exp01_classical_baseline import (           # noqa: E402
    make_clean_sequence, add_poisson_gaussian, seq_metrics, SEED,
)
from classical_denoise import (                    # noqa: E402
    estimate_nlf, spatial_bilateral,
    MotionAdaptiveRecursiveDenoiser, NoiseAdaptiveRecursiveDenoiser,
    run_stream, run_spatial,
)

READ_SIGMA = 0.02
PEAKS = [80.0, 40.0, 20.0, 10.0]     # photons at white: higher = cleaner, lower = darker/noisier


def q1_estimator(clean, static_bg):
    print("Q1  blind NLF estimation vs ground truth  (Var = a*I + b)")
    print(f"{'peak':>6}{'a_true':>10}{'a_est':>10}{'b_true':>11}{'b_est':>11}"
          f"{'sigma@0.5 true/est':>22}")
    print("-" * 70)
    for peak in PEAKS:
        rng = np.random.default_rng(SEED + int(peak))
        noisy = add_poisson_gaussian(clean, rng, peak=peak, read_sigma=READ_SIGMA)
        # estimate from a single mid-sequence frame
        a, b = estimate_nlf(noisy[len(noisy) // 2])
        a_t, b_t = 1.0 / peak, READ_SIGMA ** 2
        s_t = np.sqrt(a_t * 0.5 + b_t)
        s_e = np.sqrt(max(a * 0.5 + b, 1e-10))
        print(f"{peak:>6.0f}{a_t:>10.4f}{a:>10.4f}{b_t:>11.5f}{b:>11.5f}"
              f"{s_t:>11.4f}{s_e:>11.4f}")
    print()


def q2_sweep(clean, static_bg):
    print("Q2  denoiser robustness across noise levels  (bgPSNR / fgPSNR / flicker*1e3)")
    print(f"{'peak':>6} | {'spatial bilateral':>26} | "
          f"{'fixed motion-adapt':>26} | {'noise-adaptive':>26}")
    print(f"{'':6} | {'bg':>8}{'fg':>8}{'flick':>10} | "
          f"{'bg':>8}{'fg':>8}{'flick':>10} | {'bg':>8}{'fg':>8}{'flick':>10}")
    print("-" * 96)
    for peak in PEAKS:
        rng = np.random.default_rng(SEED + int(peak))
        noisy = add_poisson_gaussian(clean, rng, peak=peak, read_sigma=READ_SIGMA)

        m_bl = seq_metrics(run_spatial(spatial_bilateral, noisy), clean, static_bg)
        # fixed: constant sigma_motion tuned at peak=40 (exp01 default)
        m_fx = seq_metrics(run_stream(MotionAdaptiveRecursiveDenoiser(), noisy),
                           clean, static_bg)
        # noise-adaptive: threshold = k * estimated per-pixel noise sigma (blind).
        # k picked ONCE (from the Q3 frontier) and held across all noise levels.
        m_na = seq_metrics(run_stream(NoiseAdaptiveRecursiveDenoiser(k_motion=5.0), noisy),
                           clean, static_bg)

        def cell(m):
            return f"{m['bg']:>8.2f}{m['ghost']:>8.2f}{m['flicker']*1e3:>10.2f}"
        print(f"{peak:>6.0f} | {cell(m_bl)} | {cell(m_fx)} | {cell(m_na)}")
    print("-" * 96)
    print("expectation: fixed threshold (tuned @peak=40) should sag away from 40 --")
    print("at high noise (peak=10) it reads noise as motion (flicker up / bg down); at")
    print("low noise (peak=80) it over-smooths motion (fg down). Noise-adaptive should")
    print("hold bg high + fg high + flicker low across the whole range.")


def q3_k_frontier(clean, static_bg, peak=40.0):
    """The noise-adaptive threshold has one knob, k_motion (motion must exceed
    k*sigma_noise to count as motion). Sweep it to expose the bg<->fg frontier:
    low k = motion-sensitive (great fg, less bg averaging); high k = trusts
    temporal more (great bg, ghost risk)."""
    print(f"\nQ3  k_motion frontier at peak={peak:.0f}  (the noise-adaptive knob)")
    print(f"{'k_motion':>9}{'bgPSNR':>9}{'fgPSNR':>9}{'flicker*1e3':>13}")
    print("-" * 40)
    rng = np.random.default_rng(SEED + int(peak))
    noisy = add_poisson_gaussian(clean, rng, peak=peak, read_sigma=READ_SIGMA)
    for k in [2.0, 3.0, 4.0, 6.0, 8.0]:
        m = seq_metrics(run_stream(NoiseAdaptiveRecursiveDenoiser(k_motion=k), noisy),
                        clean, static_bg)
        print(f"{k:>9.1f}{m['bg']:>9.2f}{m['ghost']:>9.2f}{m['flicker']*1e3:>13.2f}")
    print("-" * 40)
    print("higher k -> bg up (more temporal averaging) but fg eventually ghosts.")


def main():
    rng = np.random.default_rng(SEED)
    clean, static_bg = make_clean_sequence(rng)
    print(f"scene: static bg + moving fg, T={len(clean)}  read_sigma={READ_SIGMA}\n")
    q1_estimator(clean, static_bg)
    q2_sweep(clean, static_bg)
    q3_k_frontier(clean, static_bg)


if __name__ == "__main__":
    main()
