"""exp08 - judge the uniform/noise-matched/zoom strength profiles under a
PERCEPTUAL (shadow-weighted) metric, not just MSE.

exp07 verdict: on plain PSNR/flicker, Zoom's shadow-weighted strength LOSES. But
plain MSE weights every pixel equally, while the eye judges noise RELATIVE to local
luminance (Weber's law): a fixed fluctuation is more visible in shadows. So we
weight the error by w(L) = 1/(L+L0)^gamma and sweep gamma from 0 (=plain MSE) to
1 (=Weber). If Zoom's shadow spend is a *perceptual* choice, it should overtake as
gamma rises.

HONEST CAVEAT: Zoom's curve (~1/luma) and the Weber weight (~1/luma) are the SAME
shape -- both encode shadow sensitivity -- so "Zoom wins under Weber" is partly
tautological. Sweeping gamma (and reporting the crossover) shows HOW MUCH shadow
emphasis is needed to justify Zoom, rather than cherry-picking one metric.

    python experiments/exp08_perceptual_metric.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))

from exp07_zoom_strength_profile import _dark_bright_scene, profiles, SIGMA_MEAN  # noqa: E402
from exp01_classical_baseline import SEED  # noqa: E402
from noise_models import add_realistic_noise_seq, add_pg_gamma_domain, C270_MEASURED  # noqa: E402
from classical_denoise import LumaProfileRecursiveDenoiser, estimate_nlf_temporal, run_stream  # noqa: E402

GAMMAS = [0.0, 0.5, 1.0, 1.5]   # 0 = plain MSE ; 1 = Weber ; >1 = stronger shadow emphasis
L0 = 0.05


def pweighted_psnr(out, clean, gamma):
    """Perceptual PSNR: MSE weighted by w(L)=1/(L+L0)^gamma, normalized so gamma=0
    equals ordinary PSNR. Higher = better."""
    num = den = 0.0
    for t in range(len(out)):
        w = 1.0 / np.power(clean[t] + L0, gamma)
        w2 = w * w
        num += float(np.sum(w2 * (out[t] - clean[t]) ** 2))
        den += float(np.sum(w2))
    wmse = num / den
    return 99.0 if wmse < 1e-12 else -10.0 * np.log10(wmse)


def pweighted_flicker(seq, gamma, mask):
    luma = seq.mean(axis=0)
    w = 1.0 / np.power(luma + L0, gamma)
    std_t = seq.std(axis=0)
    return float((w[mask] * std_t[mask]).sum() / (w[mask].sum() + 1e-8))


def synth_denoise():
    rng = np.random.default_rng(SEED)
    clean = _dark_bright_scene(rng)
    r = np.random.default_rng(SEED + 7)
    noisy = add_realistic_noise_seq(clean, r, **C270_MEASURED)
    nlf = estimate_nlf_temporal(noisy)
    outs = {name: run_stream(LumaProfileRecursiveDenoiser(fn, sigma_mean=SIGMA_MEAN), noisy)
            for name, fn in profiles(nlf).items()}
    return clean, outs


def main():
    print("Part A  synthetic (GT): perceptual PSNR vs shadow-emphasis gamma")
    print("  (gamma=0 is ordinary PSNR; higher gamma weights shadow error more)\n")
    clean, outs = synth_denoise()
    names = list(outs.keys())
    print(f"{'gamma':>7}" + "".join(f"{n:>16}" for n in names) + f"{'  best':>16}")
    print("-" * (7 + 16 * len(names) + 16))
    for g in GAMMAS:
        vals = {n: pweighted_psnr(outs[n], clean, g) for n in names}
        best = max(vals, key=vals.get)
        print(f"{g:>7.1f}" + "".join(f"{vals[n]:>16.2f}" for n in names) + f"{best:>16}")
    print("-" * (7 + 16 * len(names) + 16))
    print("read: find the gamma where 'zoom-strength' overtakes uniform/noise-matched.")
    print("That crossover = how much shadow emphasis the perceptual model needs before")
    print("Zoom's design pays off. (Zoom's curve ~1/luma == Weber weight ~1/luma, so the")
    print("crossover is expected near Weber; the value of interest is WHERE it happens.)\n")

    # real clip
    clip = os.path.join(os.path.dirname(__file__), "..", "samples", "lowlight_exp8.mp4")
    if not os.path.exists(clip):
        print("(real clip missing; skipping Part B)")
        return
    cap = cv2.VideoCapture(clip)
    fr = []
    while len(fr) < 90:
        ok, f = cap.read()
        if not ok:
            break
        fr.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0)
    cap.release()
    frames = np.asarray(fr)
    nlf = estimate_nlf_temporal(frames)
    bl = np.stack([cv2.GaussianBlur(f, (0, 0), 2.0) for f in frames])
    static = bl.std(axis=0) <= np.percentile(bl.std(axis=0), 40)
    routs = {name: run_stream(LumaProfileRecursiveDenoiser(fn, sigma_mean=SIGMA_MEAN), frames)
             for name, fn in profiles(nlf).items()}

    print("Part B  real C270 clip: perceptual flicker vs gamma (LOWER = better)")
    print(f"{'gamma':>7}" + "".join(f"{n:>16}" for n in names) + f"{'  best':>16}")
    print("-" * (7 + 16 * len(names) + 16))
    for g in GAMMAS:
        vals = {n: pweighted_flicker(routs[n], g, static) for n in names}
        best = min(vals, key=vals.get)
        print(f"{g:>7.1f}" + "".join(f"{vals[n]*1e3:>16.3f}" for n in names) + f"{best:>16}")
    print("-" * (7 + 16 * len(names) + 16))

    part_C()


def _per_luma_sigma(frames, edges):
    d = (frames[1:] - frames[:-1]).ravel()
    inten = (0.5 * (frames[1:] + frames[:-1])).ravel()
    out = []
    for i in range(len(edges) - 1):
        sel = (inten >= edges[i]) & (inten < edges[i + 1])
        if sel.sum() < 500:
            out.append(float("nan")); continue
        dd = d[sel]
        out.append(1.4826 * np.median(np.abs(dd - np.median(dd))) / np.sqrt(2))
    return out


def part_C():
    print("\nPart C  SHADOW-HEAVY noise (linear PG + gamma) -> when does zoom win?")
    rng = np.random.default_rng(SEED)
    clean = _dark_bright_scene(rng)
    r = np.random.default_rng(SEED + 11)
    noisy = add_pg_gamma_domain(clean, r, peak=60.0, read_sigma_lin=0.06)
    # confirm the noise is shadow-heavy (sigma DECREASES with luma)
    sig = _per_luma_sigma(noisy, [0.02, 0.14, 0.30, 0.50, 0.75])
    print("   per-luma noise sigma (dark->bright): " +
          " ".join(f"{s:.4f}" for s in sig) +
          "  -> " + ("DECREASES (shadow-heavy) OK" if sig[0] > sig[-1] else "not shadow-heavy!"))
    nlf = estimate_nlf_temporal(noisy)
    outs = {name: run_stream(LumaProfileRecursiveDenoiser(fn, sigma_mean=SIGMA_MEAN), noisy)
            for name, fn in profiles(nlf).items()}
    names = list(outs.keys())
    print(f"{'gamma':>7}" + "".join(f"{n:>16}" for n in names) + f"{'  best':>16}")
    print("-" * (7 + 16 * len(names) + 16))
    for g in GAMMAS:
        vals = {n: pweighted_psnr(outs[n], clean, g) for n in names}
        best = max(vals, key=vals.get)
        print(f"{g:>7.1f}" + "".join(f"{vals[n]:>16.2f}" for n in names) + f"{best:>16}")
    print("-" * (7 + 16 * len(names) + 16))
    print("if zoom-strength wins here (esp. at higher gamma), the conclusion is:")
    print("Zoom's shadow-weighted curve is right IFF noise is shadow-heavy AND the")
    print("metric is perceptual -- both conditions, not either alone.")


if __name__ == "__main__":
    main()
