"""exp09 - reproduce & diagnose the "ripple/banding" artifact on smooth skin.

Bug report (demo): on a smooth low-contrast gradient (neck skin), the denoised
output shows ripple/contour bands that follow the iso-luminance lines.

Disambiguation:
  H1 bilateral staircase  -> bands appear ONLY with the spatial bilateral stage.
  H2 8-bit quant banding   -> bands appear even with pure temporal IIR (denoising
                              removes the noise that was dithering the quantizer).
Test: run pure-temporal vs with-bilateral on a synthetic smooth gradient, quantize
to 8-bit, measure banding (run-length of equal 8-bit values along a gradient cut;
long runs / few level-changes = banding), and save crops.

    python experiments/exp09_banding_repro.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from noise_models import add_realistic_noise_seq, C270_MEASURED  # noqa: E402
from classical_denoise import (  # noqa: E402
    FixedTemporalIIR, MotionAdaptiveRecursiveDenoiser, spatial_bilateral, run_stream,
)

H, W, T = 240, 320, 120   # more frames -> denoiser converges near-clean -> banding shows
OUT = os.path.join(os.path.dirname(__file__), "..", "samples", "banding")
os.makedirs(OUT, exist_ok=True)


def skin_gradient():
    """Smooth, low-contrast, CURVED gradient (like the neck fold): value ~0.35..0.58,
    iso-luminance lines are arcs -> banding shows up as ripples along them."""
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    cx, cy = W * 1.1, H * 0.4
    r = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    g = (r - r.min()) / (np.ptp(r) + 1e-6)          # smooth radial ramp 0..1
    val = 0.44 + 0.09 * g                            # VERY low contrast (like neck skin)
    return np.repeat(val[None], T, axis=0)           # static content


def band_score(u8, y=H // 2):
    """Along a horizontal cut through the smooth region: mean run-length of equal
    8-bit values (higher = more banding) and #level-changes (lower = more banding)."""
    row = u8[y].astype(int)
    changes = int(np.sum(np.diff(row) != 0))
    runs, c = [], 1
    for i in range(1, len(row)):
        if row[i] == row[i - 1]:
            c += 1
        else:
            runs.append(c); c = 1
    runs.append(c)
    return float(np.mean(runs)), changes


def q8(imgf):
    return np.clip(imgf * 255.0 + 0.5, 0, 255).astype(np.uint8)


def q8_dither(imgf, rng, amp=1.0):
    """Triangular-PDF dither of +-amp LSB before quantization (standard debanding).
    Sub-visible (~1 gray level) but breaks the hard quantization contours."""
    tpdf = (rng.random(imgf.shape) - rng.random(imgf.shape)) * (amp / 255.0)
    return np.clip((imgf + tpdf) * 255.0 + 0.5, 0, 255).astype(np.uint8)


def main():
    rng = np.random.default_rng(7)
    clean = skin_gradient()
    noisy = add_realistic_noise_seq(clean, rng, **C270_MEASURED)
    # aggressive/converged static denoise (high alpha, large threshold so static
    # pixels get near-full temporal averaging) -> residual << 1 LSB -> banding shows
    ma = run_stream(MotionAdaptiveRecursiveDenoiser(
        alpha_max=0.98, sigma_motion=0.4, spatial_sigma_color=0.18), noisy)[-1]

    d = np.random.default_rng(1)
    cases = {
        "clean (q8)": q8(clean[-1]),
        "noisy (q8)": q8(noisy[-1]),
        "motion-adaptive converged (q8)  <-BUG": q8(ma),
        "  + DITHER amp=1": q8_dither(ma, d, amp=1.0),
        "  + DITHER amp=2 (fix)": q8_dither(ma, d, amp=2.0),
        "  + DITHER amp=3": q8_dither(ma, d, amp=3.0),
    }
    print(f"{'case':<40}{'mean-run(px)':>13}{'#changes':>10}  (banding: run↑ changes↓)")
    print("-" * 74)
    def fname(s):
        import re
        return re.sub(r'[^a-z0-9]+', '_', s.lower()).strip('_')
    for name, u in cases.items():
        mr, ch = band_score(u)
        print(f"{name:<40}{mr:>13.2f}{ch:>10}")
        cv2.imwrite(os.path.join(OUT, fname(name) + ".png"),
                    cv2.resize(u, (W * 2, H * 2), interpolation=cv2.INTER_NEAREST))
    print("-" * 74)
    print("if 'temporal-IIR (no spatial)' already bands (run>>noisy, few changes) ->")
    print("H2 quantization-banding dominates. If only the bilateral cases band -> H1")
    print("staircase. Crops saved to samples/banding/ for visual confirmation.")


if __name__ == "__main__":
    main()
