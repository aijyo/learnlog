"""exp13 - reproduce the MCTF "water streak" on the USER'S REAL clip (the real loop).

No ground truth -> rely on visual montages + a streak proxy. Runs guard / MCTF /
MCTF+FB-gate on the recorded frames (luma, like the demo) and dumps montages at
several frames so the ceiling-streak region can be inspected.

    python experiments/exp13_real_motion.py [clip.mp4]
"""
from __future__ import annotations
import os, sys, shutil
import numpy as np
import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from classical_denoise import (  # noqa: E402
    MotionAdaptiveRecursiveDenoiser, MotionCompensatedDenoiser, run_stream,
)

SRC = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\NCC Technology\Desktop\denoise_clip_092846.mp4"
OUT = os.path.join(os.path.dirname(__file__), "..", "samples", "real_motion")
os.makedirs(OUT, exist_ok=True)


def load_luma(path, maxf=120):
    cap = cv2.VideoCapture(path)
    fr = []
    while len(fr) < maxf:
        ok, f = cap.read()
        if not ok:
            break
        fr.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0)
    cap.release()
    return np.asarray(fr)


def streak_proxy(seq):
    """Low-texture drift proxy: in flat regions (low spatial gradient) a good denoiser
    is temporally stable; flow-warp drift raises temporal variation there. Report mean
    temporal std over the flattest 40% of pixels (by mean spatial-gradient)."""
    gx = np.abs(np.diff(seq, axis=2)).mean(axis=(0,))[:, :-0 or None]
    grad = np.zeros(seq.shape[1:], np.float32)
    for t in range(seq.shape[0]):
        gxx = cv2.Sobel(seq[t], cv2.CV_32F, 1, 0, ksize=3)
        gyy = cv2.Sobel(seq[t], cv2.CV_32F, 0, 1, ksize=3)
        grad += np.abs(gxx) + np.abs(gyy)
    grad /= seq.shape[0]
    flat = grad <= np.percentile(grad, 40)
    return float(seq.std(axis=0)[flat].mean())


def main():
    if not os.path.exists(SRC):
        raise SystemExit(f"clip not found: {SRC}")
    shutil.copy(SRC, os.path.join(OUT, "input.mp4"))
    frames = load_luma(SRC)
    print(f"loaded {frames.shape[0]} frames {frames.shape[2]}x{frames.shape[1]} (luma) from {os.path.basename(SRC)}")

    methods = {
        "guard": lambda: run_stream(MotionAdaptiveRecursiveDenoiser(
            alpha_max=0.95, sigma_motion=0.06, motion_dilate=8, motion_decay=0.6), frames),
        "MCTF-nogate": lambda: run_stream(
            MotionCompensatedDenoiser(alpha_max=0.9, occ_sigma=0.06, flow_scale=0.5), frames),
        "MCTF-fbgate": lambda: run_stream(
            MotionCompensatedDenoiser(alpha_max=0.9, occ_sigma=0.06, flow_scale=0.5,
                                      fb_check=True, fbc_sigma=1.0), frames),
    }
    outs = {}
    print(f"{'method':<16}{'streak-proxy(flat temporal std)':>34}")
    print("-" * 50)
    for name, fn in methods.items():
        out = fn(); outs[name] = out
        print(f"{name:<16}{streak_proxy(out)*1e3:>30.2f}e-3")
    print(f"{'noisy(input)':<16}{streak_proxy(frames)*1e3:>30.2f}e-3")
    print("-" * 50)

    # montages at several frames: noisy | guard | MCTF-nogate | MCTF-fbgate
    T = frames.shape[0]
    def u8(x): return np.clip(x * 255 + 0.5, 0, 255).astype(np.uint8)
    for t in [int(T * f) for f in (0.4, 0.55, 0.7, 0.85)]:
        row = np.hstack([u8(frames[t]), u8(outs["guard"][t]),
                         u8(outs["MCTF-nogate"][t]), u8(outs["MCTF-fbgate"][t])])
        cv2.imwrite(os.path.join(OUT, f"frame{t:03d}_noisy_guard_mctf_gate.png"), row)
    print(f"montages (noisy | guard | MCTF-nogate | MCTF-fbgate) -> samples/real_motion/")


if __name__ == "__main__":
    main()
