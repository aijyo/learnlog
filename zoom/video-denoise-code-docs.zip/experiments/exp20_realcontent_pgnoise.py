"""exp20 - generalization test: SYNTHETIC-trained nets on REAL CONTENT + controlled noise.

exp18 measured PSNR on synthetic patches (same distribution the net trained on) — an
easy test. The honest question is whether a net trained on synthetic clean patches
generalizes to real faces/fabric/skin. Method: take near-clean real webcam frames as
pseudo-GT, add the SAME Poisson-Gaussian noise used in training, denoise, measure
PSNR/SSIM against the pseudo-GT. Content is real; noise is controlled+known.

    python experiments/exp20_realcontent_pgnoise.py <clip.mp4>
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

CLIP = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\NCC Technology\Desktop\denoise_clip_143109.mp4"
PEAK, READ = 30.0, 0.03

cap = cv2.VideoCapture(CLIP)
gt = []
while len(gt) < 40:
    ok, f = cap.read()
    if not ok:
        break
    gt.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0)
cap.release()
gt = np.array(gt[::2])   # every other frame, 20 frames
print(f"pseudo-GT: {len(gt)} real frames {gt.shape[1:]}")

import torch  # noqa: E402
torch.set_num_threads(1)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_denoise import DnCNN, to_tensor, add_pg_noise  # noqa: E402
from classical_denoise import spatial_bilateral  # noqa: E402

rng = np.random.default_rng(7)
noisy = add_pg_noise(gt, rng, PEAK, READ)   # real content + known PG noise


def psnr(a, b):
    m = float(np.mean((np.clip(a, 0, 1) - np.clip(b, 0, 1)) ** 2))
    return 99.0 if m < 1e-12 else 10.0 * np.log10(1.0 / m)


def ssim(a, b):
    C1, C2 = 0.01 ** 2, 0.03 ** 2
    ma = cv2.GaussianBlur(a, (11, 11), 1.5); mb = cv2.GaussianBlur(b, (11, 11), 1.5)
    va = cv2.GaussianBlur(a * a, (11, 11), 1.5) - ma * ma
    vb = cv2.GaussianBlur(b * b, (11, 11), 1.5) - mb * mb
    vab = cv2.GaussianBlur(a * b, (11, 11), 1.5) - ma * mb
    s = ((2 * ma * mb + C1) * (2 * vab + C2)) / ((ma * ma + mb * mb + C1) * (va + vb + C2) + 1e-12)
    return float(s.mean())


def load(name, feat, depth):
    n = DnCNN(feat=feat, depth=depth, use_bn=True)
    n.load_state_dict(torch.load(os.path.join(os.path.dirname(__file__), "..", "models", f"dncnn_{name}.pt"),
                                 map_location="cpu"))
    n.eval(); return n


def run_net(n):
    out = np.empty_like(gt)
    with torch.no_grad():
        for i in range(len(gt)):
            out[i] = n(to_tensor(noisy[i:i + 1])).clamp(0, 1).numpy()[0, 0]
    return out


methods = {"noisy(in)": noisy,
           "bilateral": np.stack([spatial_bilateral(noisy[i]) for i in range(len(gt))]),
           "tinyNN(745)": run_net(load("tiny", 8, 3)),
           "smallNN(5k)": run_net(load("small", 16, 4)),
           "heavyNN(105k)": run_net(load("heavy", 48, 7))}

print(f"REAL content + PG(peak={PEAK},read={READ}) noise, PSNR/SSIM vs pseudo-GT")
print(f"{'method':<16}{'PSNR':>8}{'SSIM':>8}")
print("-" * 32)
for name, seq in methods.items():
    p = np.mean([psnr(seq[i], gt[i]) for i in range(len(gt))])
    s = np.mean([ssim(seq[i], gt[i]) for i in range(len(gt))])
    print(f"{name:<16}{p:>8.2f}{s:>8.3f}")

# save a montage on a real frame: gt | noisy | bilateral | tinyNN
u8 = lambda z: (np.clip(z, 0, 1) * 255).astype(np.uint8)
t = 8
row = np.hstack([u8(gt[t]), u8(noisy[t]), u8(methods["bilateral"][t]), u8(methods["tinyNN(745)"][t])])
row = cv2.resize(row, None, fx=0.9, fy=0.9, interpolation=cv2.INTER_AREA)
cv2.putText(row, "GT | noisy | bilateral | tinyNN", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, 255, 1)
cv2.imwrite(os.path.join(os.path.dirname(__file__), "..", "samples", "zlt_recon", "realcontent_pg.png"), row)
print("montage -> samples/zlt_recon/realcontent_pg.png")
