"""exp10 - reproduce & fix motion GHOSTING (trail left by a fast-moving object).

Bug report (demo): a fast-moving finger leaves a faint ghost trail in the vacated
background, and the finger itself looks mottled. That is the motion-adaptive
denoiser NOT dropping its temporal blend fast enough on fast motion (soft alpha
shoulder + diff-blur smearing + high alpha_max), so history bleeds through.

Reproduce with a fast dark textured bar sweeping over a bright static background
(like a finger over the ceiling), with the DEMO's params, then A/B fixes on:
  - trail-err   : mean|out-clean| in the just-vacated region (LOWER = less ghost)
  - static-flick: temporal std on never-touched bg (LOWER = better denoising)
The goal is to cut the trail without wrecking static-region denoising.

    python experiments/exp10_motion_ghost.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from noise_models import add_realistic_noise_seq, C270_MEASURED  # noqa: E402
from classical_denoise import MotionAdaptiveRecursiveDenoiser, run_stream  # noqa: E402

H, W, T = 200, 360, 40
DX = 14            # px/frame -> fast sweep (shaking finger)
BAR_W = 70
OUT = os.path.join(os.path.dirname(__file__), "..", "samples", "ghost")
os.makedirs(OUT, exist_ok=True)


def tex(h, w, lo, hi, rng, s=3.0):
    n = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), s)
    n = (n - n.min()) / (np.ptp(n) + 1e-6)
    return lo + (hi - lo) * n


def scene(rng):
    bg = tex(H, W, 0.62, 0.82, rng)                 # bright ceiling-like, static
    bar = tex(H, BAR_W, 0.46, 0.52, rng, s=9.0)     # SMOOTH-interior finger-like bar
    bar[:, :3] = 0.40; bar[:, -3:] = 0.40           # clear edges (interior stays smooth)
    frames = np.empty((T, H, W), np.float32)
    xs = []
    for t in range(T):
        f = bg.copy()
        x = 10 + DX * t
        xs.append(x)
        if x < W:
            w = min(BAR_W, W - x)
            f[:, x:x + w] = bar[:, :w]
        frames[t] = np.clip(f, 0, 1)
    return frames, bg, xs


def masks(xs, t):
    """just-vacated trail (bg now, was bar in the last 3 frames) vs never-touched bg."""
    cover = np.zeros((H, W), bool)
    trail = np.zeros((H, W), bool)
    ever = np.zeros((H, W), bool)
    for k, x in enumerate(xs):
        if x < W:
            ever[:, x:min(x + BAR_W, W)] = True
    x_now = xs[t]
    if x_now < W:
        cover[:, x_now:min(x_now + BAR_W, W)] = True
    for k in range(max(0, t - 3), t):
        x = xs[k]
        if x < W:
            trail[:, x:min(x + BAR_W, W)] = True
    trail = trail & ~cover                     # vacated (not currently covered)
    never = ~ever
    return trail, never


def run_and_score(rng_seed, **den_kw):
    rng = np.random.default_rng(rng_seed)
    frames, bg, xs = scene(rng)
    noisy = add_realistic_noise_seq(frames, rng, **C270_MEASURED)
    out = run_stream(MotionAdaptiveRecursiveDenoiser(**den_kw), noisy)
    t = 15                      # mid-sweep: bar in-frame, a real vacated trail behind it
    trail, never = masks(xs, t)
    trail_err = float(np.mean(np.abs(out[t][trail] - frames[t][trail]))) if trail.any() else float("nan")
    static_flick = float(out[:, never].std(axis=0).mean())
    return trail_err, static_flick, out, frames, t


def main():
    print("fast-moving SMOOTH bar over static bright bg; ghost trail vs static denoising")
    print(f"{'setting':<40}{'trail-err':>11}{'static-flick':>14}  (both LOWER=better)")
    print("-" * 68)
    base = dict(spatial_sigma_color=0.18, sigma_motion=0.06, alpha_max=0.95, diff_blur_sigma=3.0)
    configs = {
        "DEMO default (no guard)": base,
        "GUARD dilate=6, decay=0.6": {**base, "motion_dilate": 6, "motion_decay": 0.6},
        "GUARD dilate=10, decay=0.7": {**base, "motion_dilate": 10, "motion_decay": 0.7},
    }
    outs = {}
    for name, kw in configs.items():
        te, sf, out, clean, t = run_and_score(7, **kw)
        print(f"{name:<40}{te*1e3:>9.2f}e-3{sf*1e3:>11.2f}e-3")
        outs[name] = (out, clean, t)

    # crops at the ghost frame: clean | demo | guarded
    (out_d, clean, t) = outs["DEMO default (no guard)"]
    (out_g, _, _) = outs["GUARD dilate=10, decay=0.7"]
    def u8(x): return np.clip(x * 255 + 0.5, 0, 255).astype(np.uint8)
    row = np.hstack([u8(clean[t]), u8(out_d[t]), u8(out_g[t])])
    cv2.imwrite(os.path.join(OUT, "clean_demo_guard.png"),
                cv2.resize(row, (row.shape[1] * 2, row.shape[0] * 2), interpolation=cv2.INTER_NEAREST))
    print(f"\ncrop (clean | DEMO | GUARDED) at ghost frame -> {os.path.join(OUT, 'clean_demo_guard.png')}")


if __name__ == "__main__":
    main()
