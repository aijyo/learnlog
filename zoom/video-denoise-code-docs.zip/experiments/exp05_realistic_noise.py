"""exp05 - camera-realistic noise: reproduce the real-footage estimator signature,
and show its consequence for temporal denoising.

exp04 on real C270 footage found spatial sigma (0.070) >> temporal sigma (0.024)
-- a ~3x split that pure Poisson-Gaussian does NOT produce. Q1 decomposes which
noise component creates which half of that split. Q2 shows the actionable
consequence: fixed-pattern noise is CONSTANT over time, so temporal denoising
cannot remove it -- it survives as a residual pattern and caps PSNR.

    python experiments/exp05_realistic_noise.py

Reuses exp01's clean scene + metrics; noise from scripts/noise_models.py.
"""
from __future__ import annotations
import os, sys
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))

from exp01_classical_baseline import make_clean_sequence, SEED  # noqa: E402
from noise_models import add_realistic_noise_seq, C270_LIKE      # noqa: E402
from classical_denoise import (                                   # noqa: E402
    estimate_nlf, estimate_nlf_temporal, spatial_bilateral,
    FixedTemporalIIR, NoiseAdaptiveRecursiveDenoiser, run_stream, run_spatial,
)

PEAK, READ = 40.0, 0.02
TRUE_SIGMA_AT_HALF = float(np.sqrt(0.5 / PEAK + READ ** 2))  # true temporal marginal @I=0.5


def sigma_at(a, b, I=0.5):
    return float(np.sqrt(max(a * I + b, 1e-10)))


def q1_signature(clean):
    print("Q1  which noise component creates the spatial-vs-temporal split?")
    print(f"    (true TEMPORAL marginal sigma@0.5 = {TRUE_SIGMA_AT_HALF:.4f}; peak={PEAK:.0f})\n")
    variants = [
        ("poisson-gaussian (ideal)", dict()),
        ("+ fixed-pattern (DSNU/PRNU)", dict(dsnu=0.010, prnu=0.012)),
        ("+ spatial-corr", dict(spatial_corr=0.8)),
        ("+ temporal-corr (rho=.55)", dict(temporal_rho=0.55)),
        ("all (C270-like)", dict(C270_LIKE)),
    ]
    print(f"{'noise variant':<30}{'spatial sig':>12}{'temporal sig':>14}{'spatial/temporal':>18}")
    print("-" * 74)
    for name, kw in variants:
        kw = {**dict(peak=PEAK, read_sigma=READ), **kw}
        r = np.random.default_rng(SEED + 7)
        noisy = add_realistic_noise_seq(clean, r, **kw)
        s = sigma_at(*estimate_nlf(noisy[len(noisy) // 2]))
        t = sigma_at(*estimate_nlf_temporal(noisy))
        print(f"{name:<30}{s:>12.4f}{t:>14.4f}{s/max(t,1e-6):>18.2f}x")
    print("-" * 74)
    print("read: ideal PG -> ratio ~1 (estimators agree). Fixed-pattern pushes the")
    print("SPATIAL estimate UP (static pattern looks like spatial variance, cancels in")
    print("the temporal diff). Temporal-corr pushes the TEMPORAL estimate DOWN (the diff")
    print("only sees (1-rho) of the noise). Together they reproduce real footage's")
    print("spatial>>temporal split -- which pure Poisson-Gaussian cannot.\n")


def q2_fpn_survives(clean, static_bg):
    print("Q2  consequence: fixed-pattern noise survives temporal denoising")
    # use the KNOWN injected FPN maps as ground truth (no averaging confound). Turn
    # OFF temporal correlation here so the residual-noise term averages cleanly and
    # we isolate the fixed pattern itself.
    r = np.random.default_rng(SEED + 7)
    kw = {**C270_LIKE, "temporal_rho": 0.0}
    noisy, (dsnu_map, prnu_map) = add_realistic_noise_seq(clean, r, return_fpn=True, **kw)

    m = static_bg
    fp_true = (prnu_map - 1.0) * clean[0] + dsnu_map     # true time-constant error, static bg
    fp_rms = float(np.sqrt((fp_true[m] ** 2).mean()))

    # (a) FPN passthrough, isolated on a NOISE-FREE FPN signal. FPN is DC in time;
    #     a unity-DC temporal filter preserves it exactly -> output error IS the FPN.
    fpn_only = prnu_map[None] * clean + dsnu_map[None]   # clean + FPN, zero random noise
    out_iir_clean = run_stream(FixedTemporalIIR(0.9), fpn_only)
    res = (out_iir_clean[-1] - clean[-1])                # after transient (last frame)
    corr = float(np.corrcoef(res[m], fp_true[m])[0, 1])
    rms = float(np.sqrt((res[m] ** 2).mean()))
    print("(a) FPN passthrough (noise-free input, pure temporal IIR):")
    print(f"    injected FPN RMS = {fp_rms*1e3:.2f}e-3 ; leftover error RMS = {rms*1e3:.2f}e-3 ;"
          f" corr(leftover, FPN) = {corr:.3f}")
    print("    -> temporal filtering leaves the FPN essentially untouched (corr~1, RMS~FPN):")
    print("       FPN is DC in time, no temporal averaging can remove it.\n")

    # (b) time-VARYING noise IS removed by temporal filtering (flicker on static bg).
    out_iir = run_stream(FixedTemporalIIR(0.9), noisy)
    def flick(seq):
        return float((seq - clean).std(axis=0)[m].mean())
    print("(b) time-varying noise (flicker on static bg) with full realistic noise:")
    print(f"    noisy {flick(noisy)*1e3:.1f}e-3  ->  temporal IIR {flick(out_iir)*1e3:.1f}e-3"
          f"   ({(1-flick(out_iir)/flick(noisy))*100:.0f}% removed)")
    print("-" * 68)
    print("=> temporal denoising removes the TIME-VARYING noise but not the FIXED pattern.")
    print("   On real footage the FPN then becomes the error floor -> real pipelines need")
    print("   FPN CALIBRATION (dark-/flat-field), a synth<->real gap this model exposes.")


def main():
    rng = np.random.default_rng(SEED)
    clean, static_bg = make_clean_sequence(rng)
    print(f"scene: static bg + moving fg, T={len(clean)}\n")
    q1_signature(clean)
    q2_fpn_survives(clean, static_bg)


if __name__ == "__main__":
    main()
