"""exp17 - verify the clean-room zltCIIRDenoise reconstruction.

(A) sanity-check the faithful kernel math (detail_level): dark/bright branch,
    temporal blend 0.648, ranges.
(B) verify the ZltVppDenoiser denoise module actually denoises: synthetic (PSNR by
    region) + real clip (flicker + montage) vs our baselines.

    python experiments/exp17_zlt_recon.py
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from exp01_classical_baseline import make_clean_sequence, add_poisson_gaussian, SEED  # noqa: E402
from classical_denoise import (  # noqa: E402
    spatial_bilateral, NoiseAdaptiveRecursiveDenoiser, run_stream, run_spatial,
)
from zlt_denoise import detail_level, level_ramps, luma_strength8, ZltVppDenoiser  # noqa: E402


def part_A():
    print("(A) faithful kernel sanity — recovered math")
    v10, v12, v18, v19, v20 = level_ramps(24, 50)
    print(f"    level ramps a5=24,a6=50 -> v10={v10:.3f} v12={v12:.3f} v18={v18:.3f}")
    print(f"    luma strength: S(8)={luma_strength8(8):.2f}  S(64)={luma_strength8(64):.2f}"
          f"  S(200)={luma_strength8(200):.2f}   (shadow-weighted ✓)")
    # dark pixel (V=40) vs bright pixel (V=160), same activity
    v8 = np.array([[40.0, 160.0]], np.float32)
    act = np.array([[50.0, 50.0]], np.float32)
    n1 = detail_level(v8, act, 24, 50, prev_level=None, hist_depth=1)   # no temporal
    n2 = detail_level(v8, act, 24, 50, prev_level=np.array([[10.0, 10.0]], np.float32),
                      hist_depth=5)                                     # temporal on
    print(f"    level (no temporal): dark={n1[0,0]:.2f} bright={n1[0,1]:.2f}")
    print(f"    level (temporal on, prev=10): {n2[0,0]:.2f},{n2[0,1]:.2f} "
          f"(blend 0.648*10+0.352*n) ✓\n")


def part_B_synth():
    print("(B) synthetic (static bg + moving fg): PSNR by region + flicker")
    rng = np.random.default_rng(SEED)
    clean, static_bg = make_clean_sequence(rng)
    noisy = add_poisson_gaussian(clean, rng, peak=40.0, read_sigma=0.02)
    meanL = clean.mean(0)
    shadow, high = meanL < 0.3, meanL > 0.5

    def reg_psnr(out, m):
        e = out[:, m] - clean[:, m]; mse = float(np.mean(e ** 2))
        return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)

    def flick(out): return float(out[:, static_bg].std(0).mean())

    methods = {
        "noisy": noisy,
        "bilateral (spatial)": run_spatial(spatial_bilateral, noisy),
        "noise-adaptive (ours)": run_stream(NoiseAdaptiveRecursiveDenoiser(k_motion=5.0), noisy),
        "ZLT-recon (Zoom recipe)": run_stream(ZltVppDenoiser(a5=24, a6=50, k_thresh=3.0), noisy),
    }
    print(f"{'method':<26}{'PSNR':>7}{'shadowPSNR':>12}{'flicker':>10}")
    print("-" * 55)
    for name, out in methods.items():
        p = 10.0 * np.log10(1.0 / max(np.mean((out - clean) ** 2), 1e-12))
        print(f"{name:<26}{p:>7.2f}{reg_psnr(out, shadow):>12.2f}{flick(out)*1e3:>9.2f}e-3")
    print()


def part_B_real():
    clip = os.path.join(os.path.dirname(__file__), "..", "samples", "lowlight_exp8.mp4")
    if not os.path.exists(clip):
        print("(real clip missing; skip)"); return
    cap = cv2.VideoCapture(clip); fr = []
    while len(fr) < 90:
        ok, f = cap.read()
        if not ok: break
        fr.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255)
    cap.release(); frames = np.asarray(fr)
    blurred = np.stack([cv2.GaussianBlur(f, (0, 0), 2.0) for f in frames])
    motion = blurred.std(axis=0)
    static = motion <= np.percentile(motion, 40)
    out = run_stream(ZltVppDenoiser(a5=24, a6=50, k_thresh=3.0), frames)
    fin = frames.std(0)[static].mean(); fout = out.std(0)[static].mean()
    print(f"(B) real clip: static flicker  input {fin*1e3:.2f}e-3 -> ZLT-recon {fout*1e3:.2f}e-3"
          f"  ({(1-fout/fin)*100:.0f}% reduction)")
    od = os.path.join(os.path.dirname(__file__), "..", "samples", "zlt_recon")
    os.makedirs(od, exist_ok=True)
    t = len(frames) // 2
    u8 = lambda z: np.clip(z * 255 + 0.5, 0, 255).astype(np.uint8)
    cv2.imwrite(os.path.join(od, "noisy_vs_zltrecon.png"),
                cv2.resize(np.hstack([u8(frames[t]), u8(out[t])]), None, fx=1.4, fy=1.4,
                           interpolation=cv2.INTER_NEAREST))
    print(f"    montage (noisy | ZLT-recon) -> samples/zlt_recon/noisy_vs_zltrecon.png")


def main():
    part_A(); part_B_synth(); part_B_real()


if __name__ == "__main__":
    main()
