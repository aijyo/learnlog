"""exp06 - does Zoom's recovered noise curve match REAL per-luma noise?

Zoom's zltCIIRDenoise carries a per-luma noise curve that DECREASES with luma
(~1/luma, shadow-weighted), while our synthetic Poisson-Gaussian model has sigma
INCREASING with luma (shot-weighted). They are opposite shapes because Zoom works
in the sRGB/gamma domain (read noise dominates shadows) and PG is a linear-domain
model. This asks the empirical question on the real C270 low-light clip:

  measure sigma(luma) from the footage (temporal MAD per luma bin) -- does its
  SHAPE match Zoom's 1/luma curve, or the increasing Poisson-Gaussian curve?

    python experiments/exp06_zoom_noise_vs_real.py [path_to_clip]
"""
from __future__ import annotations
import os, sys
import numpy as np
import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from zoom_noise import zoom_strength01  # noqa: E402

CLIP = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
    os.path.dirname(__file__), "..", "samples", "lowlight_exp8.mp4")


def load_gray(path, maxf=90):
    cap = cv2.VideoCapture(path)
    fr = []
    while len(fr) < maxf:
        ok, f = cap.read()
        if not ok:
            break
        fr.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0)
    cap.release()
    return np.asarray(fr)


def per_luma_sigma(frames, nbins=12, lo=0.03, hi=0.55, min_n=2000):
    """Robust temporal noise sigma per luma bin: d=y[t]-y[t-1], sigma=MAD(d)/sqrt(2)
    (content cancels in the diff; MAD rejects moving pixels)."""
    d = (frames[1:] - frames[:-1]).ravel()
    inten = (0.5 * (frames[1:] + frames[:-1])).ravel()
    edges = np.linspace(lo, hi, nbins + 1)
    lumas, sigs = [], []
    for i in range(nbins):
        sel = (inten >= edges[i]) & (inten < edges[i + 1])
        if sel.sum() < min_n:
            continue
        dd = d[sel]
        mad = 1.4826 * np.median(np.abs(dd - np.median(dd)))
        lumas.append(0.5 * (edges[i] + edges[i + 1]))
        sigs.append(mad / np.sqrt(2.0))
    return np.array(lumas), np.array(sigs)


def main():
    frames = load_gray(CLIP)
    print(f"clip: {os.path.basename(CLIP)}  {frames.shape[0]} frames "
          f"{frames.shape[2]}x{frames.shape[1]}  median luma {np.median(frames):.3f}\n")

    luma, real = per_luma_sigma(frames)
    if len(luma) < 3:
        raise SystemExit("not enough luma coverage; capture a clip with more midtones")

    # candidate 1: Zoom curve (1/luma), scaled by a single factor to best match
    zoom_shape = zoom_strength01(luma)
    s = float((real @ zoom_shape) / (zoom_shape @ zoom_shape))
    zoom_fit = s * zoom_shape
    zoom_rmse = float(np.sqrt(np.mean((zoom_fit - real) ** 2)))

    # candidate 2: Poisson-Gaussian sigma^2 = a*luma + b (best least-squares fit)
    A = np.vstack([luma, np.ones_like(luma)]).T
    a, b = np.linalg.lstsq(A, real ** 2, rcond=None)[0]
    pg_fit = np.sqrt(np.maximum(a * luma + b, 1e-10))
    pg_rmse = float(np.sqrt(np.mean((pg_fit - real) ** 2)))

    print(f"{'luma':>6}{'real sigma':>12}{'Zoom(1/luma)':>14}{'PoissonGauss':>14}")
    print("-" * 46)
    for i in range(len(luma)):
        print(f"{luma[i]:>6.3f}{real[i]:>12.4f}{zoom_fit[i]:>14.4f}{pg_fit[i]:>14.4f}")
    print("-" * 46)
    trend = "DECREASES" if real[-1] < real[0] else "INCREASES"
    print(f"real sigma {trend} with luma  (sigma@lowluma={real[0]:.4f} -> @highluma={real[-1]:.4f})")
    print(f"shape fit RMSE:  Zoom(1/luma) {zoom_rmse:.4f}   |   Poisson-Gaussian {pg_rmse:.4f}")
    print(f"PG best fit: a={a:.4f} b={b:.5f}  (a>0 means sigma grows with luma -- wrong")
    print(f"             direction if real decreases)")
    print()
    winner = "Zoom 1/luma (shadow-weighted, gamma-domain)" if zoom_rmse < pg_rmse \
        else "Poisson-Gaussian (shot-weighted, linear-domain)"
    print(f"=> the real clip's per-luma noise shape is better matched by: {winner}")
    print("   (this tells us which noise MODEL our synthetic pipeline should use for")
    print("    sRGB-domain low-light denoising -- i.e. whether Zoom's recovered")
    print("    parameters are the right ones for our setting.)")


if __name__ == "__main__":
    main()
