"""exp03 - temporal (frame-difference) noise estimation vs spatial, vs truth.

Question: exp02 found the SPATIAL estimator's a/b split is biased by texture
(texture inflates b, deflates a). Does the TEMPORAL estimator (static content
cancels in y[t]-y[t-1]) recover a/b more faithfully?

Ground truth for our synth noise: Var = clean/peak + read^2 -> a=1/peak, b=read^2.

    python experiments/exp03_temporal_noise_est.py

Reuses exp01's scene + noise.
"""
from __future__ import annotations
import os, sys
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))

from exp01_classical_baseline import make_clean_sequence, add_poisson_gaussian, SEED  # noqa: E402
from classical_denoise import estimate_nlf, estimate_nlf_temporal  # noqa: E402

READ_SIGMA = 0.02
PEAKS = [80.0, 40.0, 20.0, 10.0]


def rel(est, true):
    return f"{est:.4f} ({100*(est-true)/true:+.0f}%)" if true else f"{est:.4f}"


def main():
    rng = np.random.default_rng(SEED)
    clean, static_bg = make_clean_sequence(rng)
    print(f"scene: static bg + moving fg, T={len(clean)}  read_sigma={READ_SIGMA}")
    print("truth: a=1/peak, b=read^2=4.0e-4.  compare a/b recovery (spatial vs temporal)\n")

    print(f"{'peak':>5} {'param':>6} {'true':>9} | {'spatial':>18} | {'temporal':>18}")
    print("-" * 66)
    for peak in PEAKS:
        r = np.random.default_rng(SEED + int(peak))
        noisy = add_poisson_gaussian(clean, r, peak=peak, read_sigma=READ_SIGMA)
        a_t, b_t = 1.0 / peak, READ_SIGMA ** 2

        a_s, b_s = estimate_nlf(noisy[len(noisy) // 2])     # spatial: single frame
        a_v, b_v = estimate_nlf_temporal(noisy)              # temporal: all pairs

        print(f"{peak:>5.0f} {'a':>6} {a_t:>9.4f} | {rel(a_s,a_t):>18} | {rel(a_v,a_t):>18}")
        print(f"{'':5} {'b':>6} {b_t:>9.4f} | {rel(b_s,b_t):>18} | {rel(b_v,b_t):>18}")
        # sigma at three intensities to show the whole curve, not just one point
        for I in (0.2, 0.5, 0.8):
            s_t = np.sqrt(a_t * I + b_t)
            s_s = np.sqrt(max(a_s * I + b_s, 1e-10))
            s_v = np.sqrt(max(a_v * I + b_v, 1e-10))
            print(f"{'':5} {'sig@'+str(I):>6} {s_t:>9.4f} | "
                  f"{rel(s_s,s_t):>18} | {rel(s_v,s_t):>18}")
        print("-" * 66)

    print("\nread: temporal should track a AND b far better (content cancels in the")
    print("frame difference, so texture cannot be mistaken for noise). Spatial trades")
    print("slope for intercept because flat-patch selection still catches some texture.")


if __name__ == "__main__":
    main()
