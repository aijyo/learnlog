"""exp18 - train LIGHTWEIGHT NN denoisers, find the speed/quality frontier.

No external dataset needed: the synthetic pipeline (clean patches + controllable
Poisson-Gaussian noise) generates (noisy, clean) pairs for free. exp15 showed the
105k-param DnCNN beats classical (+3.2dB) but is 206ms/frame on CPU. Here we train
much smaller nets and ask: which is fast enough (~real-time on CPU) AND still beats
the classical bilateral baseline?

    python experiments/exp18_lightweight_nn.py

CPU-only (no CUDA). Caveat: trained on SYNTHETIC content; real-world generalization
needs real clean images or self-supervised training (noted for later).
"""
from __future__ import annotations
import os, sys, time
import numpy as np
import cv2
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nn_denoise import make_clean_patches, add_pg_noise, to_tensor, DnCNN, psnr_t  # noqa: E402
from classical_denoise import spatial_bilateral  # noqa: E402

SEED, PEAK, READ = 20260724, 30.0, 0.03
NTR, NVAL, SIZE = 1024, 64, 64
EPOCHS, BS, LR = 20, 32, 1e-3
MODELS = os.path.join(os.path.dirname(__file__), "..", "models")
os.makedirs(MODELS, exist_ok=True)
VARIANTS = [("tiny", 8, 3), ("small", 16, 4), ("med", 24, 5), ("heavy(exp15)", 48, 7)]


def psnr(a, b):
    m = float(np.mean((np.clip(a, 0, 1) - np.clip(b, 0, 1)) ** 2))
    return 99.0 if m < 1e-12 else 10.0 * np.log10(1.0 / m)


def ssim(a, b):
    C1, C2 = 0.01 ** 2, 0.03 ** 2
    a, b = a.astype(np.float32), b.astype(np.float32)
    ma = cv2.GaussianBlur(a, (11, 11), 1.5); mb = cv2.GaussianBlur(b, (11, 11), 1.5)
    va = cv2.GaussianBlur(a * a, (11, 11), 1.5) - ma * ma
    vb = cv2.GaussianBlur(b * b, (11, 11), 1.5) - mb * mb
    vab = cv2.GaussianBlur(a * b, (11, 11), 1.5) - ma * mb
    s = ((2 * ma * mb + C1) * (2 * vab + C2)) / ((ma * ma + mb * mb + C1) * (va + vb + C2) + 1e-12)
    return float(s.mean())


def train(feat, depth, clean_tr, xcva, xnva, rng, dev):
    torch.manual_seed(SEED)
    net = DnCNN(feat=feat, depth=depth, use_bn=True).to(dev)
    opt = torch.optim.Adam(net.parameters(), lr=LR)
    lossf = torch.nn.MSELoss()
    t0 = time.time()
    for ep in range(EPOCHS):
        net.train()
        idx = rng.permutation(NTR)
        noisy_tr = add_pg_noise(clean_tr, rng, PEAK, READ)
        for i in range(0, NTR, BS):
            b = idx[i:i + BS]
            xc = to_tensor(clean_tr[b]).to(dev); xn = to_tensor(noisy_tr[b]).to(dev)
            opt.zero_grad(); lossf(net(xn), xc).backward(); opt.step()
    return net, time.time() - t0


def cpu_ms(net, dev):
    ft = torch.rand(1, 1, 480, 640).to(dev)
    net.eval()
    with torch.no_grad():
        for _ in range(2): net(ft)                       # warmup
        t = time.time()
        for _ in range(5): net(ft)
    return (time.time() - t) * 1000 / 5


def main():
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    torch.set_num_threads(os.cpu_count() or 4)
    rng = np.random.default_rng(SEED)
    clean_tr = make_clean_patches(NTR, SIZE, rng)
    clean_va = make_clean_patches(NVAL, SIZE, rng); noisy_va = add_pg_noise(clean_va, rng, PEAK, READ)
    xcva, xnva = to_tensor(clean_va).to(dev), to_tensor(noisy_va).to(dev)
    clean_ev = make_clean_patches(64, SIZE, rng); noisy_ev = add_pg_noise(clean_ev, rng, PEAK, READ)

    # classical baseline
    bil = np.stack([spatial_bilateral(noisy_ev[i]) for i in range(64)])
    bil_q = np.mean([psnr(bil[i], clean_ev[i]) for i in range(64)])
    bil_s = np.mean([ssim(bil[i], clean_ev[i]) for i in range(64)])
    t = time.time()
    for _ in range(5): [spatial_bilateral(noisy_ev[i]) for i in range(1)]
    bil_ms = (time.time() - t) * 1000 / 5   # per one 64x64; scale note below
    fr = np.random.rand(480, 640).astype(np.float32)
    t = time.time()
    for _ in range(5): spatial_bilateral(fr)
    bil_ms = (time.time() - t) * 1000 / 5

    print(f"device={dev}  noise=PG(peak={PEAK},read={READ})  eval=64 patches; speed@480x640")
    print(f"{'variant':<16}{'params':>9}{'val-PSNR':>10}{'eval-PSNR':>11}{'SSIM':>8}{'ms/frame':>10}")
    print("-" * 64)
    print(f"{'classical bilat':<16}{'-':>9}{'-':>10}{bil_q:>11.2f}{bil_s:>8.3f}{bil_ms:>10.1f}")
    best = None
    for name, feat, depth in VARIANTS:
        net, secs = train(feat, depth, clean_tr, xcva, xnva, np.random.default_rng(SEED + 1), dev)
        net.eval()
        with torch.no_grad():
            vp = psnr_t(net(xnva), xcva)
            ev = to_tensor(noisy_ev).to(dev); nn_out = net(ev).clamp(0, 1).cpu().numpy()[:, 0]
        eq = np.mean([psnr(nn_out[i], clean_ev[i]) for i in range(64)])
        es = np.mean([ssim(nn_out[i], clean_ev[i]) for i in range(64)])
        ms = cpu_ms(net, dev)
        print(f"{name:<16}{net.n_params():>9,}{vp:>10.2f}{eq:>11.2f}{es:>8.3f}{ms:>10.1f}  ({secs:.0f}s train)")
        torch.save(net.state_dict(), os.path.join(MODELS, f"dncnn_{name.split('(')[0]}.pt"))
        # frontier pick: beats bilateral AND fastest
        if eq > bil_q and (best is None or ms < best[1]):
            best = (name, ms, eq)
    print("-" * 64)
    if best:
        print(f"frontier: '{best[0]}' beats bilateral ({best[2]:.2f} vs {bil_q:.2f} dB) at {best[1]:.1f} ms/frame CPU")
    print("real-time bar ~33ms (30fps). classical bilateral is the speed floor to beat on quality.")


if __name__ == "__main__":
    main()
