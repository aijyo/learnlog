"""exp01 - classical denoise baseline on synthetic Poisson-Gaussian noise.

One question this answers: on a synthetic moving sequence with controllable
noise, how do the classical baselines compare on (a) fidelity (PSNR/SSIM) and
(b) TEMPORAL stability (warping error) -- and does motion-adaptivity beat a
fixed temporal IIR without ghosting?

This is video-denoise's P1 evaluation feedback loop, bootstrapped. Everything is
synthetic (no external data), deterministic (fixed seed), one command to run.

    python experiments/exp01_classical_baseline.py

Metrics discipline (see CLAUDE.md): single-frame quality and temporal stability
are reported SEPARATELY. PSNR/SSIM computed on sRGB [0,1]; warping error uses
Farneback optical flow on the clean frames.
"""
from __future__ import annotations
import os, sys, time
import numpy as np
import cv2

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from classical_denoise import (  # noqa: E402
    spatial_bilateral, spatial_gaussian, FixedTemporalIIR,
    MotionAdaptiveRecursiveDenoiser, run_stream, run_spatial,
)

SEED = 20260721
H, W, T = 240, 320, 40


# --------------------------------------------------------------------------
# Synthetic clean sequence -- the video-call construction: a STATIC detailed
# background (webcam on a desk) + a moving textured foreground object (the
# person). This is the regime that separates the methods:
#   - static bg -> temporal denoising gives a big SNR gain spatial-only can't;
#   - moving fg -> fixed temporal IIR ghosts/trails, motion-adaptive must not.
# `SQ` is the foreground path; the rest of the frame is a fixed background whose
# pixels are truly static (used as the flicker-measurement region).
# --------------------------------------------------------------------------
def _detailed_texture(rng, h, w):
    """Multi-scale texture with real high-frequency detail (so a plain blur is
    NOT a free win)."""
    tex = np.zeros((h, w), np.float32)
    for scale, amp in [(1.0, 0.5), (3.0, 0.8), (8.0, 1.0)]:
        n = rng.standard_normal((h, w)).astype(np.float32)
        tex += amp * cv2.GaussianBlur(n, (0, 0), scale)
    tex = (tex - tex.min()) / (np.ptp(tex) + 1e-6)
    return 0.12 + 0.76 * tex


def make_clean_sequence(rng: np.random.Generator):
    bg = _detailed_texture(rng, H, W)                 # static background
    fg_tex = _detailed_texture(rng, 56, 56) * 0.6 + 0.35  # foreground patch content
    frames = np.empty((T, H, W), np.float32)
    fg_mask = np.zeros((T, H, W), bool)               # where the moving object is
    for t in range(T):
        f = bg.copy()
        sx = 40 + int(5 * t)                          # foreground moves ~5px/frame
        sy = 90 + int(round(1.2 * t))
        f[sy:sy + 56, sx:sx + 56] = fg_tex
        fg_mask[t, sy:sy + 56, sx:sx + 56] = True
        frames[t] = f
    # static-bg region = pixels the foreground NEVER touches across the whole clip
    static_bg = ~fg_mask.any(axis=0)
    return np.clip(frames, 0.0, 1.0), static_bg


def add_poisson_gaussian(clean: np.ndarray, rng: np.random.Generator,
                         peak: float = 40.0, read_sigma: float = 0.02) -> np.ndarray:
    """Signal-dependent noise: shot noise (Poisson, variance ~ signal) + read noise
    (Gaussian). `peak` = photons at white; lower peak = noisier (low-light)."""
    photons = np.clip(clean, 0, 1) * peak
    shot = rng.poisson(photons).astype(np.float32) / peak
    read = rng.normal(0.0, read_sigma, clean.shape).astype(np.float32)
    return np.clip(shot + read, 0.0, 1.0)


# --------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------
def psnr(a: np.ndarray, b: np.ndarray) -> float:
    mse = float(np.mean((a - b) ** 2))
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)


def ssim(a: np.ndarray, b: np.ndarray) -> float:
    """Wang SSIM, gaussian window, global mean over the frame."""
    C1, C2 = 0.01 ** 2, 0.03 ** 2
    a = a.astype(np.float32); b = b.astype(np.float32)
    mu_a = cv2.GaussianBlur(a, (11, 11), 1.5)
    mu_b = cv2.GaussianBlur(b, (11, 11), 1.5)
    va = cv2.GaussianBlur(a * a, (11, 11), 1.5) - mu_a ** 2
    vb = cv2.GaussianBlur(b * b, (11, 11), 1.5) - mu_b ** 2
    vab = cv2.GaussianBlur(a * b, (11, 11), 1.5) - mu_a * mu_b
    s = ((2 * mu_a * mu_b + C1) * (2 * vab + C2)) / \
        ((mu_a ** 2 + mu_b ** 2 + C1) * (va + vb + C2) + 1e-12)
    return float(s.mean())


def bg_flicker(seq: np.ndarray, static_bg: np.ndarray) -> float:
    """Temporal std over the truly-static background pixels, averaged. This is the
    flicker measure: a stable denoiser holds a static pixel constant across time;
    a flickery one does not. Unlike warp error it is NOT gamed by spatial blur."""
    std_t = seq.std(axis=0)               # (H,W) per-pixel temporal std
    return float(std_t[static_bg].mean())


def region_psnr(out: np.ndarray, clean: np.ndarray, mask: np.ndarray) -> float:
    """PSNR restricted to a spatial region (mask over H,W), across all frames."""
    a = out[:, mask]; b = clean[:, mask]
    mse = float(np.mean((a - b) ** 2))
    return 99.0 if mse < 1e-12 else 10.0 * np.log10(1.0 / mse)


def seq_metrics(out, clean, static_bg) -> dict:
    p = np.mean([psnr(out[t], clean[t]) for t in range(len(out))])
    s = np.mean([ssim(out[t], clean[t]) for t in range(len(out))])
    return {"psnr": p, "ssim": s,
            "flicker": bg_flicker(out, static_bg),
            "bg": region_psnr(out, clean, static_bg),     # static-region fidelity (temporal SNR gain)
            "ghost": region_psnr(out, clean, ~static_bg)}  # moving-region fidelity (ghosting)


def main():
    rng = np.random.default_rng(SEED)
    clean, static_bg = make_clean_sequence(rng)
    noisy = add_poisson_gaussian(clean, rng, peak=40.0, read_sigma=0.02)

    print(f"synthetic seq: T={T} {H}x{W}  static bg + moving fg  "
          f"noise=Poisson-Gaussian(peak=40, read=0.02)")
    print(f"static-bg pixels: {static_bg.mean()*100:.0f}% of frame")
    print(f"{'method':<32}{'PSNR':>7}{'bgPSNR':>8}{'fgPSNR':>8}"
          f"{'flicker':>9}{'ms/frm':>8}")
    print(f"{'':32}{'(all)':>7}{'(static)':>8}{'(moving)':>8}"
          f"{'(bg,↓)':>9}{'':>8}")
    print("-" * 72)

    def bench(name, fn):
        t0 = time.perf_counter()
        out = fn()
        ms = (time.perf_counter() - t0) * 1000 / T
        m = seq_metrics(out, clean, static_bg)
        print(f"{name:<32}{m['psnr']:>7.2f}{m['bg']:>8.2f}{m['ghost']:>8.2f}"
              f"{m['flicker']*1e3:>9.2f}{ms:>8.2f}")
        return m

    bench("noisy (input)", lambda: noisy.copy())
    print("-" * 72)

    # spatial-only baselines (single-frame; no temporal SNR gain on static bg)
    bench("spatial gaussian s=1.2", lambda: run_spatial(spatial_gaussian, noisy, sigma=1.2))
    bench("spatial bilateral", lambda: run_spatial(spatial_bilateral, noisy))
    # temporal baselines (streaming). Fixed IIR: strong on bg, ghosts on fg.
    bench("temporal IIR fixed a=0.80", lambda: run_stream(FixedTemporalIIR(0.80), noisy))
    bench("temporal IIR fixed a=0.92", lambda: run_stream(FixedTemporalIIR(0.92), noisy))
    bench("motion-adaptive recursive", lambda: run_stream(MotionAdaptiveRecursiveDenoiser(), noisy))

    print("-" * 72)
    print("story: temporal methods win bgPSNR + flicker (time-averaging on the static")
    print("bg, which spatial-only can't). Fixed IIR a=0.92 = best bg but WORST fgPSNR")
    print("(ghost trail on the moving object). Motion-adaptive aims for high bgPSNR AND")
    print("high fgPSNR -- keep the temporal gain, drop the ghost. That combination is")
    print("exactly what zltCIIRDenoise buys, reconstructed clean-room.")


if __name__ == "__main__":
    main()
