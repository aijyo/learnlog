using System;
using System.Diagnostics;
using System.Linq;
using OpenCvSharp;
using DenoiseDemo;

// Exercises the NATIVE OpenCV binding + our ported DenoiseCore end-to-end in the
// same .NET 9 runtime the WPF app uses. Prints OK if the pipeline runs.
var rng = new Random(1);
var sw = Stopwatch.StartNew();

foreach (var mode in new[] { DenoiseMode.Spatial, DenoiseMode.MotionUniform,
                             DenoiseMode.ProfileNoiseMatched, DenoiseMode.ProfileZoom,
                             DenoiseMode.MotionCompensated,
                             DenoiseMode.ZltGuided, DenoiseMode.ZltIirRecipe,
                             DenoiseMode.TinyNN, DenoiseMode.SmallNN })
{
    var den = new Denoiser { Mode = mode, SigmaMotion = 0.06, AlphaMax = 0.95 };
    double lastMean = 0;
    sw.Restart();
    for (int t = 0; t < 8; t++)
    {
        var buf = new float[120 * 160];
        for (int i = 0; i < buf.Length; i++)
            buf[i] = 0.3f + (float)(rng.NextDouble() - 0.5) * 0.12f;   // flat + noise
        using var m = new Mat(120, 160, MatType.CV_32FC1);
        m.SetArray(buf);
        using var o = den.Process(m);
        o.GetArray(out float[] ob);
        lastMean = ob.Average();
    }
    double ms = sw.Elapsed.TotalMilliseconds / 8;
    Console.WriteLine($"  {mode,-22} out-mean={lastMean:0.000}  {ms:0.00} ms/frame");
}
Console.WriteLine("SMOKE OK: native OpenCV + DenoiseCore run for all modes.");
