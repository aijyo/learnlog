#include "attention_light/attention_light.hpp"

#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace {

struct Frame {
  int width;
  int height;
  std::vector<std::uint8_t> bytes;

  explicit Frame(int w, int h)
      : width(w), height(h), bytes(static_cast<std::size_t>(w) * h * 3 / 2, 128) {}

  attention_light::ConstI420View ConstView() const {
    const std::size_t y_size = static_cast<std::size_t>(width) * height;
    return {bytes.data(), bytes.data() + y_size,
            bytes.data() + y_size + y_size / 4,
            width, width / 2, width / 2, width, height};
  }
  attention_light::I420View View() {
    const std::size_t y_size = static_cast<std::size_t>(width) * height;
    return {bytes.data(), bytes.data() + y_size,
            bytes.data() + y_size + y_size / 4,
            width, width / 2, width / 2, width, height};
  }
};

void MakeSynthetic(Frame& frame, int sequence) {
  auto view = frame.View();
  for (int y = 0; y < frame.height; ++y) {
    for (int x = 0; x < frame.width; ++x) {
      int value = 24 + 55 * x / frame.width + ((x + y + sequence) % 7 - 3);
      const int cx = frame.width / 2 + sequence % 9 - 4;
      const int cy = frame.height / 2;
      const int dx = x - cx;
      const int dy = y - cy;
      if (dx * dx * 9 + dy * dy * 16 < frame.width * frame.width / 7) value += 55;
      view.y[y * view.stride_y + x] = static_cast<std::uint8_t>(std::max(0, std::min(255, value)));
    }
  }
}

bool WritePgm(const std::string& path, const Frame& frame) {
  std::ofstream file(path, std::ios::binary);
  if (!file) return false;
  file << "P5\n" << frame.width << ' ' << frame.height << "\n255\n";
  file.write(reinterpret_cast<const char*>(frame.bytes.data()),
             static_cast<std::streamsize>(frame.width * frame.height));
  return static_cast<bool>(file);
}

struct Options {
  int width = 320;
  int height = 180;
  int frames = 0;
  std::string input;
  std::string output = "attention_light_output.yuv";
  attention_light::ToneGate gate = attention_light::ToneGate::kShadow110;
  std::vector<attention_light::Roi> rois;
};

bool Parse(int argc, char** argv, Options& options) {
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    auto value = [&](const char* name) -> const char* {
      if (i + 1 >= argc) {
        std::cerr << name << " requires a value\n";
        return nullptr;
      }
      return argv[++i];
    };
    if (arg == "--input") { const char* v = value("--input"); if (!v) return false; options.input = v; }
    else if (arg == "--output") { const char* v = value("--output"); if (!v) return false; options.output = v; }
    else if (arg == "--width") { const char* v = value("--width"); if (!v) return false; options.width = std::stoi(v); }
    else if (arg == "--height") { const char* v = value("--height"); if (!v) return false; options.height = std::stoi(v); }
    else if (arg == "--frames") { const char* v = value("--frames"); if (!v) return false; options.frames = std::stoi(v); }
    else if (arg == "--gate") { const char* v = value("--gate"); if (!v) return false; options.gate = std::stoi(v) == 160 ? attention_light::ToneGate::kShadow160 : attention_light::ToneGate::kShadow110; }
    else if (arg == "--roi") {
      if (i + 4 >= argc) { std::cerr << "--roi requires left top right bottom\n"; return false; }
      attention_light::Roi roi;
      roi.left = std::stof(argv[++i]); roi.top = std::stof(argv[++i]);
      roi.right = std::stof(argv[++i]); roi.bottom = std::stof(argv[++i]);
      options.rois.push_back(roi);
    } else if (arg == "--help") {
      std::cout << "attention_light_demo [--input in.yuv --output out.yuv --width W --height H]\n"
                   "                     [--frames N] [--gate 110|160] [--roi l t r b]\n";
      return false;
    } else {
      std::cerr << "unknown argument: " << arg << '\n';
      return false;
    }
  }
  return true;
}

}  // namespace

int main(int argc, char** argv) {
  Options options;
  if (!Parse(argc, argv, options)) return argc == 2 && std::string(argv[1]) == "--help" ? 0 : 2;
  if ((options.width & 1) || (options.height & 1) || options.width < 64) {
    std::cerr << "invalid dimensions\n";
    return 2;
  }
  if (options.rois.empty()) options.rois.push_back({0.32F, 0.18F, 0.68F, 0.82F, 1.0F});

  attention_light::Config config;
  config.tone_gate = options.gate;
  attention_light::AttentionLight filter(config);
  Frame input(options.width, options.height);
  Frame output(options.width, options.height);
  std::ifstream source;
  const bool synthetic = options.input.empty();
  if (!synthetic) {
    source.open(options.input, std::ios::binary);
    if (!source) { std::cerr << "cannot open input\n"; return 1; }
  }
  std::ofstream destination(options.output, std::ios::binary);
  if (!destination) { std::cerr << "cannot open output\n"; return 1; }

  int frame_index = 0;
  double elapsed_ms = 0.0;
  while (options.frames <= 0 || frame_index < options.frames) {
    if (synthetic) {
      if (frame_index >= (options.frames > 0 ? options.frames : 24)) break;
      MakeSynthetic(input, frame_index);
    } else {
      source.read(reinterpret_cast<char*>(input.bytes.data()),
                  static_cast<std::streamsize>(input.bytes.size()));
      if (source.gcount() != static_cast<std::streamsize>(input.bytes.size())) break;
    }
    const auto begin = std::chrono::steady_clock::now();
    std::string error;
    if (!filter.Process(input.ConstView(), output.View(), options.rois, &error)) {
      std::cerr << "process failed: " << error << '\n';
      return 1;
    }
    elapsed_ms += std::chrono::duration<double, std::milli>(
                      std::chrono::steady_clock::now() - begin).count();
    destination.write(reinterpret_cast<const char*>(output.bytes.data()),
                      static_cast<std::streamsize>(output.bytes.size()));
    if (synthetic && frame_index == 0) {
      WritePgm("attention_light_input.pgm", input);
      WritePgm("attention_light_output.pgm", output);
    }
    ++frame_index;
  }

  const auto& d = filter.GetDiagnostics();
  std::cout << "frames=" << frame_index << " avg_ms="
            << (frame_index ? elapsed_ms / frame_index : 0.0)
            << " black=" << d.black_point << " white=" << d.white_point
            << " key=" << d.exposure_key << " roi_mean=" << d.selected_roi_mean
            << " output=" << options.output << '\n';
  return frame_index > 0 ? 0 : 1;
}
