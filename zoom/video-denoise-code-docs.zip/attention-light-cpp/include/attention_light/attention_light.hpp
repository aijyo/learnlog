#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace attention_light {

struct Roi {
  float left = 0.0F;
  float top = 0.0F;
  float right = 0.0F;
  float bottom = 0.0F;
  float confidence = 1.0F;
};

struct ConstI420View {
  const std::uint8_t* y = nullptr;
  const std::uint8_t* u = nullptr;
  const std::uint8_t* v = nullptr;
  int stride_y = 0;
  int stride_u = 0;
  int stride_v = 0;
  int width = 0;
  int height = 0;
};

struct I420View {
  std::uint8_t* y = nullptr;
  std::uint8_t* u = nullptr;
  std::uint8_t* v = nullptr;
  int stride_y = 0;
  int stride_u = 0;
  int stride_v = 0;
  int width = 0;
  int height = 0;
};

enum class ToneGate {
  kShadow110 = 0,
  kShadow160 = 1,
};

struct Config {
  bool enabled = true;
  bool use_roi_exposure = true;
  ToneGate tone_gate = ToneGate::kShadow110;
  int transition_frames = 64;
};

struct Diagnostics {
  double black_point = 4.0;
  double white_point = 251.0;
  double exposure_key = 600.0;
  double selected_roi_mean = 0.0;
  double selected_roi_geometric_mean = 0.0;
  float transition = 1.0F;
  int selected_roi = -1;
  int processed_frames = 0;
};

class AttentionLight final {
 public:
  explicit AttentionLight(Config config = {});

  void SetConfig(const Config& config);
  const Config& GetConfig() const noexcept { return config_; }
  void SetEnabled(bool enabled);
  void Reset();

  // 输入和输出允许指向同一帧。宽高必须为偶数且不小于 64x2。
  bool Process(const ConstI420View& input,
               const I420View& output,
               const std::vector<Roi>& rois = {},
               std::string* error = nullptr);

  const Diagnostics& GetDiagnostics() const noexcept { return diagnostics_; }
  const std::array<std::uint16_t, 256>& GetGainLutQ8() const noexcept {
    return gain_lut_q8_;
  }

 private:
  struct HistogramStats {
    int black = 4;
    int white = 251;
    int geometric_mean = 0;
    std::uint64_t samples = 0;
  };

  bool Validate(const ConstI420View& input,
                const I420View& output,
                std::string* error) const;
  void EnsureSize(int width, int height);
  void CopyFrame(const ConstI420View& input, const I420View& output) const;
  void BuildStableLuma(const ConstI420View& input);
  HistogramStats AnalyzeHistogram(const std::vector<float>& luma,
                                  int width,
                                  int height,
                                  int stride,
                                  int x,
                                  int y,
                                  int roi_width,
                                  int roi_height) const;
  void UpdateToneCurve(const std::vector<Roi>& rois);
  void BuildGainLut();
  void BuildRgbGuides(const ConstI420View& input);
  void BoxMean(const std::vector<float>& input,
               int radius,
               std::vector<float>& output);
  void BuildGuidedIllumination();
  void BuildLocalGain();
  void ApplyTileProtection();
  void Reconstruct(const ConstI420View& input, const I420View& output);

  static float Clamp01(float value);
  static std::uint8_t ClampByte(float value);

  Config config_{};
  Diagnostics diagnostics_{};
  int width_ = 0;
  int height_ = 0;
  int processed_frames_ = 0;
  int transition_position_ = 64;
  bool target_enabled_ = true;
  bool tone_initialized_ = false;
  bool has_history_ = false;

  double black_point_ = 4.0;
  double white_point_ = 251.0;
  double exposure_key_ = 600.0;
  std::array<std::uint16_t, 256> gain_lut_q8_{};

  std::vector<float> stable_y_;
  std::vector<float> previous_y_;
  std::vector<float> box3_;
  std::vector<float> box5_;
  std::vector<float> guide_r_;
  std::vector<float> guide_g_;
  std::vector<float> guide_b_;
  std::vector<float> guided_illumination_;
  std::vector<float> gain_q7_;
  std::vector<float> scratch_a_;
  std::vector<float> scratch_b_;
  std::vector<float> horizontal_sums_;
};

}  // namespace attention_light
