#include "attention_light/attention_light.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>

namespace {

struct Frame {
  int width;
  int height;
  std::vector<std::uint8_t> bytes;
  Frame(int w, int h, std::uint8_t y) : width(w), height(h), bytes(static_cast<std::size_t>(w) * h * 3 / 2, 128) {
    std::fill(bytes.begin(), bytes.begin() + static_cast<std::size_t>(w) * h, y);
  }
  attention_light::ConstI420View ConstView() const {
    const std::size_t ys = static_cast<std::size_t>(width) * height;
    return {bytes.data(), bytes.data() + ys, bytes.data() + ys + ys / 4,
            width, width / 2, width / 2, width, height};
  }
  attention_light::I420View View() {
    const std::size_t ys = static_cast<std::size_t>(width) * height;
    return {bytes.data(), bytes.data() + ys, bytes.data() + ys + ys / 4,
            width, width / 2, width / 2, width, height};
  }
};

double MeanY(const Frame& frame) {
  const std::size_t count = static_cast<std::size_t>(frame.width) * frame.height;
  double sum = 0.0;
  for (std::size_t i = 0; i < count; ++i) sum += frame.bytes[i];
  return sum / count;
}

std::uint64_t Difference(const Frame& a, const Frame& b) {
  std::uint64_t sum = 0;
  for (std::size_t i = 0; i < a.bytes.size(); ++i) {
    sum += static_cast<std::uint64_t>(std::abs(static_cast<int>(a.bytes[i]) - b.bytes[i]));
  }
  return sum;
}

Frame LimitedRangeBaseline(const Frame& input) {
  Frame result = input;
  const std::size_t y_size = static_cast<std::size_t>(input.width) * input.height;
  for (std::size_t i = 0; i < y_size; ++i) result.bytes[i] = (225 * input.bytes[i]) >> 8;
  for (std::size_t i = y_size; i < y_size + y_size / 4; ++i)
    result.bytes[i] = static_cast<std::uint8_t>(((234 * input.bytes[i]) >> 8) + 14);
  for (std::size_t i = y_size + y_size / 4; i < result.bytes.size(); ++i)
    result.bytes[i] = static_cast<std::uint8_t>(((234 * input.bytes[i]) >> 8) + 11);
  return result;
}

bool Check(bool condition, const char* message) {
  if (!condition) std::cerr << "FAIL: " << message << '\n';
  return condition;
}

}  // namespace

int main() {
  bool ok = true;
  {
    attention_light::AttentionLight filter;
    Frame input(128, 96, 48), output(128, 96, 0);
    for (int y = 24; y < 72; ++y)
      for (int x = 42; x < 86; ++x) input.bytes[static_cast<std::size_t>(y) * 128 + x] = 112;
    std::string error;
    ok &= Check(filter.Process(input.ConstView(), output.View(), {{0.32F, 0.24F, 0.68F, 0.76F}}, &error), error.c_str());
    ok &= Check(MeanY(output) < MeanY(input),
                "shadow gate should attenuate this mixed dark scene");
    for (const auto gain : filter.GetGainLutQ8())
      ok &= Check(gain >= 200 && gain <= 510, "gain LUT must remain in recovered bounds");
  }
  {
    attention_light::AttentionLight filter;
    Frame input(128, 96, 253), output(128, 96, 0);
    ok &= Check(filter.Process(input.ConstView(), output.View(), {}, nullptr), "white frame process");
    ok &= Check(std::fabs(MeanY(output) - 253.0) < 0.1, "near-white tiles must be protected");
  }
  {
    attention_light::AttentionLight filter;
    Frame input(128, 96, 20), output(128, 96, 0);
    filter.Process(input.ConstView(), output.View(), {{0.0F, 0.0F, 1.0F, 1.0F}}, nullptr);
    ok &= Check(std::fabs(filter.GetDiagnostics().black_point - 16.0) < 0.1,
                "black point should use the lowest occupied run and clamp to 16");
  }
  {
    attention_light::AttentionLight filter;
    Frame input(128, 96, 0), output(128, 96, 0);
    const std::size_t pixels = static_cast<std::size_t>(input.width) * input.height;
    std::fill(input.bytes.begin() + pixels / 2, input.bytes.begin() + pixels, 64);
    filter.Process(input.ConstView(), output.View(), {{0.0F, 0.0F, 1.0F, 1.0F}}, nullptr);
    ok &= Check(std::fabs(filter.GetDiagnostics().selected_roi_geometric_mean - 64.0) < 0.1,
                "geometric mean should exclude zero-valued samples");
  }
  {
    attention_light::AttentionLight filter;
    Frame input(128, 96, 64), output(128, 96, 0);
    input.bytes[0] = 240;
    filter.Process(input.ConstView(), output.View(), {{0.0F, 0.0F, 1.0F, 1.0F}}, nullptr);
    ok &= Check(std::fabs(filter.GetDiagnostics().white_point - 230.0) < 0.1,
                "isolated highlights must not raise the body white point");
  }
  {
    attention_light::Config config;
    config.transition_frames = 4;
    attention_light::AttentionLight filter(config);
    Frame input(128, 96, 64), output(128, 96, 0);
    const Frame baseline = LimitedRangeBaseline(input);
    filter.Process(input.ConstView(), output.View(), {}, nullptr);
    filter.SetEnabled(false);
    std::uint64_t previous = Difference(baseline, output);
    for (int i = 0; i < 4; ++i) {
      filter.Process(input.ConstView(), output.View(), {}, nullptr);
      const std::uint64_t current = Difference(baseline, output);
      ok &= Check(current <= previous, "disable transition must be monotonic");
      previous = current;
    }
    ok &= Check(previous == 0, "disabled output must end at the limited-range baseline");
  }
  {
    attention_light::AttentionLight filter_a;
    attention_light::AttentionLight filter_b;
    Frame source(128, 96, 72), out(128, 96, 0), in_place = source;
    filter_a.Process(source.ConstView(), out.View(), {}, nullptr);
    filter_b.Process(in_place.ConstView(), in_place.View(), {}, nullptr);
    ok &= Check(out.bytes == in_place.bytes, "in-place and out-of-place results must match");
  }
  if (ok) std::cout << "all attention-light tests passed\n";
  return ok ? 0 : 1;
}
