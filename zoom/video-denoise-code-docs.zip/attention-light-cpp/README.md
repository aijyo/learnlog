# AttentionLight C++ 功能模型

无外部依赖的 C++17 I420 局部曝光增强模块。实现保留已确认的主要机制与参数：

- ROI 曝光统计和 256-bin 直方图；
- 连续亮度 run 黑白点、孤立高光抑制和排除零值的几何均值；
- 对数增益 LUT，Q8 范围 `200..510`；
- 曲线参数 `1/32` 时域平滑；
- `77/179` 历史亮度预稳；
- 3×3、5×5 照明平面；
- 7×7 三通道局部线性导向模型，`eps=25`；
- 16×16 黑/白块保护；
- Y 增强、U/V 联动补偿和 64 帧启停渐变。

## 构建

```powershell
cmd /c 'call "D:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" && cmake -S . -B build-ninja -G Ninja -DCMAKE_BUILD_TYPE=Release'
cmake --build build-ninja
ctest --test-dir build-ninja --output-on-failure
```

MSVC 下固定使用 `/MT`，生成的 Demo 不依赖 OpenCV。

## 合成演示

```powershell
.\build-ninja\attention_light_demo.exe
```

当前目录会生成：

- `attention_light_output.yuv`
- `attention_light_input.pgm`
- `attention_light_output.pgm`

## 处理真实 I420

```powershell
.\build-ninja\attention_light_demo.exe `
  --input input_640x480.yuv --output output.yuv `
  --width 640 --height 480 --frames 100 `
  --roi 0.30 0.15 0.70 0.85
```

`--roi` 使用归一化的 `left top right bottom`，可重复传入。没有 ROI 时仍会生成稳定的默认曲线，但不会启用 ROI 曝光偏置。

## 接口

```cpp
attention_light::AttentionLight filter;
filter.Process(input_view, output_view, rois, &error);
```

输入输出可以指向同一块 I420 内存。对于视频流，应复用同一个 `AttentionLight` 对象，才能保留曲线和亮度历史状态。

## IDA 启动环境

不要使用全局 Python。辅助脚本复用了原 `startup.ps1` 的 Python 3.9 设置：

```powershell
.\tools\start_ida_attentionlight.ps1
```

无界面启动可增加 `-Headless`。2026-08-07 已用该环境实测 `ida64.exe` 返回码为 `0`。

## 当前实测

- 七组行为测试通过：阴影门控、近白 tile 保护、精确黑点、零值排除几何均值、孤立高光白点、启停渐变、原地/分离处理一致性；
- 标量 Release 版处理 640×360 合成 I420：约 `22.9 ms/帧`；
- `dumpbin /DEPENDENTS`：仅 `KERNEL32.dll`，确认 `/MT` 静态运行库。

## 精度边界

这是原创的功能模型，不复用厂商代码。全局曲线、黑白点统计、窗口、阈值、Q8→Q7 写回、色度补偿、四平面类内接线和渐变基线均已按可复核公式实现。尚未完全确认的是 ROI/第四平面的具体上游生产组件及各向量后端的逐指令舍入，因此仍不宣称整链逐像素一致。
