#include "attention_light/attention_light.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>
#include <numeric>

namespace attention_light {
namespace {

constexpr float kCovarianceEpsilon = 25.0F;
constexpr int kTileSize = 16;

int ClampInt(int value, int low, int high) {
  return std::max(low, std::min(value, high));
}

float ClampFloat(float value, float low, float high) {
  return std::max(low, std::min(value, high));
}

}  // namespace

AttentionLight::AttentionLight(Config config) : config_(config) {
  config_.transition_frames = std::max(1, config_.transition_frames);
  target_enabled_ = config_.enabled;
  transition_position_ = target_enabled_ ? config_.transition_frames : 0;
  BuildGainLut();
}

void AttentionLight::SetConfig(const Config& config) {
  const bool old_target = target_enabled_;
  config_ = config;
  config_.transition_frames = std::max(1, config_.transition_frames);
  target_enabled_ = config_.enabled;
  if (old_target == target_enabled_) {
    transition_position_ = ClampInt(transition_position_, 0, config_.transition_frames);
  }
}

void AttentionLight::SetEnabled(bool enabled) {
  config_.enabled = enabled;
  target_enabled_ = enabled;
}

void AttentionLight::Reset() {
  width_ = 0;
  height_ = 0;
  processed_frames_ = 0;
  transition_position_ = target_enabled_ ? config_.transition_frames : 0;
  tone_initialized_ = false;
  has_history_ = false;
  black_point_ = 4.0;
  white_point_ = 251.0;
  exposure_key_ = 600.0;
  diagnostics_ = {};
  stable_y_.clear();
  previous_y_.clear();
  box3_.clear();
  box5_.clear();
  guide_r_.clear();
  guide_g_.clear();
  guide_b_.clear();
  guided_illumination_.clear();
  gain_q7_.clear();
  scratch_a_.clear();
  scratch_b_.clear();
  horizontal_sums_.clear();
  BuildGainLut();
}

bool AttentionLight::Validate(const ConstI420View& input,
                              const I420View& output,
                              std::string* error) const {
  auto fail = [&](const char* text) {
    if (error != nullptr) {
      *error = text;
    }
    return false;
  };
  if (input.y == nullptr || input.u == nullptr || input.v == nullptr ||
      output.y == nullptr || output.u == nullptr || output.v == nullptr) {
    return fail("I420 plane pointer is null");
  }
  if (input.width != output.width || input.height != output.height) {
    return fail("input/output dimensions differ");
  }
  if (input.width < 64 || input.height < 2 || (input.width & 1) != 0 ||
      (input.height & 1) != 0) {
    return fail("dimensions must be even and at least 64x2");
  }
  if (input.stride_y < input.width || input.stride_u < input.width / 2 ||
      input.stride_v < input.width / 2 || output.stride_y < output.width ||
      output.stride_u < output.width / 2 || output.stride_v < output.width / 2) {
    return fail("plane stride is smaller than plane width");
  }
  return true;
}

void AttentionLight::EnsureSize(int width, int height) {
  if (width_ == width && height_ == height) {
    return;
  }
  width_ = width;
  height_ = height;
  const std::size_t count = static_cast<std::size_t>(width) * height;
  stable_y_.assign(count, 0.0F);
  previous_y_.assign(count, 0.0F);
  box3_.assign(count, 0.0F);
  box5_.assign(count, 0.0F);
  guide_r_.assign(count, 0.0F);
  guide_g_.assign(count, 0.0F);
  guide_b_.assign(count, 0.0F);
  guided_illumination_.assign(count, 0.0F);
  gain_q7_.assign(count, 128.0F);
  scratch_a_.assign(count, 0.0F);
  scratch_b_.assign(count, 0.0F);
  horizontal_sums_.assign(count, 0.0F);
  has_history_ = false;
  tone_initialized_ = false;
}

void AttentionLight::CopyFrame(const ConstI420View& input,
                               const I420View& output) const {
  for (int y = 0; y < input.height; ++y) {
    std::memmove(output.y + y * output.stride_y,
                 input.y + y * input.stride_y,
                 static_cast<std::size_t>(input.width));
  }
  for (int y = 0; y < input.height / 2; ++y) {
    std::memmove(output.u + y * output.stride_u,
                 input.u + y * input.stride_u,
                 static_cast<std::size_t>(input.width / 2));
    std::memmove(output.v + y * output.stride_v,
                 input.v + y * input.stride_v,
                 static_cast<std::size_t>(input.width / 2));
  }
}

void AttentionLight::BuildStableLuma(const ConstI420View& input) {
  for (int y = 0; y < height_; ++y) {
    const auto* row = input.y + y * input.stride_y;
    for (int x = 0; x < width_; ++x) {
      const std::size_t i = static_cast<std::size_t>(y) * width_ + x;
      const int current = row[x];
      float stable = static_cast<float>(current);
      if (has_history_ && current >= 14 && current <= 241) {
        stable = static_cast<float>((77 * current +
                                     179 * static_cast<int>(previous_y_[i]) +
                                     128) >>
                                    8);
      }
      stable_y_[i] = stable;
    }
  }
  previous_y_ = stable_y_;
  has_history_ = true;
}

AttentionLight::HistogramStats AttentionLight::AnalyzeHistogram(
    const std::vector<float>& luma,
    int width,
    int height,
    int stride,
    int x0,
    int y0,
    int roi_width,
    int roi_height) const {
  HistogramStats result;
  std::array<std::uint64_t, 256> histogram{};
  const int x1 = ClampInt(x0 + roi_width, 0, width);
  const int y1 = ClampInt(y0 + roi_height, 0, height);
  x0 = ClampInt(x0, 0, width);
  y0 = ClampInt(y0, 0, height);
  const int roi_w = x1 - x0;
  const int roi_h = y1 - y0;
  const int smallest = std::min(roi_w, roi_h);
  const int largest = std::max(roi_w, roi_h);
  int sample_step = 1;
  if (largest >= 1280 && smallest >= 720) sample_step = 8;
  else if (largest >= 640 && smallest >= 360) sample_step = 4;
  else if (largest >= 320 && smallest >= 180) sample_step = 2;

  double log_sum = 0.0;
  std::uint64_t nonzero_samples = 0;
  for (int y = y0; y < y1; y += sample_step) {
    for (int x = x0; x < x1; x += sample_step) {
      const int value = ClampInt(static_cast<int>(std::lround(
                                     luma[static_cast<std::size_t>(y) * stride + x])),
                                 0, 255);
      ++histogram[static_cast<std::size_t>(value)];
      if (value != 0) {
        log_sum += std::log(static_cast<double>(value));
        ++nonzero_samples;
      }
      ++result.samples;
    }
  }
  if (result.samples == 0) {
    return result;
  }

  std::array<int, 256> boundaries{};
  std::array<std::uint64_t, 128> run_samples{};
  int boundary_count = 0;
  int run_count = 0;
  bool inside_run = false;
  for (int level = 255; level >= 0; --level) {
    const std::uint64_t count = histogram[static_cast<std::size_t>(level)];
    if (!inside_run) {
      if (count == 0) continue;
      boundaries[static_cast<std::size_t>(boundary_count++)] = level;
      run_samples[static_cast<std::size_t>(run_count++)] = count;
      inside_run = true;
    } else if (count != 0) {
      run_samples[static_cast<std::size_t>(run_count - 1)] += count;
    } else {
      boundaries[static_cast<std::size_t>(boundary_count++)] = level;
      inside_run = false;
    }
  }

  result.black = (boundary_count & 1) != 0
                     ? 0
                     : ClampInt(boundaries[static_cast<std::size_t>(boundary_count - 1)] + 1,
                                0, 16);

  int selected_run = 0;
  if (run_count > 1) {
    std::uint64_t accumulated = 0;
    for (int i = 0; i < run_count - 1; ++i) {
      accumulated += run_samples[static_cast<std::size_t>(i)];
      if (accumulated > (result.samples >> 10)) break;
      ++selected_run;
    }
  }
  selected_run = ClampInt(selected_run, 0, std::max(0, run_count - 1));
  bool isolated_highlight = false;
  for (int i = 0; i <= selected_run && 2 * i + 2 < boundary_count; ++i) {
    const int run_width = boundaries[static_cast<std::size_t>(2 * i)] -
                          boundaries[static_cast<std::size_t>(2 * i + 1)];
    const int gap_width = boundaries[static_cast<std::size_t>(2 * i + 1)] -
                          boundaries[static_cast<std::size_t>(2 * i + 2)];
    if (2 * gap_width > 3 * run_width) isolated_highlight = true;
  }
  int white = boundaries[0];
  if (isolated_highlight) {
    white = boundaries[static_cast<std::size_t>(2 * selected_run)];
  }
  white = std::max(32, white);
  std::uint64_t peak_samples = 0;
  for (int level = std::max(0, white - 15); level <= white; ++level) {
    peak_samples += histogram[static_cast<std::size_t>(level)];
  }
  const std::uint64_t sample_unit = std::max<std::uint64_t>(1, result.samples >> 8);
  if (peak_samples > 4 * sample_unit) {
    white += static_cast<int>(std::min<std::uint64_t>(peak_samples / sample_unit, 48));
  }
  result.white = ClampInt(white, 230, 255);
  result.geometric_mean = nonzero_samples == 0
                              ? 0
                              : ClampInt(static_cast<int>(
                                             std::lround(std::exp(log_sum / nonzero_samples))),
                                         0, 255);
  return result;
}

void AttentionLight::UpdateToneCurve(const std::vector<Roi>& rois) {
  const HistogramStats full =
      AnalyzeHistogram(stable_y_, width_, height_, width_, 0, 0, width_, height_);

  double next_black = 4.0;
  double next_white = 251.0;
  double next_key = 600.0;
  int selected = -1;
  double selected_mean = 0.0;
  double selected_geometric = 0.0;

  if (config_.use_roi_exposure && !rois.empty()) {
    std::vector<int> order(rois.size());
    std::iota(order.begin(), order.end(), 0);
    std::stable_sort(order.begin(), order.end(), [&](int a, int b) {
      const Roi& ra = rois[static_cast<std::size_t>(a)];
      const Roi& rb = rois[static_cast<std::size_t>(b)];
      return (ra.right - ra.left) * (ra.bottom - ra.top) >
             (rb.right - rb.left) * (rb.bottom - rb.top);
    });
    if (order.size() > 2) order.resize(2);

    for (const int index : order) {
      const Roi& roi = rois[static_cast<std::size_t>(index)];
      int left = ClampInt(static_cast<int>(std::floor(roi.left * width_)), 0, width_ - 1);
      int right = ClampInt(static_cast<int>(std::ceil(roi.right * width_)), left + 1, width_);
      int top = ClampInt(static_cast<int>(std::floor(roi.top * height_)), 0, height_ - 1);
      int bottom = ClampInt(static_cast<int>(std::ceil(roi.bottom * height_)), top + 1, height_);

      // 只统计 ROI 中央横带，减少头发、衣服和背景对人脸曝光的污染。
      const int roi_h = bottom - top;
      const int band_top = top + roi_h / 4;
      const int band_bottom = bottom - roi_h / 4;
      double sum = 0.0;
      std::uint64_t count = 0;
      for (int y = band_top; y < band_bottom; ++y) {
        for (int x = left; x < right; ++x) {
          sum += stable_y_[static_cast<std::size_t>(y) * width_ + x];
          ++count;
        }
      }
      const double mean = count == 0 ? 0.0 : sum / count;
      if (mean > selected_mean) {
        selected_mean = mean;
        selected = index;
        const HistogramStats roi_stats = AnalyzeHistogram(
            stable_y_, width_, height_, width_, left, top, right - left, bottom - top);
        selected_geometric = roi_stats.geometric_mean;
      }
    }

    if (selected >= 0 && selected_mean >= 10.0 && selected_geometric > 0.0) {
      next_black = full.black;
      next_white = std::max(static_cast<double>(full.white),
                            std::min(255.0, 2.0 * selected_geometric));
      const double candidate = (600.0 + 3.0 * selected_geometric) / 4.0;
      if (candidate > 120.0) {
        next_key = candidate >= 150.0 ? 10.0 * (candidate - 123.0)
                                      : 5.0 * (candidate - 96.0);
      }
      next_key = std::max(64.0, std::min(900.0, next_key));
    }
  }

  if (!tone_initialized_) {
    black_point_ = next_black;
    white_point_ = next_white;
    exposure_key_ = next_key;
    tone_initialized_ = true;
  } else {
    constexpr double kNewWeight = 1.0 / 32.0;
    black_point_ += (next_black - black_point_) * kNewWeight;
    white_point_ += (next_white - white_point_) * kNewWeight;
    exposure_key_ += (next_key - exposure_key_) * kNewWeight;
  }

  diagnostics_.black_point = black_point_;
  diagnostics_.white_point = white_point_;
  diagnostics_.exposure_key = exposure_key_;
  diagnostics_.selected_roi = selected;
  diagnostics_.selected_roi_mean = selected_mean;
  diagnostics_.selected_roi_geometric_mean = selected_geometric;
}

void AttentionLight::BuildGainLut() {
  const double scale = std::max(1.0, exposure_key_ * 1.8);
  const double denominator =
      std::log1p(white_point_ / scale) - std::log1p(black_point_ / scale);
  for (int i = 0; i < 256; ++i) {
    if (i == 0) {
      gain_lut_q8_[0] = 200;
      continue;
    }
    double tone = denominator <= std::numeric_limits<double>::epsilon()
                      ? static_cast<double>(i) / 255.0
                      : (std::log1p(i / scale) - std::log1p(black_point_ / scale)) /
                            denominator;
    tone = std::max(0.0, std::min(1.0, tone));
    const int mapped = ClampInt(static_cast<int>(std::lround(255.0 * tone)), 0, 255);
    gain_lut_q8_[static_cast<std::size_t>(i)] = static_cast<std::uint16_t>(
        ClampInt((mapped << 8) / i, 200, 510));
  }
}

void AttentionLight::BuildRgbGuides(const ConstI420View& input) {
  for (int y = 0; y < height_; ++y) {
    const auto* u_row = input.u + (y / 2) * input.stride_u;
    const auto* v_row = input.v + (y / 2) * input.stride_v;
    for (int x = 0; x < width_; ++x) {
      const std::size_t i = static_cast<std::size_t>(y) * width_ + x;
      const float yy = 1.164383F * (stable_y_[i] - 16.0F);
      const float uu = static_cast<float>(u_row[x / 2]) - 128.0F;
      const float vv = static_cast<float>(v_row[x / 2]) - 128.0F;
      guide_r_[i] = ClampFloat(yy + 1.596027F * vv, 0.0F, 255.0F);
      guide_g_[i] = ClampFloat(yy - 0.391762F * uu - 0.812968F * vv, 0.0F, 255.0F);
      guide_b_[i] = ClampFloat(yy + 2.017232F * uu, 0.0F, 255.0F);
    }
  }
}

void AttentionLight::BoxMean(const std::vector<float>& input,
                             int radius,
                             std::vector<float>& output) {
  for (int y = 0; y < height_; ++y) {
    float sum = 0.0F;
    for (int x = -radius; x <= radius; ++x) {
      sum += input[static_cast<std::size_t>(y) * width_ + ClampInt(x, 0, width_ - 1)];
    }
    for (int x = 0; x < width_; ++x) {
      horizontal_sums_[static_cast<std::size_t>(y) * width_ + x] = sum;
      const int remove_x = ClampInt(x - radius, 0, width_ - 1);
      const int add_x = ClampInt(x + radius + 1, 0, width_ - 1);
      sum += input[static_cast<std::size_t>(y) * width_ + add_x] -
             input[static_cast<std::size_t>(y) * width_ + remove_x];
    }
  }
  const float norm = 1.0F / static_cast<float>((2 * radius + 1) * (2 * radius + 1));
  for (int x = 0; x < width_; ++x) {
    float sum = 0.0F;
    for (int y = -radius; y <= radius; ++y) {
      sum += horizontal_sums_[static_cast<std::size_t>(ClampInt(y, 0, height_ - 1)) *
                              width_ + x];
    }
    for (int y = 0; y < height_; ++y) {
      output[static_cast<std::size_t>(y) * width_ + x] = sum * norm;
      const int remove_y = ClampInt(y - radius, 0, height_ - 1);
      const int add_y = ClampInt(y + radius + 1, 0, height_ - 1);
      sum += horizontal_sums_[static_cast<std::size_t>(add_y) * width_ + x] -
             horizontal_sums_[static_cast<std::size_t>(remove_y) * width_ + x];
    }
  }
}

void AttentionLight::BuildGuidedIllumination() {
  const std::size_t count = stable_y_.size();
  std::vector<float> mean_r(count), mean_g(count), mean_b(count), mean_p(count);
  std::vector<float> mean_rr(count), mean_gg(count), mean_bb(count);
  std::vector<float> mean_rg(count), mean_rb(count), mean_gb(count);
  std::vector<float> mean_rp(count), mean_gp(count), mean_bp(count);

  BoxMean(guide_r_, 3, mean_r);
  BoxMean(guide_g_, 3, mean_g);
  BoxMean(guide_b_, 3, mean_b);
  BoxMean(box5_, 3, mean_p);

  const auto product_mean = [&](const std::vector<float>& a,
                                const std::vector<float>& b,
                                std::vector<float>& destination) {
    for (std::size_t i = 0; i < count; ++i) scratch_a_[i] = a[i] * b[i];
    BoxMean(scratch_a_, 3, destination);
  };
  product_mean(guide_r_, guide_r_, mean_rr);
  product_mean(guide_g_, guide_g_, mean_gg);
  product_mean(guide_b_, guide_b_, mean_bb);
  product_mean(guide_r_, guide_g_, mean_rg);
  product_mean(guide_r_, guide_b_, mean_rb);
  product_mean(guide_g_, guide_b_, mean_gb);
  product_mean(guide_r_, box5_, mean_rp);
  product_mean(guide_g_, box5_, mean_gp);
  product_mean(guide_b_, box5_, mean_bp);

  for (std::size_t i = 0; i < count; ++i) {
    const float rr = mean_rr[i] - mean_r[i] * mean_r[i] + kCovarianceEpsilon;
    const float gg = mean_gg[i] - mean_g[i] * mean_g[i] + kCovarianceEpsilon;
    const float bb = mean_bb[i] - mean_b[i] * mean_b[i] + kCovarianceEpsilon;
    const float rg = mean_rg[i] - mean_r[i] * mean_g[i];
    const float rb = mean_rb[i] - mean_r[i] * mean_b[i];
    const float gb = mean_gb[i] - mean_g[i] * mean_b[i];
    const float rp = mean_rp[i] - mean_r[i] * mean_p[i];
    const float gp = mean_gp[i] - mean_g[i] * mean_p[i];
    const float bp = mean_bp[i] - mean_b[i] * mean_p[i];
    const float covariance_peak = std::max({std::fabs(rp), std::fabs(gp), std::fabs(bp)});
    const float window_sum = mean_p[i] * 49.0F;

    float q = mean_p[i];
    if (window_sum >= 393.0F && window_sum <= 11906.0F &&
        covariance_peak > 1499.0F) {
      const float c00 = gg * bb - gb * gb;
      const float c01 = rb * gb - rg * bb;
      const float c02 = rg * gb - rb * gg;
      const float c11 = rr * bb - rb * rb;
      const float c12 = rg * rb - rr * gb;
      const float c22 = rr * gg - rg * rg;
      const float det = rr * c00 + rg * c01 + rb * c02;
      if (std::fabs(det) > 1.0e-6F) {
        const float ar = (c00 * rp + c01 * gp + c02 * bp) / det;
        const float ag = (c01 * rp + c11 * gp + c12 * bp) / det;
        const float ab = (c02 * rp + c12 * gp + c22 * bp) / det;
        const float bias = mean_p[i] - ar * mean_r[i] - ag * mean_g[i] - ab * mean_b[i];
        q = ar * guide_r_[i] + ag * guide_g_[i] + ab * guide_b_[i] + bias;
      }
    }
    guided_illumination_[i] = ClampFloat(q, 0.0F, 255.0F);
  }
}

void AttentionLight::BuildLocalGain() {
  for (std::size_t i = 0; i < gain_q7_.size(); ++i) {
    const int control = ClampInt(static_cast<int>(std::lround(guided_illumination_[i])), 0, 255);
    const int lut_q8 = gain_lut_q8_[static_cast<std::size_t>(
        ClampInt(static_cast<int>(std::lround(stable_y_[i])), 0, 255))];
    int lut_weight = 16384;
    int constant_weight = 0;
    if (control <= 220) {
      if (config_.tone_gate == ToneGate::kShadow110) {
        if (control < 110) {
          lut_weight = 22 * control;
          constant_weight = 16384 - lut_weight;
        } else {
          lut_weight = 127 * control - 11468;
          constant_weight = 27852 - 127 * control;
        }
      } else {
        if (control < 160) {
          lut_weight = 15 * control;
          constant_weight = 16384 - lut_weight;
        } else {
          lut_weight = 232 * control - 34679;
          constant_weight = 51063 - 232 * control;
        }
      }
    }
    lut_weight = ClampInt(lut_weight, 0, 16384);
    constant_weight = ClampInt(constant_weight, 0, 16384);
    const int gain = (lut_q8 * lut_weight + 225 * constant_weight + 16384) >> 15;
    gain_q7_[i] = static_cast<float>(ClampInt(gain, 100, 255));
  }
}

void AttentionLight::ApplyTileProtection() {
  for (int tile_y = 0; tile_y < height_; tile_y += kTileSize) {
    for (int tile_x = 0; tile_x < width_; tile_x += kTileSize) {
      const int x1 = std::min(width_, tile_x + kTileSize);
      const int y1 = std::min(height_, tile_y + kTileSize);
      float minimum = 255.0F;
      float maximum = 0.0F;
      for (int y = tile_y; y < y1; ++y) {
        for (int x = tile_x; x < x1; ++x) {
          const float value = stable_y_[static_cast<std::size_t>(y) * width_ + x];
          minimum = std::min(minimum, value);
          maximum = std::max(maximum, value);
        }
      }
      if (maximum < 20.0F || minimum > 250.0F) {
        for (int y = tile_y; y < y1; ++y) {
          for (int x = tile_x; x < x1; ++x) {
            gain_q7_[static_cast<std::size_t>(y) * width_ + x] = 128.0F;
          }
        }
      }
    }
  }
}

void AttentionLight::Reconstruct(const ConstI420View& input,
                                 const I420View& output) {
  const float transition = static_cast<float>(transition_position_) /
                           static_cast<float>(config_.transition_frames);
  // 先处理色度，保证输入输出别名时仍能读取未经修改的 2x2 亮度块。
  for (int y = 0; y < height_ / 2; ++y) {
    const auto* src_u = input.u + y * input.stride_u;
    const auto* src_v = input.v + y * input.stride_v;
    auto* dst_u = output.u + y * output.stride_u;
    auto* dst_v = output.v + y * output.stride_v;
    for (int x = 0; x < width_ / 2; ++x) {
      int gain_sum = 0;
      int luma_sum = 0;
      for (int dy = 0; dy < 2; ++dy) {
        for (int dx = 0; dx < 2; ++dx) {
          const std::size_t i = static_cast<std::size_t>(2 * y + dy) * width_ + 2 * x + dx;
          gain_sum += static_cast<int>(gain_q7_[i]);
          luma_sum += input.y[(2 * y + dy) * input.stride_y + 2 * x + dx];
        }
      }
      const int half_average_gain = gain_sum >> 3;
      const int chroma_limit = ClampInt(205 - ((26 * half_average_gain) >> 6), 128, 255);
      const int chroma_factor =
          ((half_average_gain - 64) * (chroma_limit >> 2) + 4096) >> 6;
      const int average_luma = luma_sum >> 2;
      const float eu = static_cast<float>(
          128 + (((static_cast<int>(src_u[x]) - 128) * chroma_factor) >> 6));
      const int v_center = average_luma >= 150 ? 128 : 131;
      const float ev = static_cast<float>(
          v_center + (((static_cast<int>(src_v[x]) - 128) * chroma_factor) >> 6));
      const int base_u = ((234 * static_cast<int>(src_u[x])) >> 8) + 14;
      const int base_v = ((234 * static_cast<int>(src_v[x])) >> 8) + 11;
      dst_u[x] = ClampByte(base_u + transition * (eu - base_u));
      dst_v[x] = ClampByte(base_v + transition * (ev - base_v));
    }
  }

  for (int y = 0; y < height_; ++y) {
    const auto* src = input.y + y * input.stride_y;
    auto* dst = output.y + y * output.stride_y;
    for (int x = 0; x < width_; ++x) {
      const std::size_t i = static_cast<std::size_t>(y) * width_ + x;
      const float enhanced = src[x] * gain_q7_[i] / 128.0F;
      const int baseline = (225 * static_cast<int>(src[x])) >> 8;
      dst[x] = ClampByte(baseline + transition * (enhanced - baseline));
    }
  }
}

bool AttentionLight::Process(const ConstI420View& input,
                             const I420View& output,
                             const std::vector<Roi>& rois,
                             std::string* error) {
  if (!Validate(input, output, error)) {
    return false;
  }
  EnsureSize(input.width, input.height);
  if (target_enabled_) {
    transition_position_ = std::min(config_.transition_frames, transition_position_ + 1);
  } else {
    transition_position_ = std::max(0, transition_position_ - 1);
  }

  BuildStableLuma(input);
  if (transition_position_ != 0) {
    UpdateToneCurve(rois);
    BuildGainLut();
    BoxMean(stable_y_, 1, box3_);
    BoxMean(box3_, 2, box5_);
    BuildRgbGuides(input);
    BuildGuidedIllumination();
    BuildLocalGain();
    ApplyTileProtection();
  }
  Reconstruct(input, output);

  ++processed_frames_;
  diagnostics_.processed_frames = processed_frames_;
  diagnostics_.transition = static_cast<float>(transition_position_) /
                            static_cast<float>(config_.transition_frames);
  return true;
}

float AttentionLight::Clamp01(float value) {
  return ClampFloat(value, 0.0F, 1.0F);
}

std::uint8_t AttentionLight::ClampByte(float value) {
  return static_cast<std::uint8_t>(ClampInt(static_cast<int>(std::lround(value)), 0, 255));
}

}  // namespace attention_light
