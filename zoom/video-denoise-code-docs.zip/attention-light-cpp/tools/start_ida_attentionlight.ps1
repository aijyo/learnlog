param(
    [string]$Target = "D:\code\work\research\video-denoise\zlt-re\out\zlt.dll",
    [switch]$Headless
)

$PythonHome = "C:\Users\CT10266\AppData\Local\Programs\Python\Python39"
$IdaHome = "D:\solft\IDA Pro 7.5.20.1028 SP3 Portable + All decompilers (Windows)\IDA Pro 7.5.20.1028 SP3 Portable"
$IdaExe = Join-Path $IdaHome "ida64.exe"

if (-not (Test-Path -LiteralPath $PythonHome)) {
    throw "Python 3.9 not found: $PythonHome"
}
if (-not (Test-Path -LiteralPath $IdaExe)) {
    throw "IDA executable not found: $IdaExe"
}
if (-not (Test-Path -LiteralPath $Target)) {
    throw "Target not found: $Target"
}

$env:PYTHONHOME = $PythonHome
$env:PATH = "$PythonHome;$PythonHome\Scripts;$env:PATH"

Write-Host "PYTHONHOME=$env:PYTHONHOME"
Write-Host "IDA=$IdaExe"
Write-Host "Target=$Target"

if ($Headless) {
    & $IdaExe -A $Target
    exit $LASTEXITCODE
}

Start-Process -FilePath $IdaExe -ArgumentList $Target -WorkingDirectory $IdaHome
