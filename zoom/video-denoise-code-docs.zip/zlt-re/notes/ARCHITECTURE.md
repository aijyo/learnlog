# zlt.dll 架构地图（Zoom 视频媒体引擎）

> 逆向目的：**理解架构 + 净室学习**（互操作/安全研究/学习）。本文件只记录**结构性事实**
> （类名、继承、导入、计数——这些是接口/互操作事实，非受著作权保护的表达），
> **不含任何反编译得到的专有代码**。算法行为层面的结论标注证据级别，未经函数体验证的标 `[待body验证]`。

- **样本**：`zlt.dll`，5.47 MB，PE32+ (x64)，来自 Zoom Windows 客户端 `AppData\Roaming\Zoom\bin\`（2026-07-08 版本）。
- **工具**：IDA Pro 7.5 SP3 + Hex-Rays，无头分析（`idat64 -B` 生成 `.i64`；`ida_map.py` / `ida_rtti_vtable.py`）。
- **产物**：[`../model/map.json`](../model/map.json)（全 DLL map）、[`../model/rtti.json`](../model/rtti.json)（关键类继承/vtable）。
- **日期**：2026-07-21。

证据级别：`[rtti]` 从 RTTI/vtable 确认 · `[imp]` 从导入表确认 · `[str]` 从字符串 · `[待body验证]` 结构强暗示但未读函数体。

---

## 1. 一句话结论

`zlt.dll` 是 **Zoom 自研的视频媒体引擎**：一套**从零实现的 H.264/AVC 编解码器**（含屏幕内容编码 SCC 与转码器）+ 一条**GPU 加速的视频前/后处理（VPP）流水线**（降噪/增强/分割/超分/美颜/虚拟背景/特效）。整个 DLL **100% 是 Zoom 自己的代码**，未静态链接任何第三方 OSS（无 ffmpeg / x264 / openh264 / onnxruntime / OpenCV）。`[imp]`

规模：**8273 个函数、428 个带虚表的 C++ 类、~3.9 MB 代码、15234 条调用边**。`[rtti]`

---

## 2. Provenance（来源划分）—— 结论：整块都是 vendor 代码

266 个导入符号，全部来自 **Windows 系统 DLL + MSVC 运行时**，无任何第三方库 DLL：`[imp]`

| 类别 | 模块 | 说明 |
|------|------|------|
| C++ 运行时 | `MSVCP140`(93)、`VCRUNTIME140`/`_1`、`api-ms-win-crt-*`(75) | STL / CRT |
| 内核/系统 | `KERNEL32`(51)、`USER32`、`ADVAPI32`、`ole32`、`OLEAUT32`、`SETUPAPI`、`SHELL32`、`SHLWAPI`、`WINMM`、`NETAPI32` | 线程/内存/COM/设备枚举/GPU 查询 |

**关键推论**：
- H.264 编解码器是 Zoom 自研，不是封装 x264/openh264（否则会看到对应符号或典型 OSS 指纹）。`[imp][rtti]`
- **没有链接任何神经网络推理运行时**（无 onnxruntime / DirectML / CUDA / OpenVINO 导入）。DLL 内的"学习型"部分只有 RAISR（基于哈希的学习滤波器组，非深度网）。若 Zoom 有深度 NN 视频特效，**不在这个 DLL 里**。`[imp]`
- 未导入 `d3d11.dll`/`d3d12.dll` → GPU 后端通过 `LoadLibrary`/COM **动态加载**（`zltCGctLoader`/`zltCVppLoader` 印证）。`[rtti]`

→ 净室重建时无 OSS 剥离问题：非 CRT 的一切都是待重建的 vendor 桶（但体量巨大，见 §7）。

---

## 3. 子系统划分（按命名空间）

428 个类按 C++ 命名空间聚成 7 个子系统 + 接口/STL 杂项：

| 命名空间 | 类数 | 子系统角色 |
|----------|------|-----------|
| `ns_avc` | 122 | **H.264/AVC 编解码器**：编码器核心、解码器核心、屏幕内容编码（Sc* 系列）、转码器、熵编码(CABAC/CAVLC)、码控、运动估计、帧内预测、去块、DPB/参考帧管理 |
| `ns_codec` | 52 | **编解码编排层**：编/解码会话、控制器、硬件编解码管理、码流适配（CAS* 系列）、发送/质量/帧率切换决策、内容检测、场景切换检测 |
| `ns_vpp` | 49 | **视频前/后处理流水线**（详见 §5）：降噪/增强/分割/超分/美颜/重采样/混合/特效 |
| `ns_base` | 46 | **基础设施**：码流容器、YUV 图像、side-data 扩展（ROI/多流/空间层信息的 parser/writer）、去闪烁、打包单元 |
| `ns_gct` | 31 | **GPU 计算后端**：D3D11/D3D12 ComputeContext、Shader、GPUBuffer、Texture、GPU 后处理、GPU RAISR |
| `ns_util` | 20 | **通用工具**：线程管理器、WPP 波前线程、分配器、条件变量、加载器、`zltIVppAlgoBase`(VPP 算法基类) |
| `ns_glt` | 7 | **D3D11 图形层**：D3D11 接口/方法表、DCC、RAISR 图形封装 |
| `(接口/STL)` | 101 | `zltI*` 抽象接口（Encoder/Decoder/Vpp/…）、STL 内部（regex 节点/facet/异常）、`gltInterface`/`gltPlatform` |

> 函数级归属：8273 个函数里仅 398 个带符号，其余为 `sub_`（符号被 strip）。函数→子系统的精确归属需调用图聚类，属重建阶段工作，画地图不需要。

---

## 4. 数据流（帧管线）

顶层公共接口（纯虚，`[rtti]`）：`zltIEncoder`(8 槽)、`zltIDecoder`(10 槽)、`zltIVpp`(11 槽)。实现体与接口分离——接口在 `ns_base`/全局，实现在 `ns_avc`/`ns_vpp`/`ns_codec`。

```
【发送/编码路径】
  采集 YUV (zltCYuvPicture/zltCYuvPic)
      │
      ▼
  VPP 前处理 (zltIVpp → zltCVppWrapper → 算法链)   ← 降噪/增强/美颜/虚拟背景在此
      │
      ▼
  编码编排 (ns_codec: zltCEncodeSession / zltCEncoderWrapper / 码控与切换决策)
      │
      ▼
  AVC 编码核心 (ns_avc: zltCEncoderCore, 32 虚槽) ──WPP 多线程──▶ H.264 码流
      │                         └ 场景分析/运动估计/模式决策/熵编码/码控/ROI量化
      ▼
  side-data 打包 (ns_base: PacketizedUnit + ROI/多流/空间层信息扩展)

【接收/解码路径】
  H.264 码流 ──▶ AVC 解码核心 (ns_avc: zltCDecoderCore, 20 虚槽) ──WPP──▶ 重建 YUV
                                                                        │
                                                                        ▼
                                        VPP 后处理 (降噪/超分/去块/去环/色彩) ──▶ 渲染
```

- **WPP 波前并行**：`zltCEncoderCore`/`zltCDecoderCore` 多重继承 `zltI*Core@ns_base` + `zltIThreadRoutine@ns_util` → **编解码核心本身就是工作线程例程**，切片(slice)/波前分块跨线程并行。`SharedParam@ns_util` 是各线程共享的每切片运行时参数基类。`[rtti]`
- **屏幕内容编码（SCC）**：`ns_avc` 里成套的 `zltCSc*`（ScEncoderCore/ScDecoderCore/ScTranscoderCore 等 30+ 类）是**屏幕共享专用编码路径**，与摄像头视频路径并列。`[rtti]`

---

## 5. VPP 子系统详解（与 video-denoise 直接相关）

### 5.1 插件架构
所有 VPP 滤镜实现统一算法接口 **`zltIVppAlgoBase@ns_util`**（6 虚槽：约为 init/process/reset/release 一类的生命周期契约，`[待body验证]`具体语义）。`zltCVppWrapper : zltIVpp` 是调度器，按配置串起算法链；内含 `MonitorLog_MethodStatistics`（每算法耗时统计）`[rtti]`。这是一个**干净的滤镜插件框架**——加一个滤镜 = 实现一次 `zltIVppAlgoBase`。

### 5.2 滤镜清单（49 类，按功能分组）

| 组 | 类 |
|----|----|
| **降噪（重点）** | `zltCDenoise`（空域）、`zltCDenoiseASM`（其手写 SIMD 子类）、`zltCTemporalDenoise`（时域）、`zltCIIRDenoise`（IIR 递归时域）、`zltCRecursiveBF`（递归双边）、`zltCGuidedFilter`（导向滤波）、`zltCGeneralFilter`、`zltCFrameBlur` |
| 低光/增强 | `zltCCLAHE`（限对比度自适应直方图均衡）、`zltCLightAdaption`、`zltCAttentionLight`、`zltCColorAdaption`、`zltCDCC`、`zltCSharpen` |
| 分割/人像/美颜 | `zltCBackgroundExtraction`、`zltCMaskRefinement`、`zltCMatting`、`zltCSkinSegmentation`、`zltCFaceDetect`、`zltCFaceBeautification`、`zltCTrack` |
| 超分 | `zltCRaisr`、`zltCScreenRAISR`（学习哈希滤波器组，GPU） |
| 特效 | `zltCDeepFake`、`zltCDynamicEmoji`、`zltCAutoFraming`、`zltCFlashDetection`、`zltCDeinterlace` |
| 重采样/几何/色彩 | `zltCBilinear`/`zltCNearest`/`zltCResample`/`zltCUpsample`/`zltCUpSampleBilinear`/`zltCAlignedBilinearUpsample`/`zltCGvdownsample`、`zltCRotate`/`zltCMirror`、`zltCColorSpaceCvt`/`zltGPUChromaUpsample` |
| 混合 | `zltCBlending`、`zltCBlendLocal` |

### 5.3 降噪家族继承链（`[rtti]` 确认）
```
zltIVppAlgoBase (VPP 算法契约)
   ├─ zltCDenoise                (空域降噪, +zltIThreadRoutine 分块并行)
   │     └─ zltCDenoiseASM        (同算法的手写汇编/SIMD 特化子类)
   ├─ zltCTemporalDenoise        (时域降噪, 7 槽——比其他多一个)
   ├─ zltCIIRDenoise             (IIR 递归时域, +zltIThreadRoutine)
   └─ zltCRecursiveBF            (递归双边滤波, +zltIThreadRoutine)
zltCGuidedFilter / zltCGeneralFilter  (独立, 非 AlgoBase 派生)
```

**核心判断**：`zltCDenoiseASM` 是 `zltCDenoise` 的子类 → 同一降噪算法有 **C 参考实现 + 手写 SIMD 实现**两份（运行时按 CPU 能力选）。降噪家族**全部是经典 DSP 滤波器**（空域/时域/IIR 递归/双边/导向），**没有任何神经网络降噪类**，也没链任何推理运行时。`[rtti][imp]`

→ **结论（对 video-denoise 有指导意义）：Zoom 的实时视频降噪走的是经典/超轻量 DSP 路线（手写 SIMD + D3D 计算着色器加速），不是深度网络。** 这与我们 P0 "弱硬件实时场景主流用经典/超轻量"的判断一致。算法内部细节（核大小、时域融合权重、IIR 系数）需 Phase 3 读函数体才能确认，当前 `[待body验证]`。

---

## 6. GPU 后端（ns_gct / ns_glt）

- `ComputeContext` / `D3D11ComputeContext` / `D3D12ComputeContext` + `D3D11Shader`/`D3D12Shader` + `GPUBuffer`/`Texture` → VPP 与 RAISR 跑在 **D3D11/D3D12 计算着色器**上。`[rtti]`
- D3D 运行时**动态加载**（导入表无 d3d11/d3d12，见 §2）。
- `CGPURaisr`/`gltD3D11Raisr` = RAISR 超分的 GPU 实现；`GPUPostProcess` = 通用 GPU 后处理。
- **边界**：GPU 侧的 HLSL 着色器是**编译后的字节码 blob**（DXBC/DXIL），属静态逆向地板（static-RE floor）——能看到 CPU 侧的分派与参数，看不到着色器源码逻辑，需动态捕获或另行反汇编着色器。`[待body验证]`

---

## 7. 净室重建边界与体量

| 部分 | 可净室重建性 | 备注 |
|------|-------------|------|
| VPP 滤镜框架 `zltIVppAlgoBase`/`zltCVppWrapper` | ✅ 易 | 接口+调度，几个类 |
| 降噪家族（空域/时域/IIR/双边/导向） | ✅ 中 | 经典 DSP，读函数体可复现算法（核/系数是事实非表达）；ASM 版用等价 SIMD 或标量重写 |
| 增强（CLAHE/LightAdaption/…） | ✅ 中 | 同上，标准算法 |
| H.264 编解码器（ns_avc 122 类） | ◑ 大 | **相当于逆向一个 x264+解码器**；解码器可 1:1（标准约束死），编码器只能功能等价（模式决策/码控是启发式，非唯一） |
| 分割/美颜/DeepFake | ⛔ 可能含权重 | 若内部有学习模型参数 → 权重是边界(不提取)；本 DLL 未链推理运行时，可能是纯 DSP 或权重内嵌，需 Phase 3 确认 |
| GPU 着色器 | ⛔ floor | 编译字节码，需动态捕获/着色器反汇编 |

**体量提醒**：全量重建 = 编解码器(最大头) + VPP + GPU 后端,是巨型工程。与 video-denoise 目标强相关的只有 **§5 的降噪家族 + VPP 框架**这一小块。

---

## 8. 对 video-denoise 项目的启示

1. **路线验证**：一线商用实时视频降噪（Zoom）用**经典 DSP**（空域+时域+IIR递归+双边），非深度网络——印证我们"弱硬件实时优先经典/超轻量"的方向。
2. **具体可借鉴的算法族**（作为 P1 非 NN 基线的加强版参照，均为公开经典算法，非 Zoom 专有）：空域降噪、**时域降噪**、**IIR 递归时域降噪**（正是我们讨论的流式递归结构的经典对应）、递归双边滤波、导向滤波。P1 的基线不该只有 ffmpeg hqdn3d，应补齐"递归时域 + 边缘保持"这条经典线。
3. **工程模式**：统一的算法插件接口（一个 `process` 契约）+ C 参考实现/SIMD 实现双份 + 分块波前并行——是实时 VPP 的成熟工程范式,我们的原型可照此组织。
4. **NN 的位置**：若要用 NN 超越经典,竞争基准就是"Zoom 这套经典 DSP 在同等每帧耗时下的质量"。我们的 NN 必须在**相同耗时预算**内打赢它才有意义。

---

## 9. 下一步（重建范围决策）

架构地图已完成。若继续，可选（一次一个，出数据再进下一步）：
- **A**（与项目最相关）：Phase 3 读 `zltCDenoise`/`zltCTemporalDenoise`/`zltCIIRDenoise` 的函数体，确认算法细节（核、时域融合、IIR 系数），净室重建这条降噪链作为 video-denoise 的经典基线。
- **B**：读 VPP 框架 `zltIVppAlgoBase`/`zltCVppWrapper`,净室搭一个滤镜插件骨架。
- **C**：暂不重建,本地跑 ffmpeg 经典降噪 + 手搓单帧网络（原 P1 计划），把本地实测数据先建起来。
