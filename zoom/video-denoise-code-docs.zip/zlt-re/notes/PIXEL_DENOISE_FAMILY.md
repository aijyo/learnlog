# Zoom zlt.dll ns_vpp 像素降噪类族 —— 逆向算法地图

> 承接 §4.9 的定论:zltCIIRDenoise 是 level 图 steering 组件,**真正抹像素的是本族类**。
> 静态定位内核(map.json 按 region/size)+ 反编译(kernels_decomp.json)+ 类名 + 恢复常量。
> 净室实现:[`../../scripts/zlt_pixel_denoise.py`](../../scripts/zlt_pixel_denoise.py)(原创代码,标准算法,非 SIMD 转抄)。日期 2026-07-22。

## 共同结构

每个像素降噪类都是三段式:**① 参数 helper**(值域/强度曲线 + 时域 EMA)→ **② 分块 + WPP 多线程分发器**(校验图、按 `*(this+212)` 分带、派 worker 线程)→ **③ SIMD worker 内核**(实际逐像素运算)。

## 类 → 算法(逆向识别)

| 类 | 算法 | 证据 / 恢复facts | 内核 EA(最大) | 净室 |
|----|------|----------------|--------------|------|
| `zltCRecursiveBF` | **递归双边滤波**(Yang 2012,O(N) 1D 递归) | param helper `sub_1801B9BD0`=值域断点曲线插值+**0.79 时域 EMA**+clamp[1,255];σ=**3.5** | 0x1801B9F80/0x1801BB930 | ✅ 标准可实现 |
| `zltCGuidedFilter` | **导向滤波**(He 2010,box-filter 序列 O(N)) | 最大内核 16KB、box-filter 结构;类名 | 0x180295F00 | ✅ **已实现** |
| `zltCTemporalDenoise` | **Haar 变换域时域降噪** + 系数阈值 | Haar 系数 **0.3535678/0.70711**;阈值常量 0.4/0.5/1.5/10 | 0x180221790/0x180222580/0x1802206A0 | ◑ 算法清楚,SIMD near floor |
| `zltCDenoise` / `zltCDenoiseASM` | **空域边缘保持平滑**(tiled+WPP;ASM=SIMD 特化子类) | 分发器 `sub_180259850` 分带派 worker;ASM 继承自 Denoise | 0x18025AC00/0x18025A120 | ◑ 手写 SIMD kernel=floor |
| `zltCGeneralFilter` | **通用卷积滤波** | 12 层循环 SIMD | 0x18026BA10 | ◑ |

## 净室实现(代表:导向滤波)

`zlt_pixel_denoise.py`:`guided_filter()`(He 2010 自导向边缘保持,原创)+ `GuidedRecursiveDenoiser`(导向空域 + 运动自适应时域递归,模拟本族"空域平滑 + 时域稳定"结构)。
验证:合成 PSNR 18.9→23.1;真实低光 clip 静止区 flicker **降 82%**(本族结构 = 目前最好),无明显伪影。

## 精确参数抠取(zltCGuidedFilter,2026-07-22)

用 `ida_consts.py` dump 内核 `sub_180295F00` 引用的 .rdata 常量:
- **`25.0`(两处)= box 均值归一化除数 → 5×5 窗口 → radius=2**(精确恢复 ✅)。
- `256.0` 定点缩放;`1/128≈0.0078`/`1.0`(同址 float/double 二义);ints `8`(SIMD 8 宽)、`4`/`16`;邻函数 `47`/`52`/`255`(疑阈值)。
### eps 与算法变体 —— 逐条读 SIMD 序列后恢复 ✅(2026-07-22)

读内核 `sub_180295F00` 的除法段(唯一 `_mm_div_ps`,line 425)+ 协方差矩阵构造:
- 结构是 **3×3 协方差矩阵求逆**(det + cofactors,`v85=1.0/det`)→ **这是 3 通道(彩色)导向滤波**(He 2010 的 color 版 `a=(Σ+εU)⁻¹·cov`),**不是灰度自导向**。算法变体修正 ✅。
- eps = 加到协方差对角的常量 **`v33 = xmmword_1805097E0 = 25.0`**(`v65=(E[X²]−E[X]²)+v33`、`v61=v57+v33`)。25 只在 **8-bit 方差域**才自洽 → 归一化 `≈ 25/255² = 3.8e-4 ≈ (0.02)²`。eps 恢复 ✅(scale 有小不确定,取决于均值归一化 v19)。
- numerator `xmmword_1805096F0`=1.0(用于 1/det),非 eps。
- 已把 radius=2 + eps=25/255² 写进 `guided_filter`,并注明 Zoom 实为彩色 3×3 变体。

**结论(更新)**:导向滤波现已恢复 **算法变体(彩色 3×3 矩阵求逆)+ 窗口(5×5)+ eps(25 raw≈0.02²)**。距"只差 SIMD/循环"只剩:①彩色 vs 灰度变体(我们处理 luma,用灰度类比),②精确定点 scale。比其余几个类推进最深。其余类(RecursiveBF/TemporalDenoise/Denoise/GeneralFilter)仍停在算法家族层。

## #1 彩色导向滤波实现 + #2 其余类抠参数(2026-07-22)

**#1**:实现彩色 3×3 矩阵求逆导向滤波 `color_guided_filter`(He 2010,Zoom 变体),用恢复的 5×5 + eps=25/255²。
真实 clip 实测:**单独只降 flicker ~5%**——因恢复的 **eps=0.02² 偏小 → 有意做成"轻"边缘保持**(平坦区近恒等、保细节)。
说明 **Zoom 的导向滤波空域步是"轻"的**,重降噪靠时域 + level 图 steering,不靠它单独。81.6ms/帧(numpy,SIMD 差距)。

**#2 抠其余四类参数**(用 `ida_consts.py` dump 内核常量;常量是事实,**角色多为推断**,不像 GuidedFilter eps 逐 operand 追):

| 类 | 恢复到的参数(事实) | 角色(推断) | 置信 |
|----|-----|------|------|
| `zltCRecursiveBF` | σ=**3.5**;时域 EMA=**0.79**(helper 已确认);断点曲线 **{0.1,0.25,0.3,0.4,0.6,0.9,1.0}**;定点 32768 | 值域 σ + 时域递归 + 值域权重曲线 | σ/0.79 高;曲线中 |
| `zltCTemporalDenoise` | Haar **0.3535/0.7071**;阈值 **{0.4,0.5,1.5,10,50}**;微正则 **5.9e-5**(4 个函数复现) | 变换域系数收缩阈值 + 正则 | 中 |
| `zltCDenoise`(空域) | **无烘焙强度常量**;仅结构 int(窗/taps=5、SIMD 8 宽、块 32) | **强度被 steer(来自 level 图)/config,非烘焙** | 高(架构印证) |
| `zltCGeneralFilter` | **无烘焙浮点**;仅结构 int(taps/stride) | 卷积系数为 config 传入 | 高 |

**架构印证**:Denoise/GeneralFilter 没有烘焙强度参数 → 证实"空域平滑强度由 zltCIIRDenoise 的 level 图 steer"这条主线。

## 诚实边界

- **算法身份 + 关键常量**已恢复(高置信,基于类名 + 结构 + 常量)。
- **实际像素 kernel 是手写 SIMD worker**,byte-exact 复刻是 **static-RE 地板**(要逐条读向量指令,收益递减)。我实现的是**类所用的标准算法**(导向滤波)+ 可用恢复参数,**不是 Zoom SIMD 内核的逐字复刻**。
- 与 zltCIIRDenoise 不同(那个我们做到了 byte-exact 内核验证):本族只做到**算法级识别 + 标准净室实现**;要 byte-exact 某个 SIMD kernel,需针对性深读单个内核(可另起,收益递减)。

## 完整图景(zlt.dll 降噪)

**zltCIIRDenoise**(时域稳定的噪声/细节 level 图,已 byte-exact 逆)→ steer → **本族像素降噪器**(递归双边/导向/Haar时域/空域SIMD,算法已识别、导向已净室实现)→ 输出去噪帧。
