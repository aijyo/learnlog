from __future__ import print_function

import json
import traceback

import ida_bytes
import ida_hexrays
import ida_name
import idc


def decompile(ea):
    try:
        return str(ida_hexrays.decompile(ea))
    except Exception as exc:
        return "<decompile failed: %s>" % exc


def main():
    if len(idc.ARGV) < 2:
        raise RuntimeError("output path is required")
    output_path = idc.ARGV[1]
    vtable_ea = 0x180504F98
    slots = []
    for index in range(6):
        target = ida_bytes.get_qword(vtable_ea + index * 8)
        slots.append(
            {
                "index": index,
                "ea": "0x%X" % target,
                "name": ida_name.get_name(target),
                "pseudocode": decompile(target) if index == 2 else "",
            }
        )
    payload = {
        "vtable": "0x%X" % vtable_ea,
        "slots": slots,
        "transition": {
            "ea": "0x1801EA840",
            "pseudocode": decompile(0x1801EA840),
        },
        "histogram_stats": {
            "ea": "0x1801E9BE0",
            "pseudocode": decompile(0x1801E9BE0),
        },
    }
    with open(output_path, "w") as stream:
        json.dump(payload, stream, indent=2)


try:
    main()
except Exception:
    if len(idc.ARGV) >= 2:
        with open(idc.ARGV[1] + ".trace", "w") as stream:
            stream.write(traceback.format_exc())
    raise
finally:
    idc.qexit(0)
