from __future__ import print_function

import json
import traceback

import ida_funcs
import ida_hexrays
import idautils
import idc


ANCHORS = [
    0x180186190,
    0x1801858C0,
    0x1801E7C40,
    0x1801E8100,
]


def pseudocode(ea):
    try:
        return str(ida_hexrays.decompile(ea))
    except Exception as exc:
        return "<decompile failed: %s>" % exc


def function_start(ea):
    fn = ida_funcs.get_func(ea)
    return fn.start_ea if fn else idc.BADADDR


def xref_functions(ea):
    result = set()
    for xref in idautils.XrefsTo(ea, 0):
        start = function_start(xref.frm)
        if start != idc.BADADDR:
            result.add(start)
    return sorted(result)


def immediate_users(value):
    result = set()
    for start in idautils.Functions():
        found = False
        for ea in idautils.FuncItems(start):
            for index in range(6):
                if idc.get_operand_type(ea, index) == idc.o_imm and idc.get_operand_value(ea, index) == value:
                    result.add(start)
                    found = True
                    break
            if found:
                break
    return sorted(result)


def record(ea, why):
    return {
        "ea": "0x%X" % ea,
        "name": idc.get_func_name(ea),
        "why": why,
        "callers": ["0x%X" % x for x in xref_functions(ea)],
        "pseudocode": pseudocode(ea),
    }


def main():
    if len(idc.ARGV) < 2:
        raise RuntimeError("output path is required")
    output_path = idc.ARGV[1]
    selected = {}
    for ea in ANCHORS:
        selected[ea] = record(ea, "anchor")
        for caller in xref_functions(ea):
            selected.setdefault(caller, record(caller, "caller-of-0x%X" % ea))
    for ea in immediate_users(3328):
        selected.setdefault(ea, record(ea, "immediate-3328"))
        for caller in xref_functions(ea):
            selected.setdefault(caller, record(caller, "caller-of-3328-user"))
    payload = {
        "constant": 3328,
        "immediate_users": ["0x%X" % ea for ea in immediate_users(3328)],
        "functions": [selected[ea] for ea in sorted(selected)],
    }
    with open(output_path, "w") as stream:
        json.dump(payload, stream, indent=2)


try:
    main()
except Exception:
    if len(idc.ARGV) >= 2:
        with open(idc.ARGV[1] + ".trace", "w") as stream:
            stream.write(traceback.format_exc())
    raise
finally:
    idc.qexit(0)
