from __future__ import print_function

import json
import traceback

import ida_funcs
import ida_hexrays
import idautils
import idc


ANCHORS = [
    0x1801E93E0,
    0x1801E9BE0,
    0x1801E9EA0,
    0x180186A40,
    0x180186AA0,
    0x180186BB0,
    0x180186D90,
    0x180186ED0,
    0x180186F30,
    0x180186F90,
    0x180186FF0,
    0x180187050,
    0x1801871F0,
    0x180188370,
    0x1802EF170,
    0x1802EFE60,
    0x1802F02E0,
    0x1802F07B0,
    0x1802F1130,
]


def pseudocode(ea):
    try:
        return str(ida_hexrays.decompile(ea))
    except Exception as exc:
        return "<decompile failed: %s>" % exc


def function_start(ea):
    fn = ida_funcs.get_func(ea)
    return fn.start_ea if fn else idc.BADADDR


def xref_functions(ea):
    result = set()
    for xref in idautils.XrefsTo(ea, 0):
        start = function_start(xref.frm)
        if start != idc.BADADDR:
            result.add(start)
    return sorted(result)


def displacement_users(values):
    wanted = set(values)
    result = {}
    for start in idautils.Functions():
        hits = set()
        for ea in idautils.FuncItems(start):
            for index in range(6):
                operand_type = idc.get_operand_type(ea, index)
                if operand_type in (idc.o_displ, idc.o_imm):
                    value = idc.get_operand_value(ea, index)
                    if value in wanted:
                        hits.add(value)
        if hits:
            result[start] = sorted(hits)
    return result


def record(ea, why, hits=None):
    return {
        "ea": "0x%X" % ea,
        "name": idc.get_func_name(ea),
        "why": why,
        "hits": hits or [],
        "callers": ["0x%X" % x for x in xref_functions(ea)],
        "pseudocode": pseudocode(ea),
    }


def main():
    if len(idc.ARGV) < 2:
        raise RuntimeError("output path is required")
    output_path = idc.ARGV[1]
    selected = {}
    for ea in ANCHORS:
        selected[ea] = record(ea, "anchor")
        for caller in xref_functions(ea):
            selected.setdefault(caller, record(caller, "caller-of-0x%X" % ea))
    users = displacement_users([3944, 3960, 18856, 16880])
    for ea, hits in users.items():
        selected.setdefault(ea, record(ea, "workspace-member-user", hits))
    payload = {
        "workspace_offsets": [3944, 3960, 18856, 16880],
        "functions": [selected[ea] for ea in sorted(selected)],
    }
    with open(output_path, "w") as stream:
        json.dump(payload, stream, indent=2)


try:
    main()
except Exception:
    if len(idc.ARGV) >= 2:
        with open(idc.ARGV[1] + ".trace", "w") as stream:
            stream.write(traceback.format_exc())
    raise
finally:
    idc.qexit(0)
