// ManagedNamedThread.h
#pragma once
#include "NamedThread.h"
#include <memory>
#include <string>

class ManagedNamedThread {
public:
	explicit ManagedNamedThread(const std::string& name_prefix);
	~ManagedNamedThread();

	// ��ֹ����
	ManagedNamedThread(const ManagedNamedThread&) = delete;
	ManagedNamedThread& operator=(const ManagedNamedThread&) = delete;

	// �����ƶ�
	ManagedNamedThread(ManagedNamedThread&&) noexcept;
	ManagedNamedThread& operator=(ManagedNamedThread&&) noexcept;

	void post(std::function<void()> task);
	void sync(std::function<void()> task);
	void wait();
	void stop(bool wait = false);
	std::string name() const;

private:
	std::shared_ptr<NamedThread> thread_;
};
