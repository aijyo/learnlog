// NamedThread.h
#pragma once
#include <queue>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <functional>
#include <atomic>
#include <string>
#include <future>

class NamedThread {
public:
	explicit NamedThread(const std::string& name);
	~NamedThread();

	void post(std::function<void()> task);
	void sync(std::function<void()> task);
	void wait();
	void stop(bool wait = true);
	std::string name() const;

private:
	void run();

	std::string name_;
	std::queue<std::function<void()>> queue_;
	std::mutex mutex_;
	std::condition_variable cond_;
	std::condition_variable cond_empty_;
	std::thread thread_;
	bool stop_flag_ = false;
	bool has_stopped_ = false;
};

using NamedThreadPtr = std::shared_ptr<NamedThread>;