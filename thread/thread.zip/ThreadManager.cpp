// ThreadManager.cpp
#include "ThreadManager.h"

ThreadManager& ThreadManager::instance() {
	static ThreadManager instance;
	return instance;
}

ThreadManager::ThreadManager() {
	create_thread("idle");
	create_thread("ui");
}

ThreadManager::~ThreadManager() {
	std::lock_guard<std::mutex> lock(mutex_);
	for (auto& it : threads_) {
		it.second->stop(true);
	}
	threads_.clear();
}

std::shared_ptr<NamedThread> ThreadManager::create_thread(const std::string& name) {
	std::lock_guard<std::mutex> lock(mutex_);
	auto it = threads_.find(name);
	if (it != threads_.end()) {
		return it->second;
	}
	auto thread = std::make_shared<NamedThread>(name);
	threads_[name] = thread;
	return thread;
}

std::shared_ptr<NamedThread> ThreadManager::create_named_thread_with_prefix(const std::string& prefix) {
	std::string name = generate_unique_name(prefix);
	return create_thread(name);
}

std::shared_ptr<NamedThread> ThreadManager::get_thread(const std::string& name) {
	std::lock_guard<std::mutex> lock(mutex_);
	auto it = threads_.find(name);
	if (it == threads_.end()) {
		return nullptr;
	}
	return it->second;
}

void ThreadManager::post(const std::function<void()>& task, const std::string& name) {
	auto t = get_thread(name);
	if (t) t->post(task);
}

void ThreadManager::post_to_idle(const std::function<void()>& task) {
	post(task, "idle");
}

void ThreadManager::post_to_ui(const std::function<void()>& task) {
	post(task, "ui");
}

void ThreadManager::sync(const std::function<void()>& task, const std::string& name) {
	auto t = get_thread(name);
	if (t) t->sync(task);
}

void ThreadManager::wait(const std::string& name) {
	auto t = get_thread(name);
	if (t) t->wait();
}

void ThreadManager::stop(const std::string& name, bool wait) {
	std::shared_ptr<NamedThread> thread;
	{
		std::lock_guard<std::mutex> lock(mutex_);
		auto it = threads_.find(name);
		if (it == threads_.end()) return;
		thread = it->second;
	}
	thread->stop(wait);
	post_to_idle([this, name]() {
		remove_thread(name);
		});
}

void ThreadManager::stop(std::shared_ptr<NamedThread>& thread_ref, bool wait) {
	if (!thread_ref) return;
	std::string name = thread_ref->name();
	thread_ref->stop(wait);
	post_to_idle([this, name, t = std::move(thread_ref)]() mutable {
		remove_thread(name);
		t.reset(); // ǿ���ͷ� thread_ref
		});
}

void ThreadManager::remove_thread(const std::string& name) {
	std::lock_guard<std::mutex> lock(mutex_);
	threads_.erase(name);
}

std::string ThreadManager::generate_unique_name(const std::string& prefix) {
	std::lock_guard<std::mutex> lock(mutex_);
	int index = prefix_counters_[prefix]++;
	return prefix + "_" + std::to_string(index);
}
