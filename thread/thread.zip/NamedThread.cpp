#include "NamedThread.h"

NamedThread::NamedThread(const std::string& name)
	: name_(name), stop_flag_(false), has_stopped_(false) {
	thread_ = std::thread([this]() { this->run(); });
}

NamedThread::~NamedThread() {
	//std::lock_guard<std::mutex> lock(mutex_);
	//if (!stop_flag_) {
	//	stop_flag_ = true;
	//	cond_.notify_all();
	//}

	//if (!has_stopped_ && thread_.joinable()) {
	//	thread_.join();
	//	has_stopped_ = true;
	//}
	std::lock_guard<std::mutex> lock(mutex_);
	if (!stop_flag_) {
		stop_flag_ = true;
		cond_.notify_all();
	}

	if (!has_stopped_ && thread_.joinable()) {
		thread_.join();
	}
}

void NamedThread::post(std::function<void()> task) {
	{
		std::lock_guard<std::mutex> lock(mutex_);
		if (stop_flag_) return;
		queue_.push(std::move(task));
	}
	cond_.notify_one();
}

void NamedThread::sync(std::function<void()> task) {
	std::promise<void> done;
	post([&task, &done]() {
		task();
		done.set_value();
		});
	done.get_future().wait();
}

void NamedThread::wait() {
	std::unique_lock<std::mutex> lock(mutex_);
	cond_empty_.wait(lock, [this]() {
		return queue_.empty();
		});
}

void NamedThread::stop(bool wait) {
	//{
	//	std::lock_guard<std::mutex> lock(mutex_);
	//	if (stop_flag_) return;
	//	stop_flag_ = true;
	//}

	//cond_.notify_all();

	//if (wait) {
	//	std::lock_guard<std::mutex> join_lock(mutex_);
	//	if (!has_stopped_ && thread_.joinable()) {
	//		thread_.join();
	//		has_stopped_ = true;
	//	}
	//}


	std::lock_guard<std::mutex> lock(mutex_);
	if (stop_flag_) return;
	stop_flag_ = true;
	cond_.notify_all();

	if (wait && !has_stopped_ && thread_.joinable()) {
		thread_.join();
	}
}

std::string NamedThread::name() const {
	return name_;
}

void NamedThread::run() {
	while (true) {
		std::function<void()> task;

		{
			std::unique_lock<std::mutex> lock(mutex_);
			cond_.wait(lock, [this]() {
				return stop_flag_ || !queue_.empty();
				});

			if (stop_flag_ && queue_.empty()) {
				break;
			}

			if (!queue_.empty()) {
				task = std::move(queue_.front());
				queue_.pop();
			}
		}

		if (task) {
			task();
		}

		{
			std::lock_guard<std::mutex> lock(mutex_);
			if (queue_.empty()) {
				cond_empty_.notify_all();
			}
		}
	}
}
