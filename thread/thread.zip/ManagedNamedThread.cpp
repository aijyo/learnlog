// ManagedNamedThread.cpp
#include "ManagedNamedThread.h"
#include "ThreadManager.h"

ManagedNamedThread::ManagedNamedThread(const std::string& name_prefix)
	: thread_(ThreadManager::instance().create_named_thread_with_prefix(name_prefix)) {
}

ManagedNamedThread::~ManagedNamedThread() {
	if (thread_) {
		ThreadManager::instance().stop(thread_, false);
	}
}

ManagedNamedThread::ManagedNamedThread(ManagedNamedThread&& other) noexcept {
	thread_ = std::move(other.thread_);
}

ManagedNamedThread& ManagedNamedThread::operator=(ManagedNamedThread&& other) noexcept {
	if (this != &other) {
		thread_ = std::move(other.thread_);
	}
	return *this;
}

void ManagedNamedThread::post(std::function<void()> task) {
	if (thread_) thread_->post(std::move(task));
}

void ManagedNamedThread::sync(std::function<void()> task) {
	if (thread_) thread_->sync(std::move(task));
}

void ManagedNamedThread::wait() {
	if (thread_) thread_->wait();
}

void ManagedNamedThread::stop(bool wait) {
	if (thread_) ThreadManager::instance().stop(thread_, wait);
}

std::string ManagedNamedThread::name() const {
	return thread_ ? thread_->name() : "";
}